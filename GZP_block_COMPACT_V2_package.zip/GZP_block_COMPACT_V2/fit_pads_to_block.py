import cadquery as cq,json,sys
from pathlib import Path
P=Path(__file__).resolve().parent;rs=json.loads((P/'compact_contact_points.json').read_text());print('Import block for exact boolean fit',flush=True)
b=cq.importers.importStep(sys.argv[1] if len(sys.argv)>1 else str(P/'770-1002015-10_asm.stp')).val().Solids()[0];out=[]
for r in rs:
 x,y,z=r['source_point_mm'];assert r['outward_normal'][1]<-.9
 stock=cq.Workplane('XY').box(16,16,8).translate((x,y,z)).val();result=stock.cut(b);solids=result.Solids();pad=max(solids,key=lambda q:q.Volume());vol=pad.Volume();name=f'pad_source_{int(x)}_{int(z)}.step';cq.exporters.export(pad,str(P/'reference_faces'/name));r['pad_file']=name
 common=pad.intersect(b);overlap=common.Volume() if common.Solids() else 0.0
 a={'source_center_mm':[x,y,z],'method':'16x16x8 mm stock minus exact block solid','stock_volume_mm3':2048,'finished_volume_mm3':vol,'raw_solid_count':len(solids),'valid':pad.isValid(),'interference_with_block_mm3':overlap,'load_capacity_verified':False};out.append(a);print(a,flush=True)
(P/'compact_contact_points.json').write_text(json.dumps(rs,indent=2));(P/'contact_footprints.json').write_text(json.dumps(out,indent=2))
