"""Compact V2. Preliminary CAD geometry, not approved for manufacturing or lifting.
Internal axes: X=source X+410, Y=-source Z, Z=source Y-190.
"""
import cadquery as cq, math, json, csv
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
CONTACTS=json.loads((ROOT/'compact_contact_points.json').read_text())
P={'version':'COMPACT_V2','supersedes':'GZP_block_PRELIMINARY V1',
'origin_source_mm':[-410,190,0],'station_source_x':[-540,-280],
'station_span_mm':260,'beam_side_y_internal':175,'beam_center_z_internal':270,
'crossbeam_length_mm':340,'hook_plate_thickness_mm':14,'plate_thickness_mm':16,
'pad_stock_mm_X_Y_Z_source':[16,16,8],'source_contact_points':CONTACTS,
'kinematics_verified':False,'strength_verified':False,'rated_load_kg':None,
'status':'PRELIMINARY_NOT_FOR_MANUFACTURE'}
(ROOT/'parameters.json').write_text(json.dumps(P,indent=2))
parts=[]
COLORS={'steel':(.16,.18,.21),'bright':(.66,.70,.74),'red':(.78,.025,.035),'pad':(.28,.37,.45)}
SRC=cq.Location(cq.Vector(-410,190,0),cq.Vector(1,0,0),-90)
def box(l,w,h,x,y,z):return cq.Workplane('XY').box(l,w,h).translate((x,y,z)).val()
def cyl(r,l,p,d=(0,0,1)):return cq.Solid.makeCylinder(r,l,cq.Vector(*p),cq.Vector(*d))
def add(name,s,color='steel',note='',custom=False):
 if isinstance(s,cq.Workplane):s=s.val()
 parts.append(dict(name=name,shape=s,color=color,note=note,custom=custom)); return s

def prof_yz(points,thick,x):return cq.Workplane('YZ',origin=(x-thick/2,0,0)).polyline(points).close().extrude(thick).val()
def tube_x(l,wy,hz,t,x,y,z):return box(l,wy,hz,x,y,z).cut(box(l+2,wy-2*t,hz-2*t,x,y,z))
def tube_y(l,wx,hz,t,x,y,z):return box(wx,l,hz,x,y,z).cut(box(wx-2*t,l+2,hz-2*t,x,y,z))
def rod(a,b,r):
 d=cq.Vector(*b)-cq.Vector(*a);return cyl(r,d.Length,a,d.normalized().toTuple())
def slot_x(s,x,y,z,length=50,width=13,depth=60):
 cutter=cq.Workplane('YZ',origin=(x-depth/2,0,0)).center(y,z).slot2D(length,width,90).extrude(depth).val()
 return s.cut(cutter)
def hexprism(r,l,x,y,z,axis='X'):
 plane={'X':'YZ','Z':'XY'}[axis]
 return cq.Workplane(plane,origin=(x,y,z)).polygon(6,2*r).extrude(l).val()
def bolt_x(name,x,y,z,length=40,d=12):
 s=cyl(d/2,length,(x,y,z),(1,0,0));head=cyl(d*.75,d,(x+length,y,z),(1,0,0))
 head=head.cut(hexprism(d*.30,d*.55,x+length+d*.5,y,z))
 add(name,s.fuse(head),'bright','Generic fastener; thread represented by major diameter')
 add(name+'_washer',cyl(d*.9,2.5,(x+length-2.5,y,z),(1,0,0)).cut(cyl(d*.55,4,(x+length-3,y,z),(1,0,0))),'bright')
def bolt_z(name,x,y,z,length=35,d=12):
 s=cyl(d/2,length,(x,y,z));head=cyl(d*.75,d,(x,y,z+length));head=head.cut(hexprism(d*.30,d*.55,x,y,z+length+d*.5,'Z'))
 add(name,s.fuse(head),'bright','Generic fastener; threads simplified')

mpx=-16.; drive_x=mpx+65
# Compact transverse hanging plate and two short crossbeams.
plate=prof_yz([(-235,300),(-235,490),(235,490),(235,300),(207,300),(207,250),(143,250),(143,300)],16,mpx)
for yy in [-210,-185,-90,-60,-30,0,30,60,90,185,210]:
 plate=plate.cut(cyl(10 if abs(yy)<=90 else 6.5,30,(mpx-15,yy,465),(1,0,0)))
for yy in [-120,120]:
 cut=cq.Workplane('YZ',origin=(mpx-15,0,0)).center(yy,402).rect(184,76).extrude(30).edges('|X').fillet(10).val();plate=plate.cut(cut)
plate=plate.cut(cyl(6.5,30,(mpx-15,-175,320),(1,0,0)))
add('01_Compact_hanging_plate',plate,custom=True,note='Photo architecture; assumed contour, 16 mm thickness')
for xx in [mpx-60,mpx+60]:
 add(f'02_Guide_{xx:g}',box(30,510,30,xx,0,245),custom=True)
 for yy in [-235,235]:
  stop=box(44,16,48,xx,yy,245).cut(box(30.8,20,30.8,xx,yy,245));add(f'03_Guide_stop_{xx:g}_{yy}',stop,custom=True)
 support=box(44,50,60,xx,175,260).cut(box(30.8,55,30.8,xx,175,245));add(f'04_Fixed_support_{xx:g}',support,custom=True)
 for yy in [158,192]:bolt_z(f'Fixed_support_bolt_{xx:g}_{yy}',xx,yy,281,12,8)

for side in [-1,1]:
 by=175*side
 add(f'05_Short_crossbeam_{side}',tube_x(340,50,40,4,0,by,270),custom=True,note='Tentative 50x40x4 profile, 340 mm length')
 for xx in [-170,170]:add(f'Crossbeam_cap_{side}_{xx}',box(4,50,40,xx,by,270),custom=True)
 for origx,xx in [(-540.,-130.),(-280.,130.)]:
  # Positive internal Y corresponds to negative source Z.
  srcz=-120. if side==1 else 130.
  r=next(c for c in CONTACTS if c['source_point_mm'][0]==origx and c['source_point_mm'][2]==srcz)
  sx,sy,sz=r['source_point_mm'];contact=cq.Vector(sx+410,-sz,sy-190);toe_top=contact.z-6.3
  inner=110 if side==1 else 120
  pts=[(side*159,toe_top-14),(side*191,toe_top-14),(side*191,290),(side*159,290),(side*159,toe_top),(side*inner,toe_top),(side*inner,toe_top-14)]
  hook=prof_yz(pts,14,xx)
  try:hook=cq.Workplane(obj=hook).edges('|X').fillet(2).val()
  except Exception:pass
  for zz in [247,272]:hook=hook.cut(cyl(5.5,28,(xx-14,by,zz),(1,0,0)))
  add(f'06_Short_hook_{side}_{int(origx)}',hook,custom=True,note='Individual toe height from proposed casting-ledge contact; 14 mm thickness tentative')
  # Source-normal transformed to internal axes; top plane lies on exact CAD face.
  nx,ny,nz=r['outward_normal'];up=cq.Vector(-nx,nz,-ny).normalized();xd=cq.Vector(1,0,0);xd=(xd-up*xd.dot(up)).normalized()
  to_internal=cq.Location(cq.Vector(410,0,-190),cq.Vector(1,0,0),90)
  pad=cq.importers.importStep(str(ROOT/'reference_faces'/r['pad_file'])).val().moved(to_internal)
  add(f'07_Conformal_contact_pad_{side}_{int(origx)}',pad,'pad',custom=True,note='Top surface cut by exact block geometry; local strength and casting tolerances NOT verified')
  # Individual seat beneath inclined pad, with small welded overlap at the toe.
  seat=box(24,18,4,xx,contact.y,contact.z-7.7)
  add(f'08_Pad_seat_{side}_{int(origx)}',seat,custom=True,note='Tentative seat; weld and tolerances TBD')
  gus=prof_yz([(side*159,235),(side*159,290),(side*136,290)],10,xx+(12 if xx>0 else -12));add(f'09_Upper_gusset_{side}_{int(origx)}',gus,custom=True)
  hx=xx+(16 if xx>0 else -16)
  grip=prof_yz([(side*162,231),(side*188,231),(side*188,288),(side*162,288),(side*162,275),(side*108,275),(side*108,259),(side*162,259)],8,hx)
  grip=slot_x(grip,hx,by,259,44,11,20)
  add(f'10_Adjustable_handle_{side}_{int(origx)}',grip,'bright',custom=True)
  for zz in [247,272]:bolt_x(f'Handle_bolt_{side}_{int(origx)}_{zz}',hx-14,by,zz,21,10)
 for xx in [mpx-60,mpx+60]:
  sleeve=tube_y(66,44,44,6,xx,by,245);add(f'11_Slider_sleeve_{side}_{xx:g}',sleeve,custom=True,note='Nominal 1 mm guide clearance; fits not approved')
  add(f'12_Sleeve_bridge_{side}_{xx:g}',box(50,66,8,xx,by,270),custom=True)
  for dy in [-22,22]:bolt_z(f'Slider_bolt_{side}_{xx:g}_{dy}',xx,by+dy,273,10,8)

# Compact drive layout. The motion and over-centre locking remain unverified.
add('13_Drive_mount',box(90,90,10,mpx+38,120,316),custom=True)
for xx in [mpx+10,mpx+65]:
 for yy in [94,146]:bolt_z(f'Drive_mount_bolt_{xx}_{yy}',xx,yy,316,10,8)
for xx in [drive_x-14,drive_x+14]:
 bracket=box(8,40,36,xx,120,338).cut(cyl(5.2,16,(xx-8,120,340),(1,0,0)));add(f'14_Pivot_bracket_{xx:g}',bracket,custom=True)
def link(name,a,b,x,th=6,width=19):
 dy=b[0]-a[0];dz=b[1]-a[1];ln=math.hypot(dy,dz)
 s=cq.Workplane('YZ',origin=(x-th/2,0,0)).center((a[0]+b[0])/2,(a[1]+b[1])/2).slot2D(ln+width,width,math.degrees(math.atan2(dz,dy))).extrude(th).val()
 for yy,zz in [a,b]:s=s.cut(cyl(5.2,th+4,(x-th/2-2,yy,zz),(1,0,0)))
 return add(name,s,'bright',custom=True,note='Concept drive link; motion and locking unverified')
A=(120,340);B=(75,337);C=(15,340)
link('15_Toggle_lever',A,B,drive_x,8)
for xx in [drive_x-9,drive_x+9]:link(f'16_Toggle_fork_{xx:g}',B,C,xx)
for j,(yy,zz) in enumerate([A,B,C]):
 add(f'Toggle_pin_{j}',cyl(5,44,(drive_x-22,yy,zz),(1,0,0)),'bright')
 for xx in [drive_x-24,drive_x+22]:add(f'Pin_head_{j}_{xx}',cyl(8,2,(xx,yy,zz),(1,0,0)),'bright')
add('17_Lever_extension',rod((drive_x,75,337),(drive_x,-65,327),6),'bright',custom=True)
add('18_Red_grip',rod((drive_x,6,332),(drive_x,-72,326),12),'red',custom=True)
for yy in [-5,-20,-35,-50,-65]:add(f'Grip_rib_{yy}',cyl(13,4,(drive_x,yy,332+(yy-6)*6/78),(0,-1,-6/78)),'red')
add('19_Push_rod',cyl(8,190,(drive_x,-175,340),(0,1,0)),'bright',custom=True,note='Threads simplified as cylinders')
add('20_Rod_guide',cyl(15,50,(drive_x,-35,340),(0,1,0)).cut(cyl(8.5,54,(drive_x,-37,340),(0,1,0))),custom=True)
add('21_Moving_drive_lug',box(28,22,76,drive_x,-175,316).cut(cyl(8.5,28,(drive_x,-189,340),(0,1,0))),custom=True)
add('22_Rod_stop',box(26,12,26,drive_x,-189,340).cut(cyl(8.5,16,(drive_x,-198,340),(0,1,0))),custom=True)
add('23_Lock_lug',box(12,30,46,mpx+34,-175,311).cut(cyl(6.5,20,(mpx+24,-175,320),(1,0,0))),custom=True)
add('24_Lock_pin',cyl(6,76,(mpx-16,-175,320),(1,0,0)).fuse(cyl(11,9,(mpx+60,-175,320),(1,0,0))),'bright',custom=True,note='Locking sequence and retention not validated')
# Certified purchased lifting shackle must replace this envelope-only shape.
path=cq.Workplane('XZ').moveTo(mpx-25,465).lineTo(mpx-25,515).threePointArc((mpx,540),(mpx+25,515)).lineTo(mpx+25,465).wire()
sh=cq.Workplane('XY',origin=(mpx-25,0,465)).circle(8).sweep(path).val()
for xx in [mpx-25,mpx+25]:sh=sh.fuse(cyl(14,16,(xx-8,0,465),(1,0,0)).cut(cyl(9,20,(xx-10,0,465),(1,0,0))))
add('25_Shackle_REFERENCE_ONLY',sh,'bright',note='Envelope only, not a rated or selected manufacturing component')
add('26_Shackle_pin_REFERENCE_ONLY',cyl(8.5,84,(mpx-42,0,465),(1,0,0)).fuse(hexprism(14,8,mpx+42,0,465)),'red',note='Select certified hardware; do not manufacture this placeholder')
# Export in ORIGINAL STEP coordinates so the supplied block overlays without moving.
assy=cq.Assembly(name='GZP_BLOCK_COMPACT_V2_NOT_FOR_MANUFACTURE')
validation=[];meshv=[];meshf=[];off=0
for r in parts:
 name=r['name'];s=r['shape'];placed=s.moved(SRC)
 assy.add(placed,name=name,color=cq.Color(*COLORS[r['color']]))
 ok=s.isValid();vol=s.Volume();n=len(s.Solids())
 validation.append(dict(name=name,valid=ok,solid_count=n,volume_mm3=vol,note=r['note']))
 verts,tris=placed.tessellate(.15,.16)
 vv=np.array([a.toTuple() for a in verts]);ff=np.array(tris);meshv.append(vv);meshf.append(ff+off);off+=len(vv)
 if r['custom']:
  cq.exporters.export(placed,str(ROOT/'parts'/f'{name}.stp'),exportType='STEP')
  cq.exporters.export(placed,str(ROOT/'parts'/f'{name}.stl'),tolerance=.15,angularTolerance=.16)
# Standard assembly STEP (individual named components, not flattened fused solid).
assy.export(str(ROOT/'GZP_block_COMPACT_V2.stp'),exportType='STEP')
compound=cq.Compound.makeCompound([r['shape'].moved(SRC) for r in parts])
cq.exporters.export(compound,str(ROOT/'GZP_block_COMPACT_V2.stl'),tolerance=.15,angularTolerance=.16)
np.savez_compressed(ROOT/'gripper_mesh.npz',v=np.vstack(meshv),f=np.vstack(meshf))
(ROOT/'validation.json').write_text(json.dumps({'component_count':len(parts),'components':validation,'all_components_valid':all(x['valid'] and x['volume_mm3']>0 for x in validation),'coordinate_frame':'original source STEP','stl_unit_convention':'mm','collision_check':'not performed','kinematic_validation':'not performed','strength_verification':'not performed'},indent=2))
with (ROOT/'component_register.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['component','status','material','note']);w.writerows([[r['name'],'PRELIMINARY','TBD',r['note']] for r in parts])
print(json.dumps({'component_count':len(parts),'valid':all(r['valid'] for r in validation),'STP_bytes':(ROOT/'GZP_block_COMPACT_V2.stp').stat().st_size,'STL_bytes':(ROOT/'GZP_block_COMPACT_V2.stl').stat().st_size}),flush=True)
