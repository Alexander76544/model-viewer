# -*- coding: utf-8 -*-
r"""step2stl.py — портативный STEP(.stp/.step) -> binary STL конвертер (3d-viewer pipeline).

Пишет binary STL для вьювера «3D просмотр моделей». Бэкенды (по убыванию предпочтения):

[gmsh]       python-модуль gmsh (pip install gmsh — без прав админа): импорт STEP через
             OpenCascade + ЧВЕТ из XCAF (COLOUR_RGB/SURFACE_STYLE_USAGE). Цвет фасетки —
             в 16-битном attribute-байте STL (RGB555 + старший бит-флаг); неокрашенные —
             серый из заголовка (COLOR=).
[fc-xcaf]    Внутри GUI FreeCAD (консоль Python): цвета из ViewObject по компонентам сборки.
[fc-plain]   freecadcmd без gmsh: вся геометрия одним проходом BRepMesh, без цветов.

Запуск:
1) Windows: перетащить .stp/.step на step2stl.bat — бэкенд выбирается сам
   (сначала python+gmsh, затем freecadcmd). Качество: set FC_LIN=<мм> (0.2 по умолчанию),
   цвет вкл/выкл: set FC_COLOR=1|0.
2) cmd, параметры переменными окружения (freecadcmd не передаёт аргументы скрипту):
      set S2S_SRC=C:\модель.stp
      set S2S_DST=C:\out\модель.stl      (по умолчанию — рядом с источником)
      set S2S_LIN=0.2  S2S_ANG=0.5  S2S_REL=1  S2S_COLOR=1  S2S_DST2=...  S2S_LIN2=0.6
      python step2stl.py   (или)   <...>\freecadcmd.exe step2stl.py
3) GUI FreeCAD (Вид → Консоль Python):
      ns = {}
      exec(open(r"D:\\step2stl-portable\\step2stl.py", encoding="utf-8").read(), ns)
      ns["main"](r"C:\\модель.stp", lin=0.2)

lin — линейная дефлексия, мм. Ориентиры: 0.2 — баланс; 0.15–0.17 — максимум деталей
(до ~1 ГБ STL на большую сборку); 0.5..1 — лёгкие превью.
"""
import os, sys, time, struct

_HDR = (b'COLOR=' + bytes((0x94, 0xA3, 0xB8, 0xFF)) + b' step2stl colored binary STL')[:80].ljust(80, b' ')


def _log(msg):
    print('[step2stl] ' + msg)
    try:
        sys.stdout.flush()
    except Exception:
        pass


def _rgb565(rgb):
    """(r,g,b) в шкале 0..1 или 0..255 -> RGB555 uint16 со старшим битом-флагом (читает viewer)."""
    if rgb is None:
        return 0
    try:
        r, g, b = float(rgb[0]), float(rgb[1]), float(rgb[2])
        if max(r, g, b) > 1.01:
            r, g, b = r / 255.0, g / 255.0, b / 255.0
        r5 = int(round(max(0.0, min(1.0, r)) * 31))
        g5 = int(round(max(0.0, min(1.0, g)) * 31))
        b5 = int(round(max(0.0, min(1.0, b)) * 31))
    except Exception:
        return 0
    return 0x8000 | (r5 << 10) | (g5 << 5) | b5


class StlWriter(object):
    """Потоковый writer binary STL с палитрой по фасеткам. total считается сам."""

    def __init__(self, path):
        self.f = open(path, 'wb')
        self.f.write(_HDR)
        self.f.write(struct.pack('<I', 0))
        self.total = 0

    def write_np(self, verts, attr):
        """verts: (n,3,3) float (np массив или вложенные списки), attr: uint16."""
        import numpy as np
        v = np.ascontiguousarray(verts, dtype='<f4')
        n = int(v.shape[0])
        if not n:
            return
        cr = np.cross(v[:, 1] - v[:, 0], v[:, 2] - v[:, 0])
        ln = np.linalg.norm(cr, axis=1)
        ln[ln == 0] = 1.0
        cr = cr / ln[:, None]
        rec = np.zeros((n, 25), dtype='<u2')
        rec[:, 0:6] = cr.view('<u2')
        rec[:, 6:24] = v.reshape(n, 9).view('<u2')
        rec[:, 24] = np.uint16(attr)
        self.f.write(rec.tobytes())
        self.total += n

    def write_iter(self, facets, attr):
        """facets: итерат по ((x,y,z)x3 v0,v1,v2); без numpy."""
        pack = struct.Struct('<12fH').pack
        buf = bytearray()
        nf = 0
        for (a, b, c) in facets:
            ux = b[0] - a[0]; uy = b[1] - a[1]; uz = b[2] - a[2]
            vx = c[0] - a[0]; vy = c[1] - a[1]; vz = c[2] - a[2]
            nx = uy * vz - uz * vy; ny = uz * vx - ux * vz; nz = ux * vy - uy * vx
            l = (nx * nx + ny * ny + nz * nz) ** 0.5 or 1.0
            buf += pack(nx / l, ny / l, nz / l, a[0], a[1], a[2],
                        b[0], b[1], b[2], c[0], c[1], c[2], attr)
            nf += 1
            if len(buf) >= (1 << 20):
                self.f.write(bytes(buf))
                buf = bytearray()
        if buf:
            self.f.write(bytes(buf))
        self.total += nf

    def footer(self):
        self.f.seek(80)
        self.f.write(struct.pack('<I', self.total))
        self.f.close()


# ============================ бэкенд 1: gmsh (цвета) ============================
def run_gmsh(src, dst, lin):
    import gmsh
    gmsh.initialize()
    try:
        gmsh.option.setNumber('General.Verbosity', 0)
        # калибровка по Schenkel-свипу: tris ~ 36/curv^1.35; min/maxe = пол/потолок поля
        curv = int(max(8, min(200, round(36.0 * (0.2 / max(lin, 1e-3)) ** 0.5))))
        maxe = max(4.0, 150.0 * lin)
        gmsh.option.setNumber('Mesh.MeshSizeFromCurvature', curv)
        gmsh.option.setNumber('Mesh.MeshSizeMax', maxe)
        gmsh.option.setNumber('Mesh.MeshSizeMin', max(0.2, 2.0 * lin))
        # обход «Identical points in triangulation» на плотных CAD-сборках
        try:
            gmsh.option.setNumber('Mesh.RandomFactor', 0.01)
            gmsh.option.setNumber('Mesh.SmallElementCoef', 0.)
        except Exception:
            pass
        _log('gmsh: opening %s (CurvDiv=%d, MeshSizeMax=%.1f mm)...' % (src, curv, maxe))
        t0 = time.time()
        gmsh.open(src)
        _log('gmsh: opened in %.0fs, meshing (silent phase is normal)...' % (time.time() - t0))
        t0 = time.time()
        gmsh.model.mesh.generate(2)
        _log('gmsh: mesh generated in %.0fs' % (time.time() - t0))
        faces = gmsh.model.getEntities(2)
        try:
            import numpy as np
            have_np = True
        except Exception:
            have_np = False
        # глобальная таблица координат узлов (id 1..N подряд)
        all_ids, all_xyz = gmsh.model.mesh.getNodes(-1, -1)[:2]
        if have_np:
            NPOS = np.asarray(all_xyz, dtype=np.float64).reshape(-1, 3)
            NID0 = int(all_ids[0]) if len(all_ids) else 1
        else:
            NPOS = [tuple(all_xyz[i * 3:i * 3 + 3]) for i in range(len(all_ids))]
            NID0 = int(all_ids[0]) if len(all_ids) else 1
        w = StlWriter(dst)
        t0 = time.time()
        ncol_faces = 0
        skipped_types = set()
        for i, (dim, tag) in enumerate(faces):
            try:
                r, g, b, a = gmsh.model.getColor(dim, tag)
            except Exception:
                r = g = b = a = 0.0
            attr = _rgb565((r, g, b)) if a > 0 else 0
            if attr:
                ncol_faces += 1
            etypes, etags, enodes = gmsh.model.mesh.getElements(2, tag)
            if not etypes:
                continue
            for et, en in zip(etypes, enodes):
                et = int(et)
                nv = {2: 3, 9: 6}.get(et)          # triangle, triangle6 (берём угловые)
                if nv is None:
                    skipped_types.add(et)
                    continue
                ne = len(en) // nv
                if have_np:
                    idx = np.asarray(en, dtype=np.int64) - NID0
                    verts = NPOS[idx].reshape(ne, nv, 3)[:, :3, :]
                    w.write_np(verts, attr)
                else:
                    en = list(en)
                    tris = []
                    for j in range(ne):
                        ids = en[j * nv:j * nv + 3]
                        tris.append((NPOS[ids[0] - NID0], NPOS[ids[1] - NID0], NPOS[ids[2] - NID0]))
                    w.write_iter(tris, attr)
            if (i + 1) % 500 == 0 or i + 1 == len(faces):
                _log('gmsh: faces %d/%d (%.0fs), facets=%d' % (i + 1, len(faces), time.time() - t0, w.total))
        w.footer()
        if skipped_types:
            _log('gmsh: пропущены типы элементов %s (не треугольники)' % sorted(skipped_types))
        _log('gmsh: wrote %s (%.1f MB, %d facets, %d/%d faces colored)' % (
            dst, os.path.getsize(dst) / 1048576.0, w.total, ncol_faces, len(faces)))
        if w.total == 0:
            raise RuntimeError('gmsh вернул пустую сетку')
        return w.total
    finally:
        try:
            gmsh.finalize()
        except Exception:
            pass


# ==================== бэкенд 2: FreeCAD XCAF (цвета, GUI-режим) ====================
def _obj_color(o):
    vo = getattr(o, 'ViewObject', None)
    if vo is None:
        return None
    try:
        c = vo.ShapeColor
        if isinstance(c, (tuple, list)) and len(c) >= 3:
            return (float(c[0]), float(c[1]), float(c[2]))
        if c is not None and hasattr(c, 'r'):
            return (c.r, c.g, c.b)
    except Exception:
        pass
    try:
        sm = vo.ShapeMaterial
        for holder in (sm, getattr(sm, 'Material', None)):
            if holder is None:
                continue
            d = getattr(holder, 'Diffuse', None)
            if d is not None and hasattr(d, 'r'):
                return (d.r, d.g, d.b)
    except Exception:
        pass
    return None


def _leaf_shapes(doc):
    out = []

    def walk(o):
        grp = getattr(o, 'Group', None)
        if grp:
            for ch in grp:
                walk(ch)
            return
        shp = getattr(o, 'Shape', None)
        if shp is not None and hasattr(shp, 'Faces'):
            try:
                nf = len(shp.Faces)
            except Exception:
                nf = 0
            if nf:
                out.append((shp, _obj_color(o)))

    for o in doc.Objects:
        walk(o)
    return out


def _import_xcaf(src):
    import Import
    import FreeCAD as App
    before = set(App.listDocuments().keys())
    r = Import.insert(src)
    after = set(App.listDocuments().keys())
    new = list(after - before)
    if new:
        return App.getDocument(new[-1])
    if r is not None and hasattr(r, 'Objects'):
        return r
    if App.ActiveDocument is not None and hasattr(App.ActiveDocument, 'Objects'):
        return App.ActiveDocument
    return None


def _mesh_facets(m):
    pts = m.Points
    for f in m.Facets:
        idx = f.PointIndices
        yield pts[idx[0]], pts[idx[1]], pts[idx[2]]


def run_colored(src, dst, lin, ang, rel):
    import MeshPart
    import FreeCAD as App
    t0 = time.time()
    doc = _import_xcaf(src)
    if doc is None:
        raise RuntimeError('Import.insert не вернул документ')
    _log('fc-xcaf: import %.0fs, objects=%d' % (time.time() - t0, len(doc.Objects)))
    try:
        leaves = _leaf_shapes(doc)
        if not leaves:
            raise RuntimeError('нет лиственных форм')
        ncol = sum(1 for s, c in leaves if c is not None)
        _log('fc-xcaf: leaf shapes=%d, with color=%d' % (len(leaves), ncol))
        if ncol == 0:
            raise RuntimeError('XCAF не отдал ни одного цвета')
        w = StlWriter(dst)
        t0 = time.time()
        for i, (shp, col) in enumerate(leaves):
            m = MeshPart.meshFromShape(Shape=shp, LinearDeflection=lin, AngularDeflection=ang, Relative=rel)
            w.write_iter(_mesh_facets(m), _rgb565(col))
            del m
            if (i + 1) % 200 == 0 or i + 1 == len(leaves):
                _log('fc-xcaf: %d/%d shapes (%.0fs), facets=%d' % (i + 1, len(leaves), time.time() - t0, w.total))
        w.footer()
        _log('fc-xcaf: wrote %s (%.1f MB)' % (dst, os.path.getsize(dst) / 1048576.0))
        return w.total
    finally:
        try:
            App.closeDocument(doc.Name)
        except Exception:
            pass


# ==================== бэкенд 3: FreeCAD plain (без цветов) =======================
def run_plain(src, dst, lin, ang, rel, tag='main'):
    import Part, MeshPart
    t0 = time.time()
    shape = Part.Shape()
    shape.read(src)
    bb = shape.BoundBox
    _log('%s: STEP read in %.0fs — solids=%d shells=%d faces=%d bb=%.0fx%.0fx%.0f mm' % (
        tag, time.time() - t0, len(shape.Solids), len(shape.Shells), len(shape.Faces),
        bb.XLength, bb.YLength, bb.ZLength))
    t0 = time.time()
    _log('%s: tessellating everything (LinearDeflection=%s mm%s)... long silent phase is normal'
         % (tag, lin, ', relative' if rel else ''))
    m = MeshPart.meshFromShape(Shape=shape, LinearDeflection=lin, AngularDeflection=ang, Relative=rel)
    _log('%s: facets=%d points=%d in %.0fs' % (tag, m.CountFacets, m.CountPoints, time.time() - t0))
    t0 = time.time()
    m.write(dst)
    _log('%s: wrote %s (%.1f MB) in %.0fs' % (tag, dst, os.path.getsize(dst) / 1048576.0, time.time() - t0))
    return m.CountFacets


# ================================ диспетчер =====================================
def _has_gmsh():
    try:
        import gmsh
        return True
    except Exception:
        return False


def _has_freecad():
    try:
        import Part
        return True
    except Exception:
        return False


def main(src, dst=None, lin=0.2, ang=0.5, rel=False, preview_dst=None, plin=0.6, color=1):
    src = os.path.abspath(src)
    if not os.path.isfile(src):
        raise IOError('файл не найден: ' + src)
    if not dst:
        dst = os.path.splitext(src)[0] + '.stl'
    dst = os.path.abspath(dst)
    d = os.path.dirname(dst)
    if d:
        try:
            os.makedirs(d)
        except OSError:
            pass
    res = {'src': src, 'dst': dst, 'lin': lin}
    use_color = bool(color)

    def one(out_path, l, tag):
        errs = []
        if use_color and _has_gmsh():
            try:
                res.update(backend='gmsh', colored=True, facets=run_gmsh(src, out_path, l))
                return
            except BaseException as e:
                errs.append('gmsh: %r' % (e,))
                try:
                    os.remove(out_path)
                except OSError:
                    pass
        if _has_freecad():
            if use_color:
                try:
                    res.update(backend='fc-xcaf', colored=True, facets=run_colored(src, out_path, l, ang, rel))
                    return
                except BaseException as e:
                    errs.append('fc-xcaf: %r' % (e,))
                    try:
                        os.remove(out_path)
                    except OSError:
                        pass
            res.update(backend='fc-plain', colored=False, facets=run_plain(src, out_path, l, ang, rel, tag=tag))
            return
        raise RuntimeError('нет доступного бэкенда (' + ' | '.join(errs) +
                           '). Поставьте gmsh (pip install gmsh) или запустите через freecadcmd/FreeCAD.')

    one(dst, lin, 'main')
    if preview_dst:
        try:
            one(os.path.abspath(preview_dst), plin, 'preview')
            res['preview'] = preview_dst
        except BaseException as e:
            _log('preview pass failed: %r' % (e,))
    _log('done: %s' % res['dst'])
    return res


def _cli():
    src = os.environ.get('S2S_SRC')
    if not src:
        a = [x for x in sys.argv[1:] if os.path.basename(x).lower() != 'step2stl.py']
        if a:
            src = a[0]
    if not src:
        print(__doc__)
        print('ОШИБКА: не задан входной .stp/.step — перетащите файл на step2stl.bat.')
        return 2
    kw = {}
    if os.environ.get('S2S_DST'):
        kw['dst'] = os.environ['S2S_DST']
    if os.environ.get('S2S_LIN'):
        kw['lin'] = float(os.environ['S2S_LIN'])
    if os.environ.get('S2S_ANG'):
        kw['ang'] = float(os.environ['S2S_ANG'])
    kw['rel'] = os.environ.get('S2S_REL') == '1'
    kw['color'] = os.environ.get('S2S_COLOR', '1') != '0'
    if os.environ.get('S2S_DST2'):
        kw['preview_dst'] = os.environ['S2S_DST2']
        kw['plin'] = float(os.environ.get('S2S_LIN2', '0.6'))
    main(src, **kw)
    return 0


def _is_main_module():
    try:
        return __name__ == '__main__'
    except NameError:
        return False


if _is_main_module() or os.environ.get('S2S_SRC'):
    try:
        sys.exit(_cli())
    except SystemExit:
        raise
    except BaseException:
        traceback = __import__('traceback')
        traceback.print_exc()
        raise SystemExit(1)
