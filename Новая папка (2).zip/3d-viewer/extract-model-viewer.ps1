# Build a pure 3D model viewer (STL/OBJ/STEP) from the PC-DMIS generator:
# everything program/element/dimension-specific is stripped, only the 3D scene machinery stays.
$ErrorActionPreference = 'Stop'
$src = 'C:\Workspace\3d\pcdmis-generator-5.html'
$dst = 'C:\Workspace\3d-viewer\index.html'
$L = Get-Content $src
function Range([int]$a, [int]$b) { ($L[($a-1)..($b-1)] -join "`n") }

# ============================================================ HTML ============
$head = Range 1 103

$bodyTop = @'
</head>
<body>
<div class="grid-bg"></div>
<header>
  <div class="header-top">
    <div class="brand">
      <div class="brand-icon">◈</div>
      <div>
        <h1>3D ПРОСМОТР МОДЕЛЕЙ</h1>
        <p>STL · OBJ · STEP · полностью офлайн · вид и модель сохраняются автоматически</p>
      </div>
    </div>
    <div class="row" style="align-items:center;">
      <span id="autosaveIndicator" style="font-size:10.5px; color:var(--muted2); opacity:0.45; margin-right:6px; transition:opacity .3s;">автосохранение включено</span>
      <button class="btn" id="clearAutosaveBtn" title="Удалить автосохранённую в браузере 3D-модель и её вид">🗑</button>
    </div>
  </div>
</header>
<main>
'@

$sceneSection = Range 253 402
$modelBrowser = Range 461 472
$threeJs = Range 474 482

# ============================================================= JS =============
$useStrict = '"use strict";'
$elHelper = Range 2677 2688
$errMsg = Range 1516 1522

$customStatsClear = @'
// ---------------- инфо-строка о модели и очистка автосохранения ----------------
function updateModelStats3(){
  const statsEl = document.getElementById('threeStats');
  if(!statsEl) return;
  if(stlMesh3 && lastModelPositions){
    const tris = Math.round(lastModelPositions.length/9).toLocaleString('ru-RU');
    const box = new THREE.Box3().setFromObject(stlMesh3);
    const sz = box.isEmpty() ? null : box.getSize(new THREE.Vector3());
    const name = (document.getElementById('stlFileName')||{}).textContent || '';
    statsEl.textContent = `${name} · ${tris} трег.` + (sz ? ` · ${sz.x.toFixed(0)}×${sz.y.toFixed(0)}×${sz.z.toFixed(0)} мм` : '');
  } else {
    statsEl.textContent = 'модель не загружена — «⬆ Загрузить STL / OBJ / STEP»';
  }
}
function clearAutosave(){
  const ok = confirm('Удалить автосохранённые в браузере 3D-модель и её вид?');
  if(!ok) return;
  try{ idbDel('model'); idbDel('modelMeta'); }catch(e){}
  lastModelPositions = null; lastModelColors = null; modelRestored = true;
  updateModelStats3();
  alert('Автосохранение модели очищено.');
}
'@

$modelAutosave = Range 3277 3389
$decls = Range 3559 3593
$initThree = Range 3595 3773
$spectateFsCam = Range 3775 3917
$makeSprite = Range 3993 4018
$applyVisSlim = @'
function applyThreeVisibility(){
  const showStl = document.getElementById('showStlCb')?.checked ?? true;
  if(stlMesh3) stlMesh3.visible = showStl;
}
'@
$gridZero = Range 4289 4475
$stlParsers = Range 4481 4586
$transformBuild = Range 4635 4726
$views = Range 4728 4815
$stepAndWiring = Range 4943 5240
$modelBrowserJs = Range 5242 5304
$visWiring = Range 5305 5322
$stlFieldsWiring = Range 5341 5364
$clearBtnWiring = Range 5369 5369

$initBlock = @'
// ---- init ----
renderThreeViewButtons();
updateModelStats3();
initThree();
updateFullscreenUI();
setTimeout(()=>{ onThreeResize3(); focusCamera3(); restoreModelFromAutosave(); }, 80);
'@

$js = @($useStrict, $elHelper, $errMsg, $customStatsClear, $modelAutosave, $decls, $initThree, $spectateFsCam,
        $makeSprite, $applyVisSlim, $gridZero, $stlParsers, $transformBuild, $views, $stepAndWiring,
        $modelBrowserJs, $visWiring, $stlFieldsWiring, $clearBtnWiring, $initBlock) -join "`n"

$html = @($head, $bodyTop, $sceneSection, '</main>', '', $modelBrowser, '', $threeJs, '', '<script>', $js, '</script>', '</body>', '</html>') -join "`n"

# =========================================================== edits ===========
function ApplyEdit([string]$name, [string[]]$oldLines, [string[]]$newLines, [int]$expected = 1){
  $oldTxt = $oldLines -join "`n"
  $newTxt = if($newLines){ $newLines -join "`n" } else { '' }
  $cnt = ([regex]::Matches($script:html, [regex]::Escape($oldTxt))).Count
  if($cnt -ne $expected){ throw "edit '$name': expected $expected match(es), got $cnt" }
  $script:html = $script:html.Replace($oldTxt, $newTxt)
}

# ---- HTML edits ----
ApplyEdit 'html-hint' @(
'      <div class="hint" style="margin:0;">',
'        3D-просмотр программы: номинальные позиции элементов (голубым) и реальные измеренные ФАКТ-позиции',
'        (янтарным), с линией отклонения между ними — так видно все элементы, где факт отличается от номинала.',
'        Можно подгрузить свою модель детали в формате STL или OBJ как визуальный ориентир. Внутренний формат',
'        PC-DMIS «.CAD» (ссылка на IGES/STEP-геометрию) браузер прочитать не может — экспортируйте модель из',
'        PC-DMIS или CAD-системы в STL/OBJ. Кнопка «⇄ Зеркалировать» отражает всю программу (элементы, номиналы',
'        размеров X/Y/Z) и модель относительно выбранной оси — для зеркально симметричных деталей; повторное',
'        нажатие отменяет. Кнопка «⌖ Нулевая точка» (или клавиша <b>N</b> в режиме полёта) задаёт своё начало',
'        отсчёта в любом месте детали — координаты в режиме полёта тогда пишутся относительно неё.',
'      </div>'
) @(
'      <div class="hint" style="margin:0;">',
'        3D-просмотр моделей: STL, OBJ и STEP (.stp/.step) — включая цветной binary STL и STEP с аналитическими',
'        поверхностями (плоскости, цилиндры, конусы, торы, сферы). Панель «Совмещение STL» помогает посадить',
'        модель на нужное место, «Сечение STL» вскрывает внутреннюю геометрию, «⌖ Нулевая точка» (или клавиша',
'        <b>N</b> в режиме полёта) задаёт начало отсчёта координат, «⭳ Скачать все виды (JPG)» делает стандартные',
'        ортовиды. Внутренние CAD-форматы со ссылками на геометрию (например «.CAD») браузер не читает —',
'        экспортируйте модель в STL/OBJ/STEP.',
'      </div>')

ApplyEdit 'html-mirror-btns' @(
'        <button class="btn" id="mirrorXBtn" title="Зеркально отразить координаты, векторы всех элементов и номиналы X-размеров (только параметры, деталь/STL-модель не трогается). Повторное нажатие возвращает как было.">⇄ X</button>',
'        <button class="btn" id="mirrorYBtn" title="Зеркально отразить координаты, векторы всех элементов и номиналы Y-размеров (только параметры, деталь/STL-модель не трогается). Повторное нажатие возвращает как было.">⇄ Y</button>',
'        <button class="btn" id="mirrorZBtn" title="Зеркально отразить координаты, векторы всех элементов и номиналы Z-размеров (только параметры, деталь/STL-модель не трогается). Повторное нажатие возвращает как было.">⇄ Z</button>'
) @()

ApplyEdit 'html-checkboxes' @(
'    <div style="display:flex; gap:16px; flex-wrap:wrap; align-items:center; margin-bottom:10px; font-size:12px;">',
'      <label class="checkbox-row"><input type="checkbox" id="showNominalCb" checked> Номинал</label>',
'      <label class="checkbox-row"><input type="checkbox" id="showFactCb" checked> Факт / отклонения</label>',
'      <label class="checkbox-row"><input type="checkbox" id="showStlCb" checked> STL/OBJ-модель</label>',
'      <label class="checkbox-row"><input type="checkbox" id="showLabelsCb"> Подписи (имя + координаты)</label>',
'      <label class="checkbox-row"><input type="checkbox" id="showTolerancesCb"> Допуски размеров</label>',
'      <label class="checkbox-row"><input type="checkbox" id="showZonesCb" title="Рисовать геометрическое поле допуска (цилиндр/сфера позиции, пояс диаметра, slab формы/ориентации) и красить его при браке"> Зоны допусков (3D)</label>',
'      <label class="checkbox-row"><input type="checkbox" id="showDatumsCb" title="Отмечать базовые элементы знаком базы (треугольник) с их обозначением"> Знаки баз</label>',
'      <label class="checkbox-row"><input type="checkbox" id="depthIntoPartCb" checked> Глубина элементов внутрь детали</label>',
'      <label class="checkbox-row"><input type="checkbox" id="showAllOpsCb"> Показать все операции вместе</label>',
'      <span id="stlFileName" style="color:var(--muted2);"></span>',
'    </div>'
) @(
'    <div style="display:flex; gap:16px; flex-wrap:wrap; align-items:center; margin-bottom:10px; font-size:12px;">',
'      <label class="checkbox-row"><input type="checkbox" id="showStlCb" checked> STL/OBJ/STEP-модель</label>',
'      <span id="stlFileName" style="color:var(--muted2);"></span>',
'    </div>')

ApplyEdit 'html-group-filter' @(
'      <label class="checkbox-row" style="gap:6px;">Группа:',
'        <select id="groupFilterSel" title="Показать в 3D только элементы выбранной группы" style="width:auto;">',
'          <option value="__all__" selected>— все —</option>',
'        </select>',
'      </label>'
) @()

ApplyEdit 'html-legend' @(
'          <span style="color:#22d3ee;">●</span> номинал &nbsp;',
'          <span style="color:#f59e0b;">●</span> факт (измерено) &nbsp;',
'          <span style="color:#f87171;">╱</span> отклонение &nbsp;',
'          <span style="color:#94a3b8;">▦</span> STL/OBJ/STEP деталь<br>',
'          <span style="color:#5b677c;">ЛКМ — вращение · ПКМ — панорама · колесо — зум</span>'
) @(
'          <span style="color:#94a3b8;">▦</span> STL/OBJ/STEP деталь · <span style="color:#4ade80;">⌖</span> нулевая точка<br>',
'          <span style="color:#5b677c;">ЛКМ — вращение · ПКМ — панорама · колесо — зум</span>')

ApplyEdit 'html-sidebar' @(
'      <div style="width:230px; flex-shrink:0; display:flex; flex-direction:column; border:1px solid var(--border); border-radius:10px; background:rgba(20,26,38,.4); overflow:hidden;">',
'        <div style="padding:10px; border-bottom:1px solid var(--border);">',
'          <div class="section-label" style="margin-bottom:6px;">Элементы</div>',
'          <input type="text" id="elementSidebarSearch" placeholder="Поиск по имени…" class="mono" style="width:100%; background:#0a0e14; border:1px solid var(--border2); border-radius:5px; padding:6px 8px; font-size:12px; color:var(--text); outline:none;">',
'        </div>',
'        <div id="elementSidebarList" style="flex:1; overflow-y:auto; max-height:calc(65vh - 56px);"></div>',
'      </div>'
) @()

ApplyEdit 'html-section-active' @('<section class="tabpanel" id="tab-model">') @('<section class="tabpanel active" id="tab-model">')

ApplyEdit 'nav-css' @(
'  nav.tabs{max-width:1180px;margin:0 auto;padding:0 20px;display:flex;gap:2px;}',
'  nav.tabs button{background:none;border:none;border-bottom:2px solid transparent;color:var(--muted2);',
'    font-size:12.5px;padding:10px 14px;cursor:pointer;display:flex;align-items:center;gap:6px;transition:.15s;}',
'  nav.tabs button:hover{color:#c3ccd9;}',
'  nav.tabs button.active{color:var(--cyan);border-bottom-color:var(--cyan);}'
) @()

ApplyEdit 'title' @('<title>Генератор программ PC-DMIS</title>') @('<title>3D-просмотр моделей · STL / OBJ / STEP</title>')

# ---- JS edits ----
ApplyEdit 'decl-elem-group' @('let scene3, camera3, renderer3, elementsGroup3, stlMesh3;') @('let scene3, camera3, renderer3, stlMesh3;')
ApplyEdit 'decl-groupfilter' @("let groupFilter3 = '__all__';                 // фильтр 3D по имени группы ('__all__'|'__none__'|имя)") @()
ApplyEdit 'decl-ray' @('let raycaster3 = null, pointer3 = null, hoveredElementId = null;') @('let raycaster3 = null, pointer3 = null;')
ApplyEdit 'decl-pf' @(
'function pf(v, d){',
'  const n = parseFloat(v);',
'  if(!isNaN(n)) return n;',
'  const n2 = parseFloat(d);',
'  return isNaN(n2) ? 0 : n2;',
'}',
''
) @()
ApplyEdit 'decl-tothreedir' @(
'function toThreeDir(i,j,k){',
'  const v = new THREE.Vector3(i, k, j);',
'  if(v.lengthSq() < 1e-9) v.set(0,1,0);',
'  return v.normalize();',
'}'
) @()

ApplyEdit 'init-group-creation' @(
'  elementsGroup3 = new THREE.Group();',
'  scene3.add(elementsGroup3);',
''
) @()

ApplyEdit 'init-pick-fns' @(
'  const TYPE_LABEL3 = {plane:"ПЛОСКОСТЬ", cylinder:"ЦИЛИНДР", cone:"КОНУС", circle:"ОКРУЖНОСТЬ",',
'    circle_constructed:"ОКРУЖНОСТЬ (постр.)", point_measured:"ТОЧКА", point_constructed:"ТОЧКА (постр.)",',
'    line_constructed:"ПРЯМАЯ (постр.)"};',
'  function pickElementAt(clientX, clientY){',
'    if(!renderer3 || !elementsGroup3 || !elementsGroup3.children.length) return null;',
'    const rect = dom.getBoundingClientRect();',
'    if(!raycaster3) raycaster3 = new THREE.Raycaster();',
'    if(!pointer3) pointer3 = new THREE.Vector2();',
'    pointer3.x = ((clientX-rect.left)/rect.width)*2-1;',
'    pointer3.y = -((clientY-rect.top)/rect.height)*2+1;',
'    raycaster3.setFromCamera(pointer3, camera3);',
'    const hits = raycaster3.intersectObjects(elementsGroup3.children, true);',
'    for(const h of hits){',
'      let o = h.object;',
'      while(o){ if(o.userData && o.userData.elementId) return o.userData.elementId; o = o.parent; }',
'    }',
'    return null;',
'  }'
) @()

ApplyEdit 'mouseup-select' @(
'      if(zeroPickMode3){ placeZeroAtClient(e.clientX, e.clientY, ''⌖ Нулевая точка''); disarmZeroPick(); return; }',
'      const id = pickElementAt(e.clientX, e.clientY);',
'      if(id) selectElementInScene(id);'
) @(
'      if(zeroPickMode3){ placeZeroAtClient(e.clientX, e.clientY, ''⌖ Нулевая точка''); disarmZeroPick(); }'
)

ApplyEdit 'hover-throttle' @(
'    // наведение: тултип + курсор (троттлинг ~30мс — на больших моделях raycast дорогой)',
'    if(e.target && e.target.closest && e.target.closest(''#threeFloatBar'')){ const t0=document.getElementById(''threeTooltip''); if(t0) t0.style.display=''none''; return; }',
'    const now = performance.now();',
'    if(now - (pickElementAt._last||0) < 30) return;',
'    pickElementAt._last = now;',
'    const tip = document.getElementById(''threeTooltip'');'
) @(
'    // наведение: предпросмотр координат нулевой точки под курсором',
'    if(e.target && e.target.closest && e.target.closest(''#threeFloatBar'')){ const t0=document.getElementById(''threeTooltip''); if(t0) t0.style.display=''none''; return; }',
'    const tip = document.getElementById(''threeTooltip'');'
)

$b1 = [char]0x60 + [char]0x60   # placeholder builder not needed; use raw backticks via char codes below
$bt = [string][char]0x60
ApplyEdit 'hover-element' ($L[3715..3728]) @()

ApplyEdit 'visibility-group-lines' @('  if(elementsGroup3 && elementsGroup3.children.length) box.expandByObject(elementsGroup3);') @() 2

ApplyEdit 'pickworld-group' @('  if(elementsGroup3 && elementsGroup3.children.length) targets.push(elementsGroup3);') @()

ApplyEdit 'focus-group' @('  if(elementsGroup3 && elementsGroup3.children.length){ box.expandByObject(elementsGroup3); any = true; }') @()

ApplyEdit 'build-stats-hook' @(
'  lastModelColors = hasColors ? rawColors : null;   // для автосохранения цвета модели',
'  saveModelGeometry();',
'}'
) @(
'  lastModelColors = hasColors ? rawColors : null;   // для автосохранения цвета модели',
'  saveModelGeometry();',
'  updateModelStats3();',
'}')

$rx = 'const baseName = (state.header.partName || state.name || "model").replace(/' + [regex]::Escape('\\/') + '*?"<>|]/g,"_");'
# the actual source line contains: replace(/[\\/:*?"<>|]/g,"_") — assemble it literally:
$srcLine = 'const baseName = (state.header.partName || state.name || "model").replace(/[\\/ :*?"<>|]/g,"_")'
# safer: take the exact line straight from the source file
$base4 = $L[4789]   # line 4790 (4-space indent variant)
$base2 = $L[4796]   # line 4797 (2-space indent variant)
if(-not $base4.Trim().StartsWith('const baseName = (state.header')){ throw "unexpected baseName line 4790: $base4" }
if(-not $base2.Trim().StartsWith('const baseName = (state.header')){ throw "unexpected baseName line 4797: $base2" }
ApplyEdit 'export-base-name' @($base4) @('    const baseName = (((document.getElementById(''stlFileName'')||{}).textContent) || "model").replace(/\.[A-Za-z0-9]+$/,"").replace(/[\\/:*?"<>|]/g,"_");')
ApplyEdit 'export-all-base-name' @($base2) @('  const baseName = (((document.getElementById(''stlFileName'')||{}).textContent) || "model").replace(/\.[A-Za-z0-9]+$/,"").replace(/[\\/:*?"<>|]/g,"_");')

# initThree(); rebuildElementsGroup3(); → initThree();
$rb = 'initThree(); rebuildElementsGroup3();'
$cnt = ([regex]::Matches($html, [regex]::Escape($rb))).Count
if($cnt -lt 5){ throw "expected several rebuild calls, got $cnt" }
$html = $html.Replace($rb, 'initThree();')

ApplyEdit 'wiring-visibility' @(
'[''showNominalCb'',''showFactCb'',''showStlCb''].forEach(id=>{',
'  document.getElementById(id).addEventListener(''change'', applyThreeVisibility);',
'});'
) @(
'[''showStlCb''].forEach(id=>{',
'  document.getElementById(id).addEventListener(''change'', applyThreeVisibility);',
'});')

ApplyEdit 'wiring-element-cbs' @(
'document.getElementById(''showLabelsCb'').addEventListener(''change'', ()=>{',
'  if(threeInitialized) rebuildElementsGroup3();',
'});',
'document.getElementById(''depthIntoPartCb'').addEventListener(''change'', ()=>{',
'  if(threeInitialized) rebuildElementsGroup3();',
'});',
'document.getElementById(''showZonesCb'').addEventListener(''change'', ()=>{ if(threeInitialized) rebuildElementsGroup3(); });',
'document.getElementById(''showDatumsCb'').addEventListener(''change'', ()=>{ if(threeInitialized) rebuildElementsGroup3(); });',
'document.getElementById(''groupFilterSel'').addEventListener(''change'', (e)=>{',
'  groupFilter3 = e.target.value;',
'  if(threeInitialized) rebuildElementsGroup3();',
'});'
) @()

ApplyEdit 'step-too-big' ($L[5156..5160]) @(
'        "STEP-файл слишком большой для браузера: "+(file.size/1048576).toFixed(0)+" МБ.\n\n"+',
'        "STEP — это B-rep модель: такие размеры в память вкладки не помещаются (предел ~"+(MAX_STEP/1048576)+" МБ). Что делать:\n"+',
'        "1) сконвертировать в STL — PowerShell:  & \"3d-viewer\\tools\\convert-stp.ps1\" \"имя_файла.stp\" (нужен установленный FreeCAD); "+',
'        "полученный .stl откроется здесь же мгновенно; либо\n"+',
'        "2) запустить \"node serve.js\" из папки с моделью и взять её кнопкой «📂 Модели рядом» — сервер огранит STEP через FreeCAD сам и запомнит результат (первый раз — несколько минут)."'
)

# ---- память: перестановка осей in-place (для гигантских STL без двойной копии) ----
ApplyEdit 'build-stl-inplace' ($L[4682..4692]) @(
'function buildStlMesh(rawPositions, rawColors, alreadyMapped){',
'  // Перестановка y↔z выполняется НА МЕСТЕ в переданном массиве: для огромных STL (сотни',
'  // МБ) вторая копия буфера убила бы память вкладки. alreadyMapped=true передаётся при',
'  // восстановлении из автосохранения — там массив уже переставлен.',
'  if(!alreadyMapped){',
'    const nv = rawPositions.length;',
'    for(let i=0;i+2<nv;i+=3){ const t = rawPositions[i+1]; rawPositions[i+1] = rawPositions[i+2]; rawPositions[i+2] = t; }',
'  }',
'  const hasColors = !!(rawColors && rawColors.length === rawPositions.length);',
'  const geo = new THREE.BufferGeometry();',
'  geo.setAttribute(''position'', new THREE.BufferAttribute(rawPositions, 3));'
)
ApplyEdit 'restore-already-mapped' ($L[3356]) @('      buildStlMesh(positions, colors, true);   // сохранённый массив уже переставлен (перестановка in-place)')
ApplyEdit 'colored-opacity' @($L[4700]) @('    ? new THREE.MeshStandardMaterial({color:0xffffff, vertexColors:true, transparent:true, opacity:0.9, side:THREE.DoubleSide, roughness:0.9, metalness:0.05})   // цветная модель — плотнее, чтобы цвет читался')
ApplyEdit 'colored-opacity-slider' @($L[4701]) @(
  $L[4701],
  "  if(hasColors){ try{ const op=document.getElementById('stlOpacity'); if(op) op.value=0.9; const ov=document.getElementById('stlOpacityVal'); if(ov) ov.textContent='0.90'; }catch(e){} }"
)

# ---- storage key renames ----
$renames = @{
  "'pcdmis_model_autosave_v1'" = "'pcdmis3d_viewer_model_v2'";
  "'pcdmis.gridVisible'"       = "'pcdmis3d.gridVisible'";
  "'pcdmis.zeroPoint'"         = "'pcdmis3d.zeroPoint'"
}
foreach($k in $renames.Keys){
  $cnt = ([regex]::Matches($html, [regex]::Escape($k))).Count
  if($cnt -lt 1){ throw "rename '$k': not found" }
  $html = $html.Replace($k, $renames[$k])
}

# ---- leftover guards ----
$forbidden = @(
  'elementsGroup3','rebuildElementsGroup3','refreshThreeIfNeeded','pickElementAt','selectElementInScene',
  'findElementById','renderElementSidebarList','buildElementGroup3','getElementsForScene','groupFilter3','groupFilterSel',
  'hoveredElementId','TYPE_LABEL3','fmtCoord','toThreeDir','showNominalCb','showFactCb','showLabelsCb','showTolerancesCb',
  'showZonesCb','showDatumsCb','depthIntoPartCb','showAllOpsCb','mirrorXBtn','mirrorActiveProject','mirrorProjectData',
  'parsePCDMIS','applyParsed','state.elements','state.header','renderProjectTabs','projectTabsBar','importFile',
  'importPaste','importSummary','jumpToElementInTable','selectionMarker3','selectedElementId','elementSidebar','nav.tabs',
  'data-tab=','statusLine','renderOutput','renderElementsList','scheduleAutosave','tryRestoreAutosave','toleranceSummaryText',
  'zoneColorForDim','makeZoneCyl','buildToleranceZone3','datumLetterFor','makeDatumMarker3','makeTextSprite3(``'
)
foreach($f in $forbidden){
  if($f.EndsWith('``')){ continue }   # template-literal example skipped
  if($html.Contains($f)){ throw "forbidden leftover: $f" }
}

$enc = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($dst, $html, $enc)
Write-Output ("WROTE {0} ({1:N0} bytes)" -f $dst, (Get-Item $dst).Length)
