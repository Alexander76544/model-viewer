// Мини-сервер для «3D-просмотра программ PC-DMIS».
// Отдаёт index.html и API браузера моделей («📂 Модели рядом» в приложении).
//
// Запуск:   node serve.js [папка-с-моделями]     (по умолчанию — папка, где лежит serve.js)
// Открыть:  http://127.0.0.1:4173                (порт меняется переменной окружения PORT)
//
// STEP (.stp/.step): если рядом с <имя>.stp уже есть <имя>.stl — раздаётся он.
// Иначе, найден FreeCAD (freecadcmd.exe), модель ограняется на сервере через tools/step2stl.py
// (первый запрос может длиться минуты; результат кэшируется в <имя>.stp.stl).
// Переменные окружения: FREECAD_CMD — полный путь к freecadcmd.exe; S2S_LIN/S2S_ANG — дефлексии.
//
// Без сервера приложение тоже полностью работает — просто двойным кликом по index.html;
// тогда кнопка «📂 Модели рядом» скрыта, а STL/OBJ/STEP грузятся кнопкой «⬆ Загрузить».
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const cp = require('child_process');

const ROOT = path.resolve(process.argv[2] || __dirname);          // что ищем (модели)
const APP_DIR = __dirname;                                        // где лежит сам viewer
const PORT = parseInt(process.env.PORT || '4173', 10);
const MODEL_EXT = new Set(['.stl', '.obj', '.stp', '.step', '.prt', '.asm', '.iges', '.igs', '.x_t', '.x_b', '.par']);
const STEP2STL = path.join(APP_DIR, 'tools', 'step2stl.py');

function walk(dir, rel, out, depth) {
  if (depth > 6) return;
  let ents;
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
  for (const ent of ents) {
    if (ent.name.startsWith('.') || ent.name === 'node_modules') continue;
    const full = path.join(dir, ent.name);
    const r = rel ? rel + '/' + ent.name : ent.name;
    if (ent.isDirectory()) { walk(full, r, out, depth + 1); continue; }
    const ext = path.extname(ent.name).toLowerCase();
    if (!MODEL_EXT.has(ext)) continue;
    let size = 0;
    try { size = fs.statSync(full).size; } catch (e) {}
    out.push({ path: r, name: ent.name, size: size, ext: ext });
  }
}

// ---------- поиск freecadcmd.exe (лениво, с кэшем) ----------
let freecadFound; // undefined = не искали, null/string
function findFreeCad() {
  if (process.env.FREECAD_CMD && fs.existsSync(process.env.FREECAD_CMD)) return process.env.FREECAD_CMD;
  if (freecadFound !== undefined) return freecadFound;
  const roots = [
    process.env.FREECAD_ROOT,
    path.join(os.homedir(), 'Downloads'),
    path.join(process.env.ProgramFiles || 'C:\\Program Files', ''),
    path.join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', ''),
    path.join(os.homedir(), 'AppData', 'Local', 'Programs'),
    'C:\\FreeCAD'
  ].filter(Boolean);
  freecadFound = null;
  for (const root of roots) {
    let stack = [root], depth = 0, seen = 0;
    while (stack.length && depth <= 4 && seen < 4000) {
      const next = [];
      for (const dir of stack) {
        let ents; seen++;
        try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { continue; }
        for (const ent of ents) {
          if (ent.isFile() && /^freecadcmd\.exe$/i.test(ent.name)) { freecadFound = path.join(dir, ent.name); stack = []; next.length = 0; break; }
          if (ent.isDirectory() && !/^\./.test(ent.name) && !/python|plugins|share|lib/i.test(ent.name)) next.push(path.join(dir, ent.name));
        }
      }
      stack = next; depth++;
    }
    if (freecadFound) break;
  }
  return freecadFound;
}

const stepConverting = new Map(); // dst -> Promise (защита от двойного запуска)
function convertStep(stpPath, stlPath) {
  const cmd = findFreeCad();
  if (!cmd) return Promise.reject(new Error('FreeCAD (freecadcmd) не найден — сконвертируйте вручную: 3d-viewer/tools/convert-stp.ps1 "' + path.basename(stpPath) + '"'));
  if (stepConverting.has(stlPath)) return stepConverting.get(stlPath);
  const p = new Promise((resolve, reject) => {
    console.log('[step2stl] конвертация ' + stpPath + ' → ' + stlPath + ' (может занять много минут)…');
    const env = Object.assign({}, process.env, {
      S2S_SRC: stpPath, S2S_DST: stlPath,
      S2S_LIN: process.env.S2S_LIN || '0.2', S2S_ANG: process.env.S2S_ANG || '0.5', S2S_REL: '0',
      S2S_COLOR: process.env.S2S_COLOR || '0'   // серверный путь — стабильный FreeCAD без цвета;
                                                // цвет — через step2stl-portable (python+gmsh)
    });
    const child = cp.spawn(cmd, [STEP2STL], { env, windowsHide: true });
    let errTail = '';
    child.stdout.on('data', d => { const s = String(d); const m = s.match(/\[[^\]]*\][^\r\n]*/g); if (m) console.log(m[m.length - 1].trim()); });
    child.stderr.on('data', d => { errTail = (errTail + String(d)).slice(-2000); });
    child.on('error', reject);
    child.on('exit', code => {
      stepConverting.delete(stlPath);
      if (code === 0 && fs.existsSync(stlPath)) { console.log('[step2stl] готово: ' + stlPath); resolve(); }
      else reject(new Error('конвертация завершилась с кодом ' + code + (errTail ? ': ' + errTail.slice(-300) : '')));
    });
  });
  stepConverting.set(stlPath, p);
  return p;
}

function sendFile(res, file, req) {
  const ext = path.extname(file).toLowerCase();
  fs.stat(file, (err, st) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'application/json' }); res.end('{"error":"файл не найден"}'); return; }
    const headers = { 'Content-Type': ext === '.obj' ? 'text/plain; charset=utf-8' : 'application/octet-stream', 'Content-Length': st.size };
    // поддержка Range не нужна (STL/OBJ читаются целиком), но отдадим Accept-Ranges: none
    res.writeHead(200, headers);
    fs.createReadStream(file).pipe(res);
  });
}

http.createServer((req, res) => {
  const u = new URL(req.url, 'http://localhost');

  if (u.pathname === '/api/list') {
    const files = [];
    walk(ROOT, '', files, 0);
    files.sort((a, b) => a.path.localeCompare(b.path, 'ru'));
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ root: path.basename(ROOT), files: files }));
    return;
  }

  if (u.pathname === '/api/mesh') {
    const rel = u.searchParams.get('path') || '';
    const full = path.resolve(ROOT, rel);
    if (full !== ROOT && !full.startsWith(ROOT + path.sep)) {
      res.writeHead(403, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'путь за пределами корня' }));
      return;
    }
    const ext = path.extname(full).toLowerCase();
    if (ext === '.stp' || ext === '.step') {
      // 1) готовый STL рядом (ручной <имя>.stl или кэш <имя>.stp.stl), 2) конвертация на лету
      const manual = full.replace(/\.st[ep]$/i, '.stl');
      const cached = full + '.stl';
      const out = fs.existsSync(manual) ? manual : (fs.existsSync(cached) ? cached : null);
      if (out) { sendFile(res, out, req); return; }
      const target = cached + '.conv';           // временное имя, затем rename
      convertStep(full, target).then(() => {
        fs.rename(target, cached, e => { if (e) console.log('rename err', e); sendFile(res, cached, req); });
      }).catch(e => {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: String(e.message || e) }));
      });
      return;
    }
    fs.readFile(full, (err, buf) => {
      if (err) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'файл не найден' }));
        return;
      }
      res.writeHead(200, { 'Content-Type': ext === '.obj' ? 'text/plain; charset=utf-8' : 'application/octet-stream' });
      res.end(buf);
    });
    return;
  }

  // статика: сам viewer
  let p = u.pathname === '/' ? '/index.html' : decodeURIComponent(u.pathname);
  const full = path.resolve(APP_DIR, '.' + p);
  if (!full.startsWith(APP_DIR + path.sep)) { res.writeHead(403); res.end('forbidden'); return; }
  fs.readFile(full, (err, buf) => {
    if (err) { res.writeHead(404); res.end('not found'); return; }
    const ct = full.endsWith('.html') ? 'text/html; charset=utf-8'
      : full.endsWith('.js') ? 'text/javascript; charset=utf-8'
      : 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': ct });
    res.end(buf);
  });
}).listen(PORT, '127.0.0.1', () => {
  console.log('3D-просмотр моделей:  http://127.0.0.1:' + PORT);
  console.log('Корень папки:         ' + ROOT);
  const fc = findFreeCad();
  console.log('FreeCAD для STEP:     ' + (fc || 'не найден (STEP можно конвертировать tools/convert-stp.ps1)'));
});
