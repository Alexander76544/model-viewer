@echo off
rem ============================================================
rem  step2stl.bat - portable STEP(.stp/.step) -> binary STL
rem  incl. COLOR (XCAF) support. No admin rights, no installs.
rem
rem  USAGE: drag one or more .stp/.step files onto this .bat.
rem  Result: <same name>.stl next to the source file.
rem
rem  Backend order:
rem    1) python + gmsh  (pip install gmsh)   -> colored STL
rem    2) FreeCAD freecadcmd.exe (auto-found) -> full geometry, no color
rem  Env knobs: FC_LIN=[mm deflection, default 0.2]
rem             FC_COLOR=0 disable color; FC_CMD=path to freecadcmd.exe;
rem             FC_ROOT=FreeCAD folder; PY_CMD=path to python.exe.
rem ============================================================
setlocal enabledelayedexpansion
set "PY=%~dp0step2stl.py"
set "LIN=%FC_LIN%"
if "%LIN%"=="" set "LIN=0.2"
set "COLOR=%FC_COLOR%"
if "%COLOR%"=="" set "COLOR=1"

set "PYEXE=%PY_CMD%"
if not defined PYEXE for /f "delims=" %%P in ('where python 2^>nul') do if not defined PYEXE set "PYEXE=%%~fP"

set "FCMD=%FC_CMD%"
set "HAVEFC="
if defined FCMD set "HAVEFC=1"
if defined HAVEFC goto :afc
if defined FC_ROOT call :chk "%FC_ROOT%"
call :chk "%~dp0."
call :chk "%USERPROFILE%\Downloads"
call :chk "%USERPROFILE%\Desktop"
call :chk "%USERPROFILE%\Documents"
call :chk "%LOCALAPPDATA%\Programs"
call :chk "%ProgramFiles%"
call :chk "%ProgramFiles(x86)%"
call :chk "C:\"
:afc
if defined FCMD set "HAVEFC=1"

if "%PYEXE%"=="" if not defined HAVEFC (
  echo Neither python+gmsh nor FreeCAD was found.
  echo   - python: install gmsh with:  pip install gmsh
  echo   - or set FC_ROOT / FC_CMD to your FreeCAD location.
  pause
  exit /b 1
)

if "%~1"=="" (
  echo Drag and drop .stp / .step files from Explorer onto this bat.
  echo Or run: step2stl.bat "C:\path\model.stp"
  echo.
  pause
  exit /b 1
)
:one
if "%~1"=="" goto :done
set "SRC=%~f1"
for %%I in ("%SRC%") do set "OUT=%%~dpnI.stl"
echo.
echo ============================================
echo  %SRC%
echo  result: !OUT!   (deflection %LIN% mm, color %COLOR%)
echo ============================================
set "S2S_SRC=%SRC%"
set "S2S_DST=!OUT!"
set "S2S_LIN=%LIN%"
set "S2S_COLOR=%COLOR%"
set "DONEFLAG="
if not "%PYEXE%"=="" (
  echo [1/2] python + gmsh...
  "%PYEXE%" "%PY%"
  if exist "!OUT!" set "DONEFLAG=1"
)
if not defined DONEFLAG if defined HAVEFC (
  echo [2/2] FreeCAD freecadcmd (headless: no colors, geometry only)...
  set "S2S_COLOR=0"
  "%FCMD%" "%PY%"
  if exist "!OUT!" set "DONEFLAG=1"
)
if not defined DONEFLAG echo [!] FAILED: no STL produced for "%SRC%"
:two
shift
goto :one
:done
echo.
pause
endlocal
exit /b 0

:chk
set "R=%~1"
for /d %%D in ("%R%\FreeCAD*") do call :sub "%%~fD"
for /d %%D in ("%R%\freecad*") do call :sub "%%~fD"
call :sub "%R%"
exit /b

:sub
call :hits "%~1"
for /d %%S in ("%~1\FreeCAD*") do call :hits "%%~fS"
for /d %%S in ("%~1\freecad*") do call :hits "%%~fS"
exit /b

:hits
set "B=%~f1"
if exist "%B%\bin\freecadcmd.exe" set "FCMD=%B%\bin\freecadcmd.exe"
if exist "%B%\usr\bin\freecadcmd.exe" set "FCMD=%B%\usr\bin\freecadcmd.exe"
if exist "%B%\FreeCADCmd.exe" set "FCMD=%B%\FreeCADCmd.exe"
if exist "%B%\freecadcmd.exe" set "FCMD=%B%\freecadcmd.exe"
exit /b