/* Local companion server for pcdmis-generator.html
 * - serves the app folder over http (so the page can read sibling model files)
 * - /api/list?dir=REL      -> JSON list of model files (.stl/.obj/.stp/.step/.prt/.iges/.igs)
 * - /api/mesh?path=REL&size=N -> mesh bytes: STL/OBJ passthrough; STEP tessellated via gmsh (step2mesh.py)
 * Usage:  node serve.js [modelsDir] [port]
 *         PORT env also honored. Default port 8017.
 */
const http = require('http');
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const os = require('os');
const url = require('url');
const crypto = require('crypto');
const { spawn } = require('child_process');

const ROOT = path.resolve(process.argv[2] || process.cwd());   // served folder + default models dir
const PORT = parseInt(process.argv[3] || process.env.PORT || '8017', 10);
const HERE = __dirname;
const PY = process.env.PYTHON || (process.platform === 'win32' ? 'python' : 'python3');
const CACHE_DIR = path.join(os.tmpdir(), 'pcdmis_step_cache');
try { fs.mkdirSync(CACHE_DIR, { recursive: true }); } catch (_) {}

const MODEL_EXT = new Set(['.stl', '.obj', '.stp', '.step', '.prt', '.asm', '.iges', '.igs', '.x_t', '.x_b', '.par']);
const MESHABLE = new Set(['.stl', '.obj']);
const STEP_EXT = new Set(['.stp', '.step']);
const NATIVE = new Set(['.prt', '.asm', '.x_t', '.x_b', '.par']);
const SKIP_DIRS = new Set(['node_modules', '.git', '.svn', '__pycache__', 'dist', 'build']);

function modelExt(name) {
  const lower = String(name).toLowerCase();
  const m = /\.(prt|asm)\.?\d*$/.exec(lower);   // Creo: part.prt.1 / asm.asm.3
  if (m) return '.' + m[1];
  return path.extname(lower);
}

function safeRel(rel) {
  const abs = path.resolve(ROOT, '.' + path.sep + (rel || ''));
  if (abs !== ROOT && !abs.startsWith(ROOT + path.sep)) return null; // traversal guard
  return abs;
}
function send(res, code, body, headers) {
  res.writeHead(code, Object.assign({ 'Access-Control-Allow-Origin': '*' }, headers || {}));
  res.end(body);
}
function json(res, code, obj) { send(res, code, JSON.stringify(obj), { 'Content-Type': 'application/json; charset=utf-8' }); }

async function walk(dir, rel, out, depth) {
  if (depth > 8) return;
  let entries;
  try { entries = await fsp.readdir(dir, { withFileTypes: true }); } catch (_) { return; }
  for (const e of entries) {
    if (e.name.startsWith('.') ) continue;
    const r = rel ? rel + '/' + e.name : e.name;
    if (e.isDirectory()) { if (!SKIP_DIRS.has(e.name)) await walk(path.join(dir, e.name), r, out, depth + 1); }
    else {
      const ext = modelExt(e.name);
      if (!MODEL_EXT.has(ext)) continue;
      let size = 0; try { size = (await fsp.stat(path.join(dir, e.name))).size; } catch (_) {}
      out.push({ path: r, name: e.name, ext, size });
    }
  }
}

function runStep2Mesh(inp, outp, size) {
  return new Promise((resolve, reject) => {
    const p = spawn(PY, [path.join(HERE, 'step2mesh.py'), inp, outp, String(size)], { windowsHide: true });
    let err = '';
    p.stderr.on('data', d => { err += d.toString(); });
    p.on('error', reject);
    p.on('close', code => {
      if (code === 0 && fs.existsSync(outp)) resolve();
      else reject(new Error('step2mesh exit ' + code + (err ? ': ' + err.slice(-400) : '')));
    });
  });
}

const server = http.createServer(async (req, res) => {
  const u = url.parse(req.url, true);
  const pathname = decodeURIComponent(u.pathname);

  try {
    if (pathname === '/api/list') {
      const abs = safeRel(u.query.dir || '');
      if (!abs) return json(res, 403, { error: 'вне каталога' });
      const out = [];
      await walk(abs, (u.query.dir || ''), out, 0);
      out.sort((a, b) => a.path.localeCompare(b.path));
      return json(res, 200, { root: path.relative(ROOT, abs) || '.', files: out });
    }

    if (pathname === '/api/mesh') {
      const rel = u.query.path || '';
      const abs = safeRel(rel);
      if (!abs) return json(res, 403, { error: 'вне каталога' });
      let st; try { st = await fsp.stat(abs); } catch (_) { return json(res, 404, { error: 'файл не найден' }); }
      if (!st.isFile()) return json(res, 400, { error: 'это не файл' });
      const ext = modelExt(path.basename(abs));

      if (MESHABLE.has(ext)) {
        const type = ext === '.obj' ? 'text/plain' : 'application/octet-stream';
        res.writeHead(200, { 'Content-Type': type, 'Content-Length': st.size, 'Access-Control-Allow-Origin': '*' });
        fs.createReadStream(abs).pipe(res);
        return;
      }
      if (NATIVE.has(ext)) {
        return json(res, 415, { error: 'Нативный формат CAD (' + ext + ') не читается. Откройте в Creo/CAD и экспортируйте в STL/OBJ или STEP.' });
      }
      if (STEP_EXT.has(ext)) {
        const size = parseFloat(u.query.size) || 4.0;
        const key = crypto.createHash('md5').update(rel + '|' + st.size + '|' + st.mtimeMs + '|' + size).digest('hex') + '.stl';
        const cached = path.join(CACHE_DIR, key);
        try {
          if (fs.existsSync(cached)) {
            const cs = await fsp.stat(cached);
            res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Length': cs.size, 'Access-Control-Allow-Origin': '*', 'X-Step-Cached': '1' });
            return fs.createReadStream(cached).pipe(res);
          }
        } catch (_) {}
        try {
          await runStep2Mesh(abs, cached, size);
          const cs = await fsp.stat(cached);
          res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Length': cs.size, 'Access-Control-Allow-Origin': '*' });
          return fs.createReadStream(cached).pipe(res);
        } catch (e) {
          return json(res, 500, { error: 'Не удалось тесселировать STEP на сервере: ' + e.message });
        }
      }
      return json(res, 415, { error: 'Неподдерживаемый формат: ' + ext });
    }

    // static file server
    let rel = pathname === '/' ? '/pcdmis-generator.html' : pathname;
    const abs = safeRel(rel);
    if (!abs) return send(res, 403, 'forbidden');
    fs.readFile(abs, (err, buf) => {
      if (err) return send(res, 404, 'not found');
      const ext = path.extname(abs).toLowerCase();
      const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
      send(res, 200, buf, { 'Content-Type': types[ext] || 'application/octet-stream' });
    });
  } catch (e) {
    json(res, 500, { error: String(e && e.message || e) });
  }
});

server.listen(PORT, () => {
  console.log('PC-DMIS companion server');
  console.log('  root (models + app): ' + ROOT);
  console.log('  open:                http://localhost:' + PORT + '/pcdmis-generator.html');
  console.log('  STEP tessellation:   ' + PY + ' + gmsh (step2mesh.py)');
});
