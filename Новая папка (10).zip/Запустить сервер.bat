@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo [!] Node.js не найден. Установите его с https://nodejs.org и запустите снова.
  pause
  exit /b 1
)
echo.
echo  Запускаю локальный сервер-компаньон...
echo  После старта откройте в браузере ссылку, которую напечатает сервер.
echo  (Модели .stl/.obj/.stp можно положить в эту же папку или подпапки.)
echo.
node serve.js %*
pause
