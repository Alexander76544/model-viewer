import sys, os, struct, math

def step_to_stl(inp, outp, maxsize=0.0):
    import gmsh
    gmsh.initialize()
    try:
        gmsh.option.setNumber("General.Verbosity", 0)
        gmsh.open(inp)
        if maxsize and maxsize > 0:
            gmsh.option.setNumber("Mesh.MeshSizeMax", maxsize)
            gmsh.option.setNumber("Mesh.MeshSizeMin", max(1e-3, maxsize * 0.05))
            gmsh.option.setNumber("Mesh.MeshSizeFromCurvature", 12)
        gmsh.model.mesh.generate(2)
        # node tag -> xyz
        ntags, ncoords, _ = gmsh.model.mesh.getNodes()
        pos = {}
        for i in range(len(ntags)):
            t = int(ntags[i]); pos[t] = (ncoords[3*i], ncoords[3*i+1], ncoords[3*i+2])
        tris = []
        etypes, etags, enodes = gmsh.model.mesh.getElements(2, -1)
        for k, et in enumerate(etypes):
            arr = enodes[k]
            et = int(et)
            if et == 2:      # 3-node triangle
                nv = 3
            elif et == 9:    # 6-node quadratic triangle -> use corners
                nv = 6
            else:
                continue
            n = len(arr) // nv
            base = etags[k]
            for j in range(n):
                a = int(arr[j*nv]); b = int(arr[j*nv+1]); c = int(arr[j*nv+2])
                if a in pos and b in pos and c in pos:
                    tris.append((pos[a], pos[b], pos[c]))
        write_binary_stl(outp, tris)
        return len(tris)
    finally:
        gmsh.finalize()

def write_binary_stl(outp, tris):
    with open(outp, "wb") as f:
        f.write(b"pcdmis-step2mesh".ljust(80, b" "))
        f.write(struct.pack("<I", len(tris)))
        buf = bytearray()
        for (a, b, c) in tris:
            ux, uy, uz = b[0]-a[0], b[1]-a[1], b[2]-a[2]
            vx, vy, vz = c[0]-a[0], c[1]-a[1], c[2]-a[2]
            nx, ny, nz = uy*vz-uz*vy, uz*vx-ux*vz, ux*vy-uy*vx
            l = math.sqrt(nx*nx+ny*ny+nz*nz) or 1.0
            nx, ny, nz = nx/l, ny/l, nz/l
            buf += struct.pack("<3f", nx, ny, nz)
            buf += struct.pack("<3f", *a); buf += struct.pack("<3f", *b); buf += struct.pack("<3f", *c)
            buf += struct.pack("<H", 0)
        f.write(buf)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.stderr.write("usage: step2mesh.py input.step output.stl [maxsize]\n"); sys.exit(2)
    ms = float(sys.argv[3]) if len(sys.argv) > 3 else 0.0
    n = step_to_stl(sys.argv[1], sys.argv[2], ms)
    sys.stderr.write("triangles=%d\n" % n)
