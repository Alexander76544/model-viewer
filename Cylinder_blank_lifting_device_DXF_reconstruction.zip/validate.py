import cadquery as cq,json,struct,numpy as np
from pathlib import Path
R=Path(__file__).parent
s=cq.importers.importStep(str(R/'Cylinder_blank_lifting_device_DXF.stp')).val();solids=s.Solids()
b=(R/'Cylinder_blank_lifting_device_DXF.stl').read_bytes();n=struct.unpack_from('<I',b,80)[0];dtype=np.dtype([('normal','<f4',(3,)),('points','<f4',(3,3)),('attr','<u2')]);a=np.frombuffer(b,offset=84,dtype=dtype)
report=json.load(open(R/'geometry_report.json'));report.update({'reimported_step_solids':len(solids),'reimported_step_valid':s.isValid(),'reimported_step_all_solids_valid':all(x.isValid() for x in solids),'stl_triangles':n,'stl_binary_length_ok':84+n*50==len(b),'stl_finite':bool(np.isfinite(a['points']).all()),'stl_min_mm':a['points'].min(axis=(0,1)).tolist(),'stl_max_mm':a['points'].max(axis=(0,1)).tolist()})
(R/'geometry_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
