"""DXF W2024-22-11 reconstruction. Geometry only, no lifting approval.
Front drawing origin (10353.213260,14668.266549). mm.
All non-explicit dimensions are reconstruction choices, see README.
"""
from pathlib import Path
import cadquery as cq, math,json,csv
import numpy as np
ROOT=Path(__file__).parent
parts=[]
COL={'steel':(.22,.27,.32),'bright':(.65,.70,.75),'handle':(.3,.35,.39),'spring':(.55,.59,.63),'pad':(.2,.39,.49)}
def add(name,s,col='steel',basis='reconstructed'):
 if isinstance(s,cq.Workplane):s=s.val()
 if not s.isValid():raise ValueError(name+' invalid')
 parts.append({'name':name,'shape':s,'color':COL[col],'basis':basis});return s

def box(l,w,h,x,y,z):return cq.Workplane('XY').box(l,w,h).translate((x,y,z)).val()
def cyl(r,l,p,d=(0,1,0)):return cq.Solid.makeCylinder(r,l,cq.Vector(*p),cq.Vector(*d))
def prof(pts,t,y):return cq.Workplane('XZ',origin=(0,y+t/2,0)).polyline(pts).close().extrude(t).val()
def hole(s,x,z,r,t=60,y=-30):return s.cut(cyl(r,t,(x,y,z)))
def bar(a,b,w,t,y,holes=()):
 dx,dz=b[0]-a[0],b[1]-a[1];L=math.hypot(dx,dz);nx,nz=-dz/L*w/2,dx/L*w/2
 s=prof([(a[0]+nx,a[1]+nz),(b[0]+nx,b[1]+nz),(b[0]-nx,b[1]-nz),(a[0]-nx,a[1]-nz)],t,y)
 for x,z in [a,b]:s=s.fuse(cyl(w/2,t,(x,y-t/2,z)))
 for x,z,r in holes:s=s.cut(cyl(r,t+2,(x,y-t/2-1,z)))
 return s

def pin(name,x,z,l=42,r=6.25,y=0):
 s=cyl(r,l,(x,y-l/2,z)).fuse(cyl(r*1.55,4,(x,y-l/2-4,z)))
 add(name,s,'bright','Pin envelope; thread, fit and retention not specified')
 add(name+'_washer',cyl(r*1.6,2,(x,y+l/2,z)).cut(cyl(r*1.04,3,(x,y+l/2-.5,z))),'bright')
 # Hex nut envelope.
 n=cq.Workplane('XZ',origin=(x,y+l/2+9,z)).polygon(6,r*3).extrude(7).val().cut(cyl(r,9,(x,y+l/2+1,z)))
 add(name+'_nut',n,'bright')

def oval(x,y,z,straight,r,stock,turn=False):
 # Capsule centreline in XZ; chain alternate links rotate 90deg around vertical.
 wire=cq.Workplane('XZ',origin=(x,y,z)).slot2D(straight+2*r,2*r,90).val()
 e=wire.Edges()[0];p=e.startPoint();t=e.tangentAt(0)
 s=cq.Workplane(cq.Plane(origin=p,normal=t)).circle(stock/2).sweep(wire,isFrenet=True).val()
 if turn:s=s.rotate((x,y,z),(x,y,z+1),90)
 return s

A=(0,483.472395); BL=(-158.477415,361.468669);BR=(158.477414,361.468669);C=(0,239.464944)
# Main crossed arm contours: measured DXF visible edges extended through occluded zones.
left_end=(-224.5,68.943325);right_end=(224.5,73.943325)
# Lower arm from left carrier to right upper pivot.
pts=[(-233.5,21.2),(-206.5,43.703135),(62.878048,262.631375),(169.883409,345.009377),(145.483,376.705),(-206.5,94.183515),(-233.5,72.0)]
s=prof(pts,10,-8).fuse(cyl(20.02511,10,(BR[0],-13,BR[1])))
for x,z,r in [(0,C[1],6.25),(*BR,8.5),(*left_end,6.25)]:s=hole(s,x,z,r,14,-15)
add('01_Crossed_arm_left_jaw',s,basis='DXF visible edges; concealed transition reconstructed; thickness 10 from plan')
# Opposite arm contour, including the square end at the right carrier.
pts2=[(-169.883409,345.009377),(-32.785884,239.464944),(202.7,58.1),(226.5,39.8),(226.5,90.3),(202.7,108.657),(0,264.705133),(-127.740649,363.046181)]
s=prof(pts2,10,8).fuse(cyl(20.02511,10,(BL[0],3,BL[1])))
for x,z,r in [(0,C[1],6.25),(*BL,8.5),(*right_end,6.25)]:s=hole(s,x,z,r,14,1)
add('02_Crossed_arm_right_jaw',s,basis='DXF visible edges; concealed transition reconstructed; thickness 10 from plan')
# Two 200mm upper suspension links, 35mm wide.
for label,b,y in [('left',BL,-20),('right',BR,20)]:
 add('03_Upper_link_'+label,bar(A,b,35,8,y,[(*A,6.5),(*b,8.5)]),basis='DXF pivot centres L200, width35; thickness8 inferred from plan')
for label,p,r in [('Top',A,6.25),('Left',BL,8),('Right',BR,8),('Cross',C,6.0)]:pin('04_'+label+'_pin',*p,54 if label!='Cross' else 36,r)
# End carriers and four individual hook plates; unequal front heights retained as drawn.
left=[(-263.5,-95.625),(-198.5,-95.625),(-198.5,-80.625),(-233.5,-80.625),(-233.5,29.479),(-206.5,29.479),(-206.5,96.485),(-263.5,96.485)]
right=[(191.797,-163.626),(256.797,-163.626),(256.797,96.49),(199.797,96.49),(199.797,29.49),(226.797,29.49),(226.797,-148.626),(191.797,-148.626)]
for label,x,span,ys,pts,ztoe in [('L',-224.5,170,[-92,92],left,-80.625),('R',224.5,140,[-77,77],right,-148.626)]:
 add('05_Carrier_'+label,box(16,span,51,x,0,62.24),basis='Plan carrier 16mm wide, 170/140mm long; front vertical envelope')
 for j,y in enumerate(ys):
  s=prof(pts,14,y)
  # Two mounting holes visible in the front projection; location inferred beneath slot.
  for zz in [33,68]:s=s.cut(cyl(4.1,16,(x+(-24 if label=='L' else 24),y-8,zz)))
  add(f'06_Hook_{label}{j+1}',s,basis='Front external hook contour, 14mm thickness and Y positions from plan; holes reconstructed')
  # Contact soft protector specified by source requirement 9. Thickness not given.
  tx=-207 if label=='L' else 201
  add(f'07_Toe_protector_{label}{j+1}',box(20,14,2,tx,y,ztoe+1),'pad','Soft protector required in DXF; material/thickness not specified')
  # Upper contact plate and slotted mounting ear.
  xx=-208.5 if label=='L' else 210
  add(f'08_Top_contact_{label}{j+1}',box(100,14,12,xx,y,5.38),basis='Drawing top contact plate envelope; weld layout unconfirmed')
  add(f'08_Seal_protection_{label}{j+1}',box(50,14,2,xx+ (20 if label=='L' else -20),y,-1.62),'pad','Required sealing-surface protection; material and 2mm thickness are reconstruction assumptions')
  ear=bar((x+(-24 if label=='L' else 24),24),(x+(-24 if label=='L' else 24),68.375),20,14,y)
  cut=cq.Workplane('XZ',origin=(0,y+8,0)).center(x+(-24 if label=='L' else 24),48).slot2D(43,8.2,90).extrude(16).val();ear=ear.cut(cut)
  add(f'09_Slotted_ear_{label}{j+1}',ear)
  for zz in [33,68]:pin(f'10_Hook_bolt_{label}{j+1}_{zz}',x+(-24 if label=='L' else 24),zz,25,4,y)
 pin('11_End_pin_'+label,x,68.94 if label=='L' else 73.94,span+30,6)
# Bent operating handles, based on the actual sampled DXF polyline.
details=json.loads((ROOT/'details.json').read_text())
add('12_Handle_left',prof(details[0]['points'],12,-8),'handle','Exact sampled DXF front contour; 12mm depth from plan')
# Right outline is interrupted in DXF by latch; reconstruct full closed handle band.
outer=[(242.52,86.49),(249.85,86.49),(283,133.83),(284.8,139.34),(283.24,144.94),(280.54,147.76),(193.48,208.72),(185,215),(178,214),(172.53,209.69),(144.55,169.73),(157.37,167.11),(176.18,193.98),(180.74,197.56),(184.6,198.24),(188.39,197.4),(190.11,196.43),(263.83,144.81),(267.41,140.25),(268.09,136.39),(266.29,130.88),(237.61,89.93)]
add('12_Handle_right',prof(outer,12,8),'handle','DXF handle fragments connected across obscured latch region')
# Narrow vertical latch support and pivoted release mechanism, not the previous toggle drive.
add('13_Latch_upright',bar((208.6,43),(208.6,223.7),12,12,26),'steel','Front upright line spacing ~12; attachment depth reconstructed')
D=(79.238707,178.463081);E=(141.585874,137.088601);H=(50.617358,325.707158)
lever=bar(D,H,30,8,-28,[(*D,6.25)])
lever=lever.fuse(prof([(78,213),(101,219),(101,232),(78,242)],8,-28))
add('14_Release_lever',lever,'handle','DXF long handle L150 and R15 top; lower profile reconstructed')
add('15_Small_latch_link',bar(D,(176.619878,155.530408),15,8,-38,[(*D,6.25)]),'handle')
add('16_Latch_rocker',bar((93,142.479),E,35,10,-18,[(*E,6.25)]),'steel')
add('17_Latch_stop',box(72,12,10,115.65,-18,137.48),'steel')
for name,p in [('Lever',D),('Rocker',E)]:pin('18_'+name+'_pin',*p,45,6)
# Helical extension spring, positioned along the visible DXF spring axis.
p0=np.array([96.,-39.,222.]);p1=np.array([171.,-39.,204.]);v=p1-p0;L=np.linalg.norm(v)
helix=cq.Wire.makeHelix(6,L,13)
s=cq.Workplane('XY',origin=(13,0,0)).circle(1.6).sweep(helix,isFrenet=True).val()
axis=np.cross([0,0,1],v/L);ang=math.degrees(math.acos(v[2]/L));s=s.rotate((0,0,0),tuple(axis),ang).translate(tuple(p0))
add('19_Return_spring',s,'spring','Spring envelope follows drawing; wire3.2, pitch6, radius13 provisional; no force specification')
for n,p in [('a',p0),('b',p1)]:
 add('20_Spring_eye_'+n,cyl(5,8,(float(p[0]),-43,float(p[2]))).cut(cyl(2.5,10,(float(p[0]),-44,float(p[2])))),'bright')
 add('20_Spring_anchor_'+n,cyl(2.5,21 if n=='a' else 58,(float(p[0]),-44,float(p[2]))),'bright','Spring attachment envelope reconstructed; retention and spring preload unverified')
# Top bow shackle and 8mm chain, alternating link planes.
add('21_Top_bow',oval(0,0,518.9,20,24,12),'bright','DXF bow envelope reconstructed; not a selected rated shackle')
pin('22_Bow_pin',0,483.472395,52,6)
for i,(z,straight,r,stock,turn) in enumerate([(560,22,15.76,9.45,False),(603.84,34.4,9.2,8,True),(630.239,16,9.2,8,False),(659,37.68,9.2,8,True),(686.319,16,9.2,8,False),(712.717,34.4,9.2,8,True),(739.117,16,9.2,8,False),(786.279,60,9.2,8,True)]):
 add(f'23_Chain_link_{i+1:02}',oval(2.306578,0,z,straight,r,stock,turn),'bright','Chain centreline reconstructed from front; closures and rating not specified')
add('24_Master_ring',oval(2.306578,0,876.242282,60,38,16),'bright','DXF master ring R46/R30 outside/inside, straight60; stock16')
# Export named assembly, separate components, mesh data for independent view rendering.
ass=cq.Assembly(name='Cylinder_blank_lifting_device_DXF_W2024_22_11')
partdir=ROOT/'parts';partdir.mkdir(exist_ok=True)
vertices=[];triangles=[];colors=[]
for i,p in enumerate(parts):
 ass.add(p['shape'],name=p['name'],color=cq.Color(*p['color']))
 cq.exporters.export(p['shape'],str(partdir/(p['name']+'.stp')),exportType='STEP')
 vs,fs=p['shape'].tessellate(.4,.15);off=len(vertices)
 vertices.extend([v.toTuple() for v in vs]);triangles.extend([[int(k)+off for k in f] for f in fs]);colors.extend([p['color']]*len(fs))
ass.export(str(ROOT/'Cylinder_blank_lifting_device_DXF.stp'),exportType='STEP')
compound=cq.Compound.makeCompound([p['shape'] for p in parts]);cq.exporters.export(compound,str(ROOT/'Cylinder_blank_lifting_device_DXF.stl'),exportType='STL',tolerance=.4,angularTolerance=.3)
np.savez_compressed(ROOT/'mesh.npz',v=np.array(vertices),f=np.array(triangles),colors=np.array(colors))
with open(ROOT/'components.csv','w') as f:
 w=csv.writer(f);w.writerow(['name','basis','valid','volume_mm3']);w.writerows([(p['name'],p['basis'],p['shape'].isValid(),round(p['shape'].Volume(),2)) for p in parts])
b=compound.BoundingBox();report={'components':len(parts),'valid_components':sum(p['shape'].isValid() for p in parts),'assembly_bounds_mm':[b.xlen,b.ylen,b.zlen],'geometry_checks_only':True,'load_capacity_verified':False,'motion_verified':False,'drawing':'W2024-22-11','front_reference_origin':[10353.21326,14668.266549],'drawing_nominal_reference_dimensions_mm':{'front_total_to_load_bottom':1487,'side_total':1120,'load_height':550,'load_plan_length':820,'load_width':396},'actual_DXF_measurements_mm':{'front_total':1486.867282,'side_total':1120.556322,'load_height':550.625,'load_width':396.546063},'source_discrepancies':'Views are not fully consistent; 1120 side is not imposed as exact device height. Assembly preserves front-view chain/hook envelope.'}
(ROOT/'geometry_report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
