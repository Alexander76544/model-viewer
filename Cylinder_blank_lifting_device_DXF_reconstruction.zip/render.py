import numpy as np,cv2,json
from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
R=Path(__file__).parent;F='/usr/share/fonts/msttcore/arial.ttf'
def font(n):return ImageFont.truetype(F,n)
a=np.load(R/'mesh.npz');v=a['v'];f=a['f'];base=a['colors']*255
norm=np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]]);norm/=np.maximum(np.linalg.norm(norm,axis=1)[:,None],1e-12)
light=np.array([-.4,-.6,.8]);light/=np.linalg.norm(light);shade=.53+.47*np.abs(norm@light);cs=(base*shade[:,None]).clip(0,255).astype(np.uint8)
def draw_model(cam,W,H,margin=50):
 cam=np.array(cam,dtype=float);cam/=np.linalg.norm(cam);right=np.cross([0,0,1],cam)
 if np.linalg.norm(right)<.01:right=np.array([1.,0,0])
 right/=np.linalg.norm(right);up=np.cross(cam,right);m=np.column_stack([right,up,cam]);vv=v@m
 lo=vv[:,:2].min(0);hi=vv[:,:2].max(0);sc=min((W-2*margin)/(hi[0]-lo[0]),(H-2*margin)/(hi[1]-lo[1]));xy=(vv[:,:2]-(lo+hi)/2)*sc;xy[:,1]*=-1;xy+=np.array([W/2,H/2]);xy=xy.astype(np.int32)
 im=np.full((H,W,3),249,dtype=np.uint8);idx=np.argsort(vv[f,2].mean(1))
 for k in idx:cv2.fillConvexPoly(im,xy[f[k]],tuple(int(t) for t in cs[k]),lineType=cv2.LINE_AA)
 return Image.fromarray(im)
for name,cam,title in [('preview',(1.3,-2.2,.85),'Ножничный захват · по DXF'),('front',(0,-1,0),'Главный вид · восстановленная геометрия')]:
 out=Image.new('RGB',(1300,1550),(249,249,249));out.paste(draw_model(cam,1200,1260),(50,140));d=ImageDraw.Draw(out)
 d.text((45,30),title,font=font(34),fill='#242b32');d.text((45,82),'Cylinder blank lifting device · W2024-22-11',font=font(23),fill='#505b65')
 d.text((45,1418),'РЕКОНСТРУКЦИЯ · НЕ ДЛЯ ИЗГОТОВЛЕНИЯ И ПОДЪЁМА',font=font(24),fill='#ae472d')
 d.text((45,1462),'Фото и прежняя рама не использованы. Неуказанные детали восстановлены.',font=font(21),fill='#56616d')
 out.save(R/(name+'.png'))
# Close-up exposes spring and four hook plates for visual inspection.
oldv=v;oldf=f;oldcs=cs
mask=(v[f].max(axis=1)[:,2]<390);f=f[mask];cs=cs[mask];ids=np.unique(f);# preserve global indices; crop vertices bounding separately through remapping
vv=v[ids];remap=np.zeros(len(v),dtype=int);remap[ids]=np.arange(len(ids));f=remap[f];v=vv
out=draw_model((1.4,-2.3,1.3),1500,1100,80);d=ImageDraw.Draw(out);d.text((35,25),'Нижние рычаги, лапы и пружинный фиксатор · геометрическая реконструкция',font=font(26),fill='#333b43');out.save(R/'detail.png')
