@echo off
rem ============================================================================
rem  3D-просмотрщик моделей — запуск локального сервера (serve.js)
rem
rem  ИЩЕТ И ЗАПОМИНАЕТ ТРИ ИНСТРУМЕНТА (для каждого — свой *-home.txt рядом):
rem    node.exe        -> нужен для самого сервера
rem    python.exe      -> цветные STEP (import OCP); автопоиск: PATH, py-launcher,
rem                        C:\Python3*, LocalAppData\Programs\Python, anaconda...
rem    freecadcmd.exe  -> резервная конвертация STEP без цвета (серая геометрия)
rem  Порядок для каждого: сохранённый путь -> PATH -> типовые папки -> ручной ввод.
rem  Введённый один раз путь запоминается в node-home.txt / python-home.txt /
rem  freecad-home.txt (или правятся вручную / переменные PY_CMD и FREECAD_CMD).
rem
rem  Аргументы:  bat ["папка с моделями"]   (по умолчанию — папка рядом с bat)
rem  Порт:       set PORT=xxxx              (по умолчанию 4173)
rem ============================================================================
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
if not defined PORT set "PORT=4173"

rem --- автотест для разработчика: только найти всё и выйти -------------------
if "%SV_AUTOTEST%"=="1" goto tools

rem --- сервер уже запущен на этом порту? -------------------------------------
powershell -NoProfile -Command "try{(New-Object Net.Sockets.TcpClient).Connect('127.0.0.1',%PORT%);exit 0}catch{exit 1}" >nul 2>nul <nul
if not errorlevel 1 (
  echo [3D] Сервер уже работает на http://127.0.0.1:%PORT%/ — открываю браузер.
  start "" "http://127.0.0.1:%PORT%/"
  exit /b 0
)

:tools
call :findnode
if not defined NODE goto asknode
goto nodeok

:asknode
echo.
echo [3D] Node.js не найден автоматически ^(PATH и типовые папки^).
echo      Напишите путь к node.exe ИЛИ к папке с ним, например:
echo        D:\tools\node-v20\node.exe     или     D:\tools\node-v20
echo      ^(q — отмена^).
set "NTRY=0"
:askloop
set /a NTRY+=1
if %NTRY% GTR 20 (echo [3D] Слишком много неудачных попыток. Отменено. & exit /b 1)
set "NIN="
set /p NIN=[3D] путь к node.exe: 
if /i "!NIN!"=="q" (echo [3D] Отменено. & exit /b 1)
call :resolve "!NIN!" node.exe
call :ckrun "!RSLV!"
if defined NODE (
  >"%~dp0node-home.txt" echo !RSLV!
  echo [3D] node запомнен в node-home.txt
  goto nodeok
)
echo [3D] Там нет рабочего node.exe. Попробуйте ещё раз ^(q — отмена^).
goto askloop

:nodeok
call :findpython
call :findfreecad

if "%SV_AUTOTEST%"=="1" (
  echo [autotest] NODE=!NODE!
  echo [autotest] PY=!PYEXE!  OCP=!PYOCP!
  echo [autotest] FC=!FCMD!
  exit /b 0
)

if not exist "%~dp0serve.js" (
  echo [3D] Не найден serve.js рядом с этим bat. Положите bat в папку 3d-viewer.
  pause
  exit /b 1
)

echo.
echo [3D] node   : "!NODE!"
if defined PYEXE (
  if defined PYOCP (echo [3D] python  : "!PYEXE!" — OCP есть, STEP будут ЦВЕТНЫМИ с деревом тел) else (
    echo [3D] python  : "!PYEXE!" — модуля OCP нет ^(STEP в цвете будут без цвета или через FreeCAD^).
    echo           Цвет даёт pip install cadquery-ocp ^(или другой python — пропишите путь в python-home.txt^).
  )
) else echo [3D] python  : НЕ НАЙДЕН — цветной STEP недоступен, STL/OBJ работают.
if defined FCMD (echo [3D] FreeCAD : "!FCMD!") else echo [3D] FreeCAD : не найден — STEP без python+OCP не сконвертируются.

if defined PYOCP goto launch
if defined FCMD goto launch
echo.
echo [3D] Нет ни python с OCP, ни FreeCAD — STEP-файлы открывать будет нечем,
echo      но STL/OBJ и просмотр работают.
set "GO="
set /p GO=[3D] Запустить сервер всё равно? [Y/n]: 
if /i "!GO!"=="n" (echo [3D] Отменено. & exit /b 1)

:launch
if defined PYEXE set "PY_CMD=!PYEXE!"
if defined FCMD set "FREECAD_CMD=!FCMD!"
echo.
echo [3D] адрес: http://127.0.0.1:%PORT%/   Ctrl+C в этом окне — остановить
echo.
start "" /b powershell -NoProfile -Command "Start-Sleep 2; Start-Process 'http://127.0.0.1:%PORT%/'"
"!NODE!" "%~dp0serve.js" %*
if errorlevel 1 pause
exit /b %errorlevel%

rem ============================= поиск python ================================
:findpython
set "PYEXE="
set "PYOCP="
rem 1) внешний PY_CMD или сохранённый python-home.txt
if defined PY_CMD call :trypython "%PY_CMD%"
if not defined PYOCP if exist "%~dp0python-home.txt" (
  set "PH="
  set /p PH=<"%~dp0python-home.txt"
  if defined PH call :trypython "!PH!"
)
rem 2) PATH
if not defined PYOCP for /f "delims=" %%i in ('where python 2^>nul ^<nul') do if not defined PYOCP call :trypython "%%i"
rem 3) py-launcher (ставится с python.org даже без PATH)
if not defined PYOCP for /f "delims=" %%i in ('py -3 -c "import sys;print(sys.executable)" 2^>nul ^<nul') do if not defined PYOCP call :trypython "%%i"
rem 4) типовые места (python.org без PATH, anaconda, miniconda, Microsoft Store)
for /d %%D in (
  "C:\Python3*"
  "%LOCALAPPDATA%\Programs\Python\Python*"
  "%ProgramFiles%\Python*"
  "%ProgramFiles(x86)%\Python*"
  "%USERPROFILE%\anaconda3"
  "%USERPROFILE%\miniconda3"
) do if not defined PYOCP call :trypython "%%~D\python.exe"
if not defined PYOCP call :trypython "%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe"
if defined PYOCP exit /b 0
if defined PYEXE goto pyask
rem совсем ничего — тот же вопрос, просто с другим текстом:
:pyask
set "PIN="
echo.
if defined PYEXE (
  echo [3D] Найден python "!PYEXE!", но пакета OCP в нём нет ^(STEP в цвете недоступны^).
  echo      Если есть другой python с OCP/cadquery — введите путь к нему.
  echo      Enter — оставить как есть, q — отмена.
) else (
  echo [3D] Python ^(с установленным OCP для цвета^) не найден.
  echo      Введите путь к python.exe или к его папке, например D:\tools\python312
  echo      ^(Enter — пропустить, q — отмена^).
)
:askpy
set "PIN="
set /p PIN=[3D] путь к python.exe: 
if /i "!PIN!"=="q" exit /b 1
if not defined PIN exit /b 0
call :resolve "!PIN!" python.exe
set "LASTOK="
call :trypython "!RSLV!"
if defined LASTOK (
  set "PYEXE=!RSLV!"
  >"%~dp0python-home.txt" echo !RSLV!
  echo [3D] python запомнен в python-home.txt
  if defined PYOCP exit /b 0
  echo [3D] Этот python рабочий, но OCP в нём не обнаружен. Другой путь ^(или Enter — оставить^)?
  goto askpy
)
echo [3D] Этот python не запускается. Попробуйте другой путь ^(или Enter — пропустить^).
goto askpy

:trypython
rem %1 = путь к python.exe или папке; PYEXE=первый рабочий, PYOCP=import OCP ok, LASTOK=проверяемый годен
set "LASTOK="
set "T=%~1"
if /i not "%~x1"==".exe" set "T=%~1\python.exe"
if not exist "!T!" exit /b 1
"!T!" -c "import sys" >nul 2>nul <nul || exit /b 1
set "LASTOK=1"
if not defined PYEXE set "PYEXE=!T!"
if defined PYOCP exit /b 0
"!T!" -c "import OCP" >nul 2>nul <nul && (set "PYOCP=1" & set "PYEXE=!T!")
exit /b 0

rem ============================= поиск FreeCAD ===============================
:findfreecad
set "FCMD="
if defined FREECAD_CMD if exist "%FREECAD_CMD%" (set "FCMD=%FREECAD_CMD%" & exit /b 0)
if exist "%~dp0freecad-home.txt" (
  set "FH="
  set /p FH=<"%~dp0freecad-home.txt"
  if defined FH call :tryfc "!FH!"
)
if defined FCMD exit /b 0
for /f "delims=" %%i in ('where freecadcmd 2^>nul ^<nul') do if not defined FCMD call :tryfc "%%i"
for /d %%D in (
  "%ProgramFiles%\FreeCAD*"
  "%ProgramFiles(x86)%\FreeCAD*"
  "C:\FreeCAD*"
  "%LOCALAPPDATA%\Programs\FreeCAD*"
) do if not defined FCMD (
  call :tryfc "%%~D\freecadcmd.exe"
  if not defined FCMD call :tryfc "%%~D\bin\freecadcmd.exe"
)
if defined FCMD exit /b 0
:askfc
echo.
echo [3D] FreeCAD ^(freecadcmd.exe^) не найден — это резервный серый конвертер STEP.
echo      Введите путь к freecadcmd.exe или к папке FreeCAD ^(Enter — пропустить^).
set "FIN="
set /p FIN=[3D] путь к freecadcmd.exe: 
if not defined FIN exit /b 0
if /i "!FIN!"=="q" exit /b 0
call :tryfc "!FIN!"
if defined FCMD (
  >"%~dp0freecad-home.txt" echo !FCMD!
  echo [3D] FreeCAD запомнен в freecad-home.txt
  exit /b 0
)
echo [3D] Там нет freecadcmd.exe. Попробуйте ещё раз ^(или Enter — пропустить^).
goto askfc

:tryfc
rem %1 = freecadcmd.exe или папка FreeCAD
set "F=%~1"
if /i "%~x1"==".exe" goto fchk
if exist "%~1\freecadcmd.exe" (set "F=%~1\freecadcmd.exe" & goto fchk)
if exist "%~1\bin\freecadcmd.exe" (set "F=%~1\bin\freecadcmd.exe" & goto fchk)
exit /b 1
:fchk
if exist "!F!" set "FCMD=!F!"
exit /b 0

rem =============================== подпрограммы ==============================
:findnode
set "NODE="
if exist "%~dp0node-home.txt" (
  set "NH="
  set /p NH=<"%~dp0node-home.txt"
  if defined NH (
    call :resolve "!NH!" node.exe
    call :ckrun "!RSLV!"
  )
)
if defined NODE exit /b 0
for /f "delims=" %%i in ('where node 2^>nul ^<nul') do if not defined NODE call :ckrun "%%i"
for %%C in (
  "%ProgramFiles%\nodejs\node.exe"
  "%ProgramFiles(x86)%\nodejs\node.exe"
  "%LocalAppData%\Programs\nodejs\node.exe"
  "%ProgramData%\chocolatey\bin\node.exe"
  "%USERPROFILE%\scoop\shims\node.exe"
  "%ProgramFiles%\Volta\bin\node.exe"
  "%APPDATA%\nvm\nodejs\node.exe"
  "%NVM_SYMLINK%\node.exe"
  "%~dp0node.exe"
) do if not defined NODE if exist %%C call :ckrun "%%~C"
exit /b 0

:resolve
rem %1 = exe или папка, %2 = имя exe в папке -> RSLV
set "RSLV=%~1"
if /i not "%~x1"==".exe" set "RSLV=%~1\%~2"
exit /b 0

:ckrun
rem %1 = полный путь к exe; проверяет запуском --version; успех -> NODE
set "CND=%~1"
if not exist "!CND!" exit /b 1
"!CND!" --version >nul 2>nul <nul || exit /b 2
set "NODE=!CND!"
exit /b 0
