# STEP(.stp/.step) -> binary STL конвертер для «3D просмотр моделей» (нужен установленный FreeCAD).
# Это ГЕОМЕТРИЧЕСКИЙ путь (без цвета). ЦВЕТ даёт путь python+gmsh:  python .\step2stl.py "C:\модель.stp"
# (gmsh ставится без админ-прав: pip install --user gmsh; см. step2stl-portable\README.txt)
#
# Пример:
#   .\convert-stp.ps1 "C:\модель.stp"                  # → C:\модель.stl (дефолт: дефлексия 0.2 мм)
#   .\convert-stp.ps1 "C:\модель.stp" -Lin 0.3         # крупная деталь — грубее, лёгкий STL
#   .\convert-stp.ps1 "C:\модель.stp" -Lin 0.05 -Ang 0.35
#   .\convert-stp.ps1 "C:\модель.stp" -Dst "D:\out\part.stl" -FreeCadRoot "C:\FreeCAD..."
#
# После конвертации полученный .stl открывается в viewer кнопкой «⬆ Загрузить STL / OBJ / STEP»
# (или «📂 Модели рядом», если запустить serve.js из папки с результатами).
param(
  [Parameter(Mandatory=$true, Position=0)][string]$Src,
  [string]$Dst = '',
  [double]$Lin = 0.2,
  [string]$Dst2 = '',      # второй выход — «preview» STL (грубее, для плавного вращения)
  [double]$Lin2 = 0.6,
  [double]$Ang = 0.5,
  [switch]$Relative,
  [switch]$Color,          # попробовать цвет (имеет смысл только если скрипт пустит python+gmsh; сам freecadcmd бесцветен)
  [string]$FreeCadRoot = ''
)
$ErrorActionPreference = 'Stop'
$Src = (Resolve-Path $Src).Path
if(-not $Dst){ $Dst = [System.IO.Path]::ChangeExtension($Src, '.stl') }

# ищем freecadcmd.exe
if($FreeCadRoot){
  $cmd = Get-ChildItem $FreeCadRoot -Recurse -Filter 'freecadcmd.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
}else{
  $cand = @(
    "$env:ProgramFiles\FreeCAD*","${env:ProgramFiles(x86)}\FreeCAD*","$env:LOCALAPPDATA\Programs\FreeCAD*",
    "$env:USERPROFILE\Downloads\FreeCAD*","C:\FreeCAD*"
  )
  $cmd = $null
  foreach($c in $cand){
    $cmd = Get-ChildItem $c -Recurse -Filter 'freecadcmd.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
    if($cmd){ break }
  }
}
if(-not $cmd){ throw "freecadcmd.exe не найден. Укажите путь: -FreeCadRoot 'C:\путь\до\FreeCAD...'" }
$cmdExe = $cmd.FullName

$script = Join-Path $PSScriptRoot 'step2stl.py'
$env:S2S_SRC = $Src
$env:S2S_DST = $Dst
$env:S2S_DST2 = $Dst2
$env:S2S_LIN = "$Lin"
$env:S2S_LIN2 = "$Lin2"
$env:S2S_ANG = "$Ang"
$env:S2S_REL = if($Relative){ '1' } else { '0' }
$env:S2S_COLOR = if($Color){ '1' } else { '0' }

Write-Host "freecadcmd: $cmdExe"
$msg = "$Src  ->  $Dst  (LinearDeflection=$Lin мм"
if($Dst2){ $msg += "; preview -> $Dst2 (Lin2=$Lin2 мм" }
Write-Host "$msg)"
& $cmdExe $script
if($LASTEXITCODE -ne 0){ throw "конвертация завершилась с кодом $LASTEXITCODE" }
if(Test-Path $Dst){ "готово: {0}  ({1:N1} МБ)" -f $Dst, ((Get-Item $Dst).Length/1MB) }
