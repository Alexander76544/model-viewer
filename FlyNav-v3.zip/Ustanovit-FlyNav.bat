@echo off
rem ============================================================
rem  FlyNav installer for FreeCAD 1.0+ (Windows)
rem  1) unzip the whole archive, 2) close FreeCAD,
rem  3) double-click this file, 4) start FreeCAD again.
rem  ASCII only: cmd reads .bat in the OEM codepage.
rem ============================================================
chcp 65001 >nul
title FlyNav install
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-flynav.ps1"
echo.
pause
