# -*- coding: utf-8 -*-
r"""
FlyNav v3 (мод/расширение) — свободный полёт камеры (WASD) + нулевая точка отсчёта. FreeCAD 1.x

Режим «как в игре»: WASD/QE — движение, мышь при удержанной ПКМ — обзор, координаты в строке
состояния и крупная надпись в 3D-виде пишутся от нулевой точки, которую можно поставить
в любом месте детали.

КЛАВИШИ (на время полёта клавиатура захватывается 3D-видом — кликать никуда не нужно;
в полях ввода текст печатается как обычно, полёт его не перехватывает)
    Работают в ЛЮБОЙ раскладке: физическая W в русской раскладке (Qt даёт код Key_Ц/символ «ц»)
    распознаётся как та же W — по физическому коду клавиши и по таблице ЙЦУКЕН.
    W A S D      вперёд / влево / назад / вправо
    E или Space  вверх              Q вниз
    Shift        ускорение x3 (удерживать)
    ПКМ + мышь   обзор
    N            нулевая точка в место ПОД КУРСОРОМ (мимо геометрии — на фокальную плоскость)
    Shift + N    нулевая точка в позицию камеры
    X            снять нулевую точку (отсчёт снова от глобального 0)
    ,  или -     скорость меньше     .  или =   скорость больше
    1 ... 4      точка обзора        Shift + 1 ... 4 — сохранить
    F            вписать модель обратно в вид (если улетел и геометрия «исчезла»)
    H            вернуть вид, который был до полёта
    Esc          выйти (callbacks, таймер, тип камеры и контекстное меню возвращаются)


УСТАНОВКА (расширение, не макрос)
    Каталог FlyNav/ кладётся в каталог модов FreeCAD:
        %APPDATA%\FreeCAD\v1-1\Mod\FlyNav\        (или в Mod установочного каталога)
    После перезапуска FreeCAD в списке верстаков появляется «FlyNav», в панели — кнопка
    полёта; команда также доступна по Ctrl+Shift+F из любого верстака.
    Команды мода: FlyNav_Toggle (вкл/выкл), FlyNav_Zero (ноль под курсором),
    FlyNav_ClearZero (снять ноль), FlyNav_KeysLog (журнал нажатий, если «W молчит»).
    Из Python-консоли:  import FlyNavCore; print(FlyNavCore.selftest())
                        FlyNavCore.debug_keys(True)   # пишет %TEMP%\FlyNav_keys.log


ЧТО МОЖЕТ МЕШАТЬ
    * Камеры в ортографии: «полёт вперёд» почти не виден — режим сам включает перспективу.
    * Если в Preferences -> Navigation выбран стиль, перехватывающий WASD, полёт всё равно
      работает: каждый кадр позиция/направление берутся с ФАКТИЧЕСКОЙ камеры.
    * События Qt/Coin нельзя «съесть», поэтому одно нажатие может прийти дважды (Coin и Qt).
      Отсюда: состояние клавиш — множество, обзор считается по позиции курсора, одиночные
      действия дедуплицируются по времени.
    * Каналов ввода два именно поэтому: Coin не видит клавиши, которые Qt по дороге отдал
      шорткатам FreeCAD (WASD, N, X, H, 1..4). На Qt-событии ShortcutOverride мы отвечаем
      accept() — на время полёта эти клавиши забираются у шорткатов, после выхода всё как было.
    * На время полёта отключается анимация переходов камеры (Preferences -> View), иначе
      анимированный переход уводит позицию и полёт «дёргается»; при выходе значение возвращается.
    * setCameraType() подменяет сам узел камеры, поэтому узел каждый берётся заново, а запись
      проверяется через viewPosition().
    * focalDistance (радиус орбиты) бережётся во время полёта, а при выходе ставится на ноль
      или центр модели, чтобы обычная орбита после полёта не «переворачивалась».
    * Колесо мыши остаётся FreeCAD (зум) — перехватывать его не стали.
"""

import math
import os
import sys
import traceback
import warnings


def _silence_swig_noise():
    """pivy/SWIG на каждом обращении к view.getCameraNode() выдаёт
    DeprecationWarning «builtin type SwigPyObject has no __module__ attribute».
    Узел камеры приходится перечитывать каждый кадр, поэтому Report view
    заливается красным, хотя работает всё верно. Глушим ровно это сообщение."""
    try:
        warnings.filterwarnings('ignore', message='.*__module__ attribute.*', category=DeprecationWarning)
        warnings.filterwarnings('ignore', message='.*SwigPyObject.*', category=DeprecationWarning)
    except Exception:
        pass


_silence_swig_noise()

import FreeCAD as App
import FreeCADGui as Gui
from pivy import coin


# ------------------------------------------------------------------ Qt (любой бэкенд)
def _pick_qt():
    """(QtCore, QtWidgets, имя_бэкенда) или (None, None, '')"""
    for name in ('PySide6', 'PySide2', 'PySide'):
        try:
            mod = __import__(name, fromlist=['QtCore'])
            qtc = getattr(mod, 'QtCore')
            try:
                qtw = getattr(__import__(name, fromlist=['QtWidgets']), 'QtWidgets')
            except Exception:
                qtw = getattr(__import__(name, fromlist=['QtGui']), 'QtGui')
            return qtc, qtw, name
        except Exception:
            continue
    return None, None, ''


QtCore, QtWidgets, QT_BACKEND = _pick_qt()


def _enum(qt, *names):
    """Найти перечисление и в Qt5 (Qt.Key_W), и в Qt6 (Qt.Key.Key_W). -> (объект, int|None)"""
    obj = None
    for n in names:
        if '.' in n:
            grp, leaf = n.split('.', 1)
            g = getattr(qt, grp, None)
            cand = getattr(g, leaf, None) if g is not None else None
        else:
            cand = getattr(qt, n, None)
        if cand is not None:
            obj = cand
            break
    if obj is None:
        return None, None
    try:
        return obj, int(obj)
    except Exception:
        pass
    try:
        return obj, int(obj.value)
    except Exception:
        return obj, None


# ------------------------------------------------------------------ НАСТРОЙКИ
TICK_MS            = 16        # период шага, мс (~60 Гц)
LOOK_SENS          = 0.0045    # обзоров на пиксель смещения курсора
BOOST              = 3.0       # множитель Shift
SPEED_MIN          = 0.05
SPEED_MAX          = 40.0
DIAG_TO_SPEED      = 0.15      # базовая скорость, мм/с = диагональ модели * коэффициент
BASE_SPEED_MIN     = 25.0      # медленнее не нужно: на мелкой детали полёт превратится в липанье
BASE_SPEED_MAX     = 1500.0    # быстрее — и одно нажатие W уносит модель за край экрана
FAR_PLANE_K        = 4.0       # запас дальней плоскости отсечения: K * (дистанция + радиус)
FLY_LIMIT          = True      # не давать улетать дальше «пузыря» вокруг модели (иначе FreeCAD
                               # отсекает деталь дальней плоскостью — выглядит как «исчезла»)
FLY_LIMIT_K        = 1.5       # радиус пузыря = K * диагональ модели (ViewFit ставит камеру на 1.2)
INVERT_X           = False     # обзор по X «за зеркалом» -> True
INVERT_Y           = False     # обзор по Y перевёрнут -> True
FORCE_PERSPECTIVE  = True      # на время полёта включить перспективную камеру
CREATE_ZERO_OBJECT = True      # оформлять ноль объектом в документе (хранится в .FCStd)
ZERO_AT_CURSOR     = True      # N берёт точку под курсором, а не в центре экрана
USE_QT_FILTER      = True      # второй канал ввода, если Coin-колбэки не получают клавиши
ACTION_DEDUPE_S    = 0.08      # окно, в котором одно и то же действие не повторяется
OVERLAY            = True      # крупная надпись режима прямо в 3D-виде (видно, что полёт включён
                               # и сколько клавиш до нас дошло)
GRAB_KEYBOARD      = True      # на время полёта захватывать клавиатуру 3D-видом: не нужно
                               # никуда кликать, и шорткаты FreeCAD клавиши не перехватывают
DEBUG_KEYS         = False     # True (или FlyNav.debug_keys(True)) — писать все клавиши в журнал
PITCH_LIMIT        = math.radians(88)
BOOKMARK_SLOTS     = ('1', '2', '3', '4')
PARAM_PATH         = 'User parameter:BaseApp/Preferences/Mod/FlyNav'
ZERO_LABEL         = u'FlyNav ZERO (ноль отсчёта)'
ZERO_NAME_HINT     = 'NOFLYZERO'
MOVE_KEYS          = {'w': 'fwd', 's': 'back', 'a': 'left', 'd': 'right',
                      'e': 'up', 'space': 'up', 'q': 'down'}


# --------------------------------------------------------------- сообщения/журнал
def _fc_version():
    for attr in ('VersionString',):
        v = getattr(App, attr, None)
        if isinstance(v, str) and v:
            return v
    try:
        v = App.Version()
        if isinstance(v, (tuple, list)):
            return '.'.join(str(x) for x in v)
        return str(v)
    except Exception:
        return '?'


def _log(msg, level='message'):
    """Report view + (для warning/error) строка состояния — чтобы ничего молча не падало"""
    txt = u'FlyNav: ' + str(msg)
    try:
        getattr(App.Console, 'Print' + level.capitalize())(txt + u'\n')
    except Exception:
        try:
            sys.stdout.write(txt + u'\n')
        except Exception:
            pass
    if level in ('error', 'warning'):
        _status(txt[:150], 8000)


def _status(txt, msec=0):
    try:
        mw = Gui.getMainWindow()
        cls = getattr(QtWidgets, 'QStatusBar', None)
        if mw is not None and cls is not None:
            sb = mw.findChild(cls)
            if sb is not None:
                sb.showMessage(str(txt), msec)
    except Exception:
        pass


def _alert(txt):
    """крайний случай: окно, которое точно заметят"""
    _log(txt, 'error')
    try:
        box = getattr(QtWidgets, 'QMessageBox', None)
        if box is not None:
            box.warning(Gui.getMainWindow(), u'FlyNav', str(txt))
    except Exception:
        pass


class FlyNav(object):
    """Один активный режим. Экземпляр хранится на модуле FreeCAD: при повторном запуске
    макроса Python создаёт новый объект класса, и «висящий» старый полёт надо снимать явно."""

    _instance = None

    # ------------------------------------------------------------- жизненный цикл
    @classmethod
    def toggle(cls):
        me = getattr(App, '_FlyNavInstance', None) or cls._instance
        if me is not None and getattr(me, 'active', False):
            try:
                me.stop()
                return None                       # повторный запуск = выход
            except Exception:
                _log(traceback.format_exc(6), 'error')
        me = cls()
        cls._instance = me
        try:
            App._FlyNavInstance = me
        except Exception:
            pass
        try:
            if not me.start():
                me = None
        except Exception:
            _alert(u'ошибка запуска режима полёта:\n' + traceback.format_exc(8))
            try:
                me.stop()
            except Exception:
                pass
            me = None
        return me

    def __init__(self):
        self.active = False
        self.view = None
        self.cam = None
        self.timer = None
        self.cbs = []
        self.qt_filter = None
        self.keys = set()
        self.shift = False
        self.look = False
        self.look_prev = None
        self.view_widget = None
        self._qt_cursor = None
        self._qt_err_shown = False
        self.yaw = 0.0
        self.pitch = 0.0
        self.pos = App.Vector(0, 0, 0)
        self.speed_mult = 1.0
        self.base_speed = 100.0
        self.zero = None
        self.bookmarks = {}
        self.saved_view = None
        self.saved_cam_type = None
        self.last_ts = None
        self.saved_anim = None
        self._diag0 = 0.0
        self._center0 = None
        self.saved_far = None
        self._limit_r = 0.0
        self._bubbled = False
        self._last_status = ''
        self._last_action = ('', -1.0)
        self.keys_seen = 0
        self.last_key = '—'
        self.kb_grabbed = False
        self.journal = None
        if DEBUG_KEYS:
            self.debug_keys(True)

    # ------------------------------------------------------------------ включение
    def start(self):
        _silence_swig_noise()                    # FreeCAD между запусками макросов сбрасывает фильтры
        if QtCore is None:
            _alert(u'не найден QtCore (PySide6/PySide2/PySide): таймер невозможен, полёт не работает.'
                   u' FreeCAD ' + _fc_version())
            return False
        view = self._get_view()
        if view is None:
            _alert(u'нет активного 3D-вида: откройте документ с моделью и кликните в 3D-окно.'
                   u' FreeCAD ' + _fc_version())
            return False
        self.view = view
        self.cam = None
        if self._camera() is None:
            _alert(u'view.getCameraNode() не вернул камеру:\n' + traceback.format_exc(4))
            return False

        self._sync_from_camera()
        try:
            self.saved_view = self._snapshot()
        except Exception:
            self.saved_view = None
        diag = self._model_diag()
        self.base_speed = max(BASE_SPEED_MIN, min(diag * DIAG_TO_SPEED, BASE_SPEED_MAX))
        self._diag0 = diag                                   # кэш на время полёта: bounding box
        self._center0 = self._model_center()                 # пересчитывать каждый кадр — дорого
        try:
            _c = self._center0 if self._center0 is not None else (self.pos * 1.0)
            self._limit_r = max(FLY_LIMIT_K * diag,
                                (self.pos - _c).Length * 1.05)
        except Exception:
            self._limit_r = 0.0
        self._load_state()

        if FORCE_PERSPECTIVE:
            self._set_perspective(True)
            self._camera()                       # узел камеры после смены типа ДРУГОЙ
        self._anim_off()                         # анимированные переходы камеры ломают полёт
        try:
            cam = self._camera()
            self.saved_far = float(cam.farDistance.getValue())
        except Exception:
            self.saved_far = None
        self._sync_from_camera()
        try:
            view.setPopupMenuEnabled(False)      # ПКМ = обзор, а не контекстное меню
        except Exception:
            pass

        self._add_cb('SoKeyboardEvent', self.on_key)
        self._add_cb('SoMouseButtonEvent', self.on_button)
        self._add_cb('SoLocation2Event', self.on_move)
        self.view_widget = self._find_view_widget()
        self._install_filter()
        self._grab_keyboard(True)                # чтобы клавиши шли нам без клика по виду

        try:
            self.timer = QtCore.QTimer(Gui.getMainWindow())
            self.timer.timeout.connect(self.tick)
            self.timer.start(TICK_MS)
        except Exception:
            _alert(u'не удалось создать таймер:\n' + traceback.format_exc(4))
            self.stop()
            return False

        self.active = True
        _status(u'✈ FlyNav: полёт ВКЛ · WASD + мышь при удержанной ПКМ · N — нулевая точка · '
                u'Esc — выход', 8000)
        _log(u'полёт включён: FreeCAD ' + _fc_version() + u', Qt=' + (QT_BACKEND or u'?') +
             u', callbacks=' + str(len(self.cbs)) +
             u', фильтр Qt=' + (u'есть' if self.qt_filter is not None else u'нет') +
             u', клавиатура ' + (u'захвачана виджетом' if self.kb_grabbed else u'без захвата') +
             u', база ' + ('%.0f' % self.base_speed) + u' мм/с. '
             u'Если WASD молчат: FlyNav.debug_keys(True) и пришлите %TEMP%\\FlyNav_keys.log')
        self._selftest_once()
        return True

    def stop(self):
        self.active = False
        self._grab_keyboard(False)
        try:
            if self.timer is not None:
                self.timer.stop()
        except Exception:
            pass
        self.timer = None
        for ev, cb in self.cbs:
            try:
                self.view.removeEventCallback(ev, cb)
            except Exception:
                pass
        self.cbs = []
        self._uninstall_filter()
        self.keys.clear()
        self.shift = False
        self.look = False
        self.look_prev = None
        try:
            self.view.setPopupMenuEnabled(True)
        except Exception:
            pass
        if FORCE_PERSPECTIVE and self.saved_cam_type:
            self._set_perspective(False)
        self._anim_on()
        if self.saved_far is not None:
            # дальнюю плоскость отсечения возвращаем как было: FreeCAD пересчитает её сам
            try:
                cam = self._camera()
                cur = float(cam.farDistance.getValue())
                if cur > self.saved_far:
                    cam.farDistance.setValue(self.saved_far)
                    # если после возврата деталь оказалась за кадром — F (вписать) или H (было)
            except Exception:
                pass
            self.saved_far = None
        try:
            self._set_orbit_center()             # после выхода орбита — вокруг точки взгляда
        except Exception:
            pass
        self._save_state()
        try:
            self.view.setAnnotation('')
        except Exception:
            pass
        _status('', 0)
        _log(u'выход из полёта')

    # --------------------------------------------------------------------- вид/камера
    @staticmethod
    def _get_view():
        getters = []
        try:
            getters.append(lambda: Gui.activeDocument().activeView())
        except Exception:
            pass
        # ВАЖНО: у View3DInventorPy атрибут __class__ — словарь реестра методов (не тип),
        # поэтому проверять надо через type(...) / hasattr, а не v.__class__.__name__.
        try:
            if App.ActiveDocument is not None:
                getters.append(lambda: Gui.getDocument(App.ActiveDocument.Name).ActiveView)
        except Exception:
            pass
        for g in getters:
            try:
                v = g()
                if v is not None and hasattr(v, 'getCameraNode'):
                    return v
            except Exception:
                continue
        return None

    def _add_cb(self, ev, fn):
        try:
            cb = self.view.addEventCallback(ev, fn)
            if cb is not None:
                self.cbs.append((ev, cb))
        except Exception:
            _log(u'не удалось повесить ' + ev + u' — остаётся Qt-фильтр', 'warning')

    def _install_filter(self):
        if not USE_QT_FILTER or QtCore is None:
            return
        owner = self
        try:
            app = QtCore.QCoreApplication.instance()
            if app is None:
                return

            class _Filter(QtCore.QObject):
                def eventFilter(self, obj, ev):
                    try:
                        owner.on_qt_event(ev, obj)
                    except Exception:
                        owner._qt_err_once()
                    return False                 # чужие события не съедаем

            self.qt_filter = _Filter()
            app.installEventFilter(self.qt_filter)
        except Exception:
            self.qt_filter = None

    def _qt_err_once(self):
        """исключения в фильтре иначе совершенно невидимы — показываем первое"""
        if getattr(self, '_qt_err_shown', False):
            return
        self._qt_err_shown = True
        _log(u'исключение в Qt-фильтре событий:\n' + traceback.format_exc(8), 'error')

    # ---------------------------------------- захват клавиатуры и журнал нажатий (диагностика)
    def _grab_keyboard(self, on):
        """grabKeyboard() на виджете 3D-вида: клавиши идут ему, даже если фокус в другом виджете,
        и QAction-шорткаты FreeCAD их не перехватывают. Тогда и кликать никуда не надо."""
        if not GRAB_KEYBOARD:
            return
        w = self.view_widget
        if w is None:
            return
        try:
            if on:
                try:
                    mw = Gui.getMainWindow()
                    if mw is not None:
                        mw.activateWindow()
                except Exception:
                    pass
                try:
                    w.setFocus(QtCore.Qt.FocusPolicy.StrongFocus)
                except Exception:
                    pass
                w.grabKeyboard()
                self.kb_grabbed = True
            else:
                if self.kb_grabbed:
                    w.releaseKeyboard()
                self.kb_grabbed = False
        except Exception:
            self.kb_grabbed = False

    def debug_keys(self, on=True, path=None):
        """FlyNav.debug_keys(True) — писать каждое нажатие в файл; при «W молчит» сразу видно,
        доходят ли клавиши до мода."""
        if not on:
            try:
                if self.journal is not None:
                    self.journal.close()
            except Exception:
                pass
            self.journal = None
            return u'журнал клавиш выключен'
        if path is None:
            import tempfile
            path = os.path.join(tempfile.gettempdir(), 'FlyNav_keys.log')
        try:
            if self.journal is not None:
                self.journal.close()
            self.journal = open(path, 'a', encoding='utf-8')
            self.journal.write('\n--- сессия %s active=%s ---\n' % (
                __import__('time').strftime('%H:%M:%S'), self.active))
            self.journal.flush()
            _log(u'журнал клавиш: ' + path)
        except Exception:
            self.journal = None
            return u'не удалось открыть журнал: ' + path
        return path

    def _note_key(self, kind, key, extra=''):
        self.keys_seen += 1
        self.last_key = '%s %s' % (kind, key)
        if self.journal is not None:
            try:
                import time
                t = time.time()
                self.journal.write('%s.%03d %s %s %s\n' % (
                    time.strftime('%H:%M:%S', time.localtime(t)), int((t % 1) * 1000),
                    kind, str(key), ((' ' + extra) if extra else '')))
                self.journal.flush()
            except Exception:
                pass

    def _uninstall_filter(self):
        try:
            if self.qt_filter is not None:
                QtCore.QCoreApplication.instance().removeEventFilter(self.qt_filter)
        except Exception:
            pass
        self.qt_filter = None

    # --------------------------------------------- анимация переходов камеры (мешает полёту)
    def _anim_off(self):
        try:
            p = App.ParamGet('User parameter:BaseApp/Preferences/View')
            self.saved_anim = (p.GetBool('AnimationEnabled', True), p.GetFloat('AnimationDuration', 0.5))
            p.SetBool('AnimationEnabled', False)
            p.SetFloat('AnimationDuration', 0.0)
        except Exception:
            self.saved_anim = None

    def _anim_on(self):
        if not self.saved_anim:
            return
        try:
            p = App.ParamGet('User parameter:BaseApp/Preferences/View')
            p.SetBool('AnimationEnabled', bool(self.saved_anim[0]))
            p.SetFloat('AnimationDuration', float(self.saved_anim[1]))
        except Exception:
            pass
        self.saved_anim = None

    def _model_diag(self):
        try:
            import Part
            shapes = []
            for o in App.ActiveDocument.Objects:
                sh = getattr(o, 'Shape', None)
                if sh is not None:
                    try:
                        if not sh.isNull():
                            shapes.append(sh)
                    except Exception:
                        pass
            if shapes:
                return float(Part.makeCompound(shapes).BoundBox.DiagonalLength)
        except Exception:
            pass
        try:
            cam = self._camera()
            return float(cam.focalDistance.getValue())
        except Exception:
            return 200.0

    def _set_perspective(self, on):
        try:
            if on:
                cur = self.view.getCameraType() or ''
                if 'Persp' in str(cur):
                    return
                self.saved_cam_type = str(cur)
                self.view.setCameraType('Perspective')
            else:
                self.view.setCameraType(self.saved_cam_type or 'Orthographic')
            return
        except Exception:
            pass
        try:
            want = 'Persp' if on else 'Ortho'
            for n in (self.view.listCameraTypes() or []):
                if want in str(n):
                    self.view.setCameraType(n)
                    return
        except Exception:
            pass

    def _sync_from_camera(self):
        pos = f = None
        try:
            plm = self.view.viewPosition()
            pos = plm.Base
            f = plm.Rotation.multVec(App.Vector(0, 0, -1))
        except Exception:
            try:
                cam = self._camera()
                p = cam.position.getValue()
                pos = App.Vector(float(p[0]), float(p[1]), float(p[2]))
                f = self._cam_dir()
            except Exception:
                pass
        if pos is None or f is None:
            return
        try:
            ln = math.sqrt(f.x * f.x + f.y * f.y + f.z * f.z) or 1.0
            self.yaw = math.atan2(f.y, f.x)
            self.pitch = math.asin(max(-1.0, min(1.0, f.z / ln)))
            self.pos = App.Vector(float(pos.x), float(pos.y), float(pos.z))
        except Exception:
            pass

    def _cam_dir(self):
        cam = self._camera()
        if cam is None:
            return App.Vector(1, 0, 0)
        rot = cam.orientation.getValue()
        v = coin.SbVec3f(0, 0, -1)
        out = None
        try:
            out = rot.multVec(v)
        except Exception:
            try:
                rot.multVec(v, v)
                out = v
            except Exception:
                out = None
        if out is None:
            return App.Vector(1, 0, 0)
        try:
            return App.Vector(float(out[0]), float(out[1]), float(out[2]))
        except Exception:
            return App.Vector(out.x, out.y, out.z)

    @staticmethod
    def fwd_of(yaw, pitch):
        cp = math.cos(pitch)
        return App.Vector(cp * math.cos(yaw), cp * math.sin(yaw), math.sin(pitch))

    @staticmethod
    def right_of(yaw):
        return App.Vector(math.cos(yaw + math.pi / 2.0), math.sin(yaw + math.pi / 2.0), 0.0)

    def _forward(self):
        return self.fwd_of(self.yaw, self.pitch)

    def _camera(self):
        """УЗЕЛ КАМЕРЫ ВСЕГДА ПЕРЕПОЛУЧАЕМ. setCameraType() меняет сам узел
        (SoOrthographicCamera -> SoPerspectiveCamera): запись в сохранённый ранее узел
        молча уходит в отсоединённый объект, и камера не двигается вообще."""
        try:
            c = self.view.getCameraNode()
            if c is not None:
                self.cam = c
        except Exception:
            pass
        return self.cam

    def _write_camera(self):
        cam = self._camera()
        fd = None
        if cam is not None:
            try:
                fd = float(cam.focalDistance.getValue())
            except Exception:
                fd = None
            try:
                cam.position.setValue(coin.SbVec3f(self.pos.x, self.pos.y, self.pos.z))
            except Exception:
                try:
                    cam.position.setValue((self.pos.x, self.pos.y, self.pos.z))
                except Exception:
                    pass
            try:
                t = self.pos + self._forward()
                cam.pointAt(coin.SbVec3f(t.x, t.y, t.z), coin.SbVec3f(0, 0, 1))
            except Exception:
                pass
            # pointAt всегда выставляет focalDistance = расстояние до цели (у нас 1 мм) — возвращаем:
            # иначе после выхода из полёта орбита крутится вокруг точки вплотную к камере.
            if fd and fd > 1e-3:
                try:
                    cam.focalDistance.setValue(fd)
                except Exception:
                    pass
        # страховка: если Coin-узел нас «не послушался» — пишем через viewPosition()
        try:
            cur = self.view.viewPosition()
            if (cur.Base - self.pos).Length > 1e-2:
                self.view.viewPosition(App.Placement(self.pos, cur.Rotation))
        except Exception:
            pass
        self._keep_far_plane(cam)

    def _keep_far_plane(self, cam=None):
        """Дальнюю плоскость отсечения FreeCAD пересчитывает только при вписывании вида, поэтому
        при полёте «от модели» деталь просто исчезает за far plane. Держим запас, чтобы геометрия
        не пропадала; при выходе значение возвращается (F — вписать вид вручную)."""
        cam = cam if cam is not None else self._camera()
        if cam is None:
            return
        try:
            c = self._center0 if getattr(self, '_center0', None) is not None else self.zero
            if c is None:
                return
            dist = (self.pos - c).Length
            need = FAR_PLANE_K * (dist + 0.5 * (getattr(self, '_diag0', 0.0) or 0.0)) + 1.0
            cur = float(cam.farDistance.getValue())
            if cur < need:
                cam.farDistance.setValue(need)
        except Exception:
            pass

    def _model_center(self):
        """центр ограничивающего бокса всех форм документа — устойчивая точка орбиты"""
        try:
            bb = App.BoundBox()
            for o in App.ActiveDocument.Objects:
                sh = getattr(o, 'Shape', None)
                if sh is None:
                    continue
                try:
                    if sh.isNull():
                        continue
                    b = sh.BoundBox
                    if not b.isValid():
                        continue
                except Exception:
                    continue
                bb.add(b)
            if bb.isValid():
                return App.Vector(bb.Center.x, bb.Center.y, bb.Center.z)
        except Exception:
            pass
        return None

    def _set_orbit_center(self):
        """после выхода орбитe нужен нормальный центр: ноль -> центр модели -> точка под курсором.
        Иначе focalDistance может стать 5 мм и вид при первом же вращении «переворачивается»."""
        p = self.zero if self.zero is not None else self._model_center()
        if p is None:
            p = self._pick(self._center_px())
        if p is None:
            return
        d = (p - self.pos).Length
        try:
            d = max(d, 0.05 * self._model_diag())
        except Exception:
            pass
        if d > 1e-6:
            cam = self._camera()
            if cam is not None:
                cam.focalDistance.setValue(float(d))

    def _size_px(self):
        try:
            w, h = self.view.getSize()
            return (int(w), int(h))
        except Exception:
            return (0, 0)

    @staticmethod
    def _find_view_widget():
        """Qt-виджет 3D-вида (нужен, чтобы переводить координаты мыши в пиксели вида)."""
        if not QT_BACKEND:
            return None
        QWidget = None
        try:
            QWidget = getattr(__import__(QT_BACKEND, fromlist=['QtGui']).QtGui, 'QWidget')
        except Exception:
            try:
                QWidget = getattr(__import__(QT_BACKEND, fromlist=['QtWidgets']).QtWidgets, 'QWidget')
            except Exception:
                QWidget = None
        if QWidget is None:
            return None
        try:
            cands = []
            for w in Gui.getMainWindow().findChildren(QWidget):
                try:
                    cn = str(w.metaObject().className())
                    if 'View3D' not in cn:
                        continue
                    g = w.geometry()
                    cands.append((int(g.width()) * int(g.height()), w, 1 if 'Viewer' in cn else 0))
                except Exception:
                    continue
            if not cands:
                return None
            cands.sort(key=lambda t: (t[0], t[2]), reverse=True)   # самый большой вид, предпочтительно Viewer
            return cands[0][1]
        except Exception:
            return None

    def _center_px(self):
        w, h = self._size_px()
        return (max(1, w // 2), max(1, h // 2))

    # ----------------------------------------------------------------------- события
    def _now(self):
        try:
            return QtCore.QDateTime.currentMSecsSinceEpoch() / 1000.0
        except Exception:
            import time
            return time.time()

    def _action_once(self, name):
        """Coin и Qt могут принести одно нажатие дважды — действие выполняем один раз"""
        t = self._now()
        last, ts = self._last_action
        if last == name and 0.0 <= (t - ts) < ACTION_DEDUPE_S:
            return False
        self._last_action = (name, t)
        return True

    SHIFTED_CHARS = {u'!': '1', u'@': '2', u'#': '3', u'$': '4', u'%': '5',
                     u'^': '6', u'&': '7', u'*': '8', u'(': '9', u')': '0',
                     u':': ';', u'<': ',', u'>': '.'}

    # -------------------------------------------------- клавиши, не зависящие от раскладки
    # При русской раскладке Qt присылает на физической клавише W кириллический код («Т»),
    # и маппинг по ev.key() её не знает — вот откуда «жму W, а ничего не происходит».
    #_nativeScanCode() — физический код (Windows PS/2 make code), раскладку не видит.
    SCAN_KEYS = {
        1: 'escape', 57: 'space', 42: 'shift', 54: 'shift',
        2: '1', 3: '2', 4: '3', 5: '4', 6: '5', 7: '6', 8: '7', 9: '8', 10: '9', 11: '0',
        12: 'minus', 13: 'equal',
        16: 'q', 17: 'w', 18: 'e', 19: 'r', 20: 't', 21: 'y', 22: 'u', 23: 'i', 24: 'o', 25: 'p',
        30: 'a', 31: 's', 32: 'd', 33: 'f', 34: 'g', 35: 'h', 36: 'j', 37: 'k', 38: 'l',        44: 'z', 45: 'x', 46: 'c', 47: 'v', 48: 'b', 49: 'n', 50: 'm',
        51: ',', 52: '.',
    }
    # ЙЦУКЕН -> та же клавиша по положению (запасной вариант, если scan code недоступен)
    CYR_KEYS = {u'ц': 'w', u'ы': 's', u'ф': 'a', u'в': 'd', u'у': 'e', u'й': 'q',
                u'р': 'h', u'т': 'n', u'ч': 'x', u'к': 'r', u'н': 'y', u'г': 'u',
                u'ш': 'i', u'щ': 'o', u'з': 'p', u'а': 'f', u'п': 'g', u'о': 'j',
                u'л': 'k', u'я': 'z', u'с': 'c', u'м': 'v', u'и': 'b', u'ь': 'm'}
    CH_ALIAS = {u' ': 'space', u'-': 'minus', u'=': 'equal', u'\x1b': 'escape'}
    ASCII_KEYS = set(u'wsadqenhf1234.,')

    def _key_of(self, ev, note=True):
        """имя клавиши режима из Qt-события: сначала по коду Qt, потом по физическому коду,
        потом по символу (включая кириллицу). Нераспознанное записываем в last_key, чтобы это
        было видно прямо в 3D-виде."""
        try:
            k = QT_KEYS.get(_as_int(ev.key()))
        except Exception:
            k = None
        if k is not None:
            return k
        scan = None
        try:
            scan = _as_int(ev.nativeScanCode())
        except Exception:
            scan = None
        if scan is not None:
            k = self.SCAN_KEYS.get(scan)
            if k is not None:
                return k
        try:
            txt = (ev.text() or u'').strip().lower()
        except Exception:
            txt = u''
        if txt:
            c = txt[0]
            k = self.CYR_KEYS.get(c) or self.CH_ALIAS.get(c) or (c if c in self.ASCII_KEYS else None)
            if k is not None:
                return k
        if note:
            try:
                self.last_key = u'?? key=0x%X scan=%s txt=%r' % (
                    (_as_int(ev.key()) or 0), scan, txt or u'-')
            except Exception:
                pass
        return None

    def on_key(self, info):
        try:
            raw = str(info.get('Key') or '').strip()
            key = raw.lower()
            if len(key) == 1 and raw in self.SHIFTED_CHARS:      # Coin отдаёт символ: '!' -> '1'
                key = self.SHIFTED_CHARS[raw]
            key = self.CYR_KEYS.get(key, key)                    # и по-русски та же клавиша
            up = str(info.get('State') or '').upper() == 'UP'
            if up:
                if key:
                    self.keys.discard(key)
                if key.startswith('shift'):
                    self.keys.discard('shift')
                return
            if info.get('ShiftDown'):
                self.shift = True
            if not key:
                return
            if key.startswith('shift'):
                self.keys.add('shift')
                self.shift = True
                return
            self.keys.add(key)
            self._note_key('coin', key, 'up' if up else 'down')
            self._handle_action(key, bool(info.get('ShiftDown')))
        except Exception:
            self._die(u'ошибка обработчика клавиатуры')

    def on_button(self, info):
        try:
            b = str(info.get('Button') or '').upper()
            if b not in ('BUTTON3', 'RIGHTBUTTON'):
                return
            self.look = str(info.get('State') or '').upper() != 'UP'
            self.look_prev = None
        except Exception:
            pass

    def on_move(self, info):
        try:
            p = info.get('Position')
            if p is not None:
                self._qt_cursor = (int(p[0]), int(p[1]))
        except Exception:
            pass

    # ------------------------------------------------- второй канал: Qt-фильтр приложения
    def on_qt_event(self, ev, receiver=None):
        """Важно: у Qt6-событий нет .widget(); получатель приходит из eventFilter(obj, ev)."""
        if not self.active or QtCore is None:
            return
        ET = QtCore.QEvent.Type
        t = ev.type()
        if t == ET.ShortcutOverride:
            # Пока фокус не в поле ввода и клавиша наша — НЕ отдаём её шорткатам FreeCAD
            # (иначе WASD/N/X/H/1..4 съедаются QAction-ярлыками и до вида/Coin не доходят).
            try:
                if not self._typing_focus() and self._key_of(ev, note=False) is not None:
                    ev.accept()
            except Exception:
                pass
            return
        if t == ET.KeyPress or t == ET.KeyRelease:
            if self._typing_focus():
                return
            key = self._key_of(ev)
            if key is None:
                # клавиша дошла, но не наша: счётчик пусть вырастет — по нему видно, что
                # клавиатура работает, а коды видно в оверлее и в журнале
                self._note_key('qt', self.last_key, 'не распознана')
                return
            shifted = _has_shift(ev.modifiers())
            if t == ET.KeyRelease:
                self.keys.discard(key)
                if key == 'shift':
                    self.shift = False
                return
            if key == 'shift':
                self.shift = True
                self.keys.add('shift')
                return
            if shifted:
                self.shift = True
            self.keys.add(key)
            self._note_key('qt', key, 'press' if t == ET.KeyPress else 'release')
            self._handle_action(key, shifted)
        elif t == ET.MouseButtonPress or t == ET.MouseButtonRelease:
            if QT_RMB is not None and _as_int(ev.button()) == QT_RMB:
                self.look = (t == ET.MouseButtonPress)
                self.look_prev = None
        elif t == ET.MouseMove:
            host = self.view_widget
            if host is None or receiver is None:
                return
            try:
                pt = ev.position() if hasattr(ev, 'position') else ev.pos()
                qp = QtCore.QPoint(int(pt.x()), int(pt.y()))
                if receiver is host:
                    p = qp
                elif receiver.isAncestorOf(host):
                    p = host.mapFrom(receiver, qp)      # mapFrom принимает ТОЛЬКО предка
                elif host.isAncestorOf(receiver):
                    p = receiver.mapTo(host, qp)        # потомок — наоборот, mapTo
                else:
                    return                              # чужой виджет: курсор не трогаем
                self._qt_cursor = (int(p.x()), int(p.y()))
            except Exception:
                pass

    def _handle_action(self, key, shift):
        if key in ('escape', 'esc'):
            if self._action_once('esc'):
                self.stop()
            return
        if key == 'n':
            if self._action_once('n'):
                self.set_zero(at_camera=shift)
            return
        if key == 'x':
            if self._action_once('x'):
                self.clear_zero()
            return
        if key == 'h':
            if self._action_once('h'):
                self._restore_saved_view()
            return
        if key == 'f':
            # F — вписать модель в вид: спасает, если улетел внутрь детали или слишком далеко
            if self._action_once('fit'):
                try:
                    Gui.SendMsgToActiveView('ViewFit')
                except Exception:
                    pass
                self._sync_from_camera()
            return
        if key in ('comma', 'minus'):
            if self._action_once('slow'):
                self.speed_mult = max(SPEED_MIN, round(self.speed_mult * 0.8, 3))
                self._save_state()
                self._hud()
            return
        if key in ('period', 'equal'):
            if self._action_once('fast'):
                self.speed_mult = min(SPEED_MAX, round(self.speed_mult * 1.25, 3))
                self._save_state()
                self._hud()
            return
        if key in BOOKMARK_SLOTS:
            if self._action_once('bm' + key + ('s' if shift else '')):
                if shift:
                    self._save_bookmark(key)
                else:
                    self._goto_bookmark(key)
            return

    @staticmethod
    def _typing_focus():
        """пока пользователь печатает в поле ввода — не летим"""
        try:
            w = Gui.getMainWindow().focusWidget()
        except Exception:
            return False
        if w is None:
            return False
        try:
            name = str(w.metaObject().className())
        except Exception:
            return False
        for frag in ('LineEdit', 'TextEdit', 'PlainTextEdit', 'SpinBox', 'ComboBox',
                     'KeySequenceEdit', 'Search'):
            if frag in name:
                return True
        return False

    # --------------------------------------------------------------------------- шаг
    def tick(self):
        if not self.active:
            return
        try:
            dt = self._dt()
            if self.look:
                self._apply_look()
            self._step(dt)
            self._hud()
        except Exception:
            self._die(u'ошибка шага полёта')

    def _dt(self):
        now = self._now()
        dt = 1.0 / 60.0 if self.last_ts is None else now - self.last_ts
        self.last_ts = now
        return max(0.0, min(0.05, dt))

    def _cursor_px(self):
        """пиксели внутри 3D-вида: сначала из событий (Coin/Qt), потом getCursorPos с проверкой границ"""
        w, h = self._size_px()
        c = getattr(self, '_qt_cursor', None)
        if c is not None and (w <= 0 or (0 <= c[0] <= w and 0 <= c[1] <= h)):
            return c
        try:
            p = self.view.getCursorPos()
            if p is not None:
                x, y = int(p[0]), int(p[1])
                if (w <= 0 or (0 <= x <= w and 0 <= y <= h)) and (x or y):
                    return (x, y)
        except Exception:
            pass
        return self._center_px()

    def _aim_px(self):
        """куда смотрим для N: под курсором (ZERO_AT_CURSOR) или в центр экрана"""
        if ZERO_AT_CURSOR:
            return self._cursor_px()
        return self._center_px()

    def _apply_look(self):
        """обзор по позиции курсора — идемпотентен, не зависит от того, кто принёс событие"""
        self._sync_from_camera()               # если вид двигали не мы, не тащим за собой старую позицию
        x, y = self._cursor_px()
        if self.look_prev is None:
            self.look_prev = (x, y)
            return
        dx = x - self.look_prev[0]
        dy = y - self.look_prev[1]
        self.look_prev = (x, y)
        if not (dx or dy):
            return
        self.yaw += (-1 if INVERT_X else 1) * dx * LOOK_SENS
        self.pitch = max(-PITCH_LIMIT, min(PITCH_LIMIT,
                                           self.pitch + ((-1 if INVERT_Y else 1) * dy * LOOK_SENS)))
        self._write_camera()

    def _step(self, dt):
        self._sync_from_camera()
        self._bubbled = False
        mv = App.Vector(0, 0, 0)
        if self.keys:
            s = self.base_speed * self.speed_mult * dt
            if self.shift or 'shift' in self.keys:
                s *= BOOST
            f = self._forward()
            r = self.right_of(self.yaw)
            axis = {'fwd': f, 'back': f * -1, 'right': r, 'left': r * -1,
                    'up': App.Vector(0, 0, 1), 'down': App.Vector(0, 0, -1)}
            for k in self.keys:
                a = MOVE_KEYS.get(k)
                if a:
                    mv = mv + axis[a] * s
        if mv.Length > 1e-12:
            self.pos = self.pos + mv
            self._clamp_bubble()
            self._write_camera()
        else:
            self._raise_bubble()                # сам пользователь (колесо, орбита) потолок поднимает
        return mv

    def _bubble_center(self):
        c = getattr(self, '_center0', None)
        if c is None:
            c = self.zero
        return c

    def _clamp_bubble(self):
        """FreeCAD пересчитывает плоскости отсечения сам и держит far plane впритык к
        дистанции (~dist + 0.3*диагональ). Как только камера отлетает дальше ~1.2 диагонали
        модели, геометрия за этой плоскостью исчезает — то самое «деталь пропала». Пузырь
        вокруг модели не даёт улететь дальше, а F/колесо мыши потолок только поднимают."""
        if not FLY_LIMIT:
            return
        c = self._bubble_center()
        if c is None:
            return
        d = (self.pos - c).Length
        lim = max(getattr(self, '_limit_r', 0.0), 1.0)
        if d > lim:
            self.pos = c + (self.pos - c) * (lim / d)
            self._bubbled = True

    def _raise_bubble(self):
        if not FLY_LIMIT:
            return
        c = self._bubble_center()
        if c is None:
            return
        try:
            d = (self.view.viewPosition().Base - c).Length
        except Exception:
            return
        if d > getattr(self, '_limit_r', 0.0):
            self._limit_r = d

    def _die(self, why=None):
        if why:
            _log(why, 'error')
        _log(traceback.format_exc(6), 'error')
        try:
            self.stop()
        except Exception:
            pass

    # ------------------------------------------------------------------ нулевая точка
    def _pick(self, px):
        try:
            oi = self.view.getObjectInfo(px)
        except Exception:
            oi = None
        try:
            if oi is not None and ('x' in oi and 'y' in oi and 'z' in oi):
                return App.Vector(float(oi['x']), float(oi['y']), float(oi['z']))
        except Exception:
            pass
        try:
            p = self.view.getPointOnFocalPlane(px)
            if p is not None:
                return App.Vector(float(p.x), float(p.y), float(p.z))
        except Exception:
            pass
        return None

    def set_zero(self, at_camera=False, pos=None):
        try:
            if at_camera:
                p = App.Vector(self.pos)
            elif pos is not None:
                p = App.Vector(pos)
            else:
                p = self._pick(self._aim_px())
                if p is None:
                    p = self.pos + self._forward() * max(20.0, self.base_speed)
            self.zero = App.Vector(float(p.x), float(p.y), float(p.z))
            self._make_zero_object(self.zero)
            self._save_state()
            _log(u'нулевая точка: X %+.3f  Y %+.3f  Z %+.3f  (от неё считаются координаты в строке состояния)'
                 % (self.zero.x, self.zero.y, self.zero.z))
            self._hud()
        except Exception:
            self._die(u'не удалось поставить нулевую точку')

    def clear_zero(self):
        self.zero = None
        self._remove_zero_object()
        self._save_state()
        self._hud()
        _log(u'нулевая точка снята — отсчёт от глобального 0')

    # ------------------------------------------------------- маркер нуля в документе
    def _find_zero_object(self):
        try:
            for o in App.ActiveDocument.Objects:
                if str(o.Name or '').startswith(ZERO_NAME_HINT) or \
                   str(o.Label or '').startswith(ZERO_LABEL):
                    return o
        except Exception:
            pass
        return None

    def _make_zero_object(self, p):
        if not CREATE_ZERO_OBJECT:
            return
        doc = App.ActiveDocument
        started = False
        if doc is None:
            return
        try:
            import Part
            old = self._find_zero_object()
            if old is not None:
                doc.removeObject(old.Name)
            L = max(5.0, self.base_speed * 0.15)
            edges = [Part.makeLine(p, p + App.Vector(L, 0, 0)),
                     Part.makeLine(p, p + App.Vector(0, L, 0)),
                     Part.makeLine(p, p + App.Vector(0, 0, L)),
                     Part.makeLine(p, p + App.Vector(-L * 0.35, 0, 0)),
                     Part.makeLine(p, p + App.Vector(0, -L * 0.35, 0)),
                     Part.makeLine(p, p + App.Vector(0, 0, -L * 0.35))]
            shp = Part.makeCompound(edges + [Part.makeSphere(L * 0.06, p)])
            try:
                doc.openTransaction(u'FlyNav zero')
                started = True
            except Exception:
                started = False
            o = doc.addObject('Part::Feature', ZERO_NAME_HINT)
            o.Label = ZERO_LABEL
            o.Shape = shp
            doc.recompute()
            vo = getattr(o, 'ViewObject', None)
            if vo is not None:
                for prop, val in (('LineColor', (0.29, 0.87, 0.50)),
                                  ('ShapeColor', (0.29, 0.87, 0.50)),
                                  ('LineWidth', 2.0),
                                  ('Selectable', False)):     # не ловит клики вместо детали
                    try:
                        setattr(vo, prop, val)
                    except Exception:
                        pass
            if started:
                try:
                    doc.commitTransaction()
                except Exception:
                    pass
        except Exception:
            if started:
                try:
                    doc.abortTransaction()
                except Exception:
                    pass
            _log(u'маркер нуля в документе не создан (на отсчёт координат не влияет)', 'warning')

    def _remove_zero_object(self):
        if not CREATE_ZERO_OBJECT:
            return
        doc = App.ActiveDocument
        if doc is None:
            return
        try:
            o = self._find_zero_object()
            if o is None:
                return
            started = False
            try:
                doc.openTransaction(u'FlyNav zero off')
                started = True
            except Exception:
                pass
            doc.removeObject(o.Name)
            if started:
                try:
                    doc.commitTransaction()
                except Exception:
                    pass
        except Exception:
            pass

    # ------------------------------------------------------------------ точки обзора
    def _snapshot(self):
        """Копия вида. viewPosition() отдаёт ЖИВОЙ объект, связанный с видом:
        сохранённый без копирования «вид» начинает дрейфовать вместе с камерой."""
        p = self.view.viewPosition()
        return App.Placement(App.Vector(p.Base), App.Rotation(p.Rotation))

    def _save_bookmark(self, slot):
        try:
            self.bookmarks[slot] = self._snapshot()
            self._save_state()
            _log(u'точка обзора ' + slot + u' сохранена')
        except Exception:
            _log(u'не удалось сохранить точку обзора', 'warning')

    def _goto_bookmark(self, slot):
        plm = self.bookmarks.get(slot)
        if plm is None:
            _log(u'точка обзора ' + slot + u' не задана (Shift+' + slot + u' — сохранить)', 'warning')
            return
        self._apply_placement(plm)

    def _restore_saved_view(self):
        if self.saved_view is None:
            return
        self._apply_placement(self.saved_view)
        _log(u'вид возвращён как до полёта')

    def _apply_placement(self, plm):
        """setCameraOrientation() в 1.x запускает АНИМАЦИЮ перехода, которая по пути уводит и
        позицию — поэтому ориентацию выставляем сами: yaw/pitch -> pointAt живого узла камеры."""
        try:
            self.pos = App.Vector(plm.Base)
        except Exception:
            return
        try:
            f = plm.Rotation.multVec(App.Vector(0, 0, -1))
            ln = math.sqrt(f.x * f.x + f.y * f.y + f.z * f.z) or 1.0
            self.yaw = math.atan2(f.y, f.x)
            self.pitch = math.asin(max(-1.0, min(1.0, f.z / ln)))
        except Exception:
            self._sync_from_camera()
        self._write_camera()
        try:                      # на случай, если анимация всё-таки включена
            cur = self.view.viewPosition()
            if (cur.Base - self.pos).Length > 1e-2:
                self.view.viewPosition(App.Placement(self.pos, plm.Rotation))
        except Exception:
            pass

    # ------------------------------------------------------------------ HUD/параметры
    def hud_text(self, pos, zero, dist=None):
        z = zero if zero is not None else App.Vector(0, 0, 0)
        r = pos - z
        rl = dist if dist is not None else math.sqrt(r.x * r.x + r.y * r.y + r.z * r.z)
        head = (u'⌖ X %+.3f Y %+.3f Z %+.3f' % (z.x, z.y, z.z)) if zero is not None else u'⌖ ноль не задан (N)'
        sp = self.base_speed * self.speed_mult * (BOOST if self.shift else 1.0)
        return (u'✈ X %+.2f  Y %+.2f  Z %+.2f  ·  R %.1f  ·  %s  ·  %.0f мм/с (%.1f×)  ·  '
                u'ПКМ+мышь обзор · N ноль · , . скорость · F вписать · 1-4 вид · Esc выход'
                % (r.x, r.y, r.z, rl, head, sp, self.speed_mult))

    def _hud(self):
        try:
            z = self.zero
            r = self.pos - (z if z is not None else App.Vector(0, 0, 0))
            txt = self.hud_text(self.pos, z, r.Length)
        except Exception:
            return
        if txt == self._last_status:
            return
        self._last_status = txt
        if getattr(self, '_bubbled', False):
            txt += u'  ·  ⛔ граница полёта (F — вписать, колесо — отдалить)'
        _status(txt, 0)
        if OVERLAY:
            try:
                self.view.setAnnotation(
                    u'\u2708 FlyNav · клавиш дошло: %d (посл. «%s»)\n%s'
                    % (self.keys_seen, self.last_key, txt))
            except Exception:
                pass

    def _save_state(self):
        try:
            p = App.ParamGet(PARAM_PATH)
            p.SetFloat('SpeedMult', self.speed_mult)
            if self.zero is not None:
                p.SetString('Zero', '%.6f,%.6f,%.6f' % (self.zero.x, self.zero.y, self.zero.z))
            else:
                p.SetString('Zero', '')
            for s in BOOKMARK_SLOTS:
                plm = self.bookmarks.get(s)
                if plm is not None:
                    b, q = plm.Base, plm.Rotation.Q
                    p.SetString('bm' + s, '%.6f,%.6f,%.6f,%.9f,%.9f,%.9f,%.9f'
                                % (b.x, b.y, b.z, q[0], q[1], q[2], q[3]))
        except Exception:
            pass

    def _load_state(self):
        try:
            p = App.ParamGet(PARAM_PATH)
            m = p.GetFloat('SpeedMult', 1.0)
            if m and m > 0:
                self.speed_mult = max(SPEED_MIN, min(SPEED_MAX, float(m)))
            s = p.GetString('Zero', '')
            if s and self.zero is None:
                v = [float(x) for x in s.split(',')]
                if len(v) == 3:
                    self.zero = App.Vector(v[0], v[1], v[2])
                    self._make_zero_object(self.zero)
            for slot in BOOKMARK_SLOTS:
                s = p.GetString('bm' + slot, '')
                if not s:
                    continue
                v = [float(x) for x in s.split(',')]
                if len(v) == 7:
                    self.bookmarks[slot] = App.Placement(App.Vector(v[0], v[1], v[2]),
                                                         App.Rotation(v[3], v[4], v[5], v[6]))
        except Exception:
            pass

    # ------------------------------------------------------------------- самодиагностика
    def _selftest_once(self):
        try:
            if getattr(App, '_FlyNavTested', False):
                return
            App._FlyNavTested = True
            self.selftest()
        except Exception:
            pass

    @classmethod
    def selftest(cls):
        v = cls._get_view()
        out = [u'FreeCAD ' + _fc_version() + u' | Python ' + sys.version.split()[0] +
               u' | Qt: ' + (QT_BACKEND or u'НЕ НАЙДЕН')]
        out.append(u'QtCore: ' + (u'ok' if QtCore is not None else u'НЕТ'))
        out.append(u'активный 3D-вид: ' + (u'ok (' + type(v).__name__ + u')'
                                           if v is not None else u'НЕТ'))
        out.append(u'документ: ' + str(getattr(App.ActiveDocument, 'Name', u'нет')) +
                   u', объектов: ' + str(len(getattr(App.ActiveDocument, 'Objects', []) or [])))
        vw = cls._find_view_widget()
        out.append(u'Qt-виджет 3D-вида: ' + (type(vw).__name__ if vw is not None else u'не найден'))
        if v is not None:
            for m in ('getCameraNode', 'viewPosition', 'addEventCallback', 'getObjectInfo',
                      'getPointOnFocalPlane', 'getSize', 'getCursorPos', 'setCameraType',
                      'setPopupMenuEnabled', 'setCameraOrientation'):
                out.append(u'  view.' + m + u': ' + (u'есть' if hasattr(v, m) else u'НЕТ'))
            try:
                out.append(u'  камера: ' + str(v.getCameraType()) + u' | список: ' + str(v.listCameraTypes()))
            except Exception as e:
                out.append(u'  камера: ошибка ' + str(e))
            try:
                sz = v.getSize()
                oi = v.getObjectInfo((int(sz[0] // 2), int(sz[1] // 2)))
                keys = sorted(oi.keys()) if isinstance(oi, dict) else repr(oi)
                out.append(u'  getObjectInfo(центр): ' + str(keys)[:220])
            except Exception as e:
                out.append(u'  getObjectInfo: ошибка ' + str(e))
            try:
                out.append(u'  callbacks: ' + str(v.addEventCallback('SoKeyboardEvent', lambda i: None)) +
                           u' (сразу снимаем)')
            except Exception as e:
                out.append(u'  addEventCallback: ошибка ' + str(e))
        out.append(u'клавиши Qt: ' + str(len(QT_KEYS)) + u' | RMB: ' + str(QT_RMB) +
                   u' | Shift: ' + str(QT_SHIFT_INT))
        text = u'\n'.join(out)
        _log(u'самодиагностика:\n' + text)
        _status(u'FlyNav selftest — подробности в Report view', 8000)
        try:
            sys.stdout.write(text + u'\n')
        except Exception:
            pass
        return text


# --------------------------------------------------------- Qt-коды клавиш -> имена
def _as_int(x):
    try:
        return int(x)
    except Exception:
        pass
    try:
        return int(x.value)
    except Exception:
        return None


_QT = getattr(QtCore, 'Qt', None) if QtCore is not None else None
if _QT is not None:
    QT_SHIFT, QT_SHIFT_INT = _enum(_QT, 'ModifierShift', 'ShiftModifier', 'KeyboardModifier.ShiftModifier')
    QT_RMB_OBJ, QT_RMB = _enum(_QT, 'RightButton', 'MouseButton.RightButton')
    if QT_RMB_OBJ is not None and QT_RMB is None:
        QT_RMB = 2

    QT_KEYS = {}

    def _bind(code_names, name):
        for cn in code_names:
            o, i = _enum(_QT, 'Key_' + cn, 'Key.Key_' + cn)
            if i is not None:
                QT_KEYS[i] = name
                return

    for letters in (('W', 'w'), ('A', 'a'), ('S', 's'), ('D', 'd'), ('E', 'e'), ('Q', 'q'),
                    ('N', 'n'), ('X', 'x'), ('H', 'h'), ('F', 'f'), ('ShiftLeft', 'shift'),
                    ('ShiftRight', 'shift'), ('Space', 'space'), ('Escape', 'escape'),
                    ('Comma', 'comma'), ('Period', 'period'),
                    ('Minus', 'minus'), ('Equal', 'equal')):
        _bind(*letters)
    for i in range(1, 10):
        _bind([str(i)], str(i))
else:
    QT_SHIFT = QT_SHIFT_INT = QT_RMB = None
    QT_KEYS = {}


def _has_shift(mods):
    if mods is None:
        return False
    if QT_SHIFT is not None:
        try:
            return bool(mods & QT_SHIFT)
        except Exception:
            pass
    mi = _as_int(mods)
    if mi is not None and QT_SHIFT_INT is not None:
        return bool(mi & QT_SHIFT_INT)
    return False


# ---------------------------------------------------------------- публичный API
def instance():
    """текущий экземпляр режима (или None)"""
    return getattr(App, '_FlyNavInstance', None)


def is_active():
    me = instance()
    return bool(me is not None and me.active)


def toggle():
    return FlyNav.toggle()


def start():
    """включить полёт (если уже включён — ничего не делать)"""
    if is_active():
        return instance()
    return FlyNav.toggle()


def stop():
    me = instance()
    if me is not None:
        try:
            me.stop()
        finally:
            App._FlyNavInstance = None
    return None


def debug_keys(on=True, path=None):
    """включить/выключить журнал нажатий клавиш — для диагностики «W молчит»"""
    me = instance()
    if me is None:
        me = FlyNav()
        App._FlyNavInstance = me
    return me.debug_keys(on, path)


def selftest():
    return FlyNav.selftest()
