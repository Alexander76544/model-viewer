# -*- coding: utf-8 -*-
"""FlyNav: консольная часть мода.

Полёт — графический режим, вся логика в FlyNavCore.py, команды в InitGui.py.
Здесь только путь до каталога мода: FreeCAD исполняет Init.py/InitGui.py без __file__,
поэтому определяем каталог по sys.path.
"""

import os
import sys


def mod_path():
    try:
        return os.path.dirname(os.path.abspath(__file__))
    except Exception:
        pass
    for p in sys.path:
        try:
            if os.path.basename(str(p)).lower() == 'flynav' and os.path.isdir(str(p)):
                return str(p)
        except Exception:
            continue
    return ''


MODPATH = mod_path()
if MODPATH and MODPATH not in sys.path:
    sys.path.append(MODPATH)
