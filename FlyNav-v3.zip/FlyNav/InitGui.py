# -*- coding: utf-8 -*-
"""FlyNav — мод/верстак FreeCAD: свободный полёт камеры (WASD) + нулевая точка отсчёта.

Примечание: docstring намеренно обычный, пути в нём без обратных слэшей, чтобы
компиляция не выдавала SyntaxWarning в Report view.

ДВЕ особенности загрузки InitGui.py в FreeCAD 1.x (проверено на 1.1.3; без них мод молча
не появляется ни в панели, ни в переключателе верстаков):

1. Тела функций и тела классов НЕ видят имена, которые этот же файл определил на верхнем
   уровне (файл исполняется с разными globals/locals). Отсюда NameError вида
   «name '_icon' is not defined» / «name 'CmdToggle' is not defined», когда FreeCAD позже
   вызывает GetResources()/IsActive()/Initialize(). Выход: методы пользуются только
   __builtins__, импортами внутри себя, атрибутами self и значениями по умолчанию.
2. Исключение, вылетевшее в C++ во время исполнения InitGui.py, ОБРЫВАЕТ загрузку файла:
   всё, что идёт дальше, уже не выполняется. Выход: каждый шаг обёрнут в try/except.

Журнал загрузки: в %TEMP% файл FlyNav_initgui.log
"""

import os
import sys


def _mod_path():
    try:
        return os.path.dirname(os.path.abspath(__file__))
    except Exception:
        pass
    for p in sys.path:
        try:
            if os.path.basename(str(p)).lower() == 'flynav' and os.path.isdir(str(p)):
                return str(p)
        except Exception:
            continue
    return ''


MODPATH = _mod_path()
if MODPATH and MODPATH not in sys.path:
    sys.path.append(MODPATH)

import FreeCAD as App
import FreeCADGui as Gui
import FlyNavCore                      # noqa: F401  ядро мода должно быть загружено


class _Base(object):
    """помощники команд: только builtins + импорты внутри (глобалы модуля тут недоступны)"""

    @staticmethod
    def _core():
        return __import__('FlyNavCore')

    @staticmethod
    def _gui():
        return __import__('FreeCADGui')

    @staticmethod
    def _app():
        return __import__('FreeCAD')

    @staticmethod
    def _icon(name):
        try:
            import os.path
            core = __import__('FlyNavCore')
            base = os.path.dirname(os.path.abspath(getattr(core, '__file__', '')))
            p = os.path.join(base, 'Resources', 'Icons', name)
            return p if os.path.exists(p) else ''
        except Exception:
            return ''

    @staticmethod
    def _log(msg):
        try:
            import os.path
            import tempfile
            import datetime
            with open(os.path.join(tempfile.gettempdir(), 'FlyNav_initgui.log'), 'a',
                      encoding='utf-8') as fh:
                fh.write('%s %s\n' % (datetime.datetime.now().strftime('%H:%M:%S.%f')[:-3], msg))
        except Exception:
            pass

    def _have_view(self):
        try:
            return self._core().FlyNav._get_view() is not None
        except Exception:
            try:
                return self._gui().activeDocument().activeView() is not None
            except Exception:
                return False


class CmdToggle(_Base):
    ICON = 'flynav.svg'

    def GetResources(self):
        return {'Pixmap': self._icon(self.ICON),
                'MenuText': u'Полёт WASD (вкл/выкл)',
                'ToolTip': u'Свободный полёт камеры: WASD/QE — движение, мышь при удержанной ПКМ '
                           u'— обзор, N — нулевая точка, Esc — выход. Клавиатуру мод захватывает '
                           u'сам, кликать по 3D-виду не нужно. Ctrl+Shift+F',
                'Accel': 'Ctrl+Shift+F'}

    def IsActive(self):
        return self._have_view()

    def Activated(self):
        try:
            self._core().toggle()
        except Exception:
            import traceback
            self._app().Console.PrintError(u'FlyNav: ' + traceback.format_exc(6))


class CmdZero(_Base):
    ICON = 'flynav-zero.svg'

    def GetResources(self):
        return {'Pixmap': self._icon(self.ICON),
                'MenuText': u'Ноль отсчёта под курсором',
                'ToolTip': u'Сделать точку под курсором нулём координат (то же, что N в полёте).'}

    def IsActive(self):
        return self._have_view()

    def Activated(self):
        try:
            core = self._core()
            me = core.instance()
            if me is None or not me.active:
                me = core.toggle()
            if me is not None:
                me.set_zero(at_camera=False)
        except Exception:
            import traceback
            self._app().Console.PrintError(u'FlyNav: ' + traceback.format_exc(6))


class CmdClearZero(_Base):
    ICON = 'flynav-zero.svg'

    def GetResources(self):
        return {'Pixmap': self._icon(self.ICON),
                'MenuText': u'Снять ноль отсчёта',
                'ToolTip': u'Вернуть отсчёт координат от глобального нуля (то же, что X в полёте).'}

    def IsActive(self):
        try:
            return self._core().instance() is not None
        except Exception:
            return False

    def Activated(self):
        try:
            me = self._core().instance()
            if me is not None:
                me.clear_zero()
        except Exception:
            pass


class CmdKeysLog(_Base):
    ICON = 'flynav-log.svg'

    def GetResources(self):
        return {'Pixmap': self._icon(self.ICON),
                'MenuText': u'Журнал нажатий клавиш (диагностика)',
                'ToolTip': u'Писать каждое дошедшее нажатие в %TEMP%\\FlyNav_keys.log. Если WASD '
                           u'не реагируют: пусто в журнале — клавиши не долетают до мода.'}

    def IsActive(self):
        return True

    def Activated(self):
        try:
            core = self._core()
            me = core.instance()
            on = not (me is not None and getattr(me, 'journal', None) is not None)
            info = core.debug_keys(on)
            self._app().Console.PrintMessage(u'FlyNav: %s\n' % (info,))
        except Exception:
            pass


_COMMANDS = ('FlyNav_Toggle', 'FlyNav_Zero', 'FlyNav_ClearZero', 'FlyNav_KeysLog')
_SPECS = (('FlyNav_Toggle', CmdToggle), ('FlyNav_Zero', CmdZero),
          ('FlyNav_ClearZero', CmdClearZero), ('FlyNav_KeysLog', CmdKeysLog))


class FlyNavWorkbench(getattr(__import__('FreeCADGui'), 'Workbench', object)):
    MenuText = u'FlyNav'
    ToolTip = u'Свободный полёт камеры (WASD) + нулевая точка отсчёта координат'
    # только литералы: имена верхнего уровня этого файла здесь недоступны
    CMDS = ('FlyNav_Toggle', 'FlyNav_Zero', 'FlyNav_ClearZero', 'FlyNav_KeysLog')
    ICON = 'flynav.svg'

    def _icon_path(self):
        try:
            import os.path
            core = __import__('FlyNavCore')
            base = os.path.dirname(os.path.abspath(getattr(core, '__file__', '')))
            p = os.path.join(base, 'Resources', 'Icons', self.ICON)
            return p if os.path.exists(p) else ''
        except Exception:
            return ''

    @staticmethod
    def _log(msg):
        try:
            import os.path
            import tempfile
            import datetime
            with open(os.path.join(tempfile.gettempdir(), 'FlyNav_initgui.log'), 'a',
                      encoding='utf-8') as fh:
                fh.write('%s %s\n' % (datetime.datetime.now().strftime('%H:%M:%S.%f')[:-3], msg))
        except Exception:
            pass

    def _set_icon(self, value):
        pass                                 # FreeCAD иногда пытается записать Icon обратно

    Icon = property(lambda self: self._icon_path(), _set_icon)

    def Initialize(self):
        try:
            cmds = list(self.CMDS)
            self.appendToolbar(u'FlyNav', cmds)
            self.appendMenu(u'FlyNav', cmds)
            self._log(u'Initialize верстака: панель и меню добавлены')
        except Exception:
            import traceback
            self._log(u'Initialize верстака УПАЛ: ' + traceback.format_exc(6))

    def Activated(self):
        pass

    def Deactivated(self):
        pass

    def GetClassName(self):
        return 'Gui::PythonWorkbench'


_MENU_SPEC = ((u'Полёт WASD — включить/выключить', 'FlyNav_Toggle'),
              (u'Ноль отсчёта под курсором', 'FlyNav_Zero'),
              (u'Снять ноль отсчёта', 'FlyNav_ClearZero'),
              (None, None),
              (u'Журнал нажатий клавиш (диагностика)', 'FlyNav_KeysLog'))
_MENU_KEEP = []


def _install_menu(_spec=_MENU_SPEC, _keep=_MENU_KEEP, _log=_Base._log):
    """постоянное меню в строке меню: панель верстака FreeCAD показывает только когда верстак
    активен, а в 1.1 новый верстак ещё и не всегда попадает в переключатель"""
    try:
        try:
            from PySide6 import QtWidgets
        except Exception:
            from PySide2 import QtWidgets
        Gui = __import__('FreeCADGui')
        mw = Gui.getMainWindow()
        if mw is None:
            _log(u'B меню: нет главного окна')
            return False
        mb = mw.menuBar()
        for a in mb.actions():
            if str(a.text()).replace('&', '') == 'FlyNav':
                return True
        m = QtWidgets.QMenu(u'Fly&Nav', mb)
        for label, cmd in _spec:
            if label is None:
                m.addSeparator()
                continue
            act = m.addAction(label)
            act.triggered.connect(lambda _=False, c=cmd: __import__('FreeCADGui').runCommand(c))
        mb.addMenu(m)
        _keep.append(m)
        _log(u'B меню FlyNav добавлено в строку меню')
        return True
    except Exception as e:
        _log(u'B меню не добавился: %r' % (e,))
        return False


def _status_hint():
    try:
        mw = __import__('FreeCADGui').getMainWindow()
        if mw is not None:
            mw.statusBar().showMessage(
                u'FlyNav: меню «FlyNav» в строке меню · Ctrl+Shift+F — полёт WASD', 20000)
    except Exception:
        pass


def _check(tag, _log=_Base._log):
    try:
        Gui = __import__('FreeCADGui')
        cmds = [c for c in Gui.listCommands() if str(c).startswith('FlyNav')]
        wbs = [w for w in Gui.listWorkbenches() if 'Fly' in w]
    except Exception as e:
        cmds, wbs = ['err %r' % e], []
    _log(u'%s: команды=%s верстаки=%s' % (tag, cmds, wbs))
    return cmds, wbs


# инстанс верстака создаём заранее: отложенные функции не видят модульные имена
try:
    _WB_INSTANCE = FlyNavWorkbench()
except Exception as _e:
    _WB_INSTANCE = None
    _log(u'создание верстака УПАЛО %r' % (_e,))


def _fix_after_start(_specs=_SPECS, _wb=_WB_INSTANCE, _log=_Base._log,
                   _inst=_install_menu, _hint=_status_hint, _chk=_check):
    """страховка: если стартовая регистрация не принялась — досоздать после старта"""
    try:
        Gui = __import__('FreeCADGui')
        cmds, wbs = _chk(u'C отложенная проверка')
        for name, cls in _specs:
            if name not in cmds:
                try:
                    Gui.addCommand(name, cls())
                    _log(u'C досоздана команда ' + name)
                except Exception as e:
                    _log(u'C досоздание %s УПАЛО %r' % (name, e))
        if not wbs and _wb is not None:
            try:
                Gui.addWorkbench(_wb)
                _log(u'C досоздан верстак')
            except Exception as e:
                _log(u'C досоздание верстака УПАЛО %r' % (e,))
        _inst()
        _hint()
        _chk(u'C после досоздания')
    except Exception as e:
        _log(u'C _fix_after_start УПАЛ: %r' % (e,))


# --------------------------------------------------------------------------- регистрация
_Base._log(u'A0 старт InitGui, MODPATH=%r' % (MODPATH,))

for _name, _cls in _SPECS:
    try:
        Gui.addCommand(_name, _cls())
        _Base._log(u'A1 addCommand %s ok' % _name)
    except Exception as _e:
        _Base._log(u'A1 addCommand %s УПАЛ %r' % (_name, _e))

try:
    if _WB_INSTANCE is not None:
        Gui.addWorkbench(_WB_INSTANCE)
        _Base._log(u'A2 addWorkbench ok')
except Exception as _e:
    _Base._log(u'A2 addWorkbench УПАЛ %r' % (_e,))

_install_menu()
_check(u'A3 сразу после регистрации')

try:
    App.Console.PrintMessage(u'FlyNav: мод загружен · меню «FlyNav» в строке меню · '
                             u'Ctrl+Shift+F — полёт · журнал %TEMP%\\FlyNav_initgui.log\n')
except Exception:
    pass

try:
    try:
        from PySide6 import QtCore
    except Exception:
        from PySide2 import QtCore
    QtCore.QTimer.singleShot(1200, _fix_after_start)
    QtCore.QTimer.singleShot(4000, _install_menu)
    QtCore.QTimer.singleShot(12000, _install_menu)
    _Base._log(u'A4 таймеры поставлены')
except Exception as _e:
    _Base._log(u'A4 таймеры не удались: %r' % (_e,))
