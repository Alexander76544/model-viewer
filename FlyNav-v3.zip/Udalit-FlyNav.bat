@echo off
rem ============================================================
rem  FlyNav uninstaller: removes Mod\FlyNav only.
rem  Restart FreeCAD afterwards. ASCII only (see install bat).
rem ============================================================
chcp 65001 >nul
title FlyNav remove
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-flynav.ps1" -Uninstall
echo.
pause
