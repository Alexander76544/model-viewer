﻿[CmdletBinding()]
param(
    [switch]$Uninstall,
    [string]$ModDir,
    [switch]$Quiet
)

# ============================================================================
#  FlyNav — установщик/удалитель мода для FreeCAD 1.0+ (Windows)
#  Запускать из распакованного архива:  Установить.bat / Удалить.bat
#  Или вручную:  powershell -ExecutionPolicy Bypass -File install-flynav.ps1
#  Указать конкретный каталог:          ... -ModDir "D:\FreeCAD\v1-1"
#  Ничего не скачивает, админ-права не нужны.
# ============================================================================

$ErrorActionPreference = 'Stop'
$script:Errors = 0

function Say($text, $color) {
    if ($Quiet) { return }
    if ($color) { Write-Host $text -ForegroundColor $color } else { Write-Host $text }
}

# ---------------------------------------------------------------- исходники
$srcRoot = $PSScriptRoot
if (-not $srcRoot) { $srcRoot = Split-Path -Parent $MyInvocation.MyCommand.Path }
$src = Join-Path $srcRoot 'FlyNav'
$must = @('Init.py', 'InitGui.py', 'FlyNavCore.py')

if (-not (Test-Path -LiteralPath (Join-Path $src 'InitGui.py'))) {
    Say '' 
    Say "  Не найден каталог FlyNav рядом с этим скриптом." -ForegroundColor Red
    Say "  Архив нужно РАСПАКОВАТЬ целиком (правой кнопкой -> Извлечь всё)," -ForegroundColor Yellow
    Say "  а не запускать из окна проводника внутри zip." -ForegroundColor Yellow
    Say "  Ожидаемая структура: <папка>\FlyNav\InitGui.py и сами файлы .bat" 
    exit 1
}
foreach ($f in $must) {
    if (-not (Test-Path -LiteralPath (Join-Path $src $f))) {
        Say "  Повреждённый пакет: нет файла $f" -ForegroundColor Red
        exit 1
    }
}

# ------------------------------------------------------- где живут конфигурации
$roots = New-Object System.Collections.Generic.List[string]
if ($ModDir) {
    $d = $ModDir.Trim().Trim('"')
    if (Test-Path -LiteralPath $d) { $roots.Add($d) }
    else { Say "  Нет такого каталога: $d" -ForegroundColor Red; exit 1 }
}
else {
    # каталоги конфигурации версий: v1-1, v1-0, v0-21 ... (cache/ и прочее отбрасываем)
    foreach ($base in @($env:APPDATA, $env:LOCALAPPDATA)) {
        if (-not $base) { continue }
        $fc = Join-Path $base 'FreeCAD'
        if (Test-Path -LiteralPath $fc) {
            foreach ($v in (Get-ChildItem -LiteralPath $fc -Directory -ErrorAction SilentlyContinue)) {
                if ($v.Name -notmatch '^v\d') { continue }
                $roots.Add($v.FullName)
            }
        }
    }
    # portable-сборки: <папка FreeCAD>\Data\FreeCAD\v1-1 (рядом с FreeCAD.exe)
    $places = @("$env:USERPROFILE\Downloads", "$env:USERPROFILE", 'C:\', 'D:\', 'E:\', 'F:\',
                'C:\Programs', 'C:\Tools', 'D:\Tools', 'C:\CAD', 'D:\CAD')
    foreach ($pat in $places) {
        if (-not (Test-Path -LiteralPath $pat)) { continue }
        foreach ($cand in (Get-ChildItem -LiteralPath $pat -Directory -Filter 'FreeCAD*' -ErrorAction SilentlyContinue)) {
            $data = Join-Path $cand.FullName 'Data\FreeCAD'
            if (Test-Path -LiteralPath $data) {
                foreach ($v in (Get-ChildItem -LiteralPath $data -Directory -ErrorAction SilentlyContinue)) {
                    $roots.Add($v.FullName)
                }
            }
        }
    }
}
$roots = @($roots | Select-Object -Unique)
if ($roots.Count -eq 0) {
    Say '' 
    Say "  FreeCAD в типовых местах не найден (%APPDATA%\FreeCAD\*)." -ForegroundColor Red
    Say "  Укажи каталог конфигурации вручную (там, где лежит user.cfg):" -ForegroundColor Yellow
    Say "      powershell -ExecutionPolicy Bypass -File install-flynav.ps1 -ModDir `"C:\Users\Ты\AppData\Roaming\FreeCAD\v1-1`"" 
    exit 1
}

$running = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match '^freecad' })
if ($running.Count -gt 0) {
    Say '' 
    Say "  ВНИМАНИЕ: FreeCAD сейчас запущен ($($running.Count) процесс)." -ForegroundColor Yellow
    Say "  Мод применяется при ЗАПУСКЕ, поэтому после установки FreeCAD нужно закрыть и открыть снова." -ForegroundColor Yellow
    Say "  (Файлы сейчас перезапишутся — это безопасно.)" 
}

# ------------------------------------------------------------------ установка
Say '' 
Say '  FlyNav — свободный полёт в 3D-виде FreeCAD (WASD + мышь)' -ForegroundColor Cyan
Say '  -------------------------------------------------------' 

foreach ($r in $roots) {
    $dst = Join-Path (Join-Path $r 'Mod') 'FlyNav'
    if ($Uninstall) {
        if (Test-Path -LiteralPath $dst) {
            Remove-Item -LiteralPath $dst -Recurse -Force -ErrorAction SilentlyContinue
            if (Test-Path -LiteralPath $dst) {
                Say "  [FAIL] не удалось удалить: $dst" -ForegroundColor Red
                $script:Errors++
            }
            else { Say "  удалён  $dst" -ForegroundColor Green }
        }
        else { Say "  не был установлен: $dst" }
        continue
    }

    try {
        $modParent = Split-Path -Parent $dst
        if (-not (Test-Path -LiteralPath $modParent)) {
            New-Item -ItemType Directory -Path $modParent -Force | Out-Null
        }
        if (Test-Path -LiteralPath $dst) {
            Remove-Item -LiteralPath $dst -Recurse -Force -ErrorAction Stop   # чистая замена, без старого __pycache__
        }
        Copy-Item -LiteralPath $src -Destination $dst -Recurse -Force
        Remove-Item -LiteralPath (Join-Path $dst '__pycache__') -Recurse -Force -ErrorAction SilentlyContinue
    }
    catch {
        Say "  [FAIL] $dst — $($_.Exception.Message)" -ForegroundColor Red
        $script:Errors++
        continue
    }

    # проверка: те же файлы, те же размеры
    $n = 0
    $miss = @()
    foreach ($f in (Get-ChildItem -LiteralPath $src -Recurse -File)) {
        $rel = $f.FullName.Substring($src.Length + 1)
        $target = Join-Path $dst $rel
        if (-not (Test-Path -LiteralPath $target)) { $miss += $rel; continue }
        if ((Get-Item -LiteralPath $target).Length -ne $f.Length) { $miss += "$rel (размер)" ; continue }
        $n++
    }
    if ($miss.Count -gt 0) {
        Say "  [FAIL] $dst — расхождение: $($miss -join ', ')" -ForegroundColor Red
        $script:Errors++
    }
    else {
        Say "  установлен  $dst   ($n файл(ов))" -ForegroundColor Green
        $ini = Join-Path $dst 'InitGui.py'
        Say "            InitGui.py: $(if (Test-Path -LiteralPath $ini) {'на месте'} else {'НЕТ!'})"
    }
}

if ($Uninstall) {
    Say '' 
    Say "  Готово. Перезапусти FreeCAD, чтобы мод исчез из меню и верстаков." -ForegroundColor Cyan
    exit $(if ($script:Errors) { 2 } else { 0 })
}

Say '' 
Say '  Дальше:' -ForegroundColor Cyan
Say '    1) закрой FreeCAD и открой снова (моды читаются только при запуске);'
Say '    2) в строке меню появится  FlyNav  (и кнопка FlyNav, если открыть верстак FlyNav);'
Say '    3) клавиатура: Ctrl+Shift+F  — включить/выключить полёт,  Esc  — выход.'
Say '    4) если верстака нет в переключателе:  Правка -> Настройки -> Workbenches -> включить FlyNav.'
Say '' 
Say "  Полный список клавиш и решение проблем — в README.txt из этого архива." -ForegroundColor DarkGray
if ($script:Errors -gt 0) {
    Say '' 
    Say "  Есть ошибки ($($script:Errors)). См. строки [FAIL] выше." -ForegroundColor Red
    exit 2
}
exit 0
