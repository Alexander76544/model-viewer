// ============================================================
//  Подпольный ЯМЗ — «босс-режим» 3.0 (общий модуль паники)
//
//  Экстренный экран: игра и все её окна скрываются, остаётся
//  настоящая книга Excel, ЗАПОЛНЕННАЯ правдоподобным рабочим
//  отчётом (отгрузки за месяц с формулами) — не пустой лист.
//
//  Горячие клавиши (работают всегда, даже при вводе в чат):
//    Esc            — скрыть / показать игру
//    ` (клавиша Ё)  — скрыть / показать игру
//    Shift два раза быстро — мгновенно скрыть
//  Автоскрытие: ушли на другое окно / вкладку (Alt+Tab, клик
//  мимо браузера) — игра прячется сама. Вкл/выкл — переключатель
//  «Автосохранение» в заголовке книги (маскировка под Excel).
//  Игра продолжает работать в фоне, соединение не рвётся.
//
//  API: window.YAMZ_PANIC = { show, hide, toggle, isOn, setAuto, getAuto }
// ============================================================
(function () {
  'use strict';
  if (window.YAMZ_PANIC) return;

  let on = false;
  const AKEY = 'yz_autohide';
  let auto = (function () { try { return localStorage.getItem(AKEY) !== '0'; } catch (_) { return true; } })();

  // ---------- стили ----------
  const style = document.createElement('style');
  style.textContent = `
body.yzp-on #yg-layer > *{display:none !important;}
body.yzp-on .ow-main > :not(.ow-grid){visibility:hidden !important;}
#yz-panic-fallback{position:fixed; inset:0; z-index:1000; background:#f2f2f2; display:none;}
/* переключатель «Автосохранение» в заголовке (как в Excel 365) */
#yz-auto{display:inline-flex; align-items:center; gap:6px; margin-left:10px; font:12px 'Segoe UI',system-ui,sans-serif;
  color:#fff; cursor:pointer; user-select:none; opacity:.95; white-space:nowrap;}
#yz-auto .sw{position:relative; width:30px; height:14px; border:1px solid #fff; border-radius:8px; box-sizing:border-box;}
#yz-auto .sw::after{content:''; position:absolute; top:2px; left:2px; width:8px; height:8px; border-radius:50%; background:#fff; transition:left .12s;}
#yz-auto.on .sw{background:rgba(255,255,255,.25);}
#yz-auto.on .sw::after{left:18px;}`;
  document.head.appendChild(style);

  const fallback = document.createElement('div');
  fallback.id = 'yz-panic-fallback';
  (document.body || document.documentElement).appendChild(fallback);

  // ---------- правдоподобный рабочий отчёт для листа ----------
  function reportData() {
    const firms = ['ООО «Техснаб»', 'АО «Волгаметалл»', 'ООО «Промресурс»', 'ПАО «Автодизель»', 'ООО «СеверТорг»', 'АО «УралКомплект»', 'ООО «Регион-Деталь»'];
    const items = ['Втулка 236-1002', 'Прокладка ГБЦ 238', 'Вал коленчатый 7511', 'Шестерня 236-1029', 'Фильтр топливный', 'Кронштейн 6522', 'Поршень 240-1004', 'Гильза цилиндра', 'Насос водяной 236'];
    const rows = [['Отчёт по отгрузкам продукции за сентябрь'], [],
      ['Дата', '№ накладной', 'Контрагент', 'Номенклатура', 'Кол-во, шт', 'Цена, руб', 'Сумма, руб', 'НДС 20%', 'Статус']];
    let seed = 7;
    const rnd = n => { seed = (seed * 9301 + 49297) % 233280; return Math.floor(seed / 233280 * n); };
    const st = ['Отгружено', 'Отгружено', 'Оплачено', 'В пути', 'Отгружено'];
    for (let i = 0; i < 24; i++) {
      const r = rows.length + 1;
      const d = "'" + String(2 + Math.floor(i * 1.2)).padStart(2, '0') + '.09.2025';
      rows.push([d, 'ТН-' + (4120 + i * 3 + rnd(3)), firms[rnd(firms.length)], items[rnd(items.length)],
        10 * (1 + rnd(40)), 150 + rnd(90) * 25, `=E${r}*F${r}`, `=ROUND(G${r}*0.2,2)`, st[rnd(st.length)]]);
    }
    const last = rows.length;
    rows.push([], ['Итого', '', '', '', `=SUM(E4:E${last})`, '', `=SUM(G4:G${last})`, `=SUM(H4:H${last})`],
      ['Средний чек', '', '', '', '', '', `=ROUND(AVERAGE(G4:G${last}),2)`]);
    return rows;
  }
  const hasSheet = () => { try { return typeof hf !== 'undefined' && typeof build === 'function'; } catch (_) { return false; } };
  let savedSheet = null, savedCw, savedMg, savedSt, savedId = null, backSid = null;
  // свой импортированный документ — лучшая маскировка: показываем его, отчёт не нужен
  //  (только если включена кнопка «📄 Обложка — мой файл»)
  function importedSid() { try { const C = window.YZ_COVER; if (!C || !C.isOn()) return null; for (const n of C.sheets || []) if (hf.doesSheetExist(n)) return hf.getSheetId(n); } catch (_) {} return null; }
  function fillSheet() {
    if (!hasSheet()) return;
    try {
      const imp = importedSid();
      if (imp != null) {
        if (sid !== imp) { backSid = sid; sid = imp; home(); tabs(); build(); }
        return;
      }
      if (window.YZ_IMPORTED && window.YZ_IMPORTED.length) { /* импорт удалён — обычный отчёт */ }
      savedId = sid;
      savedSheet = hf.getSheetSerialized(sid);
      savedCw = cw[sid];
      // объединения и оформление листа (вид «Ячейки») — на время отчёта убрать
      try { savedMg = mgs[sid]; mgs[sid] = []; } catch (_) {}
      savedSt = st[sid]; st[sid] = {};
      hf.setSheetContent(sid, reportData());
      cw[sid] = { 0: 84, 1: 84, 2: 150, 3: 150, 4: 80, 5: 80, 6: 96, 7: 84, 8: 90 };
      build();
    } catch (_) {}
  }
  function restoreSheet() {
    if (!hasSheet()) return;
    if (backSid != null) {
      try { if (hf.getSheetName(backSid) != null) { sid = backSid; home(); tabs(); build(); } } catch (_) {}
      backSid = null;
    }
    if (!savedSheet) return;
    try {
      const id = savedId != null ? savedId : sid;
      hf.setSheetContent(id, savedSheet); cw[id] = savedCw; st[id] = savedSt || {};
      try { mgs[id] = savedMg || []; } catch (_) {}
      if (sid !== id) { sid = id; home(); tabs(); }
      build();
    } catch (_) {}
    savedSheet = null; savedId = null;
  }

  function show() {
    if (on) return;
    on = true;
    // фокус из чата/полей игры — чтобы набранный текст не ушёл в игру
    try { if (document.activeElement && document.activeElement !== document.body) document.activeElement.blur(); } catch (_) {}
    window.YG_FOCUS = false;
    try { if (window.YZ_CELLS && window.YZ_CELLS.onPanic) window.YZ_CELLS.onPanic(true); } catch (_) {}
    document.body.classList.add('yzp-on');
    if (!document.getElementById('yg-layer') && !document.querySelector('.ow-main')) fallback.style.display = 'block';
    fillSheet();
    startSim();
  }
  function hide() {
    if (!on) return;
    on = false;
    stopSim();
    document.body.classList.remove('yzp-on');
    fallback.style.display = 'none';
    restoreSheet();
    if (window.YZ_CELLS) window.YZ_CELLS.force();
  }
  function toggle() { if (on) hide(); else show(); }

  // ---------- «✍ Имитация работы» (по кнопке): пока игра спрятана, в книге
  //  сам ходит курсор, выделяются диапазоны и «печатаются» значения ----------
  const FKEY = 'yz_fakework';
  let fake = (function () { try { return localStorage.getItem(FKEY) === '1'; } catch (_) { return false; } })();
  let simT = 0, simPause = 0, typing = null;
  const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  function simArea() {
    try {
      let h = 0, w = 0;
      hf.getSheetSerialized(sid).forEach((row, r) => (row || []).forEach((v, c) => { if (v != null && v !== '') { h = Math.max(h, r + 1); w = Math.max(w, c + 1); } }));
      return { h: Math.max(3, Math.min(h, NR)), w: Math.max(2, Math.min(w, NC)) };
    } catch (_) { return { h: 20, w: 6 }; }
  }
  function cancelTyping() { if (typing) { clearInterval(typing.t); typing = null; try { if (editing) stopEdit(); } catch (_) {} } }
  function simStep() {
    simT = 0;
    if (!on || !fake || !hasSheet()) return;
    if (Date.now() < simPause || typing) { simT = setTimeout(simStep, 1500); return; }
    try {
      const A = simArea(), k = Math.random();
      if (k < 0.5) {                                   // курсор: пара шагов как стрелками
        const dr = rnd(-1, 2), dc = rnd(-1, 1);
        act = { r: Math.max(1, Math.min(A.h - 1, Math.min(act.r, A.h - 1) + dr)), c: Math.max(0, Math.min(A.w - 1, Math.min(act.c, A.w - 1) + dc)) }; end = { r: act.r, c: act.c };
        sync();
      } else if (k < 0.72) {                           // выделение диапазона (как мышью)
        act = { r: rnd(1, Math.max(1, A.h - 2)), c: rnd(0, Math.max(0, A.w - 2)) };
        end = { r: Math.min(A.h - 1, act.r + rnd(1, 4)), c: Math.min(A.w - 1, act.c + rnd(0, 2)) };
        sync();
      } else {                                         // «печатает» значение в ячейку
        act = { r: rnd(1, Math.max(1, A.h - 1)), c: rnd(0, A.w - 1) }; end = { r: act.r, c: act.c };
        sync();
        const v = hf.getCellValue({ sheet: sid, row: act.r, col: act.c });
        if (v != null && typeof v === 'object') { simT = setTimeout(simStep, 900); return; }
        const own = !savedSheet;                       // свой документ — только «печатаем», не сохраняем
        const words = ['сверено', 'в работе', 'ок', 'уточнить', 'отгружено', 'см. примечание'];
        const txt = typeof v === 'number' ? String(Math.max(0, Math.round(v * (0.9 + Math.random() * 0.2) * 100) / 100)).replace('.', ',') : words[rnd(0, words.length - 1)];
        edit('');
        let i = 0;
        typing = { t: setInterval(() => {
          if (!on || !editing) { cancelTyping(); return; }
          i++; ed.value = txt.slice(0, i); fb.value = ed.value;
          if (i >= txt.length) {
            clearInterval(typing.t);
            setTimeout(() => {
              typing = null;
              if (!on || !editing) return;
              if (own) stopEdit(); else { ed.value = ed.value.replace(',', '.'); commit(); }
              try { document.activeElement && document.activeElement.blur(); } catch (_) {}
            }, rnd(300, 900));
          }
        }, rnd(110, 220)) };
      }
    } catch (_) {}
    simT = setTimeout(simStep, rnd(1300, 3600));
  }
  function startSim() { stopSim(); if (fake) simT = setTimeout(simStep, 1200); }
  function stopSim() { clearTimeout(simT); simT = 0; cancelTyping(); }
  // настоящий пользователь трогает мышь/клавиатуру — имитация замирает
  ['mousedown', 'keydown', 'wheel'].forEach(ev => document.addEventListener(ev, e => {
    if (!on || !e.isTrusted) return;
    simPause = Date.now() + 8000;
    if (typing && !(ev === 'keydown' && e.key === 'Escape')) cancelTyping();
  }, true));
  function setFake(v) { fake = !!v; try { localStorage.setItem(FKEY, fake ? '1' : '0'); } catch (_) {} syncAuto(); if (on) startSim(); }

  // ---------- горячие клавиши ----------
  let lastShift = 0;
  // Esc — на document (всплытие): мост yg-bridge сначала закрывает «Печать»/дизайн
  document.addEventListener('keydown', e => { if (e.key === 'Escape') toggle(); });
  // Ё и двойной Shift — на window (перехват раньше всех, даже раньше ячеек Excel)
  window.addEventListener('keydown', e => {
    if (e.code === 'Backquote' && !e.ctrlKey && !e.altKey && !e.metaKey) {
      e.preventDefault(); e.stopImmediatePropagation();
      toggle();
      return;
    }
    if (e.key === 'Shift' && !e.repeat) {
      const t = Date.now();
      if (t - lastShift < 350) { show(); lastShift = 0; } else lastShift = t;
    } else lastShift = 0;
  }, true);

  // ---------- автоскрытие при уходе из окна ----------
  //  окно выбора файла / цвета (импорт, заливка) уводит фокус — это не «ушёл из окна»
  let dlg = false, dlgT = 0;
  const dlgOpen = () => { dlg = true; clearTimeout(dlgT); dlgT = setTimeout(() => { dlg = false; }, 120000); };
  const dlgClose = () => { clearTimeout(dlgT); dlgT = setTimeout(() => { dlg = false; }, 400); };
  document.addEventListener('click', e => {
    const t = e.target;
    if (t && t.closest && (t.closest('input[type=file],input[type=color]') || (t.closest('label') && t.closest('label').querySelector('input[type=file],input[type=color]')))) dlgOpen();
  }, true);
  document.addEventListener('change', e => { if (e.target && /^(file|color)$/.test(e.target.type || '')) dlgClose(); }, true);
  window.addEventListener('focus', () => { if (dlg) dlgClose(); });
  window.addEventListener('blur', () => { if (auto && !dlg) show(); });
  document.addEventListener('visibilitychange', () => { if (auto && document.hidden && !dlg) show(); });

  // ---------- переключатель «Автосохранение» в заголовке ----------
  function mountAuto() {
    const tt = document.getElementById('tt');
    if (!tt || document.getElementById('yz-auto')) return;
    const sw = document.createElement('span');
    sw.id = 'yz-auto';
    sw.title = 'Автосохранение';
    sw.innerHTML = '<span>Автосохранение</span><span class="sw"></span>';
    const ttl = document.getElementById('ttl');
    if (ttl && ttl.parentNode === tt) tt.insertBefore(sw, ttl); else tt.appendChild(sw);
    sw.addEventListener('click', () => setAuto(!auto));
    // отдельная понятная кнопка: строка состояния + Рецензирование / Разработчик
    const mk = () => { const b = document.createElement('button'); b.type = 'button'; b.className = 'yz-ahb'; b.onclick = () => setAuto(!auto); return b; };
    const stb = document.getElementById('stb');
    if (stb) { const b = mk(); b.style.cssText = 'margin-left:10px;font-size:12px;padding:1px 8px;'; stb.appendChild(b); }
    ['p-rev', 'p-dev'].forEach(id => {
      const pn = document.getElementById(id); if (!pn) return;
      const g = document.createElement('div'); g.className = 'g';
      g.className = 'g yz-mask';
      g.innerHTML = '<div class="gb"><div class="rw"></div></div><div class="gl">Маскировка</div>';
      g.querySelector('.rw').appendChild(mk());
      const fb2 = document.createElement('button'); fb2.type = 'button'; fb2.className = 'yz-fwb'; fb2.onclick = () => setFake(!fake);
      g.querySelector('.rw').appendChild(fb2);
      pn.appendChild(g);
    });
    syncAuto();
  }
  function syncAuto() {
    const sw = document.getElementById('yz-auto'); if (sw) sw.classList.toggle('on', auto);
    document.querySelectorAll('.yz-ahb').forEach(b => {
      b.textContent = auto ? '🛡 Автоскрытие: ВКЛ' : '🛡 Автоскрытие: ВЫКЛ';
      b.title = auto ? 'Сейчас: ушли в другое окно/вкладку — игра сама прячется под отчёт. Нажмите, чтобы выключить'
        : 'Сейчас: игра НЕ прячется сама при переключении окна (Esc / Ё — прятать вручную). Нажмите, чтобы включить';
      b.style.background = auto ? '' : '#fff2cc';
    });
    document.querySelectorAll('.yz-fwb').forEach(b => {
      b.textContent = fake ? '✍ Имитация работы: ВКЛ' : '✍ Имитация работы: ВЫКЛ';
      b.title = 'Пока игра спрятана, в книге сам ходит курсор, выделяются ячейки и «печатаются» значения (свой файл не меняется). Нажмите, чтобы ' + (fake ? 'выключить' : 'включить');
      b.style.background = fake ? '#e2efda' : '';
    });
  }
  function setAuto(v) { auto = !!v; try { localStorage.setItem(AKEY, auto ? '1' : '0'); } catch (_) {} syncAuto(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mountAuto); else mountAuto();

  window.YAMZ_PANIC = {
    show, hide, toggle,
    isOn: () => on,
    setAuto, getAuto: () => auto,
    setFake, getFake: () => fake,
    setMode: () => {}, getMode: () => 'excel-report',
  };
})();
