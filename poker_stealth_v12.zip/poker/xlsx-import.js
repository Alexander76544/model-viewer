// ============================================================
//  xlsx-import.js — «нормальный» импорт настоящего файла Excel (.xlsx/.xlsm)
//  Переносит: все листы, значения, формулы (в т.ч. общие), шрифты (название,
//  размер, Ж/К/Ч/зачёркнутый, цвет), заливку, границы (тип, толщина, цвет),
//  выравнивание (гориз./верт., перенос, отступ, вертикальный текст),
//  форматы чисел, ширину столбцов, высоту строк, объединения, закрепление,
//  сетку, цвет ярлыков листов, примечания, имена, активный лист.
//  .xls/.ods/.csv — через SheetJS (значения, формулы, ширины, высоты,
//  объединения, заливка).
// ============================================================
(function () {
  'use strict';
  if (typeof load !== 'function' || typeof imp !== 'function') return;

  // ---------- ZIP ----------
  async function unzip(buf) {
    const u8 = new Uint8Array(buf), dv = new DataView(buf), E = {};
    let i = u8.length - 22;
    while (i >= 0 && dv.getUint32(i, true) !== 0x06054b50) i--;
    if (i < 0) throw new Error('это не файл xlsx (zip)');
    let p = dv.getUint32(i + 16, true);
    const n = dv.getUint16(i + 10, true), td = new TextDecoder('utf-8');
    for (let k = 0; k < n && dv.getUint32(p, true) === 0x02014b50; k++) {
      const method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true),
        nl = dv.getUint16(p + 28, true), el = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true),
        lho = dv.getUint32(p + 42, true);
      const name = td.decode(u8.subarray(p + 46, p + 46 + nl)).replace(/^\/+/, '');
      E[name.toLowerCase()] = { name, method, csize, lho };
      p += 46 + nl + el + cl;
    }
    const cache = {};
    async function raw(name) {
      const e = E[String(name).replace(/^\/+/, '').toLowerCase()];
      if (!e) return null;
      const s = e.lho + 30 + dv.getUint16(e.lho + 26, true) + dv.getUint16(e.lho + 28, true);
      const d = u8.subarray(s, s + e.csize);
      if (e.method === 0) return d;
      if (e.method !== 8) throw new Error('неизвестное сжатие в файле');
      const ds = new Blob([d]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
      return new Uint8Array(await new Response(ds).arrayBuffer());
    }
    return {
      has: n => !!E[String(n).replace(/^\/+/, '').toLowerCase()],
      async text(n) { if (n in cache) return cache[n]; const b = await raw(n); return (cache[n] = b ? td.decode(b) : null); },
    };
  }

  // ---------- XML ----------
  const parseX = s => s ? new DOMParser().parseFromString(s, 'application/xml') : null;
  const all = (el, n) => el ? Array.from(el.getElementsByTagNameNS('*', n)) : [];
  const one = (el, n) => el ? el.getElementsByTagNameNS('*', n)[0] || null : null;
  const kids = (el, n) => el ? Array.from(el.children).filter(x => x.localName === n) : [];
  const kid = (el, n) => kids(el, n)[0] || null;
  const at = (el, n) => el ? el.getAttribute(n) : null;
  const rid = el => el ? (el.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'id') || el.getAttribute('r:id')) : null;
  const tv = el => el ? el.textContent : '';
  const bool = (el, n, d) => { const v = at(el, n); return v == null ? d : !(v === '0' || v === 'false'); };
  function resolve(base, t) {
    if (t[0] === '/') return t.slice(1);
    const p = base.split('/'); p.pop();
    t.split('/').forEach(s => { if (s === '..') p.pop(); else if (s !== '.') p.push(s); });
    return p.join('/');
  }
  async function rels(z, part) {
    const i = part.lastIndexOf('/'), rp = part.slice(0, i + 1) + '_rels/' + part.slice(i + 1) + '.rels';
    const x = parseX(await z.text(rp)), R = {};
    all(x, 'Relationship').forEach(r => { R[at(r, 'Id')] = { type: at(r, 'Type') || '', target: at(r, 'TargetMode') === 'External' ? at(r, 'Target') : resolve(part, at(r, 'Target')) }; });
    return R;
  }

  // ---------- цвета ----------
  const IDX = '000000 FFFFFF FF0000 00FF00 0000FF FFFF00 FF00FF 00FFFF 000000 FFFFFF FF0000 00FF00 0000FF FFFF00 FF00FF 00FFFF 800000 008000 000080 808000 800080 008080 C0C0C0 808080 9999FF 993366 FFFFCC CCFFFF 660066 FF8080 0066CC CCCCFF 000080 FF00FF FFFF00 00FFFF 800080 800000 008080 0000FF 00CCFF CCFFFF CCFFCC FFFF99 99CCFF FF99CC CC99FF FFCC99 3366FF 33CCCC 99CC00 FFCC00 FF9900 FF6600 666699 969696 003366 339966 003300 333300 993300 993366 333399 333333'.split(' ');
  function tint(hex, t) {
    let r = parseInt(hex.slice(0, 2), 16) / 255, g = parseInt(hex.slice(2, 4), 16) / 255, b = parseInt(hex.slice(4, 6), 16) / 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b); let h = 0, s = 0, l = (mx + mn) / 2;
    if (mx !== mn) { const d = mx - mn; s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6; }
    l = t < 0 ? l * (1 + t) : l * (1 - t) + t;
    const f = (p, q, x) => { if (x < 0) x += 1; if (x > 1) x -= 1; return x < 1 / 6 ? p + (q - p) * 6 * x : x < 1 / 2 ? q : x < 2 / 3 ? p + (q - p) * (2 / 3 - x) * 6 : p; };
    if (s === 0) r = g = b = l; else { const q = l < .5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q; r = f(p, q, h + 1 / 3); g = f(p, q, h); b = f(p, q, h - 1 / 3); }
    return [r, g, b].map(v => Math.round(v * 255).toString(16).padStart(2, '0')).join('').toUpperCase();
  }
  function colorOf(el, ctx, auto) {
    if (!el) return null;
    let hex = null;
    if (at(el, 'rgb')) hex = at(el, 'rgb').slice(-6);
    else if (at(el, 'theme') != null) hex = ctx.theme[+at(el, 'theme')] || null;
    else if (at(el, 'indexed') != null) { const i = +at(el, 'indexed'); hex = (ctx.idx[i] || (i === 64 ? '000000' : i === 65 ? 'FFFFFF' : null)); if (i === 64 && auto) return null; }
    else if (bool(el, 'auto', false)) return null;
    if (!hex) return null;
    const t = parseFloat(at(el, 'tint') || '0');
    if (t) hex = tint(hex, t);
    return '#' + hex.toLowerCase();
  }

  // ---------- форматы чисел ----------
  const BUILTIN = { 1: '0', 2: '0.00', 3: '#,##0', 4: '#,##0.00', 9: '0%', 10: '0.00%', 14: 'dd.mm.yyyy', 15: 'd-mmm-yy', 16: 'd-mmm', 17: 'mmm-yy', 22: 'dd.mm.yyyy h:mm', 37: '#,##0 ;(#,##0)', 38: '#,##0 ;[Red](#,##0)', 39: '#,##0.00;(#,##0.00)', 40: '#,##0.00;[Red](#,##0.00)', 49: '@' };
  for (let k = 5; k <= 8; k++) BUILTIN[k] = '#,##0.00 ₽';
  for (let k = 41; k <= 44; k++) BUILTIN[k] = k % 2 ? '#,##0 ₽' : '#,##0.00 ₽';
  function nfOf(code) {
    if (!code || /^general$/i.test(code) || code === '@') return null;
    const sec = code.split(';')[0];
    const cur = /₽|р\.|руб|\[\$[^\]]*\]|\$|€/i.test(sec);
    const bare = sec.replace(/"[^"]*"/g, '').replace(/\[[^\]]*\]/g, '').replace(/\\./g, '');
    if (/[dy]/i.test(bare) || /m{3,}/i.test(bare) || (/m/i.test(bare) && /[dy]/i.test(bare))) return { nf: 'date' };
    if (/[hs]/i.test(bare) && !/[0#]/.test(bare)) return null;
    const dm = bare.match(/\.([0#?]+)/), dp = dm ? dm[1].length : 0;
    if (/%/.test(bare)) return { nf: 'pct' };
    if (cur) return { nf: 'cur' };
    if (/E\+/i.test(bare)) return null;
    if (dp) return dp === 2 && /,/.test(bare) ? { nf: 'n2' } : { nf: 'dp', dp };
    if (/[0#]/.test(bare)) return { nf: 'int' };
    return null;
  }

  // ---------- стили ----------
  const BST = { thin: '1px solid', hair: '1px dotted', dotted: '1px dotted', dashed: '1px dashed', dashDot: '1px dashed', dashDotDot: '1px dashed', medium: '2px solid', mediumDashed: '2px dashed', mediumDashDot: '2px dashed', mediumDashDotDot: '2px dashed', slantDashDot: '2px dashed', thick: '3px solid', double: '3px double' };
  const qf = n => /^[\w-]+$/.test(n) ? n : '"' + n.replace(/"/g, '') + '"';
  function readStyles(x, ctx) {
    const fmts = Object.assign({}, BUILTIN);
    all(x, 'numFmt').forEach(n => { fmts[+at(n, 'numFmtId')] = at(n, 'formatCode'); });
    const ci = one(x, 'indexedColors');
    if (ci) all(ci, 'rgbColor').forEach((c, i) => { ctx.idx[i] = (at(c, 'rgb') || '').slice(-6); });
    const fonts = kids(one(x, 'fonts'), 'font').map(f => {
      const o = {};
      const nm = kid(f, 'name') || kid(f, 'rFont'); if (nm) o.name = at(nm, 'val');
      const sz = kid(f, 'sz'); if (sz) o.pt = parseFloat(at(sz, 'val'));
      if (kid(f, 'b') && bool(kid(f, 'b'), 'val', true)) o.b = true;
      if (kid(f, 'i') && bool(kid(f, 'i'), 'val', true)) o.i = true;
      const u = kid(f, 'u'); if (u && at(u, 'val') !== 'none') o.u = true;
      if (kid(f, 'strike') && bool(kid(f, 'strike'), 'val', true)) o.k = true;
      o.color = kid(f, 'color');
      return o;
    });
    const fills = kids(one(x, 'fills'), 'fill').map(f => {
      const p = kid(f, 'patternFill');
      if (p) {
        const t = at(p, 'patternType');
        if (!t || t === 'none') return null;
        const fg = kid(p, 'fgColor'), bg = kid(p, 'bgColor');
        return t === 'solid' ? (fg || bg) : (fg || bg);
      }
      const g = kid(f, 'gradientFill');
      if (g) { const s = all(g, 'color'); return s[0] || null; }
      return null;
    });
    const borders = kids(one(x, 'borders'), 'border').map(b => {
      const o = {};
      [['left', 'bl'], ['right', 'br'], ['top', 'bt'], ['bottom', 'bb'], ['start', 'bl'], ['end', 'br']].forEach(([s, k]) => {
        const e = kid(b, s), t = e && at(e, 'style');
        if (t && t !== 'none' && !o[k]) o[k] = { st: BST[t] || '1px solid', c: kid(e, 'color') };
      });
      return o;
    });
    const xfs = kids(one(x, 'cellXfs'), 'xf').map(xf => ({
      numFmt: +(at(xf, 'numFmtId') || 0), font: +(at(xf, 'fontId') || 0), fill: +(at(xf, 'fillId') || 0),
      border: +(at(xf, 'borderId') || 0), al: kid(xf, 'alignment'),
    }));
    return { fmts, fonts, fills, borders, xfs };
  }
  function buildXf(S, ctx) {
    const def = S.fonts[0] || {}, defName = def.name || 'Calibri', defPt = def.pt || 11;
    const memo = {};
    return function (i) {
      i = +i || 0;
      if (memo[i]) return memo[i];
      const x = S.xfs[i] || S.xfs[0]; const o = {};
      if (!x) return (memo[i] = o);
      const f = S.fonts[x.font] || def;
      o.ff = qf(f.name || defName);
      const pt = f.pt || defPt;
      if (Math.abs(pt - 11) > .01) o.sz = Math.round(pt * 13 / 11 * 2) / 2;
      if (f.b) o.b = true; if (f.i) o.i = true; if (f.u) o.u = true; if (f.k) o.k = true;
      const fc = colorOf(f.color, ctx, true); if (fc && fc !== '#000000') o.fg = fc;
      const bg = colorOf(S.fills[x.fill], ctx, false); if (bg) o.bg = bg;
      const B = S.borders[x.border] || {};
      for (const k in B) o[k] = B[k].st + ' ' + (colorOf(B[k].c, ctx, true) || '#000');
      const nf = nfOf(S.fmts[x.numFmt]); if (nf) Object.assign(o, nf);
      if (x.al) {
        const h = at(x.al, 'horizontal'), v = at(x.al, 'vertical');
        if (h && h !== 'general') o.al = { centerContinuous: 'center', distributed: 'justify', fill: 'left' }[h] || h;
        if (v) o.va = { center: 'middle', top: 'top', bottom: 'bottom', justify: 'middle', distributed: 'middle' }[v] || '';
        if (bool(x.al, 'wrapText', false)) o.wr = true;
        const ind = +(at(x.al, 'indent') || 0); if (ind) o.ind = ind;
        if (at(x.al, 'textRotation') === '255') o.or = true;
      }
      if (!o.va) o.va = 'bottom';
      return (memo[i] = o);
    };
  }

  // ---------- адреса и формулы ----------
  const col2n = s => { let n = 0; for (const ch of s.toUpperCase()) n = n * 26 + ch.charCodeAt(0) - 64; return n - 1; };
  const n2col = n => { let s = ''; for (n++; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + (n - 1) % 26) + s; return s; };
  const ref = s => { const m = /^\$?([A-Za-z]+)\$?(\d+)$/.exec(s || ''); return m ? { r: +m[2] - 1, c: col2n(m[1]) } : null; };
  const range = s => { const [a, b] = String(s || '').split(':'); const p = ref(a), q = ref(b || a); return p && q ? { r1: Math.min(p.r, q.r), r2: Math.max(p.r, q.r), c1: Math.min(p.c, q.c), c2: Math.max(p.c, q.c) } : null; };
  function shiftF(f, dr, dc) {
    if (!dr && !dc) return f;
    return f.split(/("(?:[^"]|"")*")/).map((part, i) => i % 2 ? part : part.replace(/(^|[^A-Za-z0-9_.])(\$?)([A-Za-z]{1,3})(\$?)(\d+)(?![\d(A-Za-z_])/g,
      (m, pre, d1, cl, d2, rw) => pre + d1 + (d1 ? cl : n2col(col2n(cl) + dc)) + d2 + (d2 ? rw : Math.max(1, +rw + dr)))).join('');
  }
  // имена листов не латиницей Excel пишет без кавычек (Отчёт!A1) — таблице нужны кавычки
  const cleanF = f => f.replace(/_xlfn\.|_xlws\.|_xludf\./g, '').split(/("(?:[^"]|"")*"|'(?:[^']|'')*')/).map((part, i) => i % 2 ? part :
    part.replace(/(^|[^\wА-Яа-яЁё.'])([\wА-Яа-яЁё.]+)!/g, (m, pre, n) => /^[A-Za-z0-9_.]+$/.test(n) ? m : pre + "'" + n + "'!")).join('');
  const ERRS = ['#NULL!', '#DIV/0!', '#VALUE!', '#REF!', '#NAME?', '#NUM!', '#N/A'];

  // ---------- чтение листа ----------
  async function readSheet(z, part, ctx, xfOf) {
    const x = parseX(await z.text(part));
    const out = { a: [], s: {}, cw: {}, rh: {}, mg: [], fz: 0, grid: true, tab: null, notes: {}, forms: [], maxR: 0, maxC: 0 };
    if (!x) return out;
    const tc = one(one(x, 'sheetPr'), 'tabColor'); if (tc) out.tab = colorOf(tc, ctx, true);
    const sv = one(x, 'sheetView');
    if (sv) {
      if (at(sv, 'showGridLines') === '0') out.grid = false;
      const pn = kid(sv, 'pane');
      if (pn && /frozen/i.test(at(pn, 'state') || '')) { if (+at(pn, 'ySplit') >= 1) out.fz |= 1; if (+at(pn, 'xSplit') >= 1) out.fz |= 2; }
    }
    const fp = one(x, 'sheetFormatPr');
    const MDW = 7, w2px = w => Math.trunc(((256 * w + Math.trunc(128 / MDW)) / 256) * MDW);
    let defW = 64;
    if (fp && at(fp, 'defaultColWidth')) defW = w2px(parseFloat(at(fp, 'defaultColWidth')));
    else if (fp && at(fp, 'baseColWidth')) { const b = +at(fp, 'baseColWidth'); defW = Math.ceil((b * MDW + 5) / 8) * 8; }
    const defH = fp && at(fp, 'defaultRowHeight') ? Math.round(parseFloat(at(fp, 'defaultRowHeight')) * 4 / 3) : 20;
    out.defW = defW; out.defH = defH;
    const colSt = [];
    all(one(x, 'cols'), 'col').forEach(c => {
      const a = +at(c, 'min') - 1, b = Math.min(+at(c, 'max') - 1, a + 400);
      const hid = bool(c, 'hidden', false), w = at(c, 'width') != null ? w2px(parseFloat(at(c, 'width'))) : defW;
      for (let i = a; i <= b; i++) { out.cw[i] = hid ? 3 : Math.max(3, w); if (at(c, 's') && at(c, 's') !== '0') colSt.push([i, at(c, 's')]); }
    });
    const rowSt = [];
    const sd = one(x, 'sheetData');
    let rr = -1;
    kids(sd, 'row').forEach(row => {
      const r = at(row, 'r') ? +at(row, 'r') - 1 : rr + 1; rr = r;
      if (bool(row, 'hidden', false)) out.rh[r] = 3;
      else if (at(row, 'ht') != null && bool(row, 'customHeight', true)) out.rh[r] = Math.max(3, Math.round(parseFloat(at(row, 'ht')) * 4 / 3));
      else if (at(row, 'ht') != null) out.rh[r] = Math.max(3, Math.round(parseFloat(at(row, 'ht')) * 4 / 3));
      if (bool(row, 'customFormat', false) && at(row, 's')) rowSt.push([r, at(row, 's')]);
      let cc = -1;
      kids(row, 'c').forEach(c => {
        const p = ref(at(c, 'r')); const C = p ? p.c : cc + 1; cc = C;
        const t = at(c, 't') || 'n', vEl = kid(c, 'v'), fEl = kid(c, 'f');
        let v = null;
        if (t === 's') v = vEl ? ctx.sst[+tv(vEl)] ?? '' : null;
        else if (t === 'inlineStr') v = all(kid(c, 'is'), 't').map(tv).join('');
        else if (t === 'str') v = vEl ? tv(vEl) : '';
        else if (t === 'b') v = vEl ? tv(vEl) === '1' : null;
        else if (t === 'e') v = vEl ? tv(vEl) : null;
        else if (t === 'd') { const d = vEl ? Date.parse(tv(vEl)) : NaN; v = isNaN(d) ? null : d / 864e5 + 25569; }
        else if (vEl && tv(vEl) !== '') v = +tv(vEl);
        if (typeof v === 'number' && ctx.d1904) { const xf = xfOf(at(c, 's')); if (xf.nf === 'date') v += 1462; }
        let f = null;
        if (fEl) {
          const ft = at(fEl, 't'), si = at(fEl, 'si');
          if (tv(fEl)) { f = tv(fEl); if (ft === 'shared' && si != null) ctx.shared[part + si] = { f, r, c: C }; }
          else if (ft === 'shared' && si != null && ctx.shared[part + si]) { const m = ctx.shared[part + si]; f = shiftF(m.f, r - m.r, C - m.c); }
        }
        let cell = v;
        if (typeof v === 'string' && v[0] === '=' && !f) cell = "'" + v;
        if (f) { cell = '=' + cleanF(f); out.forms.push([r, C, v, t]); }
        if (cell !== null && cell !== undefined) { (out.a[r] ??= [])[C] = cell; out.maxR = Math.max(out.maxR, r); out.maxC = Math.max(out.maxC, C); }
        if (at(c, 's') != null || cell != null) {
          const s = xfOf(at(c, 's'));
          if (Object.keys(s).length) out.s[r + ',' + C] = Object.assign({}, s);
          if (at(c, 's') && at(c, 's') !== '0') { out.maxR = Math.max(out.maxR, r); out.maxC = Math.max(out.maxC, C); }
        }
      });
    });
    all(one(x, 'mergeCells'), 'mergeCell').forEach(m => { const g = range(at(m, 'ref')); if (g) { out.mg.push(g); out.maxR = Math.max(out.maxR, g.r2); out.maxC = Math.max(out.maxC, g.c2); } });
    // стили целых строк/столбцов (заливка, границы) — на пустые ячейки в пределах листа
    const vis = s => s.bg || s.bt || s.bb || s.bl || s.br;
    const R = Math.min(out.maxR + 20, 3000), Cn = Math.min(out.maxC + 2, 300);
    rowSt.forEach(([r, s]) => { const o = xfOf(s); if (vis(o)) for (let c = 0; c < Cn; c++) out.s[r + ',' + c] ??= Object.assign({}, o); });
    colSt.forEach(([c, s]) => { const o = xfOf(s); if (vis(o)) for (let r = 0; r < R; r++) out.s[r + ',' + c] ??= Object.assign({}, o); });
    // примечания
    try {
      const rl = await rels(z, part);
      for (const k in rl) if (/comments$/.test(rl[k].type)) {
        const cx = parseX(await z.text(rl[k].target));
        all(cx, 'comment').forEach(cm => { const p = ref(at(cm, 'ref')); if (p) out.notes[p.r + ',' + p.c] = all(cm, 't').map(tv).join('').trim(); });
      }
    } catch (_) {}
    return out;
  }

  async function readXlsx(buf) {
    const z = await unzip(buf);
    let wbPart = 'xl/workbook.xml';
    const root = parseX(await z.text('_rels/.rels'));
    all(root, 'Relationship').forEach(r => { if (/officeDocument$/.test(at(r, 'Type') || '')) wbPart = resolve('', at(r, 'Target')); });
    const wb = parseX(await z.text(wbPart));
    if (!wb) throw new Error('в файле нет книги');
    const wr = await rels(z, wbPart);
    const ctx = { theme: [], idx: IDX.slice(), sst: [], shared: {}, d1904: false };
    const pr = one(wb, 'workbookPr'); if (pr && bool(pr, 'date1904', false)) ctx.d1904 = true;
    for (const k in wr) {
      const t = wr[k].type;
      if (/\/theme$/.test(t)) {
        const th = parseX(await z.text(wr[k].target)), cs = one(th, 'clrScheme');
        if (cs) {
          const g = n => { const e = kid(cs, n); if (!e) return '000000'; const c = e.firstElementChild; return (at(c, 'lastClr') || at(c, 'val') || '000000').slice(-6); };
          ctx.theme = [g('lt1'), g('dk1'), g('lt2'), g('dk2'), g('accent1'), g('accent2'), g('accent3'), g('accent4'), g('accent5'), g('accent6'), g('hlink'), g('folHlink')];
        }
      }
    }
    if (!ctx.theme.length) ctx.theme = ['FFFFFF', '000000', 'E7E6E6', '44546A', '4472C4', 'ED7D31', 'A5A5A5', 'FFC000', '5B9BD5', '70AD47', '0563C1', '954F72'];
    for (const k in wr) {
      const t = wr[k].type;
      if (/sharedStrings$/.test(t)) {
        const sx = parseX(await z.text(wr[k].target));
        ctx.sst = kids(one(sx, 'sst'), 'si').map(si => { const t0 = kid(si, 't'); return t0 ? tv(t0) : kids(si, 'r').map(r => tv(kid(r, 't'))).join(''); });
      }
    }
    let S = { fmts: BUILTIN, fonts: [], fills: [], borders: [], xfs: [] };
    for (const k in wr) if (/\/styles$/.test(wr[k].type)) S = readStyles(parseX(await z.text(wr[k].target)), ctx);
    const xfOf = buildXf(S, ctx);
    const sheets = [];
    for (const sh of all(wb, 'sheet')) {
      const name = at(sh, 'name'), r = wr[rid(sh)];
      const d = r && /worksheet$/.test(r.type) ? await readSheet(z, r.target, ctx, xfOf) : { a: [], s: {}, cw: {}, rh: {}, mg: [], notes: {}, forms: [], maxR: 0, maxC: 0, grid: true, fz: 0 };
      d.name = name; d.hidden = at(sh, 'state') && at(sh, 'state') !== 'visible';
      sheets.push(d);
    }
    const names = all(one(wb, 'definedNames'), 'definedName').filter(n => at(n, 'localSheetId') == null && !/^_xlnm\./.test(at(n, 'name'))).map(n => [at(n, 'name'), tv(n)]);
    const bv = one(wb, 'workbookView'), active = bv ? +(at(bv, 'activeTab') || 0) : 0;
    return { sheets, names, active };
  }

  // ---------- .xls / .ods / .csv через SheetJS ----------
  function readOther(wb) {
    return {
      sheets: wb.SheetNames.map(n => {
        const ws = wb.Sheets[n], d = { name: n, a: [], s: {}, cw: {}, rh: {}, mg: [], notes: {}, forms: [], maxR: 0, maxC: 0, grid: true, fz: 0 };
        if (ws['!ref']) {
          const R = XLSX.utils.decode_range(ws['!ref']);
          for (let r = 0; r <= R.e.r; r++) for (let c = 0; c <= R.e.c; c++) {
            const x = ws[XLSX.utils.encode_cell({ r, c })]; if (!x) continue;
            let v = x.f ? '=' + cleanF(x.f) : x.v;
            if (v instanceof Date) v = v.getTime() / 864e5 + 25569;
            if (typeof v === 'string' && v[0] === '=' && !x.f) v = "'" + v;
            if (x.t === 'e' && !x.f) v = x.w || null;
            (d.a[r] ??= [])[c] = v;
            if (x.f) d.forms.push([r, c, x.v, x.t]);
            const o = {};
            const fg = x.s && x.s.fgColor && x.s.fgColor.rgb; if (fg && x.s.patternType && x.s.patternType !== 'none') o.bg = '#' + fg.slice(-6);
            if (x.t === 'n' && x.z) { const nf = nfOf(String(x.z)); if (nf) Object.assign(o, nf); }
            if (x.t === 'd') { o.nf = 'date'; }
            if (Object.keys(o).length) d.s[r + ',' + c] = o;
            if (x.c && x.c[0]) d.notes[r + ',' + c] = x.c.map(q => q.t).join('\n');
            d.maxR = Math.max(d.maxR, r); d.maxC = Math.max(d.maxC, c);
          }
        }
        (ws['!cols'] || []).forEach((c, i) => { if (c) { const w = c.wpx || (c.wch ? c.wch * 7 + 5 : 0); if (w) d.cw[i] = c.hidden ? 3 : Math.round(w); } });
        (ws['!rows'] || []).forEach((r, i) => { if (r) { const h = r.hpt ? r.hpt * 4 / 3 : (r.hpx || 0); if (h) d.rh[i] = r.hidden ? 3 : Math.round(h); } });
        (ws['!merges'] || []).forEach(m => d.mg.push({ r1: m.s.r, r2: m.e.r, c1: m.s.c, c2: m.e.c }));
        return d;
      }), names: [], active: 0,
    };
  }

  // ---------- .xls (BIFF8): шрифты, заливка, границы, выравнивание, форматы ----------
  function readXlsStyles(buf) {
    if (!XLSX.CFB) return null;
    const cfb = XLSX.CFB.read(new Uint8Array(buf), { type: 'array' });
    const ent = XLSX.CFB.find(cfb, 'Workbook') || XLSX.CFB.find(cfb, 'Book');
    if (!ent || !ent.content) return null;
    const u = ent.content instanceof Uint8Array ? ent.content : new Uint8Array(ent.content);
    const dv = new DataView(u.buffer, u.byteOffset, u.byteLength);
    const u16 = o => dv.getUint16(o, true), u32 = o => dv.getUint32(o, true);
    const str = (o, n, hi) => { let t = ''; for (let i = 0; i < n; i++) t += String.fromCharCode(hi ? u16(o + i * 2) : u[o + i]); return t; };
    const fonts = [], xfs = [], fmts = Object.assign({}, BUILTIN), pal = IDX.slice(), sheets = [];
    let cur = null, inGlobals = true, bofs = 0;
    const offs = {};
    for (let p = 0; p + 4 <= u.length;) {
      const t = u16(p), n = u16(p + 2), d = p + 4;
      if (d + n > u.length) break;
      if (t === 0x0809) {          // BOF
        bofs++;
        if (bofs > 1) { inGlobals = false; cur = offs[p] || null; }
      } else if (t === 0x000A) {   // EOF
        cur = null;
      } else if (inGlobals) {
        if (t === 0x0031 && n >= 15) {                     // FONT
          const cch = u[d + 14], hi = u[d + 15] & 1;
          fonts.push({ pt: u16(d) / 20, i: !!(u16(d + 2) & 2), k: !!(u16(d + 2) & 8), icv: u16(d + 4), b: u16(d + 6) >= 700, u: u[d + 10] > 0, name: str(d + 16, cch, hi) });
        } else if (t === 0x041E && n >= 5) {               // FORMAT
          const id = u16(d), cch = u16(d + 2), hi = u[d + 4] & 1; fmts[id] = str(d + 5, cch, hi);
        } else if (t === 0x00E0 && n >= 20) {              // XF
          const al = u[d + 6], b1 = u32(d + 10), b2 = u32(d + 14), b3 = u16(d + 18);
          xfs.push({ font: u16(d), fmt: u16(d + 2), alc: al & 7, wrap: !!(al & 8), alcV: (al >> 4) & 7, rot: u[d + 7], ind: u[d + 8] & 15,
            dgL: b1 & 15, dgR: (b1 >> 4) & 15, dgT: (b1 >> 8) & 15, dgB: (b1 >> 12) & 15, icvL: (b1 >> 16) & 127, icvR: (b1 >> 23) & 127,
            icvT: b2 & 127, icvB: (b2 >> 7) & 127, fls: (b2 >>> 26) & 63, fore: b3 & 127, back: (b3 >> 7) & 127 });
        } else if (t === 0x0092 && n >= 2) {               // PALETTE
          const k = u16(d); for (let i = 0; i < k && 2 + i * 4 + 3 <= n; i++) pal[8 + i] = [0, 1, 2].map(j => u[d + 2 + i * 4 + j].toString(16).padStart(2, '0')).join('').toUpperCase();
        } else if (t === 0x0085 && n >= 8) {               // BOUNDSHEET
          const cch = u[d + 6], hi = u[d + 7] & 1;
          const sh = { name: str(d + 8, cch, hi), dt: u[d + 5], xf: {}, rows: {}, cols: [], defW: 0, fz: 0, grid: true };
          sheets.push(sh); offs[u32(d)] = sh;
        }
      } else if (cur) {
        const cell = () => { cur.xf[u16(d) + ',' + u16(d + 2)] = u16(d + 4); };
        if (t === 0x0201 || t === 0x0203 || t === 0x0205 || t === 0x00FD || t === 0x0204 || t === 0x027E || t === 0x0006) { if (n >= 6) cell(); }
        else if (t === 0x00BD) { const r = u16(d), c0 = u16(d + 2), k = (n - 6) / 6; for (let i = 0; i < k; i++) cur.xf[r + ',' + (c0 + i)] = u16(d + 4 + i * 6); }
        else if (t === 0x00BE) { const r = u16(d), c0 = u16(d + 2), k = (n - 6) / 2; for (let i = 0; i < k; i++) cur.xf[r + ',' + (c0 + i)] = u16(d + 4 + i * 2); }
        else if (t === 0x0208 && n >= 16) { const g = u16(d + 12), h = u16(d + 6); cur.rows[u16(d)] = { h: (h & 0x8000) ? 0 : h / 20, hidden: !!(g & 0x20), custom: !!(g & 0x40), ixfe: (g & 0x80) ? (u16(d + 14) & 0xFFF) : null }; }
        else if (t === 0x007D && n >= 10) cur.cols.push({ a: u16(d), b: u16(d + 2), w: u16(d + 4) / 256, ixfe: u16(d + 6), hidden: !!(u16(d + 8) & 1) });
        else if (t === 0x0055 && n >= 2) cur.defW = u16(d);
        else if (t === 0x023E && n >= 2) { const g = u16(d); cur.grid = !!(g & 2); cur.frozen = !!(g & 8); }
        else if (t === 0x0041 && n >= 4) { if (cur.frozen) { if (u16(d + 2) >= 1) cur.fz |= 1; if (u16(d) >= 1) cur.fz |= 2; } }
      }
      p = d + n;
    }
    const col = i => i === 64 || i === 0x7F || i == null ? null : i === 65 ? '#ffffff' : (pal[i] ? '#' + pal[i].toLowerCase() : null);
    const BS = [null, 'thin', 'medium', 'dashed', 'dotted', 'thick', 'double', 'hair', 'mediumDashed', 'dashDot', 'mediumDashDot', 'dashDotDot', 'mediumDashDotDot', 'slantDashDot'];
    const fnt = i => fonts[i >= 4 ? i - 1 : i] || fonts[0] || {};
    const defPt = (fonts[0] || {}).pt || 10;
    const memo = {};
    function styleOf(ix) {
      if (ix == null) return {};
      if (memo[ix]) return memo[ix];
      const x = xfs[ix]; const o = {};
      if (!x) return (memo[ix] = o);
      const f = fnt(x.font);
      if (f.name) o.ff = qf(f.name);
      const pt = f.pt || defPt; if (Math.abs(pt - 11) > .01) o.sz = Math.round(pt * 13 / 11 * 2) / 2;
      if (f.b) o.b = true; if (f.i) o.i = true; if (f.u) o.u = true; if (f.k) o.k = true;
      const fc = col(f.icv); if (fc && fc !== '#000000') o.fg = fc;
      if (x.fls) { const bg = col(x.fore) || col(x.back); if (bg) o.bg = bg; }
      [['dgL', 'icvL', 'bl'], ['dgR', 'icvR', 'br'], ['dgT', 'icvT', 'bt'], ['dgB', 'icvB', 'bb']].forEach(([g, c, k]) => { const b = BS[x[g]]; if (b) o[k] = BST[b] + ' ' + (col(x[c]) || '#000'); });
      const nf = nfOf(fmts[x.fmt]); if (nf) Object.assign(o, nf);
      const H = [null, 'left', 'center', 'right', 'left', 'justify', 'center', 'justify'][x.alc]; if (H) o.al = H;
      o.va = ['top', 'middle', 'bottom', 'middle', 'middle'][x.alcV] || 'bottom';
      if (x.wrap) o.wr = true; if (x.ind) o.ind = x.ind; if (x.rot === 255) o.or = true;
      return (memo[ix] = o);
    }
    return { sheets, styleOf };
  }
  function mergeXls(B, X) {
    if (!X) return;
    const MDW = 7, w2px = w => Math.trunc(((256 * w + Math.trunc(128 / MDW)) / 256) * MDW);
    B.sheets.forEach(d => {
      const sh = X.sheets.find(q => q.name === d.name); if (!sh) return;
      for (const k in sh.xf) {
        const o = X.styleOf(sh.xf[k]); if (!Object.keys(o).length) continue;
        const [r, c] = k.split(',').map(Number);
        d.s[k] = Object.assign({}, o, d.s[k] && d.s[k].nf && !o.nf ? { nf: d.s[k].nf, dp: d.s[k].dp } : {});
        d.maxR = Math.max(d.maxR, r); d.maxC = Math.max(d.maxC, c);
      }
      if (sh.defW) d.defW = Math.ceil((sh.defW * MDW + 5) / 8) * 8;
      sh.cols.forEach(q => { for (let c = q.a; c <= Math.min(q.b, q.a + 300); c++) d.cw[c] = q.hidden ? 3 : Math.max(3, w2px(q.w)); });
      for (const r in sh.rows) { const q = sh.rows[r]; if (q.hidden) d.rh[r] = 3; else if (q.h) d.rh[r] = Math.max(3, Math.round(q.h * 4 / 3)); }
      d.defH = 20; d.grid = sh.grid; d.fz = sh.fz;
    });
  }

  // ---------- загрузка в таблицу ----------
  const tabColor = {}, gridOff = {}, frozen = {};
  function apply(B, opt) {
    opt = opt || {};
    let prevSid = null; try { prevSid = sid; } catch (_) {}
    const o = {};
    B.sheets.forEach(d => { const a = []; for (let r = 0; r <= d.maxR; r++) a[r] = (d.a[r] || []).slice(); o[d.name] = a.length ? a : [[]]; });
    // В игре: книгу НЕ пересоздаём (иначе пропадут листы игры) — листы файла
    // добавляются рядом с игровыми, совпадающие имена получают « (2)».
    const merge = !!window.OFFICE;
    let mr = 100, mc = 26;
    if (!merge) {
      load(o);
      for (const k in mgs) delete mgs[k];
      for (const k in nts) delete nts[k];
      for (const k in tabColor) delete tabColor[k];
    } else {
      if (typeof commit === 'function') try { commit(); } catch (_) {}
      const ren = {};
      B.sheets.forEach(d => {
        let n = String(d.name || 'Лист').slice(0, 31), k = 2;
        while (hf.doesSheetExist(n)) n = String(d.name).slice(0, 26) + ' (' + (k++) + ')';
        if (n !== d.name) ren[d.name] = n;
        hf.addSheet(n); d.name = n;
      });
      B.sheets.forEach(d => {
        const id = hf.getSheetId(d.name);
        let a = o[Object.keys(ren).find(x => ren[x] === d.name) || d.name] || [[]];
        try { hf.setSheetContent(id, a); }
        catch (_) { hf.setSheetContent(id, a.map(r => (r || []).map(v => typeof v === 'string' && v[0] === '=' ? "'" + v : v))); }
      });
      window.YZ_IMPORTED = (window.YZ_IMPORTED || []).concat(B.sheets.map(d => d.name));
      mr = NR; mc = NC;
    }
    B.sheets.forEach(d => {
      const id = hf.getSheetId(d.name); if (id == null) return;
      st[id] = d.s; mgs[id] = d.mg; nts[id] = d.notes;
      if (d.tab) tabColor[id] = d.tab;
      gridOff[id] = !d.grid; frozen[id] = d.fz || 0;
      const R = d.maxR + 20, C = d.maxC + 2;
      mr = Math.max(mr, R); mc = Math.max(mc, C);
      const W = {}, H = {};
      if (d.defW) for (let c = 0; c < 300; c++) W[c] = d.defW;
      if (d.defH) for (let r = 0; r < Math.min(R + 100, 5000); r++) H[r] = d.defH;
      cw[id] = Object.assign(W, d.cw); rh[id] = Object.assign(H, d.rh);
    });
    // формулы, которые таблица не умеет считать, — показываем сохранённое значение
    try {
      B.sheets.forEach(d => {
        const id = hf.getSheetId(d.name); if (id == null) return;
        d.forms.forEach(([r, c, v, t]) => {
          const cur = hf.getCellValue({ sheet: id, row: r, col: c });
          const bad = cur && typeof cur === 'object' && 'type' in cur;
          if (bad && v != null && !(t === 'e')) hf.setCellContents({ sheet: id, row: r, col: c }, typeof v === 'string' && v[0] === '=' ? "'" + v : v);
        });
      });
    } catch (_) {}
    B.names.forEach(([n, e]) => { try { hf.addNamedExpression(n, '=' + cleanF(e)); } catch (_) {} });
    NR = Math.max(merge ? NR : 0, Math.min(mr, 5000)); NC = Math.max(merge ? NC : 0, Math.min(mc, 300));
    if (merge && opt.quiet && prevSid != null && hf.getSheetName(prevSid) != null) {
      sid = prevSid;                               // тихий импорт (обложка при запуске) — остаёмся где были
    } else if (merge) {
      const d = B.sheets[Math.min(B.active, B.sheets.length - 1)] || B.sheets[0];
      sid = hf.getSheetId(d.name);
    } else {
      const ids = hf.getSheetNames().map(n => hf.getSheetId(n));
      sid = ids[Math.min(B.active, ids.length - 1)] ?? ids[0];
    }
    if (hf.clearUndoStack) try { hf.clearUndoStack(); } catch (_) {}
    if (!(merge && opt.quiet)) home();
    tabs(); build();
    B.names_ = B.sheets.map(d => d.name);
    try { window.dispatchEvent(new CustomEvent('yz-imported', { detail: { sheets: B.names_ } })); } catch (_) {}
    return B.names_;
  }
  // ярлыки: цвет; при смене листа — сетка и закрепление
  const tabs0 = tabs;
  tabs = function () {
    tabs0.apply(this, arguments);
    const names = hf.getSheetNames();
    Array.from(document.querySelectorAll('#tabs button')).forEach((b, i) => {
      const id = names[i] != null ? hf.getSheetId(names[i]) : null;
      if (id != null && tabColor[id]) b.style.boxShadow = 'inset 0 -3px ' + tabColor[id]; else b.style.boxShadow = '';
    });
  };
  const build0 = build;
  build = function () {
    if (sid in gridOff) { T.classList.toggle('ng', !!gridOff[sid]); fz = frozen[sid] || 0; }
    else if (window.OFFICE) { T.classList.remove('ng'); }
    try { const n = hf.getSheetName(sid), hn = window.YZ_CELLS && window.YZ_CELLS.hostName ? window.YZ_CELLS.hostName() : null; document.body.classList.toggle('yz-other', !!(window.YZ_IMPORTED && window.YZ_IMPORTED.includes(n) && n !== hn)); } catch (_) {}
    return build0.apply(this, arguments);
  };

  // разбор файла любого вида → книга B
  async function parseFile(nm, buf, text) {
    const isZip = buf && buf.byteLength > 4 && new Uint8Array(buf, 0, 2)[0] === 0x50 && new Uint8Array(buf, 0, 2)[1] === 0x4b && !/\.ods$/i.test(nm);
    if (/\.(xlsx|xlsm|xltx|xltm)$/i.test(nm) || isZip) return readXlsx(buf);
    const wb = text != null ? XLSX.read(text, { type: 'string' }) : XLSX.read(buf, { type: 'array', cellStyles: true, cellNF: true });
    const B = readOther(wb);
    if (/\.xls$/i.test(nm) && buf) { try { mergeXls(B, readXlsStyles(buf)); } catch (e) { console.warn('xls styles', e); } }
    return B;
  }
  let lastFile = null;                             // последний импорт: {name, buf, text, sheets}
  imp = async function (f) {
    try {
      const nm = f.name || '';
      const csv = /\.csv$/i.test(nm);
      const buf = csv ? null : await f.arrayBuffer(), text = csv ? await f.text() : null;
      const B = await parseFile(nm, buf, text);
      const names = apply(B);
      lastFile = { name: nm, buf, text, sheets: names };
      const n = B.sheets.reduce((s, d) => s + Object.keys(d.s).length, 0);
      const sb = document.querySelector('#sb');
      if (sb) sb.textContent = 'Импортировано «' + nm + '»: листов ' + B.sheets.length + ', ячеек с оформлением ' + n + (window.OFFICE ? ' · игру на этот лист: Рецензирование → «📌 Игру — на этот лист»' : '');
      if (cover.on && cover.pick) { cover.pick = false; await setCoverFile(lastFile); }
    } catch (x) { console.error(x); alert('Ошибка импорта: ' + x.message); }
  };

  // ================= «📄 Обложка — мой файл» (по кнопке) =================
  //  Свой документ запоминается (IndexedDB) и при каждом запуске игры
  //  тихо открывается отдельными листами; Esc / автоскрытие показывают его.
  const CKEY = 'yz_cover_on';
  const cover = { on: (() => { try { return localStorage.getItem(CKEY) === '1'; } catch (_) { return false; } })(), sheets: [], name: '', pick: false };
  window.YZ_COVER = { isOn: () => cover.on, get sheets() { return cover.sheets; } };
  function idb(mode, fn) {
    return new Promise((res, rej) => {
      let rq; try { rq = indexedDB.open('yz_cover', 1); } catch (e) { rej(e); return; }
      rq.onupgradeneeded = () => rq.result.createObjectStore('f');
      rq.onerror = () => rej(rq.error);
      rq.onsuccess = () => { const db = rq.result, tx = db.transaction('f', mode), r = fn(tx.objectStore('f')); tx.oncomplete = () => { res(r && r.result); db.close(); }; tx.onerror = () => rej(tx.error); };
    });
  }
  const coverGet = () => idb('readonly', s => s.get('cover')).catch(() => null);
  const coverPut = v => idb('readwrite', s => s.put(v, 'cover'));
  async function setCoverFile(F) {
    await coverPut({ name: F.name, buf: F.buf, text: F.text });
    cover.sheets = F.sheets || []; cover.name = F.name;
    syncCover(); msg('Обложка: «' + F.name + '» — теперь Esc / автоскрытие показывают этот файл');
  }
  const msg = t => { const f = () => { const sb = document.querySelector('#sb'); if (sb) sb.textContent = t; }; f(); setTimeout(f, 80); };
  function setCover(v) {
    cover.on = !!v; try { localStorage.setItem(CKEY, cover.on ? '1' : '0'); } catch (_) {}
    syncCover();
  }
  async function toggleCover() {
    if (cover.on) { setCover(false); msg('Обложка выключена — при Esc показывается обычный отчёт'); return; }
    setCover(true);
    if (lastFile) { await setCoverFile(lastFile); return; }
    const saved = await coverGet();
    if (saved && saved.name) { await loadCover(saved, true); msg('Обложка: «' + saved.name + '»'); return; }
    cover.pick = true; msg('Выберите свой файл для обложки (.xlsx / .xls)…');
    const fi = document.querySelector('#file'); if (fi) fi.click();
  }
  async function loadCover(saved, quiet) {
    if (!window.OFFICE) return;                  // в чистом Excel книгу не трогаем
    try {
      const B = await parseFile(saved.name, saved.buf, saved.text);
      cover.sheets = apply(B, { quiet }); cover.name = saved.name;
      lastFile = { name: saved.name, buf: saved.buf, text: saved.text, sheets: cover.sheets };
    } catch (e) { console.warn('cover', e); }
    syncCover();
  }
  function syncCover() {
    document.querySelectorAll('.yz-cov').forEach(b => {
      b.textContent = cover.on ? '📄 Обложка — мой файл: ВКЛ' : '📄 Обложка — мой файл: ВЫКЛ';
      b.title = cover.on ? 'Esc / автоскрытие показывают ваш файл' + (cover.name ? ' «' + cover.name + '»' : '') + '. Нажмите, чтобы выключить'
        : 'Включить: ваш импортированный файл будет открываться при каждом запуске и показываться вместо выдуманного отчёта';
      b.style.background = cover.on ? '#e2efda' : '';
    });
  }
  function mountCover() {
    ['p-rev', 'p-dev'].forEach(id => {
      const pn = document.getElementById(id); if (!pn) return;
      let g = pn.querySelector('.yz-mask');
      if (!g) { g = document.createElement('div'); g.className = 'g yz-mask'; g.innerHTML = '<div class="gb"><div class="rw"></div></div><div class="gl">Маскировка</div>'; pn.appendChild(g); }
      const rw = g.querySelector('.rw');
      const b = document.createElement('button'); b.type = 'button'; b.className = 'yz-cov'; b.onclick = () => toggleCover(); rw.appendChild(b);
      const c = document.createElement('button'); c.type = 'button'; c.textContent = '📂 Сменить файл обложки'; c.title = 'Выбрать другой файл для обложки';
      c.onclick = () => { setCover(true); cover.pick = true; const fi = document.querySelector('#file'); if (fi) fi.click(); };
      rw.appendChild(c);
    });
    syncCover();
    if (cover.on && window.OFFICE) coverGet().then(saved => { if (saved && saved.name) loadCover(saved, true); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(mountCover, 30)); else setTimeout(mountCover, 30);
  const css = document.createElement('style');
  css.textContent = 'body.yz-other #yg-layer{display:none!important}';
  document.head.appendChild(css);
  const fi = document.querySelector('#file');
  if (fi) fi.setAttribute('accept', '.xlsx,.xlsm,.xltx,.xls,.ods,.csv');

  // ================= ЭКСПОРТ в .xlsx с оформлением =================
  const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc32 = u => { let c = 0xFFFFFFFF; for (let i = 0; i < u.length; i++) c = CRC[(c ^ u[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  async function zip(files) {
    const te = new TextEncoder(), parts = [], cd = []; let off = 0;
    for (const [name, text] of files) {
      const data = te.encode(text), nm = te.encode(name), crc = crc32(data);
      let body = data, method = 0;
      if (typeof CompressionStream === 'function') {
        try { body = new Uint8Array(await new Response(new Blob([data]).stream().pipeThrough(new CompressionStream('deflate-raw'))).arrayBuffer()); method = 8; } catch (_) { body = data; method = 0; }
      }
      const h = new DataView(new ArrayBuffer(30));
      h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(8, method, true);
      h.setUint32(14, crc, true); h.setUint32(18, body.length, true); h.setUint32(22, data.length, true); h.setUint16(26, nm.length, true);
      const c = new DataView(new ArrayBuffer(46));
      c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(10, method, true);
      c.setUint32(16, crc, true); c.setUint32(20, body.length, true); c.setUint32(24, data.length, true); c.setUint16(28, nm.length, true); c.setUint32(42, off, true);
      parts.push(new Uint8Array(h.buffer), nm, body); cd.push(new Uint8Array(c.buffer), nm);
      off += 30 + nm.length + body.length;
    }
    const cdLen = cd.reduce((a, b) => a + b.length, 0), e = new DataView(new ArrayBuffer(22));
    e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, cdLen, true); e.setUint32(16, off, true);
    return new Blob([...parts, ...cd, new Uint8Array(e.buffer)]).arrayBuffer();
  }
  const xe = v => String(v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const cvs = document.createElement('canvas').getContext('2d');
  function hexOf(c) {
    if (!c || typeof c !== 'string') return null;
    if (/^#[0-9a-f]{6}$/i.test(c)) return c.slice(1).toUpperCase();
    if (/^#[0-9a-f]{3}$/i.test(c)) return c.slice(1).split('').map(x => x + x).join('').toUpperCase();
    if (/var\(/.test(c)) return '000000';
    cvs.fillStyle = '#000000'; cvs.fillStyle = c; const v = cvs.fillStyle;
    return /^#[0-9a-f]{6}$/i.test(v) ? v.slice(1).toUpperCase() : null;
  }
  function bdOf(x) {
    if (!x) return null;
    if (typeof x !== 'string') return { st: 'thin', c: '000000' };
    const w = parseFloat(x) || 1, ty = /double/.test(x) ? 'double' : /dashed/.test(x) ? 'dashed' : /dotted/.test(x) ? 'dotted' : 'solid';
    const cm = x.match(/#[0-9a-f]{3,6}\b|rgba?\([^)]*\)|[a-z]+$/i);
    const st = ty === 'double' ? 'double' : ty === 'dashed' ? (w >= 2 ? 'mediumDashed' : 'dashed') : ty === 'dotted' ? (w >= 2 ? 'mediumDashed' : 'dotted') : w >= 3 ? 'thick' : w >= 2 ? 'medium' : 'thin';
    return { st, c: (cm && hexOf(cm[0])) || '000000' };
  }
  async function writeXlsx() {
    if (typeof commit === 'function') try { commit(); } catch (_) {}
    let baseFont = 'Calibri';
    try { const tb = document.createElement('table'), td = document.createElement('td'); tb.style.cssText = 'position:absolute;visibility:hidden'; tb.appendChild(document.createElement('tr')).appendChild(td); document.body.appendChild(tb); const f0 = getComputedStyle(td).fontFamily.split(',')[0].replace(/["']/g, '').trim(); tb.remove(); if (f0) baseFont = f0; } catch (_) {}
    const fonts = [], fills = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>'], borders = ['<border><left/><right/><top/><bottom/><diagonal/></border>'], xfs = [], fmts = {};
    const idx = (arr, x) => { let i = arr.indexOf(x); if (i < 0) { i = arr.length; arr.push(x); } return i; };
    const fontX = (o) => {
      const nm = o.ff ? String(o.ff).split(',')[0].replace(/["']/g, '').trim() : baseFont;
      const pt = o.sz ? Math.round(o.sz * 11 / 13 * 2) / 2 : 11, col = hexOf(o.fg);
      return '<font>' + (o.b ? '<b/>' : '') + (o.i ? '<i/>' : '') + (o.k ? '<strike/>' : '') + (o.u ? '<u/>' : '') + '<sz val="' + pt + '"/>' + (col ? '<color rgb="FF' + col + '"/>' : '<color theme="1"/>') + '<name val="' + xe(nm) + '"/><family val="2"/></font>';
    };
    idx(fonts, fontX({}));
    xfs.push('<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>');
    const xfMemo = {};
    const NF = { int: 3, n2: 4, pct: 10, date: 14 };
    function xfOf(o) {
      if (!o) return 0;
      const key = JSON.stringify(o); if (key in xfMemo) return xfMemo[key];
      const fi = idx(fonts, fontX(o));
      const bg = hexOf(o.bg), fl = bg ? idx(fills, '<fill><patternFill patternType="solid"><fgColor rgb="FF' + bg + '"/><bgColor indexed="64"/></patternFill></fill>') : 0;
      const side = (n, x) => { const b = bdOf(x); return b ? '<' + n + ' style="' + b.st + '"><color rgb="FF' + b.c + '"/></' + n + '>' : '<' + n + '/>'; };
      const bi = (o.bl || o.br || o.bt || o.bb) ? idx(borders, '<border>' + side('left', o.bl) + side('right', o.br) + side('top', o.bt) + side('bottom', o.bb) + '<diagonal/></border>') : 0;
      let nf = 0;
      if (o.nf === 'cur') { nf = 164; fmts[164] = '#,##0.00\\ "₽"'; }
      else if (o.nf === 'dp') { const d = Math.max(0, Math.min(10, +o.dp || 0)); nf = 165 + d; fmts[nf] = d ? '0.' + '0'.repeat(d) : '0'; }
      else if (NF[o.nf]) nf = NF[o.nf];
      const H = { left: 'left', center: 'center', right: 'right', justify: 'justify' }[o.al], V = { top: 'top', middle: 'center', bottom: 'bottom' }[o.va];
      const al = (H || V || o.wr || o.ind || o.or) ? '<alignment' + (H ? ' horizontal="' + H + '"' : '') + (V ? ' vertical="' + V + '"' : '') + (o.wr ? ' wrapText="1"' : '') + (o.ind ? ' indent="' + (+o.ind | 0) + '"' : '') + (o.or ? ' textRotation="255"' : '') + '/>' : '';
      const x = '<xf numFmtId="' + nf + '" fontId="' + fi + '" fillId="' + fl + '" borderId="' + bi + '" xfId="0"' + (nf ? ' applyNumberFormat="1"' : '') + (fi ? ' applyFont="1"' : '') + (fl ? ' applyFill="1"' : '') + (bi ? ' applyBorder="1"' : '') + (al ? ' applyAlignment="1">' + al + '</xf>' : '/>');
      return (xfMemo[key] = idx(xfs, x));
    }
    const names = hf.getSheetNames(), files = [], NS = 'xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"';
    const sheetsXml = [];
    names.forEach((n, si) => {
      const id = hf.getSheetId(n), S = hf.getSheetSerialized(id), V = hf.getSheetValues(id), STY = st[id] || {};
      const cells = {}; let mr = 0, mc = 0;
      const touch = (r, c) => { (cells[r] ??= {})[c] = 1; mr = Math.max(mr, r); mc = Math.max(mc, c); };
      S.forEach((row, r) => row.forEach((x, c) => { if (x != null && x !== '') touch(r, c); }));
      for (const k in STY) { const o = STY[k]; if (o && Object.keys(o).length) { const [r, c] = k.split(',').map(Number); if (r < 20000 && c < 16384) touch(r, c); } }
      (mgs[id] || []).forEach(m => { mr = Math.max(mr, m.r2); mc = Math.max(mc, m.c2); });
      const W = cw[id] || {}, Hh = rh[id] || {};
      let cols = '';
      const lastC = Math.max(mc, ...Object.keys(W).map(Number).filter(c => c <= 300 && W[c] !== 92), 0);
      for (let c = 0; c <= lastC; c++) { const w = W[c] || 92; if (w !== 92) cols += '<col min="' + (c + 1) + '" max="' + (c + 1) + '" width="' + (Math.round(w / 7 * 100) / 100) + '" customWidth="1"/>'; }
      let rows = '';
      const lastR = Math.max(mr, ...Object.keys(Hh).map(Number).filter(r => r <= mr + 50 && Hh[r] !== 22 && r < 20000), 0);
      for (let r = 0; r <= lastR; r++) {
        const h = Hh[r] || 22, row = cells[r];
        if (!row && h === 22) continue;
        let x = '<row r="' + (r + 1) + '"' + (h !== 22 ? ' ht="' + (Math.round(h * 0.75 * 100) / 100) + '" customHeight="1"' : '') + '>';
        if (row) Object.keys(row).map(Number).sort((a, b) => a - b).forEach(c => {
          const ref = n2col(c) + (r + 1), raw = (S[r] || [])[c], v = (V[r] || [])[c], sI = xfOf(STY[r + ',' + c]);
          const sa = sI ? ' s="' + sI + '"' : '';
          if (raw == null || raw === '') { x += '<c r="' + ref + '"' + sa + '/>'; return; }
          const err = v && typeof v === 'object';
          if (typeof raw === 'string' && raw[0] === '=') {
            const f = '<f>' + xe(raw.slice(1)) + '</f>';
            if (err) x += '<c r="' + ref + '"' + sa + ' t="e">' + f + '<v>' + xe(v.value || '#VALUE!') + '</v></c>';
            else if (typeof v === 'number') x += '<c r="' + ref + '"' + sa + '>' + f + '<v>' + v + '</v></c>';
            else if (typeof v === 'boolean') x += '<c r="' + ref + '"' + sa + ' t="b">' + f + '<v>' + (v ? 1 : 0) + '</v></c>';
            else x += '<c r="' + ref + '"' + sa + ' t="str">' + f + '<v>' + xe(v == null ? '' : v) + '</v></c>';
          } else if (typeof v === 'number') x += '<c r="' + ref + '"' + sa + '><v>' + v + '</v></c>';
          else if (typeof v === 'boolean') x += '<c r="' + ref + '"' + sa + ' t="b"><v>' + (v ? 1 : 0) + '</v></c>';
          else if (err) x += '<c r="' + ref + '"' + sa + ' t="e"><v>' + xe(v.value) + '</v></c>';
          else x += '<c r="' + ref + '"' + sa + ' t="inlineStr"><is><t xml:space="preserve">' + xe(v == null ? raw : v) + '</t></is></c>';
        });
        rows += x + '</row>';
      }
      const fzz = id === sid ? fz : (frozen[id] || 0), grid = id === sid ? !T.classList.contains('ng') : !gridOff[id];
      const pane = fzz ? '<pane' + (fzz & 2 ? ' xSplit="1"' : '') + (fzz & 1 ? ' ySplit="1"' : '') + ' topLeftCell="' + (fzz & 2 ? 'B' : 'A') + (fzz & 1 ? 2 : 1) + '" activePane="' + (fzz === 3 ? 'bottomRight' : fzz & 1 ? 'bottomLeft' : 'topRight') + '" state="frozen"/>' : '';
      const tc = hexOf(tabColor[id]);
      const mg = (mgs[id] || []).filter(m => m.r2 > m.r1 || m.c2 > m.c1);
      const xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet ' + NS + '>' +
        (tc ? '<sheetPr><tabColor rgb="FF' + tc + '"/></sheetPr>' : '') +
        '<dimension ref="A1:' + n2col(mc) + (mr + 1) + '"/>' +
        '<sheetViews><sheetView workbookViewId="0"' + (grid ? '' : ' showGridLines="0"') + (id === sid ? ' tabSelected="1"' : '') + '>' + pane + '</sheetView></sheetViews>' +
        '<sheetFormatPr defaultColWidth="13.14" defaultRowHeight="16.5" customHeight="1"/>' +
        (cols ? '<cols>' + cols + '</cols>' : '') + '<sheetData>' + rows + '</sheetData>' +
        (mg.length ? '<mergeCells count="' + mg.length + '">' + mg.map(m => '<mergeCell ref="' + n2col(m.c1) + (m.r1 + 1) + ':' + n2col(m.c2) + (m.r2 + 1) + '"/>').join('') + '</mergeCells>' : '') +
        '<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/></worksheet>';
      sheetsXml.push(xml);
    });
    const nfx = Object.keys(fmts).map(k => '<numFmt numFmtId="' + k + '" formatCode="' + xe(fmts[k]) + '"/>').join('');
    const styles = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
      (nfx ? '<numFmts count="' + Object.keys(fmts).length + '">' + nfx + '</numFmts>' : '') +
      '<fonts count="' + fonts.length + '">' + fonts.join('') + '</fonts><fills count="' + fills.length + '">' + fills.join('') + '</fills>' +
      '<borders count="' + borders.length + '">' + borders.join('') + '</borders>' +
      '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
      '<cellXfs count="' + xfs.length + '">' + xfs.join('') + '</cellXfs>' +
      '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
    const act = Math.max(0, names.findIndex(n => hf.getSheetId(n) === sid));
    const wb = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<workbook ' + NS + '><bookViews><workbookView activeTab="' + act + '"/></bookViews><sheets>' +
      names.map((n, i) => '<sheet name="' + xe(n.slice(0, 31)) + '" sheetId="' + (i + 1) + '" r:id="rId' + (i + 1) + '"/>').join('') + '</sheets>' +
      (() => { try { const L = hf.listNamedExpressions(); return L.length ? '<definedNames>' + L.map(n => { const e = hf.getNamedExpressionFormula(n); return e ? '<definedName name="' + xe(n) + '">' + xe(String(e).replace(/^=/, '')) + '</definedName>' : ''; }).join('') + '</definedNames>' : ''; } catch (_) { return ''; } })() +
      '</workbook>';
    const wrels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      names.map((n, i) => '<Relationship Id="rId' + (i + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (i + 1) + '.xml"/>').join('') +
      '<Relationship Id="rId' + (names.length + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
    const ct = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>' +
      '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
      names.map((n, i) => '<Override PartName="/xl/worksheets/sheet' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>').join('') +
      '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>';
    const rootRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';
    files.push(['[Content_Types].xml', ct], ['_rels/.rels', rootRels], ['xl/workbook.xml', wb], ['xl/_rels/workbook.xml.rels', wrels], ['xl/styles.xml', styles]);
    sheetsXml.forEach((x, i) => files.push(['xl/worksheets/sheet' + (i + 1) + '.xml', x]));
    return zip(files);
  }
  if (typeof O === 'object' && O) O.ex = async () => {
    try {
      let nm = 'table.xlsx';
      try { if (typeof nm0 === 'string' && nm0) nm = /\.xlsx$/i.test(nm0) ? nm0 : nm0.replace(/\.[^.]*$/, '') + '.xlsx'; } catch (_) {}
      save(nm, await writeXlsx());
    } catch (x) { console.error(x); alert('Ошибка сохранения: ' + x.message); }
  };
  window.YZ_XLSX_IMPORT = { readXlsx, apply, writeXlsx };
})();
