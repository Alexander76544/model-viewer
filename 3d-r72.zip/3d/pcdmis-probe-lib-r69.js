/* r69: основная библиотека — встроенный PROBE.DAT из установки PC-DMIS (window.PCD_PROBE_DAT, «ITEM:ИМЯ КРЕПЛЕНИЕ»);
   собственные определения r68 остаются только для имён, которых нет в PROBE.DAT.
   r68 — библиотека компонентов щупа в формате файлов PC-DMIS probe.dat / usrprobe.dat.
   Формат восстановлен по декомпиляции PCDLRN (cs.exe): строка «ITEM:ИМЯ описание» начинает компонент,
   далее строки тела: color R G B | ribcount N | cylinder x1 y1 z1 x2 y2 z2 D | cone x1 y1 z1 D1 x2 y2 z2 D2 |
   sphere x y z D | ring x y z i j k D ширина | line x1 y1 z1 x2 y2 z2 | face N x y z … | connect x y z i j k ТИП |
   autojoint x y z i j k текущий шаг мин макс a|b angle | hotspot x y z i j k D D ball|disk|fixedball | begintip/endtip.
   Все размеры — диаметры, мм. Ось Z компонента вверх, компонент «растёт» вниз (−Z).
   VERBATIM — определения, найденные в PCDLRN дословно. Остальные — собственные, по каталожным габаритам (приближённо). */
(function (W) {
  'use strict';
  var VERBATIM = [
    'ITEM:PROBEPH9 PH9 моторизованная головка (определение PC-DMIS)',
    'color 0 0 0',
    'line -30 -30 0 30 -30 0', 'line 30 -30 0 30 30 0', 'line 30 30 0 -30 30 0', 'line -30 30 0 -30 -30 0',
    'line -30 -30 -60 30 -30 -60', 'line 30 -30 -60 30 30 -60', 'line 30 30 -60 -30 30 -60', 'line -30 30 -60 -30 -30 -60',
    'line -30 -30 0 -30 -30 -60', 'line 30 -30 0 30 -30 -60', 'line 30 30 0 30 30 -60', 'line -30 30 0 -30 30 -60',
    'ring 0 -30 -30 0 1 0 20 4',
    'ribcount 10', 'color 255 0 0', 'sphere 0 -30 -30 4',
    'autojoint 0 0 -77 0 0 1 0 7.5 -180 180 b angle',
    'color 0 0 0', 'ribcount 10', 'sphere 0 0 0 50',
    'autojoint 0 0 0 -1 0 0 0 7.5 0 105 a angle',
    'color 142 142 142', 'ribcount 10', 'cylinder -22 0 0 -25 0 0 13',
    'connect -25 0 0 1 0 0 M8',
    'ITEM:PROBETP2 TP2 щуп касания (определение PC-DMIS)',
    'color 142 142 142', 'ribcount 10', 'cylinder 0 0 0 0 0 -30 13', 'cone 0 0 -30 13 0 0 -35 11', 'cylinder 0 0 -35 0 0 -38 6',
    'connect 0 0 -38 0 0 1 M2',
    'ITEM:TIP2BY20MM Наконечник Ø2 × 20 мм (определение PC-DMIS)',
    'begintip', 'ribcount 10', 'cylinder 0 0 0 0 0 -3 3', 'cone 0 0 -3 3 0 0 -7 1.5', 'cylinder 0 0 -7 0 0 -20 1.5',
    'color 255 0 0', 'sphere 0 0 -20 2', 'hotspot 0 0 -20 0 0 1 2 2 ball', 'endtip',
    'ITEM:FIXEDPROBE Жёсткий щуп Ø8 (определение PC-DMIS)',
    'begintip', 'ribcount 10', 'cylinder 0 0 0 0 0 -8 7', 'cone 0 0 -8 7 0 0 -18 6.0', 'cylinder 0 0 -18 0 0 -50 4.5',
    'color 255 0 0', 'sphere 0 0 -50 8', 'hotspot 0 0 -50 0 0 1 8 8 fixedball', 'endtip'
  ].join('\n');

  function head(name, desc, top, len, d, bAt, kn, aStep, out) {
    return ['ITEM:' + name + ' ' + desc, 'color 70 72 76', 'ribcount 16',
      'cylinder 0 0 0 0 0 -' + top + ' ' + d, 'cone 0 0 -' + top + ' ' + d + ' 0 0 -' + len + ' ' + (d * 0.78).toFixed(1),
      'autojoint 0 0 -' + len + ' 0 0 1 0 ' + aStep + ' -180 180 b angle',
      'color 45 46 50', 'ribcount 16', 'cylinder 0 0 0 0 0 -' + (bAt * 0.5) + ' ' + (d * 0.78).toFixed(1),
      'color 230 140 30', 'ring 0 0 -4 0 0 1 ' + (d * 0.8).toFixed(1) + ' 2', 'color 45 46 50',
      'autojoint 0 0 -' + bAt + ' -1 0 0 0 ' + aStep + ' 0 105 a angle',
      'sphere 0 0 0 ' + kn, 'cylinder 0 0 ' + (kn * 0.42).toFixed(1) + ' 0 0 -' + (kn * 0.42).toFixed(1) + ' ' + (kn * 0.95).toFixed(1),
      'color 142 142 142', 'ribcount 12', 'cylinder -' + (kn / 2 - 2) + ' 0 0 -' + (kn / 2 + 8) + ' 0 0 0 20', 'cylinder -' + (kn / 2 + 8) + ' 0 0 -' + (kn / 2 + 11) + ' 0 0 0 13',
      'connect -' + (kn / 2 + 11) + ' 0 0 1 0 0 ' + out].join('\n');
  }
  function bar(name, desc, len, d, inM, out, col) {
    return ['ITEM:' + name + ' ' + desc, 'color ' + (col || '142 142 142'), 'ribcount 12', 'cylinder 0 0 0 0 0 -' + len + ' ' + d, 'connect 0 0 -' + len + ' 0 0 1 ' + out].join('\n');
  }
  var OWN = [
    head('PROBEPH10M', 'Renishaw PH10M, шаг 7.5° (приближённо)', 62, 72, 62, 42, 40, 7.5, 'M8'),
    head('PROBEPH10MQ', 'Renishaw PH10MQ, шаг 7.5° (приближённо)', 26, 36, 62, 42, 40, 7.5, 'M8'),
    head('PROBEHH-A-T2.5', 'Hexagon HH-A-T2.5, шаг 2.5° (приближённо)', 56, 66, 64, 44, 42, 2.5, 'M8'),
    head('PROBEHH-A-T5', 'Hexagon HH-A-T5, шаг 5° (приближённо)', 56, 66, 64, 44, 42, 5, 'M8'),
    ['ITEM:PROBEPH6 Renishaw PH6 фиксированная головка (приближённо)', 'color 70 72 76', 'ribcount 16', 'cylinder 0 0 0 0 0 -32 25', 'cone 0 0 -32 25 0 0 -38 16', 'connect 0 0 -38 0 0 1 M8'].join('\n'),
    bar('PEL1', 'Удлинитель M8, 50 мм', 50, 13, 'M8', 'M8'),
    bar('PEL2', 'Удлинитель M8, 100 мм', 100, 13, 'M8', 'M8'),
    bar('PEL3', 'Удлинитель M8, 200 мм', 200, 13, 'M8', 'M8'),
    bar('PAA1', 'Адаптер M8, 20 мм', 20, 13, 'M8', 'M8'),
    ['ITEM:PROBETP20 Renishaw TP20 корпус (приближённо)', 'color 40 40 42', 'ribcount 14', 'cylinder 0 0 0 0 0 -5 6', 'cylinder 0 0 -5 0 0 -36 13.2', 'color 200 200 200', 'ring 0 0 -34 0 0 1 13.4 1', 'connect 0 0 -36 0 0 1 TP20'].join('\n'),
    ['ITEM:TP20SF TP20 модуль SF (приближённо)', 'color 60 60 64', 'ribcount 14', 'cylinder 0 0 0 0 0 -12 13.2', 'cone 0 0 -12 13.2 0 0 -15 8', 'connect 0 0 -15 0 0 1 M2'].join('\n'),
    ['ITEM:TP20LF TP20 модуль LF (приближённо)', 'color 60 60 64', 'ribcount 14', 'cylinder 0 0 0 0 0 -12 13.2', 'cone 0 0 -12 13.2 0 0 -15 8', 'connect 0 0 -15 0 0 1 M2'].join('\n'),
    ['ITEM:TP20EM1 TP20 модуль EM1 (+10 мм) (приближённо)', 'color 60 60 64', 'ribcount 14', 'cylinder 0 0 0 0 0 -12 13.2', 'cylinder 0 0 -12 0 0 -22 8', 'cone 0 0 -22 8 0 0 -25 6', 'connect 0 0 -25 0 0 1 M2'].join('\n'),
    ['ITEM:TP20EM2 TP20 модуль EM2 (+50 мм) (приближённо)', 'color 60 60 64', 'ribcount 14', 'cylinder 0 0 0 0 0 -12 13.2', 'cylinder 0 0 -12 0 0 -62 8', 'cone 0 0 -62 8 0 0 -65 6', 'connect 0 0 -65 0 0 1 M2'].join('\n'),
    ['ITEM:PROBETP200 Renishaw TP200 (приближённо)', 'color 40 40 42', 'ribcount 14', 'cylinder 0 0 0 0 0 -5 6', 'cylinder 0 0 -5 0 0 -42 13.5', 'connect 0 0 -42 0 0 1 TP200'].join('\n'),
    ['ITEM:TP200SF TP200 модуль SF (приближённо)', 'color 60 60 64', 'ribcount 14', 'cylinder 0 0 0 0 0 -11 13.5', 'cone 0 0 -11 13.5 0 0 -14 8', 'connect 0 0 -14 0 0 1 M2'].join('\n'),
    ['ITEM:PROBESP25M Renishaw SP25M корпус (приближённо)', 'color 40 40 42', 'ribcount 16', 'cylinder 0 0 0 0 0 -6 6', 'color 205 205 210', 'cylinder 0 0 -6 0 0 -66 25', 'color 30 120 200', 'ring 0 0 -10 0 0 1 25.2 2', 'connect 0 0 -66 0 0 1 SM25'].join('\n'),
    ['ITEM:SM25-1 SP25M модуль SM25-1 + SH25-1 (стержни 20–50) (приближённо)', 'color 205 205 210', 'ribcount 16', 'cylinder 0 0 0 0 0 -22 25', 'color 50 50 55', 'cylinder 0 0 -22 0 0 -32 18', 'connect 0 0 -32 0 0 1 M2'].join('\n'),
    ['ITEM:SM25-2 SP25M модуль SM25-2 + SH25-2 (стержни 50–105) (приближённо)', 'color 205 205 210', 'ribcount 16', 'cylinder 0 0 0 0 0 -30 25', 'color 50 50 55', 'cylinder 0 0 -30 0 0 -42 20', 'connect 0 0 -42 0 0 1 M3'].join('\n'),
    ['ITEM:SM25-3 SP25M модуль SM25-3 + SH25-3 (стержни 120–200) (приближённо)', 'color 205 205 210', 'ribcount 16', 'cylinder 0 0 0 0 0 -95 25', 'color 50 50 55', 'cylinder 0 0 -95 0 0 -107 20', 'connect 0 0 -107 0 0 1 M3'].join('\n'),
    ['ITEM:SM25-4 SP25M модуль SM25-4 + SH25-4 (стержни 220–400) (приближённо)', 'color 205 205 210', 'ribcount 16', 'cylinder 0 0 0 0 0 -195 25', 'color 50 50 55', 'cylinder 0 0 -195 0 0 -207 20', 'connect 0 0 -207 0 0 1 M3'].join('\n'),
    ['ITEM:SM25-5 SP25M модуль SM25-5 (адаптер TP20) (приближённо)', 'color 205 205 210', 'ribcount 16', 'cylinder 0 0 0 0 0 -28 25', 'connect 0 0 -28 0 0 1 TP20'].join('\n'),
    ['ITEM:PROBELSPX1H Hexagon HP-S-X1H (приближённо)', 'color 225 225 228', 'ribcount 16', 'cylinder 0 0 0 0 0 -8 13', 'cylinder 0 0 -8 0 0 -96 30', 'color 200 30 30', 'ring 0 0 -20 0 0 1 30.2 2', 'color 225 225 228', 'cone 0 0 -96 30 0 0 -104 16', 'connect 0 0 -104 0 0 1 M5'].join('\n'),
    ['ITEM:PROBETESASTAR-P TESASTAR-P (приближённо)', 'color 30 30 32', 'ribcount 14', 'cylinder 0 0 0 0 0 -6 6', 'cylinder 0 0 -6 0 0 -42 13', 'connect 0 0 -42 0 0 1 M2'].join('\n'),
    ['ITEM:PROBETESASTAR-MP TESASTAR-MP (приближённо)', 'color 30 30 32', 'ribcount 14', 'cylinder 0 0 0 0 0 -6 6', 'cylinder 0 0 -6 0 0 -50 18', 'connect 0 0 -50 0 0 1 M3'].join('\n'),
    ['ITEM:EXTEN-M2-10 Удлинитель стержня M2, 10 мм', 'color 160 160 160', 'ribcount 10', 'cylinder 0 0 0 0 0 -10 3', 'connect 0 0 -10 0 0 1 M2'].join('\n'),
    ['ITEM:EXTEN-M3-20 Удлинитель стержня M3, 20 мм', 'color 160 160 160', 'ribcount 10', 'cylinder 0 0 0 0 0 -20 5', 'connect 0 0 -20 0 0 1 M3'].join('\n'),
    ['ITEM:EXTEN-M3-50 Удлинитель стержня M3, 50 мм', 'color 160 160 160', 'ribcount 10', 'cylinder 0 0 0 0 0 -50 5', 'connect 0 0 -50 0 0 1 M3'].join('\n'),
    ['ITEM:STAR5-M2 Звезда, 5 стержней Ø2×20 (−Z, ±X, ±Y)', 'color 150 150 150', 'ribcount 10', 'cylinder 0 0 0 0 0 -6 6', 'sphere 0 0 -9 9',
      'begintip', 'cylinder 0 0 -9 0 0 -29 1.5', 'color 255 0 0', 'sphere 0 0 -29 2', 'hotspot 0 0 -29 0 0 1 2 2 ball', 'endtip', 'color 150 150 150',
      'begintip', 'cylinder 0 0 -9 20 0 -9 1.5', 'color 255 0 0', 'sphere 20 0 -9 2', 'hotspot 20 0 -9 -1 0 0 2 2 ball', 'endtip', 'color 150 150 150',
      'begintip', 'cylinder 0 0 -9 -20 0 -9 1.5', 'color 255 0 0', 'sphere -20 0 -9 2', 'hotspot -20 0 -9 1 0 0 2 2 ball', 'endtip', 'color 150 150 150',
      'begintip', 'cylinder 0 0 -9 0 20 -9 1.5', 'color 255 0 0', 'sphere 0 20 -9 2', 'hotspot 0 20 -9 0 -1 0 2 2 ball', 'endtip', 'color 150 150 150',
      'begintip', 'cylinder 0 0 -9 0 -20 -9 1.5', 'color 255 0 0', 'sphere 0 -20 -9 2', 'hotspot 0 -20 -9 0 1 0 2 2 ball', 'endtip'].join('\n')
  ].join('\n');

  /* вход компонента (к чему крепится). ROOT — пиноль машины. TIP — стержень (любая резьба Mx). */
  var MOUNT_IN = {
    PROBEPH9: 'ARM', 'PROBEPH10M': 'ARM', 'PROBEPH10MQ': 'ARM', 'PROBEHH-A-T2.5': 'ARM', 'PROBEHH-A-T5': 'ARM', PROBEPH6: 'ARM', FIXEDPROBE: 'ARM',
    PROBETP2: 'M8', PEL1: 'M8', PEL2: 'M8', PEL3: 'M8', PAA1: 'M8', PROBETP20: 'M8', PROBETP200: 'M8', PROBESP25M: 'M8', PROBELSPX1H: 'M8', 'PROBETESASTAR-P': 'M8', 'PROBETESASTAR-MP': 'M8',
    TP20SF: 'TP20', TP20LF: 'TP20', TP20EM1: 'TP20', TP20EM2: 'TP20', TP200SF: 'TP200',
    'SM25-1': 'SM25', 'SM25-2': 'SM25', 'SM25-3': 'SM25', 'SM25-4': 'SM25', 'SM25-5': 'SM25',
    'EXTEN-M2-10': 'M2', 'EXTEN-M3-20': 'M3', 'EXTEN-M3-50': 'M3', 'STAR5-M2': 'M2', TIP2BY20MM: 'M2'
  };
  var CAT = function (n, body) {
    if (MOUNT_IN[n] === 'ARM' && /autojoint/.test(body)) return 'Головка';
    if (MOUNT_IN[n] === 'ARM') return 'Головка / жёсткий щуп';
    if (/begintip/.test(body)) return 'Стержень';
    if (/^(PEL|PAA|EXTEN)/.test(n)) return 'Удлинитель';
    if (/^(SM25|TP20[A-Z]|TP200SF)/.test(n)) return 'Модуль';
    return 'Щуп / датчик';
  };

  /* тип крепления: «M3ANALOG» → M3, «ROOT» → ARM (пиноль/фланец машины) */
  function normMount(m) { m = String(m || '').toUpperCase(); if (!m || m === 'ARM') return m ? 'ARM' : ''; return m.replace(/ANALOG$/, ''); }
  function cat2(it, body) {
    var n = it.name.toUpperCase();
    if (it.mountIn === 'ARM' && /autojoint/i.test(body)) return 'Головка';
    if (it.mountIn === 'ARM') return 'Головка / фланец / жёсткий щуп';
    if (/begintip/i.test(body)) return 'Стержень';
    if (/^(PEL|PAA|EXTEN|EXT)/.test(n)) return 'Удлинитель';
    if (/^(SM25|SH25|TP20[A-Z_]|TP200SF|TM)/.test(n)) return 'Модуль';
    return 'Щуп / датчик';
  }
  function parse(text, source) {
    var items = [], cur = null;
    String(text || '').replace(/\r/g, '').split('\n').forEach(function (raw) {
      var ln = raw.replace(/^\uFEFF/, '').trim(); if (!ln) return;
      if (/^ITEM:/i.test(ln)) {
        var rest = ln.slice(5).trim(), sp = rest.search(/\s/), name = sp < 0 ? rest : rest.slice(0, sp), desc = sp < 0 ? '' : rest.slice(sp + 1).trim();
        cur = { name: name, desc: desc, lines: [], source: source || '' };
        /* формат PROBE.DAT: второе слово — тип крепления (к чему присоединяется компонент) */
        if (desc && !/\s/.test(desc) && /^[A-Za-z0-9_&.\-]+$/.test(desc)) { cur.mountIn = normMount(desc); cur.desc = ''; cur.realDat = true; }
        items.push(cur); return;
      }
      if (!cur) return;
      if (/^comment/i.test(ln) || /^(#|\/\/|;)/.test(ln)) { if (!cur.desc && /^comment\s+\S/i.test(ln) && !/^comment\s*[-.]{3,}/i.test(ln)) cur.desc = ln.replace(/^comment\s*/i, '').slice(0, 80); return; }
      var m = /^HxPartName\s+(.+)$/i.exec(ln); if (m) { cur.desc = m[1].trim(); }
      cur.lines.push(ln);
    });
    items.forEach(function (it) {
      var body = it.lines.join('\n'), n = it.name.toUpperCase();
      if (!it.mountIn) it.mountIn = normMount(MOUNT_IN[it.name] || MOUNT_IN[n]) || (/begintip/i.test(body) ? 'TIP' : /autojoint/i.test(body) ? 'ARM' : '*');
      var c = /(?:^|\n)connect\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+(\S+)/i.exec(body); it.mountOut = c ? normMount(c[1]) : '';
      it.key = it.name + '@' + it.mountIn;
      it.cat = cat2(it, body); it.hasTip = /hotspot/i.test(body); it.joints = (body.match(/autojoint/gi) || []).length;
      it.cad = (body.match(/cadgeom/gi) || []).length;
      if (!it.desc) { var pn = /HxPartNumber\s+(\S+)/i.exec(body); it.desc = it.cat + (pn ? ' ' + pn[1] : ''); }
    });
    return items;
  }

  /* генератор стержня, по образцу TIP2BY20MM и параметрического генератора PC-DMIS (цвета 117 — резьба, 228 — стержень) */
  var THREAD = { M2: 3, M3: 5, M4: 7, M5: 8 };
  function tipDef(D, L, mount) {
    D = +D || 2; L = +L || 20; mount = (mount || (D >= 4 || L >= 50 ? 'M3' : 'M2')).toUpperCase();
    var s0 = THREAD[mount] || 3, stem = Math.min(D * 0.75, s0 * 0.9), c1 = Math.min(3, L * 0.15), c2 = Math.min(7, L * 0.35);
    var f = function (v) { return String(Math.round(v * 1000) / 1000); };
    var name = 'TIP' + f(D) + 'BY' + f(L) + 'MM' + (mount === 'M2' ? '' : '_' + mount);
    return { name: name, desc: 'Наконечник Ø' + f(D) + ' × ' + f(L) + ' мм, ' + mount + (name === 'TIP2BY20MM' ? '' : ' (генератор)'), mountIn: mount, mountOut: '', cat: 'Стержень', hasTip: true, joints: 0, source: 'генератор', key: name + '@' + mount,
      lines: ['begintip', 'ribcount 10', 'color 117 117 117', 'cylinder 0 0 0 0 0 -' + f(c1) + ' ' + f(s0), 'color 228 228 228', 'cone 0 0 -' + f(c1) + ' ' + f(s0) + ' 0 0 -' + f(c2) + ' ' + f(stem),
        'cylinder 0 0 -' + f(c2) + ' 0 0 -' + f(L) + ' ' + f(stem), 'color 255 0 0', 'sphere 0 0 -' + f(L) + ' ' + f(D), 'hotspot 0 0 -' + f(L) + ' 0 0 1 ' + f(D) + ' ' + f(D) + ' ball', 'endtip'] };
  }
  function tipFromName(n) {
    var m = /^TIP([\d.]+)BY([\d.]+)MM(?:_(M\d))?$/i.exec(String(n || ''));
    return m ? tipDef(+m[1], +m[2], m[3] || (+m[1] >= 4 || +m[2] >= 50 ? 'M3' : 'M2')) : null;
  }

  W.PcdProbeLib = { VERBATIM: VERBATIM, OWN: OWN, MOUNT_IN: MOUNT_IN, parse: parse, tipDef: tipDef, tipFromName: tipFromName,
    normMount: normMount,
    builtins: function () {
      var dat = W.PCD_PROBE_DAT ? parse(W.PCD_PROBE_DAT, 'PROBE.DAT') : [], have = {};
      dat.forEach(function (x) { have[x.name.toUpperCase()] = 1; });
      var own = parse(VERBATIM, 'PC-DMIS').concat(parse(OWN, 'r68')).filter(function (x) { return !have[x.name.toUpperCase()]; });
      return dat.concat(own);
    } };
})(window);
