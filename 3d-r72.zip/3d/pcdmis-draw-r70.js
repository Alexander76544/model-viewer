/* r70 — чтение сеток PC-DMIS .DRAW (MFC CPCDbc_coll).
   Формат (найдено разбором PH10MQ.DRAW): объект детали → заголовок «… 9f 00 R G B 00 xx P»
   (P — номер части для cadgeom), далее uint32 N (число float), 0x00000600, 8 байт, N×float32 —
   поток троек: единичный вектор = нормаль (состояние), иначе вершина; затем N/3 × uint16 кодов
   (бит0 — начало примитива, бит1 — конец, бит 0x08 — полоса треугольников, иначе — полигон (веер)).
   Между блоками — B-rep (NURBS/обрезка, double), он не нужен для показа. */
(function (G) {
  'use strict';
  function parse(buf) {
    var u8 = buf instanceof Uint8Array ? buf : new Uint8Array(buf), N = u8.length, dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    var parts = {}, i = 0, blocks = 0, lastEnd = 0;
    function hdr(from, to) { /* заголовок объекта в начале промежутка: 9f 00 R G B 00 xx P */
      for (var j = from; j < Math.min(to - 8, from + (from ? 400 : 4000)); j++) if (u8[j] === 0x9f && u8[j + 1] === 0 && u8[j + 5] === 0 && u8[j + 6] <= 1 && u8[j + 7] >= 1 && u8[j + 7] <= 32)
        return { c: [u8[j + 2], u8[j + 3], u8[j + 4]], p: u8[j + 7] };
      return null;
    }
    while (i < N - 12) {
      if (u8[i] === 0 && u8[i + 1] === 6 && u8[i + 2] === 0 && u8[i + 3] === 0 && i >= 4) {
        var c = dv.getUint32(i - 4, true), s = i + 12;
        if (c >= 3 && c < 4e6 && c % 3 === 0 && s + c * 4 + (c / 3) * 2 <= N) {
          var ok = true, k, f = new Float32Array(c);
          for (k = 0; k < c; k++) { var v = dv.getFloat32(s + k * 4, true); if (!isFinite(v) || Math.abs(v) > 1e4) { ok = false; break; } f[k] = v; }
          if (ok) {
            var n = c / 3, e = s + c * 4, h = hdr(lastEnd, i - 4) || { c: [128, 128, 128], p: 1 };
            var P = parts[h.p] || (parts[h.p] = { part: h.p, color: h.c, pos: [] }), pos = P.pos;
            var prim = null, fan = false;
            var emit = function (pr, fan) { var a, b, cc, q; for (q = 0; q + 2 < pr.length; q++) { if (fan) { a = pr[0]; b = pr[q + 1]; cc = pr[q + 2]; } else if (q % 2 === 0) { a = pr[q]; b = pr[q + 1]; cc = pr[q + 2]; } else { a = pr[q + 1]; b = pr[q]; cc = pr[q + 2]; } pos.push(a[0], a[1], a[2], b[0], b[1], b[2], cc[0], cc[1], cc[2]); } if (fan) q = 0; };
            for (k = 0; k < n; k++) {
              var cd = dv.getUint16(e + k * 2, true), x = f[k * 3], y = f[k * 3 + 1], z = f[k * 3 + 2], L = Math.sqrt(x * x + y * y + z * z);
              if ((cd & 1) || !prim) { if (prim && prim.length > 2) emit(prim, fan); prim = []; fan = !(cd & 0x08); }
              if (Math.abs(L - 1) > 1e-4) prim.push([x, y, z]);
              if (cd & 2) { emit(prim, fan); prim = null; }
            }
            if (prim && prim.length > 2) emit(prim, fan);
            blocks++; lastEnd = e + n * 2; i = lastEnd; continue;
          }
        }
      }
      i++;
    }
    var out = [];
    Object.keys(parts).sort(function (a, b) { return a - b; }).forEach(function (k) { var p = parts[k]; out.push({ part: p.part, color: p.color, pos: new Float32Array(p.pos) }); });
    return { blocks: blocks, parts: out };
  }
  /* упаковка для хранения: uint16 относительно минимума части, шаг q (≤0.02 мм для деталей до 1.3 м), base64 */
  function b64(u) { if (typeof btoa === 'undefined') return Buffer.from(u).toString('base64'); var s = ''; for (var j = 0; j < u.length; j += 0x8000) s += String.fromCharCode.apply(null, u.subarray(j, j + 0x8000)); return btoa(s); }
  function unb64(t) { if (typeof atob === 'undefined') return new Uint8Array(Buffer.from(t, 'base64')); var bin = atob(t), u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
  function pack(res) {
    return { v: 1, parts: res.parts.map(function (p) {
      var mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9], i, k, P = p.pos;
      for (i = 0; i < P.length; i += 3) for (k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], P[i + k]); mx[k] = Math.max(mx[k], P[i + k]); }
      var q = Math.max(0.002, Math.max(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]) / 65000), a = new Uint16Array(P.length);
      for (i = 0; i < P.length; i++) a[i] = Math.round((P[i] - mn[i % 3]) / q);
      return { part: p.part, color: p.color, o: mn.map(function (x) { return Math.round(x * 1000) / 1000; }), q: q, b64: b64(new Uint8Array(a.buffer)) }; }) };
  }
  function unpack(pk) {
    return { parts: pk.parts.map(function (p) { var u = unb64(p.b64), a = new Uint16Array(u.buffer, u.byteOffset, u.byteLength >> 1), f = new Float32Array(a.length);
      for (var j = 0; j < a.length; j++) f[j] = a[j] * p.q + p.o[j % 3]; return { part: p.part, color: p.color, pos: f }; }) };
  }
  G.PcdDraw = { parse: parse, pack: pack, unpack: unpack };
  if (typeof module !== 'undefined') module.exports = G.PcdDraw;
})(typeof window !== 'undefined' ? window : globalThis);
