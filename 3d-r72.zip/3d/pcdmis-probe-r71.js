/* r69 — щуп меняется по программе (ЗАГР/ЩУП), библиотека PROBE.DAT, модель КИМ (AEH Legend 10128 — параметрическая),
   экспорт/импорт касаний и траектории щупа.
   r68 — «Щуп»: конструктор щупа (модели компонентов в формате PC-DMIS probe.dat), оценка времени выполнения
   программы (модель «Estimate execution time» PC-DMIS: TIME_PER_HIT, TIME_PER_TIP, TIME_PER_TOOLCHANGE, ACCELERATION …)
   и 3D-прогон щупа по траектории с часами. Подключается после pcdmis-probe-lib-r68.js. */
(function () {
  'use strict';
  if (typeof document === 'undefined') return;
  var W = window, L = W.PcdProbeLib;
  function api() { return W.__p57api || null; }
  function G(n) { var a = api(); return a && a.G ? a.G(n) : W[n]; }
  function S() { var a = api(); return a && a.S ? a.S() : null; }
  function toast(m) { var a = api(); if (a && a.toast) a.toast(m); else console.log(m); }
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function num(v, d) { var n = parseFloat(String(v == null ? '' : v).replace(',', '.')); return isFinite(n) ? n : (d === undefined ? 0 : d); }
  function ls(k, v) { try { if (v === undefined) return JSON.parse(localStorage.getItem(k) || 'null'); localStorage.setItem(k, JSON.stringify(v)); } catch (e) { return null; } }
  function hms(t) { t = Math.max(0, Math.round(t)); var h = Math.floor(t / 3600), m = Math.floor(t / 60) % 60, s = t % 60; return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s; }
  function ms(t) { t = Math.max(0, t); var m = Math.floor(t / 60), s = t - m * 60; return m + ':' + (s < 10 ? '0' : '') + s.toFixed(1); }
  function sub(a, b) { return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]; }
  function addv(a, b, k) { k = k == null ? 1 : k; return [a[0] + b[0] * k, a[1] + b[1] * k, a[2] + b[2] * k]; }
  function len(a) { return Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]); }
  function nrm(a) { var l = len(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; }
  function lerp(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }

  /* ======================= библиотека ======================= */
  var LIB = [], USER_KEY = 'pcd68.userlib';
  function rebuildLib() {
    LIB = L ? L.builtins() : [];
    var u = ls(USER_KEY); if (u && u.text) { var it = L.parse(u.text, u.file || 'usrprobe.dat'); it.forEach(function (x) { LIB = LIB.filter(function (y) { return y.key !== x.key; }); LIB.push(x); }); }
  }
  var NM = function (m) { return L && L.normMount ? L.normMount(m) : String(m || '').toUpperCase(); };
  /* поиск компонента: имя + тип крепления предыдущего (в PROBE.DAT имена повторяются для разных креплений) */
  function item(name, prevOut) {
    if (name && name.indexOf('@') > 0) { var sp = name.split('@'); name = sp[0]; prevOut = sp[1]; }
    var pm = NM(prevOut), first = null, ci = null, up = String(name || '').toUpperCase();
    for (var i = LIB.length - 1; i >= 0; i--) { var x = LIB[i]; if (x.name === name) { if (pm && x.mountIn === pm) return x; if (!first) first = x; } else if (!ci && x.name.toUpperCase() === up && (!pm || x.mountIn === pm)) ci = x; }
    if (first) return first; if (ci) return ci;
    var t = L ? L.tipFromName(name) : null; if (t && pm && /^M\d/.test(pm)) { t = L.tipDef(+/TIP([\d.]+)/i.exec(name)[1], +/BY([\d.]+)/i.exec(name)[1], pm); t.name = name; }
    return t;
  }
  /* разрешение цепочки: [{name, it}] с учётом креплений */
  function resolve(names) { var prev = 'ARM'; return names.map(function (n) { var it = item(n, prev); prev = it ? (it.mountOut || '*') : '*'; return { name: n, it: it }; }); }

  /* ======================= сборка 3D (интерпретатор языка probe.dat) ======================= */
  var Z = null;
  function col(c) { var r = c[0], g = c[1], b = c[2]; if (r + g + b < 60) { r = g = b = 48; } return (r << 16) | (g << 8) | b; }
  function mat(cache, c, ghost) {
    var k = col(c) + (ghost ? 'g' : ''); if (cache[k]) return cache[k];
    var T = W.THREE; cache[k] = new T.MeshPhongMaterial({ color: col(c), side: T.DoubleSide, shininess: 60, transparent: !!ghost, opacity: ghost ? 0.35 : 1, depthWrite: !ghost });
    return cache[k];
  }
  function segBetween(T, p1, p2, r1, r2, seg, m) {
    var a = new T.Vector3(p1[0], p1[1], p1[2]), b = new T.Vector3(p2[0], p2[1], p2[2]), d = b.clone().sub(a), l = d.length();
    if (l < 1e-6) return null;
    var g = new T.CylinderGeometry(Math.max(r2, 0.01), Math.max(r1, 0.01), l, seg, 1, false), ms = new T.Mesh(g, m);
    ms.position.copy(a).add(b).multiplyScalar(0.5); ms.quaternion.setFromUnitVectors(new T.Vector3(0, 1, 0), d.normalize());
    return ms;
  }
  /* ---------- r70: настоящие сетки .DRAW (PcdDraw) ---------- */
  var DRAW_KEY = 'pcd70.draws', drawMem = {}, drawCache = {};
  function drawUser() { return ls(DRAW_KEY) || {}; }
  function drawPacked(file) {
    var k = String(file || '').toLowerCase(); if (!k) return null;
    if (drawMem[k]) return drawMem[k];
    var u = drawUser(); if (u[k]) return u[k];
    var b = W.PCD_PROBE_DRAW || {}; return b[k] || null;
  }
  function drawGet(file) {
    var k = String(file || '').toLowerCase(); if (drawCache[k] !== undefined) return drawCache[k];
    var pk = drawPacked(k), r = null; try { if (pk && W.PcdDraw) r = W.PcdDraw.unpack(pk); } catch (e) { console.warn('r70 draw', k, e); }
    drawCache[k] = r; return r;
  }
  function drawImport(name, buf) {
    if (!W.PcdDraw) return { ok: false, msg: 'нет модуля PcdDraw' };
    var r = W.PcdDraw.parse(new Uint8Array(buf)), nt = r.parts.reduce(function (s, p) { return s + p.pos.length / 9; }, 0), k = name.toLowerCase();
    if (nt < 20) return { ok: false, msg: name + ': сетка не найдена (другая версия формата .DRAW)' };
    var pk = W.PcdDraw.pack(r); pk.src = name; drawMem[k] = pk; delete drawCache[k];
    var saved = false; try { var u = drawUser(); u[k] = pk; localStorage.setItem(DRAW_KEY, JSON.stringify(u)); saved = true; } catch (e) {}
    kinCache = {}; return { ok: true, msg: name + ': ' + nt + ' треуг., частей ' + r.parts.length + (saved ? '' : ' (не сохранено — мало места, только до перезагрузки)') };
  }
  function drawMesh(T, v, part, file, cache, color, ghost) {
    var d = drawGet(file); if (!d) return null;
    var P = null; d.parts.forEach(function (x) { if (x.part === part) P = x; }); if (!P) return null;
    var o = [v[0], v[1], v[2]], a = [v[3], v[4], v[5]], b = [v[6], v[7], v[8]], c = [v[9], v[10], v[11]], src = P.pos, n = src.length, dst = new Float32Array(n);
    for (var i = 0; i < n; i += 3) { var x = src[i] - o[0], y = src[i + 1] - o[1], z = src[i + 2] - o[2];
      dst[i] = a[0] * x + a[1] * y + a[2] * z; dst[i + 1] = b[0] * x + b[1] * y + b[2] * z; dst[i + 2] = c[0] * x + c[1] * y + c[2] * z; }
    var g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(dst, 3)); g.computeVertexNormals();
    var cc = P.color && (P.color[0] + P.color[1] + P.color[2]) > 0 && !(P.color[0] === 128 && P.color[1] === 128 && P.color[2] === 128) ? P.color : color;
    return new T.Mesh(g, mat(cache, cc, ghost));
  }
  /* chain: [{name, lines}] → { root (THREE.Group, координаты PC-DMIS, Z вверх), joints, tips, setAngles(A,B), tipLocal(i) } */
  function build(chainNames, opt) {
    var T = W.THREE; opt = opt || {}; if (!T) return null;
    Z = Z || new T.Vector3(0, 0, 1);
    var root = new T.Group(), cur = root, joints = [], tips = [], cache = {}, notes = [], lineMat = {};
    var resd = resolve(chainNames);
    chainNames.forEach(function (nm, ci) {
      var it = resd[ci].it; if (!it) { notes.push('нет компонента ' + nm); return; }
      var comp = new T.Group(); comp.name = nm; comp.userData.ci = ci; cur.add(comp);
      var f = comp, attach = null, color = [142, 142, 142], rib = 10, lines = null, tipOpen = null, pend = null, isHead = it.joints > 0, nCad = 0;
      /* cadgeom: r70 — сетка из .DRAW (pcdmis-draw-r70.js); если файл не прочитан — приближённая форма
         от начала текущей системы компонента до следующего шарнира / точки крепления */
      function flush(to) {
        if (!pend) return; var P0 = [0, 0, 0], dd = to ? len(to) : 0, mm = mat(cache, pend.c, opt.ghost), oo = null;
        if (!to) { oo = new T.Mesh(new T.BoxGeometry(24, 24, 24), mm); oo.position.set(0, 0, -12); }
        else if (dd < 1) { oo = new T.Mesh(new T.SphereGeometry(isHead ? 24 : 12, 28, 16), mm); }
        else { var D0 = isHead ? (pend.n === 1 ? 62 : 26) : Math.min(30, Math.max(8, dd * 0.6)); oo = segBetween(T, P0, to, D0 / 2, D0 / 2 * (isHead && pend.n === 1 ? 0.85 : 1), 28, mm);
          if (isHead && pend.n > 1) { var kn = new T.Mesh(new T.SphereGeometry(22, 28, 16), mm); pend.f.add(kn); } }
        if (oo) pend.f.add(oo); pend = null;
      }
      it.lines.forEach(function (raw) {
        var t = raw.trim().split(/\s+/), op = (t[0] || '').toLowerCase(), v = t.slice(1).map(Number), seg = Math.max(12, Math.min(40, rib * 2));
        var m = mat(cache, color, opt.ghost), o = null;
        try {
          switch (op) {
            case 'color': color = [v[0] | 0, v[1] | 0, v[2] | 0]; break;
            case 'ribcount': rib = v[0] || 10; break;
            case 'solid': break;
            case 'cylinder': case 'cutcylinder': o = segBetween(T, v.slice(0, 3), v.slice(3, 6), v[6] / 2, v[6] / 2, seg, m); break;
            case 'cone': o = segBetween(T, v.slice(0, 3), v.slice(4, 7), v[3] / 2, v[7] / 2, seg, m); break;
            case 'sphere': case 'cutsphere': o = new T.Mesh(new T.SphereGeometry(Math.max(v[3] / 2, 0.01), seg, Math.max(8, seg >> 1)), m); o.position.set(v[0], v[1], v[2]); break;
            case 'ring': o = new T.Mesh(new T.TorusGeometry(v[6] / 2, Math.max(0.2, (v[7] || 1) / 2), 8, seg * 2), m); o.position.set(v[0], v[1], v[2]); o.quaternion.setFromUnitVectors(Z, new T.Vector3(v[3], v[4], v[5]).normalize()); break;
            case 'line':
              var lk = col(color); if (!lineMat[lk]) lineMat[lk] = { pts: [], f: f }; if (lineMat[lk].f !== f) { lk += '_' + Math.random(); lineMat[lk] = { pts: [], f: f }; }
              lineMat[lk].pts.push(v[0], v[1], v[2], v[3], v[4], v[5]); lineMat[lk].c = col(color); break;
            case 'face': case 'polygon':
              var n = v[0] | 0, P = []; for (var q = 0; q < n; q++) P.push([v[1 + q * 3], v[2 + q * 3], v[3 + q * 3]]);
              if (n >= 3) { var pos = []; for (var q2 = 1; q2 < n - 1; q2++) pos.push.apply(pos, P[0].concat(P[q2], P[q2 + 1])); var gg = new T.BufferGeometry(); gg.setAttribute('position', new T.Float32BufferAttribute(pos, 3)); gg.computeVertexNormals(); o = new T.Mesh(gg, m); }
              break;
            case 'cadgeom': flush(null); nCad++;
              var dm = null; try { dm = drawMesh(T, v, v[12] | 0, t[t.length - 1], cache, color[0] === 142 && color[1] === 142 ? [62, 64, 70] : color, opt.ghost); } catch (e) { dm = null; }
              if (dm) { o = dm; if (nCad === 1) notes.push(nm + ': сетка из ' + t[t.length - 1]); break; }
              pend = { f: f, n: nCad, c: color[0] === 142 && color[1] === 142 ? [62, 64, 70] : color, file: t[t.length - 1] }; if (nCad === 1) notes.push(nm + ': форма из ' + (t[t.length - 1] || '.draw') + ' показана приближённо (сетка не прочитана)'); break;
            case 'autojoint': flush([v[0], v[1], v[2]]);
              var j = new T.Group(); j.position.set(v[0], v[1], v[2]); j.quaternion.setFromUnitVectors(Z, new T.Vector3(v[3], v[4], v[5]).normalize());
              var r = new T.Group(); j.add(r); f.add(j);
              joints.push({ node: r, comp: nm, axis: String(t[11] || '').toLowerCase(), cur: v[6], step: v[7] || 7.5, min: v[8], max: v[9] }); f = r; break;
            case 'connect': if (pend && pend.f === f) flush([v[0], v[1], v[2]]);
              var c = new T.Group(); c.position.set(v[0], v[1], v[2]); c.quaternion.setFromUnitVectors(Z, new T.Vector3(v[3], v[4], v[5]).normalize()); f.add(c);
              if (!attach) { attach = c; c.userData.mount = (t[7] || '').toUpperCase(); } break;
            case 'hotspot':
              var h = new T.Object3D(); h.position.set(v[0], v[1], v[2]); f.add(h);
              var hv = new T.Object3D(); hv.position.set(v[0] + v[3], v[1] + v[4], v[2] + v[5]); f.add(hv);
              tips.push({ node: h, vnode: hv, comp: nm, D: v[6], kind: (t[9] || 'ball').toLowerCase() }); break;
            case 'begintip': tipOpen = true; break;
            case 'endtip': tipOpen = null; break;
            default: break;
          }
        } catch (e) { notes.push(nm + ': ' + raw + ' — ' + e.message); }
        if (o) f.add(o);
      });
      flush(null);
      Object.keys(lineMat).forEach(function (k) { var x = lineMat[k]; if (!x.pts.length || x.done) return; var gg = new T.BufferGeometry(); gg.setAttribute('position', new T.Float32BufferAttribute(x.pts, 3));
        x.f.add(new T.LineSegments(gg, new T.LineBasicMaterial({ color: x.c }))); x.done = true; });
      lineMat = {};
      cur = attach || f;
    });
    var o = { root: root, joints: joints, tips: tips, notes: notes, chain: chainNames.slice(), tipIndex: 0, A: 0, B: 0 };
    o.setAngles = function (A, B) {
      o.A = A; o.B = B;
      joints.forEach(function (j) { var a = j.axis === 'a' ? A : j.axis === 'b' ? B : j.cur; j.node.rotation.set(0, 0, (a || 0) * Math.PI / 180); });
      root.updateMatrixWorld(true);
    };
    /* положение центра шарика и направление стержня (голова → шарик) в СК головки (PC-DMIS, мм) */
    o.tipLocal = function (A, B, ti) {
      if (A != null) o.setAngles(A, B);
      var t = tips[ti == null ? o.tipIndex : ti] || tips[tips.length - 1];
      if (!t) return { p: [0, 0, -100], d: [0, 0, -1], D: 2 };
      var inv = new W.THREE.Matrix4().copy(root.matrixWorld).invert();
      var p = new W.THREE.Vector3().setFromMatrixPosition(t.node.matrixWorld).applyMatrix4(inv), q = new W.THREE.Vector3().setFromMatrixPosition(t.vnode.matrixWorld).applyMatrix4(inv);
      var d = nrm([p.x - q.x, p.y - q.y, p.z - q.z]);
      return { p: [p.x, p.y, p.z], d: d, D: t.D || 2 };
    };
    o.dispose = function () { root.traverse(function (x) { if (x.geometry) x.geometry.dispose(); }); Object.keys(cache).forEach(function (k) { cache[k].dispose(); }); };
    o.setAngles(0, 0);
    return o;
  }
  /* проверка совместимости цепочки */
  function chainCheck(names) {
    var msg = [], prev = 'ARM', tip = false;
    names.forEach(function (n, i) {
      var it = item(n, prev); if (!it) { msg.push((i + 1) + ': нет в библиотеке ' + n); return; }
      var need = it.mountIn || '*', ok = need === '*' || need === prev || (need === 'TIP' && /^M\d/.test(prev)) || (prev === '*');
      if (!ok) msg.push((i + 1) + ': ' + n + ' крепится на «' + need + '», а предыдущий даёт «' + prev + '»');
      prev = it.mountOut || (it.hasTip ? '' : '*'); if (it.hasTip) tip = true;
      if (!it.mountOut && i < names.length - 1) msg.push((i + 1) + ': у ' + n + ' нет точки крепления (connect) — дальше ничего не присоединить');
    });
    if (!tip) msg.push('нет наконечника (hotspot) — центр шарика не определён');
    return msg;
  }

  /* ======================= активный щуп ======================= */
  var CFG_KEY = 'pcd69.probe', MAP_KEY = 'pcd69.map', OPT_KEY = 'pcd69.opt';
  function opts() { var o = ls(OPT_KEY) || {}; return { head: o.head || 'PROBEPH10MQ', auto: o.auto !== false, cmm: o.cmm !== false, cmmModel: o.cmmModel || 'LEGEND10128' }; }
  function setOpts(o) { var c = opts(); for (var k in o) c[k] = o[k]; ls(OPT_KEY, c); kinCache = {}; }
  function defCfg() { return { chain: [opts().head, 'SP25M', 'SM25-2', 'SH25-2', 'TIP6BY75MM'], A: 90, B: -90, tip: 0, from: 'по умолчанию' }; }
  /* цепочка для имени щупа программы: своя (сохранённая в конструкторе) или автоматическая */
  function chainFor(name) { var m = ls(MAP_KEY) || {}; if (name && m[name] && m[name].length) return m[name].slice(); return name ? chainFromProbeName(name) : cfg().chain; }
  function setChainFor(name, chain) { var m = ls(MAP_KEY) || {}; if (chain) m[name] = chain; else delete m[name]; ls(MAP_KEY, m); kinCache = {}; }
  function cfg() {
    var c = ls(CFG_KEY); if (c && c.chain && c.chain.length) return c;
    var st = S(), h = st && st.header || {}; if (h.probe1) { var ab = parseTip(h.probe2) || parseTip(h.probe1) || { A: 90, B: -90 }; return { chain: chainFromProbeName(h.probe1), A: ab.A, B: ab.B, tip: 0, from: 'программа: ' + h.probe1 }; }
    return defCfg();
  }
  function setCfg(c) { ls(CFG_KEY, c); kinCache = {}; if (play.obj) { disposePlay(); } }
  /* автоматическая сборка по строке ЗАГР/ЩУП программы, напр. «SM25-2_L75_D6», «TP20_TIP2BY20MM», «TESASTAR-P_D4_L40» */
  function chainFromProbeName(s) {
    s = String(s || '').toUpperCase(); var head = opts().head, ch = [head], m, D = null, Ln = null;
    /* пары «L<длина>_D<диаметр>» (SM25-2_L75_D6, SM25-3_5L50_D5_3L21_D5 → первая пара) */
    var re = /L(\d+(?:\.\d+)?)_D(\d+(?:[X.,]\d+)?)/g, pr = re.exec(s); if (pr) { Ln = +pr[1]; D = +pr[2].replace(/[X,]/, '.'); } /* D1X5 = Ø1.5; L200_L50_D5 — L200 = держатель SH25 */
    if (!pr) { if ((m = /_D(\d+(?:\.\d+)?)/.exec(s))) D = +m[1]; if ((m = /_L(\d+(?:\.\d+)?)/.exec(s))) Ln = +m[1]; }
    if ((m = /TIP([\d.]+)BY([\d.]+)MM/.exec(s))) { D = +m[1]; Ln = +m[2]; }
    var has = function (n, mnt) { var it = item(n, mnt); return it && it.name === n ? n : null; };
    var adM8 = has('CONVERT30MM_TO_M8THRD', 'QC') ? 'CONVERT30MM_TO_M8THRD' : null; /* QC (PH10MQ/PH10M) → резьба M8 */
    if ((m = /SM25-([1-5])/.exec(s))) { ch.push('SP25M', 'SM25-' + m[1]); if (has('SH25-' + m[1], 'SM25-' + m[1])) ch.push('SH25-' + m[1]); }
    else if (/TM25/.test(s)) ch.push('SP25M', 'TM25', /EM2/.test(s) ? 'TP20_EM2_MODULE' : /EM1/.test(s) ? 'TP20_EM1_MODULE' : /6WAY/.test(s) ? 'TP20_6WAY_MODULE' : 'TP20_MODULE');
    else if (/TP200/.test(s)) { if (adM8) ch.push(adM8); ch.push('PROBETP200', 'TP200SF'); }
    else if (/TP20/.test(s)) { if (adM8) ch.push(adM8); ch.push(/EM2/.test(s) && has('PROBE_TP20_EM2_113mm', 'M8') ? 'PROBE_TP20_EM2_113mm' : /EM1/.test(s) && has('PROBE_TP20_EM1_88mm', 'M8') ? 'PROBE_TP20_EM1_88mm' : has('PROBE_TP20', 'M8') ? 'PROBE_TP20' : 'PROBETP20'); }
    else if (/LSPX1|HP-S-X1/.test(s)) ch.push('PROBELSPX1H');
    else if (/TESASTAR-MP/.test(s)) ch.push('PROBETESASTAR-MP');
    else if (/TESASTAR/.test(s)) ch.push('PROBETESASTAR-P');
    else ch.push('SP25M', 'SM25-2', 'SH25-2');
    /* согласование креплений: QC→M8 — переходник, несовместимые лишние модули — убрать */
    var ch2 = [ch[0]], pv = (item(ch[0], 'ARM') || {}).mountOut || '*';
    ch.slice(1).forEach(function (n) { var it = item(n, pv); if (!it) return; if (it.mountIn !== pv && pv !== '*' && it.mountIn !== '*') { if (pv === 'QC' && it.mountIn === 'M8' && adM8) { ch2.push(adM8); pv = 'M8'; } else return; } ch2.push(n); pv = it.mountOut || '*'; });
    ch = ch2;
    var rs = resolve(ch), lastIt = rs[rs.length - 1].it, mnt = lastIt && lastIt.mountOut && /^M\d/.test(lastIt.mountOut) ? lastIt.mountOut : 'M2';
    D = D || 4; Ln = Ln || 40;
    var f = function (v) { return String(Math.round(v * 1000) / 1000); }, cand = ['TIP' + f(D) + 'BY' + f(Ln) + 'MM', 'TIP_' + f(D) + 'BY' + f(Ln) + 'MM'], tipN = null;
    cand.forEach(function (n) { var it = item(n, mnt); if (!tipN && it && it.mountIn === mnt && it.source === 'PROBE.DAT') tipN = n; });
    ch.push(tipN || L.tipDef(D, Ln, mnt).name);
    return ch;
  }
  function parseTip(s) { var m = /A\s*(-?\d+(?:\.\d+)?)\s*B\s*(-?\d+(?:\.\d+)?)/i.exec(String(s || '')); return m ? { A: +m[1], B: +m[2] } : null; }
  /* стержень по направлению «голова → шарик» d (PC-DMIS): A от −Z, B вокруг Z; A90B0 → −Y, A90B90 → +X, A90B−90 → −X */
  function abFromDir(d, step) {
    d = nrm(d); step = step || 7.5;
    var A = Math.acos(Math.max(-1, Math.min(1, -d[2]))) * 180 / Math.PI, B = Math.atan2(d[0], -d[1]) * 180 / Math.PI;
    if (A > 105) A = 105; A = Math.round(A / step) * step; B = Math.round(B / step) * step; if (B > 180) B -= 360; if (A < 0.1) B = 0;
    return { A: A, B: B };
  }
  var kinCache = {};
  /* кинематика щупа: name — имя щупа программы ('' — активный из конструктора) */
  function kinFor(name) {
    var key = name || ''; if (kinCache[key]) return kinCache[key];
    var c0 = cfg(), chain = name ? chainFor(name) : c0.chain, b = null; try { b = build(chain); } catch (e) { console.warn('r69 probe', e); }
    var cache = {};
    var k = { name: name || '', chain: chain, cfg: c0, b: b, tip: name ? 0 : (c0.tip || 0), at: function (A, B) { var kk = A + '/' + B; if (cache[kk]) return cache[kk]; var r = b ? b.tipLocal(A, B, k.tip) : { p: [-100 * Math.sin(A * Math.PI / 180) * -Math.sin(B * Math.PI / 180), -100 * Math.sin(A * Math.PI / 180) * Math.cos(B * Math.PI / 180), -100 * Math.cos(A * Math.PI / 180)], d: [0, 0, -1], D: 4 }; cache[kk] = r; return r; } };
    k.joint = function () { if (!k._j) { k._j = b ? jointOf(b) : [0, 0, -150]; } return k._j; };
    kinCache[key] = k; return k;
  }
  function kin() { return kinFor(''); }

  /* ======================= оценка времени ======================= */
  var PKEY = 'pcd68.time';
  var PDEF = { moveSpeed: 250, accel: 600, timePerHit: 1.1, timePerFastHit: 0.6, fastProbe: false, scanSpeed: 5, scanOverhead: 5, scanMin: 15,
    timePerTip: 6, timePerTool: 30, clearance: 30, timeMovePoint: 1.5, manualHit: 3, includeManual: true, timeOther: 0.05, additional: 0, k: 1, ref: 721, refFrom: 'op5 MiniRoutines.xml (12:01)', prehit: 2, tipByAngle: true, rackApproach: 60, rackLift: 45, rackDwell: 4, prgSpeeds: true };
  var PLAB = [
    ['moveSpeed', 'Скорость перемещения, мм/с', 'MOVE_SPEED / MoveSpeed'], ['accel', 'Ускорение, мм/с²', 'ACCELERATION'],
    ['timePerHit', 'Время на касание, с', 'TIME_PER_HIT (подвод + касание + отвод)'], ['timePerFastHit', 'Время на касание (FASTPROBE), с', 'TIME_PER_HIT_FASTPROBE'],
    ['scanSpeed', 'Скорость сканирования, мм/с', 'SCAN_SPEED'], ['scanOverhead', 'Подвод/отвод на скан, с', 'накладные на каждый скан'],
    ['scanMin', 'Скан, если точек ≥', 'иначе — дискретные касания'], ['timePerTip', 'Смена угла наконечника, с', 'TIME_PER_TIP'],
    ['timePerTool', 'Смена щупа (ЗАГР/ЩУП), с', 'TIME_PER_TOOLCHANGE'], ['clearance', 'Подъём до безоп. плоскости, мм', 'ПЕРЕМЕЩ/БЕЗОП.ПЛОСК'],
    ['timeMovePoint', 'ПЕРЕМЕЩ/ТОЧКА (нет координат), с', 'точки позиционирования'], ['manualHit', 'Ручное касание, с', 'элементы в ручном режиме'],
    ['timeOther', 'Прочая команда, с', 'OTHER: построения, СК, размеры'], ['prehit', 'Подвод / отвод, мм', 'PREHIT / RETRACT (r71)'], ['rackDwell', 'Магазин: оставить / взять модуль, с', 'выдержка в гнезде (r71)'], ['rackApproach', 'Магазин: подход к гнезду, мм', 'расстояние ввода в гнездо (r71)'], ['rackLift', 'Магазин: подъём над гнездом, мм', 'r71'], ['additional', 'Доп. время, с', 'AdditionalExecutionTime'], ['k', 'Коэффициент подгонки', '× ко всей оценке']
  ];
  function P() { var p = ls(PKEY) || {}; var o = {}; for (var k in PDEF) o[k] = p[k] != null ? p[k] : PDEF[k]; return o; }
  function trap(d, v, a) { if (d <= 0) return 0; var da = v * v / a; return d >= da ? d / v + v / a : 2 * Math.sqrt(d / a); }
  function trapFrac(t, T, d, v, a) { /* доля пути при трапециевидном профиле */
    if (T <= 0 || d <= 0) return 1; var ta = Math.min(v / a, T / 2), vp = a * ta, s;
    if (t < ta) s = 0.5 * a * t * t; else if (t > T - ta) { var r = T - t; s = d - 0.5 * a * r * r; } else s = 0.5 * a * ta * ta + vp * (t - ta);
    return Math.max(0, Math.min(1, s / d));
  }
  /* последовательность программы: команды из PRG (если есть) или элементы по порядку */
  var LAST = { cmds: null, file: '' };
  /* имя щупа ЗАГР/ЩУП лежит сразу за записью команды (≈ +162 байта от её начала), строка UTF-16 с префиксом FF FE FF n */
  var U16 = typeof TextDecoder !== 'undefined' ? new TextDecoder('utf-16le') : null;
  function probeNameAt(b, a, e) {
    e = Math.min(b.length - 4, e);
    for (var k = a; k < e; k++) if (b[k] === 0xff && b[k + 1] === 0xfe && b[k + 2] === 0xff) {
      var n = b[k + 3], q = k + 4; if (n === 0xff) { n = b[q] | (b[q + 1] << 8); q += 2; }
      if (n > 0 && n < 120 && q + n * 2 <= b.length) { var t = U16.decode(b.subarray(q, q + n * 2)); if (!/^(Загр|Load|Уст|Set)/i.test(t) && !/^T\d+A-?[\d.]+B-?[\d.]+$/i.test(t) && /^[\x21-\x7e]+$/.test(t)) return t; k = q + n * 2 - 1; }
    }
    return '';
  }
  /* r71: параметры команд нового образца лежат сразу за телом команды: …GUID, пустая CString (FF FE FF 00), 8 нулевых байт, данные (float32).
     CLEARANCE_PLANE: u32 ось (0 Z+, 1 X+, 2 Y+, 3 Z−, 4 X−, 5 Y−) + float значение; MOVE_POINT: X Y Z; MOVE_SPEED / SCAN_SPEED: значение (%, мм/с). */
  function cmdData(b, C) {
    var dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
    function f32(o) { return o + 4 <= b.length ? dv.getFloat32(o, true) : NaN; }
    for (var i = 0; i < C.length; i++) {
      var c = C[i], id = c.id; if (id !== 'CLEARANCE_PLANE' && id !== 'MOVE_POINT' && id !== 'MOVE_SPEED' && id !== 'SCAN_SPEED' && id !== 'TOUCH_SPEED') continue;
      var a = c.at + 6 + c.len, e = Math.min(b.length - 4, C[i + 1] ? C[i + 1].at : a + 80, a + 120), m = -1;
      for (var k = a; k < e; k++) if (b[k] === 0xff && b[k + 1] === 0xfe && b[k + 2] === 0xff && b[k + 3] === 0) { m = k + 12; break; }
      if (m < 0) continue;
      if (id === 'CLEARANCE_PLANE') { var ax = b[m] | (b[m + 1] << 8), v = f32(m + 4); if (ax <= 5 && isFinite(v) && Math.abs(v) < 1e5) c.cp = { ax: ax, a: ax % 3 === 0 ? 2 : ax % 3 === 1 ? 0 : 1, s: ax < 3 ? 1 : -1, v: v }; }
      else if (id === 'MOVE_POINT') { var P3 = [f32(m), f32(m + 4), f32(m + 8)]; if (P3.every(function (x) { return isFinite(x) && Math.abs(x) < 1e5; })) c.pt = P3.map(function (x) { return Math.round(x * 1000) / 1000; }); }
      else { var sv = f32(m); if (isFinite(sv) && sv > 0 && sv < 1e5) c.val = Math.round(sv * 1000) / 1000; }
    }
  }
  function hookPC() {
    try { if (W.PrgCommands && !W.PrgCommands.__r68) { var op = W.PrgCommands.parse; W.PrgCommands.parse = function (part) { var r = op.apply(this, arguments);
      try { if (r && r.commands && part && U16) r.commands.forEach(function (c) { if (c.id === 'GET_PROBE_DATA') { var nm = probeNameAt(part, c.at + 6, c.at + 6 + c.len + 40); if (nm) c.arg = nm; } }); } catch (e) { console.warn('r69 probe names', e); }
      try { if (r && r.commands && part) cmdData(part, r.commands); } catch (e) { console.warn('r71 cmd data', e); }
      LAST.cmds = r; LAST.at = Date.now(); kinCache = {}; return r; }; W.PrgCommands.__r68 = 1; } } catch (e) {}
  }
  hookPC();
  function program() {
    var st = S(), els = (st && st.elements) || [], by = {}, seq = [], src = 'элементы';
    els.forEach(function (e) { by[e.name] = e; });
    var c = LAST.cmds, hit = 0, used = {};
    if (c && c.features && c.features.length) c.features.forEach(function (f) { if (by[f.name]) hit++; });
    if (c && hit >= Math.max(1, c.features.length * 0.5)) {
      src = 'команды PRG'; var manual = false, first = true;
      c.commands.forEach(function (r) {
        var id = r.id;
        if (id === 'MAN_DCC_MODE') { manual = /ручн|man/i.test(r.label) && !/ЧПУ|DCC/i.test(r.label); return; }
        if (id === 'SET_ACTIVE_TIP') { seq.push({ k: 'tip', name: r.arg, ab: parseTip(r.arg), group: r.group, cmd: r }); return; }
        if (id === 'GET_PROBE_DATA') { var pn = String(r.arg || '').trim(); if (/^(Загр|Load)/i.test(pn)) pn = ''; seq.push({ k: first ? 'probe0' : 'probe', name: pn, group: r.group, cmd: r }); first = false; return; }
        if (id === 'MOVE_CLEARP') { seq.push({ k: 'clear', group: r.group }); return; }
        if (id === 'CLEARANCE_PLANE') { if (r.cp) seq.push({ k: 'cplane', cp: r.cp, group: r.group, ci: r.i }); return; }
        if (id === 'MOVE_SPEED' || id === 'SCAN_SPEED' || id === 'TOUCH_SPEED') { if (r.val) seq.push({ k: 'speed', id: id, val: r.val }); return; }
        if (id === 'MOVE_POINT' || id === 'MOVE_SWEEP_POINT' || id === 'MOVE_INCREMENT') { seq.push({ k: 'movept', group: r.group, label: r.label, pt: id === 'MOVE_POINT' ? r.pt : null, ci: r.i }); return; }
        if (r.feature && by[r.feature.name]) { seq.push({ k: 'feat', el: by[r.feature.name], manual: manual, group: r.group }); used[r.feature.name] = 1; return; }
        if (id === 'MEASURED_POINT') { seq.push({ k: 'mpoint', name: r.arg, manual: manual, group: r.group }); return; }
        if (r.cat === 'hit' || /^END_|_END$/.test(id) || id === 'FILE_HEADER') return;
        if (/^DIMENSION_(START|2D|3D|TRUE_START)|^CONST_|ALIGN$|^START_ALIGN|^(LEVEL|ROTATE|TRANS)_/.test(id)) seq.push({ k: 'other', label: r.arg ? r.ru + ' ' + r.arg : r.ru, group: r.group });
      });
      els.forEach(function (e) { if (!used[e.name] && (e._hits || /plane|circle|cylinder|cone|sphere|point|line|slot/.test(e.type))) seq.push({ k: 'clear' }, { k: 'feat', el: e, group: e.group }); });
    } else {
      els.forEach(function (e) { if (/constr|построен/i.test(e.type)) { seq.push({ k: 'other', label: e.name }); return; } seq.push({ k: 'clear', group: e.group }, { k: 'feat', el: e, group: e.group }); });
    }
    var probes = []; seq.forEach(function (x) { if ((x.k === 'probe0' || x.k === 'probe') && x.name && probes.indexOf(x.name) < 0) probes.push(x.name); });
    if (!probes.length) { var hh = st && st.header || {}; if (hh.probe1) probes.push(String(hh.probe1)); }
    return { seq: seq, src: src, probes: probes };
  }
  /* имена щупов программы (ЗАГР/ЩУП) */
  function programProbes() { try { return program().probes; } catch (e) { return []; } }
  function hitsOf(e) {
    var out = [];
    if (e._hits && e._hits.length) e._hits.forEach(function (h) { if (h && h.length >= 3) out.push([+h[0], +h[1], +h[2], +h[3] || 0, +h[4] || 0, h[5] == null ? 1 : +h[5]]); });
    else { var a = api(); try { (a && a.hitsFor ? a.hitsFor(e) : []).forEach(function (h) { out.push([h.p[0], h.p[1], h.p[2], h.n[0], h.n[1], h.n[2]]); }); } catch (x) {} }
    if (!out.length) {
      var c = [num(e.x), num(e.y), num(e.z)], n = nrm([num(e.i), num(e.j), num(e.k, 1)]), N = Math.max(1, Math.min(50, Math.round(num(e.points, 4)))), u = nrm(Math.abs(n[2]) < 0.9 ? [n[1], -n[0], 0] : [1, 0, 0]), v = [n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0]];
      var R = e.type === 'plane' ? 15 : Math.max(1, num(e.diam, 10) / 2);
      for (var i = 0; i < N; i++) { var a2 = 2 * Math.PI * i / N, p = addv(addv(c, u, R * Math.cos(a2)), v, R * Math.sin(a2)); out.push(p.concat(n)); }
    }
    return out;
  }
  /* r71: смена угла — время зависит от поворота (PH10: 7.5°-индексация), база timePerTip соответствует повороту на 90° */
  function tipTime(p, a0, a1) { var d = Math.max(Math.abs(a1.A - a0.A), Math.abs(((a1.B - a0.B + 540) % 360) - 180)); return p.tipByAngle ? p.timePerTip * (0.4 + 0.6 * Math.min(2, d / 90)) : p.timePerTip; }
  function estimate(p, lay) {
    p = p || P(); var pr = program(), cfg0 = cfg(), seq = pr.seq, auto = opts().auto && pr.probes.length;
    var RK = rackCfg(), rack = null, layBB = null;
    if (lay !== 'pass1' && RK.on && auto && pr.probes.length > 1) {
      try { var e1 = estimate(p, 'pass1'); layBB = headBox(e1); rack = rackPlace(RK, cmmLayout(opts().cmmModel, layBB), pr.probes); } catch (er) { console.warn('r71 rack', er); rack = null; }
    }
    var pk = auto ? pr.probes[0] : '', K = kinFor(pk), probesUsed = {}; probesUsed[pk] = K.chain;
    var rBall = K.at(cfg0.A, cfg0.B).D / 2 || 2;
    var ab = { A: cfg0.A, B: cfg0.B }, tl = K.at(ab.A, ab.B), pos = null, pendingClear = true, segs = [], rows = [], t = 0, cp = null, bareNow = false, speeds = {};
    if (auto) for (var q0 = 0; q0 < seq.length; q0++) { if (seq[q0].k === 'tip' && seq[q0].ab) { ab = seq[q0].ab; tl = K.at(ab.A, ab.B); break; } if (seq[q0].k === 'feat') break; }
    var cats = { move: 0, hit: 0, scan: 0, tip: 0, tool: 0, manual: 0, other: 0 }, totals = { hits: 0, scans: 0, scanLen: 0, moveLen: 0, tips: 0, tools: 0, cplanes: 0, movepts: 0 };
    var vsPrg = 0, v = Math.max(1, p.moveSpeed), acc = Math.max(1, p.accel), row = null;
    function seg(kind, p0, p1, dt, extra) { var s = { kind: kind, t0: t, t1: t + dt, p0: p0, p1: p1, ab0: extra && extra.ab0 || ab, ab1: extra && extra.ab1 || ab, prof: extra && extra.prof, d: extra && extra.d, row: rows.length - 1, pk: pk, pk0: extra && extra.pk0 != null ? extra.pk0 : pk }; if (bareNow) s.bare = 1; if (extra && extra.pkN) s.pkN = extra.pkN; segs.push(s); t += dt; if (row) row.t += dt; return s; }
    function move(to, cat) {
      if (!pos) { pos = to.slice(); return 0; }
      var d = len(sub(to, pos)); if (d < 1e-6) return 0;
      var dt = trap(d, v, acc); seg('move', pos, to, dt, { prof: 'trap', d: d }); cats[cat || 'move'] += dt; totals.moveLen += d; if (row) row.path += d; pos = to.slice(); return dt;
    }
    function up() { return nrm([-tl.d[0], -tl.d[1], -tl.d[2]]); }
    function onPlane(q) { var r = q.slice(); r[cp.a] = cp.v; return r; }
    function newRow(o) { row = { label: o.label, kind: o.kind, group: o.group || '', el: o.el || null, hits: 0, path: 0, t: 0, t0: t }; rows.push(row); return row; }
    function tipTo(nab, cat) { var hp = sub(pos, tl.p), ntl = K.at(nab.A, nab.B), np = addv(hp, ntl.p), dt = tipTime(p, ab, nab); seg('tip', pos, np, dt, { ab0: ab, ab1: nab }); cats[cat || 'tip'] += dt; if (!cat) totals.tips++; pos = np; ab = nab; tl = ntl; }
    /* r71: смена щупа через магазин — отвести вверх, A0B0, подъехать к гнезду, оставить модуль, перейти к гнезду нового, взять, выйти */
    function rackChange(s) {
      var po = rack.port[pk], pn = rack.port[s.name], K1 = kinFor(s.name);
      newRow({ label: 'Магазин ' + rack.name + ': ' + (pk || '?') + ' (гн. ' + (po.i + 1) + ') → ' + s.name + ' (гн. ' + (pn.i + 1) + ')', kind: 'tool', group: s.group });
      var t0r = t;
      if (!pos) pos = addv(addv(po.p, po.ap, p.rackApproach), [0, 0, 120]);
      if (cp && cp.a !== 2) move(onPlane(pos), 'tool');
      move([pos[0], pos[1], Math.max(pos[2], rack.safeZ)], 'tool');
      if (ab.A || ab.B) tipTo({ A: 0, B: 0 }, 'tool');
      var j0 = K.joint(), ball = function (J, KK, jj) { return addv(sub(J, jj), KK.at(0, 0).p); };
      var A0 = addv(po.p, po.ap, p.rackApproach), b0 = ball(A0, K, j0);
      move([b0[0], b0[1], Math.max(pos[2], rack.safeZ)], 'tool'); move(b0, 'tool'); move(ball(po.p, K, j0), 'tool');
      seg('drop', pos, pos, p.rackDwell, { pk0: pk }); bareNow = true;
      var lift = [0, 0, p.rackLift];
      move(ball(addv(po.p, lift), K, j0), 'tool'); move(ball(addv(pn.p, lift), K, j0), 'tool'); move(ball(pn.p, K, j0), 'tool');
      seg('pick', pos, pos, p.rackDwell, { pk0: pk, pkN: s.name }); bareNow = false;
      pk = s.name; K = K1; probesUsed[pk] = K.chain; tl = K.at(0, 0); rBall = tl.D / 2 || 2;
      pos = ball(pn.p, K, K.joint());
      var A1 = ball(addv(pn.p, pn.ap, p.rackApproach), K, K.joint()); move(A1, 'tool'); move([A1[0], A1[1], Math.max(A1[2], rack.safeZ)], 'tool');
      cats.tool += 0; totals.tools++; row.rack = 1; pendingClear = true; return t - t0r;
    }
    seq.forEach(function (s, si) {
      if (s.k === 'cplane') { cp = s.cp; totals.cplanes++; return; }
      if (s.k === 'speed') { speeds[s.id] = s.val; if (p.prgSpeeds) { if (s.id === 'MOVE_SPEED' && s.val > 0 && s.val <= 100) v = Math.max(1, p.moveSpeed * s.val / 100); if (s.id === 'SCAN_SPEED' && s.val >= 0.1 && s.val <= 500) vsPrg = s.val; } return; }
      if (s.k === 'clear') { if (pos && cp) move(onPlane(pos)); pendingClear = true; return; }
      if (s.k === 'tip') {
        var nab = s.ab || ab; if (pos && (nab.A !== ab.A || nab.B !== ab.B)) {
          newRow({ label: 'Наконечник ' + (s.name || ''), kind: 'tip', group: s.group });
          if (!cp) move(addv(pos, up(), p.clearance));
          tipTo(nab); pendingClear = true; return;
        }
        ab = nab; tl = K.at(ab.A, ab.B); return;
      }
      if (s.k === 'probe0') { if (auto && s.name && s.name !== pk) { pk = s.name; K = kinFor(pk); probesUsed[pk] = K.chain; tl = K.at(ab.A, ab.B); rBall = tl.D / 2 || 2; } return; }
      if (s.k === 'probe') {
        if (auto && s.name && s.name === pk) return; /* тот же щуп — PC-DMIS ничего не делает */
        if (rack && auto && s.name && rack.port[pk] && rack.port[s.name]) { rackChange(s); return; }
        newRow({ label: 'Смена щупа (ЗАГР/ЩУП)' + (s.name ? ' ' + s.name : ''), kind: 'tool', group: s.group });
        var pkOld = pk, p0t = pos || [0, 0, 0];
        if (auto && s.name) { pk = s.name; K = kinFor(pk); probesUsed[pk] = K.chain; }
        var hpT = sub(p0t, tl.p); tl = K.at(ab.A, ab.B); rBall = tl.D / 2 || 2; var p1t = pos ? addv(hpT, tl.p) : p0t;
        seg('tool', p0t, p1t, p.timePerTool, { pk0: pkOld }); if (pos) pos = p1t; cats.tool += p.timePerTool; totals.tools++; pendingClear = true; return; }
      if (s.k === 'movept') {
        if (s.pt) { newRow({ label: 'ПЕРЕМЕЩ/ТОЧКА ' + s.pt.join(', '), kind: 'move', group: s.group }); move(s.pt); totals.movepts++; pendingClear = false; return; }
        newRow({ label: s.label || 'ПЕРЕМЕЩ/ТОЧКА', kind: 'move', group: s.group }); seg('wait', pos || [0, 0, 0], pos || [0, 0, 0], p.timeMovePoint); cats.move += p.timeMovePoint; return; }
      if (s.k === 'other') { if (p.timeOther > 0) { newRow({ label: s.label, kind: 'other', group: s.group }); seg('wait', pos || [0, 0, 0], pos || [0, 0, 0], p.timeOther); cats.other += p.timeOther; } return; }
      if (s.k === 'mpoint') {
        if (s.manual && !p.includeManual) return;
        newRow({ label: 'Точка ' + (s.name || ''), kind: s.manual ? 'manual' : 'hit', group: s.group }); row.hits = 1; totals.hits++;
        var dtm = s.manual ? p.manualHit : (p.fastProbe ? p.timePerFastHit : p.timePerHit); seg('hit', pos || [0, 0, 0], pos || [0, 0, 0], dtm); cats[s.manual ? 'manual' : 'hit'] += dtm; return;
      }
      if (s.k !== 'feat') return;
      var e = s.el; if (s.manual && !p.includeManual) return;
      var H = hitsOf(e); if (!H.length) return;
      if (!seq.some(function (x) { return x.k === 'tip' && x.ab; })) {
        var na = abFromDir([-H[0][3], -H[0][4], -H[0][5]], 7.5);
        if (na.A !== ab.A || na.B !== ab.B) { if (pos) { newRow({ label: 'Наконечник A' + na.A + 'B' + na.B, kind: 'tip', group: s.group }); move(addv(pos, up(), p.clearance)); tipTo(na); } ab = na; tl = K.at(ab.A, ab.B); pendingClear = true; }
      }
      var C = H.map(function (h) { return [h[0] + h[3] * rBall, h[1] + h[4] * rBall, h[2] + h[5] * rBall]; });
      var sl = 0; for (var i = 1; i < C.length; i++) sl += len(sub(C[i], C[i - 1]));
      var isScan = !s.manual && C.length >= p.scanMin && sl / Math.max(1, C.length - 1) < 3;
      newRow({ label: e.name, kind: s.manual ? 'manual' : isScan ? 'scan' : 'hit', group: s.group || e.group, el: e }); row.hits = C.length;
      var pre = p.prehit, n0 = [H[0][3], H[0][4], H[0][5]], appr = addv(C[0], n0, pre);
      /* r71: переход через безопасную плоскость: подъём по оси плоскости → движение в плоскости → спуск к подводу */
      if (pendingClear && pos) { if (cp) { move(onPlane(pos)); move(onPlane(appr)); } else { var uu = up(); move(addv(pos, uu, p.clearance)); move(addv(appr, uu, p.clearance)); } }
      move(appr);
      if (isScan) {
        var dts = p.scanOverhead / 2; seg('wait', pos, pos, dts); cats.scan += dts;
        move(C[0], 'scan'); var d0 = 0, vs = Math.max(0.1, vsPrg || p.scanSpeed);
        for (var j = 1; j < C.length; j++) { var dd = len(sub(C[j], C[j - 1])); if (dd > 3 * Math.max(1, sl / Math.max(1, C.length - 1)) && dd > 5) { var nj = [H[j][3], H[j][4], H[j][5]]; move(addv(pos, [H[j - 1][3], H[j - 1][4], H[j - 1][5]], pre)); move(addv(C[j], nj, pre)); move(C[j], 'scan'); continue; } var dtj = dd / vs; seg('scan', C[j - 1], C[j], dtj); cats.scan += dtj; d0 += dd; pos = C[j]; }
        row.path += d0; totals.scanLen += d0; totals.scans++; pos = C[C.length - 1].slice();
        var back = addv(pos, [H[H.length - 1][3], H[H.length - 1][4], H[H.length - 1][5]], pre); seg('scan', pos, back, dts); cats.scan += dts; pos = back;
      } else {
        for (var k = 0; k < C.length; k++) {
          var nk = [H[k][3], H[k][4], H[k][5]], ap = addv(C[k], nk, pre);
          if (k) move(ap); var dth = s.manual ? p.manualHit : (p.fastProbe ? p.timePerFastHit : p.timePerHit);
          seg('hit', ap, C[k], dth * 0.5); seg('hit', C[k], ap, dth * 0.5); cats[s.manual ? 'manual' : 'hit'] += dth; pos = ap;
        }
        totals.hits += C.length;
      }
      pendingClear = false;
    });
    for (var fi = 0; fi < segs.length; fi++) if (segs[fi].kind === 'move' || segs[fi].kind === 'hit' || segs[fi].kind === 'scan') { var fp = segs[fi].p0; for (var fj = 0; fj < fi; fj++) { segs[fj].p0 = fp; segs[fj].p1 = fp; } break; }
    var raw = t, total = raw * p.k + p.additional;
    return { total: total, raw: raw, segs: segs, rows: rows, cats: cats, totals: totals, src: pr.src, p: p, ab0: { A: cfg0.A, B: cfg0.B }, probes: probesUsed, auto: !!auto, rack: rack, layBB: layBB, speeds: speeds };
  }

  /* ======================= окно «Время выполнения» ======================= */
  var KIND = { move: 'перемещение', hit: 'касания', scan: 'скан', tip: 'смена угла', tool: 'смена щупа', manual: 'ручной', other: 'прочее' };
  var CSS = [
    '.p68 table{border-collapse:collapse;width:100%;font-size:11.5px}.p68 th,.p68 td{border-bottom:1px solid #ddd;padding:2px 5px;text-align:left;white-space:nowrap}',
    '.p68 th{background:#e8eef5;position:sticky;top:0;z-index:1}.p68 td.n{text-align:right;font-variant-numeric:tabular-nums}.p68 tr.cur td{background:#ffe9a8}.p68 tbody tr:hover td{background:#e5f1fb;cursor:pointer}',
    '.p68 .big{font-size:22px;font-weight:600;color:#0a5aa0;font-variant-numeric:tabular-nums}.p68 .row{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:4px 0}',
    '.p68 .grid{display:grid;grid-template-columns:auto 80px;gap:3px 8px;align-items:center}.p68 .grid input{width:76px}.p68 .bar{display:flex;height:14px;border:1px solid #bbb;margin:4px 0}.p68 .bar span{display:block;height:100%}',
    '.p68 .mut{color:#666;font-size:11px}.p68 .cap{font-weight:600;margin:8px 0 3px}.p68 select{max-width:100%}.p68 .warn{color:#b04000}',
    '#p68play{position:absolute;left:50%;bottom:34px;transform:translateX(-50%);z-index:50;background:rgba(245,247,250,.96);border:1px solid #889;border-radius:4px;padding:5px 8px;display:flex;gap:6px;align-items:center;font:12px "Segoe UI",Tahoma,sans-serif;box-shadow:0 3px 12px rgba(0,0,0,.25)}',
    '#p68play select{width:105px !important;min-width:0 !important}#p68play .ab{white-space:nowrap}#p68play button{height:22px;min-width:26px}#p68play input[type=range]{width:200px}#p68play .clk{font:600 14px Consolas,monospace;color:#0a5aa0;min-width:150px;text-align:center}#p68play .lb{max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#333}'
  ].join('\n');
  var COLORS = { move: '#5b9bd5', hit: '#ed7d31', scan: '#70ad47', tip: '#ffc000', tool: '#7030a0', manual: '#c00000', other: '#a5a5a5' };
  var lastEst = null, timeWin = null;
  function openTime() {
    var a = api(); if (!a) { alert('Интерфейс r57 не загружен'); return; }
    var w = a.win('p68time', 'Время выполнения программы (оценка)', 'feat', 760); timeWin = w; w.el.classList.add('p68');
    w.body.style.maxHeight = '72vh';
    function draw() {
      var p = P(), E; try { E = estimate(p); } catch (err) { w.body.innerHTML = '<div class="warn">Ошибка оценки: ' + esc(err.message) + '</div>'; console.error(err); return; }
      lastEst = E;
      var ref = num(p.ref, 0), diff = ref ? (E.total - ref) / ref * 100 : null, c = E.cats, tot = Object.keys(c).reduce(function (s, k) { return s + c[k]; }, 0) || 1;
      var h = [];
      h.push('<div class="row"><span class="big">' + hms(E.total) + '</span><span>≈ ' + (E.total / 60).toFixed(1) + ' мин (' + Math.round(E.total) + ' с)</span>' +
        (ref ? '<span class="mut">PC-DMIS: <b>' + hms(ref) + '</b> ' + esc(p.refFrom || '') + ' · разница ' + (diff >= 0 ? '+' : '') + diff.toFixed(1) + '%</span>' : '') + '</div>');
      h.push('<div class="mut">Источник: ' + esc(E.src) + ' · касаний ' + E.totals.hits + ' · сканов ' + E.totals.scans + ' (' + Math.round(E.totals.scanLen) + ' мм) · перемещений ' + Math.round(E.totals.moveLen) + ' мм · смен угла ' + E.totals.tips + ' · смен щупа ' + E.totals.tools + ' · щуп: ' + esc(cfg().chain.join(' → ')) + '</div>');
      try { var pkk = Object.keys(E.probes || {}); if (pkk.length) h.push('<div class="mut">Щуп' + (pkk.length > 1 ? 'и (смена по ЗАГР/ЩУП)' : '') + ': ' + pkk.map(function (k) { return '<b>' + esc(k || 'активный') + '</b> = ' + esc((E.probes[k] || []).join(' → ')); }).join('<br>') + '</div>'); } catch (e) {}
      h.push('<div class="bar">' + Object.keys(c).map(function (k) { return c[k] > 0 ? '<span title="' + KIND[k] + ': ' + ms(c[k] * p.k) + '" style="width:' + (c[k] / tot * 100) + '%;background:' + COLORS[k] + '"></span>' : ''; }).join('') + '</div>');
      h.push('<div class="row">' + Object.keys(c).map(function (k) { return c[k] > 0 ? '<span><span style="display:inline-block;width:9px;height:9px;background:' + COLORS[k] + '"></span> ' + KIND[k] + ' ' + ms(c[k] * p.k) + '</span>' : ''; }).join('') + '</div>');
      h.push('<div style="display:flex;gap:10px"><div style="flex:1;min-width:0"><div class="cap">По шагам программы (клик — перейти в 3D-прогоне)</div><div style="max-height:44vh;overflow:auto;border:1px solid #ccc;background:#fff"><table><thead><tr><th>#</th><th>Шаг</th><th>Группа</th><th>Тип</th><th>Касаний</th><th>Путь, мм</th><th>Время</th><th>Старт</th></tr></thead><tbody>');
      E.rows.forEach(function (r, i) { h.push('<tr data-i="' + i + '"><td class="n">' + (i + 1) + '</td><td>' + esc(r.label) + '</td><td>' + esc(r.group) + '</td><td>' + KIND[r.kind] + '</td><td class="n">' + (r.hits || '') + '</td><td class="n">' + (r.path ? r.path.toFixed(0) : '') + '</td><td class="n">' + ms(r.t * p.k) + '</td><td class="n">' + hms(r.t0 * p.k) + '</td></tr>'); });
      h.push('</tbody></table></div></div><div style="width:255px"><div class="cap">Параметры (как в ExecutionTimeDb PC-DMIS)</div><div class="grid">');
      PLAB.forEach(function (x) { h.push('<label title="' + esc(x[2]) + '">' + esc(x[1]) + '</label><input data-k="' + x[0] + '" value="' + esc(p[x[0]]) + '">'); });
      h.push('<label>Быстрые касания (FASTPROBE)</label><input type="checkbox" data-k="fastProbe"' + (p.fastProbe ? ' checked' : '') + '><label>Учитывать ручные элементы</label><input type="checkbox" data-k="includeManual"' + (p.includeManual ? ' checked' : '') + '><label>Скорости из программы (MOVE_SPEED %, SCAN_SPEED мм/с)</label><input type="checkbox" data-k="prgSpeeds"' + (p.prgSpeeds ? ' checked' : '') + '><label>Время смены угла по углу поворота</label><input type="checkbox" data-k="tipByAngle"' + (p.tipByAngle ? ' checked' : '') + '>');
      h.push('<label title="Время из MiniRoutines.xml или замер">Эталон PC-DMIS, с</label><input data-k="ref" value="' + esc(p.ref) + '"></div>');
      h.push('<div class="row"><button class="b" data-a="xml">MiniRoutines.xml…</button><button class="b" data-a="fit" title="Подобрать коэффициент так, чтобы оценка совпала с эталоном">Подогнать</button><button class="b" data-a="reset">Сброс</button></div>');
      h.push('<div class="mut">Модель: перемещения — трапеция (скорость + ускорение) с подъёмом к безопасной плоскости; касание — TIME_PER_HIT; скан — длина пути / скорость + накладные; смены угла/щупа — TIME_PER_TIP / TIME_PER_TOOLCHANGE. По умолчанию откалибровано по op5 (PC-DMIS 12:01).</div></div></div>');
      w.body.innerHTML = h.join('');
      [].forEach.call(w.body.querySelectorAll('input[data-k]'), function (inp) {
        inp.addEventListener('change', function () { var q = ls(PKEY) || {}; q[inp.getAttribute('data-k')] = inp.type === 'checkbox' ? inp.checked : num(inp.value, PDEF[inp.getAttribute('data-k')]); if (inp.getAttribute('data-k') === 'ref') q.refFrom = 'введено вручную'; ls(PKEY, q); draw(); if (play.est) rebuildPlay(); });
      });
      w.body.querySelector('[data-a=fit]').onclick = function () { var q = ls(PKEY) || {}, pp = P(); if (!pp.ref) { toast('Задайте эталон'); return; } q.k = Math.round((pp.ref - pp.additional) / Math.max(1, E.raw) * 1000) / 1000; ls(PKEY, q); draw(); toast('Коэффициент ' + q.k); };
      w.body.querySelector('[data-a=reset]').onclick = function () { ls(PKEY, {}); draw(); };
      w.body.querySelector('[data-a=xml]').onclick = function () { pickFile('.xml', function (txt, name) { var m = /EntireRoutine[^>]*Time="(\d+):(\d+):(\d+)"/i.exec(txt); if (!m) { toast('В файле нет EntireRoutine Time'); return; } var q = ls(PKEY) || {}; q.ref = +m[1] * 3600 + +m[2] * 60 + +m[3]; q.refFrom = name + ' (' + m[1] + ':' + m[2] + ':' + m[3] + ')'; ls(PKEY, q); draw(); }); };
      w.body.querySelector('tbody').onclick = function (ev) { var tr = ev.target.closest('tr'); if (!tr) return; var r = E.rows[+tr.getAttribute('data-i')]; startPlay(r ? r.t0 : 0, true); };
    }
    w.foot.innerHTML = ''; w.foot.style.cssText = 'display:flex;gap:6px;justify-content:flex-end;padding:6px 10px';
    var a2 = api();
    w.foot.appendChild(a2.btn('▶ Прогон щупа в 3D', function () { startPlay(0); }, 'def'));
    w.foot.appendChild(a2.btn('Конструктор щупа…', openBuilder));
    w.foot.appendChild(a2.btn('CSV', function () { if (!lastEst) return; var pk = lastEst.p.k; var csv = ['#;Шаг;Группа;Тип;Касаний;Путь мм;Время с;Старт'].concat(lastEst.rows.map(function (r, i) { return [i + 1, r.label, r.group, KIND[r.kind], r.hits, r.path.toFixed(1), (r.t * pk).toFixed(2), hms(r.t0 * pk)].join(';'); })); csv.push(';ИТОГО;;;;;' + lastEst.total.toFixed(1) + ';' + hms(lastEst.total)); download('время-выполнения.csv', '\uFEFF' + csv.join('\r\n'), 'text/csv'); }));
    w.foot.appendChild(a2.btn('Обновить', draw));
    w.foot.appendChild(a2.btn('Закрыть', function () { w.close(); }));
    w.redraw = draw; draw();
  }
  function pickFile(acc, cb, bin) { var i = document.createElement('input'); i.type = 'file'; i.accept = acc; i.onchange = function () { var f = i.files[0]; if (!f) return; var r = new FileReader(); r.onload = function () { var t = r.result; if (bin) { var u = new Uint8Array(t); t = (u[0] === 0xFF && u[1] === 0xFE) ? new TextDecoder('utf-16le').decode(u) : (function () { try { return new TextDecoder('utf-8', { fatal: true }).decode(u); } catch (e) { return new TextDecoder('windows-1251').decode(u); } })(); } cb(t, f.name); }; if (bin) r.readAsArrayBuffer(f); else r.readAsText(f); }; i.click(); }
  function download(name, text, type) { var b = new Blob([text], { type: type || 'text/plain' }), u = URL.createObjectURL(b), x = document.createElement('a'); x.href = u; x.download = name; document.body.appendChild(x); x.click(); setTimeout(function () { URL.revokeObjectURL(u); x.remove(); }, 500); }

  /* ======================= 3D-прогон ======================= */
  var play = { est: null, obj: null, objs: {}, wrap: null, path: null, done: null, t: 0, speed: 10, on: false, last: 0, raf: 0, bar: null, imported: null, cmm: null };
  function disposePlay() {
    try { if (play.wrap && play.wrap.parent) play.wrap.parent.remove(play.wrap); } catch (e) {}
    try { Object.keys(play.objs).forEach(function (k) { play.objs[k].dispose(); }); } catch (e) {}
    try { if (play.cmm) play.cmm.dispose(); } catch (e) {}
    try { if (play.rack) play.rack.dispose(); Object.keys(play.docked || {}).forEach(function (k) { play.docked[k].dispose(); }); } catch (e) {}
    play.obj = null; play.objs = {}; play.wrap = null; play.path = null; play.cmm = null; play.rack = null; play.docked = {};
  }
  function curEst() { return play.imported || estimate(); }
  function rebuildPlay() { var t = play.t; play.est = curEst(); play.t = Math.min(t, play.est.raw); ensureScene(true); updatePlay(); }

  /* ---------- r70: модель КИМ AEH Legend по паспорту (табл. 2.1, рис. 2.1 РЭ «КИМ серии Legend») ----------
     Lx Ly Lz — габариты; Dx Dy Dz — диапазон измерений; H1/H2 — запас стола по Y до/после диапазона; W1/W2 — от стоек до диапазона по X;
     h1 — от верха диапазона Z до низа траверсы; Px Py Pz — плита (стол) и её толщина; H — высота от пола до плиты; Lx1 Ly1 — перемещение портала;
     Sx Sy — расстояние между опорами; ram — сечение пиноли Z; kg — вес; load — нагрузка на стол; mpe — MPE_E (SP25), мкм */
  var LEG = [
    ['575', 1330, 1820, 2640, 500, 700, 500, 240, 450, 185, 185, 270, 890, 1380, 235, 700, 640, 720, 660, [780], 80, 1500, 800, '±(1,3+L/300)'],
    ['5105', 1330, 2120, 2640, 500, 1000, 500, 240, 450, 185, 185, 270, 890, 1380, 235, 700, 640, 1020, 660, [980], 80, 1700, 800, '±(1,3+L/350)'],
    ['7107', 1530, 2120, 3000, 700, 1000, 700, 240, 450, 185, 185, 270, 1090, 1680, 235, 700, 840, 1020, 860, [980], 80, 2000, 1000, '±(1,5+L/300)'],
    ['7157', 1530, 2620, 3000, 700, 1500, 700, 240, 450, 185, 185, 270, 1090, 2180, 235, 700, 840, 1520, 860, [1480], 80, 2400, 1000, '±(1,5+L/300)'],
    ['10128', 1960, 2660, 3370, 1000, 1200, 800, 310, 510, 185, 200, 286, 1380, 2020, 300, 770, 1140, 1700, 1095, [1120], 90, 3350, 1500, '±(1,9+L/300)'],
    ['10158', 1960, 2960, 3370, 1000, 1500, 800, 310, 510, 185, 200, 286, 1380, 2320, 300, 770, 1140, 2000, 1095, [1320], 90, 3800, 2000, '±(1,9+L/300)'],
    ['10208', 1960, 3460, 3140, 1000, 2000, 800, 310, 510, 185, 200, 286, 1380, 2820, 300, 500, 1140, 2500, 1090, [910, 910], 90, 4550, 3000, ''],
    ['10258', 1960, 3960, 3140, 1000, 2500, 800, 310, 510, 185, 200, 286, 1380, 3320, 350, 550, 1140, 3000, 1095, [1160, 1160], 90, 5980, 3500, ''],
    ['10308', 1960, 4460, 3140, 1000, 3000, 800, 310, 510, 185, 200, 286, 1380, 3820, 350, 550, 1140, 3500, 1095, [1410, 1410], 90, 7180, 4000, ''],
    ['121510', 2160, 2960, 3740, 1200, 1500, 1000, 310, 510, 185, 200, 286, 1580, 2320, 300, 770, 1340, 2000, 1295, [1320], 90, 4350, 2000, ''],
    ['122010', 2160, 3460, 3740, 1200, 2000, 1000, 310, 510, 185, 200, 286, 1580, 2820, 300, 500, 1340, 2500, 1295, [910, 910], 90, 5080, 3000, ''],
    ['122510', 2160, 3960, 3740, 1200, 2500, 1000, 310, 510, 185, 200, 286, 1580, 3320, 350, 550, 1340, 3000, 1295, [1160, 1160], 90, 6730, 4000, ''],
    ['123010', 2160, 4460, 3740, 1200, 3000, 1000, 310, 510, 185, 200, 286, 1580, 3820, 350, 550, 1340, 3500, 1295, [1410, 1410], 90, 7630, 4500, ''],
    ['152012', 2460, 3460, 3940, 1500, 2000, 1200, 310, 510, 185, 200, 286, 1880, 2820, 300, 500, 1340, 2500, 1595, [910, 910], 90, 5530, 3000, ''],
    ['152512', 2460, 3960, 3940, 1500, 2500, 1200, 310, 510, 185, 200, 286, 1880, 3320, 350, 550, 1340, 3000, 1595, [1160, 1160], 90, 7800, 4000, ''],
    ['153012', 2460, 4460, 3940, 1500, 3000, 1200, 310, 510, 185, 200, 286, 1880, 3820, 350, 550, 1340, 3500, 1595, [1410, 1410], 90, 8850, 5000, '']
  ];
  var CMMS = {};
  LEG.forEach(function (r) { var K = 'LEGEND' + r[0]; CMMS[K] = { key: K, name: 'AEH Legend ' + r[0], Lx: r[1], Ly: r[2], Lz: r[3], X: r[4], Y: r[5], Z: r[6], H1: r[7], H2: r[8], W1: r[9], W2: r[10], h1: r[11], Px: r[12], Py: r[13], Pz: r[14], H: r[15], Lx1: r[16], Ly1: r[17], Sx: r[18], Sy: r[19], ram: r[20], kg: r[21], load: r[22], mpe: r[23],
    note: 'по паспорту AEH (табл. 2.1): диапазон ' + r[4] + '×' + r[5] + '×' + r[6] + ', габарит ' + r[1] + '×' + r[2] + '×' + r[3] + ', плита ' + r[12] + '×' + r[13] + '×' + r[14] + ' на высоте ' + r[15] + ' мм, пиноль □' + r[20] + (r[23] ? ', MPE_E (SP25) ' + r[23] + ' мкм' : '') }; });
  function labelTex(T, text, fg, bg, w, h, font) {
    var c = document.createElement('canvas'); c.width = w || 512; c.height = h || 128; var x = c.getContext('2d');
    x.fillStyle = bg || '#ffffff'; x.fillRect(0, 0, c.width, c.height); x.fillStyle = fg || '#1b3f8f'; x.font = font || ('bold ' + Math.round(c.height * 0.62) + 'px Arial'); x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(text, c.width / 2, c.height / 2 + 2);
    var t = new T.CanvasTexture(c); t.anisotropy = 4; return t;
  }
  function buildCMM(model, bb) {
    var T = W.THREE, M = CMMS[model] || CMMS.LEGEND10128, g = new T.Group(); g.name = 'p70cmm';
    var mats = [], texs = [], mk = function (c, op, sh, em) { var m = new T.MeshPhongMaterial({ color: c, shininess: sh == null ? 40 : sh, transparent: op < 1, opacity: op, depthWrite: op >= 1, emissive: em || 0 }); mats.push(m); return m; };
    var box = function (par, sx, sy, sz, x, y, z, m) { var o = new T.Mesh(new T.BoxGeometry(sx, sy, sz), m); o.position.set(x, y, z); par.add(o); return o; };
    var box2 = function (par, x0, x1, y0, y1, z0, z1, m) { return box(par, x1 - x0, y1 - y0, z1 - z0, (x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2, m); };
    var plate = function (par, tex, w, h, x, y, z, ax, ay) { var m = new T.MeshBasicMaterial({ map: tex, side: T.DoubleSide }); mats.push(m); texs.push(tex); var o = new T.Mesh(new T.PlaneGeometry(w, h), m);
      var X = new T.Vector3(ax[0], ax[1], ax[2]), Y = new T.Vector3(ay[0], ay[1], ay[2]), Zn = X.clone().cross(Y); o.quaternion.setFromRotationMatrix(new T.Matrix4().makeBasis(X, Y, Zn)); o.position.set(x, y, z); par.add(o); return o; };
    /* диапазон измерений: по центру траектории головки (по X, Y), низ — плита */
    var LY = cmmLayout(model, bb), cx = LY.cx, cy = LY.cy, zt = LY.zt, rx0 = LY.rx0, rx1 = LY.rx1, ry0 = LY.ry0, ry1 = LY.ry1;
    var zBeam = zt + M.Z + M.h1, beamH = 280, beamD = 220, beamY = 230, z0 = zt - M.H, zTop = z0 + M.Lz;
    var tx0 = rx0 - M.W1, tx1 = tx0 + M.Px, ty0 = ry0 - M.H1, ty1 = ty0 + M.Py, tcx = (tx0 + tx1) / 2, tcy = (ty0 + ty1) / 2;
    var legR = 110, gw = Math.max(260, M.Lx - M.Px - legR - 20), gx1 = tx0 - 10, gx0 = gx1 - gw, gTop = zt + 110, cap = Math.max(120, (M.Ly - M.Py) / 2);
    var mGran = mk(0x2c2e33, 1, 70), mStand = mk(0x18191b, 1, 10), mWhite = mk(0xf1f1ee, 0.92, 30, 0x3a3a3a), mWhite2 = mk(0xe6e7e4, 0.95, 30, 0x303030), mBlue = mk(0x14365c, 1, 50), mRed = mk(0xc8262d, 1, 30),
      mBeam = mk(0x26282c, 0.95, 70), mRam = mk(0xc9cdd3, 1, 80, 0x202020), mDark = mk(0x3a3d44, 1, 30), mPad = mk(0x101010, 1, 10);
    /* станина и опоры */
    var sy = M.Sy.reduce(function (s, v) { return s + v; }, 0), sX = Math.min(M.Px - 80, M.Sx + 260), sYl = Math.min(M.Py - 160, sy + 560);
    box2(g, tcx - sX / 2, tcx + sX / 2, tcy - sYl / 2, tcy + sYl / 2, z0, zt - M.Pz - 25, mStand);
    var ys = [tcy - sy / 2]; M.Sy.forEach(function (v) { ys.push(ys[ys.length - 1] + v); });
    ys.forEach(function (yy) { [-1, 1].forEach(function (sx) { var c = new T.Mesh(new T.CylinderGeometry(45, 55, 25, 20), mPad); c.rotation.x = Math.PI / 2; c.position.set(tcx + sx * M.Sx / 2, yy, zt - M.Pz - 12.5); g.add(c); }); });
    /* гранитная плита */
    box2(g, tx0, tx1, ty0, ty1, zt - M.Pz, zt, mGran);
    /* направляющая Y (слева): белый короб с красной полосой, торцы — синие */
    box2(g, gx0, gx1, ty0 - cap + 120, ty1 + cap - 120, zt - M.Pz, gTop, mWhite2);
    box2(g, gx0 - 2, gx0 + 1, ty0 - cap + 130, ty1 + cap - 130, gTop - 70, gTop - 40, mRed);
    box2(g, gx0 - 10, gx1 + 10, ty0 - cap, ty0 - cap + 120, zt - M.Pz - 10, gTop + 10, mBlue); box2(g, gx0 - 10, gx1 + 10, ty1 + cap - 120, ty1 + cap, zt - M.Pz - 10, gTop + 10, mBlue);
    /* подвижный портал (Y) */
    var bridge = new T.Group(); g.add(bridge);
    var colW = 150, colX = gx0 + gw * 0.45, colH = zBeam - gTop;
    var sh = new T.Shape(); sh.moveTo(-380, 0); sh.lineTo(380, 0); sh.lineTo(160, colH * 0.42); sh.lineTo(140, colH + beamH); sh.lineTo(-140, colH + beamH); sh.lineTo(-170, colH * 0.42); sh.lineTo(-380, 0);
    var cg = new T.ExtrudeGeometry(sh, { depth: colW, bevelEnabled: false }); cg.applyMatrix4(new T.Matrix4().makeBasis(new T.Vector3(0, 1, 0), new T.Vector3(0, 0, 1), new T.Vector3(1, 0, 0))); /* форма в плоскости YZ, толщина по X */
    var col = new T.Mesh(cg, mWhite); col.position.set(colX - colW / 2, beamY, gTop); bridge.add(col);
    plate(bridge, labelTex(T, 'LEGEND', '#1b3f8f', '#f1f1ee', 512, 96), 360, 68, colX - colW / 2 - 2, beamY, gTop + colH * 0.3, [0, -1, 0], [0, 0, 1]);
    var lx = tx1 + 15 + legR / 2;
    box2(bridge, lx - legR / 2, lx + legR / 2, beamY - 90, beamY + 90, zt - 140, zBeam, mWhite);
    box2(bridge, lx - legR / 2 - 15, lx + legR / 2 + 15, beamY - 110, beamY + 110, zt - 180, zt - 120, mDark);
    /* траверса — чёрный гранит, синие торцы */
    var bx0 = colX - colW / 2 - 30, bx1 = lx + legR / 2 + 20;
    box2(bridge, bx0 + 50, bx1 - 50, beamY - beamD / 2, beamY + beamD / 2, zBeam, zBeam + beamH, mBeam);
    box2(bridge, bx0, bx0 + 50, beamY - beamD / 2 - 10, beamY + beamD / 2 + 10, zBeam - 10, zBeam + beamH + 10, mBlue);
    box2(bridge, bx1 - 50, bx1, beamY - beamD / 2 - 10, beamY + beamD / 2 + 10, zBeam - 10, zBeam + beamH + 10, mBlue);
    /* каретка X (белая, логотип AEH) и кожух пиноли до габарита Lz */
    var car = new T.Group(); bridge.add(car);
    box2(car, -160, 160, -150, beamY + beamD / 2 + 40, zBeam - 70, zBeam + beamH + 70, mWhite);
    box2(car, -125, 125, -120, 120, zBeam + beamH + 70, zTop, mWhite);
    box2(car, -40, 40, -122, -119, zBeam + beamH + 140, zTop - 120, mDark);
    plate(car, labelTex(T, 'AEH', '#1b3f8f', '#f1f1ee', 256, 128), 200, 100, 0, -152, zBeam + beamH / 2, [1, 0, 0], [0, 0, 1]);
    /* пиноль Z (сечение по паспорту) */
    var ram = new T.Group(); car.add(ram); var ramL = M.Z + M.h1 + beamH + 260;
    box(ram, M.ram, M.ram, ramL, 0, 0, ramL / 2 + 20, mRam); box(ram, M.ram - 14, M.ram - 14, 20, 0, 0, 10, mDark);
    /* рабочий объём (диапазон измерений) */
    var vb = new T.LineSegments(new T.EdgesGeometry(new T.BoxGeometry(M.X, M.Y, M.Z)), new T.LineBasicMaterial({ color: 0x19a974, transparent: true, opacity: 0.55 }));
    vb.position.set(cx, cy, zt + M.Z / 2); g.add(vb); mats.push(vb.material);
    var o = { group: g, model: M, cx: cx, cy: cy, zt: zt, zb: zBeam, range: [[rx0, rx1], [ry0, ry1], [zt, zt + M.Z]],
      update: function (hp) { bridge.position.y = hp[1]; car.position.x = hp[0]; ram.position.z = hp[2]; },
      dispose: function () { g.traverse(function (x) { if (x.geometry) x.geometry.dispose(); }); mats.forEach(function (m) { m.dispose(); }); texs.forEach(function (t) { t.dispose(); }); } };
    var span = [bb.max[0] - bb.min[0], bb.max[1] - bb.min[1], bb.max[2] - bb.min[2]];
    o.over = ['X', 'Y', 'Z'].filter(function (a, i) { return span[i] > [M.X, M.Y, M.Z][i]; });
    if (bb.max[2] > zBeam - 20 && o.over.indexOf('Z') < 0) o.over.push('Z (головка выше низа траверсы)');
    return o;
  }

  /* ======================= r71: магазин щупов (PROBECHANGER.DAT + Toolchangers\*.DRAW) =======================
     ITEM:<имя> <крепление>; cadgeom ox oy oz  a(3) b(3) c(3)  часть файл.draw  (p' = M·(p − o)); connect x y z i j k arm — гнёзда.
     СК магазина: Z вверх от основания, гнёзда открыты в −Y. Положение задаётся от угла диапазона измерений КИМ. */
  var RACK_KEY = 'pcd71.rack', RACK_USER = 'pcd71.racksUser';
  function parseRackDat(text) {
    var items = {}, cur = null;
    String(text || '').split(/\r?\n/).forEach(function (l) { var s = l.trim(); if (!s) return; var m = /^ITEM:(\S+)\s*(\S*)/i.exec(s); if (m) { cur = items[m[1]] = { mount: m[2] || '', geo: [], ports: [] }; return; }
      if (!cur) return; var w = s.split(/\s+/);
      if (/^cadgeom$/i.test(w[0]) && w.length >= 15) cur.geo.push(w.slice(1, 14).map(Number).concat([w[14].toLowerCase()]));
      else if (/^connect$/i.test(w[0]) && w.length >= 7) cur.ports.push(w.slice(1, 7).map(Number).concat([w[7] || ''])); });
    return items;
  }
  function racks() { var b = W.PCD_RACKS || {}, u = ls(RACK_USER), o = {}, k; for (k in b) o[k] = b[k]; if (u) for (k in u) o[k] = u[k]; return o; }
  function rackCfg() { var o = ls(RACK_KEY) || {}; return { on: o.on !== false, type: o.type || 'auto', x: num(o.x, 170), y: num(o.y, 110), z: num(o.z, 0), rot: num(o.rot, 0), ports: o.ports || {} }; }
  function setRackCfg(c) { var o = rackCfg(); for (var k in c) o[k] = c[k]; ls(RACK_KEY, o); }
  function autoRackType(probes) {
    var ch = probes.map(function (n) { return chainFor(n).join(' '); }).join(' '), n = probes.length, R = racks();
    var t = /SP25|SM25|SH25/i.test(ch) ? (n > 3 ? 'FCR25-6' : 'FCR25-3') : /SP600/i.test(ch) ? 'SP600' : /TP20/i.test(ch) ? 'TP20' : /TESASTAR/i.test(ch) ? 'TESASTAR-PR-6-TALL' : (n > 4 ? 'ACR3-8' : 'ACR3-4');
    return R[t] ? t : Object.keys(R)[0];
  }
  function dockIndex(ch) { for (var i = 1; i < ch.length; i++) if (/SP25|TP20|TP200|SP600|TP7|SP80|TP6|TESASTAR/i.test(ch[i - 1]) && !/^(SM|SH|TM)\d/i.test(ch[i - 1])) return i; return Math.min(2, ch.length - 1); }
  function cmmLayout(model, bb) {
    var M = CMMS[model] || CMMS.LEGEND10128, cx = (bb.min[0] + bb.max[0]) / 2, cy = (bb.min[1] + bb.max[1]) / 2, zt = bb.minTip - 80; /* верх плиты: на 80 мм ниже самой низкой точки щупа */
    return { M: M, cx: cx, cy: cy, zt: zt, rx0: cx - M.X / 2, rx1: cx + M.X / 2, ry0: cy - M.Y / 2, ry1: cy + M.Y / 2 };
  }
  function headBox(E) {
    var mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9], minTip = 1e9, stepN = Math.max(1, Math.floor(E.segs.length / 3000));
    E.segs.forEach(function (s) { if (s.kind === 'move' || s.kind === 'scan' || s.kind === 'tip') minTip = Math.min(minTip, s.p0[2], s.p1[2]); });
    for (var i = 0; i < E.segs.length; i += stepN) { var s = E.segs[i], hp = headAt({ s: s, p: s.p1, ab: s.ab1 }); for (var a = 0; a < 3; a++) { mn[a] = Math.min(mn[a], hp[a]); mx[a] = Math.max(mx[a], hp[a]); } }
    if (minTip > 1e8) minTip = mn[2] - 200; return { min: mn, max: mx, minTip: minTip };
  }
  function rackPlace(RK, LY, probes) {
    var R = racks(), type = RK.type !== 'auto' && R[RK.type] ? RK.type : autoRackType(probes), it = R[type]; if (!it || !it.ports.length) return null;
    var a = RK.rot * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a), rot = function (q) { return [ca * q[0] - sa * q[1], sa * q[0] + ca * q[1], q[2]]; };
    var O = [LY.rx0 + RK.x, LY.ry1 - RK.y, LY.zt + RK.z], zmax = -1e9;
    var ports = it.ports.map(function (q, i) { zmax = Math.max(zmax, q[2]); return { i: i, q: q, p: addv(O, rot(q)), ap: rot([0, -1, 0]) }; });
    var used = {}, map = {}, asg = {};
    probes.forEach(function (pn) { var i = RK.ports[pn]; if (i === -1) return; if (i == null || i >= ports.length || used[i]) { i = null; for (var k = 0; k < ports.length; k++) if (!used[k]) { i = k; break; } } if (i == null) return; used[i] = 1; map[pn] = ports[i]; asg[pn] = i; });
    var topZ = O[2] + zmax + 25;
    return { name: type, item: it, O: O, rot: RK.rot, ports: ports, port: map, asg: asg, topZ: topZ, safeZ: topZ + 40, cfg: RK, mesh: it.geo.some(function (v) { return !!drawGet(v[13]); }) };
  }
  function ciTag(ob) {
    ob.parts = []; ob.di = dockIndex(ob.chain);
    ob.root.traverse(function (x) { if (!x.isMesh && !x.isLine && !x.isLineSegments) return; var y = x; while (y && (!y.userData || y.userData.ci == null)) y = y.parent; ob.parts.push({ m: x, ci: y ? y.userData.ci : -1 }); });
  }
  function setBare(ob, bare) { if (!ob.parts) ciTag(ob); if (ob._bare === bare) return; ob._bare = bare; ob.parts.forEach(function (q) { if (q.ci >= ob.di) q.m.visible = !bare; }); }
  function jointOf(ob) {
    var di = dockIndex(ob.chain), c = null; ob.setAngles(0, 0);
    ob.root.traverse(function (x) { if (!c && x.userData && x.userData.ci === di) c = x; });
    if (!c) return [0, 0, -150];
    var inv = new W.THREE.Matrix4().copy(ob.root.matrixWorld).invert(), v = new W.THREE.Vector3().setFromMatrixPosition(c.matrixWorld).applyMatrix4(inv); return [v.x, v.y, v.z];
  }
  function buildRack(R, probeOf) {
    var T = W.THREE, g = new T.Group(), inner = new T.Group(), cache = {}, mats = [], texs = [], nMesh = 0; g.add(inner); g.name = 'p71rack';
    inner.position.set(R.O[0], R.O[1], R.O[2]); inner.rotation.z = R.rot * Math.PI / 180;
    var mk = function (c, op) { var m = new T.MeshPhongMaterial({ color: c, shininess: 40, transparent: op < 1, opacity: op == null ? 1 : op }); mats.push(m); return m; };
    var box2 = function (x0, x1, y0, y1, z0, z1, m) { var o = new T.Mesh(new T.BoxGeometry(x1 - x0, y1 - y0, z1 - z0), m); o.position.set((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2); inner.add(o); return o; };
    R.item.geo.forEach(function (v) { var m = drawMesh(T, v, v[12], v[13], cache, [96, 98, 104]); if (m) { inner.add(m); nMesh++; } });
    var P = R.item.ports, xs = P.map(function (q) { return q[0]; }), x0 = Math.min.apply(null, xs), x1 = Math.max.apply(null, xs), py = P[0][1], pz = P[0][2];
    if (!nMesh) { /* упрощённая модель (формат .DRAW этой стойки пока не читается): основание, две стойки, балка, корпуса гнёзд с крышками */
      var mBase = mk(0x3b3e44), mAl = mk(0xb9bec6), mPort = mk(0x2a2c30), mLid = mk(0x5a6a80, 0.9);
      box2(x0 - 55, x1 + 55, py - 40, py + 110, 0, 14, mBase);
      [x0 - 38, x1 + 38].forEach(function (x) { box2(x - 14, x + 14, py + 40, py + 80, 14, pz - 32, mAl); });
      box2(x0 - 45, x1 + 45, py - 8, py + 80, pz - 46, pz - 30, mAl);
      P.forEach(function (q) { box2(q[0] - 15.5, q[0] + 15.5, q[1] - 20, q[1] + 26, pz - 30, pz + 20, mPort); box2(q[0] - 14, q[0] + 14, q[1] - 23, q[1] - 20, pz - 26, pz + 16, mLid); });
    }
    /* номера гнёзд и метки занятости */
    var asgBy = {}; Object.keys(R.asg).forEach(function (k) { asgBy[R.asg[k]] = k; });
    P.forEach(function (q, i) {
      var used = asgBy[i] != null, tex = labelTex(T, String(i + 1), used ? '#ffffff' : '#333333', used ? '#1f8f4a' : '#d8d8d8', 64, 64); texs.push(tex);
      var sm = new T.SpriteMaterial({ map: tex, depthTest: false }); mats.push(sm); var sp = new T.Sprite(sm); sp.scale.set(14, 14, 1); sp.position.set(q[0], q[1] - 30, q[2] + 30); sp.renderOrder = 1000; inner.add(sp);
    });
    return { group: g, mesh: nMesh > 0, dispose: function () { g.traverse(function (x) { if (x.geometry) x.geometry.dispose(); }); mats.forEach(function (m) { m.dispose(); }); texs.forEach(function (t) { t.dispose(); }); Object.keys(cache).forEach(function (k) { cache[k].dispose(); }); } };
  }
  function openRack() {
    var a = api(); if (!a) return;
    var w = a.win('p71rack', 'Магазин щупов (PROBECHANGER.DAT)', 'feat', 600); w.el.classList.add('p68');
    var msg = '';
    function draw() {
      var RK = rackCfg(), R = racks(), probes = programProbes(), E = null, rk = null;
      try { E = estimate(); rk = E.rack; } catch (e) { console.warn(e); }
      var auto = autoRackType(probes.length ? probes : ['']);
      var h = ['<div class="row"><label><input type="checkbox" data-r="on"' + (RK.on ? ' checked' : '') + '> использовать магазин при ЗАГР/ЩУП (смена модуля в гнезде вместо фиксированного времени)</label></div>',
        '<div class="row">Тип <select data-r="type" style="width:260px"><option value="auto">авто (' + esc(auto) + ')</option>' + Object.keys(R).map(function (k) { var it = R[k], m = it.geo.some(function (v) { return !!drawGet(v[13]); }); return '<option value="' + esc(k) + '"' + (k === RK.type ? ' selected' : '') + '>' + esc(k) + ' — гнёзд ' + it.ports.length + (m ? ' · сетка .DRAW' : ' · упрощённо') + '</option>'; }).join('') + '</select></div>',
        '<div class="grid" style="grid-template-columns:auto 80px auto 80px">',
        '<label>X от левого края диапазона, мм</label><input data-r="x" value="' + RK.x + '"><label>Y от заднего края, мм</label><input data-r="y" value="' + RK.y + '">',
        '<label>Z основания над плитой, мм</label><input data-r="z" value="' + RK.z + '"><label>Поворот вокруг Z, °</label><select data-r="rot">' + [0, 90, 180, 270].map(function (v) { return '<option' + (v === RK.rot ? ' selected' : '') + '>' + v + '</option>'; }).join('') + '</select></div>'];
      if (rk) {
        h.push('<div class="cap">Гнёзда ' + esc(rk.name) + (rk.mesh ? '' : ' <span class="mut">(геометрия упрощённая: этот .DRAW записан в B-rep-версии формата)</span>') + '</div><table><thead><tr><th>Щуп программы</th><th>Гнездо</th><th class="n">X</th><th class="n">Y</th><th class="n">Z</th></tr></thead><tbody>');
        probes.forEach(function (pn) { var i = rk.asg[pn], pt = rk.port[pn];
          h.push('<tr><td>' + esc(pn) + '</td><td><select data-pn="' + esc(pn) + '"><option value="-1">не в магазине</option>' + rk.ports.map(function (q) { return '<option value="' + q.i + '"' + (q.i === i ? ' selected' : '') + '>' + (q.i + 1) + '</option>'; }).join('') + '</select></td>' +
            (pt ? '<td class="n">' + pt.p[0].toFixed(1) + '</td><td class="n">' + pt.p[1].toFixed(1) + '</td><td class="n">' + pt.p[2].toFixed(1) + '</td>' : '<td colspan="3" class="mut">смена — фиксированное время ' + P().timePerTool + ' с</td>') + '</tr>'); });
        h.push('</tbody></table>');
        var tr = 0, nr = 0; E.rows.forEach(function (r) { if (r.rack) { tr += r.t; nr++; } });
        h.push('<div class="mut" style="margin-top:6px">Смен через магазин: ' + nr + ', время ' + ms(tr) + (nr ? ' (≈' + (tr / nr).toFixed(1) + ' с на смену)' : '') + '. Начало СК магазина: X ' + rk.O[0].toFixed(1) + ' Y ' + rk.O[1].toFixed(1) + ' Z ' + rk.O[2].toFixed(1) + ' (в СК программы).</div>');
      } else h.push('<div class="mut" style="margin-top:6px">' + (probes.length > 1 ? (RK.on ? 'Магазин не построен (нет данных о гнёздах).' : 'Магазин выключен.') : 'В программе ' + (probes.length ? 'один щуп' : 'нет ЗАГР/ЩУП') + ' — смен щупа нет.') + '</div>');
      h.push('<div class="mut" style="margin-top:6px">Цикл смены: отвод вверх (выше магазина на 40 мм) → A0B0 → подход к гнезду спереди на ' + P().rackApproach + ' мм → ввод → оставить модуль (' + P().rackDwell + ' с) → подъём ' + P().rackLift + ' мм → над гнездом нового → опускание → взять (' + P().rackDwell + ' с) → выход вперёд. Параметры — в окне «Время выполнения».</div>');
      if (msg) h.push('<div class="mut" style="white-space:pre-line">' + esc(msg) + '</div>');
      w.body.innerHTML = h.join('');
      var B = w.body, ch = function () { var p2 = {}; [].forEach.call(B.querySelectorAll('select[data-pn]'), function (s) { p2[s.getAttribute('data-pn')] = +s.value; });
        setRackCfg({ on: B.querySelector('[data-r=on]').checked, type: B.querySelector('[data-r=type]').value, x: num(B.querySelector('[data-r=x]').value), y: num(B.querySelector('[data-r=y]').value), z: num(B.querySelector('[data-r=z]').value), rot: +B.querySelector('[data-r=rot]').value, ports: p2 });
        if (play.bar) rebuildPlay(); draw(); };
      [].forEach.call(B.querySelectorAll('input,select'), function (x) { x.onchange = ch; });
    }
    draw();
    w.foot.innerHTML = ''; w.foot.style.cssText = 'display:flex;gap:6px;justify-content:flex-end;padding:6px 10px';
    w.foot.appendChild(a.btn('▶ Прогон в 3D', function () { startPlay(0); }, 'def'));
    w.foot.appendChild(a.btn('Импорт PROBECHANGER.DAT…', function () { pickFile('.dat,.DAT,.txt', function (t, nm) { var it = parseRackDat(t), n = Object.keys(it).length; if (!n) { msg = nm + ': ITEM не найдены'; draw(); return; } ls(RACK_USER, it); msg = nm + ': магазинов ' + n; draw(); if (play.bar) rebuildPlay(); }); }));
    w.foot.appendChild(a.btn('Сброс', function () { try { localStorage.removeItem(RACK_KEY); localStorage.removeItem(RACK_USER); } catch (e) {} msg = 'Настройки магазина сброшены'; if (play.bar) rebuildPlay(); draw(); }));
    w.foot.appendChild(a.btn('Закрыть', function () { w.close(); }));
  }
  function headAt(st) {
    var s = st.s, k;
    if (s.kind === 'tip') { k = kinFor(s.pk); return sub(s.p0, k.at(s.ab0.A, s.ab0.B).p); }
    if (s.kind === 'tool') { k = kinFor(s.pk0); return sub(s.p0, k.at(s.ab1.A, s.ab1.B).p); }
    k = kinFor(s.pk); return sub(st.p, k.at(st.ab.A, st.ab.B).p);
  }
  function ensureScene(force) {
    var T = W.THREE, sc = G('scene3'); if (!T || !sc) return false;
    if (play.wrap && !force && play.wrap.parent === sc) return true;
    disposePlay();
    var E = play.est, keys = Object.keys(E.probes || { '': 1 }); if (!keys.length) keys = [''];
    var wrap = new T.Group(); wrap.matrixAutoUpdate = false; wrap.name = 'p68probe';
    var swap = new T.Group(); swap.matrixAutoUpdate = false; swap.matrix.set(1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1);
    wrap.add(swap); play.swap = swap;
    keys.forEach(function (k) { var ch = E.probes && E.probes[k] || kinFor(k).chain, ob = build(ch); if (!ob) return; ob.tipIndex = k ? 0 : (cfg().tip || 0); ob.root.visible = false; ob.pk = k; swap.add(ob.root); play.objs[k] = ob; });
    play.obj = play.objs[keys[0]] || null; if (!play.obj) return false;
    /* траектория */
    var pts = [], mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9], minTip = 1e9;
    E.segs.forEach(function (s) { if (s.kind === 'move' || s.kind === 'scan' || s.kind === 'tip') pts.push(s.p0[0], s.p0[1], s.p0[2], s.p1[0], s.p1[1], s.p1[2]); minTip = Math.min(minTip, s.p0[2], s.p1[2]); });
    var g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(pts, 3));
    play.path = new T.LineSegments(g, new T.LineBasicMaterial({ color: 0x3a6fd8, transparent: true, opacity: 0.55, depthTest: false })); play.path.renderOrder = 998; swap.add(play.path);
    var g2 = new T.BufferGeometry(); g2.setAttribute('position', new T.Float32BufferAttribute(new Float32Array(pts.length), 3)); g2.setDrawRange(0, 0);
    play.done = new T.LineSegments(g2, new T.LineBasicMaterial({ color: 0x18b34a, depthTest: false })); play.done.renderOrder = 999; swap.add(play.done); play.donePts = pts;
    /* КИМ: габарит по положениям головы */
    /* r71: магазин и модули в гнёздах */
    if (E.rack) try {
      play.rack = buildRack(E.rack); swap.add(play.rack.group);
      Object.keys(E.rack.port).forEach(function (k) { var ch = E.probes && E.probes[k] || kinFor(k).chain, ob = build(ch); if (!ob) return; ciTag(ob); ob.parts.forEach(function (q) { if (q.ci < ob.di) q.m.visible = false; });
        var j = jointOf(ob), pp = E.rack.port[k].p; ob.root.position.set(pp[0] - j[0], pp[1] - j[1], pp[2] - j[2]); ob.root.visible = false; swap.add(ob.root); play.docked[k] = ob; });
    } catch (e) { console.warn('r71 rack scene', e); }
    if (opts().cmm) try {
      if (E.layBB) { mn = E.layBB.min.slice(); mx = E.layBB.max.slice(); minTip = E.layBB.minTip; } else {
      var stepN = Math.max(1, Math.floor(E.segs.length / 3000));
      for (var i = 0; i < E.segs.length; i += stepN) { var s = E.segs[i], hp = headAt({ s: s, p: s.p1, ab: s.ab1 }); for (var a = 0; a < 3; a++) { mn[a] = Math.min(mn[a], hp[a]); mx[a] = Math.max(mx[a], hp[a]); } } }
      if (minTip < 1e8) { play.cmm = buildCMM(opts().cmmModel, { min: mn, max: mx, minTip: minTip }); swap.add(play.cmm.group); if (play.cmm.over.length && !play._overWarned) { play._overWarned = 1; toast('Траектория больше ходов ' + play.cmm.model.name + ' по ' + play.cmm.over.join(', ')); } }
    } catch (e) { console.warn('r69 cmm', e); }
    sc.add(wrap); play.wrap = wrap; syncMatrix();
    return true;
  }
  function syncMatrix() { var eg = G('elementsGroup3'); if (!play.wrap) return; if (eg) { eg.updateMatrixWorld(); play.wrap.matrix.copy(eg.matrixWorld); } else play.wrap.matrix.identity(); play.wrap.matrixWorldNeedsUpdate = true; }
  function stateAt(t) {
    var S2 = play.est.segs, lo = 0, hi = S2.length - 1, i = 0;
    while (lo <= hi) { var mid = (lo + hi) >> 1; if (S2[mid].t1 < t) lo = mid + 1; else { i = mid; hi = mid - 1; } }
    var s = S2[i]; if (!s) return null;
    var dt = s.t1 - s.t0, f = dt > 0 ? Math.max(0, Math.min(1, (t - s.t0) / dt)) : 1;
    if (s.prof === 'trap' && play.est.p) f = trapFrac(t - s.t0, dt, s.d, play.est.p.moveSpeed, play.est.p.accel);
    var ab = s.kind === 'tip' ? { A: s.ab0.A + (s.ab1.A - s.ab0.A) * f, B: s.ab0.B + (s.ab1.B - s.ab0.B) * f } : s.ab1;
    return { i: i, s: s, p: s.kind === 'tool' ? (f < 0.5 ? s.p0 : s.p1) : lerp(s.p0, s.p1, f), ab: ab, f: f };
  }
  function updatePlay() {
    if (!play.est || !play.obj) return;
    syncMatrix();
    var E = play.est, st = stateAt(play.t); if (!st) return;
    var key = st.s.kind === 'tool' && st.f < 0.5 ? (st.s.pk0 || '') : (st.s.pk || ''), bare = !!st.s.bare || (st.s.kind === 'drop' && st.f >= 0.5) || (st.s.kind === 'pick' && st.f < 0.5);
    if (st.s.kind === 'pick' && st.f >= 0.5) { key = st.s.pkN || key; bare = false; }
    var o = play.objs[key] || play.obj;
    if (o !== play.obj || !o.root.visible) { Object.keys(play.objs).forEach(function (k) { play.objs[k].root.visible = false; }); play.obj = o; }
    o.root.visible = !(st.s.kind === 'tool' && Math.abs(st.f - 0.5) < 0.15); /* «моргание» при смене щупа */
    o.tipLocal(st.ab.A, st.ab.B); if (play.rack || o._bare) setBare(o, bare);
    if (play.docked) Object.keys(play.docked).forEach(function (k) { play.docked[k].root.visible = !(k === key && !bare); });
    var hp = headAt(st); o.root.position.set(hp[0], hp[1], hp[2]);
    o.root.updateMatrixWorld(true);
    if (play.cmm) { play.cmm.update(hp); play.cmm.group.visible = opts().cmm; }
    /* пройденная траектория */
    var n = 0; for (var j = 0; j < E.segs.length && E.segs[j].t1 <= play.t; j++) { var sj = E.segs[j]; if (sj.kind === 'move' || sj.kind === 'scan' || sj.kind === 'tip') n++; }
    var attr = play.done.geometry.attributes.position; if (play._n !== n) { attr.array.set(play.donePts.slice(0, n * 6)); attr.needsUpdate = true; play.done.geometry.setDrawRange(0, n * 2); play._n = n; }
    if (play.bar) {
      var pk = E.p && E.p.k || 1, r = E.rows[st.s.row], add = E.p && E.p.additional || 0;
      play.bar.querySelector('.clk').textContent = hms(play.t * pk + (play.t >= E.raw ? add : 0)) + ' / ' + hms(E.total);
      play.bar.querySelector('.lb').textContent = r ? (r.group ? r.group + ' · ' : '') + r.label + ' (' + (KIND[r.kind] || r.kind) + ')' : '';
      play.bar.querySelector('.ab').textContent = (key ? key + ' ' : '') + 'A' + (Math.round(st.ab.A * 10) / 10) + ' B' + (Math.round(st.ab.B * 10) / 10);
      var rg = play.bar.querySelector('input[type=range]'); if (!play._drag) rg.value = String(Math.round(play.t / Math.max(1e-9, E.raw) * 10000));
      if (timeWin && timeWin.el.isConnected && play._row !== st.s.row) { play._row = st.s.row; var old = timeWin.body.querySelector('tr.cur'); if (old) old.classList.remove('cur'); var tr = timeWin.body.querySelector('tr[data-i="' + st.s.row + '"]'); if (tr) { tr.classList.add('cur'); if (play.on) tr.scrollIntoView({ block: 'nearest' }); } }
    }
  }
  function loop(ts) {
    if (!play.on) return;
    var dt = play.last ? Math.min(0.2, (ts - play.last) / 1000) : 0; play.last = ts;
    var end = play.range ? play.range.t1 : play.est.raw;
    play.t += dt * play.speed; if (play.t >= end) { play.t = end; play.on = false; setBtn(); }
    updatePlay(); if (play.on) play.raf = requestAnimationFrame(loop);
  }
  function setBtn() { if (play.bar) play.bar.querySelector('[data-a=pp]').textContent = play.on ? '⏸' : '▶'; }
  function bar() {
    if (play.bar && play.bar.isConnected) return play.bar;
    var host = document.getElementById('threeContainer') || document.body;
    var b = document.createElement('div'); b.id = 'p68play';
    b.innerHTML = '<button class="b" data-a="st" title="В начало">⏮</button><button class="b" data-a="pp">▶</button><span class="clk">0:00:00</span><input type="range" min="0" max="10000" value="0">' +
      '<select data-a="sp" title="Ускорение воспроизведения"><option value="1">×1 (реальное)</option><option value="2">×2</option><option value="5">×5</option><option value="10">×10</option><option value="25">×25</option><option value="60">×60</option></select>' +
      '<span class="rgl" style="display:none;background:#fff3c4;border:1px solid #d9b84a;border-radius:3px;padding:1px 4px;white-space:nowrap" title="Прогон выделенного: воспроизведение останавливается в конце диапазона"><span class="rgt"></span> <button class="b" data-a="rgx" title="Весь прогон" style="height:18px;min-width:18px;padding:0 3px">✕</button></span><span class="ab" style="font:11px Consolas,monospace;color:#555"></span><span class="lb"></span><button class="b" data-a="cm" title="Показать/скрыть КИМ (правая кнопка — выбор модели)">🏗</button><button class="b" data-a="io" title="Экспорт/импорт касаний и траектории">⇅</button><button class="b" data-a="fr" title="Вписать: траектория → щуп → КИМ">🎯</button><button class="b" data-a="tw" title="Таблица времени">⏱</button><button class="b" data-a="x" title="Закрыть прогон">✕</button>';
    host.appendChild(b); play.bar = b;
    var sp = b.querySelector('[data-a=sp]'); sp.value = String(play.speed);
    sp.onchange = function () { play.speed = +sp.value; };
    b.querySelector('[data-a=pp]').onclick = function () { var R = play.range; if (R && (play.t >= R.t1 - 1e-6 || play.t < R.t0 - 1e-6)) play.t = R.t0; else if (!R && play.t >= play.est.raw) play.t = 0; play.on = !play.on; play.last = 0; setBtn(); if (play.on) play.raf = requestAnimationFrame(loop); };
    b.querySelector('[data-a=st]').onclick = function () { play.t = play.range ? play.range.t0 : 0; updatePlay(); };
    b.querySelector('[data-a=rgx]').onclick = function () { play.range = null; showRange(); };
    b.querySelector('[data-a=tw]').onclick = openTime;
    b.querySelector('[data-a=io]').onclick = openIO;
    b.querySelector('[data-a=cm]').oncontextmenu = function (e) { e.preventDefault(); openCMM(); };
    b.querySelector('[data-a=cm]').onclick = function () { var on = !opts().cmm; setOpts({ cmm: on }); if (on && !play.cmm) { ensureScene(true); } updatePlay(); toast(on ? 'КИМ показана' : 'КИМ скрыта'); };
    var fr = 0; b.querySelector('[data-a=fr]').onclick = function () { var m = fr++ % (play.cmm ? 3 : 2); frame(m === 1 ? true : m === 2 ? 'cmm' : false); };
    b.querySelector('[data-a=x]').onclick = stopPlay;
    var rg = b.querySelector('input[type=range]');
    rg.oninput = function () { play._drag = true; play.t = +rg.value / 10000 * play.est.raw; updatePlay(); };
    rg.onchange = function () { play._drag = false; };
    return b;
  }
  function showRange() {
    if (!play.bar) return; var el = play.bar.querySelector('.rgl'), R = play.range; el.style.display = R ? '' : 'none';
    if (R) el.querySelector('.rgt').textContent = '▣ ' + R.label + ' · ' + ms(R.t0) + '–' + ms(R.t1) + ' (' + ms(R.t1 - R.t0) + ')';
  }
  /* r71: диапазон времени прогона по именам элементов (выделение в окне «Команды») */
  function rangeFor(E, names) {
    var R = E.rows, i0 = -1, i1 = -1, n = 0;
    R.forEach(function (r, i) { var nm = r.el ? r.el.name : ''; if ((nm && names[nm]) || names[r.label]) { if (i0 < 0) i0 = i; i1 = i; n++; } });
    if (i0 < 0) return null;
    while (i0 > 0 && /^(tip|tool|move)$/.test(R[i0 - 1].kind) && !(R[i0 - 1].el)) i0--;
    return { t0: R[i0].t0, t1: R[i1].t0 + R[i1].t, n: n, i0: i0, i1: i1 };
  }
  function playSel(names, label) {
    var keys = Object.keys(names); if (!keys.length) { toast('В выделении нет элементов программы'); return; }
    startPlay(0, false, { names: names, label: label || (keys.length === 1 ? keys[0] : keys[0] + ' … ' + keys[keys.length - 1]) });
  }
  function startPlay(t0, paused, sel) {
    try { var tb = document.querySelector('nav.tabs button[data-tab="model"]'); if (tb && !document.getElementById('tab-model').classList.contains('active')) tb.click(); } catch (e) {}
    setTimeout(function () {
      play.est = curEst(); if (!play.est.segs.length) { toast('Нет элементов с касаниями для прогона'); return; }
      if (!ensureScene(true)) { toast('3D-вид ещё не готов — откройте вкладку «3D модель»'); return; }
      var first = !play.bar; bar(); play.t = t0 || 0; play._n = -1;
      if (sel) { var rg = rangeFor(play.est, sel.names); if (!rg) { toast('Выделенные элементы не участвуют в прогоне (нет касаний)'); play.range = null; } else { play.range = { t0: rg.t0, t1: rg.t1, label: sel.label + ' (' + rg.n + ' эл.)' }; play.t = rg.t0; } } else if (t0 == null || !play.range || t0 < play.range.t0 || t0 > play.range.t1) play.range = null;
      showRange(); play._row = -1; updatePlay(); if (first) frame(false);
      play.on = !paused; play.last = 0; setBtn(); cancelAnimationFrame(play.raf); if (play.on) play.raf = requestAnimationFrame(loop);
      var np = Object.keys(play.est.probes || {}).length; if (np > 1) toast('Щупов в программе: ' + np + ' — модель меняется на ЗАГР/ЩУП');
    }, 60);
  }
  function frame(onProbe) {
    try {
      var T = W.THREE, ct = G('camTarget3'); if (!ct || !play.wrap) return; play.wrap.updateMatrixWorld(true);
      var bb = new T.Box3().setFromObject(onProbe === 'cmm' && play.cmm ? play.cmm.group : onProbe && play.obj ? play.obj.root : play.path); if (bb.isEmpty()) return; if (onProbe === 'cmm') onProbe = false;
      var c = bb.getCenter(new T.Vector3()), sz = bb.getSize(new T.Vector3()); ct.copy(c);
      var d = Math.max(sz.x, sz.y, sz.z, 50) * (onProbe ? 3 : 1.6); G('camDist3 = ' + d.toFixed(1)); var uc = G('updateCamera3'); if (typeof uc === 'function') uc();
    } catch (e) { console.warn('r68 frame', e); }
  }
  function stopPlay() { play.on = false; cancelAnimationFrame(play.raf); disposePlay(); if (play.bar) { play.bar.remove(); play.bar = null; } }

  /* ======================= экспорт / импорт касаний и траектории ======================= */
  function f4(v) { return (Math.round(v * 1e4) / 1e4).toFixed(4); }
  function exportHits() {
    var st = S(), els = (st && st.elements) || [], out = ['Элемент;№;X;Y;Z;I;J;K;Тип;Источник'], n = 0;
    els.forEach(function (e) {
      if (!(e._hits && e._hits.length) && !/plane|circle|cylinder|cone|sphere|point|line|slot/.test(e.type)) return;
      var src = e._hits && e._hits.length ? 'PRG' : 'расчёт';
      hitsOf(e).forEach(function (h, i) { out.push([e.name, i + 1, f4(h[0]), f4(h[1]), f4(h[2]), f4(h[3]), f4(h[4]), f4(h[5]), e.type || '', src].join(';')); n++; });
    });
    if (!n) { toast('Нет касаний для экспорта'); return; }
    download(fileBase() + '_касания.csv', '\uFEFF' + out.join('\r\n') + '\r\n', 'text/csv'); toast('Касаний экспортировано: ' + n);
  }
  function fileBase() { var st = S(), h = st && st.header || {}; return String(h.partName || h.name || 'программа').replace(/[\\/:*?"<>|]+/g, '_').slice(0, 60) || 'программа'; }
  function splitRow(l) { var sep = l.indexOf(';') >= 0 ? ';' : l.indexOf('\t') >= 0 ? '\t' : ','; return l.split(sep).map(function (x) { return x.trim().replace(/^"|"$/g, ''); }); }
  function importHits() {
    pickFile('.csv,.txt,.json', function (txt, fname) {
      var by = {}, st = S(), els = (st && st.elements) || [], miss = {}, n = 0, upd = 0;
      try {
        if (/^\s*[\[{]/.test(txt)) { var j = JSON.parse(txt); (Array.isArray(j) ? j : j.hits || []).forEach(function (h) { (by[h.name || h.element] = by[h.name || h.element] || []).push([+h.x, +h.y, +h.z, +h.i || 0, +h.j || 0, h.k == null ? 1 : +h.k]); }); }
        else txt.replace(/^\uFEFF/, '').split(/\r?\n/).forEach(function (l) {
          if (!l.trim()) return; var c = splitRow(l); if (c.length < 4) return;
          var nm, o; if (isFinite(num(c[1], NaN)) && isFinite(num(c[2], NaN)) && isFinite(num(c[3], NaN)) && c.length >= 8 && Math.abs(num(c[1])) < 100000 && /^\d+$/.test(c[1])) { nm = c[0]; o = 2; } else if (isFinite(num(c[1], NaN))) { nm = c[0]; o = 1; } else return;
          var x = num(c[o], NaN), y = num(c[o + 1], NaN), z = num(c[o + 2], NaN); if (!isFinite(x) || !isFinite(y) || !isFinite(z)) return;
          (by[nm] = by[nm] || []).push([x, y, z, num(c[o + 3], 0), num(c[o + 4], 0), num(c[o + 5], 1)]);
        });
      } catch (e) { toast('Ошибка чтения: ' + e.message); return; }
      Object.keys(by).forEach(function (nm) { var e = els.filter(function (x) { return x.name === nm; })[0]; if (!e) { miss[nm] = 1; return; } e._hits = by[nm]; e._hitCount = by[nm].length; if (by[nm].length <= 200) e.points = String(by[nm].length); upd++; n += by[nm].length; });
      var a = api(); try { if (a && a.refresh) a.refresh(); } catch (e) {}
      kinCache = {}; if (play.wrap && !play.imported) rebuildPlay();
      var mk = Object.keys(miss); toast('Импорт касаний: ' + n + ' точек в ' + upd + ' элементах' + (mk.length ? '; нет элементов: ' + mk.slice(0, 5).join(', ') + (mk.length > 5 ? '…' : '') : ''));
    }, true);
  }
  var PATH_HEAD = ['t0', 't1', 'вид', 'щуп', 'щуп_до', 'A0', 'B0', 'A1', 'B1', 'X0', 'Y0', 'Z0', 'X1', 'Y1', 'Z1', 'строка', 'группа'];
  function exportPath(fmt) {
    var E = play.imported || estimate(); if (!E.segs.length) { toast('Траектория пуста'); return; }
    if (fmt === 'json') {
      var o = { format: 'pcdmis-probe-path', version: 1, total: E.total, raw: E.raw, p: E.p, probes: E.probes, rows: E.rows.map(function (r) { return { label: r.label, kind: r.kind, group: r.group, hits: r.hits, path: r.path, t: r.t, t0: r.t0, el: r.el ? r.el.name : '' }; }),
        segs: E.segs.map(function (s) { return [s.kind, +s.t0.toFixed(4), +s.t1.toFixed(4), s.p0.map(function (v) { return +v.toFixed(4); }), s.p1.map(function (v) { return +v.toFixed(4); }), [s.ab0.A, s.ab0.B, s.ab1.A, s.ab1.B], s.pk || '', s.pk0 || '', s.row, s.prof || '', s.d || 0]; }) };
      download(fileBase() + '_траектория.json', JSON.stringify(o), 'application/json');
    } else {
      var L2 = [PATH_HEAD.join(';')];
      E.segs.forEach(function (s) { var r = E.rows[s.row] || {}; L2.push([s.t0.toFixed(3), s.t1.toFixed(3), s.kind, s.pk || '', s.pk0 || '', s.ab0.A, s.ab0.B, s.ab1.A, s.ab1.B, f4(s.p0[0]), f4(s.p0[1]), f4(s.p0[2]), f4(s.p1[0]), f4(s.p1[1]), f4(s.p1[2]), String(r.label || '').replace(/;/g, ','), String(r.group || '').replace(/;/g, ',')].join(';')); });
      download(fileBase() + '_траектория.csv', '\uFEFF' + L2.join('\r\n') + '\r\n', 'text/csv');
    }
    toast('Траектория экспортирована: ' + E.segs.length + ' участков');
  }
  function importPath() {
    pickFile('.json,.csv,.txt', function (txt, fname) {
      var E = { segs: [], rows: [], probes: {}, p: P(), src: 'импорт: ' + fname, cats: {}, totals: {}, ab0: { A: 0, B: 0 } };
      try {
        if (/^\s*\{/.test(txt)) {
          var j = JSON.parse(txt); E.p = j.p || E.p; E.probes = j.probes || {};
          E.rows = (j.rows || []).map(function (r) { return { label: r.label, kind: r.kind, group: r.group, hits: r.hits || 0, path: r.path || 0, t: r.t || 0, t0: r.t0 || 0, el: null }; });
          E.segs = (j.segs || []).map(function (a) { return { kind: a[0], t0: a[1], t1: a[2], p0: a[3], p1: a[4], ab0: { A: a[5][0], B: a[5][1] }, ab1: { A: a[5][2], B: a[5][3] }, pk: a[6] || '', pk0: a[7] || '', row: a[8], prof: a[9] || undefined, d: a[10] }; });
        } else {
          var rowsIx = {}, lines = txt.replace(/^\uFEFF/, '').split(/\r?\n/).filter(function (l) { return l.trim(); }), h = splitRow(lines[0]), ix = {};
          h.forEach(function (x, i) { ix[x.toLowerCase()] = i; }); if (ix.t0 == null || ix.x1 == null) throw new Error('нет заголовка ' + PATH_HEAD.join(';'));
          lines.slice(1).forEach(function (l) {
            var c = splitRow(l), g = function (k) { return c[ix[k.toLowerCase()]]; }, lb = g('строка') || '', gr = g('группа') || '', rk = lb + '\u0001' + gr + '\u0001' + (E.rows.length && E.rows[E.rows.length - 1].label === lb ? E.rows.length - 1 : '');
            var kind = g('вид') || 'move';
            if (!E.rows.length || E.rows[E.rows.length - 1].label !== lb || E.rows[E.rows.length - 1].group !== gr) E.rows.push({ label: lb, kind: kind === 'wait' ? 'other' : kind, group: gr, hits: 0, path: 0, t: 0, t0: num(g('t0')), el: null });
            var row = E.rows[E.rows.length - 1], s = { kind: kind, t0: num(g('t0')), t1: num(g('t1')), p0: [num(g('X0')), num(g('Y0')), num(g('Z0'))], p1: [num(g('X1')), num(g('Y1')), num(g('Z1'))], ab0: { A: num(g('A0')), B: num(g('B0')) }, ab1: { A: num(g('A1')), B: num(g('B1')) }, pk: g('щуп') || '', pk0: g('щуп_до') || g('щуп') || '', row: E.rows.length - 1 };
            if (kind === 'hit' && s.p1 && len(sub(s.p1, s.p0)) > 0 && row.kind !== 'scan') row.hits += 0.5; row.t += s.t1 - s.t0; if (kind === 'move' || kind === 'scan') row.path += len(sub(s.p1, s.p0));
            E.segs.push(s);
          });
          E.rows.forEach(function (r) { r.hits = Math.round(r.hits); });
        }
      } catch (e) { toast('Ошибка чтения траектории: ' + e.message); return; }
      if (!E.segs.length) { toast('В файле нет участков траектории'); return; }
      E.segs.sort(function (a, b) { return a.t0 - b.t0; });
      E.segs.forEach(function (s) { if (!E.probes[s.pk]) E.probes[s.pk] = chainFor(s.pk); if (s.pk0 && !E.probes[s.pk0]) E.probes[s.pk0] = chainFor(s.pk0); });
      E.raw = E.segs[E.segs.length - 1].t1; E.total = E.raw * (E.p.k || 1) + (E.p.additional || 0);
      E.ab0 = E.segs[0].ab0; play.imported = E;
      toast('Импорт траектории: ' + E.segs.length + ' участков, ' + hms(E.total) + ' — прогон по импортированной траектории'); startPlay(0, true);
    }, true);
  }
  function openIO() {
    var a = api(); if (!a) return;
    var w = a.win('p69io', 'Экспорт / импорт касаний и траектории щупа', 'feat', 520); w.el.classList.add('p68');
    w.body.innerHTML = '<div class="cap">Касания (точки контакта на детали, X Y Z + вектор I J K)</div>' +
      '<div class="row"><button class="b" data-a="eh">Экспорт касаний (CSV)…</button><button class="b" data-a="ih">Импорт касаний (CSV/JSON)…</button></div>' +
      '<div class="mut">CSV: Элемент;№;X;Y;Z;I;J;K — разделитель «;», «,» или Tab. Импорт заменяет касания у элементов с тем же именем.</div>' +
      '<div class="cap">Траектория щупа (проход центра шарика, со временем, углами A/B и щупом)</div>' +
      '<div class="row"><button class="b" data-a="ec">Экспорт траектории (CSV)…</button><button class="b" data-a="ej">Экспорт (JSON)…</button><button class="b" data-a="ip">Импорт траектории…</button><button class="b" data-a="rp">Сбросить импорт</button></div>' +
      '<div class="mut">CSV: ' + esc(PATH_HEAD.join(';')) + '<br>Импортированная траектория проигрывается вместо расчётной (до «Сбросить импорт»).</div><div data-r="st" class="mut" style="margin-top:6px"></div>';
    var q = function (s) { return w.body.querySelector('[data-a=' + s + ']'); };
    var stl = function () { w.body.querySelector('[data-r=st]').textContent = play.imported ? 'Сейчас: импортированная траектория (' + play.imported.src + ')' : 'Сейчас: расчётная траектория по программе'; };
    q('eh').onclick = exportHits; q('ih').onclick = importHits; q('ec').onclick = function () { exportPath('csv'); }; q('ej').onclick = function () { exportPath('json'); };
    q('ip').onclick = function () { importPath(); setTimeout(stl, 1500); }; q('rp').onclick = function () { play.imported = null; stl(); if (play.bar) startPlay(0, true); toast('Траектория — расчётная'); };
    stl();
  }

  /* ======================= Конструктор щупа ======================= */
  function openBuilder() {
    var a = api(); if (!a) return;
    var w = a.win('p68probe', 'Конструктор щупа (компоненты PC-DMIS probe.dat)', 'feat', 900); w.el.classList.add('p68');
    var c = JSON.parse(JSON.stringify(cfg())), pname = '';
    w.body.innerHTML = '<div style="display:flex;gap:10px"><div style="width:400px">' +
      '<div class="cap">Щуп программы</div><div class="row"><select data-r="pp" style="width:250px" title="Щупы из команд ЗАГР/ЩУП программы — для каждого можно поправить цепочку"></select><label title="Модель щупа меняется по командам ЗАГР/ЩУП программы"><input type="checkbox" data-r="auto"> по программе</label></div>' +
      '<div class="row">Головка по умолчанию <select data-r="head" style="width:150px"></select> <button class="b" data-a="rst" title="Сбросить свою цепочку для выбранного щупа программы">Авто</button></div>' +
      '<div class="cap">Цепочка компонентов (сверху — головка) <span class="mut">PROBE.DAT: ' + LIB.filter(function (x) { return x.source === 'PROBE.DAT'; }).length + ' компонентов</span></div><div data-r="chain"></div>' +
      '<div class="row"><button class="b" data-a="add">+ Компонент</button><button class="b" data-a="tip">+ Наконечник Ø×L…</button><button class="b" data-a="prg" title="По строке ЗАГР/ЩУП из заголовка программы">Из программы</button></div>' +
      '<div class="cap">Углы головки</div><div class="row">A <input data-r="A" style="width:50px"> <input type="range" data-r="Ar" min="0" max="105" step="7.5" style="width:90px">  B <input data-r="B" style="width:50px"> <input type="range" data-r="Br" min="-180" max="180" step="7.5" style="width:90px"></div>' +
      '<div class="row">Наконечник (TIP) № <select data-r="ti"></select> <span class="mut">Ориентация как в PC-DMIS: A90B0 → −Y, A90B90 → +X, A90B−90 → −X</span></div>' +
      '<div class="cap">Сведения</div><div data-r="info" class="mut" style="white-space:pre-wrap"></div>' +
      '<div class="cap">Определение компонента <span class="mut">(язык probe.dat; можно править и сохранить как свой)</span></div>' +
      '<select data-r="defsel" style="width:100%"></select><textarea data-r="def" spellcheck="false" style="width:100%;height:150px;font:11px Consolas,monospace;white-space:pre"></textarea>' +
      '<div class="row"><button class="b" data-a="save" title="Сохранить в пользовательскую библиотеку (как usrprobe.dat)">Сохранить компонент</button><button class="b" data-a="imp">Импорт probe.dat / usrprobe.dat…</button><button class="b" data-a="exp">Экспорт usrprobe.dat</button><button class="b" data-a="clr">Сбросить свои</button></div>' +
      '</div><div style="flex:1;min-width:0"><div data-r="view" style="height:520px;background:linear-gradient(#f4f6f9,#cfd6df);border:1px solid #aaa;position:relative;cursor:grab"></div><div class="mut">Мышь: вращение · колесо: масштаб · двойной клик: вписать</div></div></div>';
    var $ = function (s) { return w.body.querySelector('[data-r=' + s + ']'); };
    var T = W.THREE, R = null, scene, cam, cur = null, yaw = -0.7, pitch = 0.35, dist = 400, ctr = new T.Vector3(0, 0, -120), raf = 0;
    try {
      R = new T.WebGLRenderer({ antialias: true, alpha: true }); R.setPixelRatio(Math.min(2, W.devicePixelRatio || 1));
      $('view').appendChild(R.domElement); scene = new T.Scene(); cam = new T.PerspectiveCamera(35, 1, 1, 20000);
      cam.up.set(0, 0, 1);
      scene.add(new T.AmbientLight(0xffffff, 0.55)); var dl = new T.DirectionalLight(0xffffff, 0.8); dl.position.set(300, -500, 600); scene.add(dl); var dl2 = new T.DirectionalLight(0xffffff, 0.35); dl2.position.set(-400, 300, -200); scene.add(dl2);
      var grid = new T.GridHelper(400, 20, 0x8899aa, 0xc0c8d0); grid.rotation.x = Math.PI / 2; grid.position.z = -600; scene.add(grid); scene.userData.grid = grid;
      var ax = new T.AxesHelper(40); scene.add(ax);
    } catch (e) { $('view').innerHTML = '<div class="warn" style="padding:10px">WebGL недоступен: ' + esc(e.message) + '</div>'; }
    function render() {
      if (!R) return; var el = $('view'); if (!el || !el.isConnected) { cancelAnimationFrame(raf); return; }
      var Wd = el.clientWidth, Hd = el.clientHeight; if (R.domElement.width !== Math.round(Wd * R.getPixelRatio())) R.setSize(Wd, Hd, true);
      cam.aspect = Wd / Math.max(1, Hd); cam.updateProjectionMatrix();
      cam.position.set(ctr.x + dist * Math.cos(pitch) * Math.sin(yaw), ctr.y - dist * Math.cos(pitch) * Math.cos(yaw), ctr.z + dist * Math.sin(pitch)); cam.lookAt(ctr);
      R.render(scene, cam);
    }
    function fit() { if (!cur) return; var bb = new T.Box3().setFromObject(cur.root); if (bb.isEmpty()) return; bb.getCenter(ctr); dist = Math.max(80, bb.getSize(new T.Vector3()).length() * 1.6); if (scene.userData.grid) scene.userData.grid.position.z = bb.min.z - 10; render(); }
    if (R) {
      var v = $('view'), drag = null;
      v.addEventListener('mousedown', function (e) { drag = [e.clientX, e.clientY, yaw, pitch]; e.preventDefault(); });
      W.addEventListener('mousemove', function (e) { if (!drag) return; yaw = drag[2] + (e.clientX - drag[0]) * 0.01; pitch = Math.max(-1.5, Math.min(1.5, drag[3] + (e.clientY - drag[1]) * 0.01)); render(); });
      W.addEventListener('mouseup', function () { drag = null; });
      v.addEventListener('wheel', function (e) { e.preventDefault(); dist *= e.deltaY > 0 ? 1.12 : 1 / 1.12; render(); }, { passive: false });
      v.addEventListener('dblclick', fit);
      if (W.ResizeObserver) new ResizeObserver(render).observe(v);
    }
    function compatList(prevOut) {
      var ok = [], bad = [];
      prevOut = NM(prevOut) || '*';
      LIB.forEach(function (it) { var need = it.mountIn || '*', good = need === '*' || need === prevOut || prevOut === '*' || (need === 'TIP' && /^M\d/.test(prevOut)); (good ? ok : bad).push(it); });
      ok.sort(function (a, b) { return a.name < b.name ? -1 : a.name > b.name ? 1 : 0; });
      return { ok: ok, bad: bad };
    }
    function chainUI() {
      var box = $('chain'); box.innerHTML = ''; var prev = 'ARM';
      c.chain.forEach(function (n, i) {
        var it = item(n, prev), cl = compatList(prev), s = document.createElement('select'); s.style.width = '262px';
        var add = function (x, warn) { var o = document.createElement('option'); o.value = x.name; o.textContent = (warn ? '⚠ ' : '') + x.name + ' — ' + x.desc + ' [' + (x.mountIn || '*') + '→' + (x.mountOut || (x.hasTip ? 'шарик' : '')) + ']'; s.appendChild(o); };
        if (it && !cl.ok.some(function (x) { return x.name === n; })) add(it, it.mountIn !== NM(prev) && it.mountIn !== 'TIP');
        if (!it) add({ name: n, desc: 'нет в библиотеке', mountIn: '?', mountOut: '' }, true);
        var seen = {}; cl.ok.forEach(function (x) { if (seen[x.name]) return; seen[x.name] = 1; add(x); }); s.value = n;
        s.onchange = function () { c.chain[i] = s.value; changed(true); };
        var row = document.createElement('div'); row.className = 'row'; row.style.cssText = 'margin:2px 0;flex-wrap:nowrap';
        var lab = document.createElement('span'); lab.textContent = (i + 1) + '.'; lab.style.width = '16px'; row.appendChild(lab); row.appendChild(s);
        [['↑', function () { if (i) { var t = c.chain[i - 1]; c.chain[i - 1] = c.chain[i]; c.chain[i] = t; changed(true); } }], ['↓', function () { if (i < c.chain.length - 1) { var t = c.chain[i + 1]; c.chain[i + 1] = c.chain[i]; c.chain[i] = t; changed(true); } }], ['×', function () { c.chain.splice(i, 1); changed(true); }], ['def', function () { showDef(n); }]].forEach(function (b) {
          var x = document.createElement('button'); x.className = 'b'; x.style.minWidth = '24px'; x.title = { '↑': 'Выше', '↓': 'Ниже', '×': 'Удалить', def: 'Показать определение' }[b[0]] || ''; x.style.padding = '0 4px'; x.textContent = b[0]; x.onclick = b[1]; row.appendChild(x);
        });
        box.appendChild(row); prev = it ? (it.mountOut || '*') : '*';
      });
    }
    function showDef(n) {
      var sel = $('defsel'); if (!sel.options.length || sel._lib !== LIB.length) { sel.innerHTML = ''; LIB.forEach(function (x) { var o = document.createElement('option'); o.value = x.name; o.textContent = x.name + ' — ' + x.desc + (x.source ? ' (' + x.source + ')' : ''); sel.appendChild(o); }); sel._lib = LIB.length; }
      var it = item(n, n === c.chain[0] ? 'ARM' : (function () { var r = resolve(c.chain), k = c.chain.indexOf(n); return k > 0 && r[k - 1].it ? r[k - 1].it.mountOut : ''; })()); if (!it) return; if (![].some.call(sel.options, function (o) { return o.value === n; })) { var o2 = document.createElement('option'); o2.value = n; o2.textContent = n + ' — ' + it.desc; sel.appendChild(o2); }
      sel.value = n; $('def').value = 'ITEM:' + it.name + ' ' + (it.realDat ? it.mountIn : it.desc) + '\n' + it.lines.join('\n');
    }
    function changed(chain) {
      if (chain) chainUI();
      c.A = num($('A').value, c.A); c.B = num($('B').value, c.B);
      if (cur) { scene.remove(cur.root); cur.dispose(); }
      cur = build(c.chain); if (!cur) return;
      var ti = $('ti'); if (chain || ti.options.length !== cur.tips.length) { ti.innerHTML = cur.tips.map(function (t, i) { return '<option value="' + i + '">' + (i + 1) + ' (' + esc(t.comp) + ', Ø' + t.D + ')</option>'; }).join(''); if ((c.tip || 0) >= cur.tips.length) c.tip = 0; ti.value = String(c.tip || 0); }
      cur.tipIndex = c.tip || 0; cur.setAngles(c.A, c.B); scene.add(cur.root);
      var tl = cur.tipLocal(c.A, c.B), bb = new T.Box3().setFromObject(cur.root), sz = bb.getSize(new T.Vector3());
      var warn = chainCheck(c.chain).concat(cur.notes), jt = cur.joints.map(function (j) { return j.axis.toUpperCase() + ': ' + j.min + '…' + j.max + '° шаг ' + j.step; }).join(', ');
      var A0 = cur.joints.filter(function (j) { return j.axis === 'a'; })[0], B0 = cur.joints.filter(function (j) { return j.axis === 'b'; })[0];
      if (A0 && (c.A < A0.min || c.A > A0.max)) warn.push('A вне диапазона ' + A0.min + '…' + A0.max);
      if (A0 && Math.abs(c.A / A0.step - Math.round(c.A / A0.step)) > 1e-6) warn.push('A не кратен шагу ' + A0.step + '°');
      if (B0 && Math.abs(c.B / B0.step - Math.round(c.B / B0.step)) > 1e-6) warn.push('B не кратен шагу ' + B0.step + '°');
      $('info').innerHTML = esc((pname ? 'Щуп программы: ' + pname + '\n' : '') + 'Цепочка: ' + c.chain.join(' → ') + '\nНаконечник: T' + ((c.tip || 0) + 1) + 'A' + c.A + 'B' + c.B + ', шарик Ø' + tl.D + '\nЦентр шарика от головки: X ' + tl.p[0].toFixed(2) + '  Y ' + tl.p[1].toFixed(2) + '  Z ' + tl.p[2].toFixed(2) + ' мм' +
        '\nНаправление стержня: ' + tl.d.map(function (x) { return x.toFixed(3); }).join(', ') + '\nГабарит: ' + sz.x.toFixed(0) + ' × ' + sz.y.toFixed(0) + ' × ' + sz.z.toFixed(0) + ' мм' + (jt ? '\nШарниры: ' + jt : '')) +
        (warn.length ? '<div class="warn">⚠ ' + warn.map(esc).join('<br>⚠ ') + '</div>' : '<div style="color:#18803a">✓ цепочка совместима</div>');
      $('A').value = c.A; $('B').value = c.B; $('Ar').value = c.A; $('Br').value = c.B;
      if (pname) { var cc = JSON.parse(JSON.stringify(cfg())); cc.A = c.A; cc.B = c.B; ls(CFG_KEY, cc); if (chain) setChainFor(pname, c.chain.slice()); kinCache = {}; if (play.obj) disposePlay(); }
      else setCfg(JSON.parse(JSON.stringify(c)));
      render(); if (chain) fit();
    }
    $('A').onchange = function () { changed(); }; $('B').onchange = function () { changed(); };
    $('Ar').oninput = function () { $('A').value = $('Ar').value; changed(); }; $('Br').oninput = function () { $('B').value = $('Br').value; changed(); };
    $('ti').onchange = function () { c.tip = +$('ti').value; changed(); };
    $('defsel').onchange = function () { showDef($('defsel').value); };
    var q = function (s) { return w.body.querySelector('[data-a=' + s + ']'); };
    q('add').onclick = function () { var rr = resolve(c.chain), last = rr.length ? rr[rr.length - 1].it : null, cl = compatList(last ? last.mountOut || '*' : 'ARM'); c.chain.push((cl.ok[0] || LIB[0]).name); changed(true); };
    /* щупы программы / головка / авто */
    (function () {
      var pp = $('pp'), names = programProbes(), hs = $('head'), seenH = {};
      pp.innerHTML = '<option value="">— активный щуп (без программы) —</option>' + names.map(function (n) { var m = ls(MAP_KEY) || {}; return '<option value="' + esc(n) + '">' + esc(n) + (m[n] ? ' (своя цепочка)' : ' (авто)') + '</option>'; }).join('');
      LIB.forEach(function (x) { if (x.mountIn === 'ARM' && x.joints > 0 && !seenH[x.name]) { seenH[x.name] = 1; var o = document.createElement('option'); o.value = x.name; o.textContent = x.name; hs.appendChild(o); } });
      hs.value = opts().head; $('auto').checked = opts().auto;
      hs.onchange = function () { setOpts({ head: hs.value }); if (pname) { c.chain = chainFor(pname); } else { c.chain[0] = hs.value; } changed(true); };
      $('auto').onchange = function () { setOpts({ auto: $('auto').checked }); toast($('auto').checked ? 'Щуп меняется по командам ЗАГР/ЩУП' : 'Один щуп на всю программу'); };
      pp.onchange = function () { pname = pp.value; c.chain = pname ? chainFor(pname) : cfg().chain.slice(); var ab = null; changed(true); };
      q('rst').onclick = function () { if (!pname) { toast('Выберите щуп программы'); return; } setChainFor(pname, null); c.chain = chainFor(pname); changed(true); toast('Цепочка ' + pname + ' — автоматически'); };
      if (names.length && opts().auto) { pname = names[0]; pp.value = pname; c.chain = chainFor(pname); }
    })();
    q('tip').onclick = function () {
      var s = prompt('Наконечник: диаметр шарика × длина, мм (и резьба), напр. «4 x 40 M3»', '4 x 40'); if (!s) return;
      var m = /([\d.,]+)\s*[x×х*\s]\s*([\d.,]+)\s*(M\d)?/i.exec(s); if (!m) { toast('Не понял размеры'); return; }
      var lastOf = function () { var r = resolve(c.chain); return r.length ? r[r.length - 1].it : null; }, last = lastOf(); if (last && last.hasTip) c.chain.pop(); last = lastOf();
      c.chain.push(L.tipDef(num(m[1]), num(m[2]), m[3] || (last && /^M\d/.test(last.mountOut) ? last.mountOut : null)).name); changed(true);
    };
    q('prg').onclick = function () { var st = S(), h = st && st.header || {}, nm = h.probe1 || ''; var ab = parseTip(h.probe2 || '') || parseTip(nm); c.chain = chainFromProbeName(nm); if (ab) { c.A = ab.A; c.B = ab.B; } c.from = 'программа: ' + nm; toast('Щуп из программы: ' + (nm || '(нет в заголовке — по умолчанию)')); changed(true); };
    q('save').onclick = function () { var it = L.parse($('def').value, 'свой'); if (!it.length) { toast('Нужна строка ITEM:ИМЯ'); return; } var u = ls(USER_KEY) || { text: '', file: 'usrprobe.dat' }; var keep = L.parse(u.text, u.file).filter(function (x) { return !it.some(function (y) { return y.name === x.name; }); }); u.text = keep.concat(it).map(function (x) { return 'ITEM:' + x.name + ' ' + x.desc + '\n' + x.lines.join('\n'); }).join('\n'); ls(USER_KEY, u); rebuildLib(); kinCache = null; $('defsel').innerHTML = ''; showDef(it[0].name); changed(true); toast('Сохранено: ' + it.map(function (x) { return x.name; }).join(', ')); };
    q('imp').onclick = function () { pickFile('.dat,.txt,*', function (txt, name) { var it = L.parse(txt, name); if (!it.length) { toast('В файле нет строк ITEM:'); return; } var u = ls(USER_KEY) || { text: '' }; u.text = (u.text ? u.text + '\n' : '') + txt; u.file = name; ls(USER_KEY, u); rebuildLib(); $('defsel').innerHTML = ''; chainUI(); toast('Импортировано компонентов: ' + it.length + ' из ' + name); }, true); };
    q('exp').onclick = function () { var used = resolve(c.chain).map(function (r) { return r.it; }).filter(Boolean); var u = ls(USER_KEY); var txt = (u && u.text ? u.text + '\n' : '') + used.filter(function (x) { return x.source !== 'PC-DMIS' && x.source !== 'PROBE.DAT'; }).map(function (x) { return 'ITEM:' + x.name + ' ' + x.desc + '\n' + x.lines.join('\n'); }).join('\n'); download('usrprobe.dat', txt + '\n'); };
    q('clr').onclick = function () { if (!confirm('Удалить импортированные/свои компоненты?')) return; ls(USER_KEY, null); rebuildLib(); $('defsel').innerHTML = ''; changed(true); };
    w.foot.innerHTML = ''; w.foot.style.cssText = 'display:flex;gap:6px;justify-content:flex-end;padding:6px 10px';
    w.foot.appendChild(a.btn('Время выполнения…', openTime));
    w.foot.appendChild(a.btn('▶ Прогон в 3D', function () { startPlay(0); }, 'def'));
    w.foot.appendChild(a.btn('Закрыть', function () { w.close(); }));
    var oc = w.onClose; w.onClose = function () { cancelAnimationFrame(raf); try { if (cur) cur.dispose(); R && R.dispose(); } catch (e) {} if (oc) oc(); };
    chainUI(); showDef(c.chain[c.chain.length - 1]); changed(false); fit();
  }

  /* ======================= r70: окно «Модель КИМ» и «Сетки .DRAW» ======================= */
  function openCMM() {
    var a = api(); if (!a) return;
    var w = a.win('p70cmm', 'Модель КИМ (AEH Legend — по паспорту)', 'feat', 560); w.el.classList.add('p68');
    function draw() {
      var o = opts(), M = CMMS[o.cmmModel] || CMMS.LEGEND10128;
      var h = ['<div class="row">Модель <select data-r="m" style="width:200px">' + Object.keys(CMMS).map(function (k) { return '<option value="' + k + '"' + (k === M.key ? ' selected' : '') + '>' + esc(CMMS[k].name) + '</option>'; }).join('') + '</select>',
        ' <label><input type="checkbox" data-r="on"' + (o.cmm ? ' checked' : '') + '> показывать в прогоне</label></div>',
        '<table class="tb" style="margin-top:6px"><tbody>'];
      [['Диапазон измерений Dx × Dy × Dz', M.X + ' × ' + M.Y + ' × ' + M.Z], ['Габариты Lx × Ly × Lz', M.Lx + ' × ' + M.Ly + ' × ' + M.Lz], ['Плита Px × Py, толщина Pz', M.Px + ' × ' + M.Py + ', ' + M.Pz],
        ['Высота от пола до плиты H', M.H], ['Запас по Y: H1 / H2', M.H1 + ' / ' + M.H2], ['От стоек до диапазона по X: W1 / W2', M.W1 + ' / ' + M.W2], ['От верха диапазона до траверсы h1', M.h1],
        ['Перемещение портала Lx1 / Ly1', M.Lx1 + ' / ' + M.Ly1], ['Опоры Sx / Sy', M.Sx + ' / ' + M.Sy.join('+')], ['Сечение пиноли Z', '□' + M.ram], ['Вес КИМ / нагрузка на стол, кг', M.kg + ' / ' + M.load],
        ['MPE_E с SP25, мкм', M.mpe || '—']].forEach(function (r) { h.push('<tr><td>' + esc(r[0]) + '</td><td class="n">' + esc(r[1]) + '</td></tr>'); });
      h.push('</tbody></table><div class="mut" style="margin-top:6px">Источник: РЭ «КИМ серии Legend (HA)», табл. 2.1 и рис. 2.1. Модели HA — та же геометрия. Диапазон (зелёная рамка) ставится по центру траектории головки, верх плиты — на 80 мм ниже нижней точки щупа.</div>');
      if (play.cmm) h.push('<div class="mut">Текущий прогон: ' + (play.cmm.over.length ? '<b style="color:#c33">выход за ходы по ' + esc(play.cmm.over.join(', ')) + '</b>' : 'траектория в пределах ходов') + '</div>');
      w.body.innerHTML = h.join('');
      w.body.querySelector('[data-r=m]').onchange = function () { setOpts({ cmmModel: this.value }); play._overWarned = 0; if (play.bar) rebuildPlay(); draw(); };
      w.body.querySelector('[data-r=on]').onchange = function () { setOpts({ cmm: this.checked }); if (play.bar) rebuildPlay(); };
    }
    draw();
    w.foot.innerHTML = ''; w.foot.style.cssText = 'display:flex;gap:6px;justify-content:flex-end;padding:6px 10px';
    w.foot.appendChild(a.btn('Магазин щупов…', openRack));
    w.foot.appendChild(a.btn('▶ Прогон в 3D', function () { startPlay(0); }, 'def'));
    w.foot.appendChild(a.btn('Закрыть', function () { w.close(); }));
  }
  /* ======================= r71: «Виртуальный прогон выделенного» в контекстном меню окна «Команды» ======================= */
  var NAME_RE = /^\s*([^\s=\/]+)\s*=/;
  function lineNames(ln) {
    var box = document.getElementById('pcdProgText'); if (!box) return {};
    var lines = [].slice.call(box.children).filter(function (x) { return x.classList && x.classList.contains('ln'); }), sel = W.getSelection && W.getSelection(), picked = [];
    if (sel && !sel.isCollapsed && sel.rangeCount && box.contains(sel.getRangeAt(0).commonAncestorContainer)) lines.forEach(function (l, i) { if (sel.containsNode(l, true)) picked.push(i); });
    if (!picked.length && ln) picked.push(lines.indexOf(ln));
    var out = {}; if (!picked.length || picked[0] < 0) return out;
    for (var b = picked[0]; b >= 0 && b > picked[0] - 60; b--) { var m0 = NAME_RE.exec(lines[b].textContent || ''); if (m0) { out[m0[1]] = 1; break; } if (b < picked[0] && /^\S/.test(lines[b].textContent || '')) break; }
    picked.forEach(function (i) { var m = NAME_RE.exec(lines[i].textContent || ''); if (m) out[m[1]] = 1; });
    return out;
  }
  W.addEventListener('contextmenu', function (e) {
    var t = e.target, ln = t.closest && t.closest('#pcdProgText > .ln'), body = t.closest && t.closest('#pcdProgPane .pcd-prog-body'); if (!ln && !body) return;
    var names = lineNames(ln);
    setTimeout(function () {
      var m = document.getElementById('p57Menu'); if (!m || m.style.display !== 'block') return;
      var keys = Object.keys(names), E = null, rg = null; try { E = curEst(); rg = keys.length ? rangeFor(E, names) : null; } catch (x) {}
      m.appendChild(document.createElement('hr'));
      var it = document.createElement('div'); it.className = 'i'; it.id = 'p71selPlay';
      it.innerHTML = '<span style="width:16px;text-align:center;color:#1f8f4a">▶</span><span>Виртуальный прогон выделенного' + (rg ? ' (' + rg.n + ' эл., ' + ms(rg.t1 - rg.t0) + ')' : keys.length ? ' (нет касаний)' : ' (ничего не выделено)') + '</span>';
      if (!rg) it.style.color = '#999';
      it.addEventListener('click', function () { m.style.display = 'none'; playSel(names); });
      m.appendChild(it);
      m.style.top = Math.max(0, Math.min(parseFloat(m.style.top) || 0, W.innerHeight - m.offsetHeight - 4)) + 'px';
    }, 0);
  }, true);
  function drawList() {
    var b = W.PCD_PROBE_DRAW || {}, u = drawUser(), out = [];
    Object.keys(b).forEach(function (k) { out.push({ k: k, src: 'встроено', pk: b[k] }); });
    Object.keys(u).concat(Object.keys(drawMem)).forEach(function (k) { if (!out.some(function (x) { return x.k === k && x.src !== 'встроено'; })) out.push({ k: k, src: 'импорт', pk: drawMem[k] || u[k] }); });
    return out;
  }
  function openDraws() {
    var a = api(); if (!a) return;
    var w = a.win('p70draw', 'Сетки щупов PC-DMIS (.DRAW)', 'feat', 560); w.el.classList.add('p68');
    var msg = '';
    function users(k) { var r = []; LIB.forEach(function (it) { if (it.lines && it.lines.some(function (l) { return /^\s*cadgeom/i.test(l) && l.trim().split(/\s+/).pop().toLowerCase() === k; })) r.push(it.name); }); return r; }
    function draw() {
      var L = drawList(), h = ['<div class="mut">Файлы .DRAW из папки Probes PC-DMIS. Читается версия формата с готовой триангуляцией (CPCDbc_coll, блоки 0x600); в остальных — только B-rep, они показываются приближённо.</div>',
        '<table class="tb" style="margin-top:6px"><thead><tr><th>Файл</th><th>Источник</th><th class="n">Частей</th><th class="n">Треуг.</th><th>Компоненты PROBE.DAT</th></tr></thead><tbody>'];
      L.forEach(function (x) { var n = 0; x.pk.parts.forEach(function (p) { n += Math.round(p.b64.length * 3 / 4 / 2 / 9); }); var us = users(x.k);
        h.push('<tr><td>' + esc(x.pk.src || x.k) + '</td><td>' + x.src + '</td><td class="n">' + x.pk.parts.length + '</td><td class="n">' + n + '</td><td>' + esc(us.slice(0, 4).join(', ') + (us.length > 4 ? ' …+' + (us.length - 4) : '')) + '</td></tr>'); });
      h.push('</tbody></table>'); if (msg) h.push('<div class="mut" style="margin-top:6px;white-space:pre-line">' + esc(msg) + '</div>');
      w.body.innerHTML = h.join('');
    }
    draw();
    w.foot.innerHTML = ''; w.foot.style.cssText = 'display:flex;gap:6px;justify-content:flex-end;padding:6px 10px';
    w.foot.appendChild(a.btn('Импорт .DRAW…', function () {
      var i = document.createElement('input'); i.type = 'file'; i.accept = '.draw,.DRAW'; i.multiple = true;
      i.onchange = function () { var fs = [].slice.call(i.files), res = [], left = fs.length; if (!left) return;
        fs.forEach(function (f) { var r = new FileReader(); r.onload = function () { try { res.push(drawImport(f.name, r.result).msg); } catch (e) { res.push(f.name + ': ошибка ' + e.message); } if (!--left) { msg = res.join('\n'); draw(); if (play.bar) { disposePlay(); startPlay(play.t, true); } } }; r.readAsArrayBuffer(f); }); };
      i.click(); }));
    w.foot.appendChild(a.btn('Удалить импортированные', function () { drawMem = {}; drawCache = {}; try { localStorage.removeItem(DRAW_KEY); } catch (e) {} kinCache = {}; msg = 'Импортированные сетки удалены'; draw(); }));
    w.foot.appendChild(a.btn('Закрыть', function () { w.close(); }));
  }

  /* ======================= меню ======================= */
  function menu() {
    var m = document.getElementById('pcdMenu'); if (!m) return false; if (document.getElementById('p68Mi')) return true;
    var mi = document.createElement('span'); mi.className = 'mi'; mi.id = 'p68Mi'; mi.appendChild(document.createTextNode('Щуп'));
    var sb = document.createElement('span'); sb.className = 'sub';
    [['Конструктор щупа…', openBuilder], ['Время выполнения программы…', openTime], ['Прогон щупа в 3D (с часами)', function () { startPlay(0); }], null,
      ['Экспорт / импорт касаний и траектории…', openIO], ['Экспорт касаний (CSV)', exportHits], ['Экспорт траектории щупа (CSV)', function () { exportPath('csv'); }], ['Импорт траектории щупа…', importPath],
      ['Модель КИМ (AEH Legend по паспорту)…', openCMM], ['Магазин щупов (PROBECHANGER.DAT)…', openRack], ['Показать / скрыть КИМ', function () { var on = !opts().cmm; setOpts({ cmm: on }); if (play.bar) rebuildPlay(); toast(on ? 'КИМ в прогоне: показана' : 'КИМ в прогоне: скрыта'); }], ['Сетки щупов .DRAW…', openDraws], null,
      ['Импорт probe.dat / usrprobe.dat…', function () { openBuilder(); setTimeout(function () { var b = document.querySelector('#p57w_p68probe [data-a=imp]'); if (b) b.click(); }, 50); }],
      ['Щупы программы (ЗАГР/ЩУП)…', function () { var n = programProbes(); toast(n.length ? 'Щупы: ' + n.map(function (x) { return x + ' → ' + chainFor(x).join('·'); }).join(' | ') : 'В программе нет ЗАГР/ЩУП'); }],
      ['Щуп из заголовка программы', function () { var st = S(), h = st && st.header || {}; var c = cfg(); c.chain = chainFromProbeName(h.probe1); var ab = parseTip(h.probe2) || parseTip(h.probe1); if (ab) { c.A = ab.A; c.B = ab.B; } setCfg(c); toast('Щуп: ' + c.chain.join(' → ')); }],
      ['Остановить прогон', stopPlay]].forEach(function (x) {
      if (!x) { sb.appendChild(document.createElement('hr')); return; }
      var s = document.createElement('span'); s.className = 'si'; s.textContent = x[0];
      s.addEventListener('click', function (e) { e.stopPropagation(); [].forEach.call(document.querySelectorAll('.mi.open'), function (y) { y.classList.remove('open'); }); x[1](); });
      sb.appendChild(s);
    });
    mi.appendChild(sb);
    var ref = document.getElementById('p67cadMi'); m.insertBefore(mi, ref ? ref.nextSibling : null);
    return true;
  }
  function ver() { try { var vv = document.querySelector('[title*="Версия приложения"]'); if (vv) { vv.textContent = 'r71'; vv.title = 'Версия приложения (должно быть r71 после перезагрузки)'; } } catch (e) {} }
  var st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);
  rebuildLib();
  var n = 0, iv = setInterval(function () { var ok = menu(); ver(); if ((ok && n > 8) || ++n > 40) clearInterval(iv); }, 500);
  W.pcdProbe69 = W.pcdProbe68 = { lib: function () { return LIB; }, item: item, resolve: resolve, build: build, cfg: cfg, setCfg: setCfg, chainFromProbeName: chainFromProbeName, chainFor: chainFor, setChainFor: setChainFor, abFromDir: abFromDir,
    estimate: estimate, program: program, programProbes: programProbes, openTime: openTime, openBuilder: openBuilder, openIO: openIO, startPlay: startPlay, stopPlay: stopPlay, play: play, last: LAST, params: P, opts: opts, setOpts: setOpts,
    exportHits: exportHits, importHits: importHits, exportPath: exportPath, importPath: importPath, kinFor: kinFor, CMMS: CMMS, openCMM: openCMM, openDraws: openDraws, drawImport: drawImport, drawGet: drawGet, buildCMM: buildCMM,
    openRack: openRack, racks: racks, rackCfg: rackCfg, setRackCfg: setRackCfg, parseRackDat: parseRackDat, playSel: playSel, rangeFor: rangeFor, lineNames: lineNames, dockIndex: dockIndex };
  W.pcdProbe71 = W.pcdProbe70 = W.pcdProbe69;
})();
