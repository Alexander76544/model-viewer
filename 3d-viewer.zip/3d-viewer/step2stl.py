"""
STEP -> STL конвертер для больших сборок (для просмотра в приложении на телефоне).

Запускать через step2stl.bat:
    step2stl.bat вход.stp выход.stl [deflection]

или вручную из freecadcmd (он не умеет передавать argv скрипту, поэтому
параметры берутся из переменных окружения):
    set STEP2STL_IN=case.stp
    set STEP2STL_OUT=case.stl
    set STEP2STL_DEFL=0.5
    freecadcmd step2stl.py

Смысл: приложение на Android открывает .step/.stp через OCCT-WASM, у которого
потолок памяти ~2 ГБ — сборки из Creo/SolidWorks на 100+ МБ STEP в него физически
не влезают. Этот скрипт один раз тесселирует модель на ПК и пишет обычный .stl,
который в просмотрщике летает без ограничений.
"""
import os
import sys

import FreeCAD as App
import Import
import MeshPart
import Part


def main():
    src = os.environ.get('STEP2STL_IN') or (sys.argv[1] if len(sys.argv) > 1 else None)
    dst = os.environ.get('STEP2STL_OUT') or (sys.argv[2] if len(sys.argv) > 2 else None)
    defl = float(os.environ.get('STEP2STL_DEFL') or '0.5')
    if not src or not dst:
        print('usage: STEP2STL_IN / STEP2STL_OUT / STEP2STL_DEFL env vars (see step2stl.bat)')
        return
    print('converting:', src, '->', dst, '| deflection', defl)

    doc = App.newDocument('conv')
    Import.insert(src, doc.Name)
    doc.recompute()

    shapes = [o.Shape for o in doc.Objects
              if hasattr(o, 'Shape') and o.Shape is not None and not o.Shape.isNull()]
    if not shapes:
        print('ERROR: no shapes found in', src)
        return

    comp = shapes[0] if len(shapes) == 1 else Part.makeCompound(shapes)
    bb = comp.BoundBox
    print('shapes:', len(shapes), '| bbox mm:',
          round(bb.XLength, 1), round(bb.YLength, 1), round(bb.ZLength, 1))

    mesh = MeshPart.meshFromShape(Shape=comp, LinearDeflection=defl,
                                  AngularDeflection=0.6, Relative=False)
    mesh.write(dst)
    print('wrote:', dst, '| facets:', mesh.CountFacets)


main()
