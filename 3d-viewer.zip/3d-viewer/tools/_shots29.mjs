// _shots29.mjs — превью: preview-stock.png (asm, 🧮), preview-ar.png (🧊 стол), + обновлённый preview-sheet.svg
import fs from 'fs';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const j=async u=>{const r=await fetch(u);return r.json();};
const t=await j('http://127.0.0.1:9333/json');
const pg=t.find(x=>x.type==='page'&&x.webSocketDebuggerUrl);
const ws=new WebSocket(pg.webSocketDebuggerUrl);let id=0;const pend=new Map();
ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&pend.has(m.id)){pend.get(m.id)(m);}};
const send=(m,p={})=>new Promise(r=>{const i=++id;pend.set(i,r);ws.send(JSON.stringify({id:i,method:m,params:p}));});
await new Promise(r=>{ws.onopen=r});
await send('Runtime.enable'); await send('Page.enable');
await send('Emulation.setDeviceMetricsOverride',{width:1500,height:880,deviceScaleFactor:1,mobile:false});
const ev=async x=>{const m=await send('Runtime.evaluate',{expression:x,returnByValue:true,awaitPromise:true});if(m.result.exceptionDetails)throw new Error((m.result.exceptionDetails.exception?.description||'err').slice(0,300));return m.result.result.value;};
async function waitfor(expr,ms=240000){const dl=Date.now()+ms;for(;;){let v=false;try{v=await ev(expr);}catch(e){}if(v)return;if(Date.now()>dl)throw new Error('timeout '+expr);await sleep(500);}}
async function shot(file){const s=await send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(file,Buffer.from(s.result.data,'base64'));console.log('→',file);}
await send('Page.navigate',{url:'http://127.0.0.1:4173/?model=770_1003014-10.stp'});
await waitfor('!!(stlMesh3 && stepBodies3 && stepBodies3.length)');
await sleep(2500);
const svg=await ev('window.__sheetSVG3()');
fs.writeFileSync('preview-sheet.svg', svg);
console.log('→ preview-sheet.svg', (svg.length/1e6).toFixed(1)+'MB');
await send('Page.navigate',{url:'http://127.0.0.1:4173/?model=770_1003011-101_asm_asm.stp'});
await waitfor('stepBodies3 && stepBodies3.filter(b=>b._mesh).length >= stepBodies3.length-1',300000);
await sleep(2800);
// ① 🧮 заготовка на главной детали
await ev(`(function(){
  closeAllPanels2();
  window.__openPanel2('apAna');
  document.querySelectorAll('.anaTab')[3].click();
  const bs=stepBodies3.filter(b=>b._mesh&&b.vol); let big=bs[0]; for(const b of bs){ if(b.vol>big.vol) big=b; }
  const sel=document.getElementById('stockTarget'); fillStockSel3(); sel.value=String(big.id); stockSel3=String(big.id);
  stockRun3();
  aimCam3(...(function(){const bb=new THREE.Box3().setFromObject(big._mesh); const c=bb.getCenter(new THREE.Vector3()); return [c.x,c.y,c.z];})());
  camDist3 = Math.max(bb=>0,0) || camDist3;
  return 1;
})()`);
await sleep(1400);
await shot('preview-stock.png');
await ev(`(function(){ stockClr3(); return 1; })()`);
// ② 🧊 псевдостол
await ev(`(function(){ closeAllPanels2(); window.__openPanel2('apAr'); return 1; })()`);
await sleep(500);
await ev(`(function(){ window.__arTable3(true); return 1; })()`);
await sleep(1600);
await shot('preview-ar.png');
await ev(`(function(){ window.__arTable3(false); closeAllPanels2(); return 1; })()`);
console.log('DONE');
ws.close(); process.exit(0);

