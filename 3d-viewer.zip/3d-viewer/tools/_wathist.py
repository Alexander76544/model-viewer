# -*- coding: utf-8 -*-
import struct, sys, os
from collections import Counter
path = sys.argv[1]
f = open(path, 'rb'); f.seek(80)
n = struct.unpack('<I', f.read(4))[0]
rec = struct.Struct('<12fH')
edges = Counter()
verts = set()
degen = 0
for t in range(n):
    d = rec.unpack(f.read(50))
    a = (round(d[3], 2), round(d[4], 2), round(d[5], 2))
    b = (round(d[6], 2), round(d[7], 2), round(d[8], 2))
    c = (round(d[9], 2), round(d[10], 2), round(d[11], 2))
    verts.add(a); verts.add(b); verts.add(c)
    if a == b or b == c or c == a:
        degen += 1
        continue
    for p, q in ((a, b), (b, c), (c, a)):
        edges[(p if p < q else q, p if p < q else q)] += 1
f.close()
print('triangles: %d | degenerate: %d | unique verts (0.01mm): %d' % (n, degen, len(verts)))
hist = Counter(edges.values())
print('edge-count histogram (usage: #edges):')
for k in sorted(hist):
    if k <= 10:
        print('  %d : %d' % (k, hist[k]))
big = {k: hist[k] for k in hist if k > 10}
if big:
    print('  >10 :', dict(sorted(big.items())[:10]))
print('unique edges: %d' % len(edges))
