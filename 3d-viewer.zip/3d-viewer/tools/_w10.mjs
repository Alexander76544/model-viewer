const j=async u=>{const r=await fetch(u);return r.json();};
const t=await j('http://127.0.0.1:9333/json');
const pg=t.find(x=>x.type==='page'&&x.webSocketDebuggerUrl);
const ws=new WebSocket(pg.webSocketDebuggerUrl);let id=0;const pend=new Map();
ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&pend.has(m.id)){pend.get(m.id)(m);}};
const send=(m,p={})=>new Promise(r=>{const i=++id;pend.set(i,r);ws.send(JSON.stringify({id:i,method:m,params:p}));});
await new Promise(r=>{ws.onopen=r}); await send('Runtime.enable'); await send('Page.enable');
const ex=async x=>{const m=await send('Runtime.evaluate',{expression:x,returnByValue:true,awaitPromise:true});if(m.result.exceptionDetails)return 'EXC '+(m.result.exceptionDetails.exception?.description||'').slice(0,500);return m.result.result.value;};
await send('Page.navigate',{url:'http://127.0.0.1:4173/?model=770_1003014-10.stp'});
for(let i=0;i<90;i++){ const ok=await ex('!!(stlMesh3 && stepBodies3 && stepBodies3.filter(b=>b._mesh).length>=stepBodies3.length-1)').catch(()=>false); if(ok)break; await new Promise(r=>setTimeout(r,600)); }
await new Promise(r=>setTimeout(r,2500));
console.log('STOCK', await ex(`(()=>{
  const bs=stepBodies3.filter(b=>b._mesh&&b.vol); let big=bs[0]; for(const b of bs){ if(b.vol>big.vol) big=b; }
  const sel=document.getElementById('stockTarget'); if(!sel) return 'NO SELECT';
  sel.value=String(big.id); stockSel3=String(big.id);
  const r=stockRun3(); if(!r) return 'NULL';
  const vs=r.variants.map(v=>v.key+':'+(v.vol/1000).toFixed(0)+'см³ k='+(v.use).toFixed(0)+'%'+(v.best?' *':''));
  const rows=document.querySelectorAll('#stockList .stockRow').length;
  const wires=stockGrp3?stockGrp3.children.length:0;
  const vis=stockGrp3?stockGrp3.children.filter(c=>c.visible).length:0;
  const csv=stockCsvText3().length;
  return { big:+(big.vol/1000).toFixed(0)+'см³', vs, rows, wires, vis, csv, cylR:r.cyl?+r.cyl.r.toFixed(1):null, cylLen:r.cyl?+r.cyl.len.toFixed(0):null };
})()`));
console.log('STOCK-ALL', await ex(`(()=>{ stockSel3='all'; document.getElementById('stockTarget').value='all'; const r=stockRun3(); return r? r.variants.map(v=>v.key+' '+(v.vol/1e6).toFixed(1)+'дм³'+(v.best?'*':'')) : 'NULL'; })()`));
console.log('TABLE', await ex(`(()=>{
  const before={p:stlMesh3.position.clone(), s:stlMesh3.scale.x, d:camDist3, t:camTarget3.clone()};
  window.__arTable3(true);
  const mid={ py:+stlMesh3.position.y.toFixed(0), grid:!!tableGrp3, children:tableGrp3?tableGrp3.children.length:0, camY:+camera3.position.y.toFixed(0), dist:+camDist3.toFixed(0) };
  window.__arTable3(false);
  const after={ dpos:+stlMesh3.position.distanceTo(before.p).toFixed(3), dscale:+(stlMesh3.scale.x-before.s).toFixed(6), ddist:+(camDist3-before.d).toFixed(3), gridGone:!tableGrp3 };
  return { mid, after, ok: mid.grid && mid.children>=3 && after.dpos<0.01 && after.ddist<0.01 && after.gridGone };
})()`));
console.log('AR-GA', await ex(`(async()=>{
  const ok=await window.__arSupport3();
  const go=document.getElementById('arGoBtn'), st=document.getElementById('arStatus');
  await arCheck3();
  return { supported:ok, goDisabled:go.disabled, status:st.textContent.slice(0,40) };
})()`));
console.log('SHEET-D', await ex(`(()=>{ const s=window.__sheetSVG3(); return { ok: s.includes('↔') && s.includes('↕') && (s.match(/<path/g)||[]).length===4, w:s.match(/↔ (\\d+)/)?.[1], h:s.match(/↕ (\\d+)/)?.[1] }; })()`));
ws.close();process.exit(0);

