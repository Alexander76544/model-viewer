// _persist25.mjs — создал замеры/вид/бокс → F5 → всё восстановилось
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const j=async u=>{const r=await fetch(u);return r.json();};
const t=await j('http://127.0.0.1:9333/json');
const pg=t.find(x=>x.type==='page'&&x.webSocketDebuggerUrl);
const ws=new WebSocket(pg.webSocketDebuggerUrl);let id=0;const pend=new Map();
ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&pend.has(m.id)){pend.get(m.id)(m);pend.delete(m.id);}};
const send=(m,p={})=>new Promise(r=>{const i=++id;pend.set(i,r);ws.send(JSON.stringify({id:i,method:m,params:p}));});
await new Promise(r=>{ws.onopen=r});
await send('Runtime.enable'); await send('Page.enable');
const ev=async x=>{const m=await send('Runtime.evaluate',{expression:x,returnByValue:true});if(m.result.exceptionDetails)throw new Error((m.result.exceptionDetails.exception?.description||'err').slice(0,200));return m.result.result.value;};
async function waitfor(expr,ms=15000){const dl=Date.now()+ms;for(;;){let v=false;try{v=await ev(expr);}catch(e){}if(v)return;if(Date.now()>dl)throw new Error('wait timeout '+expr);await sleep(300);}}

// страница: small
await send('Page.navigate',{url:'http://127.0.0.1:4173/?model=770_1003014-10.stp'});
await waitfor('stepBodies3 && stepBodies3.length>0', 30000); await sleep(1500);
const made = await ev(`(function(){
  closeAllPanels2 && closeAllPanels2();
  document.getElementById('viewNameInput').value='PERSIST'; document.getElementById('captureViewBtn').click();
  setMeasureMode3(true);
  const rect=renderer3.domElement.getBoundingClientRect();
  const scr=v=>{const p=v.clone().project(camera3);return [rect.left+(p.x*.5+.5)*rect.width, rect.top+(-p.y*.5+.5)*rect.height];};
  const bb=new THREE.Box3().setFromObject(stepBodies3.filter(b=>b._mesh)[0]._mesh);
  const A=scr(bb.getCenter(new THREE.Vector3()));
  const ra=measurePick3(A[0],A[1]); let B=null;
  for(let dx=-240;dx<=240&&!B;dx+=60)for(let dy=-180;dy<=180&&!B;dy+=45){const q=[A[0]+dx,A[1]+dy];const r=measurePick3(q[0],q[1]);if(r&&r.point.distanceTo(ra.point)>5)B=q;}
  measureClick3(A[0],A[1]); measureClick3(B[0],B[1]);
  setMeasureMode3(false);
  clipState3.enabled=true; clipState3.mode='box'; clipState3.box.on.z=true; clipState3.box.z=[0.25,0.9];
  applyStlClipping();
  scheduleModelMetaAutosave();
  return {views:views3.length, meas:measures3.length};
})()`);
console.log('создано:', JSON.stringify(made));
await sleep(1400); // автосейв
await send('Page.navigate',{url:'http://127.0.0.1:4173/'});
await waitfor('stepBodies3 && stepBodies3.length>0', 30000); await sleep(2500);
const got = await ev(`({views: views3.map(v=>v.name), meas: measures3.length, snapA: measures3[0]&&measures3[0].sa!==undefined, clipOn: clipState3.enabled, clipMode: clipState3.mode, z: clipState3.box.z, zOn: clipState3.box.on.z, planes: (stlMesh3&&stlMesh3.children.find(c=>c.material&&c.material.clippingPlanes))? stlMesh3.children.find(c=>c.material.clippingPlanes).material.clippingPlanes.length : -1})`);
console.log('после F5:', JSON.stringify(got));
const ok = got.views.includes('PERSIST') && got.meas>=1 && got.clipOn && got.clipMode==='box' && Math.abs(got.z[0]-0.25)<0.01 && got.zOn && got.planes===2;
console.log(ok ? 'PERSIST OK' : 'PERSIST FAIL');
ws.close(); process.exit(ok?0:1);
