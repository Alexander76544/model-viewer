// _w7.mjs — smoke: ⚖️ массы + ⌚ грань-замер на текущей модели
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const j=async u=>{const r=await fetch(u);return r.json();};
const URL_=process.argv[2]||'http://127.0.0.1:4173/?model=770_1003011-101_asm_asm.stp';
const t=await j('http://127.0.0.1:9333/json');
const pg=t.find(x=>x.type==='page'&&x.webSocketDebuggerUrl);
const ws=new WebSocket(pg.webSocketDebuggerUrl);let id=0;const pend=new Map();
ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&pend.has(m.id)){pend.get(m.id)(m);pend.delete(m.id);}};
const send=(m,p={})=>new Promise(r=>{const i=++id;pend.set(i,r);ws.send(JSON.stringify({id:i,method:m,params:p}));});
await new Promise(r=>{ws.onopen=r});
await send('Runtime.enable'); await send('Page.enable');
const ev=async x=>{const m=await send('Runtime.evaluate',{expression:x,returnByValue:true,awaitPromise:true});if(m.result.exceptionDetails)throw new Error((m.result.exceptionDetails.exception?.description||'EXC').slice(0,300));return m.result.result.value;};
async function waitfor(expr,ms=90000){const dl=Date.now()+ms;for(;;){let v=false;try{v=await ev(expr);}catch(e){}if(v)return;if(Date.now()>dl)throw new Error('wait '+expr);await sleep(400);}}
await send('Page.navigate',{url:URL_});
await waitfor('stepBodies3 && stepBodies3.length>0');
await waitfor('stepBodies3.filter(b=>b._mesh).length >= stepBodies3.length-1',150000);
await sleep(1500);
console.log('MASS', JSON.stringify(await ev(`(()=>{
  const T = massTotals3();
  const rows = document.querySelectorAll('#massList .massRow').length;
  return { kg: +(T.g/1000).toFixed(2), n: T.n, noV: T.noV, cg: T.cg && T.cg.map(v=>+v.toFixed(1)), rows, totalTxt: document.getElementById('massTotal').textContent.slice(0,40) };
})()`)));
console.log('FACECAT', JSON.stringify(await ev(`(()=>{
  const nb = Object.keys(faceCatalog3).length;
  let P=0,C=0,K=0,S=0; for(const b of Object.values(faceCatalog3)) for(const f of b){ if(f.t==='P')P++; else if(f.t==='C')C++; else if(f.t==='K')K++; else S++; }
  return {nb, P,C,K,S};
})()`)));
console.log('PROBE', JSON.stringify(await ev(`(()=>{
  setFaceMode3(true);
  const rect = renderer3.domElement.getBoundingClientRect();
  const scr=(v)=>{const p=v.clone().project(camera3);return [rect.left+(p.x*.5+.5)*rect.width, rect.top+(-p.y*.5+.5)*rect.height];};
  // тело с максимальным числом плоскостей, чей bbox виден крупно: просто переберём кандидатов
  const cand = Object.entries(faceCatalog3).map(([bid,fs])=>({bid:+bid, p:fs.filter(f=>f.t==='P').length}))
    .filter(x=>x.p>=3).sort((a,b)=>b.p-a.p).slice(0,6);
  let out={cyl:false, one:false, pair:false, pairTxt:null, inMeta:false};
  for(const c of cand){
    const b=stepBodies3.find(x=>x.id===c.bid); if(!b||!b._mesh) continue;
    const bb=new THREE.Box3().setFromObject(b._mesh); const ctr=scr(bb.getCenter(new THREE.Vector3()));
    let pxA=null, fA=null;
    outer0: for(let dx=-140; dx<=140; dx+=10){ for(let dy=-100; dy<=100; dy+=10){
      const rr=measurePick3(ctr[0]+dx, ctr[1]+dy);
      if(!rr || rr.bid!==c.bid) continue;
      const ff=matchFace3(rr.bid, rr.point);
      if(ff && ff.t==='P'){ pxA=[ctr[0]+dx, ctr[1]+dy]; fA=ff; break outer0; }
    } }
    if(!pxA) continue;
    faceClick3(pxA[0], pxA[1]);
    out.one = probes3.length===1 && String(probes3[0].txt).indexOf('①')===0;
    let pxB=null, fB=null;
    outer1: for(let dx=-140; dx<=140; dx+=10){ for(let dy=-100; dy<=100; dy+=10){
      const rr=measurePick3(ctr[0]+dx, ctr[1]+dy);
      if(!rr || rr.bid!==c.bid) continue;
      const ff=matchFace3(rr.bid, rr.point);
      if(ff && ff.t==='P' && ff!==fA){ pxB=[ctr[0]+dx, ctr[1]+dy]; fB=ff; break outer1; }
    } }
    if(!pxB) continue;
    faceClick3(pxB[0], pxB[1]);
    const last = probes3[probes3.length-1];
    out.pair = probes3.length===2 && !!last && String(last.txt).indexOf('①')!==0;
    out.pairTxt = last && String(last.txt).slice(0,80);
    out.inMeta = (currentModelMeta().probes3||[]).length===2;
    if(out.pair) break;
  }
  return out;
})()`)));
console.log('CLEANUP', JSON.stringify(await ev(`(()=>{ setFaceMode3(false); resetMeasureState3(); return probes3.length===0; })()`)));
ws.close(); process.exit(0);
