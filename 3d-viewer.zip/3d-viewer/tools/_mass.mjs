// _mass.mjs <dir.bodies> — v5: сверка GProp-объёма с объёмом по мешу (signed tetra)
import fs from 'fs'; import path from 'path';
const dir = process.argv[2];
const man = JSON.parse(fs.readFileSync(path.join(dir,'manifest.json'),'utf8'));
function stlVol(f){
  const buf = fs.readFileSync(f);
  const n = buf.readUInt32LE(80);
  let s = 0;
  for(let i=0;i<n;i++){
    const o = 84 + i*50;
    const x1=buf.readFloatLE(o+12),y1=buf.readFloatLE(o+16),z1=buf.readFloatLE(o+20);
    const x2=buf.readFloatLE(o+24),y2=buf.readFloatLE(o+28),z2=buf.readFloatLE(o+32);
    const x3=buf.readFloatLE(o+36),y3=buf.readFloatLE(o+40),z3=buf.readFloatLE(o+44);
    s += (x1*(y2*z3-z2*y3) - y1*(x2*z3-z2*x3) + z1*(x2*y3-y2*x3))/6;
  }
  return Math.abs(s);
}
let nv=0, sumG=0, worst=0, nf=0, snapC=0, planeC=0, coneC=0, sphC=0, ncmOut=0;
for(const b of man.bodies||[]){
  if(b.faces){ nf++; for(const e of b.faces){ if(e.t==='C')snapC++; else if(e.t==='P')planeC++; else if(e.t==='K')coneC++; else sphC++; } }
  if(!b.vol) continue;
  nv++; sumG += b.vol;
  if(b.bb){ const inbb = b.cm[0]>b.bb[0]-1&&b.cm[0]<b.bb[3]+1&&b.cm[1]>b.bb[1]-1&&b.cm[1]<b.bb[4]+1&&b.cm[2]>b.bb[2]-1&&b.cm[2]<b.bb[5]+1; if(!inbb) ncmOut++; }
  const f = path.join(dir, b.file);
  if(fs.existsSync(f)){
    const mv = stlVol(f);
    const rel = Math.abs(mv-b.vol)/Math.max(b.vol,mv);
    if(rel>worst) worst=rel;
  }
}
console.log(`v:${man.v} тел с vol: ${nv} (ЦТ вне bb: ${ncmOut}) ΣV=${(sumG/1e6).toFixed(3)} л, max отклонение mesh-vs-GProp: ${(worst*100).toFixed(2)}%`);
console.log(`тел с faces: ${nf} — граней: P ${planeC}, C ${snapC}, K ${coneC}, S ${sphC}`);
