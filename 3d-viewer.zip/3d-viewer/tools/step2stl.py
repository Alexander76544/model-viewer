# -*- coding: utf-8 -*-
r"""step2stl.py — портативный STEP(.stp/.step) -> binary STL конвертер (3d-viewer pipeline).

Пишет binary STL для вьювера «3D просмотр моделей». Бэкенды (по убыванию предпочтения):

[gmsh]       python-модуль gmsh (pip install gmsh — без прав админа): импорт STEP через
             OpenCascade + ЧВЕТ из XCAF (COLOUR_RGB/SURFACE_STYLE_USAGE). Цвет фасетки —
             в 16-битном attribute-байте STL (RGB555 + старший бит-флаг); неокрашенные —
             серый из заголовка (COLOR=).
[fc-xcaf]    Внутри GUI FreeCAD (консоль Python): цвета из ViewObject по компонентам сборки.
[fc-plain]   freecadcmd без gmsh: вся геометрия одним проходом BRepMesh, без цветов.

Запуск:
1) Windows: перетащить .stp/.step на step2stl.bat — бэкенд выбирается сам
   (сначала python+gmsh, затем freecadcmd). Качество: set FC_LIN=<мм> (0.2 по умолчанию),
   цвет вкл/выкл: set FC_COLOR=1|0.
2) cmd, параметры переменными окружения (freecadcmd не передаёт аргументы скрипту):
      set S2S_SRC=C:\модель.stp
      set S2S_DST=C:\out\модель.stl      (по умолчанию — рядом с источником)
      set S2S_LIN=0.2  S2S_ANG=0.5  S2S_REL=1  S2S_COLOR=1  S2S_DST2=...  S2S_LIN2=0.6
      python step2stl.py   (или)   <...>\freecadcmd.exe step2stl.py
3) GUI FreeCAD (Вид → Консоль Python):
      ns = {}
      exec(open(r"D:\\step2stl-portable\\step2stl.py", encoding="utf-8").read(), ns)
      ns["main"](r"C:\\модель.stp", lin=0.2)

lin — линейная дефлексия, мм. Ориентиры: 0.2 — баланс; 0.15–0.17 — максимум деталей
(до ~1 ГБ STL на большую сборку); 0.5..1 — лёгкие превью.
"""
import os, sys, time, struct

_HDR = (b'COLOR=' + bytes((0x94, 0xA3, 0xB8, 0xFF)) + b' step2stl colored binary STL')[:80].ljust(80, b' ')


def _log(msg):
    print('[step2stl] ' + msg)
    try:
        sys.stdout.flush()
    except Exception:
        pass


def _rgb565(rgb):
    """(r,g,b) в шкале 0..1 или 0..255 -> RGB555 uint16 со старшим битом-флагом (читает viewer)."""
    if rgb is None:
        return 0
    try:
        r, g, b = float(rgb[0]), float(rgb[1]), float(rgb[2])
        if max(r, g, b) > 1.01:
            r, g, b = r / 255.0, g / 255.0, b / 255.0
        r5 = int(round(max(0.0, min(1.0, r)) * 31))
        g5 = int(round(max(0.0, min(1.0, g)) * 31))
        b5 = int(round(max(0.0, min(1.0, b)) * 31))
    except Exception:
        return 0
    return 0x8000 | (r5 << 10) | (g5 << 5) | b5


class StlWriter(object):
    """Потоковый writer binary STL с палитрой по фасеткам. total считается сам."""

    def __init__(self, path):
        self.f = open(path, 'wb')
        self.f.write(_HDR)
        self.f.write(struct.pack('<I', 0))
        self.total = 0

    def write_np(self, verts, attr):
        """verts: (n,3,3) float (np массив или вложенные списки), attr: uint16."""
        import numpy as np
        v = np.ascontiguousarray(verts, dtype='<f4')
        n = int(v.shape[0])
        if not n:
            return
        cr = np.cross(v[:, 1] - v[:, 0], v[:, 2] - v[:, 0])
        ln = np.linalg.norm(cr, axis=1)
        ln[ln == 0] = 1.0
        cr = cr / ln[:, None]
        rec = np.zeros((n, 25), dtype='<u2')
        rec[:, 0:6] = cr.view('<u2')
        rec[:, 6:24] = v.reshape(n, 9).view('<u2')
        rec[:, 24] = np.uint16(attr)
        self.f.write(rec.tobytes())
        self.total += n

    def write_iter(self, facets, attr):
        """facets: итерат по ((x,y,z)x3 v0,v1,v2); без numpy."""
        pack = struct.Struct('<12fH').pack
        buf = bytearray()
        nf = 0
        for (a, b, c) in facets:
            ux = b[0] - a[0]; uy = b[1] - a[1]; uz = b[2] - a[2]
            vx = c[0] - a[0]; vy = c[1] - a[1]; vz = c[2] - a[2]
            nx = uy * vz - uz * vy; ny = uz * vx - ux * vz; nz = ux * vy - uy * vx
            l = (nx * nx + ny * ny + nz * nz) ** 0.5 or 1.0
            buf += pack(nx / l, ny / l, nz / l, a[0], a[1], a[2],
                        b[0], b[1], b[2], c[0], c[1], c[2], attr)
            nf += 1
            if len(buf) >= (1 << 20):
                self.f.write(bytes(buf))
                buf = bytearray()
        if buf:
            self.f.write(bytes(buf))
        self.total += nf

    def footer(self):
        self.f.seek(80)
        self.f.write(struct.pack('<I', self.total))
        self.f.close()


# ==================== бэкенд 1b: OCP (cadquery-ocp): OCC ядро + XCAF цвет ====================
def run_ocp(src, dst, lin, ang, rel=False):
    """OCC-ядро BRepMesh (как FreeCAD) + цвета STEP через XCAF. pip install cadquery-ocp."""
    from OCP.STEPCAFControl import STEPCAFControl_Reader
    from OCP.TDocStd import TDocStd_Document
    from OCP.TCollection import TCollection_ExtendedString
    from OCP.XCAFDoc import XCAFDoc_DocumentTool
    from OCP.TopoDS import TopoDS
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopAbs import TopAbs_FACE
    from OCP.BRep import BRep_Tool
    from OCP.BRepMesh import BRepMesh_IncrementalMesh
    from OCP.TopLoc import TopLoc_Location
    from OCP.TDF import TDF_ChildIterator, TDF_AttributeIterator
    try:                                   # OCP <= 7.x
        from OCP.TDF import TDF_LabelSequence as LSeq
    except Exception:                      # OCP >= 8
        from OCP.collections import Sequence_TDF_Label as LSeq

    doc = TDocStd_Document(TCollection_ExtendedString("XmlOcaf"))
    reader = STEPCAFControl_Reader()
    try:
        reader.SetColorMode(True)
    except Exception:
        pass
    if reader.ReadFile(src) != 1:
        raise RuntimeError('OCP: не удалось прочитать файл')
    if not reader.Transfer(doc):
        raise RuntimeError('OCP: Transfer не выполнен')
    shp_tool = XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
    col_tool = XCAFDoc_DocumentTool.ColorTool_s(doc.Main())

    # ---------- цвета XCAF ----------
    # STEPCAFControl_Reader кладёт цвета граней в карту ColorTool по формам БЕЗ размещения
    # (хэш TopoDS в этой карте игнорирует location), поэтому ключ — грань со сброшенным TopLoc:
    from OCP.XCAFDoc import XCAFDoc_ColorSurf, XCAFDoc_ColorGen, XCAFDoc_ColorCurv
    from OCP.Quantity import Quantity_ColorRGBA
    _CT = (XCAFDoc_ColorSurf, XCAFDoc_ColorGen, XCAFDoc_ColorCurv)

    def face_color(face):
        try:
            key = face.Located(TopLoc_Location())
        except Exception:
            key = face
        for _t in _CT:
            try:
                c = Quantity_ColorRGBA()
                if col_tool.GetColor(key, _t, c):
                    qq = c.GetRGB()
                    return (qq.Red(), qq.Green(), qq.Blue())
            except Exception:
                continue
        return None

    _log('ocp: XCAF ColorTool готов, ищу корни...')

    roots = LSeq()
    shp_tool.GetFreeShapes(roots)
    nr = roots.Length()
    _log('ocp: корней %d, BRepMesh lin=%.3f мм...' % (nr, lin))

    t0 = time.time()
    w = StlWriter(dst)
    ncolf = 0
    for ri in range(1, nr + 1):
        try:
            shp = shp_tool.GetShape_s(roots.Value(ri))
        except Exception:
            shp = None
        if shp is None or shp.IsNull():
            continue
        try:
            BRepMesh_IncrementalMesh(shp, lin, rel, ang, True)
        except Exception:
            BRepMesh_IncrementalMesh(shp, lin, rel, ang)
        exp = TopExp_Explorer(shp, TopAbs_FACE)
        nf = 0
        while exp.More():
            nf += 1
            face = None
            try:
                face = TopoDS.Face(exp.Current())
            except Exception:
                pass
            if face is not None:
                col = face_color(face)
                if col:
                    ncolf += 1
                attr = _rgb565(col)
                loc = TopLoc_Location()
                try:
                    tri = BRep_Tool.Triangulation_s(face, loc)
                except Exception:
                    try:
                        tri = BRep_Tool.Triangulation(face, loc)
                    except Exception:
                        tri = None
                if tri is not None:
                    trsf = loc.Transformation()
                    pts = [tri.Node(i).Transformed(trsf) for i in range(1, tri.NbNodes() + 1)]
                    verts = []
                    for k in range(1, tri.NbTriangles() + 1):
                        t = tri.Triangle(k)
                        i1 = t.Value(1); i2 = t.Value(2); i3 = t.Value(3)
                        p1 = pts[i1 - 1]; p2 = pts[i2 - 1]; p3 = pts[i3 - 1]
                        verts.append(((p1.X(), p1.Y(), p1.Z()), (p2.X(), p2.Y(), p2.Z()), (p3.X(), p3.Y(), p3.Z())))
                    try:
                        if face.Orientation() == 1:  # TopAbs_REVERSED
                            verts = [(a, c, b) for (a, b, c) in verts]
                    except Exception:
                        pass
                    if verts:
                        try:
                            import numpy as np
                            w.write_np(np.asarray(verts, dtype=np.float64), attr)
                        except Exception:
                            w.write_iter(verts, attr)
            exp.Next()
        _log('ocp: корень %d/%d: граней %d, фасеток %d (%.0fs)' % (ri, nr, nf, w.total, time.time() - t0))
    w.footer()
    _log('ocp: wrote %s (%.1f MB, %d facets, %d/%d граней окрашено)' % (
        dst, os.path.getsize(dst) / 1048576.0, w.total, ncolf, nf))
    if w.total == 0:
        raise RuntimeError('OCP: пустая сетка')
    return w.total


# ==================== бэкенд 1c: OCP, РАЗБОР ПО ТЕЛАМ (дерево STEP) ====================
def _emit_faces(shp, face_color, w):
    """Огранить все грани shp в StlWriter w; вернуть (грани, окрашено, фасетки, rgb-накопление)."""
    from OCP.TopoDS import TopoDS
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopAbs import TopAbs_FACE
    from OCP.BRep import BRep_Tool
    from OCP.TopLoc import TopLoc_Location
    nf = 0; ncol = 0; rgb = [0.0, 0.0, 0.0]; nrgb = 0
    vol = 0.0; cx = 0.0; cy = 0.0; cz = 0.0
    exp = TopExp_Explorer(shp, TopAbs_FACE)
    while exp.More():
        nf += 1
        face = None
        try:
            face = TopoDS.Face(exp.Current())
        except Exception:
            pass
        if face is not None:
            col = face_color(face)
            attr = _rgb565(col)
            if col:
                ncol += 1
                rgb[0] += col[0]; rgb[1] += col[1]; rgb[2] += col[2]; nrgb += 1
            loc = TopLoc_Location()
            try:
                tri = BRep_Tool.Triangulation_s(face, loc)
            except Exception:
                try:
                    tri = BRep_Tool.Triangulation(face, loc)
                except Exception:
                    tri = None
            if tri is not None:
                trsf = loc.Transformation()
                pts = [tri.Node(i).Transformed(trsf) for i in range(1, tri.NbNodes() + 1)]
                rev = False
                try:
                    rev = (face.Orientation() == 1)  # TopAbs_REVERSED
                except Exception:
                    pass
                verts = []
                for k in range(1, tri.NbTriangles() + 1):
                    t = tri.Triangle(k)
                    i1 = t.Value(1); i2 = t.Value(2); i3 = t.Value(3)
                    p1 = pts[i1 - 1]; p2 = pts[i2 - 1]; p3 = pts[i3 - 1]
                    if rev:
                        verts.append(((p1.X(), p1.Y(), p1.Z()), (p3.X(), p3.Y(), p3.Z()), (p2.X(), p2.Y(), p2.Z())))
                    else:
                        verts.append(((p1.X(), p1.Y(), p1.Z()), (p2.X(), p2.Y(), p2.Z()), (p3.X(), p3.Y(), p3.Z())))
                    # объём и ЦТ — по той же триангуляции, та же ориентация, что пишется в STL
                    a = (p1.X(), p1.Y(), p1.Z()); b = (p2.X(), p2.Y(), p2.Z()); cc = (p3.X(), p3.Y(), p3.Z())
                    tv = (a[0] * (b[1] * cc[2] - b[2] * cc[1])
                          - a[1] * (b[0] * cc[2] - b[2] * cc[0])
                          + a[2] * (b[0] * cc[1] - b[1] * cc[0])) / 6.0
                    if rev:
                        tv = -tv
                    vol += tv
                    cx += tv * (a[0] + b[0] + cc[0]) * 0.25
                    cy += tv * (a[1] + b[1] + cc[1]) * 0.25
                    cz += tv * (a[2] + b[2] + cc[2]) * 0.25
                if verts:
                    try:
                        w.write_np(__import__('numpy').asarray(verts, dtype=__import__('numpy').float64), attr)
                    except Exception:
                        w.write_iter(verts, attr)
        exp.Next()
    avg = [rgb[0] / nrgb, rgb[1] / nrgb, rgb[2] / nrgb] if nrgb else None
    av = abs(vol)
    cm = None
    if av > 1.0 and nf:
        sgn = 1.0 if vol > 0 else -1.0
        cm = [round(cx * sgn / av, 2), round(cy * sgn / av, 2), round(cz * sgn / av, 2)]
    return nf, ncol, avg, (round(av, 1) if av > 1.0 else None), cm


def _body_shape(shp):
    """SOLID'ы формы (для разбивки «несколько тел в одном продукте»); если нет — SHELL-оболочки."""
    from OCP.TopoDS import TopoDS
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopAbs import TopAbs_SOLID, TopAbs_SHELL
    out = []
    try:
        exp = TopExp_Explorer(shp, TopAbs_SOLID)
        while exp.More():
            try:
                out.append(TopoDS.Solid(exp.Current()))
            except Exception:
                pass
            exp.Next()
    except Exception:
        pass
    if not out:
        try:
            exp = TopExp_Explorer(shp, TopAbs_SHELL)
            while exp.More():
                try:
                    out.append(TopoDS.Shell(exp.Current()))
                except Exception:
                    pass
                exp.Next()
        except Exception:
            pass
    return out


def _count_faces(shp):
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopAbs import TopAbs_FACE
    n = 0
    try:
        ex = TopExp_Explorer(shp, TopAbs_FACE)
        while ex.More():
            n += 1
            ex.Next()
    except Exception:
        return 0
    return n


def _step_sections(src, cap=300):
    """Сечения/виды, которые CAD экспортирует в AP242 как draughting-модели с отсекающими плоскостями.

    Creo (AP242, «Include: X-Section/Views») пишет каждый разрез как
        DRAUGHTING_MODEL('XSEC0001', (...))  +  CAMERA_MODEL_D3_MULTI_CLIPPING('XSEC0001', #cam, #vol, (#planes))
        #plane = PLANE('', AXIS2_PLACEMENT_3D(#point, #normal, #xdir))
    Возвращает [{'name','planes':[{'o':[x,y,z],'n':[dx,dy,dz]}],'cam':{...}|None}] — в системе детали, мм.
    """
    import re
    try:
        if os.path.getsize(src) > 400 * 1048576:
            return []
        raw = open(src, 'r', encoding='utf-8', errors='replace').read()
        if 'DRAUGHTING_MODEL' not in raw or 'CAMERA_MODEL_D3_MULTI_CLIPPING' not in raw:
            return []
        sec = raw.split('DATA;', 1)[1].split('ENDSEC;')[0]
        del raw
    except BaseException:
        return []

    def split_list(s):
        out, buf, depth, inq = [], '', 0, False
        for c in s or '':
            if inq:
                buf += c
                if c == "'":
                    inq = False
                continue
            if c == "'":
                inq = True
                buf += c
                continue
            if c == '(':
                depth += 1
            elif c == ')':
                depth -= 1
            if c == ',' and depth == 0:
                out.append(buf.strip())
                buf = ''
            else:
                buf += c
        if buf.strip():
            out.append(buf.strip())
        return out

    def unq(a):
        a = (a or '').strip()
        return a[1:-1].replace("''", "'").strip() if len(a) > 1 and a[0] == "'" else ''

    def rid(a):
        m = re.match(r'\s*#(\d+)', a or '')
        return m.group(1) if m else None

    def refs(a):
        return re.findall(r'#(\d+)', a or '')

    try:
        RX_BIG = re.compile(r"#(\d+)\s*=\s*(DRAUGHTING_MODEL|CAMERA_MODEL_D3_MULTI_CLIPPING|PLANE|AXIS2_PLACEMENT_3D)\s*\(([^;]*?)\)\s*;", re.S)
        big = {}
        for m in RX_BIG.finditer(sec):
            big[m.group(1)] = (m.group(2), m.group(3))

        views = []
        for _eid, (ty, args) in big.items():
            if ty != 'CAMERA_MODEL_D3_MULTI_CLIPPING':
                continue
            a = split_list(args)
            name = unq(a[0]) if a else ''
            cam = rid(a[1]) if len(a) > 1 else None
            clips = refs(a[3]) if len(a) > 3 else []
            if not clips:
                continue
            views.append({'name': name or 'разрез', 'cam': cam, 'clips': clips})

        need = set()
        plac_of_plane = {}
        for v in views:
            for c in v['clips']:
                ent = big.get(c)
                if not ent or ent[0] != 'PLANE':
                    continue
                pa = split_list(ent[1])
                pl = rid(pa[1]) if len(pa) > 1 else None
                if not pl or pl not in big or big[pl][0] != 'AXIS2_PLACEMENT_3D':
                    continue
                plac_of_plane[c] = pl
                pa2 = split_list(big[pl][1])
                if len(pa2) > 2:
                    need.add(rid(pa2[1])); need.add(rid(pa2[2]))
            if v['cam'] and v['cam'] in big and big[v['cam']][0] == 'AXIS2_PLACEMENT_3D':
                pa3 = split_list(big[v['cam']][1])
                for i in (1, 2, 3):
                    if len(pa3) > i:
                        need.add(rid(pa3[i]))
        need.discard(None)
        if not plac_of_plane:
            return []

        pts, dirs = {}, {}
        RX_SMALL = re.compile(r"#(\d+)\s*=\s*(CARTESIAN_POINT|DIRECTION)\s*\(\s*'[^']*'\s*,\s*\(\s*([-0-9.Ee+]+)\s*,\s*([-0-9.Ee+]+)\s*,\s*([-0-9.Ee+]+)\s*\)\s*\)\s*;")
        for m in RX_SMALL.finditer(sec):
            i = m.group(1)
            if i not in need:
                continue
            val = (float(m.group(3)), float(m.group(4)), float(m.group(5)))
            (pts if m.group(2) == 'CARTESIAN_POINT' else dirs)[i] = val

        out, seen = [], set()
        for v in views:
            planes = []
            for c in v['clips']:
                pl = plac_of_plane.get(c)
                if not pl:
                    continue
                pa = split_list(big[pl][1])
                o = pts.get(rid(pa[1]) if len(pa) > 1 else '')
                n = dirs.get(rid(pa[2]) if len(pa) > 2 else '')
                if not o or not n or (n[0] == 0 and n[1] == 0 and n[2] == 0):
                    continue
                key = (tuple(round(x, 3) for x in o), tuple(round(x, 3) for x in n))
                if key in seen:
                    continue
                seen.add(key)
                planes.append({'o': [round(x, 4) for x in o], 'n': [round(x, 4) for x in n]})
            if not planes:
                continue
            cam = None
            if v['cam'] and v['cam'] in big:
                ca = split_list(big[v['cam']][1])
                co = pts.get(rid(ca[1]) if len(ca) > 1 else '')
                cz = dirs.get(rid(ca[2]) if len(ca) > 2 else '')
                cx = dirs.get(rid(ca[3]) if len(ca) > 3 else '')
                if co and cz:
                    cam = {'o': [round(x, 3) for x in co], 'z': [round(x, 5) for x in cz],
                           'x': ([round(x, 5) for x in cx] if cx else None)}
            out.append({'name': (v['name'] or 'разрез')[:60], 'planes': planes, 'cam': cam})
            if len(out) >= cap:
                break
        return out
    except BaseException:
        return []


def _step_named_planes(src, cap=400):
    """Именованные плоскости (датумы/опорные плоскости) из текста STEP.

    Возвращает [{'name':str, 'o':[x,y,z], 'n':[dx,dy,dz], 'x':[dx,dy,dz]}].
    Пустой список — если CAD их не экспортировал (у Creo по умолчанию так и есть,
    в этом случае «разрез» строится в самом просмотрщике либо вырезом в Creo).
    Координаты — в системе детали, мм (та же, что у тел в манифесте).
    """
    import re
    try:
        if os.path.getsize(src) > 400 * 1048576:
            return []
        raw = open(src, 'r', encoding='utf-8', errors='replace').read()
        if 'PLANE(' not in raw or 'AXIS2_PLACEMENT_3D' not in raw:
            return []
        parts = raw.split('DATA;')
        if len(parts) < 2:
            return []
        sec = parts[1].split('ENDSEC;')[0]
        del raw, parts
    except BaseException:
        return []
    # быстрый выход: есть ли вообще именованные плоскости
    if not re.search(r"PLANE\s*\(\s*'[^']", sec):
        return []
    try:
        place = {}
        for m in re.finditer(r"#(\d+)\s*=\s*AXIS2_PLACEMENT_3D\s*\(\s*'[^']*'\s*,\s*#(\d+)\s*(?:,\s*#(\d+))?\s*(?:,\s*#(\d+))?\s*\)", sec):
            place[m.group(1)] = (m.group(2), m.group(3), m.group(4))
        pts = {}
        for m in re.finditer(r"#(\d+)\s*=\s*CARTESIAN_POINT\s*\(\s*'[^']*'\s*,\s*\(\s*([^)]*)\)\s*\)", sec):
            pts[m.group(1)] = m.group(2)
        dirs = {}
        for m in re.finditer(r"#(\d+)\s*=\s*DIRECTION\s*\(\s*'[^']*'\s*,\s*\(\s*([^)]*)\)\s*\)", sec):
            dirs[m.group(1)] = m.group(2)

        def nums(s, n=3):
            out = []
            for t in (s or '').replace(',', ' ').split():
                try:
                    out.append(float(t))
                except ValueError:
                    pass
            return out[:n] if len(out) >= n else None

        seen = set()
        out = []
        for m in re.finditer(r"#(\d+)\s*=\s*PLANE\s*\(\s*'((?:[^']|'')*)'\s*,\s*#(\d+)\s*\)", sec):
            name = m.group(2).replace("''", "'").strip()
            if not name:
                continue
            pl = place.get(m.group(3))
            if not pl:
                continue
            o = nums(pts.get(pl[0]))
            n = nums(dirs.get(pl[1])) if pl[1] else None
            x = nums(dirs.get(pl[2])) if pl[2] else None
            if not o or not n:
                continue
            key = (name, tuple(round(v, 3) for v in o), tuple(round(v, 3) for v in n))
            if key in seen:
                continue
            seen.add(key)
            out.append({'name': name[:60], 'o': [round(v, 4) for v in o], 'n': [round(v, 4) for v in n],
                        'x': ([round(v, 4) for v in x] if x else None)})
            if len(out) >= cap:
                break
        return out
    except BaseException:
        return []


def _step_product_map(src):
    """Лёгкий текстовый парсер AP203-структуры STEP: имя изделия и face-count'ы
    каждого solid/оболочки в порядке обхода NAUO. Возвращает (seq, sheets) или None.
    seq  = [(product_name, n_faces_solid), ...]  — по одному элементу на solid-вхождение
    sheets = [(product_name, n_faces_shell), ...] — оболочки вне solid'ов (поверхности)"""
    import re
    from collections import Counter
    try:
        size = os.path.getsize(src)
        if size > 400 * 1048576:
            return None
        raw = open(src, 'r', encoding='utf-8', errors='replace').read()
        if 'NEXT_ASSEMBLY_USAGE_OCCURRENCE' not in raw and 'PRODUCT(' not in raw:
            return None
        parts = raw.split('DATA;')
        if len(parts) < 2:
            return None
        sec = parts[1].split('ENDSEC;')[0]
        del raw, parts
        ents = {}
        for m in re.finditer(r'#(\d+)\s*=\s*([A-Z_0-9]+)\s*\(', sec):
            ents[m.group(1)] = (m.group(2), m.start())
        if len(ents) < 50:
            return None

        def args_of(num):
            ty, pos = ents[num]
            i = sec.find('(', pos)
            depth = 0
            j = i
            while j < len(sec):
                c = sec[j]
                if c == '(':
                    depth += 1
                elif c == ')':
                    depth -= 1
                    if depth == 0:
                        break
                elif c == ';' and depth == 1:
                    break
                j += 1
            return ty, sec[i + 1:j]

        def split_args(s):
            out = []
            buf = ''
            depth = 0
            inq = False
            for c in s:
                if inq:
                    buf += c
                    if c == "'":
                        inq = False
                    continue
                if c == "'":
                    inq = True
                    buf += c
                    continue
                if c in '([':
                    depth += 1
                elif c in ')]':
                    depth -= 1
                if c == ',' and depth == 0:
                    out.append(buf.strip())
                    buf = ''
                else:
                    buf += c
            if buf.strip():
                out.append(buf.strip())
            return out

        def ref(a):
            m = re.match(r'#(\d+)', a or '')
            return m.group(1) if m else None

        def reflist(a):
            return re.findall(r'#(\d+)', a or '')

        prod_name, pdf_prod, pd_of_form = {}, {}, {}
        msb_set, cs_faces, os_faces = set(), {}, {}
        abrs_items, nauos = {}, []
        pds_all, sdr_by_owner = {}, {}
        for n, (ty, pos) in ents.items():
            if ty == 'PRODUCT':
                a = split_args(args_of(n)[1])
                nm = ''
                if len(a) > 1 and a[1].startswith("'"):
                    nm = a[1].strip("'")
                elif a and a[0].startswith("'"):
                    nm = a[0].strip("'")
                if nm:
                    prod_name[n] = nm
            elif ty.startswith('PRODUCT_DEFINITION_FORMATION'):
                a = split_args(args_of(n)[1])
                p = ref(a[2]) if len(a) > 2 else None
                if p:
                    pdf_prod[n] = p
        for n, (ty, pos) in ents.items():
            if ty == 'PRODUCT_DEFINITION':
                a = split_args(args_of(n)[1])
                for x in a:
                    f = ref(x)
                    if f and f in pdf_prod:
                        pd_of_form[n] = f
                        break
            elif ty == 'MANIFOLD_SOLID_BREP':
                msb_set.add(n)
            elif ty == 'CLOSED_SHELL':
                a = split_args(args_of(n)[1])
                fl = a[1] if len(a) > 1 else ''
                cs_faces[n] = len(reflist(fl)) if fl.startswith('(') else (1 if ref(fl) else 0)
            elif ty == 'OPEN_SHELL':
                a = split_args(args_of(n)[1])
                fl = a[1] if len(a) > 1 else ''
                os_faces[n] = len(reflist(fl)) if fl.startswith('(') else (1 if ref(fl) else 0)
            elif ty == 'PRODUCT_DEFINITION_SHAPE':
                a = split_args(args_of(n)[1])
                d = ref(a[2]) if len(a) > 2 else None
                if d:
                    pds_all.setdefault(d, []).append(n)
            elif ty == 'SHAPE_DEFINITION_REPRESENTATION':
                a = split_args(args_of(n)[1])
                own, rep = ref(a[0]), ref(a[1])
                if own and rep:
                    sdr_by_owner.setdefault(own, []).append(rep)
            elif ty == 'NEXT_ASSEMBLY_USAGE_OCCURRENCE':
                a = split_args(args_of(n)[1])
                pp, cp = ref(a[3]), ref(a[4])
                if pp and cp:
                    nauos.append((pp, cp))
            elif ty == 'ADVANCED_BREP_SHAPE_REPRESENTATION':
                a = split_args(args_of(n)[1])
                abrs_items[n] = reflist(a[1]) if len(a) > 1 else []
        msb_cs = {}
        for n in msb_set:
            a = split_args(args_of(n)[1])
            msb_cs[n] = ref(a[1]) if len(a) > 1 else None

        def msb_faces_n(m):
            return cs_faces.get(msb_cs.get(m), 0)

        rep_link = {}
        for n, (ty, pos) in ents.items():
            if ty == 'SHAPE_REPRESENTATION_RELATIONSHIP':
                a = split_args(args_of(n)[1])
                r1, r2 = ref(a[2]), ref(a[3])
                if r1 and r2:
                    rep_link.setdefault(r1, set()).add(r2)
                    rep_link.setdefault(r2, set()).add(r1)

        def expand_reps(reps):
            seen = set()
            stack = list(reps)
            while stack:
                r = stack.pop()
                if r in seen:
                    continue
                seen.add(r)
                for x in rep_link.get(r, ()):
                    if x not in seen:
                        stack.append(x)
            return seen

        def rep_facecounts(rep, acc):
            a = split_args(args_of(rep)[1])
            items = reflist(a[1]) if len(a) > 1 else []
            for it in items:
                if it in msb_set:
                    acc.append(('S', msb_faces_n(it)))
                elif it in cs_faces:
                    acc.append(('S', cs_faces[it]))
                elif it in os_faces:
                    acc.append(('O', os_faces[it]))
                else:
                    t2 = ents.get(it, ('?', 0))[0]
                    if t2 in ('SHAPE_REPRESENTATION', 'ASSOCIATIVE_SHAPE_REPRESENTATION',
                              'ADVANCED_BREP_SHAPE_REPRESENTATION', 'MANIFOLD_SURFACE_SHAPE_REPRESENTATION'):
                        rep_facecounts(it, acc)
                    elif t2 == 'SHELL_BASED_SURFACE_MODEL':
                        b = split_args(args_of(it)[1])
                        for sh in (reflist(b[1]) if len(b) > 1 else []):
                            if sh in os_faces:
                                acc.append(('O', os_faces[sh]))
                            elif sh in cs_faces:
                                acc.append(('S', cs_faces[sh]))

        def pd_name(pdn):
            f = pd_of_form.get(pdn)
            return prod_name.get(pdf_prod.get(f, ''), '') if f else ''

        child = {}
        for pp, cp in nauos:
            child.setdefault(pp, []).append(cp)
        used = set(c for _, c in nauos)
        roots = [p for p in pd_of_form if p not in used]
        seq, sheets, nodes = [], [], []
        occ = [0]

        def traverse(pdn, depth, parent_nid):
            if depth > 12 or occ[0] > 6000:
                return
            occ[0] += 1
            nm = pd_name(pdn) or '?'
            nodes.append({'id': len(nodes) + 1, 'pid': parent_nid, 'name': nm})
            nid = nodes[-1]['id']
            myreps = set()
            for pds in pds_all.get(pdn, []):
                for rep in sdr_by_owner.get(pds, []):
                    myreps.add(rep)
            acc = []
            for rep in expand_reps(myreps):
                rep_facecounts(rep, acc)
            for t, fc in acc:
                if t == 'S' and fc > 0:
                    seq.append((nm, fc, nid))
                elif fc > 0:
                    sheets.append((nm, fc, nid))
            for k in child.get(pdn, []):
                traverse(k, depth + 1, nid)
        for r in roots:
            traverse(r, 0, None)
        if not seq:
            return None
        return seq, sheets, nodes
    except BaseException as e:
        _log('bodies: product map недоступна (%r)' % (e,))
        return None


def run_bodies(src, out_dir, lin, ang, rel=False):
    """XCAF-структура STEP -> папка out_dir: NNNN.stl на тело + manifest.json (для serve.js /api/bodies)."""
    import json as _json
    from OCP.STEPCAFControl import STEPCAFControl_Reader
    from OCP.TDocStd import TDocStd_Document
    from OCP.TCollection import TCollection_ExtendedString
    from OCP.XCAFDoc import XCAFDoc_DocumentTool, XCAFDoc_ColorSurf, XCAFDoc_ColorGen, XCAFDoc_ColorCurv
    from OCP.Quantity import Quantity_ColorRGBA
    from OCP.TopLoc import TopLoc_Location
    from OCP.TDataStd import TDataStd_Name
    from OCP.Bnd import Bnd_Box
    from OCP.BRepBndLib import BRepBndLib
    from OCP.BRepMesh import BRepMesh_IncrementalMesh
    from OCP.BRepAdaptor import BRepAdaptor_Surface
    from OCP.GeomAbs import GeomAbs_Cylinder
    from OCP.TopAbs import TopAbs_FACE, TopAbs_REVERSED, TopAbs_SOLID
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopoDS import TopoDS as _TD
    from OCP.gp import gp_Vec
    try:
        from OCP.TDF import TDF_LabelSequence as LSeq
    except Exception:
        from OCP.collections import Sequence_TDF_Label as LSeq

    def _snaps_of(sh, cap=300, faces=None):
        """Цилиндрические грани (угол >= ~166°; отверстия часто разрезаны на полувитки)
        -> привязки для вьюера: центр по высоте, радиус, ось, hole/pin по ориентации.
        Координаты — ровно в той системе, в какой _emit_faces кладёт меш (Triangulation loc)."""
        from OCP.BRep import BRep_Tool
        from OCP.TopLoc import TopLoc_Location
        out = []
        seen = set()
        it = iter(faces) if faces is not None else None
        n = 0
        def add_face(face):
            if len(out) >= cap:
                return
            try:
                ad = BRepAdaptor_Surface(face)
                if ad.GetType() != GeomAbs_Cylinder:
                    return
                cyl = ad.Cylinder()
                r = cyl.Radius()
                ua0, ua1 = ad.FirstUParameter(), ad.LastUParameter()
                va0, va1 = ad.FirstVParameter(), ad.LastVParameter()
                if not (0.15 < r < 5000.0 and abs(ua1 - ua0) >= 2.9 and abs(va1 - va0) >= 0.25):
                    return
                loc = TopLoc_Location()
                try:
                    tri = BRep_Tool.Triangulation_s(face, loc)
                except Exception:
                    try:
                        tri = BRep_Tool.Triangulation(face, loc)
                    except Exception:
                        tri = None
                if tri is None:
                    return
                try:
                    d = cyl.Axis().Direction()
                except Exception:
                    d = cyl.AxisDirection()
                p0 = cyl.Location().Translated(gp_Vec(d).Multiplied((va0 + va1) * 0.5))
                # ВАЖНО: BRepAdaptor в этих биндингах УЧИТЫВАЕТ Location грани сам
                # (проверено на asm: p0 попадает ровно в bb смещённого меша).
                # Дополнительный trsf из Triangation_s применять НЕ НАДО — будет двойной сдвиг.
                try:
                    rev = (face.Orientation() == TopAbs_REVERSED)
                    if not rev:
                        try:
                            rev = (int(face.Orientation()) == 1)   # TopAbs_REVERSED==1 (как в _emit_faces)
                        except Exception:
                            rev = False
                    kind = 'hole' if rev else 'pin'
                except Exception:
                    kind = 'cyl'
                # дедуп половинок одного отверстия: ключ — ось (канонический знак) + проекция центра
                dx, dy, dz = d.X(), d.Y(), d.Z()
                if dx < -1e-9 or (abs(dx) < 1e-9 and (dy < -1e-9 or (abs(dy) < 1e-9 and dz < 0))):
                    dx, dy, dz = -dx, -dy, -dz
                    px, py, pz = -p0.X(), -p0.Y(), -p0.Z()
                else:
                    px, py, pz = p0.X(), p0.Y(), p0.Z()
                # точка на оси: сдвигаем к нулю оси, чтобы половинки давали один ключ
                tpar = px*dx + py*dy + pz*dz
                qx, qy, qz = px - dx*tpar, py - dy*tpar, pz - dz*tpar
                key = (round(qx, 0), round(qy, 0), round(qz, 0), round(tpar, 0), round(r, 1), kind)
                if key in seen:
                    return
                seen.add(key)
                out.append({'x': round(p0.X(), 3), 'y': round(p0.Y(), 3), 'z': round(p0.Z(), 3),
                            'r': round(r, 3), 'h': round(abs(va1 - va0), 3),
                            'd': [round(d.X(), 5), round(d.Y(), 5), round(d.Z(), 5)], 'k': kind})
            except BaseException as e:
                if not out and not getattr(_snaps_of, '_err', None):
                    _snaps_of._err = repr(e)
        try:
            if it is None:
                exp = TopExp_Explorer(sh, TopAbs_FACE)
                while exp.More() and n < cap * 8 and len(out) < cap:
                    n += 1
                    try:
                        add_face(_TD.Face(exp.Current()))
                    except BaseException as e:
                        if n <= 3:
                            _log('snapface err %r' % (e,))
                    exp.Next()
            else:
                for face0 in it:
                    if len(out) >= cap or n >= cap * 8:
                        break
                    n += 1
                    try:
                        add_face(_TD.Face(face0))
                    except BaseException:
                        pass
        except BaseException as e:
            _log('bodies: snaps ошибка (%r)' % (e,))
        if not out:
            _log('snaps: пусто (просмотрено %r граней, последняя ошибка %r)' % (n, getattr(_snaps_of, '_err', None)))
            _snaps_of._err = None
        return out

    def _faces_of(sh, cap=100, faces=None, min_area=30.0):
        """Каталог аналитических граней тела (CAD-точные замеры во вьюере):
        P={n,d,p} плоскость | C={c,d,r,h,ang} цилиндр | K={ap,d,sa,r0,r1,ang} конус |
        S={c,r,ang} сфера. rev=1 — нормаль внутрь (отверстие). Топ cap граней по площади."""
        from OCP.GeomAbs import GeomAbs_Plane, GeomAbs_Cone, GeomAbs_Sphere
        from OCP.BRep import BRep_Tool
        from OCP.TopLoc import TopLoc_Location
        import math as _m

        def tri_area(face):
            loc = TopLoc_Location()
            try:
                tri = BRep_Tool.Triangulation_s(face, loc)
            except Exception:
                try:
                    tri = BRep_Tool.Triangulation(face, loc)
                except Exception:
                    tri = None
            if tri is None:
                return None
            try:
                a = 0.0
                for k in range(1, tri.NbTriangles() + 1):
                    t = tri.Triangle(k)
                    p1 = tri.Node(t.Value(1)); p2 = tri.Node(t.Value(2)); p3 = tri.Node(t.Value(3))
                    ux, uy, uz = p2.X() - p1.X(), p2.Y() - p1.Y(), p2.Z() - p1.Z()
                    vx, vy, vz = p3.X() - p1.X(), p3.Y() - p1.Y(), p3.Z() - p1.Z()
                    cx, cy, cz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
                    a += 0.5 * (cx * cx + cy * cy + cz * cz) ** 0.5
                return a
            except BaseException:
                return None

        def describe(face):
            try:
                ad = BRepAdaptor_Surface(face)
                gt = ad.GetType()
                rev = 0
                try:
                    rev = 1 if (face.Orientation() == TopAbs_REVERSED or int(face.Orientation()) == 1) else 0
                except BaseException:
                    pass
                ua0, ua1 = ad.FirstUParameter(), ad.LastUParameter()
                va0, va1 = ad.FirstVParameter(), ad.LastVParameter()
                if gt == GeomAbs_Plane:
                    pl = ad.Plane()
                    ax = pl.Axis().Direction()
                    lo = pl.Location()
                    dn = ax.X() * lo.X() + ax.Y() * lo.Y() + ax.Z() * lo.Z()
                    return {'t': 'P', 'n': [round(ax.X(), 6), round(ax.Y(), 6), round(ax.Z(), 6)],
                            'd': round(dn, 3), 'rev': rev}
                if gt == GeomAbs_Cylinder:
                    if abs(ua1 - ua0) < 0.5 or abs(va1 - va0) < 0.1:
                        return None
                    cyl = ad.Cylinder()
                    try:
                        d = cyl.Axis().Direction()
                    except Exception:
                        d = cyl.AxisDirection()
                    p0 = cyl.Location().Translated(gp_Vec(d).Multiplied((va0 + va1) * 0.5))
                    return {'t': 'C', 'c': [round(p0.X(), 3), round(p0.Y(), 3), round(p0.Z(), 3)],
                            'd': [round(d.X(), 5), round(d.Y(), 5), round(d.Z(), 5)],
                            'r': round(cyl.Radius(), 4), 'h': round(abs(va1 - va0), 3),
                            'ang': round(abs(ua1 - ua0), 4), 'rev': rev}
                if gt == GeomAbs_Cone:
                    co = ad.Cone()
                    ap = co.Apex()
                    try:
                        d = co.Axis().Direction()
                    except Exception:
                        d = co.AxisDirection()
                    sa = co.SemiAngle()
                    ts = 1.0 / _m.tan(sa) if abs(_m.tan(sa)) > 1e-9 else 0.0
                    t0, t1 = va0 * ts, va1 * ts
                    r0, r1 = abs(t0) * abs(_m.tan(sa)), abs(t1) * abs(_m.tan(sa))
                    return {'t': 'K', 'ap': [round(ap.X(), 3), round(ap.Y(), 3), round(ap.Z(), 3)],
                            'd': [round(d.X(), 5), round(d.Y(), 5), round(d.Z(), 5)],
                            'sa': round(sa, 5), 'r0': round(min(r0, r1), 3), 'r1': round(max(r0, r1), 3),
                            'ang': round(abs(ua1 - ua0), 4), 'rev': rev}
                if gt == GeomAbs_Sphere:
                    sp = ad.Sphere()
                    ce = sp.Location()
                    if abs(ua1 - ua0) < 0.5:
                        return None
                    return {'t': 'S', 'c': [round(ce.X(), 3), round(ce.Y(), 3), round(ce.Z(), 3)],
                            'r': round(sp.Radius(), 4), 'ang': round(abs(ua1 - ua0), 4), 'rev': rev}
                return None
            except BaseException:
                return None

        out = []
        try:
            fl = []
            if faces is None:
                n = 0
                exp = TopExp_Explorer(sh, TopAbs_FACE)
                while exp.More() and n < 8000:
                    n += 1
                    try:
                        f = _TD.Face(exp.Current())
                        if f is not None and not f.IsNull():
                            fl.append(f)
                    except BaseException:
                        pass
                    exp.Next()
            else:
                for f0 in faces:
                    try:
                        fl.append(_TD.Face(f0))
                    except BaseException:
                        pass
            scored = []
            for f in fl:
                try:
                    a = tri_area(f)
                    if a is None or a < min_area:
                        continue
                    e = describe(f)
                    if e:
                        e['a'] = round(a, 1)
                        scored.append((a, e))
                except BaseException:
                    pass
            scored.sort(key=lambda x: -x[0])
            out = [e for _, e in scored[:cap]]
        except BaseException as e:
            _log('bodies: faces ошибка (%r)' % (e,))
        return out or None

    os.makedirs(out_dir, exist_ok=True)
    doc = TDocStd_Document(TCollection_ExtendedString("XmlOcaf"))
    reader = STEPCAFControl_Reader()
    try:
        reader.SetColorMode(True)
    except Exception:
        pass
    if reader.ReadFile(src) != 1:
        raise RuntimeError('bodies: не удалось прочитать файл')
    if not reader.Transfer(doc):
        raise RuntimeError('bodies: Transfer не выполнен')
    shp_tool = XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
    col_tool = XCAFDoc_DocumentTool.ColorTool_s(doc.Main())
    _CT = (XCAFDoc_ColorSurf, XCAFDoc_ColorGen, XCAFDoc_ColorCurv)

    def face_color(face):
        try:
            key = face.Located(TopLoc_Location())
        except Exception:
            key = face
        for _t in _CT:
            try:
                c = Quantity_ColorRGBA()
                if col_tool.GetColor(key, _t, c):
                    qq = c.GetRGB()
                    return (qq.Red(), qq.Green(), qq.Blue())
            except Exception:
                continue
        return None

    def label_name(label):
        try:
            att = TDataStd_Name()
            if label.FindAttribute(TDataStd_Name.GetID_s(), att):
                es = att.Get()
                s = es.ToExtString()
                s = ''.join(ch for ch in s if ord(ch) >= 32).strip()
                if s:
                    return s[:80]
        except Exception:
            pass
        return ''

    def bbox_of(shp):
        try:
            box = Bnd_Box(); BRepBndLib.Add_s(shp, box, False)
            if box.IsVoid_s():
                return None
            mn = box.CornerMin(); mx = box.CornerMax()
            return [mn.X(), mn.Y(), mn.Z(), mx.X(), mx.Y(), mx.Z()]
        except Exception:
            try:
                box = Bnd_Box(); BRepBndLib.Add_s(shp, box)
                mn = box.CornerMin(); mx = box.CornerMax()
                return [mn.X(), mn.Y(), mn.Z(), mx.X(), mx.Y(), mx.Z()]
            except Exception:
                return None

    bodies = []
    counter = [0]
    t0 = time.time()

    # --- очередь имён изделий из AP203-структуры STEP ---
    # Считывается до огранки: если XCAF не разложил сборку на компоненты (одна
    # ссылка на общий compound), имена solid'ам выдаются из этой очереди по порядку.
    _prod_state = {'rest': []}
    try:
        _pm0 = _step_product_map(src)
        if _pm0 and _pm0[0]:
            _prod_state['rest'] = [[nm, fc, nid] for (nm, fc, nid) in _pm0[0]]
            _log('bodies: карта изделий заранее: %d solid-вхождений' % len(_prod_state['rest']))
    except BaseException as e:
        _log('bodies: ранняя карта изделий ошибка (%r)' % (e,))

    def _take_product_for(fc):
        """Следующее имя изделия по порядку следования (как в NAUO файла STEP)."""
        rest = _prod_state['rest']
        if not rest:
            return None, None
        nm, f, nid = rest.pop(0)
        return nm, nid

    def emit_body(shape, label, pid):
        """Огранить один лист-шейп (или каждый его solid) в отдельный файл."""
        solids = _body_shape(shape)
        base = label or 'Тело'
        if len(solids) > 1:
            # _body_shape даёт список TopoDS_Solid (без имён). XCAF для многих сборок
            # (Creo и т.п.) не раскладывает состав на компоненты — все solid'ы лежат
            # одним соединением с именем верхнего узла. Поэтому каждому solid'у
            # выдаём реальное имя изделия из AP203-карты STEP (по порядку следования).
            items = []
            for s in solids:
                nm, _nid = _take_product_for(_count_faces(s))
                items.append((nm or base, s))
        else:
            items = [(base, shape)]
        for si, (nm, sh) in enumerate(items):
            try:
                if sh is None or sh.IsNull():
                    continue
                try:
                    BRepMesh_IncrementalMesh(sh, lin, rel, ang, True)
                except Exception:
                    BRepMesh_IncrementalMesh(sh, lin, rel, ang)
                counter[0] += 1
                bid = counter[0]
                fname = '%04d.stl' % bid
                w = StlWriter(os.path.join(out_dir, fname))
                nf, ncol, avg, volX, cmX = _emit_faces(sh, face_color, w)
                w.footer()
                if w.total == 0:
                    try:
                        os.remove(os.path.join(out_dir, fname))
                    except OSError:
                        pass
                    continue
                full = nm if nm != base else (nm + ((' · %d' % (si + 1)) if len(items) > 1 else ''))
                ent = {'id': bid, 'pid': pid, 'name': full or ('Тело %d' % bid),
                       'file': fname, 'tris': w.total, 'bb': bbox_of(sh), 'rgb': avg,
                       '_fc': _count_faces(sh)}
                if nm != base:
                    ent['part'] = nm   # реальное имя изделия из STEP — сразу при огранке
                try:
                    sn = _snaps_of(sh)
                    if sn:
                        ent['snaps'] = sn
                except BaseException:
                    pass
                try:
                    # vol/cm приходят из самой триангуляции: если mesh фактически замкнут
                    # (в т.ч. «shell-оболочка» из CAD), объём корректен независимо от топологии
                    if volX and cmX:
                        ent['vol'] = volX
                        ent['cm'] = cmX
                except BaseException:
                    pass
                try:
                    fc = _faces_of(sh)
                    if fc:
                        ent['faces'] = fc
                except BaseException:
                    pass
                bodies.append(ent)
            except BaseException as e:
                _log('bodies: лист пропущен (%r)' % (e,))
        # 1b) geometry вне solid'ов: CAD (Creo и т.п.) часто отдаёт крупные детали
        #     (головки блока) как набор OPEN_SHELL/граней без обёртки SOLID.
        #     Единая сетка их показывает (идёт по граням), а дерево по solid'ам — теряло.
        #     Сравнение граней — C++-картой (в этом OCP у формы нет HashCode).
        if len(solids) > 1:
            try:
                from OCP.TopExp import TopExp
                from OCP.TopAbs import TopAbs_FACE
                from OCP.collections import IndexedMap_TopoDS_Shape_TopTools_ShapeMapHasher as _FaceMap
                solid_faces = _FaceMap()
                for s in solids:
                    TopExp.MapShapes_s(s, TopAbs_FACE, solid_faces)
                all_faces = _FaceMap()
                TopExp.MapShapes_s(shape, TopAbs_FACE, all_faces)
                stray = []
                for i in range(1, all_faces.Extent() + 1):
                    f = all_faces.FindKey(i)
                    if not solid_faces.Contains(f):
                        stray.append(f)
                if stray:
                    counter[0] += 1
                    bid = counter[0]
                    fname = '%04d.stl' % bid
                    w = StlWriter(os.path.join(out_dir, fname))
                    box = Bnd_Box()
                    cnum = [0., 0., 0.]
                    cden = 0
                    try:
                        try: BRepMesh_IncrementalMesh(shape, lin, rel, ang, True)
                        except Exception: BRepMesh_IncrementalMesh(shape, lin, rel, ang)
                        for f in stray:
                            try: BRepBndLib.Add_s(f, box, False)
                            except Exception: pass
                            nfX, ncolX, avgX, _vX, _cX = _emit_faces(f, face_color, w)
                            if avgX is not None and ncolX:
                                cnum = [cnum[k] + avgX[k] * ncolX for k in range(3)]
                                cden += ncolX
                    except BaseException as e:
                        _log('bodies: часть граней пропущена (%r)' % (e,))
                    w.footer()
                    if w.total > 0:
                        bb = None
                        try:
                            if not box.IsVoid_s():
                                mn = box.CornerMin(); mx = box.CornerMax()
                                bb = [mn.X(), mn.Y(), mn.Z(), mx.X(), mx.Y(), mx.Z()]
                        except Exception:
                            try:
                                if not box.IsVoid():
                                    mn = box.CornerMin(); mx = box.CornerMax()
                                    bb = [mn.X(), mn.Y(), mn.Z(), mx.X(), mx.Y(), mx.Z()]
                            except Exception:
                                bb = None
                        rgb = [cnum[k] / cden for k in range(3)] if cden else None
                        ent2 = {'id': bid, 'pid': pid,
                                'name': (base or 'Тело') + ' · поверхности (%d)' % len(stray),
                                'file': fname, 'tris': w.total, 'bb': bb, 'rgb': rgb,
                                '_fc': len(stray)}
                        try:
                            sn2 = _snaps_of(shape, cap=600, faces=stray)
                            if sn2:
                                ent2['snaps'] = sn2
                        except BaseException:
                            pass
                        try:
                            fc2 = _faces_of(None, cap=120, faces=stray, min_area=40.0)
                            if fc2:
                                ent2['faces'] = fc2
                        except BaseException:
                            pass
                        bodies.append(ent2)
                    else:
                        try: os.remove(os.path.join(out_dir, fname))
                        except OSError: pass
            except BaseException as e:
                _log('bodies: фаза поверхностных граней ошибка (%r)' % (e,))

    def walk_label(label, pid, depth):
        nm = label_name(label)
        node_id = pid
        comps = LSeq()
        try:
            shp_tool.GetComponents_s(label, comps)
        except Exception:
            try:
                shp_tool.GetComponents(label, comps)
            except Exception:
                comps = None
        if comps is not None and comps.Length() > 0 and depth < 4:
            if nm:
                counter[0] += 1
                node_id = counter[0]
                bodies.append({'id': node_id, 'pid': pid, 'name': nm, 'file': None, 'tris': 0, 'bb': None, 'rgb': None})
            for k in range(1, comps.Length() + 1):
                try:
                    walk_label(comps.Value(k), node_id, depth + 1)
                except BaseException:
                    pass
            return
        try:
            shp = shp_tool.GetShape_s(label)
        except Exception:
            shp = None
        if shp is None or shp.IsNull():
            return
        emit_body(shp, nm, pid)

    roots = LSeq()
    shp_tool.GetFreeShapes(roots)
    nr = roots.Length()
    _log('bodies: корней %d, lin=%.3f мм...' % (nr, lin))
    for ri in range(1, nr + 1):
        try:
            walk_label(roots.Value(ri), 0, 0)
        except BaseException as e:
            _log('bodies: корень %d ошибка %r' % (ri, e))
    if not any(b['file'] for b in bodies):
        raise RuntimeError('bodies: XCAF не отдал ни одного тела с геометрией')
    # --- именование тел по AP203-структуре (XCAF здесь плоский, имена — из текста STEP) ---
    try:
        pm = _step_product_map(src)
    except BaseException as e:
        _log('bodies: product map ошибка (%r)' % (e,))
        pm = None
    if pm:
        seq, sheets, nodes = pm
        buckets = {}
        for nm, fc, nid in seq:
            buckets.setdefault(fc, []).append((nm, nid))
        named = 0
        for b in bodies:
            if not b.get('file'):
                continue
            if b.get('part') is not None:
                named += 1   # имя уже выдано при огранке — не перезаписываем
                continue
            fc = b.get('_fc')
            lst = buckets.get(fc) if fc else None
            if lst:
                nm, nid = lst.pop(0)
                b['part'] = nm
                b['node'] = nid
                named += 1
        # «поверхности» (вне solid'ов): имя продукта с максимальной суммарной face-массой
        if sheets:
            tot, top_node = {}, None
            for nm, fc, nid in sheets:
                tot[nm] = tot.get(nm, 0) + fc
                if top_node is None or tot[nm] == max(tot.values()):
                    top_node = nid
            top = max(tot.items(), key=lambda x: x[1])[0]
            sheet_sum = sum(fc for _, fc, _ in sheets)
            for b in bodies:
                if b.get('file') and b.get('part') is None and b.get('_fc') and abs(b['_fc'] - sheet_sum) <= 2:
                    b['part'] = top
                    b['node'] = top_node
                    named += 1
        _log('bodies: именовано %d/%d (product map: %d solid, %d shell, %d узлов)' %
             (named, sum(1 for b in bodies if b.get('file')), len(seq), len(sheets), len(nodes)))
    man = {'src': os.path.basename(src), 'lin': lin, 'count': len(bodies), 'v': 8,
           'tris': sum(b['tris'] for b in bodies), 'bodies': bodies,
           'tree': (pm[2] if pm else None),
           'planes': _step_named_planes(src),
           'sections': _step_sections(src),
           'secs': round(time.time() - t0, 1)}
    with open(os.path.join(out_dir, 'manifest.json'), 'w', encoding='utf-8') as f:
        _json.dump(man, f, ensure_ascii=False)
    _log('bodies: %d записей, %d фасеток, %.0fs -> %s' % (len(bodies), man['tris'], man['secs'], out_dir))
    return man['tris']


def run_gmsh(src, dst, lin):
    import gmsh
    gmsh.initialize()
    try:
        gmsh.option.setNumber('General.Verbosity', 0)
        # калибровка по Schenkel-свипу: tris ~ 36/curv^1.35; min/maxe = пол/потолок поля
        curv = int(max(8, min(200, round(36.0 * (0.2 / max(lin, 1e-3)) ** 0.5))))
        maxe = max(4.0, 150.0 * lin)
        gmsh.option.setNumber('Mesh.MeshSizeFromCurvature', curv)
        gmsh.option.setNumber('Mesh.MeshSizeMax', maxe)
        gmsh.option.setNumber('Mesh.MeshSizeMin', max(0.2, 2.0 * lin))
        # обход «Identical points in triangulation» на плотных CAD-сборках
        try:
            gmsh.option.setNumber('Mesh.RandomFactor', 0.0001)
            gmsh.option.setNumber('Mesh.SmallElementCoef', 0.)
        except Exception:
            pass
        _log('gmsh: opening %s (CurvDiv=%d, MeshSizeMax=%.1f mm)...' % (src, curv, maxe))
        t0 = time.time()
        gmsh.open(src)
        _log('gmsh: opened in %.0fs, meshing (silent phase is normal)...' % (time.time() - t0))
        faces = gmsh.model.getEntities(2)
        # «Impossible to mesh periodic surface» на BAMG: пробуем алгоритмы 2D по очереди
        gen_err = None
        for alg in (1, 5, 4):
            try:
                gmsh.option.setNumber('Mesh.Algorithm', alg)
                t0 = time.time()
                gmsh.model.mesh.generate(2)
                _log('gmsh: mesh generated in %.0fs (Mesh.Algorithm=%d)' % (time.time() - t0, alg))
                gen_err = None
                break
            except Exception as e:
                gen_err = e
                _log('gmsh: algorithm %d failed (%s) — trying next' % (alg, str(e)[:120]))
                try:
                    gmsh.model.mesh.clear()
                except Exception:
                    pass
        try:
            gmsh.option.setNumber('Mesh.Algorithm', 1)
        except Exception:
            pass
        if gen_err is not None:
            raise RuntimeError('gmsh не смог огранить модель: %s' % (gen_err,))
        try:
            import numpy as np
            have_np = True
        except Exception:
            have_np = False
        # глобальная таблица координат узлов (id 1..N подряд)
        all_ids, all_xyz = gmsh.model.mesh.getNodes(-1, -1)[:2]
        if have_np:
            NPOS = np.asarray(all_xyz, dtype=np.float64).reshape(-1, 3)
            NID0 = int(all_ids[0]) if len(all_ids) else 1
        else:
            NPOS = [tuple(all_xyz[i * 3:i * 3 + 3]) for i in range(len(all_ids))]
            NID0 = int(all_ids[0]) if len(all_ids) else 1
        w = StlWriter(dst)
        t0 = time.time()
        ncol_faces = 0
        skipped_types = set()
        failed_faces = []
        for i, (dim, tag) in enumerate(faces):
            try:
                r, g, b, a = gmsh.model.getColor(dim, tag)
            except Exception:
                r = g = b = a = 0.0
            attr = _rgb565((r, g, b)) if a > 0 else 0
            if attr:
                ncol_faces += 1
            etypes, etags, enodes = gmsh.model.mesh.getElements(2, tag)
            if not etypes:
                continue
            for et, en in zip(etypes, enodes):
                et = int(et)
                nv = {2: 3, 9: 6, 8: 4}.get(et)
                if nv is None:
                    skipped_types.add(et)
                    continue
                if have_np:
                    idx = np.asarray(en, dtype=np.int64) - NID0
                    if nv == 4:
                        q = NPOS[idx].reshape(-1, 4, 3)
                        tris = np.concatenate([q[:, [0, 1, 2]], q[:, [0, 2, 3]]], axis=0)
                        w.write_np(tris.copy(), attr)
                    else:
                        verts = NPOS[idx].reshape(-1, nv, 3)[:, :3, :]
                        w.write_np(verts, attr)
                else:
                    en = [int(x) for x in en]
                    if nv == 4:
                        tris = []
                        for j in range(len(en) // 4):
                            a0, a1, a2, a3 = (NPOS[en[j * 4 + k] - NID0] for k in range(4))
                            tris += [(a0, a1, a2), (a0, a2, a3)]
                    else:
                        tris = [(NPOS[en[j * nv] - NID0], NPOS[en[j * nv + 1] - NID0], NPOS[en[j * nv + 2] - NID0])
                                for j in range(len(en) // nv)]
                    w.write_iter(tris, attr)
            if (i + 1) % 500 == 0 or i + 1 == len(faces):
                _log('gmsh: faces %d/%d (%.0fs), facets=%d' % (i + 1, len(faces), time.time() - t0, w.total))
        w.footer()
        if skipped_types:
            _log('gmsh: пропущены типы элементов %s (не треугольники)' % sorted(skipped_types))
        _log('gmsh: wrote %s (%.1f MB, %d facets, %d/%d faces colored)' % (
            dst, os.path.getsize(dst) / 1048576.0, w.total, ncol_faces, len(faces)))
        if w.total == 0:
            raise RuntimeError('gmsh вернул пустую сетку')
        return w.total
    finally:
        try:
            gmsh.finalize()
        except Exception:
            pass


# ==================== бэкенд 2: FreeCAD XCAF (цвета, GUI-режим) ====================
def _obj_color(o):
    vo = getattr(o, 'ViewObject', None)
    if vo is None:
        return None
    try:
        c = vo.ShapeColor
        if isinstance(c, (tuple, list)) and len(c) >= 3:
            return (float(c[0]), float(c[1]), float(c[2]))
        if c is not None and hasattr(c, 'r'):
            return (c.r, c.g, c.b)
    except Exception:
        pass
    try:
        sm = vo.ShapeMaterial
        for holder in (sm, getattr(sm, 'Material', None)):
            if holder is None:
                continue
            d = getattr(holder, 'Diffuse', None)
            if d is not None and hasattr(d, 'r'):
                return (d.r, d.g, d.b)
    except Exception:
        pass
    return None


def _leaf_shapes(doc):
    out = []

    def walk(o):
        grp = getattr(o, 'Group', None)
        if grp:
            for ch in grp:
                walk(ch)
            return
        shp = getattr(o, 'Shape', None)
        if shp is not None and hasattr(shp, 'Faces'):
            try:
                nf = len(shp.Faces)
            except Exception:
                nf = 0
            if nf:
                out.append((shp, _obj_color(o)))

    for o in doc.Objects:
        walk(o)
    return out


def _import_xcaf(src):
    import Import
    import FreeCAD as App
    before = set(App.listDocuments().keys())
    r = Import.insert(src)
    after = set(App.listDocuments().keys())
    new = list(after - before)
    if new:
        return App.getDocument(new[-1])
    if r is not None and hasattr(r, 'Objects'):
        return r
    if App.ActiveDocument is not None and hasattr(App.ActiveDocument, 'Objects'):
        return App.ActiveDocument
    return None


def _mesh_facets(m):
    pts = m.Points
    for f in m.Facets:
        idx = f.PointIndices
        yield pts[idx[0]], pts[idx[1]], pts[idx[2]]


def run_colored(src, dst, lin, ang, rel):
    import MeshPart
    import FreeCAD as App
    t0 = time.time()
    doc = _import_xcaf(src)
    if doc is None:
        raise RuntimeError('Import.insert не вернул документ')
    _log('fc-xcaf: import %.0fs, objects=%d' % (time.time() - t0, len(doc.Objects)))
    try:
        leaves = _leaf_shapes(doc)
        if not leaves:
            raise RuntimeError('нет лиственных форм')
        ncol = sum(1 for s, c in leaves if c is not None)
        _log('fc-xcaf: leaf shapes=%d, with color=%d' % (len(leaves), ncol))
        if ncol == 0:
            raise RuntimeError('XCAF не отдал ни одного цвета')
        w = StlWriter(dst)
        t0 = time.time()
        for i, (shp, col) in enumerate(leaves):
            m = MeshPart.meshFromShape(Shape=shp, LinearDeflection=lin, AngularDeflection=ang, Relative=rel)
            w.write_iter(_mesh_facets(m), _rgb565(col))
            del m
            if (i + 1) % 200 == 0 or i + 1 == len(leaves):
                _log('fc-xcaf: %d/%d shapes (%.0fs), facets=%d' % (i + 1, len(leaves), time.time() - t0, w.total))
        w.footer()
        _log('fc-xcaf: wrote %s (%.1f MB)' % (dst, os.path.getsize(dst) / 1048576.0))
        return w.total
    finally:
        try:
            App.closeDocument(doc.Name)
        except Exception:
            pass


# ==================== бэкенд 3: FreeCAD plain (без цветов) =======================
_KNOWN_MESH_EXT = ('.stl', '.bld', '.brd', '.urp', '.off', '.nas', '.inr', '.unst', '.wings',
                   '.geo', '.iv', '.py', '.msh', '.dat', '.node', '.ele', '.face', '.obj', '.ply', '.asc')


def _mesh_write(m, dst):
    """Mesh.write выбирает формат по расширению; служебные хвосты (.conv и т.п.) не понимают.
    Пишем во временный файл с известным расширением и переносим на dst."""
    if os.path.splitext(dst)[1].lower() in _KNOWN_MESH_EXT:
        m.write(dst)
        return
    tmp = dst + '.tmpmesh.stl'
    try:
        m.write(tmp)
        if os.path.exists(dst):
            os.remove(dst)
        os.replace(tmp, dst)
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass


def run_plain(src, dst, lin, ang, rel, tag='main'):
    import Part, MeshPart
    t0 = time.time()
    shape = Part.Shape()
    shape.read(src)
    bb = shape.BoundBox
    _log('%s: STEP read in %.0fs — solids=%d shells=%d faces=%d bb=%.0fx%.0fx%.0f mm' % (
        tag, time.time() - t0, len(shape.Solids), len(shape.Shells), len(shape.Faces),
        bb.XLength, bb.YLength, bb.ZLength))
    t0 = time.time()
    _log('%s: tessellating everything (LinearDeflection=%s mm%s)... long silent phase is normal'
         % (tag, lin, ', relative' if rel else ''))
    m = MeshPart.meshFromShape(Shape=shape, LinearDeflection=lin, AngularDeflection=ang, Relative=rel)
    _log('%s: facets=%d points=%d in %.0fs' % (tag, m.CountFacets, m.CountPoints, time.time() - t0))
    t0 = time.time()
    _mesh_write(m, dst)
    _log('%s: wrote %s (%.1f MB) in %.0fs' % (tag, dst, os.path.getsize(dst) / 1048576.0, time.time() - t0))
    return m.CountFacets


# ================================ диспетчер =====================================
def _has_gmsh():
    try:
        import gmsh
        return True
    except Exception:
        return False


def _has_ocp():
    try:
        import OCP  # cadquery-ocp: pip install cadquery-ocp
        return True
    except Exception:
        return False


def _has_freecad():
    try:
        import Part
        return True
    except Exception:
        return False


def main(src, dst=None, lin=0.2, ang=0.5, rel=False, preview_dst=None, plin=0.6, color=1, bodies_dir=None):
    src = os.path.abspath(src)
    if not os.path.isfile(src):
        raise IOError('файл не найден: ' + src)
    if bodies_dir:
        if not _has_ocp():
            raise RuntimeError('bodies: нужен python + cadquery-ocp (pip install --user cadquery-ocp)')
        os.makedirs(os.path.abspath(bodies_dir), exist_ok=True)
        n = run_bodies(src, os.path.abspath(bodies_dir), lin, ang, rel)
        return {'src': src, 'bodies': os.path.abspath(bodies_dir), 'lin': lin, 'backend': 'ocp-bodies', 'colored': True, 'facets': n}
    if not dst:
        dst = os.path.splitext(src)[0] + '.stl'
    dst = os.path.abspath(dst)
    d = os.path.dirname(dst)
    if d:
        try:
            os.makedirs(d)
        except OSError:
            pass
    res = {'src': src, 'dst': dst, 'lin': lin}
    use_color = bool(color)

    def one(out_path, l, tag):
        errs = []
        if use_color and _has_ocp():
            try:
                res.update(backend='ocp', colored=True, facets=run_ocp(src, out_path, l, ang, rel))
                return
            except BaseException as e:
                errs.append('ocp: %r' % (e,))
                try:
                    os.remove(out_path)
                except OSError:
                    pass
        if use_color and _has_gmsh():
            try:
                res.update(backend='gmsh', colored=True, facets=run_gmsh(src, out_path, l))
                return
            except BaseException as e:
                errs.append('gmsh: %r' % (e,))
                try:
                    os.remove(out_path)
                except OSError:
                    pass
        if _has_freecad():
            if use_color:
                try:
                    res.update(backend='fc-xcaf', colored=True, facets=run_colored(src, out_path, l, ang, rel))
                    return
                except BaseException as e:
                    errs.append('fc-xcaf: %r' % (e,))
                    try:
                        os.remove(out_path)
                    except OSError:
                        pass
            res.update(backend='fc-plain', colored=False, facets=run_plain(src, out_path, l, ang, rel, tag=tag))
            return
        raise RuntimeError('нет доступного бэкенда (' + ' | '.join(errs) +
                           '). Поставьте gmsh (pip install gmsh) или запустите через freecadcmd/FreeCAD.')

    one(dst, lin, 'main')
    if preview_dst:
        try:
            one(os.path.abspath(preview_dst), plin, 'preview')
            res['preview'] = preview_dst
        except BaseException as e:
            _log('preview pass failed: %r' % (e,))
    _log('done: %s' % res['dst'])
    return res


def _cli():
    src = os.environ.get('S2S_SRC')
    if not src:
        a = [x for x in sys.argv[1:] if os.path.basename(x).lower() != 'step2stl.py']
        if a:
            src = a[0]
    if not src:
        print(__doc__)
        print('ОШИБКА: не задан входной .stp/.step — перетащите файл на step2stl.bat.')
        return 2
    kw = {}
    if os.environ.get('S2S_DST'):
        kw['dst'] = os.environ['S2S_DST']
    if os.environ.get('S2S_LIN'):
        kw['lin'] = float(os.environ['S2S_LIN'])
    if os.environ.get('S2S_ANG'):
        kw['ang'] = float(os.environ['S2S_ANG'])
    kw['rel'] = os.environ.get('S2S_REL') == '1'
    kw['color'] = os.environ.get('S2S_COLOR', '1') != '0'
    if os.environ.get('S2S_BODIES'):
        kw['bodies_dir'] = os.environ['S2S_BODIES']
    if os.environ.get('S2S_DST2'):
        kw['preview_dst'] = os.environ['S2S_DST2']
        kw['plin'] = float(os.environ.get('S2S_LIN2', '0.6'))
    main(src, **kw)
    return 0


def _is_main_module():
    try:
        return __name__ == '__main__'
    except NameError:
        return False


if _is_main_module() or os.environ.get('S2S_SRC'):
    try:
        sys.exit(_cli())
    except SystemExit:
        raise
    except BaseException:
        traceback = __import__('traceback')
        traceback.print_exc()
        raise SystemExit(1)
