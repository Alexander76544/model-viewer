# -*- coding: utf-8 -*-
"""Проверка: есть ли в SOLID из STEP повторяющиеся области (surface + u/v bounds).
Также суммарная площадь триангуляции vs bbox."""
import os, sys, time
from collections import Counter
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE, TopAbs_SHELL
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS
from OCP.BRep import BRep_Tool
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.TopLoc import TopLoc_Location
try:
    from OCP.TDF import TDF_LabelSequence as LSeq
except Exception:
    from OCP.collections import Sequence_TDF_Label as LSeq

src = os.path.abspath(sys.argv[1])
doc = TDocStd_Document(TCollection_ExtendedString("XmlOcaf"))
reader = STEPCAFControl_Reader()
t0 = time.time()
assert reader.ReadFile(src) == 1
assert reader.Transfer(doc)
print('read+transfer %.0fs' % (time.time() - t0))
shp_tool = XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
roots = LSeq()
shp_tool.GetFreeShapes(roots)
shp = shp_tool.GetShape_s(roots.Value(1))

# найдём SOLID
solid = None
exp = TopExp_Explorer(shp, TopAbs_SOLID)
while exp.More():
    solid = TopoDS.Solid(exp.Current())
    exp.Next()
print('solid found: %s' % (solid is not None and not solid.IsNull()))

keys = Counter()
faces = []
surfaces = []   # живые ссылки, чтобы id() не перепутались после GC
from OCP.BRepAdaptor import BRepAdaptor_Surface
exp = TopExp_Explorer(solid, TopAbs_FACE)
t0 = time.time()
while exp.More():
    f = TopoDS.Face(exp.Current())
    faces.append(f)
    try:
        sur = BRep_Tool.Surface_s(f)
        surfaces.append(sur)
        sid = len(surfaces) - 1
    except Exception:
        sid = -1
    # u/v bounds через adaptor
    try:
        ad = BRepAdaptor_Surface(f)
        key = (sid, round(ad.FirstUParameter(), 3), round(ad.LastUParameter(), 3),
               round(ad.FirstVParameter(), 3), round(ad.LastVParameter(), 3))
    except Exception:
        key = (sid, None, None, None, None)
    keys[key] += 1
    exp.Next()
print('faces: %d in %.0fs' % (len(faces), time.time() - t0))
dup = {k: v for k, v in keys.items() if v > 1}
print('unique (surface,u,v) keys: %d | keys used >1x: %d' % (len(keys), len(dup)))
if dup:
    hv = Counter(dup.values())
    print('dup histogram (times-used: #keys): %s' % dict(sorted(hv.items())[:12]))
    faces_in_dup = sum(dup.values())
    print('faces covered by duplicated keys: %d / %d' % (faces_in_dup, len(faces)))

# триангуляция и суммарная площадь
t0 = time.time()
try:
    BRepMesh_IncrementalMesh(solid, 2.0, False, 0.5, True)
except Exception:
    BRepMesh_IncrementalMesh(solid, 2.0, False, 0.5)
print('meshed (lin=2) in %.0fs' % (time.time() - t0))
area = 0.0
tris = 0
for f in faces:
    loc = TopLoc_Location()
    try:
        tri = BRep_Tool.Triangulation_s(f, loc)
    except Exception:
        try:
            tri = BRep_Tool.Triangulation(f, loc)
        except Exception:
            tri = None
    if tri is None:
        continue
    trsf = loc.Transformation()
    for k in range(1, tri.NbTriangles() + 1):
        t = tri.Triangle(k)
        p1 = tri.Node(t.Value(1)).Transformed(trsf)
        p2 = tri.Node(t.Value(2)).Transformed(trsf)
        p3 = tri.Node(t.Value(3)).Transformed(trsf)
        ux, uy, uz = p2.X()-p1.X(), p2.Y()-p1.Y(), p2.Z()-p1.Z()
        vx, vy, vz = p3.X()-p1.X(), p3.Y()-p1.Y(), p3.Z()-p1.Z()
        cx, cy, cz = uy*vz-uz*vy, uz*vx-ux*vz, ux*vy-uy*vx
        area += 0.5 * (cx*cx + cy*cy + cz*cz) ** 0.5
        tris += 1
print('total tessellated area: %.0f mm2 (%d tris at lin=2)' % (area, tris))
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
box = Bnd_Box(); BRepBndLib.Add_s(solid, box, False)
mn, mx = box.CornerMin(), box.CornerMax()
print('bbox: %.0fx%.0fx%.0f' % (mx.X()-mn.X(), mx.Y()-mn.Y(), mx.Z()-mn.Z()))
