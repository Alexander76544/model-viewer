// Тест перелива через край: спавн капель ВНЕ устья (на поверхности, наружу),
// guide edgeOnly — ведёт за край, а не обратно в полный канал
'use strict';
const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const s1 = html.indexOf('function ftBuildTopo3');
const e1 = html.indexOf('// асинхронный расчёт топологии');
const sA = html.indexOf('function fluidLeakBurst3');
const eA = html.indexOf('function fluidFlush3');
const sB = html.indexOf('function fluidPointKind3');
const eB = html.indexOf('function fluidDeposit3cell');
if(s1<0||sA<0||sB<0) { console.log('NEEDED MARKERS NOT FOUND', s1, sA, sB); process.exit(1); }
const core = html.slice(s1, e1) + '\n' + html.slice(sA, eA) + '\n' + html.slice(sB, eB);
const VF_SURF = 1, VF_OUT = 2, FTK_SOLID = 0, FTK_CAV = 1, FTK_AIR = 2, FTK_PASS = 3;
globalThis.VF_SURF = VF_SURF; globalThis.VF_OUT = VF_OUT;
globalThis.FTK_SOLID = FTK_SOLID; globalThis.FTK_CAV = FTK_CAV;
globalThis.FTK_AIR = FTK_AIR; globalThis.FTK_PASS = FTK_PASS;
globalThis.THREE = { Vector3: class { constructor(x=0,y=0,z=0){this.x=x;this.y=y;this.z=z;} set(x,y,z){this.x=x;this.y=y;this.z=z;return this;} } };
globalThis.stlMesh3 = null; globalThis.stepBodies3 = [];
globalThis.DROPS_MAX3 = 900;
globalThis.FL_FILL_RATE3 = 2.2; globalThis.FL_DRAIN_RATE3 = 9000;
globalThis.fluidMsg3 = () => {};
let drops3 = null;
Object.defineProperty(globalThis, 'drops3', { configurable: true, get: () => drops3 });
globalThis.fluidBarrier3 = null; globalThis.fluidClipPlanes3 = null;
globalThis.fluidBodyVisible3 = ()=>true; globalThis.fluidPointClipped3 = ()=>false; globalThis.fluidPointBarrier3 = ()=>false;
(0, eval)(core);

const H = 0.5, DX = 203;
const grid = new Uint8Array(DX*DX*DX);
const inBlock = (x,y,z) => x>=0 && x<=100 && y>=0 && y<=100 && z>=0 && z<=100;
const inHoleA = (x,y,z) => x>=45 && x<=55 && y>=50 && y<=100 && z>=45 && z<=55;   // слепое, устье сверху (центр 50,50)
const inHoleB = (x,y,z) => x>=70 && x<=80 && y>=0 && y<=100 && z>=70 && z<=80;    // сквозное (центр 75,75)
for(let k=0;k<DX;k++) for(let j=0;j<DX;j++) for(let i=0;i<DX;i++){
  const x=-H+(i+0.5)*H, y=-H+(j+0.5)*H, z=-H+(k+0.5)*H;
  const idx=(k*DX+j)*DX+i;
  if(!inBlock(x,y,z)){ grid[idx]=2; continue; }
  if(inHoleA(x,y,z) || inHoleB(x,y,z)){ grid[idx]=2; continue; }
  const ds = Math.min(x,100-x,y,100-y,z,100-z);
  grid[idx] = ds < H ? 1 : 0;
}
const body = { id:-1, grid, dims:[DX,DX,DX], mins:[-H,-H,-H], h:H, box:{ containsPoint:()=>true } };
body._ftopo = ftBuildTopo3(body);
drops3 = { cache: { token:'t', bodies:[body], h:H }, list: [] };

function mkPool(regionIdx){
  const region = body._ftopo.regions[regionIdx];
  const cap = ftCapForRegion3(body, region);
  return { body, regionIdx:regionIdx, region, h:H, h3:H**3, drops:[], depositedVox:0, curVox:0, drainedVox:0,
           leakAcc:0, lastDropVox:400, pourAcc:0, inflowEMA:0, capJ:cap.capJ, capVox:cap.capVox, sealed:cap.sealed,
           openUnsealed:cap.openUnsealed, leakPts:cap.leakPts, sealT:0, vol:0, full:false, dirty:false, overflowWarned:0 };
}
let pass=0, fail=0;
const ok=(n,c)=>{ if(c){pass++;console.log('  OK   '+n);} else {fail++;console.log('  FAIL '+n);} };

const blind = body._ftopo.regions.findIndex(r=>r.minY>50);
const thru  = body._ftopo.regions.findIndex(r=>r.minY<=5);
ok('оба региона найдены', blind>=0 && thru>=0);
const rb = body._ftopo.regions[blind];
const capB = ftCapForRegion3(body, rb);
ok('слепое: крышка == верх (capVox≈total)', capB.capVox >= rb.total - 2);
ok('слепое: leakPts есть (верхнее устье)', capB.leakPts && capB.leakPts.length > 0);

// --- 1) спавн перелива из слепого: капли НА поверхности ВНЕ устья, скорость наружу
drops3.list.length = 0;
const pb = mkPool(blind);
fluidLeakBurst3(pb, 400);   // ~16 капель по 25 мм³
const drops = drops3.list.filter(d=>d.leak);
ok('слепое: капли перелива созданы', drops.length >= 8);
let allOut=0, allVel=0, allEdge=0, allAir=0, allY=0;
for(const d of drops){
  const inMouth = d.p.x>45 && d.p.x<55 && d.p.z>45 && d.p.z<55;
  if(!inMouth) allOut++;
  const outDot = (d.p.x-50)*d.v.x + (d.p.z-50)*d.v.z;
  if(outDot > 0) allVel++;
  if(d.leakEdge===1) allEdge++;
  const pk = fluidPointKind3(d.p);
  if(pk && pk.kind===FTK_AIR) allAir++;
  if(d.p.y>100 && d.p.y<101.6) allY++;
}
const n = drops.length||1;
ok('слепое: спавн вне устья (не упадёт обратно)', allOut/n > 0.9);
ok('слепое: скорость направлена НАРУЖУ от канала', allVel/n > 0.9);
ok('слепое: все капли leakEdge=1', allEdge===drops.length);
ok('слепое: спавн в воздухе над поверхностью (не в материале)', allAir/n > 0.9);
ok('слепое: высота ≈ верх детали (100..101.6)', allY/n > 0.9);

// --- 2) guide: edgeOnly ведёт ЗА КРАЙ (не к устью); обычный — к устью
if(drops.length){
  const d0 = drops[0];
  const gEdge = fluidDripGuide3(d0, 1);
  const gNorm = fluidDripGuide3(d0, 0);
  ok('guide edgeOnly: есть цель', !!gEdge);
  if(gEdge) ok('guide edgeOnly: цель у края, ДАЛЕКО от устья (>15 мм)', Math.hypot(gEdge.x-50, gEdge.z-50) > 15);
  if(gNorm) ok('guide обычный: цель у устья (<12 мм, радиус устья 5) — контраст', Math.hypot(gNorm.x-50, gNorm.z-50) < 12);
}

// --- 3) сквозное: leakPts — НИЖНЕЕ отверстие; спавн — старая логика (вниз, под модель)
drops3.list.length = 0;
const pt = mkPool(thru);
fluidLeakBurst3(pt, 400);
const tDrops = drops3.list.filter(d=>d.leak);
ok('сквозное: капли из нижнего отверстия созданы', tDrops.length >= 8);
let below=0, noEdge=0, down=0;
for(const d of tDrops){
  if(d.p.y < 0.6) below++;
  if(!d.leakEdge) noEdge++;
  if(d.v.y < 0) down++;
}
const m = tDrops.length||1;
ok('сквозное: спавн под нижней гранью (старое поведение)', below/m > 0.9);
ok('сквозное: без leakEdge', noEdge===tDrops.length);
ok('сквозное: падают вниз', down===tDrops.length);

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail?1:0);
