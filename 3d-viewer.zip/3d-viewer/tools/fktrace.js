'use strict';
const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const s1 = html.indexOf('function ftBuildTopo3');
const e1 = html.indexOf('// асинхронный расчёт топологии');
const core = html.slice(s1, e1);
const VF_SURF = 1, VF_OUT = 2, FTK_SOLID = 0, FTK_CAV = 1, FTK_AIR = 2, FTK_PASS = 3;
globalThis.VF_SURF = VF_SURF; globalThis.VF_OUT = VF_OUT;
globalThis.FTK_SOLID = FTK_SOLID; globalThis.FTK_CAV = FTK_CAV;
globalThis.FTK_AIR = FTK_AIR; globalThis.FTK_PASS = FTK_PASS;
globalThis.THREE = { Vector3: class {} }; globalThis.stlMesh3 = null; globalThis.stepBodies3 = [];
Object.defineProperty(globalThis, 'drops3', { configurable: true, get: () => null });
globalThis.fluidBarrier3 = null; globalThis.fluidClipPlanes3 = null;
globalThis.fluidBodyVisible3 = ()=>true; globalThis.fluidPointClipped3 = ()=>false; globalThis.fluidPointBarrier3 = ()=>false;
(0, eval)(core);

const H = 0.5, DX = 203;
const grid = new Uint8Array(DX*DX*DX);
const inBlock = (x,y,z) => x>=0 && x<=100 && y>=0 && y<=100 && z>=0 && z<=100;
const inHoleA = (x,y,z) => x>=45 && x<=55 && y>=50 && y<=100 && z>=45 && z<=55;
for(let k=0;k<DX;k++) for(let j=0;j<DX;j++) for(let i=0;i<DX;i++){
  const x=-H+(i+0.5)*H, y=-H+(j+0.5)*H, z=-H+(k+0.5)*H;
  const idx=(k*DX+j)*DX+i;
  if(!inBlock(x,y,z)){ grid[idx]=2; continue; }
  if(inHoleA(x,y,z)){ grid[idx]=2; continue; }
  const ds = Math.min(x,100-x,y,100-y,z,100-z);
  grid[idx] = ds < H ? 1 : 0;
}
const body = { id:-1, grid, dims:[DX,DX,DX], mins:[-H,-H,-H], h:H, box:{containsPoint:()=>true} };
body._ftopo = ftBuildTopo3(body);
const k = body._ftopo.kind;
const dx=DX, dy=DX;
// вертикальная линия через центр слепого канала (x=50, z=50 → i=101, k=101)
const i0=101, k0=101;
let lineG=[], lineK=[];
for(let j=100;j<=205;j++){
  lineG.push(grid[(k0*dy+j)*dx+i0]);
  lineK.push(k[(k0*dy+j)*dx+i0]);
}
console.log('grid line :', lineG.join(''));
console.log('kind line :', lineK.join(''));
// горизонтальная линия через середину канала (y=75 → j=151), по X
let rowG=[], rowK=[];
for(let i=95;i<=110;i++){ rowG.push(grid[(k0*dy+151)*dx+i]); rowK.push(k[(k0*dy+151)*dx+i]); }
console.log('grid row  :', rowG.join(''));
console.log('kind row  :', rowK.join(''));
// что говорит «коридор» для центральной ячейки: расстояния до стен 1
{
  const j=151;
  let last=Infinity;
  for(let i=dx-1;i>=0;i--){ if(grid[(k0*dy+j)*dx+i]===1){ last=i; break; } }
  console.log('dist +X to wall 1 from i=101:', last-101, ' BIG:', dx+dy+dz+8);
}
