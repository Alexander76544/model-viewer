// _shots27.mjs — превью ☀️: ручка солнца + луч + панель света (asm)
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const j=async u=>{const r=await fetch(u);return r.json();};
const t=await j('http://127.0.0.1:9333/json');
const pg=t.find(x=>x.type==='page'&&x.webSocketDebuggerUrl);
const ws=new WebSocket(pg.webSocketDebuggerUrl);let id=0;const pend=new Map();
ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&pend.has(m.id)){pend.get(m.id)(m);}};
const send=(m,p={})=>new Promise(r=>{const i=++id;pend.set(i,r);ws.send(JSON.stringify({id:i,method:m,params:p}));});
await new Promise(r=>{ws.onopen=r});
await send('Runtime.enable'); await send('Page.enable');
await send('Emulation.setDeviceMetricsOverride',{width:1500,height:880,deviceScaleFactor:1,mobile:false});
const ev=async x=>{const m=await send('Runtime.evaluate',{expression:x,returnByValue:true});if(m.result.exceptionDetails)throw new Error((m.result.exceptionDetails.exception?.description||'err').slice(0,250));return m.result.result.value;};
async function waitfor(expr,ms=120000){const dl=Date.now()+ms;for(;;){let v=false;try{v=await ev(expr);}catch(e){}if(v)return;if(Date.now()>dl)throw new Error('timeout '+expr);await sleep(400);}}
import fs from 'fs';
async function shot(file){const s=await send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(file,Buffer.from(s.result.data,'base64'));console.log('→',file);}

await send('Page.navigate',{url:'http://127.0.0.1:4173/?model=770_1003011-101_asm_asm.stp'});
await waitfor('stepBodies3 && stepBodies3.length>1 && threeInitialized',90000);
await waitfor('stepBodies3.filter(b=>b._mesh).length >= stepBodies3.length-1',150000);
await sleep(2500);
await ev(`(function(){
  closeAllPanels2();
  light3.ray = true; light3.sun = true;
  light3.dir = [0.85, 0.30, -0.42];
  light3.head = 0.45; light3.amb = 0.30;
  syncLightUI3(); applyLight3();
  setTimeout(()=>window.__openPanel2('apLight'), 30);
  return 1;
})()`);
await sleep(1400);
await shot('preview-light.png');
// вернём дефолт, чтобы не оставить тестовое состояние в mete
await ev(`(function(){ document.getElementById('ltResetBtn').click(); return 1; })()`);
await sleep(900);
ws.close(); process.exit(0);
