# -*- coding: utf-8 -*-
"""Лучи вдоль Y: пересечения с поверхностью; биннинг треугольников в сетку (x,z)."""
import os, sys, time
from collections import Counter, defaultdict
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS
from OCP.BRep import BRep_Tool
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.TopLoc import TopLoc_Location
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
try:
    from OCP.TDF import TDF_LabelSequence as LSeq
except Exception:
    from OCP.collections import Sequence_TDF_Label as LSeq

src = os.path.abspath(sys.argv[1])
doc = TDocStd_Document(TCollection_ExtendedString("XmlOcaf"))
reader = STEPCAFControl_Reader()
assert reader.ReadFile(src) == 1
assert reader.Transfer(doc)
shp_tool = XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
roots = LSeq()
shp_tool.GetFreeShapes(roots)
shp = shp_tool.GetShape_s(roots.Value(1))
solid = None
exp = TopExp_Explorer(shp, TopAbs_SOLID)
while exp.More():
    solid = TopoDS.Solid(exp.Current())
    exp.Next()
t0 = time.time()
try:
    BRepMesh_IncrementalMesh(solid, 2.0, False, 0.5, True)
except Exception:
    BRepMesh_IncrementalMesh(solid, 2.0, False, 0.5)
print('meshed in %.0fs' % (time.time() - t0))
box = Bnd_Box(); BRepBndLib.Add_s(solid, box, False)
mn, mx = box.CornerMin(), box.CornerMax()
print('bbox: x[%.0f,%.0f] y[%.0f,%.0f] z[%.0f,%.0f]' % (mn.X(), mx.X(), mn.Y(), mx.Y(), mn.Z(), mx.Z()))

tris = []
exp = TopExp_Explorer(solid, TopAbs_FACE)
while exp.More():
    f = TopoDS.Face(exp.Current())
    loc = TopLoc_Location()
    tri = None
    try:
        tri = BRep_Tool.Triangulation_s(f, loc)
    except Exception:
        try:
            tri = BRep_Tool.Triangulation(f, loc)
        except Exception:
            pass
    if tri is not None:
        trsf = loc.Transformation()
        for k in range(1, tri.NbTriangles() + 1):
            t = tri.Triangle(k)
            p1 = tri.Node(t.Value(1)).Transformed(trsf)
            p2 = tri.Node(t.Value(2)).Transformed(trsf)
            p3 = tri.Node(t.Value(3)).Transformed(trsf)
            tris.append((p1.X(), p1.Y(), p1.Z(), p2.X(), p2.Y(), p2.Z(), p3.X(), p3.Y(), p3.Z()))
    exp.Next()
print('tris: %d' % len(tris))

# биннинг по (x, z), шаг 10 мм
CELL = 10.0
grid = defaultdict(list)
x0g = int(mn.X() // CELL)
for i, t in enumerate(tris):
    xs = [t[0], t[3], t[6]]; zs = [t[2], t[5], t[8]]
    cx0 = int(min(xs) // CELL); cx1 = int(max(xs) // CELL)
    cz0 = int(min(zs) // CELL); cz1 = int(max(zs) // CELL)
    for cx in range(cx0, cx1 + 1):
        for cz in range(cz0, cz1 + 1):
            grid[(cx, cz)].append(i)
print('grid cells: %d' % len(grid))

def ray_crossings(x, z, y0, y1):
    c = 0
    cx = int(x // CELL); cz = int(z // CELL)
    for i in grid.get((cx, cz), ()):
        t = tris[i]
        ax, ay, az = t[0], t[1], t[2]
        bx, by, bz = t[3], t[4], t[5]
        cx2, cy2, cz2 = t[6], t[7], t[8]
        e1x, e1y, e1z = bx - ax, by - ay, bz - az
        e2x, e2y, e2z = cx2 - ax, cy2 - ay, cz2 - az
        hx, hy, hz = e2z, 0.0, -e2x
        a = -e1y * e2z
        if a > -1e-12 and a < 1e-12:
            continue
        f = 1.0 / a
        sx, sy, sz = x - ax, 0.0, z - az
        u = (sx * hy - sy * hz) * f
        if u < -1e-9 or u > 1 + 1e-9:
            continue
        q0 = e1x * sy - e1y * sx
        q1 = e1y * sz - e1z * sy
        q2 = e1z * sx - e1x * sz
        v = (hx * q1 + hy * q2 + hz * q0) * f
        if v < -1e-9 or u + v > 1 + 1e-9:
            continue
        yhit = ay + u * e1y + v * e2y
        if y0 - 1e-6 <= yhit <= y1 + 1e-6:
            c += 1
    return c

x0, x1 = mn.X() + 5, mx.X() - 5
z0, z1 = mn.Z() + 5, mx.Z() - 5
y0, y1 = mn.Y() - 1, mx.Y() + 1
step = 20.0
res = Counter()
total = 0
t0 = time.time()
xs = int((x1 - x0) / step) + 1
zs = int((z1 - z0) / step) + 1
for ix in range(xs):
    x = x0 + ix * step
    for iz in range(zs):
        z = z0 + iz * step
        res[ray_crossings(x, z, y0, y1)] += 1
        total += 1
print('rays: %d in %.0fs' % (total, time.time() - t0))
print('crossing-count histogram (count: #rays):')
for k in sorted(res):
    print('  %d : %d' % (k, res[k]))
