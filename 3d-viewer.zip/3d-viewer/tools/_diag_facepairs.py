# -*- coding: utf-8 -*-
"""Структура дубликатов: пары (face_i, face_j) с совпадающими треугольниками.
Проверяем: 1-к-1? одинаковые bbox? какая доля граней дублируется."""
import os, sys, time, math
from collections import defaultdict, Counter
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS
from OCP.BRep import BRep_Tool
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.TopLoc import TopLoc_Location
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
try:
    from OCP.TDF import TDF_LabelSequence as LSeq
except Exception:
    from OCP.collections import Sequence_TDF_Label as LSeq

src = os.path.abspath(sys.argv[1])
doc = TDocStd_Document(TCollection_ExtendedString("XmlOcaf"))
reader = STEPCAFControl_Reader()
assert reader.ReadFile(src) == 1
assert reader.Transfer(doc)
shp_tool = XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
roots = LSeq()
shp_tool.GetFreeShapes(roots)
shp = shp_tool.GetShape_s(roots.Value(1))
solid = None
exp = TopExp_Explorer(shp, TopAbs_SOLID)
while exp.More():
    solid = TopoDS.Solid(exp.Current())
    exp.Next()
t0 = time.time()
try:
    BRepMesh_IncrementalMesh(solid, 3.0, False, 0.5, True)
except Exception:
    BRepMesh_IncrementalMesh(solid, 3.0, False, 0.5)
print('meshed in %.0fs' % (time.time() - t0))

CELL = 4.0
grid = defaultdict(list)
face_info = []   # (bbox, ntri)
ntri = 0
face_i = 0
exp = TopExp_Explorer(solid, TopAbs_FACE)
while exp.More():
    f = TopoDS.Face(exp.Current())
    # bbox грани
    try:
        box = Bnd_Box(); BRepBndLib.Add_s(f, box, False)
        if box.IsVoid():
            bb = None
        else:
            mn, mx = box.CornerMin(), box.CornerMax()
            bb = (round(mn.X(),1), round(mn.Y(),1), round(mn.Z(),1), round(mx.X(),1), round(mx.Y(),1), round(mx.Z(),1))
    except Exception:
        bb = None
    loc = TopLoc_Location()
    tri = None
    try:
        tri = BRep_Tool.Triangulation_s(f, loc)
    except Exception:
        try:
            tri = BRep_Tool.Triangulation(f, loc)
        except Exception:
            pass
    nt = 0
    if tri is not None:
        trsf = loc.Transformation()
        for k in range(1, tri.NbTriangles() + 1):
            t = tri.Triangle(k)
            p1 = tri.Node(t.Value(1)).Transformed(trsf)
            p2 = tri.Node(t.Value(2)).Transformed(trsf)
            p3 = tri.Node(t.Value(3)).Transformed(trsf)
            cx = (p1.X()+p2.X()+p3.X())/3; cy = (p1.Y()+p2.Y()+p3.Y())/3; cz = (p1.Z()+p2.Z()+p3.Z())/3
            ux, uy, uz = p2.X()-p1.X(), p2.Y()-p1.Y(), p2.Z()-p1.Z()
            vx, vy, vz = p3.X()-p1.X(), p3.Y()-p1.Y(), p3.Z()-p1.Z()
            nx, ny, nz = uy*vz-uz*vy, uz*vx-ux*vz, ux*vy-uy*vx
            l = math.sqrt(nx*nx+ny*ny+nz*nz) or 1
            grid[(int(cx//CELL), int(cy//CELL), int(cz//CELL))].append((cx, cy, cz, nx/l, ny/l, nz/l, face_i))
            nt += 1
    face_info.append((bb, nt))
    face_i += 1
    exp.Next()
print('faces: %d tris: %d' % (face_i, sum(x[1] for x in face_info)))

# пары граней с совпадающими треугольниками
pair_tri = Counter()   # (fa, fb) -> число совпавших треугольников
for cell, lst in grid.items():
    if len(lst) < 2:
        continue
    for i in range(len(lst)):
        a = lst[i]
        for j in range(i+1, len(lst)):
            b = lst[j]
            if a[6] == b[6]:
                continue
            dx, dy, dz = a[0]-b[0], a[1]-b[1], a[2]-b[2]
            if dx*dx + dy*dy + dz*dz > 1.5*1.5:
                continue
            dot = a[3]*b[3] + a[4]*b[4] + a[5]*b[5]
            if abs(dot) < 0.9:
                continue
            pair_tri[(min(a[6], b[6]), max(a[6], b[6]))] += 1
print('face pairs with coincident tris: %d' % len(pair_tri))
# сколько треугольников у каждой грани vs совпавших
dup_faces = Counter()
for (fa, fb), c in pair_tri.items():
    dup_faces[fa] += c
    dup_faces[fb] += c
nf_dup = 0
# для каждой грани: доля совпавших треугольников
frac_dup = {}
for fi in range(face_i):
    nt = face_info[fi][1]
    tot = dup_faces.get(fi, 0)
    if not nt or not tot:
        continue
    frac_dup[fi] = min(1.0, tot / nt)
    if frac_dup[fi] >= 0.5:
        nf_dup += 1
print('faces with >=50%% overlapping tris: %d / %d' % (nf_dup, face_i))
# распределение долей
hist = Counter()
for fi, fr in frac_dup.items():
    hist[round(fr, 1)] += 1
print('frac histogram:', dict(sorted(hist.items())))
# пары 1-к-1 с почти равными bbox
n11 = 0
for (fa, fb), c in pair_tri.items():
    bba, nta = face_info[fa]
    bbb, ntb = face_info[fb]
    if bba and bbb:
        same = all(abs(bba[k]-bbb[k]) < 5.0 for k in range(6))
        if same and nta and ntb and 0.3 < nta/ntb < 3.3:
            n11 += 1
print('pairs with matching bbox & tri count (1:1 dup): %d / %d' % (n11, len(pair_tri)))
