# -*- coding: utf-8 -*-
"""Грани SOLID по XCAF-цветам: если оболочка состоит из 2+ совпадающих слоёв,
цвета разобьются на группы."""
import os, sys, time
from collections import Counter
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.XCAFDoc import XCAFDoc_DocumentTool, XCAFDoc_ColorSurf, XCAFDoc_ColorGen, XCAFDoc_ColorCurv
from OCP.Quantity import Quantity_ColorRGBA
from OCP.TopoDS import TopoDS
from OCP.TopLoc import TopLoc_Location
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE
from OCP.TopExp import TopExp_Explorer
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
try:
    from OCP.TDF import TDF_LabelSequence as LSeq
except Exception:
    from OCP.collections import Sequence_TDF_Label as LSeq

src = os.path.abspath(sys.argv[1])
doc = TDocStd_Document(TCollection_ExtendedString("XmlOcaf"))
reader = STEPCAFControl_Reader()
try:
    reader.SetColorMode(True)
except Exception:
    pass
assert reader.ReadFile(src) == 1
assert reader.Transfer(doc)
shp_tool = XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
col_tool = XCAFDoc_DocumentTool.ColorTool_s(doc.Main())
roots = LSeq()
shp_tool.GetFreeShapes(roots)
shp = shp_tool.GetShape_s(roots.Value(1))

_CT = (XCAFDoc_ColorSurf, XCAFDoc_ColorGen, XCAFDoc_ColorCurv)

def face_color(face):
    try:
        key = face.Located(TopLoc_Location())
    except Exception:
        key = face
    for _t in _CT:
        try:
            c = Quantity_ColorRGBA()
            if col_tool.GetColor(key, _t, c):
                qq = c.GetRGB()
                return (round(qq.Red(), 2), round(qq.Green(), 2), round(qq.Blue(), 2))
        except Exception:
            continue
    return None

solid = None
exp = TopExp_Explorer(shp, TopAbs_SOLID)
while exp.More():
    solid = TopoDS.Solid(exp.Current())
    exp.Next()

cnt = Counter()
bb_by_color = {}
exp = TopExp_Explorer(solid, TopAbs_FACE)
n = 0
while exp.More():
    f = TopoDS.Face(exp.Current())
    n += 1
    col = face_color(f)
    cnt[col] += 1
    try:
        box = Bnd_Box(); BRepBndLib.Add_s(f, box, False)
        if not box.IsVoid():
            mn, mx = box.CornerMin(), box.CornerMax()
            bb = (round(mn.X()), round(mn.Y()), round(mn.Z()), round(mx.X()), round(mx.Y()), round(mx.Z()))
        else:
            bb = None
    except Exception:
        bb = None
    lst = bb_by_color.setdefault(col, [])
    if len(lst) < 3:
        lst.append(bb)
    exp.Next()
print('solid faces: %d' % n)
print('color histogram (color: #faces):')
for col, c in cnt.most_common(20):
    print('  %s : %d   sample bbs: %s' % (col, c, bb_by_color.get(col)))
