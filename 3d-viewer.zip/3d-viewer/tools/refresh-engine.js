// tools/refresh-engine.js — обновление three.js (+ аддоны postprocessing) в 3d-viewer/index.html
//
// three@>=171 в CDN — это ESM-файлы (three.module.min.js + three.core.min.js + examples/jsm/*).
// Вьюер — офлайн одиночный файл, поэтому инструмент:
//   1) превращает ESM-пару в один классический IIFE, публикующий window.THREE;
//   2) дописывает аддоны examples/jsm (vendor/addons/*) тем же трюком и кладёт их классы в window.THREE;
//   3) заменяет движковый <script> блок в index.html (первый из блоков);
//   4) идемпотентно патчит блок приложения под r128-совместимый цвет.
//
// Запуск:            node tools/refresh-engine.js <core.js> <module.js> [--html PATH] [--no-addons] [--skip-smoke]
// Билды three (r178):
//   https://cdn.jsdelivr.net/npm/three@0.178.0/build/three.core.min.js
//   https://cdn.jsdelivr.net/npm/three@0.178.0/build/three.module.min.js
// Аддоны лежат в vendor/addons (топологический порядок ниже); при обновлении three скачать их
// с той же версии: examples/jsm/postprocessing/{Pass,ShaderPass,MaskPass,RenderPass,EffectComposer,UnrealBloomPass}.js
//                examples/jsm/shaders/{CopyShader,LuminosityHighPassShader}.js
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const argv = process.argv.slice(2);
let htmlPath = path.resolve(__dirname, '..', 'index.html');
let useAddons = true;
let skipSmoke = false;
const pos = [];
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a === '--html') { htmlPath = path.resolve(argv[++i]); continue; }
  if (a === '--no-addons') { useAddons = false; continue; }
  if (a === '--skip-smoke') { skipSmoke = true; continue; }
  pos.push(a);
}
const [corePath, modPath] = pos;
if (!corePath || !modPath) {
  console.error('использование: node tools/refresh-engine.js <three.core.min.js> <three.module.min.js> [--html PATH] [--no-addons]');
  process.exit(1);
}

// топологический порядок сборки аддонов (зависимые — после зависимости)
const ADDON_ORDER = [
  'CopyShader.js', 'LuminosityHighPassShader.js', 'Pass.js', 'ShaderPass.js',
  'MaskPass.js', 'RenderPass.js', 'EffectComposer.js', 'UnrealBloomPass.js',
];

function mapList(s) {
  return s.split(',').map(x => {
    const a = x.split(' as ');
    if (a.length === 2) return JSON.stringify(a[1].trim()) + ':' + a[0].trim();
    return JSON.stringify(x.trim()) + ':' + x.trim();
  }).join(',');
}
function mapCoreList(s) {
  return s.split(',').map(x => {
    const a = x.split(' as ');
    if (a.length === 2) return JSON.stringify(a[1].trim()) + ':__CORE[' + JSON.stringify(a[0].trim()) + ']';
    return JSON.stringify(x.trim()) + ':__CORE[' + JSON.stringify(x.trim()) + ']';
  }).join(',');
}
function destrList(s) {
  return s.split(',').map(x => {
    const a = x.trim().split(' as ');
    if (a.length === 2) return a[0].trim() + ':' + a[1].trim();
    return x.trim();
  }).join(',');
}

// ---------- 1. ядро: core+module ESM -> classic ----
const coreSrc = fs.readFileSync(path.resolve(corePath), 'utf8');
const mainSrc = fs.readFileSync(path.resolve(modPath), 'utf8');

const cIdx = coreSrc.lastIndexOf('export{');
const cMm = coreSrc.slice(cIdx).match(/^export\{([^{}]*)\};\s*$/);
if (!cMm) throw new Error('core: хвостовой export не найден — формат билда изменился');
const coreBody = coreSrc.slice(0, cIdx) + '\nreturn {' + mapList(cMm[1]) + '};\n';

const iStart = mainSrc.indexOf('import{');
const iFrom = mainSrc.indexOf('}from"', iStart);
const iSemi = mainSrc.indexOf(';', iFrom);
if (iStart < 0 || iFrom < 0 || iSemi < 0) throw new Error('module: head import не найден');
const importList = mainSrc.slice(iStart + 7, iFrom);
let rest = mainSrc.slice(iSemi + 1);

if (!rest.startsWith('export{')) throw new Error('module: re-export после import не найден');
const hEnd = rest.indexOf('}', 7);
const preList = rest.slice(7, hEnd);
if (/[{};]/.test(preList)) throw new Error('module: re-export список грязный');
rest = rest.slice(hEnd + 1);
if (rest.startsWith('from"')) {          // export{...}from"...";
  const fs2 = rest.indexOf(';', 5);
  rest = rest.slice(fs2 + 1);
}
const tIdx = rest.lastIndexOf('export{');
const tMm = rest.slice(tIdx).match(/^export\{([^{}]*)\};\s*$/);
if (!tMm) throw new Error('module: хвостовой export не найден');
const code = rest.slice(0, tIdx);

let classic = '(function(){\nvar __CORE=(function(){\n' + coreBody + '})();\n'
  + 'var {' + destrList(importList) + '} = __CORE;\n'
  + code
  + '\nwindow.THREE={' + mapCoreList(preList) + ',' + mapList(tMm[1]) + '};\n})();\n';

// ---------- 2. аддоны examples/jsm ----------
function bundleAddons(dir) {
  const built = {};
  let out = '\n// ---- three examples/jsm addons -> window.THREE ----\n(function(){\nvar __T = window.THREE; var __MOD = {};\n';
  const pubs = [];
  for (const file of ADDON_ORDER) {
    const fp = path.join(dir, file);
    if (!fs.existsSync(fp)) throw new Error('аддон не найден: ' + fp);
    let src = fs.readFileSync(fp, 'utf8');
    src = src.replace(/\/\*\*[\s\S]*?\*\//g, '');   // JSDoc-блоки: внутри псевдо-импорты @three_import
    const base = path.basename(file, '.js');
    src = src.replace(/import\s*\{([^}]*)\}\s*from\s*["']([^"']+)["']\s*;?/g, function (all, list, from) {
      if (from === 'three') return 'var {' + destrList(list) + '} = __T;';
      const dep = path.basename(from, '.js');
      if (!(dep in built)) throw new Error(base + ': зависимость ' + from + ' не собрана раньше (порядок!)');
      return 'var {' + destrList(list) + '} = __MOD["' + dep + '"];';
    });
    if (/^\s*import\b/m.test(src)) throw new Error(base + ': неподдержанная форма import осталась');
    const ex = src.match(/export\s*\{([^{};]*)\}\s*;?\s*$/);
    if (!ex) throw new Error(base + ': хвостовой export не найден');
    src = src.replace(ex[0], '');
    const ret = mapList(ex[1]);
    built[base] = true;
    pubs.push(ret);
    out += '__MOD["' + base + '"]=(function(){\n' + src + '\nreturn {' + ret + '};\n})();\n';
  }
  out += 'for(var k in __MOD){ var e=__MOD[k]; for(var n in e) window.THREE[n]=e[n]; }\n})();\n';
  return out;
}
const addonsDir = path.resolve(__dirname, '..', 'vendor', 'addons');
if (useAddons && fs.existsSync(addonsDir)) {
  classic += bundleAddons(addonsDir);
  console.log('аддоны: ' + ADDON_ORDER.length + ' модулей (EffectComposer/UnrealBloomPass/...)');
}

// ---------- 3. smoke ----------
if (!skipSmoke) {
  new vm.Script(classic);
  const sandbox = { window: {}, self: null }; sandbox.self = sandbox.window;
  vm.createContext(sandbox);
  vm.runInContext(classic, sandbox);
  const T = sandbox.window.THREE;
  if (!T || typeof T.WebGLRenderer !== 'function') throw new Error('smoke: нет WebGLRenderer');
  const need = ['Scene', 'Mesh', 'MeshStandardMaterial', 'MeshBasicMaterial', 'BufferGeometry', 'Float32BufferAttribute',
    'BufferAttribute', 'GridHelper', 'AxesHelper', 'Raycaster', 'Plane', 'CanvasTexture', 'Sprite', 'SpriteMaterial',
    'TorusGeometry', 'SphereGeometry', 'CircleGeometry', 'LineBasicMaterial', 'LineSegments', 'EdgesGeometry', 'Group',
    'ColorManagement', 'LinearSRGBColorSpace', 'SRGBColorSpace', 'MathUtils', 'Box3', 'Vector2', 'Vector3', 'Color',
    'AmbientLight', 'DirectionalLight', 'PerspectiveCamera', 'DoubleSide', 'LinearFilter',
    'PMREMGenerator', 'ACESFilmicToneMapping', 'NoToneMapping', 'ShadowMaterial',
    'EffectComposer', 'RenderPass', 'ShaderPass', 'UnrealBloomPass', 'MaskPass', 'ClearMaskPass', 'Pass', 'FullScreenQuad'];
  const miss = need.filter(k => T[k] === undefined);
  if (miss.length) throw new Error('smoke: отсутствуют ' + miss.join(', '));
  console.log(`smoke: ok | r${T.REVISION} | экспортов THREE: ${Object.keys(T).length}`);
}
const revM = /\bconst t="(\d+)"/.exec(coreSrc);
const rev = revM ? revM[1] : 'x';
console.log(`движок: r${rev} | классика ${classic.length} B`);

// ---------- 4. инъекция ----------
let html = fs.readFileSync(htmlPath, 'utf8');
const o1 = html.indexOf('<script');
const c1 = html.indexOf('</script>', o1);
const o2 = html.indexOf('<script', c1);
if (o1 < 0 || c1 < 0 || o2 < 0) throw new Error('не найдены script-блоки');
const head = html.slice(0, o1);
const tail = html.slice(o2);
const newEngine = '<script>\n/* three.js r' + rev + ' (+ аддоны postprocessing) — классическая обёртка ESM-билда, см. tools/refresh-engine.js; встроен для офлайн-режима */\n'
  + classic + '\n</script>';

let app = tail;
const CM_MARK = '/*engine-compat*/';
if (!app.includes(CM_MARK)) {
  app = app.replace('"use strict";',
    '"use strict";\n' + CM_MARK + 'if(THREE.ColorManagement) THREE.ColorManagement.enabled = false; // цвета как в r128: без конвертаций');
}
const OS_MARK = 'renderer3.outputColorSpace';
if (app.includes('renderer3 = new THREE.WebGLRenderer({antialias:true});') && !app.includes(OS_MARK)) {
  app = app.replace('renderer3 = new THREE.WebGLRenderer({antialias:true});',
    'renderer3 = new THREE.WebGLRenderer({antialias:true});\n  ' + OS_MARK + ' = THREE.LinearSRGBColorSpace; // без sRGB-энкодинга — палитра RGB555 выводится 1:1');
}

const outHtml = head + newEngine + '\n\n' + app;
fs.writeFileSync(htmlPath, outHtml);
console.log(`index.html: ${html.length} -> ${outHtml.length} B`);
