// _lum8.mjs — A/B: насколько headlight подсвечивает нутро модели на срезе (волна 8).
// Запуск: node tools/_lum8.mjs   (serve.js :4173 + headless Edge :9333 должны быть подняты)
const j=async u=>{const r=await fetch(u);return r.json();};
const t=await j('http://127.0.0.1:9333/json');
const pg=t.find(x=>x.type==='page'&&x.webSocketDebuggerUrl);
const ws=new WebSocket(pg.webSocketDebuggerUrl);let id=0;const pend=new Map();
ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&pend.has(m.id)){pend.get(m.id)(m);pend.delete(m.id);}};
const send=(m,p={})=>new Promise(r=>{const i=++id;pend.set(i,r);ws.send(JSON.stringify({id:i,method:m,params:p}));});
await new Promise(r=>{ws.onopen=r});
await send('Runtime.enable'); await send('Page.enable');
await send('Emulation.setDeviceMetricsOverride',{width:1400,height:820,deviceScaleFactor:1,mobile:false});
const ev=async x=>{const m=await send('Runtime.evaluate',{expression:x,returnByValue:true,awaitPromise:true});if(m.result.exceptionDetails)throw new Error((m.result.exceptionDetails.exception?.description||'err').slice(0,300));return m.result.result.value;};
async function waitfor(expr,ms=180000){const dl=Date.now()+ms;for(;;){let v=false;try{v=await ev(expr);}catch(e){}if(v)return;if(Date.now()>dl)throw new Error('timeout');await new Promise(r=>setTimeout(r,500));}}
await send('Page.navigate',{url:'http://127.0.0.1:4173/?model=770_1003014-10.stp'});
await waitfor('!!(stlMesh3 && stepBodies3 && stepBodies3.length)');
await new Promise(r=>setTimeout(r,2000));
await ev(`(function(){
  clipState3.enabled=true; clipState3.mode='slab'; clipState3.axis='x'; clipState3.pos=0.35; clipState3.pos2=0.55;
  applyStlClipping();
  light3.head=0; light3.amb=0; light3.sun=false; applyLight3(true);
  return 1;
})()`);
await new Promise(r=>setTimeout(r,900));
async function countLit(){
  const s=await send('Page.captureScreenshot',{format:'png'});
  await ev(`window.__b64=${JSON.stringify(s.result.data)};1`);
  return await ev(`(async()=>{
    const img=new Image(); img.src='data:image/png;base64,'+window.__b64;
    await new Promise((res,rej)=>{img.onload=res;img.onerror=rej;});
    const c=document.createElement('canvas'); c.width=img.width;c.height=img.height;
    const x=c.getContext('2d'); x.drawImage(img,0,0);
    const x0=Math.floor(c.width*0.2), x1=Math.floor(c.width*0.8), y0=Math.floor(c.height*0.15), y1=Math.floor(c.height*0.85); const d=x.getImageData(x0,y0,x1-x0,y1-y0).data; let lit=0;
    for(let i=0;i<d.length;i+=4){ if((d[i]+d[i+1]+d[i+2])/3>28) lit++; }
    return lit;
  })()`);
}
const a=await countLit();
await ev(`(function(){ light3.head=0.6; applyLight3(true); return 1; })()`);
await new Promise(r=>setTimeout(r,900));
const b=await countLit();
console.log(`LIGHT A/B (срез, head 0 -> 60): различимых пикселей ${a} -> ${b}  (+${Math.round(100*(b-a)/Math.max(1,a))}%)`);
ws.close(); process.exit(0);



