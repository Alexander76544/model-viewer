// CDP-скриншоты оболочки v3: общий вид, панель+окраска+меню, компактный режим
const PORT=9333, DIR='C:\\Workspace\\3d-viewer';
const URL_='http://127.0.0.1:4173/?model=770_1003011-101_asm_asm.stp';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function j(u){const r=await fetch(u);return r.json();}
function connect(wsUrl){const ws=new WebSocket(wsUrl);let id=0;const pend=new Map();ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&pend.has(m.id)){pend.get(m.id)(m);pend.delete(m.id);}};const send=(method,params={})=>new Promise(res=>{const i=++id;pend.set(i,res);ws.send(JSON.stringify({id:i,method,params}));});return{ws,send};}
async function ev(send,expr){const m=await send('Runtime.evaluate',{expression:expr,returnByValue:true,awaitPromise:true});if(m.result&&m.result.exceptionDetails)throw new Error('EXC '+JSON.stringify(m.result.exceptionDetails));return m.result&&m.result.result?m.result.result.value:undefined;}
async function shot(send,out){const s=await send('Page.captureScreenshot',{format:'png'});await import('node:fs').then(fs=>fs.writeFileSync(DIR+'\\'+out, Buffer.from(s.result.data,'base64')));console.log('SAVED',out);}
(async()=>{
  let t;for(let k=0;k<40;k++){try{t=await j('http://127.0.0.1:'+PORT+'/json');if(t.some(x=>x.type==='page'))break;}catch(e){}await sleep(500);}
  const pg=t.find(x=>x.type==='page'&&x.webSocketDebuggerUrl);const{ws,send}=connect(pg.webSocketDebuggerUrl);await new Promise(r=>{ws.onopen=r;});
  await send('Runtime.enable'); await send('Page.enable');
  await send('Emulation.setDeviceMetricsOverride',{width:1600,height:900,deviceScaleFactor:1,mobile:false});
  await send('Page.navigate',{url:URL_});
  for(let k=0;k<240;k++){const n=await ev(send,'(typeof stepBodies3!=="undefined" && lastStepRel3==="770_1003011-101_asm_asm.stp" && stepBodies3.filter(b=>b._mesh).length)||0');if(n>=100)break;await sleep(500);}
  await sleep(1500);
  await shot(send,'preview-shell.png');   // 1: дерево + рейка, чистый вид
  // 2: окраска нескольких групп + панель «Вид и цвета» + меню на канвасе
  await ev(send,`(()=>{
    const rows = stepTreeRows3.filter(r=>r.kind!=='node' && r.ids.length>=1);
    const g18 = rows.find(r=>r.ids.length>=10);
    applyRecolor3(g18.ids, {h:'#e11d48', o:1});
    const others = rows.filter(r=>r!==g18);
    applyRecolor3([others[2]?.ids[0], others[7]?.ids[0], others[15]?.ids[0]].filter(x=>x!=null), {h:'#3b82f6', o:1});
    const big = stepBodies3.filter(b=>b._mesh && b.tris>40000)[0];
    if(big) applyRecolor3([big.id], {h:null, o:0.32});
    __openPanel2('apAppearance');
    openBodyMenu3At(1010, 300, g18.ids, g18.name);
    return 1;
  })()`);
  await sleep(900);
  await shot(send,'preview-recolor.png');
  // 3: компактный режим (панели закрыты, всё скрыто пока мышь не наведена)
  await ev(send,`(()=>{ closeAllPanels2(); closeBodyMenu3(); document.body.classList.add('compact2'); document.getElementById('stepTreePanel').style.display='none'; syncRail2(); return 1; })()`);
  await sleep(800);
  await shot(send,'preview-compact.png');
  ws.close();process.exit(0);
})().catch(e=>{console.error('FAIL',e.message);process.exit(1);});
