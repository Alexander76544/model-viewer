// tools/verify-index.js — структурная проверка index.html (после правок движка/дизайна)
// запуск: node tools/verify-index.js [путь/к/index.html]
'use strict';
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const P = path.resolve(process.argv[2] || path.join(__dirname, '..', 'index.html'));
const html = fs.readFileSync(P, 'utf8');

const blocks = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
console.log('script blocks:', blocks.length, blocks.length === 2 ? '(engine + app — ок)' : '(ОЖИДАЛОСЬ 2!)');
if (blocks.length !== 2) process.exit(1);
new vm.Script(blocks[0]);
console.log('engine block: parse OK,', blocks[0].length, 'B');
const app = blocks[1];
new vm.Script(app);
console.log('app block: parse OK,', app.length, 'B');
console.log('ColorManagement compat:', app.includes('THREE.ColorManagement.enabled = false'));
console.log('outputColorSpace compat:', app.includes('renderer3.outputColorSpace = THREE.LinearSRGBColorSpace'));
const m = /three\.js r(\d+)/.exec(html);
console.log('engine marker:', m ? 'r' + m[1] : 'NOT FOUND');

const ids = new Set([...html.matchAll(/id="([^"]+)"/g)].map(x => x[1]));
const refs = [...html.matchAll(/getElementById\(\s*['"]([^'"]+)['"]\s*\)/g)].map(x => x[1]);
const missing = [...new Set(refs)].filter(r => !ids.has(r));
console.log('id refs:', new Set(refs).size, '| missing:', missing.length ? missing : 'none');

// CSS-аудит: каждый класс из разметки/JS-строк объявлен в <style>
const s0 = html.indexOf('<style>'), s1 = html.indexOf('</style>', s0);
const css = html.slice(s0, s1);
const cls = new Set();
for (const x of html.matchAll(/class="([^"]+)"/g)) x[1].split(/\s+/).forEach(c => c && cls.add(c));
const noCss = [...cls].filter(c => !css.includes('.' + c));
console.log('classes in markup:', cls.size, '| без объявления в CSS:', noCss.length ? noCss : 'none');
const tokens = ['bg','panel','panel2','border','border2','text','muted','muted2','cyan','cyan-dim','amber','red'];
const noTok = tokens.filter(t => !css.includes('--' + t + ':'));
console.log('tokens:', noTok.length ? 'MISSING ' + noTok : 'all present');
console.log(noCss.length || missing.length || noTok.length ? 'RESULT: PROBLEMS' : 'RESULT: CLEAN');
