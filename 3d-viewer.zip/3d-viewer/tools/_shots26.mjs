// _shots26.mjs — превью: ⚖️ массы+ЦТ (asm) и ⌚ CAD-замер граней (small)
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const j=async u=>{const r=await fetch(u);return r.json();};
const t=await j('http://127.0.0.1:9333/json');
const pg=t.find(x=>x.type==='page'&&x.webSocketDebuggerUrl);
const ws=new WebSocket(pg.webSocketDebuggerUrl);let id=0;const pend=new Map();
ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&pend.has(m.id)){pend.get(m.id)(m);pend.delete(m.id);}};
const send=(m,p={})=>new Promise(r=>{const i=++id;pend.set(i,r);ws.send(JSON.stringify({id:i,method:m,params:p}));});
await new Promise(r=>{ws.onopen=r});
await send('Runtime.enable'); await send('Page.enable');
await send('Emulation.setDeviceMetricsOverride',{width:1500,height:880,deviceScaleFactor:1,mobile:false});
const ev=async x=>{const m=await send('Runtime.evaluate',{expression:x,returnByValue:true});if(m.result.exceptionDetails)throw new Error((m.result.exceptionDetails.exception?.description||'err').slice(0,250));return m.result.result.value;};
async function waitfor(expr,ms=60000){const dl=Date.now()+ms;for(;;){let v=false;try{v=await ev(expr);}catch(e){}if(v)return;if(Date.now()>dl)throw new Error('timeout '+expr);await sleep(400);}}
import fs from 'fs';
async function shot(file){const s=await send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(file,Buffer.from(s.result.data,'base64'));console.log('→',file);}

// ============ 1) МАССЫ — asm ============
await send('Page.navigate',{url:'http://127.0.0.1:4173/?model=770_1003011-101_asm_asm.stp'});
await waitfor('stepBodies3 && stepBodies3.length>1 && threeInitialized',90000);
await waitfor('stepBodies3.filter(b=>b._mesh).length >= stepBodies3.length-1',150000);
await sleep(2500);
await ev(`(function(){
  closeAllPanels2();
  renderMassList3();
  const cb=document.getElementById('massCgCb'); cb.checked=true; updateMassCg3();
  setTimeout(()=>window.__openPanel2('apMass'), 30);
  return 1;
})()`);
await sleep(1400);
await shot('preview-mass.png');
// изоляция пары самых тяжёлых не нужна — оставим общий вид

// ============ 2) ГРАНЬ — small ============
await send('Page.navigate',{url:'http://127.0.0.1:4173/?model=770_1003014-10.stp'});
await waitfor('stepBodies3 && stepBodies3.length>0 && threeInitialized',90000);
await waitfor('stepBodies3.filter(b=>b._mesh).length >= stepBodies3.length-1',150000);
await sleep(2500);
const face = await ev(`(function(){
  closeAllPanels2(); resetMeasureState3();
  setFaceMode3(true);
  const rect=renderer3.domElement.getBoundingClientRect();
  const b = stepBodies3.find(x=>x._mesh && (faceCatalog3[x.id]||[]).length);
  const ctr=(v=>{const p=v.clone().project(camera3);return [rect.left+(p.x*.5+.5)*rect.width, rect.top+(-p.y*.5+.5)*rect.height];})(new THREE.Box3().setFromObject(b._mesh).getCenter(new THREE.Vector3()));
  // клики: цилиндр (отверстие крупное) + плоскость — чтобы в списке были ⌀ и пара
  let c1=null,f1=null,c2=null,f2=null;
  for(let dx=-160; dx<=160 && !(c1&&c2); dx+=6){ for(let dy=-120; dy<=120 && !(c1&&c2); dy+=6){
    const rr=measurePick3(ctr[0]+dx,ctr[1]+dy); if(!rr||rr.bid!==b.id) continue;
    const ff=matchFace3(rr.bid,rr.point); if(!ff) continue;
    if(!c1 && ff.t==='C'){ c1=[ctr[0]+dx,ctr[1]+dy]; f1=ff; }
    else if(!c2 && ff.t==='P' && ff!==f2){ c2=[ctr[0]+dx,ctr[1]+dy]; f2=ff; }
  } }
  if(!c1) return {ok:false};
  faceClick3(c1[0],c1[1]);
  if(c2) faceClick3(c2[0],c2[1]);
  window.__openPanel2('apMeasure');
  return { ok:true, n:probes3.length, txts: probes3.map(p=>p.txt.slice(0,44)) };
})()`);
console.log('FACE-SHOT', JSON.stringify(face));
await sleep(1400);
await shot('preview-face.png');
ws.close(); process.exit(0);
