# -*- coding: utf-8 -*-
"""Ищем совпадающие треугольники (центр < 1.5 мм, нормали близки) из разных граней SOLID.
Такие пары = дублирующиеся слои поверхности (z-fighting в вьювере)."""
import os, sys, time, math
from collections import defaultdict
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS
from OCP.BRep import BRep_Tool
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.TopLoc import TopLoc_Location
try:
    from OCP.TDF import TDF_LabelSequence as LSeq
except Exception:
    from OCP.collections import Sequence_TDF_Label as LSeq

src = os.path.abspath(sys.argv[1])
doc = TDocStd_Document(TCollection_ExtendedString("XmlOcaf"))
reader = STEPCAFControl_Reader()
assert reader.ReadFile(src) == 1
assert reader.Transfer(doc)
shp_tool = XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
roots = LSeq()
shp_tool.GetFreeShapes(roots)
shp = shp_tool.GetShape_s(roots.Value(1))
solid = None
exp = TopExp_Explorer(shp, TopAbs_SOLID)
while exp.More():
    solid = TopoDS.Solid(exp.Current())
    exp.Next()
t0 = time.time()
try:
    BRepMesh_IncrementalMesh(solid, 3.0, False, 0.5, True)
except Exception:
    BRepMesh_IncrementalMesh(solid, 3.0, False, 0.5)
print('meshed in %.0fs' % (time.time() - t0))

# (cellx, cellz, celly) -> list (tri center, normal, face_idx)
CELL = 4.0
grid = defaultdict(list)
face_i = 0
ntri = 0
exp = TopExp_Explorer(solid, TopAbs_FACE)
while exp.More():
    f = TopoDS.Face(exp.Current())
    loc = TopLoc_Location()
    tri = None
    try:
        tri = BRep_Tool.Triangulation_s(f, loc)
    except Exception:
        try:
            tri = BRep_Tool.Triangulation(f, loc)
        except Exception:
            pass
    if tri is not None:
        trsf = loc.Transformation()
        for k in range(1, tri.NbTriangles() + 1):
            t = tri.Triangle(k)
            p1 = tri.Node(t.Value(1)).Transformed(trsf)
            p2 = tri.Node(t.Value(2)).Transformed(trsf)
            p3 = tri.Node(t.Value(3)).Transformed(trsf)
            cx = (p1.X() + p2.X() + p3.X()) / 3
            cy = (p1.Y() + p2.Y() + p3.Y()) / 3
            cz = (p1.Z() + p2.Z() + p3.Z()) / 3
            ux, uy, uz = p2.X()-p1.X(), p2.Y()-p1.Y(), p2.Z()-p1.Z()
            vx, vy, vz = p3.X()-p1.X(), p3.Y()-p1.Y(), p3.Z()-p1.Z()
            nx, ny, nz = uy*vz-uz*vy, uz*vx-ux*vz, ux*vy-uy*vx
            l = math.sqrt(nx*nx+ny*ny+nz*nz) or 1
            nx, ny, nz = nx/l, ny/l, nz/l
            # ориентируем нормаль вверх по y для сравнения
            if ny < 0:
                nx, ny, nz = -nx, -ny, -nz
            grid[(int(cx//CELL), int(cy//CELL), int(cz//CELL))].append((cx, cy, cz, nx, ny, nz, face_i))
            ntri += 1
    face_i += 1
    exp.Next()
print('tris: %d faces: %d' % (ntri, face_i))

coinc = 0
checked_cells = 0
examples = []
for cell, lst in grid.items():
    if len(lst) < 2:
        continue
    checked_cells += 1
    for i in range(len(lst)):
        for j in range(i + 1, len(lst)):
            a, b = lst[i], lst[j]
            if a[6] == b[6]:
                continue  # одна грань
            dx, dy, dz = a[0]-b[0], a[1]-b[1], a[2]-b[2]
            if dx*dx + dy*dy + dz*dz > 1.5*1.5:
                continue
            dn = (a[3]-b[3])**2 + (a[4]-b[4])**2 + (a[5]-b[5])**2
            if dn < 0.1:
                coinc += 1
                if len(examples) < 8:
                    examples.append((round(a[0]), round(a[1]), round(a[2]), a[6], b[6]))
print('cells with >=2 tris: %d' % checked_cells)
print('coincident triangle pairs (diff faces): %d' % coinc)
for e in examples:
    print('  at (%d,%d,%d): face %d vs face %d' % e)
