// Юнит-тесты топологии жидкости (ftBuildTopo3 / ftMakeRegion3 / ftCapForRegion3)
// Запуск: node tools\ftopo_test.js
const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const s = html.indexOf('function ftBuildTopo3');
const e = html.indexOf('// асинхронный расчёт топологии');
if (s < 0 || e < 0 || e <= s) { console.error('extract failed', s, e); process.exit(1); }
const core = html.slice(s, e);

const VF_SURF = 1, VF_OUT = 2, FTK_SOLID = 0, FTK_CAV = 1, FTK_AIR = 2, FTK_PASS = 3;
globalThis.VF_SURF = VF_SURF; globalThis.VF_OUT = VF_OUT;
globalThis.FTK_SOLID = FTK_SOLID; globalThis.FTK_CAV = FTK_CAV;
globalThis.FTK_AIR = FTK_AIR; globalThis.FTK_PASS = FTK_PASS;
class V3 { constructor(x = 0, y = 0, z = 0) { this.x = x; this.y = y; this.z = z; } set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; } }
global.THREE = { Vector3: V3 };
global.stlMesh3 = null; global.stepBodies3 = [];
let drops3 = null;

// eval с прокидыванием зависимостей
new Function('deps', core + '\nreturn { ftBuildTopo3, ftMakeRegion3, ftCapForRegion3 };')
({ VF_SURF, VF_OUT, FTK_SOLID, FTK_CAV, FTK_AIR, FTK_PASS, drops3: null, get drops3_() { return drops3; } });

// проще: объявляем функции через eval в этой области
globalThis.fluidBarrier3 = null; globalThis.fluidClipPlanes3 = null;
globalThis.fluidBodyVisible3 = ()=>true; globalThis.fluidPointClipped3 = ()=>false; globalThis.fluidPointBarrier3 = ()=>false;
(0, eval)(core);
function getDrops3() { return drops3; }
// ftCapForRegion3 ссылается на глобальное имя drops3 — подменяем через globalThis
Object.defineProperty(globalThis, 'drops3', { configurable: true, get: () => drops3 });

function makeBody(id, dims, fillFn) {
  const [dx, dy, dz] = dims;
  const grid = new Uint8Array(dx * dy * dz);
  for (let k = 0; k < dz; k++) for (let j = 0; j < dy; j++) for (let i = 0; i < dx; i++) grid[(k * dy + j) * dx + i] = fillFn(i, j, k);
  return { id, grid, dims, mins: [0, 0, 0], h: 1,
    box: { min: { x: 0, y: 0, z: 0 }, max: { x: dx, y: dy, z: dz },
      containsPoint(v) { return v.x >= 0 && v.x <= dx && v.y >= 0 && v.y <= dy && v.z >= 0 && v.z <= dz; } } };
}
const block = (i, j, k) => i >= 1 && i <= 10 && j >= 1 && j <= 10 && k >= 1 && k <= 10;
const blockWall = (i, j, k) => i === 1 || i === 10 || j === 1 || j === 10 || k === 1 || k === 10;
let pass = 0, fail = 0;
function ok(name, cond) { if (cond) { pass++; console.log('  OK   ' + name); } else { fail++; console.log('  FAIL ' + name); } }
function kindCounts(t) { const c = [0, 0, 0, 0]; for (const x of t.kind) c[x]++; return c; }

// === A: сплошной блок — без регионов, 0 = материал ===
{
  const A = makeBody(1, [12, 12, 12], (i, j, k) => !block(i, j, k) ? 2 : (blockWall(i, j, k) ? 1 : 0));
  const t = ftBuildTopo3(A);
  const c = kindCounts(t);
  ok('A: нет CAV (глубокий материал распознан)', c[1] === 0);
  ok('A: нет PASS (наружный воздух = AIR)', c[3] === 0);
  ok('A: нет регионов', t.regions.length === 0);
  ok('A: внутренняя 0-ячейка = SOLID', t.kind[(5 * 12 + 5) * 12 + 5] === FTK_SOLID);
}
// === B: слепое вертикальное отверстие (низ закрыт, верх открыт) ===
{
  const hole = (i, j, k) => i >= 5 && i <= 6 && k >= 5 && k <= 6 && j >= 4 && j <= 10;
  const A = makeBody(1, [12, 12, 12], (i, j, k) => hole(i, j, k) ? 2 : (!block(i, j, k) ? 2 : (blockWall(i, j, k) ? 1 : 0)));
  const t = ftBuildTopo3(A);
  ok('B: один регион (трубка)', t.regions.length === 1);
  const r = t.regions[0];
  ok('B: регион = 28 ячеек (2x2x7)', r.total === 28);
  ok('B: ячейка трубки = PASS', t.kind[(5 * 12 + 4) * 12 + 5] === FTK_PASS);
  ok('B: отверстия есть', r.open.length > 0);
  drops3 = { cache: { token: 't1', bodies: [A] } };
  const cap = ftCapForRegion3(A, r);
  ok('B: не закрыто заглушкой', cap.sealed === false);
  ok('B: крышка = верхний торец (j=10)', cap.capJ === 10);
  ok('B: держит до края = все 28', cap.capVox === 28);
  ok('B: leakPts — верхние ячейки', cap.leakPts.length > 0 && cap.leakPts.every(oi => (Math.floor(oi / 12) % 12) === 10));
  drops3 = null;
}
// === C: сквозное отверстие (низ открыт) — слив ===
{
  const hole = (i, j, k) => i >= 5 && i <= 6 && k >= 5 && k <= 6 && j >= 1 && j <= 10;
  const A = makeBody(1, [12, 12, 12], (i, j, k) => hole(i, j, k) ? 2 : (!block(i, j, k) ? 2 : (blockWall(i, j, k) ? 1 : 0)));
  const t = ftBuildTopo3(A);
  const r = t.regions[0];
  ok('C: регион = 40 ячеек (2x2x10)', r.total === 40);
  drops3 = { cache: { token: 't2', bodies: [A] } };
  const cap = ftCapForRegion3(A, r);
  ok('C: крышка = нижний торец (j=1)', cap.capJ === 1);
  ok('C: держит только нижний слой (4)', cap.capVox === 4);
  ok('C: leakPts — нижние ячейки', cap.leakPts.every(oi => (Math.floor(oi / 12) % 12) === 1));
  drops3 = null;
}
// === D: сквозное отверстие + заглушка снизу (другое тело) ===
{
  const hole = (i, j, k) => i >= 5 && i <= 6 && k >= 5 && k <= 6 && j >= 1 && j <= 10;
  const A = makeBody(1, [12, 12, 12], (i, j, k) => hole(i, j, k) ? 2 : (!block(i, j, k) ? 2 : (blockWall(i, j, k) ? 1 : 0)));
  const inB = (i, j, k) => i >= 4 && i <= 7 && j >= 0 && j <= 2 && k >= 4 && k <= 7;
  const wallB = (i, j, k) => i === 4 || i === 7 || j === 0 || j === 2 || k === 4 || k === 7;
  const B = makeBody(2, [12, 12, 12], (i, j, k) => inB(i, j, k) ? (wallB(i, j, k) ? 1 : 0) : 2);
  const t = ftBuildTopo3(A);
  const r = t.regions[0];
  drops3 = { cache: { token: 't3', bodies: [A, B] } };
  const cap = ftCapForRegion3(A, r);
  ok('D: низ закрыт заглушкой → крышка сверху (j=10)', cap.capJ === 10);
  ok('D: держит все 40 (до верхнего края)', cap.capVox === 40);
  drops3 = null;
}
// === E: замкнутая полость внутри блока ===
{
  const cav = (i, j, k) => i >= 5 && i <= 6 && j >= 4 && j <= 5 && k >= 5 && k <= 6;
  const cavWall = (i, j, k) =>
    i >= 4 && i <= 7 && j >= 3 && j <= 6 && k >= 4 && k <= 7 &&
    (i === 4 || i === 7 || j === 3 || j === 6 || k === 4 || k === 7);
  const A = makeBody(1, [12, 12, 12], (i, j, k) => {
    if (cav(i, j, k)) return 0;
    if (cavWall(i, j, k)) return 1;
    return !block(i, j, k) ? 2 : (blockWall(i, j, k) ? 1 : 0);
  });
  const t = ftBuildTopo3(A);
  ok('E: CAV-ячейки есть (полость распознана)', kindCounts(t)[1] > 0);
  const r = t.regions.find(x => x.total === 8);
  ok('E: регион полости = 8 ячеек', !!r);
  ok('E: у полости нет отверстий', r && r.open.length === 0);
  drops3 = { cache: { token: 't4', bodies: [A] } };
  const cap = r ? ftCapForRegion3(A, r) : null;
  ok('E: полость заполняется целиком (sealed, capVox=8)', r && cap.sealed === true && cap.capVox === 8);
  drops3 = null;
}
// === F: желобок на поверхности (открыт сверху) ===
{
  const groove = (i, j, k) => j === 10 && i >= 3 && i <= 7 && k === 5;
  const A = makeBody(1, [12, 12, 12], (i, j, k) => groove(i, j, k) ? 2 : (!block(i, j, k) ? 2 : (blockWall(i, j, k) ? 1 : 0)));
  const t = ftBuildTopo3(A);
  const r = t.regions.find(x => x.total === 5);
  ok('F: желобок = регион из 5 ячеек', !!r);
  drops3 = { cache: { token: 't5', bodies: [A] } };
  const cap = r ? ftCapForRegion3(A, r) : null;
  ok('F: жидкость стоит в желобке до края (capVox=5, j=10)', r && cap.capVox === 5 && cap.capJ === 10);
  drops3 = null;
}
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
