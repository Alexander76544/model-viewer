// _shots25.mjs — превью: замеры+магнит, бокс-сечение, ракурсы (asm)
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const j=async u=>{const r=await fetch(u);return r.json();};
const t=await j('http://127.0.0.1:9333/json');
const pg=t.find(x=>x.type==='page'&&x.webSocketDebuggerUrl);
const ws=new WebSocket(pg.webSocketDebuggerUrl);let id=0;const pend=new Map();
ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&pend.has(m.id)){pend.get(m.id)(m);pend.delete(m.id);}};
const send=(m,p={})=>new Promise(r=>{const i=++id;pend.set(i,r);ws.send(JSON.stringify({id:i,method:m,params:p}));});
await new Promise(r=>{ws.onopen=r});
await send('Runtime.enable'); await send('Page.enable');
await send('Emulation.setDeviceMetricsOverride',{width:1500,height:880,deviceScaleFactor:1,mobile:false});
const ev=async x=>{const m=await send('Runtime.evaluate',{expression:x,returnByValue:true});if(m.result.exceptionDetails)throw new Error((m.result.exceptionDetails.exception?.description||'err').slice(0,250));return m.result.result.value;};
async function waitfor(expr,ms=60000){const dl=Date.now()+ms;for(;;){let v=false;try{v=await ev(expr);}catch(e){}if(v)return;if(Date.now()>dl)throw new Error('timeout '+expr);await sleep(400);}}
import fs from 'fs';
async function shot(file){const s=await send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(file,Buffer.from(s.result.data,'base64'));console.log('→',file);}

await send('Page.navigate',{url:'http://127.0.0.1:4173/?model=770_1003011-101_asm_asm.stp'});
await waitfor('stepBodies3 && stepBodies3.length>1 && threeInitialized',90000);
await waitfor('stepBodies3.filter(b=>b._mesh).length >= stepBodies3.length-1',150000);
await sleep(2500);

// 1) ЗАМЕРЫ + МАРКЕРЫ
await ev(`(function(){
  closeAllPanels2(); resetMeasureState3();
  const cb=document.getElementById('snapShowCb'); cb.checked=true; toggleSnapMarkers3(true);
  setMeasureMode3(true);
  const rect=renderer3.domElement.getBoundingClientRect();
  const scr=v=>{const p=v.clone().project(camera3);return [rect.left+(p.x*.5+.5)*rect.width, rect.top+(-p.y*.5+.5)*rect.height];};
  const b=stepBodies3.find(x=>x._mesh); const bb=new THREE.Box3().setFromObject(b._mesh);
  const A=scr(bb.getCenter(new THREE.Vector3())); const ra=measurePick3(A[0],A[1]);
  let B=null; for(let dx=-300;dx<=300&&!B;dx+=50)for(let dy=-220;dy<=220&&!B;dy+=40){const q=[A[0]+dx,A[1]+dy];const r=measurePick3(q[0],q[1]);if(r&&r.point.distanceTo(ra.point)>40)B=q;}
  measureClick3(A[0],A[1]); measureClick3(B[0],B[1]);
  let C=null; const rb=measurePick3(B[0],B[1]);
  for(let dx=-360;dx<=360&&!C;dx+=45)for(let dy=-260;dy<=260&&!C;dy+=35){const q=[A[0]+dx,A[1]+dy];if(!B&&q[0]===B?.[0])continue;const r=measurePick3(q[0],q[1]);if(r&&r.point.distanceTo(ra.point)>40&&r.point.distanceTo(rb.point)>40)C=q;}
  if(C){measureClick3(A[0],A[1]);measureClick3(C[0],C[1]);}
  setMeasureMode3(false);
  window.__openPanel2 && __openPanel2('apMeasure');
})()`);
await sleep(700); await shot('C:\\Workspace\\3d-viewer\\preview-measure.png');

// 2) БОКС-СЕЧЕНИЕ
await ev(`(function(){
  closeAllPanels2();
  document.getElementById('snapShowCb').checked=false; toggleSnapMarkers3(false);
  resetMeasureState3();
  clipState3.enabled=true; clipState3.mode='box';
  clipState3.box.on={x:true,y:true,z:false}; clipState3.box.x=[0.42,1]; clipState3.box.y=[0.5,1]; clipState3.box.z=[0,1];
  syncClipBoxInputs3(); syncClipModeUI3(); applyStlClipping();
  window.__openPanel2 && __openPanel2('apClip');
})()`);
await sleep(700); await shot('C:\\Workspace\\3d-viewer\\preview-box.png');

// 3) РАКУРСЫ
await ev(`(function(){
  closeAllPanels2();
  clipState3.enabled=false; applyStlClipping();
  camTheta3=Math.PI/4; camPhi3=Math.PI/3.2; focusCamera3(); updateCamera3();
  document.getElementById('viewNameInput').value='Изог'; document.getElementById('captureViewBtn').click();
})()`);
await sleep(700);
await ev(`(function(){
  camTheta3=Math.PI*0.85; camPhi3=Math.PI/2.4; updateCamera3();
})()`);
await sleep(900);
await ev(`(function(){
  document.getElementById('viewNameInput').value='Сбоку'; document.getElementById('captureViewBtn').click();
  camTheta3=Math.PI/4; camPhi3=Math.PI/3.2; updateCamera3();
  window.__openPanel2 && __openPanel2('apViews');
})()`);
await sleep(1200); await shot('C:\\Workspace\\3d-viewer\\preview-views.png');

// cleanup превью-сессии
await ev(`(function(){ closeAllPanels2(); resetMeasureState3(); views3=[]; renderViews3(); clipState3.enabled=false; applyStlClipping(); scheduleModelMetaAutosave(); })()`);
ws.close(); process.exit(0);

