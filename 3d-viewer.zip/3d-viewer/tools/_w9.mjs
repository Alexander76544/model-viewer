// _w9.mjs — смоук bolts/clash/thick/sheet на мелкой
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const j=async u=>{const r=await fetch(u);return r.json();};
const t=await j('http://127.0.0.1:9333/json');
const pg=t.find(x=>x.type==='page'&&x.webSocketDebuggerUrl);
const ws=new WebSocket(pg.webSocketDebuggerUrl);let id=0;const pend=new Map();
ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&pend.has(m.id)){pend.get(m.id)(m);}};
const send=(m,p={})=>new Promise(r=>{const i=++id;pend.set(i,r);ws.send(JSON.stringify({id:i,method:m,params:p}));});
await new Promise(r=>{ws.onopen=r});
await send('Runtime.enable'); await send('Page.enable');
const ex=async (x,ap)=>{const m=await send('Runtime.evaluate',{expression:x,returnByValue:true,awaitPromise:ap!==false});if(m.result.exceptionDetails)throw new Error((m.result.exceptionDetails.exception?.description||'EXC').slice(0,500));return m.result.result.value;};
await send('Page.navigate',{url:'http://127.0.0.1:4173/?model=770_1003014-10.stp'});
for(let i=0;i<90;i++){ const ok=await ex('!!(stlMesh3 && stlMesh3.visible && stepBodies3 && stepBodies3.filter(b=>b._mesh).length>=3)',false).catch(()=>false); if(ok)break; await sleep(700); }
await sleep(2500);
// BOLT
const bolt=await ex('(()=>{ const g=boltRun3(); return { groups:g.length, top:g.slice(0,4).map(x=>x.kind+" ⌀"+x.d+" x"+x.n+(x.metric?" "+x.metric:"")+(x.bc?" ОК"+x.bc.d.toFixed(0):"")) }; })()',false);
console.log('BOLT', JSON.stringify(bolt));
// rings click
const rings=await ex('(()=>{ showBoltRings3(0); return { rings: boltRingGrp3? boltRingGrp3.children.length : 0 }; })()',false);
console.log('RINGS', JSON.stringify(rings));
// CLASH (await!)
const t0=Date.now();
const clash=await ex(`(async()=>{ const p=await clashRun3(); const c=voxCache3; return { ms:${'0'}, pairs:p.length, grids:c.bodies.length, skipped:c.skipped, h:+c.h.toFixed(2), inst: clashGrp3 && clashGrp3.children[0] ? clashGrp3.children[0].count : 0, rows: document.querySelectorAll('#clashList .anaRow').length }; })()`);
console.log('CLASH', JSON.stringify({...clash, totalMs:Date.now()-t0}), 'сек');
// CLASH cached rerun
const t1=Date.now();
const clash2=await ex(`(async()=>{ const p=await clashRun3(); return p.length; })()`);
console.log('CLASH cached rerun', clash2, (Date.now()-t1)+'ms');
// THICK
const t2=Date.now();
const thick=await ex(`(async()=>{ const d=await thickRun3(); return { pts: d? d.th.length : 0, min:+Math.min(...Array.from(d.th.slice(0,4000))).toFixed(1), stats: document.getElementById('thickStats').textContent.slice(0,60) }; })()`);
console.log('THICK', JSON.stringify(thick), (Date.now()-t2)+'ms');
// SHEET
const sheet=await ex(`(()=>{ const s=buildSheetSvg3(); return { len:s.length, paths:(s.match(/<path/g)||[]).length, ok:s.startsWith('<svg') && s.indexOf('Изометрия')>0 }; })()`);
console.log('SHEET', JSON.stringify(sheet));
ws.close(); process.exit(0);
