// E2E: разрез по именованной плоскости из STEP (режим 📐 Плоск. STEP).
const PORT = 9333;
const URL_ = 'http://127.0.0.1:4288/?model=_test_torus.stl';
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function j(u){ const r = await fetch(u); return r.json(); }
function connect(wsUrl){
  const ws = new WebSocket(wsUrl);
  let id = 0; const pend = new Map();
  ws.onmessage = e => { const m = JSON.parse(e.data); if(m.id && pend.has(m.id)){ pend.get(m.id)(m); pend.delete(m.id); } };
  const send = (method, params={}) => new Promise(res => { const i=++id; pend.set(i,res); ws.send(JSON.stringify({id:i,method,params})); });
  return { ws, send };
}
async function ev(send, expr){
  const m = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
  if(m.result && m.result.exceptionDetails) throw new Error('EXC '+JSON.stringify(m.result.exceptionDetails));
  return m.result && m.result.result ? m.result.result.value : undefined;
}
(async ()=>{
  let targets;
  for(let k=0;k<40;k++){ try{ targets = await j('http://127.0.0.1:'+PORT+'/json'); if(targets.some(t=>t.type==='page')) break; }catch(e){} await sleep(500); }
  const page = targets.find(t=>t.type==='page' && t.webSocketDebuggerUrl);
  if(!page) throw new Error('нет page target');
  const { ws, send } = connect(page.webSocketDebuggerUrl);
  await new Promise(r=>{ ws.onopen = r; });
  await send('Runtime.enable');
  await send('Page.navigate', { url: URL_ });
  let ready = false;
  for(let k=0;k<160;k++){
    try{ const ok = await ev(send, '(typeof threeInitialized!=="undefined" && threeInitialized && !!stlMesh3 && modelMaterials3().length) || 0'); if(ok){ ready = true; break; } }catch(e){}
    await sleep(500);
  }
  if(!ready) throw new Error('модель не загрузилась');
  console.log('MODEL OK, материалов:', await ev(send, 'modelMaterials3().length'));

  // 1) без разрезов кнопка выключена
  const noPlane = await ev(send, '(()=>{ syncStepCuts3({}); const b=document.getElementById("clipModePlane"); return {disabled:b.disabled, hint:document.getElementById("clipPlaneVal").textContent}; })()');
  console.log('NO CUTS', JSON.stringify(noPlane));
  if(noPlane.disabled !== true) throw new Error('кнопка должна быть disabled без разрезов');

  // 2) сечение из AP242 (XSEC0001): плоскость x=10 в системе детали
  const withPlane = await ev(send, `(()=>{
    syncStepCuts3({sections:[{name:'XSEC0001', planes:[{o:[10,0,0], n:[1,0,0]}]}]});
    const b=document.getElementById('clipModePlane');
    b.click();
    const mats=modelMaterials3();
    return { disabled:b.disabled, active:b.classList.contains('active'),
             planeWrap:document.getElementById('clipPlaneWrap').style.display,
             clipCount:mats[0].clippingPlanes ? mats[0].clippingPlanes.length : 0,
             normal:mats[0].clippingPlanes ? mats[0].clippingPlanes[0].normal.toArray().map(v=>+v.toFixed(3)) : null,
             const:mats[0].clippingPlanes ? +mats[0].clippingPlanes[0].constant.toFixed(2) : null,
             selOptions:document.getElementById('clipPlaneSel').options.length,
             selText:document.getElementById('clipPlaneSel').options[0].textContent,
             hint:document.getElementById('clipPlaneVal').textContent };
  })()`);
  console.log('SECTION APPLIED', JSON.stringify(withPlane));
  if(withPlane.disabled || !withPlane.active) throw new Error('режим plane не включился');
  if(withPlane.clipCount !== 1) throw new Error('плоскость не применена к материалам');

  // 2б) многоплоскостное сечение (как H12/C-виды) + датумы в общем списке
  const multi = await ev(send, `(()=>{
    syncStepCuts3({sections:[{name:'A1', planes:[{o:[10,0,0], n:[1,0,0]}, {o:[0,10,0], n:[0,1,0]}]}],
                    planes:[{name:'DTM1', o:[0,0,0], n:[0,0,1]}]});
    const opts=[...document.getElementById('clipPlaneSel').options].map(o=>o.textContent);
    document.getElementById('clipPlaneSel').value='0';
    document.getElementById('clipPlaneSel').dispatchEvent(new Event('change'));
    const n=modelMaterials3()[0].clippingPlanes.length;
    document.getElementById('clipPlaneSel').value='1';
    document.getElementById('clipPlaneSel').dispatchEvent(new Event('change'));
    const m=modelMaterials3()[0].clippingPlanes;
    return { options:opts, multiCount:n, datumCount:m.length, datumName:document.getElementById('clipPlaneVal').textContent.split(' · ')[0] };
  })()`);
  console.log('MULTI/DATUM', JSON.stringify(multi));
  if(multi.multiCount !== 2) throw new Error('многоплоскостное сечение не применилось');
  if(multi.options.length !== 2) throw new Error('список разрезов не объединил сечения и датумы');
  if(multi.datumName !== 'DTM1' || multi.datumCount !== 1) throw new Error('датум-плоскость не применилась');

  // вернуть одиночное сечение x=10 для проверок отступа/реверса
  await ev(send, `syncStepCuts3({sections:[{name:'XSEC0001', planes:[{o:[10,0,0], n:[1,0,0]}], cam:{o:[300,0,0], z:[1,0,0]}}]}); document.getElementById('clipPlaneSel').value='0'; document.getElementById('clipPlaneSel').dispatchEvent(new Event('change')); 1`);

  // 2в) кнопка «👁 вид» встаёт на точку обзора из STEP
  const viewBtn = await ev(send, `(()=>{
    const d0=camDist3, t0=camTheta3;
    const dis=document.getElementById('clipPlaneView').disabled;
    document.getElementById('clipPlaneView').click();
    return { disabled:dis, distChanged:Math.abs(camDist3-d0)>0.01, thetaChanged:Math.abs(camTheta3-t0)>1e-6,
             camX:camera3.position.x.toFixed(1) };
  })()`);
  console.log('CUT VIEW', JSON.stringify(viewBtn));
  if(viewBtn.disabled) throw new Error('кнопка вида должна быть доступна при наличии камеры');
  if(!viewBtn.distChanged || !viewBtn.thetaChanged) throw new Error('камера не перешла к виду разреза');
  const noCam = await ev(send, `(()=>{ syncStepCuts3({sections:[{name:'plain', planes:[{o:[10,0,0], n:[1,0,0]}]}]}); return document.getElementById('clipPlaneView').disabled; })()`);
  if(noCam !== true) throw new Error('без камеры кнопка вида должна быть недоступна');

  // 3) отступ и реверс (плоскость x=10 в системе детали)
  const moved = await ev(send, `(()=>{
    const off=document.getElementById('clipPlaneOff'); off.value='25'; off.dispatchEvent(new Event('input'));
    const m1=modelMaterials3()[0].clippingPlanes[0];
    off.value='0'; off.dispatchEvent(new Event('input'));
    const fl=document.getElementById('clipPlaneFlip'); fl.checked=true; fl.dispatchEvent(new Event('change'));
    const m2=modelMaterials3()[0].clippingPlanes[0];
    return { constOff:+m1.constant.toFixed(2), nOff:m1.normal.toArray().map(v=>+v.toFixed(2)),
             constFlip:+m2.constant.toFixed(2), nFlip:m2.normal.toArray().map(v=>+v.toFixed(2)),
             offLabel:document.getElementById('clipPlaneOffVal').textContent };
  })()`);
  console.log('OFFSET/FLIP', JSON.stringify(moved));
  if(moved.nOff[0] !== 1 || Math.abs(moved.constOff + 35) > 0.01) throw new Error('отступ применён неверно');
  if(moved.nFlip[0] !== -1 || Math.abs(moved.constFlip - 10) > 0.01) throw new Error('реверс применён неверно');

  // 4) сброс и отключение
  const reset = await ev(send, `(()=>{
    document.getElementById('clipPlaneReset').click();
    const c1 = modelMaterials3()[0].clippingPlanes.length;
    document.getElementById('clipEnableCb').checked=false;
    document.getElementById('clipEnableCb').dispatchEvent(new Event('change'));
    return { afterReset:c1, afterDisable:modelMaterials3()[0].clippingPlanes };
  })()`);
  console.log('RESET/DISABLE', JSON.stringify(reset));
  if(reset.afterDisable !== null) throw new Error('выключение не убрало плоскость');
  console.log('RESULT: OK');
  ws.close();
  process.exit(0);
})().catch(e=>{ console.error('FAIL', e.message); process.exit(1); });
