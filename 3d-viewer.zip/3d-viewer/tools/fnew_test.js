// Тест новых возможностей жидкости: скрытая заглушка, разрез, барьер, прямая заливка
'use strict';
const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const sA = html.indexOf('function fluidBodyVisible3');
const eA = html.indexOf('function ftBuildTopo3');
const sB = html.indexOf('function ftBuildTopo3');
const eB = html.indexOf('function fluidPointKind3');
const sC = html.indexOf('function fluidPointKind3');
const eC = html.indexOf('function fluidSettleIdx3');
if(sA<0||sB<0||sC<0){ console.log('MARKERS NOT FOUND', sA, sB, sC); process.exit(1); }
const core = html.slice(sA, eA) + '\n' + html.slice(sB, eB) + '\n' + html.slice(sC, eC);

const VF_SURF=1, VF_OUT=2, FTK_SOLID=0, FTK_CAV=1, FTK_AIR=2, FTK_PASS=3;
globalThis.VF_SURF=VF_SURF; globalThis.VF_OUT=VF_OUT;
globalThis.FTK_SOLID=FTK_SOLID; globalThis.FTK_CAV=FTK_CAV; globalThis.FTK_AIR=FTK_AIR; globalThis.FTK_PASS=FTK_PASS;
class V3{ constructor(x=0,y=0,z=0){this.x=x;this.y=y;this.z=z;} set(x,y,z){this.x=x;this.y=y;this.z=z;return this;} clone(){return new V3(this.x,this.y,this.z);} }
class Plane{ constructor(n, c){ this.normal = n||new V3(0,1,0); this.constant = (c===undefined)?0:c; }
  distanceToPoint(p){ return this.normal.x*p.x + this.normal.y*p.y + this.normal.z*p.z + this.constant; } }
globalThis.THREE = { Vector3: V3, Plane: Plane };
globalThis.fluidClipPlanes3 = null; globalThis.fluidBarrier3 = null; globalThis.fluidRegionCache3 = null; globalThis.fluidCavitiesGrp3 = null;
globalThis.stlMesh3 = { visible: true };
globalThis.fluid3 = null; globalThis.drops3 = null;
globalThis.modelMaterials3 = ()=>[]; globalThis.fluidMsg3 = ()=>{};
(0, eval)(core);

const H=0.5, DX=203;
const grid = new Uint8Array(DX*DX*DX);
const inBlock=(x,y,z)=> x>=0&&x<=100&&y>=0&&y<=100&&z>=0&&z<=100;
const inHoleA=(x,y,z)=> x>=45&&x<=55&&y>=50&&y<=100&&z>=45&&z<=55;   // слепое (центр 50,50)
const inHoleB=(x,y,z)=> x>=70&&x<=80&&y>=0&&y<=100&&z>=70&&z<=80;    // сквозное (центр 75,75)
for(let k=0;k<DX;k++) for(let j=0;j<DX;j++) for(let i=0;i<DX;i++){
  const x=-H+(i+0.5)*H, y=-H+(j+0.5)*H, z=-H+(k+0.5)*H, idx=(k*DX+j)*DX+i;
  if(!inBlock(x,y,z)){ grid[idx]=2; continue; }
  if(inHoleA(x,y,z)||inHoleB(x,y,z)){ grid[idx]=2; continue; }
  grid[idx] = Math.min(x,100-x,y,100-y,z,100-z) < H ? 1 : 0;
}
const body = { id:-1, name:'test', grid, dims:[DX,DX,DX], mins:[-H,-H,-H], h:H, box:{ containsPoint:()=>true } };
body._ftopo = ftBuildTopo3(body);
globalThis.drops3 = { cache:{ token:'t', bodies:[body], h:H }, list:[] };

let pass=0, fail=0;
const ok=(n,c)=>{ if(c){pass++;} else {fail++; console.log('  FAIL '+n);} };

// 1) видимость тел
globalThis.stepBodies3 = [{id:5,_mesh:{visible:false}},{id:6,_mesh:{visible:true}}];
ok('видимость: скрытое тело не участвует', fluidBodyVisible3({id:5})===false);
ok('видимость: видимое тело участвует', fluidBodyVisible3({id:6})===true);
ok('видимость: чистая STL (id -1) по stlMesh3', fluidBodyVisible3({id:-1})===true);

// 2) разрез
globalThis.fluidClipPlanes3 = [ new Plane(new V3(0,1,0), 0) ];
ok('разрез: точка ниже плоскости отсечена', fluidPointClipped3({x:0,y:-1,z:0})===true);
ok('разрез: точка выше плоскости — в материале', fluidPointClipped3({x:0,y:1,z:0})===false);
globalThis.fluidClipPlanes3 = null;

// 3) барьер
globalThis.fluidBarrier3 = { on:true, y:50 };
ok('барьер: ниже — заблокировано', fluidPointBarrier3({x:0,y:40,z:0})===true);
ok('барьер: выше — свободно', fluidPointBarrier3({x:0,y:60,z:0})===false);

// 4) скрытая заглушка в fluidPointKind3
globalThis.stlMesh3.visible = true;
let pk = fluidPointKind3(new V3(10,50,10));
ok('точка в материале видимой STL — SOLID', pk && pk.kind===FTK_SOLID);
globalThis.stlMesh3.visible = false;
pk = fluidPointKind3(new V3(10,50,10));
ok('точка в материале СКРЫТОЙ STL — пусто (не мешает)', pk===null);
globalThis.stlMesh3.visible = true;

// 5) прямая заливка слепой полости
globalThis.fluid3 = { type:'fuel', dropD:10, pools:[] };
globalThis.stepBodies3 = [];
const blind = body._ftopo.regions.findIndex(r=>r.minY>50);
ok('слепая полость найдена', blind>=0);
const rBlind = body._ftopo.regions[blind];
ok('заливка слепой полости — true', fluidFillRegion3({b:body, ri:blind})===true);
ok('заливка: пул создан, уровень = полному объёму', (()=>{ const p=fluid3.pools[0]; return p && p.capVox===rBlind.total && p.depositedVox===rBlind.total && p.curVox===rBlind.total; })());

// 6) барьер меняет крышку сквозного канала
const thru = body._ftopo.regions.findIndex(r=>r.minY<=5);
const rThru = body._ftopo.regions[thru];
globalThis.fluidBarrier3 = null;
const cap0 = ftCapForRegion3(body, rThru);
globalThis.fluidBarrier3 = { on:true, y:0 };
const cap1 = ftCapForRegion3(body, rThru);
ok('сквозной без барьера: крышка ~0', cap0.capVox < rThru.total*0.05);
ok('сквозной с барьером на дне: крышка ≈ весь канал', cap1.capVox > rThru.total*0.9);
globalThis.fluidBarrier3 = null;

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail?1:0);
