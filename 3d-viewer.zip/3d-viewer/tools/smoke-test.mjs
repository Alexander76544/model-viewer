// tools/smoke-test.mjs — дымовой тест 3d-viewer: движок three.js (из index.html) + stub DOM + app-блок.
// запуск: node tools/smoke-test.mjs [путь/к/index.html]
// Проверяет: загрузка STL, 🩻 рентген, 🎯 произвольная плоскость, 📐 DXF (+🚫 HLR),
// 🔎 фичи (CAD-грани + воксели), 🪟 мультивид, ✍️ аннотации, 🤖 Ollama (mock fetch), ↶/↷ undo-redo.
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const P = process.argv[2] || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'index.html');
const html = readFileSync(P, 'utf8');
const blocks = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
if (blocks.length !== 2) { console.error('ОЖИДАЛОСЬ 2 script-блока, найдено', blocks.length); process.exit(1); }

// ---------- stub DOM ----------
function makeEl(tag) {
  const el = {
    tagName: (tag || 'div').toUpperCase(),
    style: {}, dataset: {}, children: [],
    textContent: '', value: '', checked: false, innerHTML: '',
    offsetWidth: 100, offsetHeight: 50, clientWidth: 800, clientHeight: 600,
    width: 92, height: 92,
    _cls: new Set(),
    classList: null,
    addEventListener() {}, removeEventListener() {},
    appendChild(c) { el.children.push(c); return c; },
    remove() {}, click() {}, focus() {}, blur() {},
    setAttribute() {}, getAttribute() { return null; },
    querySelector() { return makeEl('div'); },
    querySelectorAll() { return []; },
    closest() { return null; }, contains() { return false; },
    getBoundingClientRect() { return { left: 0, top: 0, width: 800, height: 600, right: 800, bottom: 600 }; },
    getContext() { return ctx2d; },
    dispatchEvent() { return true; },
  };
  el.classList = {
    add: c => el._cls.add(c), remove: c => el._cls.delete(c),
    toggle: (c, f) => { const on = f === undefined ? !el._cls.has(c) : !!f; on ? el._cls.add(c) : el._cls.delete(c); return on; },
    contains: c => el._cls.has(c),
  };
  return el;
}
const ctx2d = {
  font: '', measureText: () => ({ width: 12 }), fillText() {}, strokeText() {},
  clearRect() {}, fillRect() {}, beginPath() {}, arc() {}, rect() {}, fill() {}, stroke() {},
  closePath() {}, moveTo() {}, lineTo() {}, arcTo() {}, ellipse() {}, save() {}, restore() {}, translate() {}, scale() {},
  setTransform() {}, createLinearGradient: () => ({ addColorStop() {} }),
};
const elById = new Map();
const documentStub = {
  getElementById(id) { if (!elById.has(id)) elById.set(id, makeEl('div')); return elById.get(id); },
  createElement(t) { return makeEl(t); },
  createTextNode(t) { return { nodeType: 3, textContent: String(t) }; },
  querySelectorAll() { return []; }, querySelector() { return null; },
  addEventListener() {}, removeEventListener() {},
  body: makeEl('body'), documentElement: makeEl('html'),
  activeElement: null, fullscreenElement: null, webkitFullscreenElement: null,
  exitFullscreen() { return Promise.resolve(); },
};

const alerts = [];
let lastBlob = null;

// ---------- моки Ollama (🤖 спроси модель): /api/tags + /api/chat (NDJSON-стрим) ----------
const mockAI = { tags: 0, chats: 0, lastBody: null };
function mockFetch(url, opts) {
  const u = String(url);
  if (u.includes('nowhere.invalid')) return Promise.reject(new Error('ECONNREFUSED (mock)'));
  if (u.endsWith('/api/tags')) {
    mockAI.tags++;
    return Promise.resolve(new Response(JSON.stringify({ models: [{ name: 'llama3.2' }, { name: 'qwen2.5:7b' }] }), { status: 200 }));
  }
  if (u.endsWith('/api/chat')) {
    mockAI.chats++;
    mockAI.lastBody = opts && opts.body ? JSON.parse(opts.body) : null;
    const enc = new TextEncoder();
    const rs = new ReadableStream({
      start(c) {
        c.enqueue(enc.encode(JSON.stringify({ message: { role: 'assistant', content: 'Габарит: ' }, done: false }) + '\n'));
        c.enqueue(enc.encode(JSON.stringify({ message: { role: 'assistant', content: '10×10×10 мм' }, done: false }) + '\n'));
        c.enqueue(enc.encode(JSON.stringify({ message: { role: 'assistant', content: '' }, done: true }) + '\n'));
        c.close();
      },
    });
    return Promise.resolve(new Response(rs, { status: 200 }));
  }
  return Promise.reject(new Error('mockFetch: unexpected url ' + u));
}
const sandbox = {
  console, performance,
  setTimeout, clearTimeout, setInterval, clearInterval,
  URL, URLSearchParams, Blob: class { constructor(parts, opts) { this.parts = parts; this.type = opts && opts.type; } },
  Event: class { constructor(t) { this.type = t; } },
  File: class {},
  FileReader: class {
    readAsArrayBuffer(f) { this.result = f._buf; if (this.onload) this.onload({ target: this }); }
    readAsText(f) { this.result = f._text; if (this.onload) this.onload({ target: this }); }
  },
  alert: (m) => { alerts.push(String(m)); },
  fetch: mockFetch,
  Response: globalThis.Response,
  ReadableStream: globalThis.ReadableStream,
  AbortController: globalThis.AbortController,
  localStorage: (() => { const m = new Map(); return { getItem: k => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: k => m.delete(k) }; })(),
  indexedDB: { open: () => ({ onsuccess: null, onerror: null }) },   // idb-проми́сы не резолвятся — restore в подвешенном состоянии (ок)
  navigator: { userAgent: 'node-test', maxTouchPoints: 0 },
  devicePixelRatio: 1,
  matchMedia: () => ({ matches: false, addEventListener() {}, removeEventListener() {} }),
  requestAnimationFrame: () => 0,
  cancelAnimationFrame() {},
  location: { search: '', protocol: 'file:', href: 'file:///test/', pathname: '/index.html' },
  document: documentStub,
  HTMLElement: class {},
  TextEncoder, TextDecoder,
  addEventListener() {}, removeEventListener() {},
  __lastBlob: () => lastBlob,
  __mockAI: mockAI,
};
sandbox.window = sandbox;
sandbox.self = sandbox;
sandbox.globalThis = sandbox;
const context = vm.createContext(sandbox);
const run = (code) => vm.runInContext(code, context, { filename: 'test.js' });

// ---------- 1) движок ----------
vm.runInContext(blocks[0], context, { filename: 'engine.js' });
if (!context.THREE) { console.error('THREE не появился после engine-блока'); process.exit(1); }

// ---------- 2) фейковый WebGLRenderer (GL в node нет) ----------
class FakeRenderer {
  constructor() {
    this.domElement = makeEl('canvas');
    this.domElement.clientWidth = 800; this.domElement.clientHeight = 600;
    this.shadowMap = { enabled: false, type: 0 };
    this.outputColorSpace = 'srgb';
    this.toneMapping = 0; this.toneMappingExposure = 1;
    this.xr = { isPresenting: false, addEventListener() {}, removeEventListener() {}, setAnimationLoop() {} };
    this._size = [800, 600]; this._pr = 1;
    this.localClippingEnabled = false;
  }
  setSize(w, h) { this._size = [w, h]; }
  setPixelRatio(v) { this._pr = v; }
  getPixelRatio() { return this._pr; }
  getSize(v) { v.set(this._size[0], this._size[1]); return v; }
  render() {} setAnimationLoop() {} dispose() {}
  setScissorTest() {} setScissor() {} setViewport() {}
  getContext() { return null; }
}
context.THREE.WebGLRenderer = FakeRenderer;
const RealURL = context.URL;
context.URL.createObjectURL = (blob) => { lastBlob = blob; return 'blob:fake-' + Math.random().toString(36).slice(2); };
context.URL.revokeObjectURL = () => {};

// ---------- 3) app-блок ----------
try {
  vm.runInContext(blocks[1], context, { filename: 'app.js' });
} catch (e) {
  console.error('APP BLOCK THREW AT TOP LEVEL:', e.stack.split('\n').slice(0, 8).join('\n'));
  process.exit(1);
}

// ---------- 4) сценарий (код исполняется ВНУТРИ контекста — видит let-состояние) ----------
const failures = [];
const chk = (name, cond) => { if (cond) console.log('  ok  ' + name); else { console.log('FAIL  ' + name); failures.push(name); } };

// binary STL: куб 10×10×10, 12 треугольников — кладём в контекст
try {
run(`__cubeBuf = (() => {
  const s = 10;
  const v = [[0,0,0],[s,0,0],[s,s,0],[0,s,0],[0,0,s],[s,0,s],[s,s,s],[0,s,s]];
  const faces = [[0,3,2],[0,2,1],[4,5,6],[4,6,7],[0,1,5],[0,5,4],[1,2,6],[1,6,5],[2,3,7],[2,7,6],[3,0,4],[3,4,7]];
  const buf = new ArrayBuffer(84 + faces.length * 50);
  const dv = new DataView(buf);
  const ta = new TextEncoder().encode('smoke-test-cube'); ta.forEach((b, i) => dv.setUint8(i, b));
  dv.setUint32(80, faces.length, true);
  let off = 84;
  for (const f of faces) {
    const a = v[f[0]], b = v[f[1]], c = v[f[2]];
    const ux = b[0]-a[0], uy = b[1]-a[1], uz = b[2]-a[2], vx = c[0]-a[0], vy = c[1]-a[1], vz = c[2]-a[2];
    const nx = uy*vz-uz*vy, ny = uz*vx-ux*vz, nz = ux*vy-uy*vx;
    dv.setFloat32(off, nx, true); dv.setFloat32(off+4, ny, true); dv.setFloat32(off+8, nz, true);
    let vo = off + 12;
    for (const p of [a, b, c]) { dv.setFloat32(vo, p[0], true); dv.setFloat32(vo+4, p[1], true); dv.setFloat32(vo+8, p[2], true); vo += 12; }
    dv.setUint16(off+48, 0, true);
    off += 50;
  }
  return buf;
})()`);
} catch (e) {
  console.error('STL-gen failed:', e.message);
  const d = run(`({ ab: ArrayBuffer.toString().slice(0, 80), dv: DataView.toString().slice(0, 80), fl: typeof faces })`);
  console.error('diag:', JSON.stringify(d));
  process.exit(1);
}

console.log('== загрузка STL ==');
run(`loadModelFile({ name: 'cube.stl', size: __cubeBuf.byteLength, _buf: __cubeBuf })`);
let r = run(`({
  mesh: !!(stlMesh3 && stlMesh3.isMesh),
  verts: stlMesh3 ? stlMesh3.geometry.attributes.position.count : -1,
})`);
chk('stlMesh3 создан (Mesh)', r.mesh);
chk('вершин 36 (12 трег.)', r.verts === 36);

console.log('== 🩻 рентген ==');
run(`applyXray3(true)`);
r = run(`({
  xrayMat: !!(stlMesh3.material.userData && stlMesh3.material.userData.xray3),
  noShadow: stlMesh3.castShadow === false,
  shaderHasVXrZ: String(stlMesh3.material.onBeforeCompile).includes('vXrZ'),
  ls: localStorage.getItem('pcdmis3d.xray'),
})`);
chk('материал заменён на xray-клон', r.xrayMat);
chk('castShadow выключен', r.noShadow);
chk('шейдер содержит vXrZ', r.shaderHasVXrZ);
chk('localStorage pcdmis3d.xray=1', r.ls === '1');
run(`applyRecolor3([-1], { h: '#ff0000', o: 1 })`);
r = run(`({ col: stlMesh3.material.color.getHex(), stillXray: !!(stlMesh3.material.userData && stlMesh3.material.userData.xray3) })`);
chk('окраска применилась к xray-материалу', r.col === 0xff0000 && r.stillXray);
run(`applyXray3(false)`);
r = run(`({ notXray: !(stlMesh3.material.userData && stlMesh3.material.userData.xray3), shadow: stlMesh3.castShadow !== false })`);
chk('оригинальный материал возвращён', r.notXray);
chk('castShadow восстановлен', r.shadow);

console.log('== 🎯 произвольная плоскость ==');
// 3 точки на плоскости y=3 (three): (2,3,2) (8,3,2) (2,3,8) → нормаль (0,±1,0)
r = run(`(() => {
  freePickPts3.length = 0;
  const V = THREE.Vector3;
  freePickPts3.push(new V(2,3,2), new V(8,3,2), new V(2,3,8));
  const a = freePickPts3[0], b = freePickPts3[1], c = freePickPts3[2];
  const n = new V().subVectors(b, a).cross(new V().subVectors(c, a)).normalize();
  clipState3.free = { o: [a.x, a.y, a.z], n: [n.x, n.y, n.z], off: 0, flip: false };
  clipState3.enabled = true; clipState3.mode = 'free';
  applyStlClipping();
  const m = modelMaterials3()[0];
  const pl = m.clippingPlanes;
  const c1 = pl ? pl[0].constant : null;
  clipState3.free.off = 3; applyStlClipping();
  const c2 = m.clippingPlanes[0].constant;
  return {
    mode: clipState3.mode,
    nCalc: [n.x, n.y, n.z],
    planes: pl ? pl.length : 0,
    c1, c2,
    helper: !!(freePlaneVis3 && freePlaneVis3.parent === stlMesh3),
    helperKids: freePlaneVis3 ? freePlaneVis3.children.length : 0,
  };
})()`);
chk('режим free активен', r.mode === 'free');
chk('нормаль (0,±1,0) — плоскость y=const (three-up)', Math.abs(r.nCalc[1]) > 0.99);
chk('одна клип-плоскость назначена', r.planes === 1);
chk('плоскость через точки: |constant| ≈ 3', Math.abs(Math.abs(r.c1) - 3) < 1e-6);
chk('отступ +3мм: constant сдвинулся точно на 3', Math.abs(Math.abs(r.c2 - r.c1) - 3) < 1e-6);
chk('helper плоскости в сцене (диск+обводка+стрелка)', r.helper && r.helperKids >= 2);

console.log('== 📐 DXF ==');
run(`exportDxf3()`);
r = run(`__lastBlob()`);
chk('Blob DXF скачан', !!r);
if (r) {
  const t = r.parts[0];
  chk('начинается с 0\\nSECTION', t.startsWith('0\nSECTION'));
  chk('единицы мм ($INSUNITS 4)', t.includes('$INSUNITS') && t.includes('\n70\n4\n'));
  chk('есть LINE (12+ с рамками)', (t.match(/LINE/g) || []).length >= 12);
  chk('есть TEXT (3 вида)', (t.match(/TEXT/g) || []).length >= 3);
  chk('нет NaN', !/NaN/.test(t));
  chk('5 слоёв объявлены', ['VP_FRONT','VP_LEFT','VP_TOP','VP_FRAME','NOTES'].every(L => t.includes('2\n' + L + '\n')));
  console.log('  dxf: ' + t.length + ' B, строк LINE: ' + (t.match(/LINE/g) || []).length);
}

console.log('== 🚫 DXF без невидимых линий (HLR) ==');
// чистая математика: большой куб (0..10)³ + маленький (3..7)×(3..7)×(-4..0) за его задней гранью
r = run(`(() => {
  function cubeTris(x0,y0,z0,x1,y1,z1){
    const v=[[x0,y0,z0],[x1,y0,z0],[x1,y1,z0],[x0,y1,z0],[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]];
    const quads=[[0,1,2,3],[4,5,6,7],[0,1,5,4],[2,3,7,6],[1,2,6,5],[0,3,7,4]];
    const out=[];
    for(const q of quads){
      out.push(v[q[0]][0],v[q[0]][1],v[q[0]][2], v[q[1]][0],v[q[1]][1],v[q[1]][2], v[q[2]][0],v[q[2]][1],v[q[2]][2]);
      out.push(v[q[0]][0],v[q[0]][1],v[q[0]][2], v[q[2]][0],v[q[2]][1],v[q[2]][2], v[q[3]][0],v[q[3]][1],v[q[3]][2]);
    }
    return out;
  }
  function cubeSegs(x0,y0,z0,x1,y1,z1){
    const e=[]; const add=(a,b,c,d2,e2,f2)=>e.push(a,b,c,d2,e2,f2);
    add(x0,y0,z0,x1,y0,z0); add(x1,y0,z0,x1,y1,z0); add(x1,y1,z0,x0,y1,z0); add(x0,y1,z0,x0,y0,z0);
    add(x0,y0,z1,x1,y0,z1); add(x1,y0,z1,x1,y1,z1); add(x1,y1,z1,x0,y1,z1); add(x0,y1,z1,x0,y0,z1);
    add(x0,y0,z0,x0,y0,z1); add(x1,y0,z0,x1,y0,z1); add(x1,y1,z0,x1,y1,z1); add(x0,y1,z0,x0,y1,z1);
    return e;
  }
  const tris = new Float32Array([...cubeTris(0,0,0,10,10,10), ...cubeTris(3,3,-4,7,7,0)]);
  const g = hlBuildGrid3(tris);
  const segs = [...cubeSegs(0,0,0,10,10,10), ...cubeSegs(3,3,-4,7,7,0)];
  const front = hlFilterSegs3(segs, [{u:[1,0,0],v:[0,1,0]}], g)[0];
  const top   = hlFilterSegs3(segs, [{u:[1,0,0],v:[0,0,-1]}], g)[0];
  const sum=(arr,i0,i1)=>{ let t=0; for(let i=i0;i<i1;i++) t+=arr[i]; return t; };
  return { vf: sum(front,0,12), vb: sum(front,12,24), tt: sum(top,0,12), tb: sum(top,12,24) };
})()`);
// куб в чистом ортовиде: видим только 4 рёбра контура; вертикальные рёбра проецируются в угловые точки
chk('HLR front: 4/12 рёбер куба видимы (контуры, задние скрыты)', r.vf === 4);
chk('HLR front: куб за деталью — 0 видимых рёбер', r.vb === 0);
chk('HLR top: A — 4/12 видимы', r.tt === 4);
chk('HLR top: B — 3 ребра (полоска, выступающая за A по z) видимы', r.tb === 3);
r = run(`(() => {
  document.getElementById('dxfNoHiddenCb').checked = true;
  exportDxf3();
  const t = __lastBlob().parts[0];
  const n = (t.match(/LINE/g) || []).length;
  document.getElementById('dxfNoHiddenCb').checked = false;
  return { n, nan: /NaN/.test(t) };
})()`);
chk('DXF+HLR: 3 вида × (4 рёбра + 4 рамки) = 24 LINE', r.n === 24);
chk('DXF+HLR: нет NaN', !r.nan);

console.log('== 🔎 обзорщик фич ==');
r = run(`(() => {
  const V = THREE.Vector3;
  faceCatalog3 = { '1': [
    { t:'C', cv:new V(5,5,5), dv:new V(0,0,1), r:5, h:10, ang:6.2832, rev:1, a:314 },   // сквозное ⌀10
    { t:'K', apv:new V(5,5,0), dv:new V(0,0,1), sa:0.1974, r0:4, r1:5, ang:6.2832, rev:0, a:60 }, // фаска
    { t:'C', cv:new V(9,9,5), dv:new V(0,0,1), r:1, h:2, ang:1.5708, rev:0, a:15 }      // дуга R1 (скругление)
  ] };
  const list = featFromFaces3();
  faceCatalog3 = {};
  const hole = list.find(f=>f.kind==='hole');
  return { n: list.length, kinds: list.map(f=>f.kind), through: hole ? /сквозное/.test(hole.name) : false };
})()`);
chk('фичи: найдены hole+chamfer+fillet', r.n === 3 && r.kinds.join(',') === 'hole,chamfer,fillet');
chk('фичи: отверстие ⌀10 в кубе 10мм — сквозное', r.through);

console.log('== 🪟 мультивид ==');
r = run(`(() => {
  mvToggle3();
  const on1 = multiView3;
  const layout = { colW: mvL3.colW, mainW: mvL3.mainW, rows: mvL3.rows.length };
  const mv = mvViews3[0];
  const th0 = mv.th, ph0 = mv.ph;
  camTheta3 += 0.5; camPhi3 -= 0.2; updateCamera3();
  const dth = mv.th - th0, dph = mv.ph - ph0;
  renderScene3();   // scissor-путь не падает
  const mvOff = !multiView3;
  mvToggle3();
  const off2 = !multiView3;
  return { on1, layout, dth, dph, mvOff, off2 };
})()`);
chk('мультивид: вкл + layout 3 ряда / 3 окна', r.on1 && r.layout.rows === 3 && r.layout.colW > 0 && r.layout.mainW > 0);
chk('мультивид: синхронизация орбиты (Δθ=+0.5, Δφ=-0.2)', Math.abs(r.dth - 0.5) < 1e-9 && Math.abs(r.dph + 0.2) < 1e-9);
chk('мультивид: выкл — multiView3=false', r.off2);

console.log('== ✍️ аннотации ==');
r = run(`(() => {
  annos3.length = 0; annoSeq3 = 1;
  annos3.push({ id:1, type:'note', a:[2,2,2], b:null, n:[0,1,0], text:'Тест', color:'#ffd43b' });
  annos3.push({ id:2, type:'arrow', a:[4,2,2], b:[8,6,2], n:[0,0,1], text:'→', color:'#22d3ee' });
  rebuildAnnos3();
  const children = annoGroup3 ? annoGroup3.children.length : -1;
  const meta = currentModelMeta();
  const okMeta = Array.isArray(meta.annos3) && meta.annos3.length===2 && meta.annos3[0].text==='Тест' && meta.annos3[1].type==='arrow';
  annos3.length = 0;
  applyRestoredMeta3({ annos3: meta.annos3 });
  return { children, okMeta, restored: annos3.length===2 && annos3[1].b && annos3[1].b[1]===6 };
})()`);
chk('аннотации: заметка + стрелка нарисованы в сцене', r.children >= 6);
chk('аннотации: вошли в мету модели (автосохранение)', r.okMeta);
chk('аннотации: восстановлены из меты (roundtrip)', r.restored);
r = run(`(() => { setAnnoMode3(true); const on = annoMode3; const hud = document.getElementById('annoHud').style.display; setAnnoMode3(false); return { on, hud, off: !annoMode3 }; })()`);
chk('аннотации: включение/выключение режима + HUD', r.on && r.hud === 'flex' && r.off);

console.log('== 🤖 спроси модель (Ollama, mock) ==');
r = run(`(() => {
  const ctx = aiContext3();
  return { hasDims: ctx.indexOf('Габариты') >= 0 && /10/.test(ctx), stl: ctx.indexOf('STL') >= 0, len: ctx.length };
})()`);
chk('AI: контекст модели собран (габариты куба 10, тип STL)', r.hasDims && r.stl && r.len > 30);
await run(`(async () => { aiInit3(); setAIMode3('llm'); await aiLoadModels3(); })()`);
r = run(`(() => {
  const sel = document.getElementById('aiModel');
  return { opts: sel.children.length, val: sel.value, llm: aiMode3 === 'llm' };
})()`);
chk('AI: список моделей с /api/tags (2 шт, дефолт llama3.2)', r.opts === 2 && r.val === 'llama3.2' && r.llm);
{
  const p = run(`(() => { const inp = document.getElementById('aiInp'); inp.value = 'Какие габариты?'; return aiSend3(); })()`);
  await p;
}
r = run(`(() => {
  const log = document.getElementById('aiLog');
  const kids = log.children;
  const last = kids[kids.length-1];
  return { n: kids.length, last: last ? last.textContent : '', hist: aiHist3.length, busy: aiBusy3 };
})()`);
chk('AI: стриминговый NDJSON-ответ собран в чате', r.last.indexOf('10×10×10') >= 0);
chk('AI: история диалога + флаг занятости сброшен', r.hist === 2 && r.busy === false && r.n >= 2);
const mb = run(`__mockAI.lastBody`);
chk('AI: POST /api/chat (model, system-контекст, stream, temp)', !!mb && mb.model === 'llama3.2' && mb.stream === true
  && mb.messages[0].role === 'system' && mb.messages[0].content.indexOf('Габариты') >= 0 && mb.options.temperature === 0.2);
{
  const p = run(`(() => {
    const u = document.getElementById('aiUrl'); u.value = 'http://nowhere.invalid';
    const inp = document.getElementById('aiInp'); inp.value = 'тест ошибки';
    return aiSend3().then(()=>{
      u.value = 'http://localhost:11434';
      const log = document.getElementById('aiLog');
      const k = log.children;
      return k[k.length-1] ? k[k.length-1].textContent : '';
    });
  })()`);
  const errTxt = await p;
  chk('AI: недоступный Ollama — ошибка показана в чате', String(errTxt).indexOf('Ошибка Ollama') >= 0);
}

console.log('== ⚡ query-язык (локально, без сети) ==');
run(`(() => { featList3 = []; faceCatalog3 = {}; boltGroups3 = []; })()`);   // сброс синтетики из теста фич
r = await run(`(async () => {
  return {
    dims: await qEval3('габариты'),
    help: await qEval3('помощь'),
    cnt: await qEval3('отверстия >8 count'),
    annos: await qEval3('аннотации'),
    vol: await qEval3('объём'),
    bad: await qEval3('что-то несусветное')
  };
})()`);
chk('query: габариты (куб 10 мм)', r.dims.indexOf('10.0') >= 0);
chk('query: помощь содержит команды и фильтр', r.help.indexOf('отверстия') >= 0 && r.help.indexOf('Фильтр') >= 0);
chk('query: «отверстия >8 count» → 0 шт. (куб без отверстий)', r.cnt.indexOf('0 шт.') >= 0 && r.cnt.indexOf('> 8') >= 0);
chk('query: аннотации (roundtrip «Тест»)', r.annos.indexOf('Тест') >= 0);
chk('query: объём STL (воксели/подсказка)', /мм³|воксел|анализ/i.test(r.vol));
chk('query: неизвестная команда — подсказка', r.bad.indexOf('помощь') >= 0);
{
  const chatsBefore = run(`__mockAI.chats`);
  run(`(() => { setAIMode3('query'); const inp = document.getElementById('aiInp'); inp.value = 'габариты'; aiSend3(); })()`);
  await run(`new Promise(res => setTimeout(res, 80))`);
  r = run(`(() => {
    const log = document.getElementById('aiLog');
    const k = log.children;
    return { last: k[k.length-1] ? k[k.length-1].textContent : '', chats: __mockAI.chats };
  })()`);
  chk('query: ответ в чате (локально)', r.last.indexOf('10.0') >= 0);
  chk('query: сеть не трогалась (mock /api/chat не вызван)', r.chats === chatsBefore);
}

console.log('== ↶/↷ undo-redo ==');
r = run(`(() => {
  undoStack3.length = 0; redoStack3.length = 0; undoCoalesce3 = null;
  applyRecolor3([-1], { h: '#00ff00', o: 1 });
  const s1 = undoStack3.length;
  undoCoalesce3 = null;
  undoPush3('transform'); stlTransform.x = 42; applyStlTransform();   // как в UI: «до» снимается до применения
  const s2 = undoStack3.length;
  undoDo3(-1);
  const u1 = { x: stlTransform.x, h: recolor3['-1'] ? recolor3['-1'].h : null };
  undoDo3(-1);
  const u2 = { h: recolor3['-1'] ? recolor3['-1'].h : null };
  undoDo3(1);
  const rd = { h: recolor3['-1'] ? recolor3['-1'].h : null };
  undoStack3.length = 0; undoCoalesce3 = null;
  applyRecolor3([-1], { h: '#111111', o: 1 });
  applyRecolor3([-1], { h: '#222222', o: 1 });
  applyRecolor3([-1], { h: '#333333', o: 1 });
  const co = undoStack3.length;
  undoDo3(-1);
  const after = recolor3['-1'] ? recolor3['-1'].h : null;
  return { s1, s2, u1, u2, rd, co, after };
})()`);
chk('снапшот после окраски', r.s1 === 1);
chk('снапшот после трансформы', r.s2 === 2);
chk('undo: x=0, цвет сохранён', r.u1.x === 0 && r.u1.h === '#00ff00');
chk('undo: цвет до undo-секции (#ff0000 из xray-теста)', r.u2.h === '#ff0000');
chk('redo: цвет вернулся', r.rd.h === '#00ff00');
chk('coalesce: серия окрасок = 1 снапшот', r.co === 1);
chk('undo серии: цвет до серии', r.after === '#00ff00');

console.log('== 🔎 фичи по вокселям (STL) ==');
{
  // тот же куб загружен (сплошной, без отверстий) → сквозных отверстий быть не должно
  const vp = run(`featFromVoxels3()`);
  const res = await vp;
  chk('фичи(воксели): сплошной куб → 0 сквозных отверстий', Array.isArray(res) && res.length === 0);
}

console.log('== 🧊 ViewCube + статус-бар (CAD) ==');
r = run(`(() => {
  let threw = null;
  try { drawViewCube3(); } catch(e) { threw = String(e); }
  const g = vcGeom3();
  const eyeLen = g ? g.eye.length() : -1;
  const faces = vcFaces3.length;
  camTheta3 = 0; camPhi3 = Math.PI/2; updateCamera3();
  const v1 = sbViewName3();
  camTheta3 = Math.PI/4; camPhi3 = Math.PI/3.2; updateCamera3();
  const v2 = sbViewName3();
  updateStatusBar3();
  sbCursor3(1.5, -2.25, 3.75, true);
  const el = (id) => document.getElementById(id).textContent;
  return { threw, eyeLen, faces, v1, v2, model: el('sbModel'), view: el('sbView'), zoom: el('sbZoom'), cur: el('sbCursor') };
})()`);
chk('ViewCube: отрисовка без ошибок (ctx2d-stub) + ≥1 видимой грани', r.threw === null && r.faces >= 1);
chk('ViewCube: eye-вектор единичной длины (сфера камеры)', Math.abs(r.eyeLen - 1) < 1e-9);
chk('имена видов: Спереди / Изометрия (канон. углы)', r.v1 === 'Спереди' && r.v2 === 'Изометрия');
chk('статус-бар: имя модели в sbModel', r.model.indexOf('cube.stl') >= 0);
chk('статус-бар: вид «Изометрия» после update', r.view === 'вид: Изометрия');
chk('статус-бар: зум в мм', /зум \d+ мм/.test(r.zoom));
chk('статус-бар: координаты курсора X 1.5 … мм', r.cur.indexOf('X 1.5') >= 0 && r.cur.indexOf('мм') >= 0);
r = run(`(() => { sbCursor3(0,0,0,false); return document.getElementById('sbCursor').textContent; })()`);
chk('статус-бар: курсор за моделью — поле чистое', r === '');

console.log('== ⛽🛢 Жидкость: капли с физикой (воксели, уровень воды) ==');
r = run(`(() => {
  // --- юнит: U-образная трубка 5×3×1 — мосток y=0 соединяет камеры, сверху «крышка»;
  // две капли (слева внизу и справа вверху), суммарно 6 вокселей
  const dx=5, dy=3, dz=1, dims=[dx,dy,dz];
  const g = new Uint8Array(dx*dy*dz).fill(1);   // стена; сверху «крышка» (j=2), между камерами выше мостка (2,1)
  for(let y=0;y<=1;y++){ g[y*dx+0]=0; g[y*dx+1]=0; g[y*dx+3]=0; g[y*dx+4]=0; }
  g[2]=0;
  const comp = fluidFlood3(g, dims, 0);
  const slotOf = new Map(); comp.forEach((idx,s)=>slotOf.set(idx,s));
  const levFull = fluidLevel3(dims, comp, fluidFallSlots3(dims, slotOf, [0]), 99);
  // капля 1: 5 вокселей слева внизу → ровно нижний ряд (обе камеры на одном уровне)
  const lev5 = fluidLevel3(dims, comp, fluidFallSlots3(dims, slotOf, [0]), 5);
  // капли 1+2: ещё 1 voxel сверху (вход в правой камере (4,1) = idx 9)
  const lev6 = fluidLevel3(dims, comp, fluidFallSlots3(dims, slotOf, [0, 9]), 6);
  const jOf = (idx)=> Math.floor(idx/dx) % dy;
  const tops = (fill)=>{ let L=-1,R=-1; for(let s=0;s<comp.length;s++){ if(!fill[s]) continue; const x=comp[s]%dx; if(x<=1) L=Math.max(L,jOf(comp[s])); else if(x>=3) R=Math.max(R,jOf(comp[s])); } return [L,R]; };
  const [t5L, t5R] = tops(lev5.fill);
  const [t6L, t6R] = tops(lev6.fill);
  // --- юнит: запечатанный вертикальный карман 3×3×3 — капля 2 вокселя, потом 100
  const d2=3, dims2=[d2,d2,d2];
  const g2 = new Uint8Array(d2*d2*d2).fill(1);
  g2[0]=0; g2[3]=0; g2[6]=0;
  const comp2 = fluidFlood3(g2, dims2, 0);
  const slotOf2 = new Map(); comp2.forEach((idx,s)=>slotOf2.set(idx,s));
  const lev2p = fluidLevel3(dims2, comp2, fluidFallSlots3(dims2, slotOf2, [0]), 2);
  const lev2f = fluidLevel3(dims2, comp2, fluidFallSlots3(dims2, slotOf2, [0]), 100);
  return { compLen: comp.length, fullCnt: levFull.cnt, t5L, t5R, c5: lev5.cnt,
           t6L, t6R, c6: lev6.cnt, compLen2: comp2.length, c2p: lev2p.cnt, lJ2p: lev2p.lJ, c2f: lev2f.cnt };
})()`);
chk('физика: U-трубка — полость 9 вокселей (мосток соединяет камеры)', r.compLen === 9);
chk('физика: объёма на 99 → залита вся полость (лишек отбрасывается)', r.fullCnt === 9);
chk('физика: 5 вокселей — ровно нижний ряд, уровень в обеих камерах ОДИНАКОВЫЙ', r.c5 === 5 && r.t5L === 0 && r.t5R === 0);
chk('физика: 6-й voxel поднялся только в одной камере (не выровнялся — мало жидкости)', r.c6 === 6 && ((r.t6L===1 && r.t6R===0) || (r.t6L===0 && r.t6R===1)));
chk('физика: карман — капля 2 вокселя: нижние два, lJ=1', r.compLen2 === 3 && r.c2p === 2 && r.lJ2p === 1);
chk('физика: карман — объём 100: заполнен целиком', r.c2f === 3);

console.log('--- жидкость: интеграция на модели (рой капель) ---');
// в тестовом DOM чекбоксы по умолчанию unchecked → applyThreeVisibility() прячет модель;
// возвращаем видимость (как в реальном HTML, где «Показать STL» отмечен) и сбрасываем кэш вокселей
run(`(() => { const cb = document.getElementById('showStlCb'); cb.checked = true; applyThreeVisibility(); voxCache3 = null; return stlMesh3.visible; })()`);
r = run(`(() => {
  try { if(xrayOn3) applyXray3(false); } catch(e){}
  setFluid3('fuel');
  return { pools: fluid3.pools.length, dropD: fluid3.dropD, xray: xrayOn3 };
})()`);
chk('рой: режим включён (0 пулов, капля 10 мм, рентген авто)', r.pools === 0 && r.dropD === 10 && r.xray === true);
// рой Ø6 мм над центром куба: V = π/6·216 ≈ 113 мм³ ≈ 0.113 см³, N = 4+6·2 = 16 капель
// rAF в тесте не срабатывает → физику двигаем вручную: 300 шагов по 16 мс ≈ 4.8 с симуляции
r = await run(`fluidSpawnBurst3(new THREE.Vector3(5,8,5), 6)`);
chk('рой 1: статус "ok" (получено: ' + String(r) + ')', r === 'ok');
r = run(`(() => {
  for(let i=0;i<300;i++) fluidStep3(0.016);
  fluidFlush3();
  const p = fluid3.pools[0];
  return { pools: fluid3.pools.length, flying: drops3.list.filter(d=>!d.frozen).length,
           listLen: drops3.list.length, drops: p ? p.drops.length : -1, cnt: p ? p.cnt : -1,
           vol: p ? p.vol : -1, full: p ? p.full : null, slots: p ? p.slots.length : -1,
           mesh: p && p.mesh ? p.mesh.parent === stlMesh3 : false };
})()`);
chk('рой 1: все 16 капель упали, осели и слились в пул (остатков нет)', r.pools === 1 && r.flying === 0 && r.listLen === 0 && r.drops === 16 && r.mesh);
chk('рой 1: залито (vol=' + r.vol.toFixed(3) + ' см³, cnt=' + r.cnt + ', full=' + r.full + ', slots=' + r.slots + ')', r.vol > 0.05 && r.vol < 0.2 && r.full === false && r.cnt > 0);
// рой Ø12 мм: V ≈ 905 мм³, N = 28 → итого > объёма полости куба (614 мм³) → full
r = await run(`fluidSpawnBurst3(new THREE.Vector3(5,7,5), 12)`);
r = run(`(() => {
  for(let i=0;i<300;i++) fluidStep3(0.016);
  fluidFlush3();
  const p = fluid3.pools[0];
  return { same: fluid3.pools.length === 1, drops: p.drops.length, full: p.full, cnt: p.cnt,
           slots: p.slots.length, vol: p.vol, listLen: drops3.list.length };
})()`);
chk('рой 2: тот же пул (связанная область), 44 капли, остатков нет', r.same && r.drops === 44 && r.listLen === 0);
chk('капли: суммарный объём > полость → заполнена целиком', r.full === true && r.cnt === r.slots);
// ОТВЕРСТИЕ: капля над открытым проёмом (v=2) пролетает наружу и улетает,
// соседняя оседает на дне — сетка 9×7×9: потолок j=6, пол j=0..1 с дырой в (4,4), полость j=2..5
r = run(`(() => {
  setFluid3('fuel');   // текущий тип fuel → переключить выкл
  setFluid3('fuel');   // заново
  fluidDropsEnsure3();
  const g = new Uint8Array(9*7*9);
  for(let k=0;k<9;k++) for(let j=0;j<7;j++) for(let i=0;i<9;i++){
    const idx=(k*7+j)*9+i;
    if(j===6){ g[idx]=1; continue; }
    if(j<2){ g[idx]=(i===4&&k===4)?2:1; continue; }
    g[idx]=(i===0||i===8||k===0||k===8)?1:0;
  }
  const body = { id:-1, h:1, dims:[9,7,9], mins:[0,0,0], grid:g,
                 box:new THREE.Box3(new THREE.Vector3(0,0,0), new THREE.Vector3(9,7,9)) };
  drops3.cache = { bodies:[body], token: fluid3.token || 1 };
  drops3.list.length = 0;
  drops3.list.push({ p:new THREE.Vector3(2.5,5.8,4.5), v:new THREE.Vector3(0,-20,0), r:1.0, vol:10, frozen:0, life:0, dead:0 });
  drops3.list.push({ p:new THREE.Vector3(4.5,5.8,4.5), v:new THREE.Vector3(0,-20,0), r:1.0, vol:10, frozen:0, life:0, dead:0 });
  for(let i=0;i<60;i++) fluidStep3(0.016);
  fluidFlush3();
  const p = fluid3.pools[0];
  return { pools: fluid3.pools.length, drops: p?p.drops.length:-1, vol: p?p.vol:-1,
           listLen: drops3.list.length };
})()`);
chk('отверстие: капля над проёмом улетела наружу (в пул попала только соседняя)', r.pools === 1 && r.drops === 1 && r.listLen === 0);
// 10 мм³ на дне 7×7 = мелкая лужа: voxel-приближение — часть нижнего слоя (10..49 ячеек)
chk('отверстие: соседняя капля осела на дно (vol=' + r.vol.toFixed(3) + ' см³)', r.vol >= 0.01 && r.vol < 0.05);
// переключение на масло — перекраска без пересимуляции
r = run(`(() => {
  setFluid3('oil');
  const t = fluid3.type, c = fluid3.pools[0].mesh.material.color.getHex();
  return { t, c, cnt: fluid3.pools[0].cnt };
})()`);
chk('рой: переключение на масло — перекраска, залитое сохранено', r.t === 'oil' && r.c === 0xd98a23 && r.cnt > 0);
// 🧹 убрать — кнопка (setFluid3(null)): все пулы сняты, рой капель убран из сцены
r = run(`(() => {
  setFluid3('oil');
  const off = fluid3 === null;
  const clean = !stlMesh3.children.find(o => o.userData && o.userData.isFluid3)
              && !scene3.children.find(o => o.userData && o.userData.isFluid3);
  return { off, clean };
})()`);
chk('рой: «убрать» — выкл, сцена чиста (mesh пулов и InstancedMesh капель удалены)', r.off && r.clean);
// freecam: F — рой из позиции камеры (Ø10 → N = 24, V = 523.6 мм³)
r = await (async () => {
  run(`(() => { enterSpectate3(); setFluid3('fuel'); spectatePos.set(5,5,5); return true; })()`);
  const st = await run(`fluidSpawnBurst3(spectatePos.clone(), fluid3.dropD)`);
  const post = run(`(() => { exitSpectate3(); for(let i=0;i<300;i++) fluidStep3(0.016); fluidFlush3();
                     const p = fluid3 && fluid3.pools[0];
                     return { pools: fluid3 ? fluid3.pools.length : -1, drops: p ? p.drops.length : -1, vol: p ? p.vol : -1 }; })()`);
  post.st = st;
  return post;
})();
chk('freecam: F — рой из позиции камеры слился в полость', r.st === 'ok' && r.pools === 1 && r.drops === 24 && r.vol > 0.05);
run(`(() => { setFluid3(null); return true; })()`);

console.log('== 🎮 Полёт: свободное вращение 6DOF (кватернион) ==');
r = run(`(() => {
  enterSpectate3();
  const inMode = spectateMode3;
  const rot = (axis, ang)=>{ spectateQuat.multiply(new THREE.Quaternion().setFromAxisAngle(axis, ang)).normalize(); };
  const V = (x,y,z)=> new THREE.Vector3(x,y,z);
  const dir = ()=>{ stepSpectate3(); camera3.updateMatrixWorld(); const d=new THREE.Vector3(); camera3.getWorldDirection(d); return d; };
  spectateQuat.identity();
  const d0 = dir();
  rot(V(1,0,0), 115*Math.PI/180);
  const d1 = dir();
  rot(V(1,0,0), 65*Math.PI/180);   // суммарно 180° — переворот через верх
  const d2 = dir();
  spectateQuat.identity();
  rot(V(1,0,0), -90*Math.PI/180);
  const d4 = dir();
  spectateQuat.identity();
  rot(V(0,1,0), 90*Math.PI/180);
  const d3 = dir();
  // WASD: при перевёрнутой камере E = «вверх по экрану» (локальный up), а не мировой Y
  spectateQuat.identity();
  rot(V(1,0,0), 180*Math.PI/180);  // камера перевёрнута
  const p0 = spectatePos.clone();
  const saved = Object.assign({}, spectateKeys);
  spectateKeys['KeyE'] = true;
  stepSpectate3();
  spectateKeys['KeyE'] = false;
  for(const k in saved) spectateKeys[k] = saved[k];
  const moved = spectatePos.clone().sub(p0);
  exitSpectate3();
  return { inMode, out: !spectateMode3,
           d0ok: Math.abs(d0.z + 1) < 1e-9,
           y1: d1.y, y1ok: Math.abs(d1.y - Math.sin(115*Math.PI/180)) < 1e-9,
           d2ok: Math.abs(d2.x) < 1e-9 && Math.abs(d2.y) < 1e-9 && Math.abs(d2.z - 1) < 1e-9,
           d4ok: Math.abs(d4.x) < 1e-9 && d4.y < -0.999 && Math.abs(d4.z) < 1e-9,
           d3ok: Math.abs(d3.x + 1) < 1e-9 && Math.abs(d3.z) < 1e-9,
           eUp: moved.y < -0.99 };   // перевёрнутый: E двигает вниз по миру (вверх по экрану)
})()`);
chk('полёт: вход/выход из режима', r.inMode && r.out);
chk('полёт: базовый взгляд (-Z)', r.d0ok);
chk('полёт: 115° вверх — взгляд за вертикаль (стопора нет)', r.y1ok);
chk('полёт: 180° — переворот через верх, смотрит горизонтально назад', r.d2ok);
chk('полёт: 90° вниз — вертикально вниз', r.d4ok);
chk('полёт: yaw 90° — вправо', r.d3ok);
chk('полёт: E — «вверх по экрану» даже при перевёрнутой камере', r.eUp);

console.log('');
if (alerts.length) console.log('ALERTS (не ожидались):', JSON.stringify(alerts, null, 1));
if (failures.length) { console.log('RESULT: ' + failures.length + ' FAIL'); process.exit(1); }
console.log('RESULT: ALL PASS');
process.exit(0);

