// E2E через CDP: грузим viewer с деревом тел, скрываем тело, проверяем состояние сцены.
const PORT = 9333;
const URL_ = process.argv[2] || 'http://127.0.0.1:4173/?model=770_1003014-10.stp';
const EXP_REL = process.argv[3] || '770_1003014-10.stp';
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function j(u){ const r = await fetch(u); return r.json(); }
function connect(wsUrl){
  const ws = new WebSocket(wsUrl);
  let id = 0; const pend = new Map();
  ws.onmessage = e => { const m = JSON.parse(e.data); if(m.id && pend.has(m.id)){ pend.get(m.id)(m); pend.delete(m.id); } };
  const send = (method, params={}) => new Promise(res => { const i=++id; pend.set(i,res); ws.send(JSON.stringify({id:i,method,params})); });
  return { ws, send };
}
async function evalJs(send, expr){
  const m = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
  if(m.result && m.result.exceptionDetails) throw new Error('page exc: '+JSON.stringify(m.result.exceptionDetails));
  return m.result && m.result.result ? m.result.result.value : undefined;
}
(async ()=>{
  const t0 = Date.now();
  let targets;
  for(let k=0;k<40;k++){ try{ targets = await j('http://127.0.0.1:'+PORT+'/json'); if(targets.some(t=>t.type==='page')) break; }catch(e){} await sleep(500); }
  const page = targets.find(t=>t.type==='page' && t.webSocketDebuggerUrl);
  if(!page) throw new Error('нет page target');
  const { ws, send } = connect(page.webSocketDebuggerUrl);
  await new Promise(r=>{ ws.onopen=r; });
  await send('Runtime.enable');
  await send('Page.navigate', { url: URL_ });
  // ждём именно ОЖИДАЕМУЮ модель (иначе автосохранение прошлой страницы пройдёт как ready)
  let ready=false;
  for(let k=0;k<400;k++){
    try{ const n = await evalJs(send, '(typeof stepBodies3!=="undefined" && typeof lastStepRel3!=="undefined" && lastStepRel3==='+JSON.stringify(EXP_REL)+' && lastModelPositions===null && stepBodies3.filter(b=>b._mesh).length) || 0'); if(n>=2){ ready=true; break; } }catch(e){}
    await sleep(500);
  }
  if(!ready) throw new Error('тела не построились за 200с');
  const info = await evalJs(send, `(()=>{
    const parts = stepBodies3.filter(b=>b._mesh);
    const st = document.getElementById('stepTreePanel');
    return { count: parts.length, panelShown: st.style.display!=='none',
      rows: document.querySelectorAll('#stepTreeList .stepTreeRow').length,
      tris: updateModelStats3 ? document.getElementById('threeStats').textContent : '' };
  })()`);
  console.log('LOAD OK', JSON.stringify(info), 'wall='+((Date.now()-t0)/1000)+'s');
  // скрыть 3-е тело: снять чекбокс и вызвать change (через карту — строки могут быть сгруппированы)
  const hide = await evalJs(send, `(()=>{
    const parts = stepBodies3.filter(b=>b._mesh); const b = parts[parts.length-1];
    const cb = stepRowCb3[b.id];
    cb.checked=false; cb.dispatchEvent(new Event('change'));
    return { id:b.id, visible:b._mesh.visible };
  })()`);
  console.log('HIDE', JSON.stringify(hide));
  if(hide.visible!==false) throw new Error('скрытие не сработало');
  // вернуть
  await evalJs(send, `(()=>{ const parts=stepBodies3.filter(b=>b._mesh); const b=parts[parts.length-1]; const cb=stepRowCb3[b.id]; cb.checked=true; cb.dispatchEvent(new Event('change')); return 1; })()`);
  // hover подсветка
  const hov = await evalJs(send, `(()=>{ const b=stepBodies3.filter(x=>x._mesh)[0]; hoverBody3(b.id); const e=b._mesh.material.emissive.getHex(); const row=stepRowEl3[b.id]; return { emis:e, hot: row.classList.contains('hot') }; })()`);
  console.log('HOVER', JSON.stringify(hov));
  if(hov.emis===0 || !hov.hot) throw new Error('hover не подсвечивает');
  const unhov = await evalJs(send, `(()=>{ unhoverBody3(); const b=stepBodies3.filter(x=>x._mesh)[0]; return { emis:b._mesh.material.emissive.getHex() }; })()`);
  if(unhov.emis!==0) throw new Error('unhover не сбросил эмиссию');
  // фокус камеры по телу
  await evalJs(send, `(()=>{ const b=stepBodies3.filter(x=>x._mesh)[0]; focusBody3(b); return camDist3>0; })()`);
  // каскад узла сборки: снять галку с узла → всё поддерево скрыто; вернуть (строка дерева, не XCAF-узел)
  const casc = await evalJs(send, `(()=>{
    const nr = stepTreeRows3.find(r=>r.kind==='node'); if(!nr) return {skip:true};
    const ncb = nr.el.querySelector('input');
    ncb.checked=false; ncb.dispatchEvent(new Event('change'));
    const visOff = stepBodies3.filter(b=>b._mesh).every(b=>!b._mesh.visible);
    const leafBoxesOff = stepTreeRows3.filter(r=>r.kind!=='node').every(r=>!r.el.querySelector('input').checked);
    ncb.checked=true; ncb.dispatchEvent(new Event('change'));
    const visOn = stepBodies3.filter(b=>b._mesh).every(b=>b._mesh.visible);
    return { visOff, leafBoxesOff, visOn };
  })()`);
  console.log('CASCADE', JSON.stringify(casc));
  if(!casc.skip && !(casc.visOff && casc.leafBoxesOff && casc.visOn)) throw new Error('каскад узла не работает');
  // клик по строке узла — фокус поддерева без исключений
  await evalJs(send, `(()=>{ const node=stepBodies3.find(b=>!b._mesh); if(node) focusSubtree3(node); return camDist3>0; })()`);
  // NAMES: именование тел по product map (для asm — почти все, для мелких — по возможности)
  const names = await evalJs(send, `(()=>{
    const parts = stepBodies3.filter(b=>b._mesh);
    const named = parts.filter(b=>b.part);
    const uniq = new Set(named.map(b=>b.part)).size;
    const head = named.find(b=>b.part && b.part.indexOf('1003014')>=0);
    return { total: parts.length, named: named.length, uniq, head: !!head };
  })()`);
  console.log('NAMES', JSON.stringify(names));
  if(names.named < Math.max(1, names.total*0.5)) throw new Error('product map не именовала тела: '+JSON.stringify(names));
  if(EXP_REL.indexOf('asm')>=0 && !names.head) throw new Error('головка 770_1003014 не именована');
  // GROUPS: бейджи ×N на группах одинаковых деталей (актуально для asm)
  const groups = await evalJs(send, `(()=>{
    const badges = [...document.querySelectorAll('#stepTreeList .stepTreeBadge')].map(x=>x.textContent);
    const rows = document.querySelectorAll('#stepTreeList .stepTreeRow').length;
    return { badges: badges.length, maxN: badges.reduce((m,x)=>Math.max(m, parseInt(x.slice(1),10)||0), 0), rows };
  })()`);
  console.log('GROUPS', JSON.stringify(groups));
  if(names.total > 50 && groups.badges < 3) throw new Error('нет групп одинаковых деталей');
  if(names.total > 50 && groups.rows >= names.total) throw new Error('строки не склеены в группы');
  // TREE: настоящая NAUO-иерархия (для asm), сворачивание узлов
  const tree = await evalJs(send, `(()=>{
    if(!stepTree3) return { legacy: true };
    const nodeRows = stepTreeRows3.filter(r=>r.kind==='node');
    const root = nodeRows[0];
    const depths = new Set(stepTreeRows3.map(r=>parseInt(r.el.style.paddingLeft,10)||0));
    // сворачивание: найти непустой узел не-корень и щёлкнуть fold
    const foldRow = nodeRows.find(r=>r.el.querySelector('.stepTreeFold') && r.sub.length>0 && r.sub.length<${names.total});
    let folded=false, back=false;
    if(foldRow){
      const before = stepTreeRows3.length;
      foldRow.el.querySelector('.stepTreeFold').dispatchEvent(new MouseEvent('click',{bubbles:true}));
      const after = stepTreeRows3.length;
      folded = after < before;
      const fr = stepTreeRows3.find(r=>r.kind==='node' && r.name===foldRow.name);
      fr.el.querySelector('.stepTreeFold').dispatchEvent(new MouseEvent('click',{bubbles:true}));
      back = stepTreeRows3.length === before;
    }
    return { legacy:false, nodes: nodeRows.length, rootSub: root?root.sub.length:0, levels: depths.size, folded, back };
  })()`);
  console.log('TREE', JSON.stringify(tree));
  if(!tree.legacy){
    const big = EXP_REL.indexOf('asm')>=0;
    if(tree.nodes < (big ? 40 : 1)) throw new Error('мало узлов дерева: '+tree.nodes);
    if(tree.rootSub !== names.total) throw new Error('корень не покрывает все тела: '+JSON.stringify(tree));
    if(big){
      if(tree.levels < 3) throw new Error('нет вложенности (глубина < 3): '+JSON.stringify(tree));
      if(!tree.folded || !tree.back) throw new Error('сворачивание узлов не работает: '+JSON.stringify(tree));
    }
  }
  // ISOLATE: изоляция группы и возврат
  const iso = await evalJs(send, `(()=>{
    const r = stepTreeRows3.filter(x=>x.kind!=='node').sort((a,b)=>b.ids.length-a.ids.length)[0];
    isolateTo3(r.ids.slice(), r.name);
    const vis = stepBodies3.filter(b=>b._mesh && b._mesh.visible).map(b=>b.id).sort((a,b)=>a-b);
    const chip = document.getElementById('isolateChip3').style.display;
    const okVis = JSON.stringify(vis)===JSON.stringify(r.ids.slice().sort((a,b)=>a-b));
    const cbOff = stepTreeRows3.filter(x=>x.kind!=='node' && x!==r).every(x=>!x.el.querySelector('input').checked);
    unisolate3();
    const allBack = stepBodies3.filter(b=>b._mesh).every(b=>b._mesh.visible);
    const chipOff = document.getElementById('isolateChip3').style.display==='none';
    return { n: r.ids.length, okVis, chip, cbOff, allBack, chipOff };
  })()`);
  console.log('ISOLATE', JSON.stringify(iso));
  if(!(iso.okVis && iso.chip==='block' && iso.cbOff && iso.allBack && iso.chipOff)) throw new Error('изоляция не работает: '+JSON.stringify(iso));
  // SEARCH: фильтр по подстроке
  const search = await evalJs(send, `(()=>{
    const si = document.getElementById('stepTreeSearch');
    const wrapShown = getComputedStyle(document.getElementById('sbSearchWrap')).display;
    const total = stepTreeRows3.length;
    si.value='780'; si.dispatchEvent(new Event('input'));
    const vis = stepTreeRows3.filter(r=>r.el.style.display!=='none').length;
    const hitBodies = stepTreeRows3.filter(r=>!r.node && r.el.style.display!=='none').reduce((s,r)=>s+r.ids.length,0);
    si.value=''; si.dispatchEvent(new Event('input'));
    const back = stepTreeRows3.every(r=>r.el.style.display!=='none');
    return { wrapShown, total, vis, hitBodies, back };
  })()`);
  console.log('SEARCH', JSON.stringify(search));
  if(names.total > 7 && search.wrapShown==='none') throw new Error('строка поиска не показана');
  if(search.wrapShown!=='none' && (search.vis >= search.total || search.hitBodies===0 || !search.back)) throw new Error('поиск не фильтрует: '+JSON.stringify(search));
  // CLIP: включение сечения на STEP-группе + slab (вторая плоскость)
  const clip = await evalJs(send, `(()=>{
    const cb = document.getElementById('clipEnableCb');
    cb.checked = true; cb.dispatchEvent(new Event('change'));
    const pos = document.getElementById('clipPos');
    pos.value = '30'; pos.dispatchEvent(new Event('input'));
    const mats = modelMaterials3();
    const clipped = mats.filter(m=>m.clippingPlanes && m.clippingPlanes.length>0).length;
    const p1 = mats[0].clippingPlanes.length;
    const p2 = document.getElementById('clipPos2');
    p2.value = '15'; p2.dispatchEvent(new Event('input'));
    const slabN = modelMaterials3()[0].clippingPlanes.length;
    const st = { enabled: clipState3.enabled, axis: clipState3.axis, pos: clipState3.pos, pos2: clipState3.pos2 };
    p2.value='0'; p2.dispatchEvent(new Event('input'));
    const back1 = modelMaterials3()[0].clippingPlanes.length;
    cb.checked = false; cb.dispatchEvent(new Event('change'));
    const cleared = modelMaterials3().every(m=>!m.clippingPlanes || !m.clippingPlanes.length);
    return { st, mats: mats.length, clipped, p1, slabN, back1, cleared };
  })()`);
  console.log('CLIP', JSON.stringify(clip));
  if(!clip.st.enabled || clip.clipped === 0) throw new Error('сечение не применяется к STEP: '+JSON.stringify(clip));
  if(clip.p1 !== 1 || clip.slabN !== 2 || clip.back1 !== 1) throw new Error('slab-плоскости не переключаются: '+JSON.stringify(clip));
  if(!clip.cleared) throw new Error('сечение не снялось');
  // EXPLODE: разнесение 60% → тела разъезжаются, 0% → на место
  const exp = await evalJs(send, `(()=>{
    const parts = stepBodies3.filter(b=>b._mesh);
    const se = document.getElementById('sbExplode');
    const ewShown = getComputedStyle(document.getElementById('sbExplWrap')).display;
    se.value='60'; se.dispatchEvent(new Event('input'));
    const offs = parts.map(b=>Math.round(b._mesh.position.length()));
    se.value='0'; se.dispatchEvent(new Event('input'));
    const zero = parts.every(b=>b._mesh.position.length()<1e-9);
    return { ewShown, offs, zero };
  })()`);
  console.log('EXPLODE', JSON.stringify(exp));
  if(exp.ewShown==='none' && exp.offs.length>1) throw new Error('слайдер explode не показан при 2+ телах');
  if(exp.offs.length>1 && !(exp.offs.some(o=>o>0) && exp.zero)) throw new Error('разнесение не работает');
  // COMPASS: нарисован, 6 кликабельных точек, клик по фронтовой оси меняет углы камеры
  const comp = await evalJs(send, `(()=>{
    drawCompass3();
    const pts = compassPts3.filter(p=>p.front);
    const p0 = pts[0];
    const before = { th:camTheta3, ph:camPhi3 };
    compassPick3(p0.px, p0.py);
    const after = { th:camTheta3, ph:camPhi3 };
    const moved = Math.abs(after.th-before.th)+Math.abs(after.ph-before.ph) > 1e-6 || pts.length<2;
    return { total: compassPts3.length, front: pts.length, moved };
  })()`);
  console.log('COMPASS', JSON.stringify(comp));
  if(comp.total!==6) throw new Error('компас: ожидалось 6 точек');
  if(!comp.moved) throw new Error('клик компаса не поворачивает камеру');
  // колесо видов: клик кнопке «Сверху» (data-v=4)
  const wheel = await evalJs(send, `(()=>{
    const b = document.querySelector('#viewWheel .vw[data-v="4"]'); b.click();
    return { phi: +camPhi3.toFixed(4), label: b.title };
  })()`);
  console.log('WHEEL', JSON.stringify(wheel));
  if(wheel.phi > 0.1) throw new Error('кнопка «Сверху» не применилась: '+JSON.stringify(wheel));
  // скрытые meta-поля
  const meta2 = await evalJs(send, `(()=>{ const m=currentModelMeta(); return { explode: m.explode, rel: m.bodiesRel }; })()`);
  console.log('META2', JSON.stringify(meta2));
  // проверка, что автосохранился meta с bodiesRel
  await sleep(1500);
  const meta = await evalJs(send, `currentModelMeta().bodiesRel`);
  console.log('META bodiesRel =', meta);
  if(meta!==EXP_REL) throw new Error('meta.bodiesRel не сохранился: '+meta);
  // SHELL v3: рейка + панели
  const shell = await evalJs(send, `(()=>{
    const rails = document.querySelectorAll('#rail2 .railBtn').length;
    __openPanel2('apClip'); const o1 = panelOpen2('apClip');
    __openPanel2('apClip'); const o2 = panelOpen2('apClip');   // повторный клик — закрыть
    __openPanel2('apAppearance'); const ex = !panelOpen2('apClip') && panelOpen2('apAppearance');
    const dock = !!document.querySelector('header .header-top #stlUploadBtn');
    closeAllPanels2(); syncRail2();
    const railOn = [...document.querySelectorAll('#rail2 .railBtn[data-p^="ap"]')].some(b=>b.classList.contains('on'));
    const treeOn = document.getElementById('railTreeBtn').classList.contains('on');   // дерево открыто с STEP — ок
    return { rails, o1, o2: !o2, ex, dock, railOn: !railOn, treeOn };
  })()`);
  console.log('SHELL', JSON.stringify(shell));
  if(!(shell.rails>=6 && shell.o1 && shell.o2 && shell.ex && shell.dock && shell.railOn && shell.treeOn)) throw new Error('оболочка v3: '+JSON.stringify(shell));
  // RECOLOR: окраска тела, meta, сброс
  const rec = await evalJs(send, `(()=>{
    const b = stepBodies3.filter(x=>x._mesh)[0];
    const before = b._mesh.material.color.getHexString();
    applyRecolor3([b.id], {h:'#e11d48', o:1});
    const after = b._mesh.material.color.getHexString();
    const inMeta = (currentModelMeta().recolor3||{})[b.id];
    const dot = stepRowEl3[b.id].querySelector('.stepTreePc');
    const hot = !!dot && dot.classList.contains('has');
    applyRecolor3([b.id], null);
    const back = b._mesh.material.color.getHexString();
    const gone = !currentModelMeta().recolor3[b.id];
    return { before, after, back, inMeta: inMeta && inMeta.h, hot, gone };
  })()`);
  console.log('RECOLOR', JSON.stringify(rec));
  if(!(rec.after==='e11d48' && rec.back===rec.before && rec.inMeta==='#e11d48' && rec.hot && rec.gone)) throw new Error('окраска не работает: '+JSON.stringify(rec));
  // MENU: открытие/позиция/закрытие Esc
  const menu = await evalJs(send, `(()=>{
    const b = stepBodies3.filter(x=>x._mesh)[1] || stepBodies3.filter(x=>x._mesh)[0];
    openBodyMenu3At(300, 300, [b.id], b.part||'тест');
    const m = document.getElementById('bodyMenu3');
    const o = m.classList.contains('open');
    const inC = m.offsetLeft >= 0 && m.offsetTop >= 0;
    window.dispatchEvent(new KeyboardEvent('keydown', {key:'Escape', bubbles:true}));
    const c = !m.classList.contains('open');
    return { o, inC, c };
  })()`);
  console.log('MENU', JSON.stringify(menu));
  if(!(menu.o && menu.inC && menu.c)) throw new Error('меню окраски: '+JSON.stringify(menu));
  // COMPACT: переключение + meta
  const cmp = await evalJs(send, `(()=>{
    document.body.classList.add('compact2');
    const m = !!currentModelMeta().compact2;
    document.body.classList.remove('compact2');
    return { m, hid: getComputedStyle(document.getElementById('rail2')).opacity };
  })()`);
  console.log('COMPACT', JSON.stringify(cmp));
  if(!cmp.m) throw new Error('compact2 не в meta');
  // BOX: бокс-сечение (плоскости + регресс slab + meta)
  const box = await evalJs(send, `(()=>{
    clipState3.enabled=true; clipState3.mode='box'; clipState3.box.x=[0,0.5]; clipState3.box.y=[0.5,1]; clipState3.box.z=[0,1]; clipState3.box.on={x:true,y:true,z:true};
    applyStlClipping(); const nb = modelMaterials3()[0].clippingPlanes.length;
    clipState3.mode='slab'; clipState3.pos=0.4; clipState3.pos2=0; applyStlClipping(); const s1 = modelMaterials3()[0].clippingPlanes.length;
    clipState3.pos2=0.2; applyStlClipping(); const s2 = modelMaterials3()[0].clippingPlanes.length;
    const inMeta = !!(currentModelMeta().clip && currentModelMeta().clip.box);
    clipState3.enabled=false; clipState3.pos2=0; applyStlClipping();
    return { nb, s1, s2, inMeta };
  })()`);
  console.log('BOX', JSON.stringify(box));
  if(!(box.nb===2 && box.s1===1 && box.s2===2 && box.inMeta)) throw new Error('бокс-сечение: '+JSON.stringify(box));
  // VIEWS: ракурс сохранился/применился/в meta
  const vws = await evalJs(send, `(()=>{
    const n0 = views3.length;
    document.getElementById('viewNameInput').value='E2E'; document.getElementById('captureViewBtn').click();
    const v = views3[views3.length-1];
    flyToCam3({tx:5,ty:6,tz:7,dist:3000,theta:0.5,phi:1.1});
    const okMeta = (currentModelMeta().views3||[]).some(x=>x.name==='E2E');
    return { added: views3.length===n0+1, thumb: !!(v&&v.thumb&&v.thumb.length>1500), okMeta };
  })()`);
  console.log('VIEWS', JSON.stringify(vws));
  if(!(vws.added && vws.thumb && vws.okMeta)) throw new Error('ракурсы: '+JSON.stringify(vws));
  // MEASURE: два клика по телам → замер, в meta, очистка
  const msr = await evalJs(send, `(()=>{
    setMeasureMode3(true);
    const rect = renderer3.domElement.getBoundingClientRect();
    const scr = v => { const p=v.clone().project(camera3); return [rect.left+(p.x*.5+.5)*rect.width, rect.top+(-p.y*.5+.5)*rect.height]; };
    const vis = stepBodies3.filter(b=>b._mesh && b._mesh.visible);
    const bb = new THREE.Box3().setFromObject(vis[0]._mesh);
    const A = scr(bb.getCenter(new THREE.Vector3()));
    const ra = measurePick3(A[0], A[1]);
    if(!ra) return { pend:false, created:false, inMeta:false, why:'нет хита в центр' };
    // вторая точка — сеткой вокруг, иначе на перекрывающихся телах попадание совпадёт
    let B = null, rb = null;
    for(let dx=-240; dx<=240 && !B; dx+=60) for(let dy=-180; dy<=180 && !B; dy+=45){
      const q = [A[0]+dx, A[1]+dy];
      if(q[0]<rect.left+5||q[0]>rect.right-5||q[1]<rect.top+5||q[1]>rect.bottom-5) continue;
      const r = measurePick3(q[0], q[1]);
      if(r && r.point.distanceTo(ra.point) > 5){ B = q; rb = r; }
    }
    if(!B) return { pend:false, created:false, inMeta:false, why:'не найдена вторая точка' };
    measureClick3(A[0],A[1]); const pend = !!measurePending3;
    measureClick3(B[0],B[1]);
    const m = measures3[measures3.length-1];
    const dist = m ? new THREE.Vector3(...m.a).distanceTo(new THREE.Vector3(...m.b)) : 0;
    const inMeta = (currentModelMeta().measures3||[]).length > 0;
    resetMeasureState3(); setMeasureMode3(false);
    return { pend, created: !!m && dist>1, inMeta };
  })()`);
  console.log('MEASURE', JSON.stringify(msr));
  if(!(msr.pend && msr.created && msr.inMeta)) throw new Error('замеры: '+JSON.stringify(msr));
  // SNAPS: магнит к нулевой точке + к привязкам манифеста + маркеры
  const snp = await evalJs(send, `(()=>{
    const b = stepBodies3.find(x=>x._mesh);
    const c = new THREE.Box3().setFromObject(b._mesh).getCenter(new THREE.Vector3());
    setZeroPoint3({x:c.x, y:c.y+1, z:c.z}, 'e2e');   // мир three
    const rect = renderer3.domElement.getBoundingClientRect();
    const p = new THREE.Vector3(c.x, c.y+1, c.z).project(camera3);
    const cx = rect.left+(p.x*.5+.5)*rect.width, cy = rect.top+(-p.y*.5+.5)*rect.height;
    const s = nearestSnap3(cx, cy, toLocal3(new THREE.Vector3(c.x,c.y,c.z)));
    // магнит к манифест-привязке: проекция снапа, клик рядом должен притянуться именно к нему
    let probe = null;
    for(let i=0; i<snaps3.length && !probe; i+=11){
      const sp = snaps3[i];
      const v = sp.p.clone(); if(stlMesh3) stlMesh3.localToWorld(v); v.project(camera3);
      if(v.z>1) continue;
      const px = rect.left+(v.x*.5+.5)*rect.width, py = rect.top+(-v.y*.5+.5)*rect.height;
      const r = measurePick3(px, py);
      if(r && r.snapped) probe = { kind:r.snapped, exact: snaps3.some(q=>r.point.distanceTo(q.p) < 1e-6) };
    }
    let mk = 0;
    try{ const cb=document.getElementById('snapShowCb'); cb.checked=true; toggleSnapMarkers3(true); mk = snapMarkersGrp3? snapMarkersGrp3.children.length : 0; cb.checked=false; toggleSnapMarkers3(false); }catch(e){}
    clearZeroPoint3();
    return { zeroSnap: !!s, cnt: snaps3.length, probe, mk };
  })()`);
  console.log('SNAPS', JSON.stringify(snp));
  if(!snp.zeroSnap) throw new Error('магнит не притянулся к нулевой точке');
  if(snp.cnt > 0){
    if(!snp.probe || !snp.probe.exact) throw new Error('магнит к манифест-привязке не сработал: '+JSON.stringify(snp.probe));
    if(snp.mk < 10) throw new Error('маркеры привязок не построены: '+snp.mk);
    console.log('SNAPS: v4 — привязок', snp.cnt, 'магнит', snp.probe.kind, 'маркеров', snp.mk);
  } else console.log('SNAPS: манифест v3 (без привязок) — допустимо');
  // MASS: объёмы/ЦТ, панель, плотность тела, ЦТ-маркер
  const mss = await evalJs(send, `(()=>{
    renderMassList3(); updateMassCg3();
    const T = massTotals3();
    const rows = document.querySelectorAll('#massList .massRow').length;
    const withVol = stepBodies3.filter(b=>b.vol && b.cm).length;
    const cgShown = !!(massCgGroup3 && massCgGroup3.children.length>0);
    const b0 = stepBodies3.filter(b=>b.vol).sort((a,b)=>b.vol-a.vol)[0];
    delete dens3[b0.id]; const T0 = massTotals3();
    dens3[b0.id] = 1.23; const g2 = massTotals3().g; delete dens3[b0.id]; renderMassList3();
    const densWorks = Math.abs(g2 - T0.g) > T0.g*0.05 && T.g > 0;
    // ЦТ обязан попадать в bbox своего тела (составная ЦТ сборки — в общий)
    let cmOk = 0, cmBad = 0;
    for(const b of stepBodies3){ if(!b.vol||!b.cm||!b._mesh) continue;
      const bb = new THREE.Box3().setFromObject(b._mesh);
      const p = new THREE.Vector3(b.cm[0], b.cm[2], b.cm[1]);
      if(bb.containsPoint(p)) cmOk++; else cmBad++; }
    return { withVol, rows, kg: +(T.g/1000).toFixed(3), cgShown, densWorks, cmOk, cmBad };
  })()`);
  console.log('MASS', JSON.stringify(mss));
  if(mss.withVol < 1 || mss.rows < 1) throw new Error('нет данных v5 о массе (нужен манифест v5)');
  if(!(mss.kg > 0)) throw new Error('масса сборки нулевая');
  if(!mss.densWorks) throw new Error('индивидуальная плотность не влияет на массу');
  if(mss.cmBad > 0) throw new Error('ЦТ вне bbox тел: '+mss.cmBad);
  if(!mss.cgShown) throw new Error('маркер ЦТ сборки не построен');
  // FACE: одиночная грань + пара P+P того же тела
  const fac = await evalJs(send, `(()=>{
    resetMeasureState3(); setFaceMode3(true);
    const rect = renderer3.domElement.getBoundingClientRect();
    const scr = v => { const p=v.clone().project(camera3); return [rect.left+(p.x*.5+.5)*rect.width, rect.top+(-p.y*.5+.5)*rect.height]; };
    const cand = Object.entries(faceCatalog3).map(([bid,fs])=>({bid:+bid, p:fs.filter(f=>f.t==='P').length}))
      .filter(x=>x.p>=3).sort((a,b)=>b.p-a.p).slice(0,6);
    let oneTxt=null, pairTxt=null, nC=0, nP=0;
    for(const key of Object.keys(faceCatalog3)) for(const f of faceCatalog3[key]){ if(f.t==='C')nC++; else if(f.t==='P')nP++; }
    for(const c of cand){
      const b = stepBodies3.find(x=>x.id===c.bid); if(!b || !b._mesh) continue;
      const ctr = scr(new THREE.Box3().setFromObject(b._mesh).getCenter(new THREE.Vector3()));
      let pxA=null, fA=null;
      for(let dx=-140; dx<=140 && !pxA; dx+=10) for(let dy=-100; dy<=100 && !pxA; dy+=10){
        const rr=measurePick3(ctr[0]+dx, ctr[1]+dy); if(!rr||rr.bid!==c.bid) continue;
        const ff=matchFace3(rr.bid, rr.point); if(ff&&ff.t==='P'){ pxA=[ctr[0]+dx,ctr[1]+dy]; fA=ff; }
      }
      if(!pxA) continue;
      faceClick3(pxA[0],pxA[1]);
      oneTxt = probes3.length===1 && String(probes3[0].txt).indexOf('①')===0 ? probes3[0].txt : null;
      let pxB=null;
      for(let dx=-140; dx<=140 && !pxB; dx+=10) for(let dy=-100; dy<=100 && !pxB; dy+=10){
        const rr=measurePick3(ctr[0]+dx, ctr[1]+dy); if(!rr||rr.bid!==c.bid) continue;
        const ff=matchFace3(rr.bid, rr.point); if(ff&&ff.t==='P'&&ff!==fA){ pxB=[ctr[0]+dx,ctr[1]+dy]; }
      }
      if(!pxB) continue;
      faceClick3(pxB[0],pxB[1]);
      const last = probes3[probes3.length-1];
      if(probes3.length===2 && last && String(last.txt).indexOf('①')!==0) pairTxt = last.txt;
      break;
    }
    const inMeta = (currentModelMeta().probes3||[]).length===2;
    resetMeasureState3();
    return { nC, nP, one:!!oneTxt, oneTxt: oneTxt && oneTxt.slice(0,50), pair:!!pairTxt, pairTxt: pairTxt && pairTxt.slice(0,60), inMeta };
  })()`);
  console.log('FACE', JSON.stringify(fac));
  if(fac.nC + fac.nP < 20) throw new Error('каталог граней v5 пуст — нужен STEP-разбор v5');
  if(!fac.one) throw new Error('одиночный клик по грани не дал ①-замер');
  if(!fac.pair) throw new Error('пара граней не дала совместный замер: '+JSON.stringify(fac));
  if(!fac.inMeta) throw new Error('probes3 не попадают в meta автосохранения');
  // LIGHT: ползунки + перетаскивание солнца
  const lit = await evalJs(send, `(()=>{
    const out = {};
    closeAllPanels2();
    out.handleVisible = !!(sunHandle3 && sunHandle3.visible);
    const d0 = light3.dir.slice();
    const baseAmb = ambLight3.intensity, baseHead = headLight3.intensity;
    const h=document.getElementById('ltHead'); h.value='60'; h.dispatchEvent(new Event('input',{bubbles:true}));
    out.headUp = Math.abs(headLight3.intensity - 0.72) < 1e-6;
    const a=document.getElementById('ltAmb'); a.value='100'; a.dispatchEvent(new Event('input',{bubbles:true}));
    out.ambUp = ambLight3.intensity > baseAmb + 0.5;
    h.value='30'; h.dispatchEvent(new Event('input',{bubbles:true}));
    a.value='20'; a.dispatchEvent(new Event('input',{bubbles:true}));
    out.headBack = Math.abs(headLight3.intensity - baseHead) < 1e-6 && Math.abs(ambLight3.intensity-baseAmb)<1e-6;
    const pr = projectSunScreen3();
    if(!pr) return Object.assign(out, { drag:false, why:'ручка не видна' });
    // смещение — на 55% к экранному центру модели: луч гарантированно пересекает сферу-орбиту
    const cV = sunCenter3().project(camera3);
    const rect = renderer3.domElement.getBoundingClientRect();
    const ctr = [ rect.left+(cV.x*.5+.5)*rect.width, rect.top+(-cV.y*.5+.5)*rect.height ];
    const to = [ pr[0]+(ctr[0]-pr[0])*0.55, pr[1]+(ctr[1]-pr[1])*0.55 ];
    const dom = renderer3.domElement;
    dom.dispatchEvent(new MouseEvent('mousedown', { clientX:pr[0], clientY:pr[1], button:0, bubbles:true }));
    window.dispatchEvent(new MouseEvent('mousemove', { clientX:to[0], clientY:to[1], bubbles:true }));
    window.dispatchEvent(new MouseEvent('mouseup',   { clientX:to[0], clientY:to[1], bubbles:true }));
    const d1 = light3.dir.slice();
    const moved = Math.hypot(d1[0]-d0[0], d1[1]-d0[1], d1[2]-d0[2]) > 0.05;
    const dv = new THREE.Vector3(d1[0],d1[1],d1[2]).normalize();
    const kv = keyLight3.position.clone().sub(sunFitC3).normalize();
    out.drag = moved && dv.dot(kv) > 0.995;
    out.dragMoved = moved; out.keyAlign = +dv.dot(kv).toFixed(4);
    const mL = currentModelMeta().light3 || {};
    out.meta = !!(mL.dir && Math.hypot(mL.dir[0]-d1[0], mL.dir[1]-d1[1], mL.dir[2]-d1[2]) < 1e-9 && typeof mL.head==='number');
    document.getElementById('ltResetBtn').click();
    out.resetBack = Math.abs(light3.dir[0]-0.6)<1e-6 && Math.abs(light3.head-0.3)<1e-9;
    const sc=document.getElementById('ltSunCb'); sc.checked=false; sc.dispatchEvent(new Event('change',{bubbles:true}));
    const hid = !sunHandle3.visible;
    sc.checked=true; sc.dispatchEvent(new Event('change',{bubbles:true}));
    out.cbWorks = hid && sunHandle3.visible;
    return out;
  })()`);
  console.log('LIGHT', JSON.stringify(lit));
  if(!lit.handleVisible) throw new Error('ручка солнца не видна при загруженной модели');
  if(!lit.headUp || !lit.ambUp || !lit.headBack) throw new Error('ползунки света не работают: '+JSON.stringify(lit));
  if(!lit.drag) throw new Error('перетаскивание солнца не повернуло свет: '+JSON.stringify(lit));
  if(!lit.meta) throw new Error('light3 не в meta автосохранения');
  if(!lit.resetBack) throw new Error('сброс света не вернул дефолты');
  if(!lit.cbWorks) throw new Error('чекбокс ручки солнца не работает');
  // ---- 🧪 волна 9: BOLT / CLASH / THICK / SHEET ----
  const bo = await evalJs(send, `(()=>{
    const g = boltRun3();
    const holes = g.filter(x=>x.kind==='hole'), pins = g.filter(x=>x.kind==='pin');
    const nh = holes.reduce((s,x)=>s+x.n,0), np = pins.reduce((s,x)=>s+x.n,0);
    const ringIdx = holes.length ? g.indexOf(holes.reduce((a,b)=>a.n>b.n?a:b)) : 0;
    showBoltRings3(ringIdx);
    const ringKids = boltRingGrp3 ? boltRingGrp3.children.length : 0;
    const kidsOk = ringKids === g[ringIdx].n + (g[ringIdx].bc?1:0);
    document.getElementById('boltHideBtn').click();
    const hidden = boltRingGrp3 && !boltRingGrp3.visible;
    return { ok: !!g.length && nh>=1 && np>=1 && kidsOk && !!hidden, nh, np, groups:g.length, ringKids,
             top: g.slice(0,3).map(x=>x.kind+' ⌀'+x.d+'×'+x.n+(x.metric?' '+x.metric:'')) };
  })()`);
  console.log('BOLT', JSON.stringify(bo));
  if(!bo.ok) throw new Error('болт-анализ: '+JSON.stringify(bo));
  const cl = await evalJs(send, `(async()=>{
    // синтетическая интерференция: вонзаем тестовый куб 30мм в материал главного тела
    const bs = stepBodies3.filter(b=>b._mesh && b.vol);
    if(!bs.length) return { ok:false, why:'novol' };
    let big=bs[0]; for(const b of bs){ if(b.vol>big.vol) big=b; }
    voxCache3=null;
    const c = await buildVoxels3();
    const vb = c.bodies.find(v=>v.id===big.id);
    if(!vb || vb.insideCnt<50) return { ok:false, why:'nobiginterior', inside: vb?vb.insideCnt:0 };
    let cell=null, cellScore=-1;
    {
      const [DX,DY,DZ]=vb.dims;
      for(let k=1;k<DZ-1;k++) for(let j=1;j<DY-1;j++) for(let i=1;i<DX-1;i++){
        if(vb.grid[(k*DY+j)*DX+i]!==0) continue;
        const score=Math.min(i,DX-1-i,j,DY-1-j,k,DZ-1-k);
        if(score>cellScore){ cellScore=score; cell=[vb.mins[0]+(i+.5)*vb.h, vb.mins[1]+(j+.5)*vb.h, vb.mins[2]+(k+.5)*vb.h]; }
      }
    }
    if(!cell || cellScore<3) return { ok:false, why:'nocell', score:cellScore };
    const fake=new THREE.Mesh(new THREE.BoxGeometry(30,30,30), new THREE.MeshBasicMaterial({visible:false}));
    fake.position.set(cell[0],cell[1],cell[2]);
    stlMesh3.add(fake); fake.updateMatrix(); fake.updateWorldMatrix(true,false);
    const fb={ id:9999001, name:'e2e-box-30', vol:27000, _mesh:fake };
    stepBodies3.push(fb);
    const pairs = await clashRun3();
    const mine = pairs.find(p=> (p.a.id===9999001||p.b.id===9999001));
    const rows = document.querySelectorAll('#clashList .anaRow').length;
    const inst = (clashGrp3 && clashGrp3.children[0]) ? clashGrp3.children[0].count : 0;
    const t1=performance.now(); const again=await clashRun3(); const cachedMs=performance.now()-t1;
    const idx=stepBodies3.indexOf(fb); if(idx>=0) stepBodies3.splice(idx,1);
    stlMesh3.remove(fake); fake.geometry.dispose(); fake.material.dispose();
    const n2 = await clashRun3();   // чистая пересборка без куба = проверка инвалидации токена
    const ok = !!mine && mine.cnt>3 && inst>0 && rows>=1 && again.length>=1 && cachedMs<2500 && !n2.find(p=>p.a.id===9999001||p.b.id===9999001);
    clearVoxAnalysis3();
    return { ok, n:pairs.length, cnt: mine?mine.cnt:0, inst, rows, cachedMs:Math.round(cachedMs), realClean:n2.length };
  })()`);
  console.log('CLASH', JSON.stringify(cl));
  if(!cl.ok) throw new Error('сталк-тест: '+JSON.stringify(cl));
  const tk = await evalJs(send, `(async()=>{
    const d = await thickRun3();
    if(!d) return { ok:false, why:'null' };
    let min=1e9, max=0; for(const t of d.th){ if(t<min)min=t; if(t>max)max=t; }
    const pts=thickPts3;
    const cols=pts.geometry.attributes.color.array;
    let sumA=0; for(let i=0;i<6000;i++) sumA+=cols[i];
    thickMax3=40; recolorThick3();
    let sumB=0; for(let i=0;i<6000;i++) sumB+=cols[i];
    thickMax3=10; recolorThick3();
    const stats=document.getElementById('thickStats').textContent.length>8;
    return { ok: d.th.length>20000 && max>=min*1.5 && pts.parent===stlMesh3 && sumA!==sumB && !!stats,
             n:d.th.length, min:+min.toFixed(1), max:+max.toFixed(1), stats };
  })()`);
  console.log('THICK', JSON.stringify(tk));
  if(!tk.ok) throw new Error('карта толщин: '+JSON.stringify(tk));
  const sh = await evalJs(send, `(()=>{
    const t0=performance.now(); const svg=window.__sheetSVG3(); const ms=Math.round(performance.now()-t0);
    return { ok: svg.length>50000 && svg.startsWith('<svg') && (svg.match(/<path/g)||[]).length===4
              && svg.includes('Изометрия') && svg.includes('М 1:') && svg.includes('420mm')
              && svg.includes('↔') && svg.includes('↕'), len:svg.length, ms };
  })()`);
  console.log('SHEET', JSON.stringify(sh));
  if(!sh.ok) throw new Error('авточертёж: '+JSON.stringify(sh));
  const st = await evalJs(send, `(()=>{
    const bs=stepBodies3.filter(b=>b._mesh&&b.vol); if(!bs.length) return { ok:false, why:'novol' };
    let big=bs[0]; for(const b of bs){ if(b.vol>big.vol) big=b; }
    const sel=document.getElementById('stockTarget'); if(!sel) return { ok:false, why:'noselect' };
    sel.value=String(big.id); stockSel3=String(big.id);
    const r=stockRun3(); if(!r) return { ok:false, why:'null' };
    const keys=r.variants.map(v=>v.key).sort().join(',');
    const bestN=r.variants.filter(v=>v.best).length;
    const volsOk=r.variants.every(v=>v.vol>0 && v.use>=0 && v.use<=100 && isFinite(v.kg) && v.kg>0);
    const rows=document.querySelectorAll('#stockList .stockRow').length===3;
    const wires=stockGrp3 && stockGrp3.children.length===3 && stockGrp3.children.filter(c=>c.visible).length===1;
    const csv=stockCsvText3().includes('заготовка') && stockCsvText3().length>100;
    const cylOk=r.cyl && r.cyl.r>1 && r.cyl.len>1 && r.cyl.vol>Math.PI*r.cyl.r*r.cyl.len*0.8;
    // переключение видимости кликом по строке:
    const rw=document.querySelector('#stockList .stockRow[data-k="cube"]'); rw.click();
    const toggled = stockGrp3.children.find(c=>c.userData.skey==='cube').visible===true;
    rw.click();
    stockSel3='all'; stockRun3(); stockClr3();
    const cleared=!stockRes3 && !stockGrp3;
    return { ok: keys==='cube,cyl,plate' && bestN===1 && volsOk && rows && !!wires && csv && !!cylOk && toggled && cleared, best:r.best, keys };
  })()`);
  console.log('STOCK', JSON.stringify(st));
  if(!st.ok) throw new Error('заготовки: '+JSON.stringify(st));
  const ar = await evalJs(send, `(async()=>{
    const ok=await window.__arSupport3();
    await arCheck3();
    const go=document.getElementById('arGoBtn');
    const statusOk = /WebXR/.test(document.getElementById('arStatus').textContent);
    // сценарий пользователя: включённое сечение НЕ должно съедать модель на столе
    clipState3.enabled=true; clipState3.mode='slab'; clipState3.axis='x'; clipState3.pos=0.35; clipState3.pos2=0.55; applyStlClipping();
    const before={ p:stlMesh3.position.clone(), s:stlMesh3.scale.clone(), d:camDist3, t:camTarget3.clone(), th:camTheta3 };
    window.__arTable3(true);
    const muted = clipState3.enabled===false;
    const grid = tableGrp3 && tableGrp3.children.length>=3;
    const camY = camera3.position.y;
    const onTable = stlMesh3.position.y > 600;
    stlMesh3.updateMatrixWorld(true); camera3.updateMatrixWorld(true);
    const bb=new THREE.Box3().setFromObject(stlMesh3);
    const pm=new THREE.Matrix4().multiplyMatrices(camera3.projectionMatrix, camera3.matrixWorldInverse);
    let inCam=0; const v=new THREE.Vector4();
    for(const X of [bb.min.x,bb.max.x]) for(const Y of [bb.min.y,bb.max.y]) for(const Z of [bb.min.z,bb.max.z]){
      v.set(X,Y,Z,1).applyMatrix4(pm);
      if(Math.abs(v.x/v.w)<1.25 && Math.abs(v.y/v.w)<1.25 && v.z/v.w<1.02) inCam++;
    }
    const dbg = { muted, grid:!!grid, onTable, camY:+camY.toFixed(0), d:+camDist3.toFixed(0), tgt:camTarget3.toArray().map(n=>+n.toFixed(0)), ph:+camPhi3.toFixed(2),
                  bb:[+bb.min.x.toFixed(0),+bb.min.y.toFixed(0),+bb.min.z.toFixed(0), +bb.max.x.toFixed(0),+bb.max.y.toFixed(0),+bb.max.z.toFixed(0)],
                  clipMuted: !clipState3.enabled };
    window.__arTable3(false);
    const clipBack = clipState3.enabled===true;
    const restored = stlMesh3.position.distanceTo(before.p)<0.01 && Math.abs(stlMesh3.scale.x-before.s.x)<1e-9
       && Math.abs(camDist3-before.d)<0.01 && camTarget3.distanceTo(before.t)<0.01 && !tableGrp3 && Math.abs(camTheta3-before.th)<1e-9;
    clipState3.enabled=false; applyStlClipping();
    return { ok: go.disabled===(!ok) && statusOk && muted && clipBack && !!grid && onTable && inCam>=6 && restored && camY>900, inCam, arOk:ok, dbg,
             restored, clipBack };
  })()`);
  console.log('AR', JSON.stringify(ar));
  if(!ar.ok) throw new Error('AR/стол: '+JSON.stringify(ar));
  console.log('ALL E2E CHECKS PASSED');
  ws.close(); process.exit(0);
})().catch(e=>{ console.error('E2E FAIL:', e.message); process.exit(1); });
