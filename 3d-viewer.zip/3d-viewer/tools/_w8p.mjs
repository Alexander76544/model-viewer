// _w8p.mjs — свет переживает F5: выставить dir/head/amb/ray → reload '/' → сравнить
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const j=async u=>{const r=await fetch(u);return r.json();};
const t=await j('http://127.0.0.1:9333/json');
const pg=t.find(x=>x.type==='page'&&x.webSocketDebuggerUrl);
const ws=new WebSocket(pg.webSocketDebuggerUrl);let id=0;const pend=new Map();
ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&pend.has(m.id)){pend.get(m.id)(m);}};
const send=(m,p={})=>new Promise(r=>{const i=++id;pend.set(i,r);ws.send(JSON.stringify({id:i,method:m,params:p}));});
await new Promise(r=>{ws.onopen=r});
await send('Runtime.enable'); await send('Page.enable');
const ev=async x=>{const m=await send('Runtime.evaluate',{expression:x,returnByValue:true});if(m.result.exceptionDetails)throw new Error((m.result.exceptionDetails.exception?.description||'EXC').slice(0,200));return m.result.result.value;};
async function waitfor(expr,ms=150000){const dl=Date.now()+ms;for(;;){let v=false;try{v=await ev(expr);}catch(e){}if(v)return;if(Date.now()>dl)throw new Error('wait '+expr);await sleep(400);}}
await send('Page.navigate',{url:'http://127.0.0.1:4173/?model=770_1003014-10.stp'});
await waitfor('stepBodies3 && stepBodies3.filter(b=>b._mesh).length>=2',120000);
await sleep(1800);
const set = await ev(`(()=>{
  light3.dir=[0.15,0.9,-0.4]; light3.head=0.52; light3.amb=0.31; light3.ray=true; light3.sun=true;
  syncLightUI3(); applyLight3(); scheduleModelMetaAutosave();
  return { dir: light3.dir.slice(), keyY: +keyLight3.position.y.toFixed(1), sunPos: sunHandle3.visible };
})()`);
console.log('SET', JSON.stringify(set));
await sleep(1100);
await send('Page.navigate',{url:'http://127.0.0.1:4173/'});
await waitfor('stlMesh3 && stlMesh3.visible && stepBodies3 && stepBodies3.filter(b=>b._mesh).length>=2',180000);
await sleep(2500);
const got = await ev(`(()=>({ dir: light3.dir.slice(), head: +headLight3.intensity.toFixed(3), ray: sunRay3.visible, sun: sunHandle3.visible }))()`);
console.log('GOT', JSON.stringify(got));
const d = Math.hypot(got.dir[0]-0.15, got.dir[1]-0.9, got.dir[2]+0.4);
const ok = d < 1e-3 && Math.abs(got.head-0.624)<1e-3 && got.ray && got.sun;
console.log(ok ? 'LIGHT PERSIST OK' : 'LIGHT PERSIST FAIL');
// возврат к дефолту, чтобы не гадить в meta
await ev(`(()=>{ document.getElementById('ltResetBtn').click(); scheduleModelMetaAutosave(); return 1; })()`);
await sleep(900);
ws.close(); process.exit(ok?0:1);
