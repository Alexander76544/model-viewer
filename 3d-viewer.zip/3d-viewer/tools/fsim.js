// Симуляция капли (та же логика, что в fluidStep3) на точной геометрии test-fluid.stl
'use strict';
const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const s1 = html.indexOf('function ftBuildTopo3');
const e1 = html.indexOf('// асинхронный расчёт топологии');
const s2 = html.indexOf('function fluidPointKind3');
const e2 = html.indexOf('function fluidStep3');
const core = html.slice(s1, e1) + '\n' + html.slice(s2, e2);
const VF_SURF = 1, VF_OUT = 2, FTK_SOLID = 0, FTK_CAV = 1, FTK_AIR = 2, FTK_PASS = 3;
globalThis.VF_SURF = VF_SURF; globalThis.VF_OUT = VF_OUT;
globalThis.FTK_SOLID = FTK_SOLID; globalThis.FTK_CAV = FTK_CAV;
globalThis.FTK_AIR = FTK_AIR; globalThis.FTK_PASS = FTK_PASS;
globalThis.THREE = { Vector3: class { constructor(x=0,y=0,z=0){this.x=x;this.y=y;this.z=z;} set(x,y,z){this.x=x;this.y=y;this.z=z;return this;} } };
globalThis.stlMesh3 = {}; globalThis.stepBodies3 = [];
globalThis.fluid3 = { type:'fuel', dropD:10, pools:[] };
let drops3 = null;
Object.defineProperty(globalThis, 'drops3', { configurable: true, get: () => drops3 });
globalThis.fluidBarrier3 = null; globalThis.fluidClipPlanes3 = null;
globalThis.fluidBodyVisible3 = ()=>true; globalThis.fluidPointClipped3 = ()=>false; globalThis.fluidPointBarrier3 = ()=>false;
(0, eval)(core);

const H = 100/240, DX = Math.ceil(100/H)+3;
const N = DX*DX*DX;
const grid = new Uint8Array(N);
const inBlock = (x,y,z) => x>=0 && x<=100 && y>=0 && y<=100 && z>=0 && z<=100;
const inHoleA = (x,y,z) => x>=45 && x<=55 && y>=50 && y<=100 && z>=45 && z<=55;
const inHoleB = (x,y,z) => x>=70 && x<=80 && y>=0 && y<=100 && z>=70 && z<=80;
for(let k=0;k<DX;k++) for(let j=0;j<DX;j++) for(let i=0;i<DX;i++){
  const x=-H+(i+0.5)*H, y=-H+(j+0.5)*H, z=-H+(k+0.5)*H;
  const idx=(k*DX+j)*DX+i;
  if(!inBlock(x,y,z)){ grid[idx]=2; continue; }
  if(inHoleA(x,y,z) || inHoleB(x,y,z)){ grid[idx]=2; continue; }
  const ds = Math.min(x, 100-x, y, 100-y, z, 100-z);
  grid[idx] = ds < H ? 1 : 0;
}
const body = { id:-1, grid, dims:[DX,DX,DX], mins:[-H,-H,-H], h:H, box:{ containsPoint:()=>true } };
body._ftopo = ftBuildTopo3(body);
drops3 = { cache: { token:'t', bodies:[body], h:H } };

function simDrop(x0, y0, z0, opts = {}) {
  const p = { x:x0, y:y0, z:z0, clone(){ return { x:this.x, y:this.y, z:this.z }; } };
  const d = { p, v:{ x:(Math.random()-0.5)*50, y:-40-Math.random()*100, z:(Math.random()-0.5)*50 },
              drip:0, guide3:null, guideFail:0, frozen:0, life:0, dead:0 };
  const G = 2600, VMAX = 900, dt = 1/60;
  const marks = [];
  for(let frame=0; frame<900 && !d.dead; frame++){
    const vmax = Math.hypot(d.v.x,d.v.y,d.v.z);
    const n = Math.max(2, Math.min(24, Math.ceil(vmax*dt/(H*0.5)) || 2));
    for(let pass=0; pass<n; pass++){
      const sdt = dt/n;
      if(d.frozen){ if(drops3.cache.bodies.every(b=>b._ftopo)) d.frozen=0; else continue; }
      d.life += sdt;
      d.v.y -= G*sdt;
      const sp = Math.hypot(d.v.x,d.v.y,d.v.z); if(sp>VMAX){ const f=VMAX/sp; d.v.x*=f; d.v.y*=f; d.v.z*=f; }
      let blockedY = false;
      for(const axis of ['x','y','z']){
        if(d.v[axis]===0) continue;
        const tp = p.clone(); tp[axis] = tp[axis] + d.v[axis]*sdt;
        const hit = fluidPointKind3(tp);
        if(hit && hit.kind===FTK_SOLID){ d.v[axis]=0; if(axis==='y') blockedY=true; continue; }
        p[axis] = tp[axis];
      }
      if(pass===0){ const pk2 = fluidPointKind3(p); if(pk2 && (pk2.kind===FTK_CAV || pk2.kind===FTK_PASS) && pk2.b._ftopo) d.lastReg = { b: pk2.b, idx: pk2.idx }; }
      if(blockedY){
        d.v.x *= d.drip?0.965:0.86; d.v.z *= d.drip?0.965:0.86;
        if(d.drip){
          if(!d.guide3 && !d.guideFail && d.life>0.1){ d.guide3=fluidDripGuide3(d); if(!d.guide3) d.guideFail=1; }
          if(d.guide3){
            const gxg=d.guide3.x-p.x, gzg=d.guide3.z-p.z, gd=Math.hypot(gxg,gzg);
            if(gd<H) d.guide3=null;
            else { const s2=Math.min(240, gd*6+20); d.v.x=(gxg/gd)*s2+(Math.random()-0.5)*8; d.v.z=(gzg/gd)*s2+(Math.random()-0.5)*8; }
          } else if(d.guideFail && Math.random()<sdt*2){ d.v.x+=(Math.random()-0.5)*120; d.v.z+=(Math.random()-0.5)*120; }
        }
      }
      const still = Math.hypot(d.v.x,d.v.y,d.v.z)<30;
      if((blockedY&&still)||d.life>12){
        const si = fluidSettleIdx3(d);
        if(si && !si.air){ d.dead = 'DEPOSIT y='+p.y.toFixed(1); break; }
        if(si && si.air){
          if(!d.drip){
            d.drip=1; d.guide3=null; d.guideFail=0;
            if(!opts.noLift) p.y += H*0.65;
            d.v.x=(Math.random()-0.5)*60; d.v.y=-30; d.v.z=(Math.random()-0.5)*60;
          }
          if(d.life>8) d.dead='DIED(drip)';
        } else { if(d.life>12) d.dead='DIED(frozen)'; else d.frozen=1; }
      }
      if(p.y < -400){ if(d.lastReg){ fluidDeposit3cell(d.lastReg.b, d.lastReg.idx, 100, d); d.dead='FELL+DEPOSIT'; } else d.dead='FELL'; break; }
    }
    if(frame===12||frame===30||frame===60) marks.push(`t=${(frame/60).toFixed(1)}s (${p.x.toFixed(1)},${p.y.toFixed(1)},${p.z.toFixed(1)}) drip=${d.drip} guide=${d.guide3?d.guide3.x.toFixed(1)+','+d.guide3.z.toFixed(1):'-'}`);
  }
  const pools = fluid3.pools.map(pp=>({ region:pp.regionIdx, depMM3:+(pp.depositedVox*pp.h3).toFixed(0) }));
  return { dead: d.dead || 'STILL_ALIVE', life:d.life.toFixed(2), marks, end:{x:+p.x.toFixed(1),y:+p.y.toFixed(1),z:+p.z.toFixed(1)}, pools };
}

console.log('1) капля у кромки устья (5 мм слева), С подъёмом:');
console.log('   ', JSON.stringify(simDrop(39.93, 101, 50.26)));
console.log('2) та же, БЕЗ подъёма (старый баг):');
console.log('   ', JSON.stringify(simDrop(39.93, 101, 50.26, {noLift:true})));
console.log('3) капля точно над устьем:');
console.log('   ', JSON.stringify(simDrop(50, 101, 50)));
console.log('4) капля на плоскости (20,20), отверстий рядом нет:');
console.log('   ', JSON.stringify(simDrop(20, 101, 20)));
console.log('5) капля над сквозным каналом (75,75):');
console.log('   ', JSON.stringify(simDrop(75, 101, 75)));
