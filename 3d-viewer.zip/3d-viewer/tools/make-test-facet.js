// tools/make-test-stl.js — маленький цветной тор для регресс-скриншотов вьюера
// запуск: node tools/make-test-stl.js [out.stl]   (по умолчанию ../_test_facet.stl)
'use strict';
const fs = require('fs');
const path = require('path');
const out = process.argv[2] || path.resolve(__dirname, '..', '_test_facet.stl');
const R = 130, r0 = 52, NU = 14, NV = 7;
const facets = NU * NV * 2;
const buf = Buffer.alloc(84 + facets * 50);
buf.write('solid _test_facet'.padEnd(80, '\0'), 0, 'ascii');
buf.writeUInt32LE(facets, 80);
let o = 84;
function push(a, b, c, col){
  buf.writeFloatLE(0, o); buf.writeFloatLE(0, o + 4); buf.writeFloatLE(0, o + 8);      // нормаль — пересчитает вьюер
  buf.writeFloatLE(a[0], o + 12); buf.writeFloatLE(a[1], o + 16); buf.writeFloatLE(a[2], o + 20);
  buf.writeFloatLE(b[0], o + 24); buf.writeFloatLE(b[1], o + 28); buf.writeFloatLE(b[2], o + 32);
  buf.writeFloatLE(c[0], o + 36); buf.writeFloatLE(c[1], o + 40); buf.writeFloatLE(c[2], o + 44);
  buf.writeUInt16LE(0x8000 | col, o + 48);                                              // RGB555 + флаг цвета
  o += 50;
}
function rgb555(r, g, b){ return ((r & 31) << 10) | ((g & 31) << 5) | (b & 31); }
function P(u, v){
  const cu = Math.cos(u), su = Math.sin(u), cv = Math.cos(v), sv = Math.sin(v);
  return [(R + r0 * cv) * cu, (R + r0 * cv) * su, r0 * sv];
}
for (let i = 0; i < NU; i++) {
  const u0 = (i / NU) * Math.PI * 2, u1 = ((i + 1) / NU) * Math.PI * 2;
  for (let j = 0; j < NV; j++) {
    const v0 = (j / NV) * Math.PI * 2, v1 = ((j + 1) / NV) * Math.PI * 2;
    const A = P(u0, v0), B = P(u1, v0), C = P(u1, v1), D = P(u0, v1);
    const hue = i / NU;
    const rr = Math.round(31 * Math.max(0, Math.sin(hue * Math.PI * 2) * 1.0) + 0 * 31);
    const gg = Math.round(31 * Math.max(0, Math.sin(hue * Math.PI * 2 + 2.09) * 1.0));
    const bb = Math.round(31 * Math.max(0, Math.sin(hue * Math.PI * 2 + 4.19) * 1.0));
    const col = ((Math.max(rr, 4) & 31) << 10) | ((Math.max(gg, 4) & 31) << 5) | (Math.max(bb, 6) & 31);
    push(A, B, C, col);
    push(A, C, D, col);
  }
}
fs.writeFileSync(out, buf);
console.log('written', out, (buf.length / 1048576).toFixed(2), 'MB,', facets, 'facets');

