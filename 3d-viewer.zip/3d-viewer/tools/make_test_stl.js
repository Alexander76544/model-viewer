// Генератор тестовой модели для физики жидкости:
// блок 100×100×100 мм с (A) слепым вертикальным отверстием (заполняется до края)
// и (B) сквозным вертикальным отверстием (вытекает, заглушки нет).
// Запуск: node tools\make_test_stl.js
'use strict';
const fs = require('fs');
const path = require('path');

const S = 40, H = 2.5;   // вокселей, мм на воксель
const solid = new Uint8Array(S * S * S);
const idx = (x, y, z) => (z * S + y) * S + x;
// в STL «вверх» = Z (вьюер поворачивает в Y-up): каналы вертикальные = вдоль Z
const inHoleA = (x, y, z) => x >= 18 && x <= 22 && y >= 18 && y <= 22 && z >= 20;  // слепое, дно на z=19, устье на верхней грани
const inHoleB = (x, y, z) => x >= 28 && x <= 32 && y >= 28 && y <= 32;            // сквозное (z 0..39)
for (let z = 0; z < S; z++) for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
  if (!inHoleA(x, y, z) && !inHoleB(x, y, z)) solid[idx(x, y, z)] = 1;
}
const isSolid = (x, y, z) => (x >= 0 && y >= 0 && z >= 0 && x < S && y < S && z < S) && solid[idx(x, y, z)] === 1;

// [dir, треугольник1, треугольник2, нормаль] — порядок вершин: (v1-v0)×(v2-v0) = нормаль
const FACE = [
  [[-1,0,0], [[0,0,0],[0,1,1],[0,1,0]], [[0,0,0],[0,0,1],[0,1,1]], [-1,0,0]],
  [[1,0,0],  [[1,0,0],[1,1,1],[1,0,1]], [[1,0,0],[1,1,0],[1,1,1]], [1,0,0]],
  [[0,-1,0], [[0,0,0],[1,0,0],[1,0,1]], [[0,0,0],[1,0,1],[0,0,1]], [0,-1,0]],
  [[0,1,0],  [[0,1,0],[1,1,1],[1,1,0]], [[0,1,0],[0,1,1],[1,1,1]], [0,1,0]],
  [[0,0,-1], [[0,0,0],[0,1,0],[1,1,0]], [[0,0,0],[1,1,0],[1,0,0]], [0,0,-1]],
  [[0,0,1],  [[0,0,1],[1,0,1],[1,1,1]], [[0,0,1],[1,1,1],[0,1,1]], [0,0,1]]
];
const tris = [];
for (let z = 0; z < S; z++) for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
  if (!isSolid(x, y, z)) continue;
  for (const [d, t1, t2, n] of FACE) {
    if (isSolid(x + d[0], y + d[1], z + d[2])) continue;   // внутренняя грань — не трогаем
    for (const t of [t1, t2]) {
      const a = [ (x + t[0][0]) * H, (y + t[0][1]) * H, (z + t[0][2]) * H ];
      const b = [ (x + t[1][0]) * H, (y + t[1][1]) * H, (z + t[1][2]) * H ];
      const c = [ (x + t[2][0]) * H, (y + t[2][1]) * H, (z + t[2][2]) * H ];
      tris.push([n, a, b, c]);
    }
  }
}
let out = 'solid testfluid\n';
for (const [n, a, b, c] of tris) {
  out += `  facet normal ${n[0]} ${n[1]} ${n[2]}\n    outer loop\n` +
    `      vertex ${a[0]} ${a[1]} ${a[2]}\n      vertex ${b[0]} ${b[1]} ${b[2]}\n      vertex ${c[0]} ${c[1]} ${c[2]}\n` +
    `    endloop\n  endfacet\n`;
}
out += 'endsolid testfluid\n';
const dst = path.join(__dirname, '..', 'test-fluid.stl');
fs.writeFileSync(dst, out);
console.log('tris:', tris.length, '→', dst, (out.length / 1024 / 1024).toFixed(2), 'MB');
