// Отладка «ручья» на точной геометрии test-fluid.stl (100 мм, вертикальные каналы)
'use strict';
const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const s1 = html.indexOf('function ftBuildTopo3');
const e1 = html.indexOf('// асинхронный расчёт топологии');
const s2 = html.indexOf('function fluidPointKind3');
const e2 = html.indexOf('function fluidDeposit3cell');
const core = html.slice(s1, e1) + '\n' + html.slice(s2, e2);

const VF_SURF = 1, VF_OUT = 2, FTK_SOLID = 0, FTK_CAV = 1, FTK_AIR = 2, FTK_PASS = 3;
globalThis.VF_SURF = VF_SURF; globalThis.VF_OUT = VF_OUT;
globalThis.FTK_SOLID = FTK_SOLID; globalThis.FTK_CAV = FTK_CAV;
globalThis.FTK_AIR = FTK_AIR; globalThis.FTK_PASS = FTK_PASS;
globalThis.THREE = { Vector3: class { constructor(x=0,y=0,z=0){this.x=x;this.y=y;this.z=z;} set(x,y,z){this.x=x;this.y=y;this.z=z;return this;} } };
globalThis.stlMesh3 = null; globalThis.stepBodies3 = [];
let drops3 = null;
Object.defineProperty(globalThis, 'drops3', { configurable: true, get: () => drops3 });
globalThis.fluidBarrier3 = null; globalThis.fluidClipPlanes3 = null;
globalThis.fluidBodyVisible3 = ()=>true; globalThis.fluidPointClipped3 = ()=>false; globalThis.fluidPointBarrier3 = ()=>false;
(0, eval)(core);

// точная сетка как в buildVoxels3: h = maxDim/240, mins = bb.min - h, dims = extent/h + 3
const H = 100/240, DX = Math.ceil(100/H)+3;   // 243
const N = DX*DX*DX;
const grid = new Uint8Array(N);
const inBlock = (x,y,z) => x>=0 && x<=100 && y>=0 && y<=100 && z>=0 && z<=100;
const inHoleA = (x,y,z) => x>=45 && x<=55 && y>=50 && y<=100 && z>=45 && z<=55;   // слепое, устье на y=100
const inHoleB = (x,y,z) => x>=70 && x<=80 && y>=0 && y<=100 && z>=70 && z<=80;   // сквозное
for(let k=0;k<DX;k++) for(let j=0;j<DX;j++) for(let i=0;i<DX;i++){
  const x=-H+(i+0.5)*H, y=-H+(j+0.5)*H, z=-H+(k+0.5)*H;
  const idx=(k*DX+j)*DX+i;
  if(!inBlock(x,y,z)){ grid[idx]=2; continue; }
  if(inHoleA(x,y,z) || inHoleB(x,y,z)){ grid[idx]=2; continue; }
  const ds = Math.min(x, 100-x, y, 100-y, z, 100-z);
  grid[idx] = ds < H ? 1 : 0;
}
const mins=[-H,-H,-H];
const body = { id:-1, grid, dims:[DX,DX,DX], mins, h:H,
  box: { containsPoint:()=>true } };
const t0 = Date.now();
body._ftopo = ftBuildTopo3(body);
console.log('topo:', Date.now()-t0, 'ms; regions:', body._ftopo.regions.map(r=>`total=${r.total}, open=${r.open.length}, minY=${r.minY}, maxY=${r.maxY}`).join(' | '));

drops3 = { cache: { token:'t', bodies:[body], h:H } };

// капля на верхней грани, 5 мм левее кромки устья (как в браузерном замере: пик (39.93, 100, 50.26))
const d = { p: { x:39.93, y:100.2, z:50.26 } };
const pk = fluidPointKind3(d.p);
console.log('pk:', pk && { kind: pk.kind, i: pk.i, j: pk.j, k: pk.k });
const g = fluidDripGuide3(d);
console.log('guide:', g ? `(${g.x.toFixed(2)}, ${g.z.toFixed(2)})` : null);
// контрольные: капля в центре устья, капля посреди плоскости
const d2 = { p: { x:50, y:100.2, z:50 } };
console.log('guide@mouth:', JSON.stringify(fluidDripGuide3(d2)));
const d3 = { p: { x:20, y:100.2, z:20 } };
console.log('guide@flat:', JSON.stringify(fluidDripGuide3(d3)));
