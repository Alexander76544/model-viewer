# -*- coding: utf-8 -*-
"""Сколько «слоёв» треугольников накладывается в STL: для выборок вершин с
большим числом инцидентных рёбер печатаем нормали соседей (складываем по направлениям)."""
import struct, sys, os
from collections import defaultdict, Counter

path = os.path.abspath(sys.argv[1])
f = open(path, 'rb'); f.seek(80)
n = struct.unpack('<I', f.read(4))[0]
rec = struct.Struct('<12fH')
tris = []
for t in range(n):
    d = rec.unpack(f.read(50))
    a = (round(d[3], 1), round(d[4], 1), round(d[5], 1))
    b = (round(d[6], 1), round(d[7], 1), round(d[8], 1))
    c = (round(d[9], 1), round(d[10], 1), round(d[11], 1))
    tris.append((a, b, c))
f.close()
print('tris:', n)

# инцидентность: vertex -> list tri indices
inc = defaultdict(list)
for i, (a, b, c) in enumerate(tris):
    for v in (a, b, c):
        inc[v].append(i)

# возьмём вершины с 12..24 инцидентными треугольниками (в норме ~6)
cand = [(v, i) for v, i in inc.items() if 12 <= len(i) <= 24]
print('verts with 12-24 incident tris:', len(cand))

import math
def norm(a, b, c):
    ux, uy, uz = b[0]-a[0], b[1]-a[1], b[2]-a[2]
    vx, vy, vz = c[0]-a[0], c[1]-a[1], c[2]-a[2]
    cx, cy, cz = uy*vz-uz*vy, uz*vx-ux*vz, ux*vy-uy*vx
    l = math.sqrt(cx*cx+cy*cy+cz*cz) or 1.0
    return (round(cx/l,2), round(cy/l,2), round(cz/l,2))

sampled = 0
for v, ti in cand[:4000]:
    # группируем нормали по направлениям (нормаль и её отражение — разные слои одной стороны)
    dirs = Counter()
    for i in ti:
        dirs[norm(*tris[i])] += 1
    top = dirs.most_common(3)
    # «слоёв» = суммарное число треугольников / ~6
    layers = len(ti) / 6.0
    if sampled < 12:
        print('v=%s  tris=%d  ~layers=%.1f  top dirs=%s' % (v, len(ti), layers, top))
    sampled += 1
# сводка: распределение "слоёв" по всем вершинам-кандидатам
dist = Counter()
for v, ti in cand:
    dist[round(len(ti)/6.0, 1)] += 1
print('layer distribution (layers: #verts):')
for k in sorted(dist):
    print('  %.1f : %d' % (k, dist[k]))
