// _shots28.mjs — превью wave9: preview-bolt.png / preview-clash.png / preview-thick.png (asm)
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const j=async u=>{const r=await fetch(u);return r.json();};
const t=await j('http://127.0.0.1:9333/json');
const pg=t.find(x=>x.type==='page'&&x.webSocketDebuggerUrl);
const ws=new WebSocket(pg.webSocketDebuggerUrl);let id=0;const pend=new Map();
ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&pend.has(m.id)){pend.get(m.id)(m);}};
const send=(m,p={})=>new Promise(r=>{const i=++id;pend.set(i,r);ws.send(JSON.stringify({id:i,method:m,params:p}));});
await new Promise(r=>{ws.onopen=r});
await send('Runtime.enable'); await send('Page.enable');
await send('Emulation.setDeviceMetricsOverride',{width:1500,height:880,deviceScaleFactor:1,mobile:false});
const ev=async x=>{const m=await send('Runtime.evaluate',{expression:x,returnByValue:true,awaitPromise:true});if(m.result.exceptionDetails)throw new Error((m.result.exceptionDetails.exception?.description||'err').slice(0,300));return m.result.result.value;};
async function waitfor(expr,ms=180000){const dl=Date.now()+ms;for(;;){let v=false;try{v=await ev(expr);}catch(e){}if(v)return;if(Date.now()>dl)throw new Error('timeout '+expr);await sleep(500);}}
import fs from 'fs';
async function shot(file){const s=await send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(file,Buffer.from(s.result.data,'base64'));console.log('→',file);}

await send('Page.navigate',{url:'http://127.0.0.1:4173/?model=770_1003011-101_asm_asm.stp'});
await waitfor('stepBodies3 && stepBodies3.filter(b=>b._mesh).length >= stepBodies3.length-1',240000);
await sleep(2500);

// ① 🔩 bolts: группы + кольца на самой массовой группе
await ev(`(function(){
  closeAllPanels2();
  window.__openPanel2('apAna');
  const g=boltRun3();
  const holes=g.filter(x=>x.kind==='hole');
  const top=holes.reduce((a,b)=>a.n>b.n?a:b, holes[0]);
  showBoltRings3(g.indexOf(top));
  camDist3 = Math.max(150, top.bc? top.bc.d*1.35 : top.holes[0].r*30); updateCamera3();
  return 1;
})()`);
await sleep(1500);
await shot('preview-bolt.png');
await ev(`(function(){ if(boltRingGrp3){ boltRingGrp3.visible=false; } return 1; })()`);

// ② 🔴 реальные интерференции на живой сборке
const real=await ev(`(async()=>{
  document.querySelectorAll('.anaTab')[1].click();
  const p=await clashRun3();
  if(p[0]){ camTarget3.set(p[0].cx,p[0].cy,p[0].cz); camDist3=220; updateCamera3(); }
  return { pairs:p.length, volTop: p[0]? +(p[0].vol/1000).toFixed(1): 0, names: p.slice(0,3).map(x=>String(x.a.name).slice(0,14)+'∩'+String(x.b.name).slice(0,14)), inst: clashGrp3&&clashGrp3.children[0]? clashGrp3.children[0].count:0, skipped: voxCache3.skipped };
})()`);
console.log('REAL-CLASH', JSON.stringify(real));
let useSynthetic = real.pairs===0;
if(useSynthetic){
  await ev(`(async()=>{
    const bs = stepBodies3.filter(b=>b._mesh && b.vol);
    let big=bs[0]; for(const b of bs){ if(b.vol>big.vol) big=b; }
    const c = voxCache3; const vb = c.bodies.find(v=>v.id===big.id);
    let cell=null, sc=-1;
    { const [DX,DY,DZ]=vb.dims;
      for(let k=1;k<DZ-1;k++) for(let j=1;j<DY-1;j++) for(let i=1;i<DX-1;i++){
        if(vb.grid[(k*DY+j)*DX+i]!==0) continue;
        const s=Math.min(i,DX-1-i,j,DY-1-j,k,DZ-1-k);
        if(s>sc){ sc=s; cell=[vb.mins[0]+(i+.5)*vb.h, vb.mins[1]+(j+.5)*vb.h, vb.mins[2]+(k+.5)*vb.h]; }
      } }
    const fake=new THREE.Mesh(new THREE.BoxGeometry(30,30,30), new THREE.MeshBasicMaterial({visible:false}));
    fake.position.set(cell[0],cell[1],cell[2]);
    stlMesh3.add(fake); fake.updateMatrix(); fake.updateWorldMatrix(true,false);
    window.__fb={ id:9999001, name:'вмятина-30', vol:27000, _mesh:fake };
    stepBodies3.push(window.__fb);
    await clashRun3();
    const p0 = clashPairs3[0];
    if(p0){ camTarget3.set(p0.cx,p0.cy,p0.cz); camDist3=170; updateCamera3(); }
    return 1;
  })()`);
}
await sleep(900);
await shot('preview-clash.png');
if(useSynthetic){
  await ev(`(function(){
    const fb=window.__fb;
    if(fb){ const i=stepBodies3.indexOf(fb); if(i>=0) stepBodies3.splice(i,1); stlMesh3.remove(fb._mesh); fb._mesh.geometry.dispose(); fb._mesh.material.dispose(); }
    clearVoxAnalysis3();
    return 1;
  })()`);
}

// ③ 🌡 толщины со срезом, чтобы видеть внутренку
await ev(`(async()=>{
  clipState3.enabled=true; clipState3.mode='slab'; clipState3.axis='x'; clipState3.pos=0.30; clipState3.pos2=0.62;
  applyStlClipping();
  await thickRun3();
  const tabs=document.querySelectorAll('.anaTab'); tabs[2].click();
  return 1;
})()`);
await sleep(1200);
await shot('preview-thick.png');
await ev(`(function(){ clipState3.enabled=false; clipState3.pos2=0; applyStlClipping(); closeAllPanels2(); return 1; })()`);
await sleep(700);
console.log('DONE');
ws.close(); process.exit(0);
