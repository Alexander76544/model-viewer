// _w7p.mjs — F5-персистентность probes3 + dens3 (создать → reload '/' → проверить восстановление)
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const j=async u=>{const r=await fetch(u);return r.json();};
const t=await j('http://127.0.0.1:9333/json');
const pg=t.find(x=>x.type==='page'&&x.webSocketDebuggerUrl);
const ws=new WebSocket(pg.webSocketDebuggerUrl);let id=0;const pend=new Map();
ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&pend.has(m.id)){pend.get(m.id)(m);pend.delete(m.id);}};
const send=(m,p={})=>new Promise(r=>{const i=++id;pend.set(i,r);ws.send(JSON.stringify({id:i,method:m,params:p}));});
await new Promise(r=>{ws.onopen=r});
await send('Runtime.enable'); await send('Page.enable');
const ev=async x=>{const m=await send('Runtime.evaluate',{expression:x,returnByValue:true,awaitPromise:true});if(m.result.exceptionDetails)throw new Error((m.result.exceptionDetails.exception?.description||'EXC').slice(0,300));return m.result.result.value;};
async function waitfor(expr,ms=120000){const dl=Date.now()+ms;for(;;){let v=false;try{v=await ev(expr);}catch(e){}if(v)return;if(Date.now()>dl)throw new Error('wait '+expr);await sleep(400);}}
// фаза 1: создать пару probe + свою плотность, дождаться автосохранения
await send('Page.navigate',{url:'http://127.0.0.1:4173/?model=770_1003014-10.stp'});
await waitfor('stepBodies3 && stepBodies3.filter(b=>b._mesh).length>=2');
await sleep(1500);
const made = await ev(`(()=>{
  resetMeasureState3(); setFaceMode3(true);
  const rect=renderer3.domElement.getBoundingClientRect();
  const bid = +Object.entries(faceCatalog3).map(([k,fs])=>({k:+k,p:fs.filter(f=>f.t==='P').length})).sort((a,b)=>b.p-a.p)[0].k;
  const b = stepBodies3.find(x=>x.id===bid);
  const ctr = (v=>{const p=v.clone().project(camera3);return [rect.left+(p.x*.5+.5)*rect.width, rect.top+(-p.y*.5+.5)*rect.height];})(new THREE.Box3().setFromObject(b._mesh).getCenter(new THREE.Vector3()));
  let pxA=null,fA=null,pxB=null;
  for(let dx=-140; dx<=140 && !pxA; dx+=8) for(let dy=-100; dy<=100 && !pxA; dy+=8){
    const rr=measurePick3(ctr[0]+dx,ctr[1]+dy); if(!rr||rr.bid!==bid) continue;
    const ff=matchFace3(rr.bid,rr.point); if(ff&&ff.t==='P'){pxA=[ctr[0]+dx,ctr[1]+dy];fA=ff;}}
  if(!pxA) return {ok:false};
  faceClick3(pxA[0],pxA[1]);
  for(let dx=-140; dx<=140 && !pxB; dx+=8) for(let dy=-100; dy<=100 && !pxB; dy+=8){
    const rr=measurePick3(ctr[0]+dx,ctr[1]+dy); if(!rr||rr.bid!==bid) continue;
    const ff=matchFace3(rr.bid,rr.point); if(ff&&ff.t==='P'&&ff!==fA) pxB=[ctr[0]+dx,ctr[1]+dy];}
  if(!pxB) return {ok:false,one:true};
  faceClick3(pxB[0],pxB[1]);
  const bb = stepBodies3.filter(x=>x.vol).sort((a,c)=>c.vol-a.vol)[0];
  dens3[bb.id]=1.23; renderMassList3();
  scheduleModelMetaAutosave();
  return { ok:true, n:probes3.length, txt: probes3[1].txt, densId: bb.id };
})()`);
console.log('MADE', JSON.stringify(made));
if(!made.ok) process.exit(1);
await sleep(1200); // debounce 600 + запись
// фаза 2: reload без ?model= (restore работает только на plain /)
await send('Page.navigate',{url:'http://127.0.0.1:4173/'});
await waitfor('stlMesh3 && stlMesh3.visible && stepBodies3 && stepBodies3.filter(b=>b._mesh).length>=2',180000);
await sleep(2000);
const got = await ev(`(()=>({ n: probes3.length, txt: probes3[probes3.length-1] && probes3[probes3.length-1].txt.slice(0,50),
  vis: !!(probeGroup3 && probeGroup3.children.length>0),
  dens: dens3[${made.densId}] || null, kg: +(massTotals3().g/1000).toFixed(2) }))()`);
console.log('GOT', JSON.stringify(got));
const okp = got.n===2 && got.vis && Math.abs(got.dens-1.23)<1e-9 && got.txt===made.txt.slice(0,50);
console.log(okp ? 'PERSIST OK' : 'PERSIST FAIL');
//cleanup
await ev(`(()=>{ setFaceMode3(false); resetMeasureState3(); delete dens3[${made.densId}]; renderMassList3(); scheduleModelMetaAutosave(); return 1; })()`);
await sleep(1000);
ws.close(); process.exit(okp?0:1);
