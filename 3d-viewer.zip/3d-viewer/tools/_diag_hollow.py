# -*- coding: utf-8 -*-
"""Диагностика: что XCAF читает из STEP (типы форм, грани, bbox)."""
import os, sys, time
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
from OCP.TopAbs import TopAbs_SOLID, TopAbs_SHELL, TopAbs_FACE
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS, TopoDS_Shape
try:
    from OCP.TDF import TDF_LabelSequence as LSeq
except Exception:
    from OCP.collections import Sequence_TDF_Label as LSeq

src = os.path.abspath(sys.argv[1])
t0 = time.time()
doc = TDocStd_Document(TCollection_ExtendedString("XmlOcaf"))
reader = STEPCAFControl_Reader()
try:
    reader.SetColorMode(True)
except Exception:
    pass
rc = reader.ReadFile(src)
print('ReadFile rc=%s (%.0fs)' % (rc, time.time() - t0))
t0 = time.time()
tr = reader.Transfer(doc)
print('Transfer=%s (%.0fs)' % (tr, time.time() - t0))
shp_tool = XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())

def bb(shp):
    box = Bnd_Box()
    BRepBndLib.Add_s(shp, box, False)
    if box.IsVoid():
        return None
    mn, mx = box.CornerMin(), box.CornerMax()
    return '%.0fx%.0fx%.0f @ (%.0f,%.0f,%.0f)' % (
        mx.X()-mn.X(), mx.Y()-mn.Y(), mx.Z()-mn.Z(), mn.X(), mn.Y(), mn.Z())

def counts(shp):
    out = {}
    for key, typ in (('solids', TopAbs_SOLID), ('shells', TopAbs_SHELL), ('faces', TopAbs_FACE)):
        n = 0
        exp = TopExp_Explorer(shp, typ)
        while exp.More():
            n += 1
            exp.Next()
        out[key] = n
    return out

roots = LSeq()
shp_tool.GetFreeShapes(roots)
print('free shapes: %d' % roots.Length())
tot_f = 0
for ri in range(1, roots.Length() + 1):
    shp = shp_tool.GetShape_s(roots.Value(ri))
    try:
        nm = ''
        from OCP.TDataStd import TDataStd_Name
        att = TDataStd_Name()
        if roots.Value(ri).FindAttribute(TDataStd_Name.GetID_s(), att):
            nm = att.Get().ToExtString()
    except Exception:
        pass
    c = counts(shp)
    tot_f += c['faces']
    print('root %d: name=%r %s bbox=%s' % (ri, nm[:60], c, bb(shp)))
    # по оболочкам: закрытые/открытые
    nclosed = nopen = 0
    exp = TopExp_Explorer(shp, TopAbs_SHELL)
    si = 0
    while exp.More():
        si += 1
        sh = TopoDS.Shell(exp.Current())
        try:
            cl = sh.IsClosed()
        except Exception:
            try:
                cl = sh.Closed()
            except Exception:
                cl = None
        if cl:
            nclosed += 1
        else:
            nopen += 1
        # грани оболочки
        nf = 0
        ex2 = TopExp_Explorer(sh, TopAbs_FACE)
        while ex2.More():
            nf += 1
            ex2.Next()
        if si <= 12 or nclosed + nopen <= 12:
            print('   shell %d: faces=%d closed=%s bbox=%s' % (si, nf, cl, bb(sh)))
        exp.Next()
    print('   shells: closed=%d open=%d (показаны %d)' % (nclosed, nopen, min(si, 12 if si > 12 else si)))
print('TOTAL faces in free shapes: %d' % tot_f)
