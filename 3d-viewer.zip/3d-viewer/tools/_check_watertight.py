# -*- coding: utf-8 -*-
"""Проверка binary STL: замкнутость (каждое ребро ровно у 2 треугольников),
знакообъём (для замкнутой meshes = истинный объём), количество рёбер-дефектов."""
import struct, sys, os

def check(path):
    sz = os.path.getsize(path)
    print('file: %s (%.1f MB)' % (path, sz / 1048576.0))
    f = open(path, 'rb')
    f.seek(80)
    n = struct.unpack('<I', f.read(4))[0]
    print('triangles: %d' % n)
    edges = {}
    vol = 0.0
    bad_normals = 0
    off = f.tell()
    rec = struct.Struct('<12fH')
    for t in range(n):
        d = rec.unpack(f.read(50))
        a = (d[3], d[4], d[5]); b = (d[6], d[7], d[8]); c = (d[9], d[10], d[11])
        vol += (a[0]*(b[1]*c[2]-b[2]*c[1]) - a[1]*(b[0]*c[2]-b[2]*c[0]) + a[2]*(b[0]*c[1]-b[1]*c[0])) / 6.0
        if d[0] == 0 and d[1] == 0 and d[2] == 0:
            bad_normals += 1
        for p, q in ((a, b), (b, c), (c, a)):
            if p == q:
                continue
            k = (p if p < q else q, p if p < q else q)
            # округление до 0.001 мм для устойчивости к float-джиттеру
            k = ((round(k[0][0], 3), round(k[0][1], 3), round(k[0][2], 3),
                  round(k[1][0], 3), round(k[1][1], 3), round(k[1][2], 3)))
            edges[k] = edges.get(k, 0) + 1
    f.close()
    print('signed volume: %.1f mm3 (abs %.1f)' % (vol, abs(vol)))
    print('zero-normal facets: %d' % bad_normals)
    uniq = len(edges)
    c1 = sum(1 for v in edges.values() if v == 1)
    c2 = sum(1 for v in edges.values() if v == 2)
    c3 = sum(1 for v in edges.values() if v >= 3)
    print('unique edges: %d | count==1 (OPEN): %d | count==2 (ok): %d | count>=3: %d' % (uniq, c1, c2, c3))
    if c1 == 0 and c3 == 0:
        print('RESULT: WATERTIGHT (замкнут)')
    else:
        print('RESULT: NOT watertight — %d open edges, %d multi-shared' % (c1, c3))
        # топ-примеры открытых рёбер
        ex = [k for k, v in edges.items() if v == 1][:5]
        for k in ex:
            print('   open edge: (%.2f,%.2f,%.2f) - (%.2f,%.2f,%.2f)' % (k[0][:3] + k[1][:3]))

if __name__ == '__main__':
    check(os.path.abspath(sys.argv[1]))
