// Юнит-тест «ручья»: fluidDripGuide3 (стекающая капля → ближайшее отверстие / край детали)
// Запуск: node tools\fdrip_test.js
'use strict';
const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const s1 = html.indexOf('function ftBuildTopo3');
const e1 = html.indexOf('// асинхронный расчёт топологии');
const s2 = html.indexOf('function fluidPointKind3');
const e2 = html.indexOf('function fluidDeposit3cell');
if (s1 < 0 || e1 < 0 || s2 < 0 || e2 < 0 || e1 <= s1 || e2 <= s2) { console.error('extract failed', s1, e1, s2, e2); process.exit(1); }
const core = html.slice(s1, e1) + '\n' + html.slice(s2, e2);

const VF_SURF = 1, VF_OUT = 2, FTK_SOLID = 0, FTK_CAV = 1, FTK_AIR = 2, FTK_PASS = 3;
globalThis.VF_SURF = VF_SURF; globalThis.VF_OUT = VF_OUT;
globalThis.FTK_SOLID = FTK_SOLID; globalThis.FTK_CAV = FTK_CAV;
globalThis.FTK_AIR = FTK_AIR; globalThis.FTK_PASS = FTK_PASS;
globalThis.THREE = { Vector3: class { constructor(x=0,y=0,z=0){this.x=x;this.y=y;this.z=z;} clone(){ return new globalThis.THREE.Vector3(this.x,this.y,this.z); } } };
globalThis.stlMesh3 = null; globalThis.stepBodies3 = [];
let drops3 = null;
Object.defineProperty(globalThis, 'drops3', { configurable: true, get: () => drops3 });
globalThis.fluidBarrier3 = null; globalThis.fluidClipPlanes3 = null;
globalThis.fluidBodyVisible3 = ()=>true; globalThis.fluidPointClipped3 = ()=>false; globalThis.fluidPointBarrier3 = ()=>false;
(0, eval)(core);

function makeBody(id, dims, fillFn, h = 1) {
  const [dx, dy, dz] = dims;
  const grid = new Uint8Array(dx * dy * dz);
  for (let k = 0; k < dz; k++) for (let j = 0; j < dy; j++) for (let i = 0; i < dx; i++) grid[(k * dy + j) * dx + i] = fillFn(i, j, k);
  return { id, grid, dims, mins: [0, 0, 0], h,
    box: { min: { x: 0, y: 0, z: 0 }, max: { x: dx * h, y: dy * h, z: dz * h },
      containsPoint(v) { return v.x >= 0 && v.x <= dx*h && v.y >= 0 && v.y <= dy*h && v.z >= 0 && v.z <= dz*h; } } };
}
const block = (i, j, k) => i >= 1 && i <= 10 && j >= 1 && j <= 10 && k >= 1 && k <= 10;
const blockWall = (i, j, k) => i === 1 || i === 10 || j === 1 || j === 10 || k === 1 || k === 10;
let pass = 0, fail = 0;
function ok(name, cond) { if (cond) { pass++; console.log('  OK   ' + name); } else { fail++; console.log('  FAIL ' + name); } }
const dropAt = (x, y, z) => ({ p: { x, y, z, clone: function () { return this; } } });
const W = (b, i, j, k) => [b.mins[0] + (i + 0.5) * b.h, b.mins[1] + (j + 0.5) * b.h, b.mins[2] + (k + 0.5) * b.h];

// модель: блок 1..10 с слепым вертикальным отверстием (x 5..6, z 5..6, y 4..10)
const hole = (i, j, k) => i >= 5 && i <= 6 && k >= 5 && k <= 6 && j >= 4 && j <= 10;
const A = makeBody(1, [12, 12, 12], (i, j, k) => hole(i, j, k) ? 2 : (!block(i, j, k) ? 2 : (blockWall(i, j, k) ? 1 : 0)));
A._ftopo = ftBuildTopo3(A);   // ftBuildTopo3 тоже нужен
drops3 = { cache: { token: 't', bodies: [A], h: 1 } };

// 1) капля на торце рядом с устьем (2 клетки от края канала) → цель = устье
{
  const d = dropAt(W(A, 3, 11, 5)[0], W(A, 3, 11, 5)[1], W(A, 3, 11, 5)[2]);
  const g = fluidDripGuide3(d);
  const [wx, , wz] = W(A, 5, 10, 5);
  ok('1: найдено устье канала', !!g);
  ok('1: цель = ячейка устья (5,10,5)', g && Math.abs(g.x - wx) < 1e-9 && Math.abs(g.z - wz) < 1e-9);
}
// 2) капля в середине плоского торца (дальше 15 мм от канала? здесь канал ближе → всё равно в канал)
{
  const d = dropAt(W(A, 2, 11, 2)[0], W(A, 2, 11, 2)[1], W(A, 2, 11, 2)[2]);
  const g = fluidDripGuide3(d);
  ok('2: найдена цель (устье)', !!g && g.x >= 4.5 && g.x <= 6.5 && g.z >= 4.5 && g.z <= 6.5);
}
// 3) блок БЕЗ отверстий: капля в центре торца → цель = ближайший край детали
{
  const B = makeBody(1, [12, 12, 12], (i, j, k) => !block(i, j, k) ? 2 : (blockWall(i, j, k) ? 1 : 0));
  B._ftopo = ftBuildTopo3(B);
  drops3 = { cache: { token: 't2', bodies: [B], h: 1 } };
  const d = dropAt(W(B, 2, 11, 2)[0], W(B, 2, 11, 2)[1], W(B, 2, 11, 2)[2]);
  const g = fluidDripGuide3(d);
  ok('3: цель найдена (край детали)', !!g);
  // ближайшие края: k=0 (2 клетки) и i=0 (2 клетки) — цель должна быть у края (координата ~0.5 или ~11.5)
  const atEdge = g && ((Math.abs(g.z - 0.5) < 0.01 || Math.abs(g.z - 11.5) < 0.01 || Math.abs(g.x - 0.5) < 0.01 || Math.abs(g.x - 11.5) < 0.01));
  ok('3: цель на краю детали', atEdge);
}
// 4) капля в центре большого плоского торца (блок 20×20, краёв >15мм, отверстий нет) → край
{
  const C = makeBody(1, [22, 22, 22], (i, j, k) => i >= 1 && i <= 20 && j >= 1 && j <= 20 && k >= 1 && k <= 20 ? (i === 1 || i === 20 || j === 1 || j === 20 || k === 1 || k === 20 ? 1 : 0) : 2);
  C._ftopo = ftBuildTopo3(C);
  drops3 = { cache: { token: 't3', bodies: [C], h: 1 } };
  const d = dropAt(W(C, 11, 21, 11)[0], W(C, 11, 21, 11)[1], W(C, 11, 21, 11)[2]);
  const g = fluidDripGuide3(d);
  ok('4: цель найдена', !!g);
  ok('4: цель у края (не в центре)', g && !(Math.abs(g.x - 11.5) < 5 && Math.abs(g.z - 11.5) < 5));
}
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
