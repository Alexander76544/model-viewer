// Симуляция динамики пула (fluidPoolTick3) — «столб потока»
'use strict';
const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const s1 = html.indexOf('function ftBuildTopo3');
const e1 = html.indexOf('// асинхронный расчёт топологии');
const s2 = html.indexOf('function fluidPoolTick3');
const e2 = html.indexOf('function fluidSpawnLeak3');
const core = html.slice(s1, e1) + '\n' + html.slice(s2, e2);
const VF_SURF = 1, VF_OUT = 2, FTK_SOLID = 0, FTK_CAV = 1, FTK_AIR = 2, FTK_PASS = 3;
globalThis.VF_SURF = VF_SURF; globalThis.VF_OUT = VF_OUT;
globalThis.FTK_SOLID = FTK_SOLID; globalThis.FTK_CAV = FTK_CAV;
globalThis.FTK_AIR = FTK_AIR; globalThis.FTK_PASS = FTK_PASS;
globalThis.THREE = { Vector3: class { constructor(x=0,y=0,z=0){this.x=x;this.y=y;this.z=z;} set(x,y,z){this.x=x;this.y=y;this.z=z;return this;} } };
globalThis.stlMesh3 = null; globalThis.stepBodies3 = [];
let drops3 = null;
Object.defineProperty(globalThis, 'drops3', { configurable: true, get: () => drops3 });
const FL_FILL_RATE3 = 2.2, FL_DRAIN_RATE3 = 9000;
globalThis.FL_FILL_RATE3 = FL_FILL_RATE3; globalThis.FL_DRAIN_RATE3 = FL_DRAIN_RATE3;
globalThis.fluidMsg3 = () => {};
let leaks = 0;
globalThis.fluidSpawnLeak3 = (pool, oi, vol) => { leaks++; };
globalThis.fluidBarrier3 = null; globalThis.fluidClipPlanes3 = null;
globalThis.fluidBodyVisible3 = ()=>true; globalThis.fluidPointClipped3 = ()=>false; globalThis.fluidPointBarrier3 = ()=>false;
(0, eval)(core);

const H = 0.5, DX = 203;
const grid = new Uint8Array(DX*DX*DX);
const inBlock = (x,y,z) => x>=0 && x<=100 && y>=0 && y<=100 && z>=0 && z<=100;
const inHoleA = (x,y,z) => x>=45 && x<=55 && y>=50 && y<=100 && z>=45 && z<=55;
const inHoleB = (x,y,z) => x>=70 && x<=80 && y>=0 && y<=100 && z>=70 && z<=80;
for(let k=0;k<DX;k++) for(let j=0;j<DX;j++) for(let i=0;i<DX;i++){
  const x=-H+(i+0.5)*H, y=-H+(j+0.5)*H, z=-H+(k+0.5)*H;
  const idx=(k*DX+j)*DX+i;
  if(!inBlock(x,y,z)){ grid[idx]=2; continue; }
  if(inHoleA(x,y,z) || inHoleB(x,y,z)){ grid[idx]=2; continue; }
  const ds = Math.min(x,100-x,y,100-y,z,100-z);
  grid[idx] = ds < H ? 1 : 0;
}
const body = { id:-1, grid, dims:[DX,DX,DX], mins:[-H,-H,-H], h:H, box:{ containsPoint:()=>true } };
body._ftopo = ftBuildTopo3(body);
drops3 = { cache: { token:'t', bodies:[body], h:H } };

function mkPool(regionIdx){
  const region = body._ftopo.regions[regionIdx];
  const cap = ftCapForRegion3(body, region);
  const slotOf = new Map(); region.order.forEach((s,t)=>slotOf.set(s,t));
  return { body, regionIdx:regionIdx, region, h:H, h3:H**3, drops:[], depositedVox:0, curVox:0, drainedVox:0,
           leakAcc:0, lastDropVox:1, pourAcc:0, inflowEMA:0, capJ:cap.capJ, capVox:cap.capVox, sealed:cap.sealed,
           openUnsealed:cap.openUnsealed, leakPts:cap.leakPts, sealT:0, vol:0, full:false, dirty:false };
}
let pass=0, fail=0;
const ok=(n,c)=>{ if(c){pass++;console.log('  OK   '+n);} else {fail++;console.log('  FAIL '+n);} };

// регион 0 = слепое (y 102..201), регион 1 = сквозное (y 0..201) — сверим по minY
const blind = body._ftopo.regions.findIndex(r=>r.minY>50);
const thru = body._ftopo.regions.findIndex(r=>r.minY<=5);
ok('оба региона найдены', blind>=0 && thru>=0);

// --- сквозной: льём 3 см³ (3000 мм³ = 24000 vox), держим 1 с, потом перестали
{
  leaks = 0;
  const p = mkPool(thru);
  const dt = 1/60;
  for(let f=0; f<60; f++){   // литьё: +0.005 см³/кадр (50 мм³)
    p.depositedVox += 50/p.h3;
    p.lastDropVox = 50/p.h3;
    p.pourAcc += 50;
    fluidPoolTick3(p, dt);
  }
  const midVol = p.vol;
  ok('сквозное: во время литья уровень высокий (столб потока) >1 см³', midVol > 1.0);
  for(let f=0; f<300; f++) fluidPoolTick3(p, dt);   // 5 с после остановки
  ok('сквозное: после остановки уровень вытек (~0)', p.vol < 0.08);
  ok('сквозное: вытекло ~залитое', Math.abs(p.drainedVox*p.h3/1000 - (60*50)/1000) < 0.5);
  ok('сквозное: были капли-утечки', leaks > 20);
}
// --- слепое: льём 2 см³ (меньше объёма канала ~7 см³)
{
  leaks = 0;
  const p = mkPool(blind);
  const dt = 1/60;
  for(let f=0; f<60; f++){ p.depositedVox += 50/p.h3; p.lastDropVox = 50/p.h3; p.pourAcc += 50; fluidPoolTick3(p, dt); }   // всего 3 см³
  for(let f=0; f<120; f++) fluidPoolTick3(p, dt);
  ok('слепое: уровень стоит на залитом (~3 см³)', Math.abs(p.vol - 3.0) < 0.5);
  ok('слепое: утечек нет (не переполнено)', leaks === 0 && p.drainedVox === 0);
  // перелив: ещё 30 см³
  for(let f=0; f<600; f++){ p.depositedVox += 50/p.h3; p.lastDropVox = 50/p.h3; p.pourAcc += 50; fluidPoolTick3(p, dt); }
  ok('слепое: при переполнении канал полон', p.curVox >= p.region.total - 1);
  ok('слепое: избыток вытекает (uteчки есть)', leaks > 10 && p.drainedVox > 100);
}
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail?1:0);
