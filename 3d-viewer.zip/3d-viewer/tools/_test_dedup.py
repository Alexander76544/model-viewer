# -*- coding: utf-8 -*-
"""Прямой тест _dedup_faces на 770_1003014-10.stp: сколько граней уходит,
что остаётся (цвета), время."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import importlib.util
spec = importlib.util.spec_from_file_location(
    's2s', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'step2stl.py'))
s2s = importlib.util.module_from_spec(spec)
# не даём скрипту запустить main
os.environ.pop('S2S_SRC', None)
spec.loader.exec_module(s2s)

from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.XCAFDoc import XCAFDoc_DocumentTool, XCAFDoc_ColorSurf, XCAFDoc_ColorGen, XCAFDoc_ColorCurv
from OCP.Quantity import Quantity_ColorRGBA
from OCP.TopoDS import TopoDS
from OCP.TopLoc import TopLoc_Location
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE
from OCP.TopExp import TopExp_Explorer
try:
    from OCP.TDF import TDF_LabelSequence as LSeq
except Exception:
    from OCP.collections import Sequence_TDF_Label as LSeq

src = os.path.abspath(sys.argv[1])
doc = TDocStd_Document(TCollection_ExtendedString("XmlOcaf"))
reader = STEPCAFControl_Reader()
assert reader.ReadFile(src) == 1
assert reader.Transfer(doc)
shp_tool = XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
col_tool = XCAFDoc_DocumentTool.ColorTool_s(doc.Main())
roots = LSeq()
shp_tool.GetFreeShapes(roots)
shp = shp_tool.GetShape_s(roots.Value(1))
solid = None
exp = TopExp_Explorer(shp, TopAbs_SOLID)
while exp.More():
    solid = TopoDS.Solid(exp.Current())
    exp.Next()

t0 = time.time()
skip, nrm, nfa = s2s._dedup_faces(solid)
t1 = time.time()
print('dedup: removed %d / %d faces in %.0fs (map extent=%s)' % (
    nrm, nfa, t1 - t0, skip.Extent() if skip is not None else None))

# что осталось — по цветам
def face_color(face):
    for _t in (XCAFDoc_ColorSurf, XCAFDoc_ColorGen, XCAFDoc_ColorCurv):
        try:
            key = face.Located(TopLoc_Location())
        except Exception:
            key = face
        try:
            c = Quantity_ColorRGBA()
            if col_tool.GetColor(key, _t, c):
                qq = c.GetRGB()
                return (round(qq.Red(), 2), round(qq.Green(), 2), round(qq.Blue(), 2))
        except Exception:
            continue
    return None

from collections import Counter
kept = Counter()
exp = TopExp_Explorer(solid, TopAbs_FACE)
while exp.More():
    f = TopoDS.Face(exp.Current())
    if skip is not None:
        try:
            if skip.Contains(f):
                exp.Next()
                continue
        except Exception:
            pass
    kept[face_color(f)] += 1
    exp.Next()
print('remaining faces: %d' % sum(kept.values()))
for col, c in kept.most_common(10):
    print('  %s : %d' % (col, c))
