// hit-test: каждый ключевой UI-элемент должен быть кликабелен (top-most в своей середине)
const PORT=9333;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function j(u){const r=await fetch(u);return r.json();}
function connect(wsUrl){const ws=new WebSocket(wsUrl);let id=0;const pend=new Map();ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&pend.has(m.id)){pend.get(m.id)(m);pend.delete(m.id);}};const send=(method,params={})=>new Promise(res=>{const i=++id;pend.set(i,res);ws.send(JSON.stringify({id:i,method,params}));});return{ws,send};}
async function ev(send,expr){const m=await send('Runtime.evaluate',{expression:expr,returnByValue:true,awaitPromise:true});if(m.result&&m.result.exceptionDetails)throw new Error('EXC '+JSON.stringify(m.result.exceptionDetails));return m.result&&m.result.result?m.result.result.value:undefined;}
(async()=>{
  const t=await j('http://127.0.0.1:'+PORT+'/json');
  const pg=t.find(x=>x.type==='page'&&x.webSocketDebuggerUrl);const{ws,send}=connect(pg.webSocketDebuggerUrl);await new Promise(r=>{ws.onopen=r;});
  await send('Runtime.enable'); await send('Page.enable');
  await send('Emulation.setDeviceMetricsOverride',{width:1600,height:900,deviceScaleFactor:1,mobile:false});
  await send('Page.navigate',{url:'http://127.0.0.1:4173/?model=770_1003011-101_asm_asm.stp'});
  for(let k=0;k<240;k++){const n=await ev(send,'(typeof stepBodies3!=="undefined" && lastStepRel3==="770_1003011-101_asm_asm.stp" && stepBodies3.filter(b=>b._mesh).length)||0');if(n>=100)break;await sleep(500);}
  await sleep(1500);
  await ev(send, `(()=>{ closeAllPanels2(); document.body.classList.remove('compact2'); return 1; })()`);
  await sleep(300);
  const res = await ev(send, `(()=>{
    const bad = [];
    const test = (sel, label)=>{
      const el = document.querySelector(sel); if(!el){ bad.push(label+': НЕТ ЭЛЕМЕНТА'); return; }
      const cs = getComputedStyle(el);
      if(cs.display==='none' || cs.visibility==='hidden'){ bad.push(label+': скрыт'); return; }
      const r = el.getBoundingClientRect();
      if(r.width<4 || r.height<4){ bad.push(label+': нулевой размер'); return; }
      const cx = r.x+r.width/2, cy = r.y+r.height/2;
      if(cx<0||cy<0||cx>innerWidth||cy>innerHeight){ bad.push(label+': вне экрана'); return; }
      const top = document.elementFromPoint(cx, cy);
      if(top && (el.contains(top) || top===el || (top.closest && top.closest(sel)===el))) return;
      bad.push(label+' перекрыт: '+(top? (top.id||top.className||top.tagName) : 'null'));
    };
    test('#stlUploadBtn','upload'); test('#compactBtn2','compact'); test('#helpBtn2','help');
    test('#rail2 .railBtn[data-p="apClip"]','rail-clip'); test('#rail2 .railBtn#railTreeBtn','rail-tree');
    test('#stepTreePanel .stepTreeRow','tree-row');
    test('#viewWheel','wheel'); test('#compass3','compass');
    test('#threeFloatBar .btn-mini','floatbtn');
    // панель поверх: открыть clip и проверить её заголовок + слайдер
    __openPanel2('apClip');
    test('#apClip .ap2-head','clip-head'); test('#clipPos','clip-slider'); test('#apClip .ap2-close','clip-close');
    const treeVis = (()=>{ const tp=document.getElementById('stepTreePanel').getBoundingClientRect(); const cp=document.getElementById('apClip').getBoundingClientRect();
      return !(tp.right>cp.left && tp.left<cp.right && tp.bottom>cp.top && tp.top<cp.bottom); })();
    if(!treeVis) bad.push('clip-панель перекрывает дерево');
    closeAllPanels2();
    return { bad, ok: bad.length===0 };
  })()`);
  console.log('HIT', JSON.stringify(res, null, 1));
  ws.close(); process.exit(res.ok?0:1);
})().catch(e=>{console.error('FAIL',e.message);process.exit(1);});
