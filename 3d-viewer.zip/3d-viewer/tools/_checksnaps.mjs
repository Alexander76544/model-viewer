// _checksnaps.mjs <manifest.json> — сводка по снапам
import fs from 'fs';
const man = JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
console.log('v:', man.v, 'bodies:', man.bodies.length);
let tot=0, kinds={}, minR=1e9, maxR=0, oob=0;
for(const b of man.bodies){
  if(!b.snaps) continue;
  for(const s of b.snaps){ tot++; kinds[s.k]=(kinds[s.k]||0)+1;
    minR=Math.min(minR,s.r); maxR=Math.max(maxR,s.r);
    if(b.bb){ const pad=s.r+2;
      if(s.x<b.bb[0]-pad||s.x>b.bb[3]+pad||s.y<b.bb[1]-pad||s.y>b.bb[4]+pad||s.z<b.bb[2]-pad||s.z>b.bb[5]+pad) oob++; }
  }
}
console.log('snaps:', tot, JSON.stringify(kinds), 'r:', minR.toFixed(2), '…', maxR.toFixed(2), 'вне bb:', oob);
const withS = man.bodies.filter(b=>b.snaps&&b.snaps.length);
console.log('тел со снапами:', withS.length);
if(withS[0]) console.log('пример:', JSON.stringify(withS[0].snaps.slice(0,2)), 'body', withS[0].name, 'bb', withS[0].bb&&withS[0].bb.map(x=>x.toFixed(1)).join(','));
process.exit(tot>0?0:0);
