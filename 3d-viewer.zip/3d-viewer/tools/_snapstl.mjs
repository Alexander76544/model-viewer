// _snapstl.mjs <dir.bodies> — снапы против реальных граней STL тела (ground truth)
import fs from 'fs'; import path from 'path';
const dir = process.argv[2];
const man = JSON.parse(fs.readFileSync(path.join(dir,'manifest.json'),'utf8'));
function readStlBounds(f){
  const buf = fs.readFileSync(f);
  const n = buf.readUInt32LE(80);
  let mn=[1e18,1e18,1e18], mx=[-1e18,-1e18,-1e18];
  for(let i=0;i<n;i++){
    const o = 84 + i*50;
    for(let v=0;v<3;v++){
      const bx = buf.readFloatLE(o+12+v*12), by=buf.readFloatLE(o+16+v*12), bz=buf.readFloatLE(o+20+v*12);
      if(bx<mn[0])mn[0]=bx; if(by<mn[1])mn[1]=by; if(bz<mn[2])mn[2]=bz;
      if(bx>mx[0])mx[0]=bx; if(by>mx[1])mx[1]=by; if(bz>mx[2])mx[2]=bz;
    }
  }
  return {mn,mx};
}
function distToBox(p,b){
  let d2=0;
  for(let k=0;k<3;k++){ const lo=b.mn[k], hi=b.mx[k];
    if(p[k]<lo) d2+=(lo-p[k])**2; else if(p[k]>hi) d2+=(p[k]-hi)**2; }
  return Math.sqrt(d2);
}
let tot=0, bad=0, worst=0, badBodies=0, nofile=0;
for(const b of man.bodies||[]){
  if(!b.snaps) continue;
  if(!b.file){ nofile++; continue; }
  const f = path.join(dir, b.file);
  if(!fs.existsSync(f)){ nofile++; continue; }
  const bb = readStlBounds(f);
  let badInBody=0;
  for(const s of b.snaps){
    tot++;
    const d = distToBox([s.x,s.y,s.z], bb);
    const tol = 2 + (s.h||0)*0 + s.r; // центр на середине высоты цилиндра — обязан быть внутри/у границ
    if(d > Math.max(3, s.r)){ bad++; badInBody++; worst=Math.max(worst,d); }
  }
  if(badInBody) badBodies++;
}
console.log(`v:${man.v} снапов ${tot}, вне своего STL: ${bad} (${badBodies} тел, max dist ${worst.toFixed(1)} мм), нет файла: ${nofile}`);
if(bad){
  for(const b of man.bodies||[]){
    if(!b.snaps||!b.file) continue;
    const f=path.join(dir,b.file); if(!fs.existsSync(f)) continue;
    const bb=readStlBounds(f);
    const s0=b.snaps.find(s=>distToBox([s.x,s.y,s.z],bb)>Math.max(3,s.r));
    if(s0){ console.log('пример:', b.name, 'stl bb', bb.mn.map(v=>v.toFixed(1)).join(), '→', bb.mx.map(v=>v.toFixed(1)).join(), 'snap', JSON.stringify(s0)); break; }
  }
}
process.exit(0);
