@echo off
rem STEP -> STL конвертер (см. step2stl.py)
rem usage: step2stl.bat input.stp output.stl [deflection]
set "FCMD=C:\Users\diibl\Downloads\FreeCAD_1.1.3-Windows-x86_64-py311\FreeCAD_1.1.3-Windows-x86_64-py311\bin\freecadcmd.exe"
if not exist "%FCMD%" (
  echo freecadcmd not found at "%FCMD%"
  echo install FreeCAD or edit FCMD path in this .bat
  exit /b 1
)
set "STEP2STL_IN=%~1"
set "STEP2STL_OUT=%~2"
if "%~3"=="" (set "STEP2STL_DEFL=0.5") else (set "STEP2STL_DEFL=%~3")
"%FCMD%" "%~dp0step2stl.py"
