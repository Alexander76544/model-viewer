# Extract standalone 3D viewer from pcdmis-generator-5.html
$ErrorActionPreference = 'Stop'
$src = 'C:\Workspace\3d\pcdmis-generator-5.html'
$dstDir = 'C:\Workspace\3d-viewer'
$dst = Join-Path $dstDir 'index.html'
New-Item -ItemType Directory -Force -Path $dstDir | Out-Null

$L = Get-Content $src
function Range([int]$a, [int]$b) { ($L[($a-1)..($b-1)] -join "`n") }

$head = Range 1 103

$bodyTop = @'
</head>
<body>
<div class="grid-bg"></div>
<header>
  <div class="header-top">
    <div class="brand">
      <div class="brand-icon">◈</div>
      <div>
        <h1>3D-ПРОСМОТР ПРОГРАММ PC-DMIS</h1>
        <p id="statusLine">без названия · 0 элем. · 0 размеров</p>
      </div>
    </div>
    <div class="row" style="align-items:center;">
      <span id="autosaveIndicator" style="font-size:10.5px; color:var(--muted2); opacity:0.45; margin-right:6px; transition:opacity .3s;">автосохранение включено</span>
      <button class="btn" id="clearAutosaveBtn" title="Удалить автосохранение браузера (программы и 3D-модель)">🗑</button>
    </div>
  </div>
  <div id="projectTabsBar" style="display:flex; align-items:center; gap:6px; padding:8px 20px; border-top:1px solid var(--border); overflow-x:auto; max-width:1180px; margin:0 auto;"></div>
</header>
<main>
  <!-- IMPORT -->
  <div class="hint" style="max-width:840px;">Откройте .txt программы PC-DMIS — элементы, размеры и допуски будут разобраны и показаны в 3D-сцене ниже
    (номинал — голубым, факт — янтарным, с линиями отклонения). Каждый файл — своя вкладка операции вверху;
    чекбокс «Показать все операции вместе» рисует их в одной сцене. STL/OBJ/STEP детали — кнопкой «⬆ Загрузить» над сценой.</div>
  <div class="dim-card" style="max-width:840px; margin-bottom:18px;">
    <input type="file" id="importFileInput" accept=".txt,text/plain" multiple
      style="color:var(--muted);font-size:12px;margin-bottom:10px;">
    <div id="importFileList"></div>
    <hr class="sep">
    <details>
      <summary style="cursor:pointer; font-size:12px; color:var(--muted2);">...или вставьте текст программы</summary>
      <textarea class="output mono" id="importPasteArea" style="height:160px; margin-top:10px;" placeholder="Вставьте содержимое .txt файла PC-DMIS сюда"></textarea>
      <div style="margin-top:10px;">
        <button class="btn primary" id="importPasteBtn">⇩ Разобрать и загрузить вставленный текст</button>
      </div>
    </details>
    <div id="importSummary" style="max-width:760px; margin-top:10px;"></div>
  </div>
'@

$sceneSection = Range 253 402
$modelBrowser = Range 461 472
$threeJs = Range 474 482

$refreshStatus = @'
// ---------------- status line (simplified: no editor validation panel here) ----------------
function refreshStatus(){
  const line = document.getElementById("statusLine");
  if(!line) return;
  line.textContent = `${state.name} · ${state.header.partName || "без названия"} · ${state.elements.length} элем. · ${state.dimensions.length} размеров`;
}
'@

$initBlock = @'
// ---- init ----
tryRestoreAutosave();
renderProjectTabs();
refreshStatus();
refreshGroupFilter();
renderThreeViewButtons();
initThree();
rebuildElementsGroup3();
setTimeout(()=>{ onThreeResize3(); focusCamera3(); restoreModelFromAutosave(); }, 80);
'@

$js = @(
  (Range 552 674),
  (Range 676 678),
  (Range 701 714),
  (Range 859 865),
  (Range 945 1442),
  (Range 2677 2688),
  $refreshStatus,
  (Range 2737 2762),
  (Range 3193 3389),
  (Range 3558 5240),
  (Range 5242 5367),
  (Range 5369 5369),
  $initBlock
) -join "`n"

$parts = @($head, $bodyTop, $sceneSection, '</main>', '', $modelBrowser, '', $threeJs, '', '<script>', $js, '</script>', '</body>', '</html>')
$html = $parts -join "`n"

# ---------- targeted edits ----------
function ApplyEdit([string]$name, [string[]]$oldLines, [string[]]$newLines){
  $oldTxt = $oldLines -join "`n"
  $newTxt = if($newLines){ $newLines -join "`n" } else { '' }
  $cnt = ([regex]::Matches($script:html, [regex]::Escape($oldTxt))).Count
  if($cnt -ne 1){ throw "edit '$name': expected 1 match, got $cnt" }
  $script:html = $script:html.Replace($oldTxt, $newTxt)
}

# E1: switchProject — drop editor renders
ApplyEdit 'switchProject' @(
'  renderProjectTabs();',
'  renderHeaderTab();',
'  renderElementsList();',
'  renderDimensionsList();',
'  renderTrendPartsList();',
'  renderTrendDimList();',
'  renderTrendChart();',
'  refreshStatus();',
'  renderOutput();',
'  refreshGroupFilter();',
'  refreshThreeIfNeeded();'
) @(
'  renderProjectTabs();',
'  refreshStatus();',
'  refreshGroupFilter();',
'  refreshThreeIfNeeded();',
'  scheduleAutosave();'
)

# E2: start with an empty scene
ApplyEdit 'empty-initial' @(
'state.elements = [newElement("plane")];',
'state.elements[0].name = "PL1_1";'
) @('state.elements = [];')

# E3: applyParsed — drop editor renders, persist import
ApplyEdit 'applyParsed' @(
'  renderProjectTabs();',
'  renderHeaderTab();',
'  renderElementsList();',
'  renderDimensionsList();',
'  renderTrendPartsList();',
'  renderTrendDimList();',
'  refreshStatus();',
'  renderOutput();',
'  refreshGroupFilter();',
'  refreshThreeIfNeeded();   // если вкладка 3D уже открыта — перестроить сцену из импортированных элементов'
) @(
'  renderProjectTabs();',
'  refreshStatus();',
'  refreshGroupFilter();',
'  refreshThreeIfNeeded();   // перестроить 3D-сцену из импортированных элементов',
'  scheduleAutosave();'
)

# E4: import summary button -> scroll to the scene
ApplyEdit 'import-summary-btn' @(
'    (()=>{ const b=el("button",{class:"btn primary",onClick:()=>{ document.querySelector(''nav.tabs button[data-tab="elements"]'').click(); }},["Перейти к элементам →"]); return b; })()'
) @(
'    (()=>{ const b=el("button",{class:"btn primary",onClick:()=>{ document.getElementById(''threeContainer'').scrollIntoView({behavior:"smooth", block:"center"}); }},["Смотреть в 3D ↓"]); return b; })()'
)

# E5: mirrorActiveProject — update 3D instead of editor tables
ApplyEdit 'mirror' @(
'  renderElementsList(); renderDimensionsList(); refreshStatus(); renderOutput();'
) @(
'  refreshStatus(); refreshGroupFilter(); refreshThreeIfNeeded(); scheduleAutosave();'
)

# E6: drop jump-to-editor-table plumbing from selectElementInScene
ApplyEdit 'selectElementInScene' @(
'  renderElementSidebarList();',
'  const found = findElementById(id);',
'  if(found && found.projectIndex===activeProjectIndex && !found.el.open){ found.el.open = true; renderElementsList(); }',
'}',
'',
'function jumpToElementInTable(id){',
'  const found = findElementById(id);',
'  if(!found) return;',
'  if(found.projectIndex !== activeProjectIndex) switchProject(found.projectIndex);',
'  document.querySelector(''nav.tabs button[data-tab="elements"]'').click();',
'  setTimeout(()=>{',
'    if(!found.el.open){ found.el.open = true; renderElementsList(); }',
'    setTimeout(()=>{',
'      const cardEl = document.getElementById(''elcard-''+found.el.id);',
'      if(cardEl){ cardEl.scrollIntoView({behavior:''smooth'', block:''center''}); cardEl.style.outline = ''2px solid #22d3ee''; setTimeout(()=>{ cardEl.style.outline=''''; }, 1500); }',
'    }, 60);',
'  }, 60);',
'}'
) @(
'  renderElementSidebarList();',
'}'
)

# E7: sidebar "open in table" button is gone
ApplyEdit 'sidebar-btn' @(
'    if(!elData.factSameAsNominal) row.appendChild(el("span",{style:"color:#f59e0b; font-size:10px;"},["●"]));',
'    row.appendChild(el("button",{class:"btn ghost", style:"padding:2px 5px; font-size:10px;", title:"Открыть в таблице элементов",',
'      onClick:()=> jumpToElementInTable(elData.id)',
'    },["▤"]));'
) @(
'    if(!elData.factSameAsNominal) row.appendChild(el("span",{style:"color:#f59e0b; font-size:10px;"},["●"]));'
)

# E8: rename storage keys so the viewer never clobbers the generator's autosave
$renames = @{
  "'pcdmis_generator_autosave_v2'" = "'pcdmis_3d_viewer_autosave_v1'";
  "'pcdmis_generator_autosave_v1'" = "'pcdmis_3d_viewer_autosave_v0'";
  "'pcdmis_model_autosave_v1'"     = "'pcdmis_3d_viewer_model_v1'";
  "'pcdmis.gridVisible'"           = "'pcdmis3d.gridVisible'";
  "'pcdmis.zeroPoint'"             = "'pcdmis3d.zeroPoint'"
}
foreach($k in $renames.Keys){
  $cnt = ([regex]::Matches($html, [regex]::Escape($k))).Count
  if($cnt -lt 1){ throw "rename '$k': not found (got $cnt)" }
  $html = $html.Replace($k, $renames[$k])
}

# E9: section class (no tab system anymore) + title + drop dead nav CSS
$html = $html.Replace('<section class="tabpanel" id="tab-model">', '<section id="tab-model">')
$html = $html.Replace('<title>Генератор программ PC-DMIS</title>', '<title>3D-просмотр программ PC-DMIS</title>')
$navCss = @(
'  nav.tabs{max-width:1180px;margin:0 auto;padding:0 20px;display:flex;gap:2px;}',
'  nav.tabs button{background:none;border:none;border-bottom:2px solid transparent;color:var(--muted2);',
'    font-size:12.5px;padding:10px 14px;cursor:pointer;display:flex;align-items:center;gap:6px;transition:.15s;}',
'  nav.tabs button:hover{color:#c3ccd9;}',
'  nav.tabs button.active{color:var(--cyan);border-bottom-color:var(--cyan);}'
) -join "`n"
$cnt = ([regex]::Matches($html, [regex]::Escape($navCss))).Count
if($cnt -ne 1){ throw "edit 'nav-css': expected 1 match, got $cnt" }
$html = $html.Replace($navCss, '')

# ---------- leftover-reference guard ----------
$forbidden = @(
  'renderHeaderTab(','renderElementsList(','renderDimensionsList(','renderTrendPartsList(','renderTrendDimList(',
  'renderTrendChart(','renderOutput(','validateProject(','getOcrWorkerCount(','nav.tabs button','data-tab=','openPartReport(',
  'headerFields','elementAddButtons','outputText','jumpToElementInTable'
)
foreach($f in $forbidden){
  if($html.Contains($f)){ throw "forbidden leftover: $f" }
}

$enc = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($dst, $html, $enc)
Write-Output ("WROTE {0} ({1:N0} bytes)" -f $dst, (Get-Item $dst).Length)
