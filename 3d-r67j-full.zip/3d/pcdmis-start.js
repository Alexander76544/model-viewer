/* r67e - стартовый интерфейс как в PC-DMIS + меню «CAD / 3D» со всеми функциями 3D.
   При запуске: окно «Открыть программу детали» (Новая… / Открыть… / Импорт CAD… / список операций),
   окно «Новая программа детали» (Имя детали, Ревизия, Серийный №, Единицы, Интерфейс),
   затем главное окно: Окно редактирования слева + Окно графического отображения (3D) + строка состояния. */
(function(){
  'use strict';
  var W = window, LS = 'pcd67start';
  function $(id){ return document.getElementById(id); }
  function act(k){ try { W.pcdAct(k); } catch(e){ console.warn(e); } }
  function click(id){ var b = $(id); if (b){ b.click(); return true; } return false; }
  function say(m){ try { toast(m); } catch(e){ console.log(m); } }
  function S(){ try { return state; } catch(e){ return null; } }
  function P(){ try { return projects; } catch(e){ return []; } }
  function esc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
  function cfg(){ try { return JSON.parse(localStorage.getItem(LS)) || {}; } catch(e){ return {}; } }
  function save(c){ try { localStorage.setItem(LS, JSON.stringify(c)); } catch(e){} }

  var css = [
    '/* r67h: плавающие кнопки дублируют меню «CAD / 3D» и накладывались на панели 3D — скрыты */',
    '#p67fxBar,#p67hitsFab,#p66qfFab{display:none!important}',
    '#p67ov{position:fixed;inset:0;background:rgba(40,48,60,.45);z-index:100000;display:flex;align-items:center;justify-content:center;font:12px Segoe UI,Tahoma,sans-serif;color:#1c2128}',
    '.p67w{background:#f0f0f0;border:1px solid #7a8594;box-shadow:0 10px 40px rgba(0,0,0,.35);min-width:560px;max-width:760px}',
    '.p67t{background:linear-gradient(#2f6ea8,#245a8c);color:#fff;padding:6px 10px;font-weight:600;display:flex;justify-content:space-between;align-items:center}',
    '.p67t b{cursor:pointer;padding:0 6px}',
    '.p67b{padding:12px;display:flex;gap:12px}',
    '.p67l{flex:1;background:#fff;border:1px solid #9aa4b1;height:260px;overflow:auto}',
    '.p67l div{padding:4px 8px;cursor:pointer;border-bottom:1px solid #eef0f3;display:flex;justify-content:space-between}',
    '.p67l div:hover,.p67l div.sel{background:#cfe3f7}',
    '.p67r{display:flex;flex-direction:column;gap:6px;width:200px}',
    '.p67r button,.p67f button{padding:5px 10px;border:1px solid #8a94a3;background:linear-gradient(#fdfdfd,#e3e6ea);cursor:pointer;text-align:left;font:12px Segoe UI,sans-serif}',
    '.p67r button:hover,.p67f button:hover{background:linear-gradient(#eaf3fc,#cfe3f7)}',
    '.p67f{padding:12px;display:grid;grid-template-columns:150px 1fr;gap:8px 10px;align-items:center}',
    '.p67f input,.p67f select{padding:3px 5px;border:1px solid #9aa4b1;font:12px Segoe UI,sans-serif}',
    '.p67foot{padding:8px 12px;border-top:1px solid #c9ced6;display:flex;justify-content:space-between;align-items:center}',
    '.p67foot .bt{display:flex;gap:6px}',
    '.p67foot button{padding:4px 16px;border:1px solid #8a94a3;background:linear-gradient(#fdfdfd,#e3e6ea);cursor:pointer}',
    '.p67logo{font-size:20px;font-weight:700;color:#245a8c;padding:4px 12px 0}',
    '.p67sub{color:#5a6472;padding:0 12px}'
  ].join('\n');

  function overlay(html){
    close();
    var o = document.createElement('div'); o.id = 'p67ov'; o.innerHTML = html;
    document.body.appendChild(o);
    o.addEventListener('keydown', function(e){ if (e.key === 'Escape') close(); });
    return o;
  }
  function close(){ var o = $('p67ov'); if (o) o.remove(); }

  /* ---------- главное окно (рабочее пространство PC-DMIS) ---------- */
  function workspace(){
    document.body.classList.add('pcdmis-skin');
    act('tab:model');
    var pane = $('pcdProgPane'); if (pane){ pane.style.display = ''; pane.classList.remove('min'); }
    try { renderOutput(); } catch(e){}
    status();
  }
  function status(){
    var s = S(), c = cfg(), el = $('p67stat');
    if (!el){ var bar = $('pcdStatus'); if (!bar) return; el = document.createElement('span'); el.className = 'c seg'; el.id = 'p67stat'; bar.insertBefore(el, bar.children[1] || null); }
    if (!s) return;
    var h = s.header || {};
    el.textContent = 'Готово · ' + (c.units || 'ММ') + ' · ' + (c.iface || 'Офлайн') + ' · ' + (h.partName || s.name || '') +
      (h.revision ? ' рев. ' + h.revision : '') + ' · элем. ' + (s.elements || []).length + ' · разм. ' + (s.dimensions || []).length +
      (W.__pcdFixture && W.__pcdFixture.mesh ? ' · оснастка' : '');
  }

  /* ---------- «Открыть программу детали» ---------- */
  function startDialog(){
    var ps = P(), c = cfg(), ai = 0; try { ai = activeProjectIndex; } catch(e){}
    var list = ps.map(function(p, i){
      var h = p.header || {};
      return '<div data-i="' + i + '"' + (i === ai ? ' class="sel"' : '') + '><span>' + esc(h.partName || p.name) + (p.name && p.name !== h.partName ? ' — ' + esc(p.name) : '') +
        '</span><span style="color:#7a828e">' + (p.elements || []).length + ' эл. / ' + (p.dimensions || []).length + ' р.</span></div>';
    }).join('') || '<div style="color:#888">нет программ</div>';
    var o = overlay('<div class="p67w" tabindex="0"><div class="p67t">Открыть программу детали<b data-x>✕</b></div>' +
      '<div class="p67logo">PC-DMIS · генератор программ</div><div class="p67sub">Выберите программу детали или создайте новую</div>' +
      '<div class="p67b"><div class="p67l" id="p67list">' + list + '</div><div class="p67r">' +
      '<button data-a="new">📄 Новая…  (Ctrl+N)</button>' +
      '<button data-a="open">📂 Открыть .PRG / .txt…</button>' +
      '<button data-a="cad">📥 Импорт CAD (.CAD / STEP / IGES)…</button>' +
      '<button data-a="stl">🧊 Импорт модели STL / OBJ…</button>' +
      '<button data-a="fix">🗜 Загрузить оснастку…</button>' +
      '<button data-a="res">📊 Импорт результатов…</button>' +
      '<hr style="width:100%;border:0;border-top:1px solid #c9ced6">' +
      '<button data-a="go">▶ Открыть выбранную</button>' +
      '</div></div><div class="p67foot"><label><input type="checkbox" id="p67show"' + (c.noStart ? '' : ' checked') + '> Показывать при запуске</label>' +
      '<div class="bt"><button data-a="go">ОК</button><button data-x>Отмена</button></div></div></div>');
    var sel = ai;
    o.querySelectorAll('#p67list div[data-i]').forEach(function(d){
      d.onclick = function(){ o.querySelectorAll('#p67list div').forEach(function(x){ x.classList.remove('sel'); }); d.classList.add('sel'); sel = +d.getAttribute('data-i'); };
      d.ondblclick = function(){ sel = +d.getAttribute('data-i'); run('go'); };
    });
    function run(a){
      var cc = cfg(); cc.noStart = !$('p67show').checked; save(cc);
      if (a === 'new') return newDialog();
      close(); workspace();
      if (a === 'go'){ try { if (sel !== ai) switchProject(sel); } catch(e){} workspace(); }
      else if (a === 'open'){ act('import'); }
      else if (a === 'cad'){ if (!click('p61Btn')) act('model'); }
      else if (a === 'stl'){ act('model'); }
      else if (a === 'fix'){ W.__pcdFixture && W.__pcdFixture.pick(); }
      else if (a === 'res'){ act('importres'); }
    }
    o.querySelectorAll('[data-a]').forEach(function(b){ b.onclick = function(){ run(b.getAttribute('data-a')); }; });
    o.querySelectorAll('[data-x]').forEach(function(b){ b.onclick = function(){ var cc = cfg(); cc.noStart = !$('p67show').checked; save(cc); close(); workspace(); }; });
    o.querySelector('.p67w').focus();
  }

  /* ---------- «Новая программа детали» ---------- */
  function newDialog(){
    var c = cfg();
    var o = overlay('<div class="p67w" tabindex="0"><div class="p67t">Новая программа детали<b data-x>✕</b></div><div class="p67f">' +
      '<label>Имя детали:</label><input id="p67pn" value="">' +
      '<label>Номер ревизии:</label><input id="p67rv">' +
      '<label>Серийный номер:</label><input id="p67sn">' +
      '<label>Единицы измерения:</label><select id="p67un"><option>ММ</option><option>ДЮЙМ</option></select>' +
      '<label>Интерфейс:</label><select id="p67if"><option>Офлайн</option><option>Машина (КИМ)</option></select>' +
      '<label>Модель CAD:</label><select id="p67cad"><option value="">— не загружать —</option><option value="cad">Импорт CAD (.CAD / STEP / IGES)…</option><option value="stl">STL / OBJ…</option></select>' +
      '<label>Оснастка:</label><select id="p67fx"><option value="">— нет —</option><option value="fx">Загрузить osnastka.stl + .qfxt.json…</option></select>' +
      '</div><div class="p67foot"><span style="color:#5a6472">Создаётся новая операция (программа детали)</span><div class="bt"><button data-ok>ОК</button><button data-x>Отмена</button></div></div></div>');
    $('p67un').value = c.units || 'ММ'; $('p67if').value = (c.iface || 'Офлайн').indexOf('Маш') === 0 ? 'Машина (КИМ)' : 'Офлайн';
    $('p67pn').focus();
    o.querySelector('[data-x]').onclick = startDialog;
    o.querySelectorAll('.p67foot [data-x]').forEach(function(b){ b.onclick = startDialog; });
    function ok(){
      var pn = $('p67pn').value.trim();
      if (!pn){ $('p67pn').style.borderColor = '#c00'; $('p67pn').focus(); return; }
      var cc = cfg(); cc.units = $('p67un').value; cc.iface = $('p67if').value; save(cc);
      var cad = $('p67cad').value, fx = $('p67fx').value;
      try {
        var p = addProject(pn);
        p.header = p.header || {}; p.header.partName = pn; p.header.revision = $('p67rv').value.trim(); p.header.orderNumber = $('p67sn').value.trim();
        p.units = cc.units === 'ДЮЙМ' ? 'INCH' : 'MM'; p.iface = cc.iface;
        try { switchProject(projects.length - 1); } catch(e){}
      } catch(e){ console.error(e); say('Не удалось создать программу: ' + e.message); }
      close(); workspace();
      if (cad === 'cad'){ if (!click('p61Btn')) act('model'); } else if (cad === 'stl') act('model');
      if (fx) setTimeout(function(){ W.__pcdFixture && W.__pcdFixture.pick(); }, cad ? 400 : 0);
      say('Программа детали «' + pn + '» создана');
    }
    o.querySelector('[data-ok]').onclick = ok;
    o.addEventListener('keydown', function(e){ if (e.key === 'Enter') ok(); });
  }

  /* ---------- меню «CAD / 3D» и пункты в «Файл» ---------- */
  var CAD_ITEMS = [
    ['Импорт CAD (.CAD / STEP / IGES / BREP)…', function(){ if (!click('p61Btn')) act('model'); }],
    ['Импорт модели STL / OBJ…', function(){ act('model'); }],
    ['Открыть программу .PRG (с касаниями)…', function(){ act('import'); }],
    null,
    ['Оснастка: загрузить (osnastka.stl + .qfxt.json)…  Ctrl+Shift+O', function(){ W.__pcdFixture && W.__pcdFixture.pick(); }],
    ['Оснастка: показать / скрыть', function(){ W.__pcdFixture && W.__pcdFixture.toggle(); }],
    ['Оснастка: прозрачность', function(){ var f = W.__pcdFixture; f && f.setOpacity(f.opacity > 0.6 ? 0.35 : (f.opacity > 0.3 ? 1 : 0.85)); }],
    ['Оснастка: строки LOAD_FIXTURE', function(){ W.__pcdFixture && W.__pcdFixture.exportText(); }],
    ['Quick Fixture — укладка детали…  Ctrl+Shift+F', function(){ if (W.pcdCadQuickFixture) W.pcdCadQuickFixture.open(); else click('p66qfFab'); }],
    null,
    ['Касания: показать / скрыть  Ctrl+Shift+H', function(){ W.prgHits && W.prgHits.toggle(); }],
    ['Касания: выгрузить (HIT/BASIC)…', function(){ W.prgHits && W.prgHits.exportText(); }],
    null,
    ['Извлечь фичи из CAD (Feature Tools)…', function(){ act('featuretools'); }],
    ['Тела модели (дерево)', function(){ act('rail:__tree'); }],
    ['Сечение', function(){ act('rail:apClip'); }],
    ['Замер (линейка)', function(){ act('rail:apMeasure'); }],
    null,
    ['Вписать в окно', function(){ act('view:fit'); }],
    ['Изометрия', function(){ act('view:iso'); }],
    ['Сверху (Z+)', function(){ act('view:top'); }],
    ['Спереди', function(){ act('view:front'); }],
    ['Твёрдое отображение', function(){ act('render:solid'); }],
    ['Каркас (Wireframe)', function(){ act('render:wire'); }],
    ['Рентген (X-Ray)', function(){ act('render:xray'); }]
  ];
  function si(text, fn){
    var s = document.createElement('span'); s.className = 'si p67mi';
    var m = text.split('  '); s.textContent = m[0];
    if (m[1]){ var k = document.createElement('span'); k.className = 'k'; k.textContent = m[1]; s.appendChild(k); }
    s.addEventListener('click', function(ev){ ev.stopPropagation(); try { document.querySelectorAll('.mi.open').forEach(function(x){ x.classList.remove('open'); }); } catch(e){} fn(); setTimeout(status, 300); });
    return s;
  }
  function menus(){
    var menu = $('pcdMenu'); if (!menu || $('p67cadMi')) return;
    var mi = document.createElement('span'); mi.className = 'mi'; mi.id = 'p67cadMi'; mi.appendChild(document.createTextNode('CAD / 3D'));
    var sub = document.createElement('span'); sub.className = 'sub';
    CAD_ITEMS.forEach(function(it){ sub.appendChild(it ? si(it[0], it[1]) : document.createElement('hr')); });
    mi.appendChild(sub);
    var ref = null; menu.querySelectorAll(':scope > .mi').forEach(function(m){ if (/^Измерение/.test(m.textContent)) ref = m; });
    menu.insertBefore(mi, ref ? ref.nextSibling : null);
    var file = menu.querySelector(':scope > .mi .sub');
    if (file){
      file.insertBefore(si('Открыть программу детали…  Ctrl+O', startDialog), file.firstChild);
      file.insertBefore(si('Новая программа детали…', newDialog), file.firstChild);
    }
    // стандартный пункт «Стартовый экран» теперь открывает окно как в PC-DMIS
    W.pcdHomeOpenOld = W.pcdHomeOpen; W.pcdHomeOpen = startDialog;
  }

  function init(){
    var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
    menus();
    document.addEventListener('keydown', function(e){
      if (e.ctrlKey && !e.shiftKey && e.code === 'KeyO'){ e.preventDefault(); startDialog(); }
    }, true);
    setInterval(status, 2000);
    var c = cfg();
    if (!c.noStart) setTimeout(startDialog, 600); else setTimeout(workspace, 600);
  }
  W.pcdStart = { open: startDialog, newProgram: newDialog, workspace: workspace, items: CAD_ITEMS };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function(){ setTimeout(init, 300); }); else setTimeout(init, 300);
})();
