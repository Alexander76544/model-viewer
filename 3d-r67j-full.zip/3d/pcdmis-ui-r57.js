/* r57: окна PC-DMIS «Автоэлемент», «Положение элемента», «Расстояние / Угол», DIMINFO и метки ID в 3D,
 * предпросмотр касаний, контекстное меню элемента в графике, F9 = правка выбранного элемента.
 * Компоновка окон — по мотивам PC-DMIS 2025 (DimensionSharedViews / Auto Feature), код свой.
 * Работает поверх pcdmis-generator-6.html (глобальные state, projects, THREE, scene3, camera3 ...). */
(function () {
  'use strict';
  if (window.__p57) return; window.__p57 = true;

  /* ---------------- доступ к приложению ---------------- */
  function S() { try { return state; } catch (e) { return null; } }
  function G(name) { try { return eval(name); } catch (e) { return undefined; } } // eslint-disable-line no-eval
  function $(id) { return document.getElementById(id); }
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function num(v, d) { var n = parseFloat(String(v == null ? '' : v).replace(',', '.')); return isFinite(n) ? n : (d === undefined ? 0 : d); }
  function f3(v) { var n = num(v, NaN); return isFinite(n) ? (Math.round(n * 1000) / 1000).toFixed(3) : ''; }
  function fs(v) { var n = num(v, NaN); return isFinite(n) ? String(Math.round(n * 1e6) / 1e6) : ''; }
  function newId() { try { return uid(); } catch (e) { return 'p57' + Math.random().toString(36).slice(2, 9); } }
  function icon(n) { try { return window.pcd25Icon ? window.pcd25Icon(n) : ''; } catch (e) { return ''; } }
  function refresh() {
    ['renderElementsList', 'renderDimensionsList', 'refreshStatus', 'renderOutput'].forEach(function (f) {
      try { var fn = G(f); if (typeof fn === 'function') fn(); } catch (e) { console.warn('p57 refresh', f, e); }
    });
    try { if (window.pcdRefreshProg) window.pcdRefreshProg(); } catch (e) {}
    diminfoDirty = true;
  }
  function toast(msg) {
    var t = $('p57Toast');
    if (!t) { t = document.createElement('div'); t.id = 'p57Toast'; document.body.appendChild(t); }
    t.innerHTML = msg; t.style.display = 'block';
    clearTimeout(toast._t); toast._t = setTimeout(function () { t.style.display = 'none'; }, 3500);
  }
  function elements() { var s = S(); return (s && s.elements) || []; }
  function dims() { var s = S(); return (s && s.dimensions) || []; }
  function elByName(n) { return elements().filter(function (e) { return e.name === n; })[0] || null; }
  function elById(id) { return elements().filter(function (e) { return e.id === id; })[0] || null; }
  function uniqueName(base, list) {
    var names = {}; list.forEach(function (x) { names[x.name] = 1; });
    if (!names[base]) return base;
    var m = /^(.*?)(\d+)$/.exec(base), stem = m ? m[1] : base + '_', i = m ? +m[2] : 1;
    while (names[stem + i]) i++;
    return stem + i;
  }
  function nextName(prefix, list) {
    var mx = 0, re = new RegExp('^' + prefix + '(\\d+)$');
    list.forEach(function (x) { var m = re.exec(x.name || ''); if (m) mx = Math.max(mx, +m[1]); });
    return prefix + (mx + 1);
  }

  /* ---------------- стили ---------------- */
  var css = [
    '.p57w{position:fixed;z-index:960;background:#f0f0f0;border:1px solid #7a7a7a;box-shadow:0 6px 24px rgba(0,0,0,.35);font:12px "Segoe UI",Tahoma,sans-serif;color:#000;display:flex;flex-direction:column;min-width:300px;}',
    '.p57w.act{border-color:#1883d7;box-shadow:0 8px 30px rgba(0,0,0,.4);}',
    '.p57hd{height:28px;display:flex;align-items:center;gap:6px;padding-left:8px;background:#fff;cursor:move;user-select:none;flex:none;}',
    '.p57w.act .p57hd{background:#fff;}',
    '.p57hd svg{width:16px;height:16px;}',
    '.p57hd .t{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
    '.p57hd .x{width:44px;height:28px;display:flex;align-items:center;justify-content:center;font-size:14px;cursor:default;}',
    '.p57hd .x:hover{background:#e81123;color:#fff;}',
    '.p57bd{padding:8px 10px;overflow:auto;flex:1;}',
    '.p57ft{display:flex;gap:6px;justify-content:flex-end;align-items:center;padding:8px 10px;border-top:1px solid #dadada;flex:none;}',
    '.p57ft .sp{flex:1;}',
    '.p57w button.b{min-width:75px;height:23px;padding:0 10px;background:#e1e1e1;border:1px solid #adadad;font:12px "Segoe UI",Tahoma,sans-serif;color:#000;cursor:default;}',
    '.p57w button.b:hover{background:#e5f1fb;border-color:#0078d7;}',
    '.p57w button.b.def{border:2px solid #0078d7;padding:0 9px;}',
    '.p57w button.b:disabled{color:#a0a0a0;background:#f4f4f4;border-color:#cfcfcf;}',
    '.p57w button.s{min-width:24px;height:23px;padding:0 4px;}',
    '.p57w fieldset{border:1px solid #d5dfe5;margin:0 0 8px;padding:4px 8px 8px;}',
    '.p57w legend{padding:0 4px;color:#000;}',
    '.p57w input[type=text],.p57w select{height:21px;box-sizing:border-box;border:1px solid #7a7a7a;background:#fff;font:12px "Segoe UI",Tahoma,sans-serif;padding:0 4px;color:#000;}',
    '.p57w input[type=text]:focus,.p57w select:focus{border-color:#0078d7;outline:none;}',
    '.p57w input[type=text].n{width:84px;text-align:right;font-family:Consolas,monospace;}',
    '.p57w input[type=text]:disabled{background:#f0f0f0;color:#6d6d6d;border-color:#cccccc;}',
    '.p57w select[multiple]{height:auto;padding:0;}',
    '.p57w label{display:inline-flex;align-items:center;gap:3px;white-space:nowrap;}',
    '.p57types{display:flex;gap:2px;margin-bottom:8px;padding:2px;border:1px solid #d5dfe5;background:#fafafa;}',
    '.p57types button{width:30px;height:28px;border:1px solid transparent;background:transparent;display:flex;align-items:center;justify-content:center;}',
    '.p57types button:hover{background:#e5f1fb;border-color:#99d1ff;}',
    '.p57types button.on{background:#cce8ff;border-color:#99d1ff;}',
    '.p57types button svg{width:20px;height:20px;}',
    '.p57row{display:flex;align-items:center;gap:6px;margin-bottom:6px;}',
    '.p57grid{display:grid;grid-template-columns:auto 1fr 1fr;gap:3px 6px;align-items:center;}',
    '.p57grid .h{color:#444;font-weight:600;text-align:center;}',
    '.p57grid .l{text-align:right;color:#000;}',
    '.p57cols{display:flex;gap:10px;align-items:flex-start;}',
    '.p57axes{display:grid;grid-template-columns:repeat(3,auto);gap:4px 12px;justify-content:start;}',
    '.p57w input,.p57w select{border-radius:0 !important;box-shadow:none !important;}',
    '.p57di td.dn{text-align:left;background:#eef3f6;color:#333;font-family:"Segoe UI",Tahoma,sans-serif;}',
    '.p57tol{width:100%;border-collapse:collapse;}',
    '.p57tol th{background:#fff;border:1px solid #d5dfe5;font-weight:normal;color:#444;padding:2px 4px;}',
    '.p57tol td{border:1px solid #d5dfe5;padding:1px 2px;background:#fff;}',
    '.p57tol td input[type=text].n{width:100%;border:none;height:19px;}',
    '.p57muted{color:#6d6d6d;}',
    '.p57more{color:#0066cc;cursor:pointer;user-select:none;}',
    '#p57Toast{position:fixed;left:50%;bottom:48px;transform:translateX(-50%);background:#fff;border:1px solid #7a7a7a;box-shadow:0 4px 14px rgba(0,0,0,.3);padding:7px 14px;font:12px "Segoe UI",Tahoma,sans-serif;z-index:990;display:none;}',
    /* контекстное меню */
    '#p57Menu{position:fixed;z-index:995;background:#f0f0f0;border:1px solid #979797;box-shadow:2px 2px 6px rgba(0,0,0,.3);padding:2px;font:12px "Segoe UI",Tahoma,sans-serif;min-width:220px;display:none;}',
    '#p57Menu .i{display:flex;align-items:center;gap:8px;height:22px;padding:0 20px 0 6px;cursor:default;white-space:nowrap;}',
    '#p57Menu .i:hover{background:#91c9f7;}',
    '#p57Menu .i svg{width:16px;height:16px;}',
    '#p57Menu .hd{padding:3px 6px;color:#555;font-weight:600;border-bottom:1px solid #d7d7d7;margin-bottom:2px;}',
    '#p57Menu hr{border:none;border-top:1px solid #d7d7d7;margin:2px 0 2px 28px;}',
    /* DIMINFO / ID в графике */
    '#p57Ov{position:absolute;inset:0;pointer-events:none;z-index:6;overflow:hidden;}',
    '#p57Ov svg.ld{position:absolute;inset:0;width:100%;height:100%;}',
    '.p57lab{position:absolute;pointer-events:auto;background:#fff;border:1px solid #000;font:11px "Segoe UI",Tahoma,sans-serif;padding:0 4px;white-space:nowrap;cursor:move;color:#000;line-height:15px;}',
    '.p57lab.sel{background:#ffff9e;}',
    '.p57di{position:absolute;pointer-events:auto;background:#fff;border:1px solid #000;font:10.5px Consolas,"Courier New",monospace;color:#000;cursor:move;box-shadow:1px 1px 3px rgba(0,0,0,.25);}',
    '.p57di .ttl{background:#d5dfe5;font:600 11px "Segoe UI",Tahoma,sans-serif;padding:1px 5px;border-bottom:1px solid #000;white-space:nowrap;}',
    '.p57di .ttl.bad{background:#ff8080;}',
    '.p57di .ttl.ok{background:#9fe39f;}',
    '.p57di table{border-collapse:collapse;}',
    '.p57di th{font-weight:normal;color:#333;padding:0 4px;border-bottom:1px solid #aaa;text-align:right;}',
    '.p57di td{padding:0 4px;text-align:right;white-space:nowrap;}',
    '.p57di td.ax{text-align:left;font-weight:600;}',
    '.p57di td.bad{background:#ff8080;}',
    '.p57di td.warn{background:#ffff80;}',
    '.p57di td.ok{background:#b5f5b5;}',
    '.p57di .bar{display:inline-block;width:42px;height:7px;border:1px solid #444;position:relative;vertical-align:middle;background:linear-gradient(90deg,#ff8080 0 15%,#9fe39f 15% 85%,#ff8080 85%);}',
    '.p57di .bar i{position:absolute;top:-2px;width:2px;height:11px;background:#000;}',
    '#pcdViewsStrip3 .p57tg.on{background:#cce4f7 !important;border-color:#0078d7 !important;font-weight:600 !important;}'
  ].join('\n');
  var st = document.createElement('style'); st.id = 'p57css'; st.textContent = css; document.head.appendChild(st);

  /* ---------------- окно (немодальное, перетаскиваемое) ---------------- */
  var wins = {}, zTop = 960;
  function win(id, title, ic, width) {
    if (wins[id]) { front(wins[id]); return wins[id]; }
    var w = document.createElement('div'); w.className = 'p57w'; w.id = 'p57w_' + id;
    w.style.width = (width || 420) + 'px';
    w.innerHTML = '<div class="p57hd">' + icon(ic || 'feat') + '<span class="t"></span><span class="x" title="Закрыть"><svg width="10" height="10" viewBox="0 0 10 10"><path d="M0 0L10 10M10 0L0 10" stroke="currentColor" stroke-width="1.2"/></svg></span></div><div class="p57bd"></div><div class="p57ft"></div>';
    document.body.appendChild(w);
    var pos = null; try { pos = JSON.parse(localStorage.getItem('p57.pos.' + id) || 'null'); } catch (e) {}
    var W = window.innerWidth, H = window.innerHeight;
    var left = pos ? pos[0] : Math.max(10, (W - (width || 420)) / 2 + Object.keys(wins).length * 24);
    var top = pos ? pos[1] : Math.max(40, H * 0.12 + Object.keys(wins).length * 24);
    w.style.left = Math.min(Math.max(0, left), W - 120) + 'px'; w.style.top = Math.min(Math.max(0, top), H - 60) + 'px';
    var o = { id: id, el: w, body: w.querySelector('.p57bd'), foot: w.querySelector('.p57ft'), onClose: null };
    o.setTitle = function (t) { w.querySelector('.t').textContent = t; };
    o.close = function () { if (o.onClose) try { o.onClose(); } catch (e) {} w.remove(); delete wins[id]; };
    o.setTitle(title);
    w.querySelector('.x').addEventListener('click', o.close);
    w.addEventListener('mousedown', function () { front(o); }, true);
    w.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { e.stopPropagation(); o.close(); }
      if (e.key === 'Enter' && e.target.tagName === 'INPUT') { var d = w.querySelector('button.b.def'); if (d) { e.preventDefault(); d.click(); } }
    });
    var hd = w.querySelector('.p57hd');
    hd.addEventListener('mousedown', function (e) {
      if (e.target.closest('.x')) return;
      var sx = e.clientX, sy = e.clientY, l0 = w.offsetLeft, t0 = w.offsetTop;
      function mv(ev) { w.style.left = Math.max(-200, l0 + ev.clientX - sx) + 'px'; w.style.top = Math.max(0, t0 + ev.clientY - sy) + 'px'; }
      function up() { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up); try { localStorage.setItem('p57.pos.' + id, JSON.stringify([w.offsetLeft, w.offsetTop])); } catch (e) {} }
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up); e.preventDefault();
    });
    wins[id] = o; front(o);
    return o;
  }
  function front(o) {
    Object.keys(wins).forEach(function (k) { wins[k].el.classList.remove('act'); });
    o.el.style.zIndex = ++zTop; o.el.classList.add('act');
  }
  function btn(label, fn, cls) {
    var b = document.createElement('button'); b.className = 'b' + (cls ? ' ' + cls : ''); b.textContent = label; b.type = 'button';
    b.addEventListener('click', fn); return b;
  }
  function inp(v, cls) { var i = document.createElement('input'); i.type = 'text'; if (cls) i.className = cls; i.value = v == null ? '' : v; return i; }
  function sel(opts, v) {
    var s = document.createElement('select');
    opts.forEach(function (o) { var op = document.createElement('option'); if (Array.isArray(o)) { op.value = o[0]; op.textContent = o[1]; } else { op.value = op.textContent = o; } s.appendChild(op); });
    if (v != null) s.value = v; return s;
  }
  function h(tag, attrs, kids) {
    var e = document.createElement(tag);
    if (attrs) for (var k in attrs) { if (k === 'class') e.className = attrs[k]; else if (k === 'html') e.innerHTML = attrs[k]; else if (k === 'text') e.textContent = attrs[k]; else e.setAttribute(k, attrs[k]); }
    (kids || []).forEach(function (c) { if (c != null) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }

  /* ================= 1. АВТОЭЛЕМЕНТ ================= */
  var FT = [
    ['point_measured', 'Точка', 'point', 'PNT'], ['plane', 'Плоскость', 'plane', 'PLN'], ['circle', 'Окружность', 'circle', 'CIR'],
    ['cylinder', 'Цилиндр', 'cylinder', 'CYL'], ['cone', 'Конус', 'cone', 'CON'], ['sphere', 'Сфера', 'sphere', 'SPH'], ['ellipse', 'Эллипс', 'ellipse', 'ELL']
  ];
  function ftOf(t) { for (var i = 0; i < FT.length; i++) if (FT[i][0] === t) return FT[i]; return null; }
  var HAS_DIAM = { circle: 1, cylinder: 1, sphere: 1, ellipse: 1 };
  var HAS_HITS_ROWS = { cylinder: 1, cone: 1, sphere: 1, plane: 1 };
  var autoWin = null;

  window.pcdAutoFeatureOpen = function (arg) {
    var editing = null, type = 'circle';
    if (arg && typeof arg === 'object') editing = arg;
    else if (typeof arg === 'string') { var byId = elById(arg); if (byId) editing = byId; else type = arg; }
    if (editing) type = editing.type;
    if (!ftOf(type) && editing) { // типы без автоэлемента (построенные) — обычная вкладка
      try { jumpToElementInTable(editing.id); } catch (e) {}
      return;
    }
    if (!ftOf(type)) type = 'circle';
    var w = win('auto', '', 'feat', 470); autoWin = w;
    w.body.innerHTML = ''; w.foot.innerHTML = '';

    var model = editing ? JSON.parse(JSON.stringify(editing)) : (function () { var e = newElementSafe(type); e.name = nextName(ftOf(type)[3], elements()); return e; })();
    function setTitle() { w.setTitle('Автоэлемент [' + ftOf(model.type)[1] + ']' + (editing ? ' — ' + editing.name : '')); }

    // панель типов
    var types = h('div', { class: 'p57types' });
    FT.forEach(function (t) {
      var b = h('button', { type: 'button', title: t[1], html: icon(t[2]) });
      b.addEventListener('click', function () {
        if (editing && editing.type !== t[0] && !confirm('Сменить тип элемента «' + editing.name + '» на «' + t[1] + '»?')) return;
        model.type = t[0];
        if (!editing) model.name = nextName(t[3], elements());
        build();
      });
      b.dataset.t = t[0]; types.appendChild(b);
    });
    w.body.appendChild(types);
    var host = h('div'); w.body.appendChild(host);
    var F = {};

    function build() {
      setTitle();
      [].forEach.call(types.children, function (b) { b.classList.toggle('on', b.dataset.t === model.type); });
      host.innerHTML = ''; F = {};
      var groups = {}; elements().forEach(function (e) { if (e.group) groups[e.group] = 1; });
      F.name = inp(model.name); F.name.style.width = '150px';
      F.group = inp(model.group || ''); F.group.style.width = '150px'; F.group.setAttribute('list', 'p57grp');
      var dl = h('datalist', { id: 'p57grp' }); Object.keys(groups).forEach(function (g) { dl.appendChild(h('option', { value: g })); });
      host.appendChild(h('div', { class: 'p57row' }, [h('span', { text: 'ID элемента:' }), F.name, h('span', { text: 'Группа:', style: 'margin-left:8px' }), F.group, dl]));

      // свойства элемента: теор / факт
      var fsP = h('fieldset', {}, [h('legend', { text: 'Свойства элемента' })]);
      var g = h('div', { class: 'p57grid' }, [h('span'), h('span', { class: 'h', text: 'Теор.' }), h('span', { class: 'h', text: 'Факт' })]);
      function row(lbl, key, fkey) {
        F[key] = inp(fs(model[key]), 'n');
        F[fkey] = inp(model.factSameAsNominal ? '' : fs(model[fkey]), 'n');
        g.appendChild(h('span', { class: 'l', text: lbl })); g.appendChild(F[key]); g.appendChild(F[fkey]);
      }
      row('X', 'x', 'factX'); row('Y', 'y', 'factY'); row('Z', 'z', 'factZ');
      row('I', 'i', 'factI'); row('J', 'j', 'factJ'); row('K', 'k', 'factK');
      if (HAS_DIAM[model.type]) row('Диаметр', 'diam', 'factDiam');
      if (model.type === 'ellipse') row('Малый Ø', 'ellipseMinorDiam', 'factEllipseMinorDiam');
      if (model.type === 'cylinder') row('Длина', 'depth', 'factDepth');
      if (model.type === 'cone') { row('Ø 1', 'coneDiam1', 'factConeDiam1'); row('Ø 2', 'coneDiam2', 'factConeDiam2'); row('Угол', 'coneAngle', 'factConeAngle'); }
      fsP.appendChild(g);
      F.same = h('input', { type: 'checkbox' }); F.same.checked = model.factSameAsNominal !== false;
      var norm = btn('Нормализовать IJK', function () {
        var v = [num(F.i.value), num(F.j.value), num(F.k.value)], n = Math.hypot(v[0], v[1], v[2]) || 1;
        F.i.value = fs(v[0] / n); F.j.value = fs(v[1] / n); F.k.value = fs(v[2] / n); preview();
      }); norm.style.minWidth = '0';
      var flip = btn('Обратить вектор', function () { F.i.value = fs(-num(F.i.value)); F.j.value = fs(-num(F.j.value)); F.k.value = fs(-num(F.k.value)); preview(); });
      flip.style.minWidth = '0';
      fsP.appendChild(h('div', { class: 'p57row', style: 'margin:6px 0 0' }, [h('label', {}, [F.same, 'Факт = теор.']), h('span', { class: 'sp', style: 'flex:1' }), norm, flip]));
      function syncSame() { ['factX', 'factY', 'factZ', 'factI', 'factJ', 'factK', 'factDiam', 'factDepth', 'factEllipseMinorDiam', 'factConeDiam1', 'factConeDiam2', 'factConeAngle'].forEach(function (k) { if (F[k]) F[k].disabled = F.same.checked; }); }
      F.same.addEventListener('change', syncSame); syncSame();
      host.appendChild(fsP);

      // параметры касаний
      if (model.type !== 'point_measured') {
        var fsH = h('fieldset', {}, [h('legend', { text: 'Параметры касаний' })]);
        var gh = h('div', { class: 'p57grid', style: 'grid-template-columns:auto 1fr auto 1fr' });
        function hrow(lbl, key, lbl2, key2) {
          F[key] = inp(model[key], 'n'); gh.appendChild(h('span', { class: 'l', text: lbl })); gh.appendChild(F[key]);
          if (lbl2) { F[key2] = inp(model[key2], 'n'); gh.appendChild(h('span', { class: 'l', text: lbl2 })); gh.appendChild(F[key2]); }
          else { gh.appendChild(h('span')); gh.appendChild(h('span')); }
        }
        hrow('Касаний', 'points', HAS_HITS_ROWS[model.type] ? 'Рядов' : null, 'rows');
        if (model.type !== 'plane') hrow('Глубина', 'depthParam', model.type === 'cylinder' || model.type === 'cone' ? 'Отступ от конца' : null, 'finishOffset');
        if (model.type !== 'plane') hrow('Нач. угол', 'startAngle', 'Кон. угол', 'endAngle');
        fsH.appendChild(gh);
        if (model.type !== 'plane') {
          F.direction = sel(['ПРОТИВ ЧАСОВОЙ', 'ПО ЧАСОВОЙ'], model.direction || 'ПРОТИВ ЧАСОВОЙ');
          fsH.appendChild(h('div', { class: 'p57row', style: 'margin:6px 0 0' }, [h('span', { text: 'Направление:' }), F.direction]));
        }
        var strat = []; try { strat = (G('STRATEGIES') || {})[model.type] || []; } catch (e) {}
        if (strat.length) {
          F.strategy = sel(strat, model.strategy || strat[0]); F.strategy.style.maxWidth = '330px';
          fsH.appendChild(h('div', { class: 'p57row', style: 'margin:6px 0 0' }, [h('span', { text: 'Стратегия:' }), F.strategy]));
        }
        host.appendChild(fsH);
      }
      F.show = h('input', { type: 'checkbox' }); F.show.checked = localStorage.getItem('p57.hits') !== '0';
      F.show.addEventListener('change', function () { localStorage.setItem('p57.hits', F.show.checked ? '1' : '0'); preview(); });
      host.appendChild(h('div', { class: 'p57row' }, [h('label', { title: 'Показывать в графике теоретические касания и векторы подвода' }, [F.show, 'Показать касания в графике']),
        h('span', { class: 'p57muted', id: 'p57hitInfo', style: 'margin-left:auto' })]));

      [].forEach.call(host.querySelectorAll('input,select'), function (x) { x.addEventListener('input', preview); x.addEventListener('change', preview); });
      buildFoot();
      preview();
    }

    function collect(target) {
      var t = target || {};
      t.type = model.type;
      t.name = (F.name.value || '').trim() || model.name;
      t.group = (F.group.value || '').trim();
      ['x', 'y', 'z', 'i', 'j', 'k', 'diam', 'depth', 'ellipseMinorDiam', 'coneDiam1', 'coneDiam2', 'coneAngle', 'points', 'rows', 'depthParam', 'finishOffset', 'startAngle', 'endAngle'].forEach(function (k) {
        if (F[k]) t[k] = String(F[k].value).replace(',', '.').trim();
      });
      if (F.direction) t.direction = F.direction.value;
      if (F.strategy) t.strategy = F.strategy.value;
      t.factSameAsNominal = F.same.checked;
      ['factX', 'factY', 'factZ', 'factI', 'factJ', 'factK', 'factDiam', 'factDepth', 'factEllipseMinorDiam', 'factConeDiam1', 'factConeDiam2', 'factConeAngle'].forEach(function (k) {
        if (F[k]) t[k] = F.same.checked ? '' : String(F[k].value).replace(',', '.').trim();
      });
      return t;
    }
    function validate(t, selfId) {
      if (!t.name) return 'Укажите ID элемента';
      if (/\s/.test(t.name)) return 'ID не должен содержать пробелов';
      if (elements().some(function (e) { return e.name === t.name && e.id !== selfId; })) return 'Элемент с ID «' + t.name + '» уже есть';
      if (HAS_DIAM[t.type] && !(num(t.diam) > 0)) return 'Диаметр должен быть больше 0';
      return '';
    }
    function buildFoot() {
      w.foot.innerHTML = '';
      var list = elements(), idx = editing ? list.indexOf(editing) : -1;
      var prev = btn('<<', function () { if (idx > 0) window.pcdAutoFeatureOpen(list[idx - 1]); }, 's'); prev.title = 'Предыдущий элемент';
      var next = btn('>>', function () { if (idx >= 0 && idx < list.length - 1) window.pcdAutoFeatureOpen(list[idx + 1]); }, 's'); next.title = 'Следующий элемент';
      prev.disabled = !(idx > 0); next.disabled = !(idx >= 0 && idx < list.length - 1);
      w.foot.appendChild(prev); w.foot.appendChild(next);
      w.foot.appendChild(h('span', { class: 'sp' }));
      if (editing) {
        w.foot.appendChild(btn('Удалить', function () {
          if (!confirm('Удалить элемент «' + editing.name + '»?')) return;
          var s = S(); s.elements.splice(s.elements.indexOf(editing), 1);
          refresh(); toast('Элемент <b>' + esc(editing.name) + '</b> удалён'); w.close();
        }));
        w.foot.appendChild(btn('Размер…', function () { window.pcdLocationOpen([editing.name]); }));
        w.foot.appendChild(btn('ОК', function () {
          var t = collect({}), err = validate(t, editing.id); if (err) { toast(err); return; }
          var old = editing.name; for (var k in t) editing[k] = t[k];
          if (old !== editing.name) dims().forEach(function (d) { if (d.refElement === old) d.refElement = editing.name; if (d.refElement2 === old) d.refElement2 = editing.name; });
          refresh(); toast('Элемент <b>' + esc(editing.name) + '</b> обновлён'); setTitle();
        }, 'def'));
      } else {
        w.foot.appendChild(btn('Создать', function () {
          var t = collect(newElementSafe(model.type)), err = validate(t, null); if (err) { toast(err); return; }
          var s = S(); s.elements.push(t);
          refresh(); toast('Создан элемент <b>' + esc(t.name) + '</b>');
          model = JSON.parse(JSON.stringify(t)); model.name = nextName(ftOf(model.type)[3], elements()); build();
        }, 'def'));
      }
      w.foot.appendChild(btn('Закрыть', function () { w.close(); }));
    }
    w.onClose = function () { clearHits(); autoWin = null; };
    build();
    setTimeout(function () { try { F.name.focus(); F.name.select(); } catch (e) {} }, 20);
    function preview() {
      if (!F.show || !F.show.checked) { clearHits(); return; }
      var t = collect(JSON.parse(JSON.stringify(model)));
      var hits = hitsFor(t), info = $('p57hitInfo');
      if (info) info.textContent = hits.length ? 'касаний в графике: ' + hits.length : '';
      drawHits(hits, t);
    }
  };
  function newElementSafe(type) {
    try { var f = G('newElement'); if (typeof f === 'function') return f(type); } catch (e) {}
    return { id: newId(), type: type, name: 'EL', group: '', x: '0', y: '0', z: '0', i: '0', j: '0', k: '1', diam: '10', depth: '10', points: '4', rows: '3', depthParam: '2', finishOffset: '5', startAngle: '0', endAngle: '360', direction: 'ПРОТИВ ЧАСОВОЙ', factSameAsNominal: true, hasTarget: true, open: true };
  }

  /* -------- теоретические касания (по параметрам стратегии) -------- */
  function basis(n) {
    var a = Math.abs(n[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0];
    var u = cross(n, a); u = nrm(u); var v = cross(n, u);
    return [u, v];
  }
  function cross(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
  function nrm(a) { var l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; }
  function add(a, b, s) { return [a[0] + b[0] * s, a[1] + b[1] * s, a[2] + b[2] * s]; }
  function hitsFor(e) {
    var c = [num(e.x), num(e.y), num(e.z)], n = nrm([num(e.i), num(e.j), num(e.k, 1)]);
    if (!(Math.abs(n[0]) + Math.abs(n[1]) + Math.abs(n[2]))) n = [0, 0, 1];
    var B = basis(n), u = B[0], v = B[1], out = [];
    var N = Math.max(1, Math.min(400, Math.round(num(e.points, 4)))), R = Math.max(1, Math.min(50, Math.round(num(e.rows, 1))));
    var a0 = num(e.startAngle, 0), a1 = num(e.endAngle, 360), dir = e.direction === 'ПО ЧАСОВОЙ' ? -1 : 1;
    var full = Math.abs(Math.abs(a1 - a0) - 360) < 1e-6 || a1 === a0, span = a1 === a0 ? 360 : a1 - a0;
    function ring(center, r, cnt, inward) {
      for (var p = 0; p < cnt; p++) {
        var t = full ? p / cnt : (cnt === 1 ? 0.5 : p / (cnt - 1));
        var a = (a0 + span * t) * dir * Math.PI / 180, rad = add(add([0, 0, 0], u, Math.cos(a)), v, Math.sin(a));
        out.push({ p: add(center, rad, r), n: inward ? [-rad[0], -rad[1], -rad[2]] : rad });
      }
    }
    var dp = num(e.depthParam, 2);
    if (e.type === 'point_measured') out.push({ p: c, n: n });
    else if (e.type === 'circle' || e.type === 'ellipse') ring(add(c, n, -dp), num(e.diam, 10) / 2, N, false);
    else if (e.type === 'cylinder' || e.type === 'cone') {
      var L = Math.abs(num(e.depth, 10)), fo = num(e.finishOffset, 0), z0 = dp, z1 = Math.max(dp, L - fo);
      for (var r = 0; r < R; r++) {
        var d = R === 1 ? z0 : z0 + (z1 - z0) * r / (R - 1);
        var rr = e.type === 'cone' ? (num(e.coneDiam1, 10) + (num(e.coneDiam2, 30) - num(e.coneDiam1, 10)) * (L ? d / L : 0)) / 2 : num(e.diam, 10) / 2;
        ring(add(c, n, -d), rr, N, false);
      }
    } else if (e.type === 'sphere') {
      var rs = num(e.diam, 10) / 2; out.push({ p: add(c, n, rs), n: n });
      for (var q = 1; q <= R; q++) {
        var lat = (90 - 60 * q / R) * Math.PI / 180, cnt = N;
        ring(add(c, n, rs * Math.sin(lat)), rs * Math.cos(lat), cnt, false);
      }
    } else if (e.type === 'plane') {
      var side = Math.max(10, num(e.diam, 20)), per = Math.max(1, Math.ceil(N / R));
      for (var ri = 0; ri < R; ri++) for (var pi = 0; pi < per && out.length < N; pi++) {
        var su = R === 1 ? 0 : (ri / (R - 1) - 0.5) * side, sv = per === 1 ? 0 : (pi / (per - 1) - 0.5) * side;
        out.push({ p: add(add(c, u, sv), v, su), n: n });
      }
    }
    return out.slice(0, 2000);
  }
  var hitGroup = null;
  function clearHits() {
    try {
      if (hitGroup && hitGroup.parent) hitGroup.parent.remove(hitGroup);
      if (hitGroup) hitGroup.traverse(function (o) { if (o.geometry) o.geometry.dispose(); if (o.material) o.material.dispose(); });
    } catch (e) {}
    hitGroup = null;
  }
  function drawHits(hits, e) {
    clearHits();
    var THREE_ = window.THREE, scene = G('scene3'); if (!THREE_ || !scene || !hits.length) return;
    var tv = G('toThreeVec'), td = G('toThreeDir');
    if (typeof tv !== 'function') return;
    var size = Math.max(0.4, Math.min(3, num(e.diam, 10) / 25)), vlen = Math.max(2, Math.min(15, num(e.diam, 10) * 0.25));
    hitGroup = new THREE_.Group(); hitGroup.name = 'p57Hits';
    var geo = new THREE_.SphereGeometry(size, 10, 8), mat = new THREE_.MeshBasicMaterial({ color: 0xff7f00, depthTest: false, depthWrite: false, transparent: true, opacity: 1, fog: false, toneMapped: false });
    var lp = [], first = true;
    hits.forEach(function (hh) {
      var m = new THREE_.Mesh(geo, first ? new THREE_.MeshBasicMaterial({ color: 0x00c000, depthTest: false, depthWrite: false, transparent: true, opacity: 1, fog: false, toneMapped: false }) : mat); first = false;
      var P = tv(hh.p[0], hh.p[1], hh.p[2]); m.position.copy(P); m.renderOrder = 999; hitGroup.add(m);
      var D = td(hh.n[0], hh.n[1], hh.n[2]);
      lp.push(P, P.clone().addScaledVector(D, vlen));
    });
    var lg = new THREE_.BufferGeometry().setFromPoints(lp);
    var ls = new THREE_.LineSegments(lg, new THREE_.LineBasicMaterial({ color: 0xff7f00, depthTest: false, depthWrite: false, transparent: true, opacity: 1, fog: false, toneMapped: false })); ls.renderOrder = 998; hitGroup.add(ls);
    var eg = G('elementsGroup3');
    if (eg && eg.matrixWorld) { eg.updateMatrixWorld(); hitGroup.matrixAutoUpdate = false; hitGroup.matrix.copy(eg.matrixWorld); }
    scene.add(hitGroup);
  }

  /* ================= 2. ПОЛОЖЕНИЕ ЭЛЕМЕНТА (Feature Location) ================= */
  var AXES = [['X', 'X'], ['Y', 'Y'], ['Z', 'Z'], ['D', 'Диаметр'], ['R', 'Радиус'], ['L', 'Длина'], ['A', 'Угол'], ['PR', 'Полярн. радиус'], ['PA', 'Полярн. угол'], ['T', 'Вектор (T)'], ['H', 'Высота']];
  function defaultAxes(type) {
    if (type === 'circle' || type === 'cylinder' || type === 'sphere' || type === 'circle_constructed' || type === 'ellipse') return ['X', 'Y', 'Z', 'D'];
    if (type === 'cone') return ['X', 'Y', 'Z', 'A'];
    if (type === 'point_measured') return ['X', 'Y', 'Z', 'T'];
    return ['X', 'Y', 'Z'];
  }
  function nominalFor(e, ax) {
    if (!e) return '0';
    var x = num(e.x), y = num(e.y);
    switch (ax) {
      case 'X': return f3(e.x); case 'Y': return f3(e.y); case 'Z': return f3(e.z);
      case 'D': return f3(e.type === 'cone' ? e.coneDiam1 : e.diam); case 'R': return f3(num(e.type === 'cone' ? e.coneDiam1 : e.diam) / 2);
      case 'L': return f3(e.depth); case 'A': return f3(e.coneAngle || 0); case 'H': return f3(e.depth);
      case 'PR': return f3(Math.hypot(x, y)); case 'PA': return f3(Math.atan2(y, x) * 180 / Math.PI);
      default: return '0.000';
    }
  }
  function featureList(multi, onChange) {
    var wrap = h('div', { style: 'display:flex;flex-direction:column;gap:4px;width:180px;flex:none' });
    var q = inp(''); q.placeholder = 'Найти ID…';
    var lb = document.createElement('select'); if (multi) lb.multiple = true; lb.size = 15; lb.style.width = '100%'; lb.style.height = '260px';
    function fill() {
      var keep = {}; [].forEach.call(lb.selectedOptions || [], function (o) { keep[o.value] = 1; });
      lb.innerHTML = ''; var f = (q.value || '').toUpperCase();
      elements().forEach(function (e) {
        if (f && String(e.name).toUpperCase().indexOf(f) < 0) return;
        var o = document.createElement('option'); o.value = e.name; o.textContent = e.name; if (keep[e.name]) o.selected = true; lb.appendChild(o);
      });
    }
    q.addEventListener('input', fill); lb.addEventListener('change', function () { onChange && onChange(); });
    fill();
    wrap.appendChild(h('span', { text: multi ? 'Элементы (Ctrl — несколько):' : 'Элемент:' })); wrap.appendChild(q); wrap.appendChild(lb);
    return { el: wrap, list: lb, selected: function () { return [].map.call(lb.selectedOptions, function (o) { return o.value; }); },
      select: function (names) { [].forEach.call(lb.options, function (o) { o.selected = names.indexOf(o.value) >= 0; }); } };
  }
  function outputBlock(cur) {
    var fsO = h('fieldset', {}, [h('legend', { text: 'Вывод / анализ' })]);
    var out = sel([['ОБА', 'Оба'], ['СТАТИСТИКА', 'Статистика'], ['ОТЧЕТ', 'Отчёт'], ['НЕТ', 'Нет']], (cur && cur.out) || 'ОБА');
    var gr = h('input', { type: 'checkbox' }), tx = h('input', { type: 'checkbox' }), mult = inp((cur && cur.mult) || '10.00', 'n'); mult.style.width = '60px';
    gr.checked = !!(cur && cur.graph); tx.checked = !!(cur && cur.text);
    fsO.appendChild(h('div', { class: 'p57row' }, [h('span', { text: 'Вывод в:' }), out, h('label', { style: 'margin-left:8px' }, [gr, 'Графика']), h('label', {}, [tx, 'Текст']), h('span', { text: 'Множ.:' }), mult]));
    return { el: fsO, line: function (extra) {
      return 'ГРАФ.=' + (gr.checked ? 'ВКЛ' : 'ВЫКЛ') + '  ТЕКСТ=' + (tx.checked ? 'ВКЛ' : 'ВЫКЛ') + '  НЕСК.=' + (num(mult.value, 10)).toFixed(2) + '  ВЫВОД=' + out.value + (extra || '');
    } };
  }
  function parseOpt(line) {
    var o = {}; if (!line) return o;
    var m = /ВЫВОД=(\S+)/.exec(line); if (m) o.out = m[1];
    o.graph = /ГРАФ\.=ВКЛ/.test(line); o.text = /ТЕКСТ=ВКЛ/.test(line);
    m = /НЕСК\.=([\d.]+)/.exec(line); if (m) o.mult = m[1];
    return o;
  }

  window.pcdLocationOpen = function (preset, editDim) {
    var w = win('loc', editDim ? 'Положение элемента — ' + editDim.name : 'Положение элемента', 'dim', 680);
    w.body.innerHTML = ''; w.foot.innerHTML = '';
    var fl = featureList(!editDim, function () { onSel(); });
    var right = h('div', { style: 'flex:1;min-width:0' });
    w.body.appendChild(h('div', { class: 'p57cols' }, [fl.el, right]));

    var idIn = inp(editDim ? editDim.name : nextName('LOC', dims())); idIn.style.width = '140px';
    right.appendChild(h('div', { class: 'p57row' }, [h('span', { text: 'ID:' }), idIn,
      h('span', { class: 'p57muted', text: editDim ? '' : '(при нескольких элементах — LOC1, LOC2 …)' })]));

    var fsA = h('fieldset', {}, [h('legend', { text: 'Оси' })]), axBox = h('div', { class: 'p57axes' }), chk = {};
    AXES.forEach(function (a) { var c = h('input', { type: 'checkbox' }); chk[a[0]] = c; c.addEventListener('change', paintTol); axBox.appendChild(h('label', { title: a[1] }, [c, a[0] === a[1] ? a[0] : a[0] + ' — ' + a[1]])); });
    var defB = btn('По умолчанию', function () { setDefault(); }); defB.style.marginTop = '6px';
    fsA.appendChild(axBox); fsA.appendChild(defB); right.appendChild(fsA);

    var fsT = h('fieldset', {}, [h('legend', { text: 'Номиналы и допуски' })]);
    var allP = inp('0.1', 'n'), allM = inp('-0.1', 'n');
    fsT.appendChild(h('div', { class: 'p57row' }, [h('span', { text: 'Для всех осей: +' }), allP, h('span', { text: '−' }), allM,
      btn('Применить', function () { [].forEach.call(tolTb.querySelectorAll('tr[data-a]'), function (tr) { tr.querySelector('.p').value = allP.value; tr.querySelector('.m').value = allM.value; }); })]));
    var tolTb = h('table', { class: 'p57tol' }); fsT.appendChild(tolTb); right.appendChild(fsT);
    var opt = outputBlock(editDim ? parseOpt(editDim.optLine) : null); right.appendChild(opt.el);

    var tolMem = {};
    if (editDim) (editDim.axes || []).forEach(function (a) { tolMem[a.axis] = { nom: a.nominal, p: a.plusTol, m: a.minusTol }; });
    function firstEl() { var s = fl.selected(); return elByName(s[0]); }
    function paintTol() {
      [].forEach.call(tolTb.querySelectorAll('tr[data-a]'), function (tr) { tolMem[tr.dataset.a] = { nom: tr.querySelector('.nom').value, p: tr.querySelector('.p').value, m: tr.querySelector('.m').value, user: tr.dataset.user === '1' }; });
      var e = firstEl(), multi = fl.selected().length > 1;
      tolTb.innerHTML = '<tr><th>Ось</th><th>Номинал</th><th>+Доп</th><th>−Доп</th></tr>';
      AXES.forEach(function (a) {
        if (!chk[a[0]].checked) return;
        var mem = tolMem[a[0]] || {};
        var nom = inp((mem.user || editDim) && mem.nom != null ? mem.nom : nominalFor(e, a[0]), 'n nom'), p = inp(mem.p != null ? mem.p : allP.value, 'n p'), m = inp(mem.m != null ? mem.m : allM.value, 'n m');
        if (multi) { nom.disabled = true; nom.value = '(по элементу)'; }
        var tr = h('tr', { 'data-a': a[0] }, [h('td', { text: a[0] }), h('td', {}, [nom]), h('td', {}, [p]), h('td', {}, [m])]);
        if (mem.user) tr.dataset.user = '1';
        nom.addEventListener('input', function () { tr.dataset.user = '1'; });
        tolTb.appendChild(tr);
      });
    }
    function setDefault() {
      var e = firstEl(), d = defaultAxes(e ? e.type : 'circle');
      AXES.forEach(function (a) { chk[a[0]].checked = d.indexOf(a[0]) >= 0; });
      paintTol();
    }
    function onSel() {
      Object.keys(tolMem).forEach(function (k) { if (tolMem[k]) tolMem[k].user = false; });
      [].forEach.call(tolTb.querySelectorAll('tr[data-a]'), function (tr) { tr.dataset.user = ''; });
      if (!editDim && !idTouched) { var s = fl.selected(); idIn.value = nextName('LOC', dims()); }
      setDefaultIfEmpty(); paintTol();
      tolTb.querySelectorAll('tr[data-a]').forEach(function (tr) { if (!fl.selected().length) return; var e = firstEl(); if (e && !editDim) tr.querySelector('.nom').value = nominalFor(e, tr.dataset.a); });
    }
    function setDefaultIfEmpty() { if (!AXES.some(function (a) { return chk[a[0]].checked; })) setDefault(); }
    var idTouched = false; idIn.addEventListener('input', function () { idTouched = true; });

    if (editDim) {
      fl.select([editDim.refElement]);
      (editDim.axes || []).forEach(function (a) { if (chk[a.axis]) chk[a.axis].checked = true; });
      paintTol();
    } else {
      var pre = preset && preset.length ? preset : (function () { var id = G('selectedElementId'), e = id && elById(id); return e ? [e.name] : []; })();
      fl.select(pre);
      if (preset && preset.axes) AXES.forEach(function (a) { chk[a[0]].checked = preset.axes.indexOf(a[0]) >= 0; }); else setDefault();
      paintTol();
    }

    function axesFor(e) {
      var out = [];
      [].forEach.call(tolTb.querySelectorAll('tr[data-a]'), function (tr) {
        var a = tr.dataset.a, nomIn = tr.querySelector('.nom');
        var nom = nomIn.disabled ? nominalFor(e, a) : nomIn.value;
        var old = editDim && (editDim.axes || []).filter(function (x) { return x.axis === a; })[0];
        var ax = old || { id: newId(), axis: a };
        ax.nominal = String(nom).replace(',', '.'); ax.plusTol = String(tr.querySelector('.p').value).replace(',', '.'); ax.minusTol = String(tr.querySelector('.m').value).replace(',', '.');
        out.push(ax);
      });
      return out;
    }
    w.foot.appendChild(h('span', { class: 'sp' }));
    w.foot.appendChild(btn(editDim ? 'ОК' : 'Создать', function () {
      var names = fl.selected(); if (!names.length) { toast('Выберите элемент в списке'); return; }
      if (!tolTb.querySelector('tr[data-a]')) { toast('Отметьте хотя бы одну ось'); return; }
      var s = S(); s.dimensions = s.dimensions || [];
      if (editDim) {
        editDim.name = (idIn.value || '').trim() || editDim.name; editDim.refElement = names[0];
        editDim.axes = axesFor(elByName(names[0])); editDim.optLine = opt.line('  ПОЛОВИНА УГЛА=НЕТ'); editDim.rawBlock = null;
        refresh(); toast('Размер <b>' + esc(editDim.name) + '</b> обновлён'); return;
      }
      var made = [];
      names.forEach(function (n, i) {
        var e = elByName(n), nm = names.length === 1 ? ((idIn.value || '').trim() || nextName('LOC', s.dimensions)) : nextName('LOC', s.dimensions);
        if (s.dimensions.some(function (d) { return d.name === nm; })) nm = uniqueName(nm, s.dimensions);
        var d = { id: newId(), name: nm, dimType: 'ПОЛОЖЕНИЕ', refElement: n, refElement2: '', mod1: '', mod2: '', extraSuffix: '', axes: axesFor(e), optLine: opt.line('  ПОЛОВИНА УГЛА=НЕТ'), axisHeader: '', groupPath: e && e.group ? [e.group] : [] };
        s.dimensions.push(d); made.push(nm);
      });
      refresh(); toast('Создано размеров: ' + made.length + ' (' + esc(made.slice(0, 4).join(', ')) + (made.length > 4 ? '…' : '') + ')');
      idTouched = false; idIn.value = nextName('LOC', s.dimensions);
    }, 'def'));
    w.foot.appendChild(btn('Закрыть', function () { w.close(); }));
  };

  /* ================= 3. РАССТОЯНИЕ / УГОЛ / ОТНОСИТЕЛЬНЫЕ ================= */
  window.pcdDistanceOpen = function (kind, preset) {
    var KINDS = [['РАССТОЯНИЕ 2D', 'Расстояние 2D'], ['УГОЛ', 'Угол'], ['СООСНОСТЬ', 'Соосность'], ['КОНЦЕНТРИЧНОСТЬ', 'Концентричность'], ['ПАРАЛЛЕЛЬНОСТЬ', 'Параллельность'], ['ПЕРПЕНДИКУЛЯРНОСТЬ', 'Перпендикулярность']];
    var w = win('dist', 'Размер между элементами', 'dim', 640);
    w.body.innerHTML = ''; w.foot.innerHTML = '';
    var f1 = featureList(false, upd), f2 = featureList(false, upd);
    f1.el.firstChild.textContent = 'От элемента:'; f2.el.firstChild.textContent = 'Относительно:';
    var right = h('div', { style: 'flex:1;min-width:0' });
    w.body.appendChild(h('div', { class: 'p57cols' }, [f1.el, f2.el, right]));
    var type = sel(KINDS, kind || 'РАССТОЯНИЕ 2D'), idIn = inp(''); idIn.style.width = '130px';
    right.appendChild(h('div', { class: 'p57row' }, [h('span', { text: 'Тип:' }), type]));
    right.appendChild(h('div', { class: 'p57row' }, [h('span', { text: 'ID:' }), idIn]));
    var fsT = h('fieldset', {}, [h('legend', { text: 'Допуск' })]);
    var nom = inp('', 'n'), p = inp('0.1', 'n'), m = inp('-0.1', 'n');
    var gt = h('div', { class: 'p57grid', style: 'grid-template-columns:auto 1fr' }, [h('span', { class: 'l', text: 'Номинал' }), nom, h('span', { class: 'l', text: '+Доп' }), p, h('span', { class: 'l', text: '−Доп' }), m]);
    fsT.appendChild(gt); right.appendChild(fsT);
    var fsR = h('fieldset', {}, [h('legend', { text: 'Отношение' })]);
    var rel = sel([['МЕЖДУ ЦЕНТРАМИ', 'Между центрами'], ['ПО ОСИ X', 'По оси X'], ['ПО ОСИ Y', 'По оси Y'], ['ПО ОСИ Z', 'По оси Z']], 'МЕЖДУ ЦЕНТРАМИ');
    fsR.appendChild(rel); right.appendChild(fsR);
    var opt = outputBlock(null); right.appendChild(opt.el);
    var info = h('div', { class: 'p57muted' }); right.appendChild(info);
    var idTouched = false; idIn.addEventListener('input', function () { idTouched = true; });
    var nomTouched = false; nom.addEventListener('input', function () { nomTouched = true; });
    function upd() {
      var t = type.value, a = elByName(f1.selected()[0]), b = elByName(f2.selected()[0]);
      var isDist = t === 'РАССТОЯНИЕ 2D', isAng = t === 'УГОЛ';
      fsR.style.display = isDist ? '' : 'none';
      m.disabled = !(isDist || isAng); if (m.disabled) m.value = '0';
      nom.disabled = !(isDist || isAng); if (nom.disabled) nom.value = '0';
      if (!idTouched) idIn.value = nextName(isDist ? 'DIST' : isAng ? 'ANG' : t === 'СООСНОСТЬ' ? 'COAX' : t === 'КОНЦЕНТРИЧНОСТЬ' ? 'CONC' : t === 'ПАРАЛЛЕЛЬНОСТЬ' ? 'PAR' : 'PERP', dims());
      var txt = '';
      if (a && b) {
        var da = [num(a.x) - num(b.x), num(a.y) - num(b.y), num(a.z) - num(b.z)];
        var va = nrm([num(a.i), num(a.j), num(a.k, 1)]), vb = nrm([num(b.i), num(b.j), num(b.k, 1)]);
        var ang = Math.acos(Math.max(-1, Math.min(1, va[0] * vb[0] + va[1] * vb[1] + va[2] * vb[2]))) * 180 / Math.PI;
        var r = rel.value, dist = r === 'ПО ОСИ X' ? Math.abs(da[0]) : r === 'ПО ОСИ Y' ? Math.abs(da[1]) : r === 'ПО ОСИ Z' ? Math.abs(da[2]) : Math.hypot(da[0], da[1]);
        txt = 'Теор.: расстояние 2D ' + dist.toFixed(3) + ' · 3D ' + Math.hypot(da[0], da[1], da[2]).toFixed(3) + ' · угол между осями ' + ang.toFixed(3) + '°';
        if (!nomTouched && isDist) nom.value = dist.toFixed(3);
        if (!nomTouched && isAng) nom.value = ang.toFixed(3);
      }
      info.textContent = txt;
    }
    type.addEventListener('change', function () { nomTouched = false; idTouched = false; upd(); }); rel.addEventListener('change', function () { nomTouched = false; upd(); });
    if (preset && preset[0]) f1.select([preset[0]]); if (preset && preset[1]) f2.select([preset[1]]);
    upd();
    w.foot.appendChild(h('span', { class: 'sp' }));
    w.foot.appendChild(btn('Создать', function () {
      var a = f1.selected()[0], b = f2.selected()[0], t = type.value;
      if (!a || !b) { toast('Выберите оба элемента'); return; }
      if (a === b) { toast('Элементы должны различаться'); return; }
      var s = S(); s.dimensions = s.dimensions || [];
      var nm = (idIn.value || '').trim() || nextName('DIST', s.dimensions); if (s.dimensions.some(function (d) { return d.name === nm; })) nm = uniqueName(nm, s.dimensions);
      var ea = elByName(a);
      var axis = t === 'РАССТОЯНИЕ 2D' ? 'M' : t === 'УГОЛ' ? 'A' : 'M';
      var d = { id: newId(), name: nm, dimType: t, refElement: a, refElement2: b, mod1: '', mod2: '', extraSuffix: '',
        axes: [{ id: newId(), axis: axis, nominal: String(nom.value || '0').replace(',', '.'), plusTol: String(p.value).replace(',', '.'), minusTol: String(m.value).replace(',', '.') }],
        optLine: opt.line(), axisHeader: '', groupPath: ea && ea.group ? [ea.group] : [] };
      if (t === 'РАССТОЯНИЕ 2D' && rel.value !== 'МЕЖДУ ЦЕНТРАМИ') d.extraSuffix = rel.value;
      s.dimensions.push(d); refresh(); toast('Создан размер <b>' + esc(nm) + '</b> (' + esc(t) + ')');
      idTouched = false; nomTouched = false; upd();
    }, 'def'));
    w.foot.appendChild(btn('Закрыть', function () { w.close(); }));
  };

  /* открыть существующий GDT-диалог с выбранной характеристикой */
  function openGdt(type, feat) {
    if (typeof window.pcdGdtOpen !== 'function') { try { pcdAct('tab:dimensions'); } catch (e) {} return; }
    window.pcdGdtOpen();
    setTimeout(function () {
      var boxes = document.querySelectorAll('.pcd-dlg'), box = boxes[boxes.length - 1]; if (!box) return;
      [].forEach.call(box.querySelectorAll('select'), function (s) {
        var vals = [].map.call(s.options, function (o) { return o.value; });
        if (type && vals.indexOf(type) >= 0 && vals.indexOf('ПОЗИЦИЯ') >= 0) { s.value = type; s.dispatchEvent(new Event('change')); }
        else if (feat && vals.indexOf(feat) >= 0 && !s.__p57) { s.__p57 = 1; s.value = feat; s.dispatchEvent(new Event('change')); }
      });
    }, 30);
  }
  window.pcdGdtOpenType = openGdt;

  /* правка размера по двойному щелчку */
  function editDimension(d) {
    if (!d) return;
    if (d.dimType === 'ПОЛОЖЕНИЕ') { window.pcdLocationOpen(null, d); return; }
    try { pcdAct('tab:dimensions'); } catch (e) {}
    setTimeout(function () {
      var cards = document.querySelectorAll('#dimensionsList .dim-card, #dimensionsList > *');
      [].forEach.call(cards, function (c) { if ((c.textContent || '').indexOf(d.name) >= 0 && !editDimension._done) { editDimension._done = 1; c.scrollIntoView({ block: 'center' }); c.style.outline = '2px solid #0078d7'; setTimeout(function () { c.style.outline = ''; }, 1500); } });
      editDimension._done = 0;
    }, 120);
  }

  /* ================= 4. ГРАФИКА: метки ID, DIMINFO ================= */
  var ov = null, svgL = null, boxes = {}, diminfoDirty = true, lastSig = '';
  var showId = localStorage.getItem('p57.id') === '1', showDi = localStorage.getItem('p57.di') === '1';
  function diStore() { var s = S(); if (!s) return {}; s._p57di = s._p57di || {}; return s._p57di; }
  function ensureOv() {
    var cont = $('threeContainer'); if (!cont) return null;
    if (ov && ov.parentNode === cont) return ov;
    ov = h('div', { id: 'p57Ov' }); svgL = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svgL.setAttribute('class', 'ld');
    ov.appendChild(svgL); cont.appendChild(ov); boxes = {}; diminfoDirty = true;
    return ov;
  }
  function dimsOfEl(e) { return dims().filter(function (d) { return d.refElement === e.name; }); }
  function axisRows(e) {
    var rows = [];
    dimsOfEl(e).forEach(function (d) {
      (d.axes || []).forEach(function (a) {
        var nomv = num(a.nominal, NaN), meas = a.measured != null && a.measured !== '' ? num(a.measured, NaN) : NaN;
        var pr = d.protocolResult && d.protocolResult.perAxis && d.protocolResult.perAxis[a.axis];
        if (!isFinite(meas) && pr && pr.measured != null) meas = +pr.measured;
        if (!isFinite(meas) && !e.factSameAsNominal) {
          var mk = { X: 'factX', Y: 'factY', Z: 'factZ', D: 'factDiam', L: 'factDepth' }[a.axis];
          if (mk && e[mk] !== '' && e[mk] != null) meas = num(e[mk], NaN);
        }
        var pt = num(a.plusTol, NaN), mt = num(a.minusTol, NaN);
        if (a.axis === 'TP' && !isFinite(nomv)) nomv = 0;
        var dev = isFinite(meas) && isFinite(nomv) ? meas - nomv : NaN, out = NaN;
        if (isFinite(dev)) {
          var hi = isFinite(pt) ? pt : Infinity, lo = isFinite(mt) ? (a.axis === 'TP' ? -Infinity : (mt > 0 ? -mt : mt)) : -Infinity;
          out = dev > hi ? dev - hi : dev < lo ? dev - lo : 0;
        }
        rows.push({ dim: d.name, ax: a.axis, nom: nomv, meas: meas, pt: pt, mt: mt, dev: dev, out: out });
      });
    });
    return rows;
  }
  function fmt(v) { return isFinite(v) ? v.toFixed(3) : '—'; }
  function diHtml(e) {
    var rows = axisRows(e); if (!rows.length) return '';
    var anyBad = rows.some(function (r) { return r.out > 0; }), anyMeas = rows.some(function (r) { return isFinite(r.meas); });
    var hh = '<div class="ttl ' + (anyMeas ? (anyBad ? 'bad' : 'ok') : '') + '">' + esc(e.name) + '</div><table><tr><th style="text-align:left">ОСЬ</th><th>НОМ</th><th>ИЗМ</th><th>+ДОП</th><th>−ДОП</th><th>ОТКЛ</th><th>ВНЕ</th><th></th></tr>';
    var multiDim = rows.some(function (r) { return r.dim !== rows[0].dim; }), lastDim = null;
    rows.slice(0, 14).forEach(function (r) {
      if (multiDim && r.dim !== lastDim) { lastDim = r.dim; hh += '<tr><td class="dn" colspan="8">' + esc(r.dim) + '</td></tr>'; }
      var cls = !isFinite(r.dev) ? '' : r.out > 0 ? 'bad' : (isFinite(r.pt) && Math.abs(r.dev) > Math.abs(r.pt) * 0.75 ? 'warn' : 'ok');
      var bar = '';
      if (isFinite(r.dev) && isFinite(r.pt) && r.pt !== 0) {
        var lo = isFinite(r.mt) ? (r.mt > 0 ? -r.mt : r.mt) : -r.pt, span = (r.pt - lo) || 1, pos = (r.dev - lo) / span; // 0..1 в поле допуска
        var x = Math.max(0, Math.min(1, 0.15 + pos * 0.7)) * 40;
        bar = '<span class="bar"><i style="left:' + x.toFixed(1) + 'px"></i></span>';
      }
      hh += '<tr><td class="ax">' + esc(r.ax) + '</td><td>' + fmt(r.nom) + '</td><td>' + fmt(r.meas) + '</td><td>' + (isFinite(r.pt) ? r.pt.toFixed(3) : '') + '</td><td>' + (isFinite(r.mt) ? r.mt.toFixed(3) : '') +
        '</td><td class="' + cls + '">' + fmt(r.dev) + '</td><td class="' + (r.out > 0 ? 'bad' : '') + '">' + (isFinite(r.out) ? r.out.toFixed(3) : '—') + '</td><td>' + bar + '</td></tr>';
    });
    if (rows.length > 14) hh += '<tr><td colspan="8" style="text-align:left">… ещё ' + (rows.length - 14) + '</td></tr>';
    return hh + '</table>';
  }
  function anchor(e) {
    var tv = G('toThreeVec'), eg = G('elementsGroup3'); if (typeof tv !== 'function') return null;
    var p = tv(num(e.x), num(e.y), num(e.z)); if (eg && eg.localToWorld) eg.localToWorld(p); return p;
  }
  function makeBox(kind, e) {
    var b = h('div', { class: kind === 'id' ? 'p57lab' : 'p57di' }); b.dataset.el = e.id; b.dataset.kind = kind;
    b.addEventListener('mousedown', function (ev) {
      if (ev.button !== 0) return; ev.stopPropagation(); ev.preventDefault();
      var store = diStore(), key = kind + ':' + e.id, o = store[key] || defOff(kind), sx = ev.clientX, sy = ev.clientY, ox = o[0], oy = o[1], moved = false;
      function mv(m) { moved = true; store[key] = [ox + m.clientX - sx, oy + m.clientY - sy]; place(); }
      function up() { document.removeEventListener('mousemove', mv, true); document.removeEventListener('mouseup', up, true); if (!moved) { try { selectElementInScene(e.id); } catch (_) {} } else { try { scheduleAutosave(); } catch (_) {} } }
      document.addEventListener('mousemove', mv, true); document.addEventListener('mouseup', up, true);
    });
    b.addEventListener('dblclick', function (ev) { ev.stopPropagation(); window.pcdAutoFeatureOpen(elById(e.id) || e); });
    b.addEventListener('contextmenu', function (ev) { ev.preventDefault(); ev.stopPropagation(); elMenu(ev.clientX, ev.clientY, elById(e.id)); });
    return b;
  }
  function defOff(kind) { return kind === 'id' ? [24, -34] : [40, 26]; }
  function syncBoxes() {
    var o = ensureOv(); if (!o) return;
    var list = elements(), want = {}, selId = G('selectedElementId');
    var sig = (S() && S().id) + '|' + showId + showDi + '|' + selId + '|' + JSON.stringify(list.map(function (e) { return [e.id, e.name, e.factSameAsNominal, e.factX, e.factY, e.factZ, e.factDiam]; })) + '|' + JSON.stringify(dims().map(function (d) { return [d.name, d.refElement, d.axes, d.protocolResult && d.protocolResult.importedAt]; }));
    if (!diminfoDirty && sig === lastSig) return;
    diminfoDirty = false; lastSig = sig;
    var many = list.length > 120;
    list.forEach(function (e) {
      if (showId && (!many || e.id === selId)) want['id:' + e.id] = e;
      if (showDi && (!many || e.id === selId) && dimsOfEl(e).length) want['di:' + e.id] = e;
    });
    Object.keys(boxes).forEach(function (k) { if (!want[k]) { boxes[k].remove(); delete boxes[k]; } });
    Object.keys(want).forEach(function (k) {
      var e = want[k], kind = k.slice(0, 2);
      if (!boxes[k]) { boxes[k] = makeBox(kind, e); o.appendChild(boxes[k]); }
      if (kind === 'id') boxes[k].textContent = e.name; else boxes[k].innerHTML = diHtml(e);
      boxes[k].classList.toggle('sel', e.id === selId);
    });
  }
  var _v = null;
  function place() {
    if (!ov) return;
    var cam = G('camera3'), r = G('renderer3'), THREE_ = window.THREE; if (!cam || !r || !THREE_) return;
    var W = ov.clientWidth, H = ov.clientHeight, store = diStore(), lines = '';
    cam.updateMatrixWorld();
    Object.keys(boxes).forEach(function (k) {
      var b = boxes[k], e = elById(b.dataset.el); if (!e) return;
      var p = anchor(e); if (!p) return;
      var v = p.clone().project(cam);
      if (v.z > 1 || v.z < -1 || Math.abs(v.x) > 1.5 || Math.abs(v.y) > 1.5) { b.style.display = 'none'; return; }
      var sx = (v.x * 0.5 + 0.5) * W, sy = (-v.y * 0.5 + 0.5) * H, off = store[k] || defOff(b.dataset.kind);
      b.style.display = ''; b.style.left = (sx + off[0]) + 'px'; b.style.top = (sy + off[1]) + 'px';
      var bw = b.offsetWidth, bh = b.offsetHeight, bx = sx + off[0], by = sy + off[1];
      var tx = Math.max(bx, Math.min(sx, bx + bw)), ty = Math.max(by, Math.min(sy, by + bh));
      lines += '<line x1="' + sx.toFixed(1) + '" y1="' + sy.toFixed(1) + '" x2="' + tx.toFixed(1) + '" y2="' + ty.toFixed(1) + '" stroke="#000" stroke-width="1"/><circle cx="' + sx.toFixed(1) + '" cy="' + sy.toFixed(1) + '" r="2" fill="#000"/>';
    });
    if (svgL) svgL.innerHTML = lines;
  }
  var lastCam = '';
  (function loop() {
    requestAnimationFrame(loop);
    try {
      var tab = $('tab-model'); if (tab && !tab.classList.contains('active')) return;
      if (!showId && !showDi) { if (ov && Object.keys(boxes).length) { Object.keys(boxes).forEach(function (k) { boxes[k].remove(); }); boxes = {}; if (svgL) svgL.innerHTML = ''; } return; }
      syncBoxes();
      var cam = G('camera3'); if (!cam) return;
      var c = cam.matrixWorld.elements.join(',') + '|' + cam.projectionMatrix.elements[0] + '|' + (ov ? ov.clientWidth + 'x' + ov.clientHeight : '') + '|' + lastSig.length + JSON.stringify(diStore());
      if (c !== lastCam) { lastCam = c; place(); }
    } catch (e) {}
  })();
  function setToggle(kind, on) {
    if (kind === 'id') { showId = on; localStorage.setItem('p57.id', on ? '1' : '0'); } else { showDi = on; localStorage.setItem('p57.di', on ? '1' : '0'); }
    diminfoDirty = true; lastCam = '';
    [].forEach.call(document.querySelectorAll('.p57tg'), function (b) { b.classList.toggle('on', b.dataset.k === 'id' ? showId : showDi); });
  }
  window.pcdDimInfoToggle = function (on) { setToggle('di', on == null ? !showDi : !!on); };
  window.pcdIdLabelsToggle = function (on) { setToggle('id', on == null ? !showId : !!on); };
  function addStripButtons() {
    var strip = $('pcdViewsStrip3'); if (!strip || strip.querySelector('.p57tg')) return !!strip;
    var row = h('div', { style: 'display:flex;gap:3px;pointer-events:auto;' });
    [['id', 'ID', 'Метки ID элементов в графике'], ['di', 'DIMINFO', 'Окна информации о размерах (DIMINFO) в графике']].forEach(function (d) {
      var b = h('button', { class: 'p57tg', title: d[2], text: d[1] }); b.dataset.k = d[0];
      b.style.cssText = 'font-size:10px;padding:3px 7px;cursor:pointer;';
      b.addEventListener('click', function () { setToggle(d[0], !(d[0] === 'id' ? showId : showDi)); });
      row.appendChild(b);
    });
    strip.appendChild(row); setToggle('id', showId); setToggle('di', showDi);
    return true;
  }

  /* ================= 5. контекстное меню элемента, двойной щелчок, F9 ================= */
  function menu(x, y, title, items) {
    var m = $('p57Menu'); if (!m) { m = h('div', { id: 'p57Menu' }); document.body.appendChild(m); }
    m.innerHTML = title ? '<div class="hd">' + esc(title) + '</div>' : '';
    items.forEach(function (it) {
      if (it === '-') { m.appendChild(h('hr')); return; }
      var i = h('div', { class: 'i', html: (it[2] ? icon(it[2]) : '<span style="width:16px"></span>') + '<span>' + esc(it[0]) + '</span>' });
      i.addEventListener('click', function () { m.style.display = 'none'; it[1](); }); m.appendChild(i);
    });
    m.style.display = 'block';
    m.style.left = Math.min(x, window.innerWidth - m.offsetWidth - 4) + 'px'; m.style.top = Math.min(y, window.innerHeight - m.offsetHeight - 4) + 'px';
  }
  document.addEventListener('mousedown', function (e) { var m = $('p57Menu'); if (m && m.style.display === 'block' && !m.contains(e.target)) m.style.display = 'none'; }, true);
  function elMenu(x, y, e) {
    if (!e) return;
    menu(x, y, e.name, [
      ['Изменить… (F9)', function () { window.pcdAutoFeatureOpen(e); }, 'feat'],
      ['Выделить и показать', function () { try { selectElementInScene(e.id); } catch (_) {} }, 'gfx'],
      ['Свойства…', function () { if (window.pcdPropsOpen) window.pcdPropsOpen(e); }, 'header'],
      '-',
      ['Размер: положение…', function () { window.pcdLocationOpen([e.name]); }, 'dim'],
      ['Размер: расстояние / угол…', function () { window.pcdDistanceOpen('РАССТОЯНИЕ 2D', [e.name]); }, 'dim'],
      ['GD&T: позиция…', function () { openGdt('ПОЗИЦИЯ', e.name); }, 'pos'],
      '-',
      [showDi ? 'Скрыть DIMINFO' : 'Показать DIMINFO', function () { window.pcdDimInfoToggle(); }, null],
      [showId ? 'Скрыть метки ID' : 'Показать метки ID', function () { window.pcdIdLabelsToggle(); }, null],
      '-',
      ['Удалить элемент', function () {
        if (!confirm('Удалить элемент «' + e.name + '»?')) return;
        var s = S(); s.elements.splice(s.elements.indexOf(e), 1); refresh(); toast('Элемент <b>' + esc(e.name) + '</b> удалён');
      }, null]
    ]);
  }
  window.pcdElementMenu = elMenu;
  function hookGraphics() {
    var r = G('renderer3'); if (!r || !r.domElement || r.domElement.__p57) return !!(r && r.domElement && r.domElement.__p57);
    var cv = r.domElement; cv.__p57 = 1;
    cv.addEventListener('dblclick', function (ev) {
      try { var id = pickProgramAt(ev.clientX, ev.clientY); if (id) { var e = elById(id); if (e) window.pcdAutoFeatureOpen(e); } } catch (_) {}
    });
    cv.addEventListener('mousedown', function (ev) { if (ev.button === 2) cv.__rd = [ev.clientX, ev.clientY]; }, true);
    cv.addEventListener('contextmenu', function (ev) {
      try {
        if (cv.__rd && Math.hypot(ev.clientX - cv.__rd[0], ev.clientY - cv.__rd[1]) > 5) return; // это было панорамирование
        var id = pickProgramAt(ev.clientX, ev.clientY); if (!id) return;
        var e = elById(id); if (!e) return;
        ev.preventDefault(); ev.stopImmediatePropagation(); elMenu(ev.clientX, ev.clientY, e);
      } catch (_) {}
    }, true);
    return true;
  }
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'F9') return;
    var id = G('selectedElementId'), el = id && elById(id);
    e.preventDefault();
    if (el) window.pcdAutoFeatureOpen(el); else window.pcdAutoFeatureOpen('circle');
  });
  // окно правки → Сводка: двойной щелчок по элементу/размеру открывает окно правки
  document.addEventListener('dblclick', function (e) {
    var row = e.target.closest && e.target.closest('#pcd25Sum .n[data-k]'); if (!row) return;
    var k = row.getAttribute('data-k');
    if (k.indexOf('e:') === 0) { var el = elById(k.slice(2)); if (el) { e.stopPropagation(); window.pcdAutoFeatureOpen(el); } }
    else if (k.indexOf('d:') === 0) { var id = k.slice(2), d = dims().filter(function (x) { return x.id === id; })[0]; if (d) { e.stopPropagation(); editDimension(d); } }
  }, true);

  /* ================= 6. панели инструментов и меню «Вставка» ================= */
  var TB_MAP = [
    [/^Плоскость/, function () { window.pcdAutoFeatureOpen('plane'); }, 'Автоэлемент: плоскость'],
    [/^Цилиндр/, function () { window.pcdAutoFeatureOpen('cylinder'); }, 'Автоэлемент: цилиндр'],
    [/^Конус/, function () { window.pcdAutoFeatureOpen('cone'); }, 'Автоэлемент: конус'],
    [/^Окружность/, function () { window.pcdAutoFeatureOpen('circle'); }, 'Автоэлемент: окружность'],
    [/^Точка/, function () { window.pcdAutoFeatureOpen('point_measured'); }, 'Автоэлемент: точка'],
    [/^Сфера/, function () { window.pcdAutoFeatureOpen('sphere'); }, 'Автоэлемент: сфера'],
    [/^Диаметр/, function () { window.pcdLocationOpen({ length: 0, axes: ['D'] }); }, 'Размер: положение (диаметр)'],
    [/^Позиция/, function () { openGdt('ПОЗИЦИЯ'); }, 'GD&T: позиция'],
    [/^Параллельность/, function () { openGdt('ПАРАЛЛЕЛЬНОСТЬ'); }, 'GD&T: параллельность'],
    [/^Перпендикулярность/, function () { openGdt('ПЕРПЕНДИКУЛЯРНОСТЬ'); }, 'GD&T: перпендикулярность'],
    [/^Круглость/, function () { openGdt('КРУГЛОСТЬ'); }, 'GD&T: круглость'],
    [/^Цилиндричность/, function () { openGdt('ЦИЛИНДРИЧНОСТЬ'); }, 'GD&T: цилиндричность']
  ];
  function rewireToolbars() {
    [].forEach.call(document.querySelectorAll('.pcd-tb button, .pcd-vert button'), function (b) {
      if (b.__p57) return; var t = b.getAttribute('title') || '';
      for (var i = 0; i < TB_MAP.length; i++) if (TB_MAP[i][0].test(t)) {
        b.__p57 = 1; b.removeAttribute('onclick'); b.onclick = null; b.title = TB_MAP[i][2];
        b.addEventListener('click', TB_MAP[i][1]); break;
      }
    });
    // в группу размеров — «Положение» и «Расстояние»
    var tb2 = $('pcdTb2'), g = tb2 && tb2.querySelectorAll('.g')[1];
    if (g && !g.querySelector('.p57loc')) {
      var b1 = h('button', { class: 'p57loc', title: 'Размер: положение элемента (X/Y/Z/D…)', html: icon('dim') }); b1.addEventListener('click', function () { window.pcdLocationOpen(); });
      var b2 = h('button', { class: 'p57dst', title: 'Размер: расстояние / угол между элементами', html: icon('line') }); b2.addEventListener('click', function () { window.pcdDistanceOpen(); });
      g.insertBefore(b2, g.firstChild); g.insertBefore(b1, g.firstChild);
    }
  }
  function extendMenu() {
    var items = document.querySelectorAll('.mi .sub .si'), ins = null;
    [].forEach.call(items, function (s) { var oc = s.getAttribute('onclick') || ''; if (/pcdAct\('adddim'\)/.test(oc)) ins = s; });
    if (!ins || ins.parentNode.querySelector('.p57mi')) return;
    var defs = [
      ['Автоэлемент: окружность…', function () { window.pcdAutoFeatureOpen('circle'); }, 'circle'],
      ['Автоэлемент: цилиндр…', function () { window.pcdAutoFeatureOpen('cylinder'); }, 'cylinder'],
      ['Автоэлемент: плоскость…', function () { window.pcdAutoFeatureOpen('plane'); }, 'plane'],
      ['Автоэлемент: точка…', function () { window.pcdAutoFeatureOpen('point_measured'); }, 'point'],
      ['Автоэлемент: конус / сфера…', function () { window.pcdAutoFeatureOpen('cone'); }, 'cone'],
      '-',
      ['Размер: положение элемента…', function () { window.pcdLocationOpen(); }, 'dim'],
      ['Размер: расстояние / угол…', function () { window.pcdDistanceOpen(); }, 'dim']
    ], frag = document.createDocumentFragment();
    frag.appendChild(document.createElement('hr'));
    defs.forEach(function (d) {
      if (d === '-') { frag.appendChild(document.createElement('hr')); return; }
      var s = h('span', { class: 'si p57mi', html: '<span class="mic">' + icon(d[2]) + '</span>' + esc(d[0]) });
      s.addEventListener('click', function (ev) { ev.stopPropagation(); try { document.querySelectorAll('.mi.open').forEach(function (x) { x.classList.remove('open'); }); } catch (_) {} d[1](); });
      frag.appendChild(s);
    });
    ins.parentNode.insertBefore(frag, ins.nextSibling);
  }

  window.__p57api = { win: win, btn: btn, inp: inp, sel: sel, h: h, menu: menu, icon: icon, toast: toast, refresh: refresh, esc: esc, num: num, f3: f3, fs: fs,
    S: S, G: G, elements: elements, dims: dims, elById: elById, elByName: elByName, uniqueName: uniqueName, nextName: nextName, newId: newId,
    hitsFor: hitsFor, editDimension: editDimension, axisRows: axisRows, openGdt: openGdt, dirty: function () { diminfoDirty = true; lastCam = ''; } };

  /* ---------------- запуск ---------------- */
  function boot() {
    try { rewireToolbars(); } catch (e) { console.warn('p57 tb', e); }
    try { extendMenu(); } catch (e) { console.warn('p57 menu', e); }
    var tries = 0;
    (function waitGfx() {
      var ok1 = false, ok2 = false;
      try { ok1 = addStripButtons(); } catch (e) {}
      try { ok2 = hookGraphics(); } catch (e) {}
      if ((!ok1 || !ok2) && ++tries < 120) setTimeout(waitGfx, 500);
    })();
    try { var v = document.querySelector('[title*="Версия приложения"]'); if (v) { v.textContent = 'r57'; v.title = 'Версия приложения (должно быть r57 после перезагрузки)'; } } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else setTimeout(boot, 0);
})();
