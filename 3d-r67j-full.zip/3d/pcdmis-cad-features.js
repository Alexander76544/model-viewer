/* r66h: все элементы из .CAD — плоскости, цилиндры (отверстия/валы), сферы по точной геометрии граней.
   PcdCadFeatures.collect(P, pos, opts) → { els:[{type,base,p,w,extra,info}], stat }
   P = { off, n, triFace, cad, hidden }, pos — Float32Array треугольников (9 чисел на треугольник),
   opts.swapped=true, если в pos оси уже переставлены (three: x, z, y). */
(function (root) {
  function norm(a) { var l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; }
  function dot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
  function canon(A) { // знак оси: наибольшая по модулю компонента > 0
    var m = Math.abs(A[0]) >= Math.abs(A[1]) && Math.abs(A[0]) >= Math.abs(A[2]) ? 0 : (Math.abs(A[1]) >= Math.abs(A[2]) ? 1 : 2);
    return A[m] < 0 ? [-A[0], -A[1], -A[2]] : A.slice();
  }
  function r3(x) { return Math.round(x * 1000) / 1000; }
  function collect(P, pos, opts) {
    opts = opts || {};
    var o = P.cad, n = P.n, off = (P.off || 0) * 9, tf = P.triFace, hid = opts.visibleOnly ? (P.hidden || {}) : {}, sw = !!opts.swapped;
    var want = opts.types || { plane: 1, cylinder: 1, sphere: 1 };
    var F = {}; // по грани
    var v = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
    for (var t = 0; t < n; t++) {
      var h = tf[t]; if (!h) continue; var b = o.faceBody[h] || 0; if (hid[b]) continue;
      var sh = o.faceSurf[h], s = o.surfaces[sh]; if (!s) continue;
      var k = s.k === 'PLANE' ? 'plane' : s.k === 'CYLINDER' ? 'cylinder' : s.k === 'SPHERE' ? 'sphere' : null; if (!k || !want[k]) continue;
      var q = off + t * 9;
      for (var j = 0; j < 3; j++) { var z = q + j * 3; v[j][0] = pos[z]; if (sw) { v[j][1] = pos[z + 2]; v[j][2] = pos[z + 1]; } else { v[j][1] = pos[z + 1]; v[j][2] = pos[z + 2]; } }
      var e1 = [v[1][0] - v[0][0], v[1][1] - v[0][1], v[1][2] - v[0][2]], e2 = [v[2][0] - v[0][0], v[2][1] - v[0][1], v[2][2] - v[0][2]];
      var c = [e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]], ar = Math.hypot(c[0], c[1], c[2]) / 2; if (!(ar > 0)) continue;
      var g = [(v[0][0] + v[1][0] + v[2][0]) / 3, (v[0][1] + v[1][1] + v[2][1]) / 3, (v[0][2] + v[1][2] + v[2][2]) / 3];
      var f = F[h]; if (!f) f = F[h] = { h: h, k: k, s: s, sh: sh, body: b, area: 0, cx: 0, cy: 0, cz: 0, nd: 0, tmin: 1e30, tmax: -1e30 };
      f.area += ar; f.cx += g[0] * ar; f.cy += g[1] * ar; f.cz += g[2] * ar;
      if (k === 'plane') f.nd += dot(c, s.N) / 2;
      else {
        var A = norm(s.A || [0, 0, 1]), d = [g[0] - s.O[0], g[1] - s.O[1], g[2] - s.O[2]], ta = dot(d, A), rad = [d[0] - ta * A[0], d[1] - ta * A[1], d[2] - ta * A[2]];
        f.nd += dot(c, rad) / 2 / (Math.hypot(rad[0], rad[1], rad[2]) || 1); // >0 — нормаль сетки наружу от оси (вал), <0 — к оси (отверстие)
        if (k === 'cylinder') for (var jj = 0; jj < 3; jj++) { var tt = (v[jj][0] - s.O[0]) * A[0] + (v[jj][1] - s.O[1]) * A[1] + (v[jj][2] - s.O[2]) * A[2]; if (tt < f.tmin) f.tmin = tt; if (tt > f.tmax) f.tmax = tt; }
      }
    }
    var minA = opts.minPlaneArea != null ? opts.minPlaneArea : 5, dMin = opts.minDiam != null ? opts.minDiam : 1, dMax = opts.maxDiam || 1e9, holesOnly = !!opts.holesOnly;
    var pls = [], cyl = {}, sph = {}, stat = { faces: 0, plane: 0, cylinder: 0, sphere: 0, skippedSmall: 0, merged: 0 };
    for (var key in F) {
      var f2 = F[key]; stat.faces++;
      if (f2.k === 'plane') {
        if (f2.area < minA) { stat.skippedSmall++; continue; }
        var N = norm(f2.s.N); if (f2.nd < 0) N = [-N[0], -N[1], -N[2]]; // нормаль — из материала (по ориентации сетки)
        var C = [f2.cx / f2.area, f2.cy / f2.area, f2.cz / f2.area], dp = (C[0] - f2.s.O[0]) * N[0] + (C[1] - f2.s.O[1]) * N[1] + (C[2] - f2.s.O[2]) * N[2];
        C = [C[0] - dp * N[0], C[1] - dp * N[1], C[2] - dp * N[2]];
        pls.push({ type: 'plane', base: 'CAD_PL', p: C, w: N, area: f2.area, body: f2.body, info: 'S=' + r3(f2.area) + ' мм²' });
      } else {
        var s2 = f2.s, Dm = 2 * s2.R; if (Dm < dMin || Dm > dMax) continue;
        var inner = f2.nd < 0; if (holesOnly && !inner) continue;
        var Ac = canon(norm(s2.A || [0, 0, 1])), O = s2.O;
        if (f2.k === 'cylinder') {
          // одна ось + радиус = один цилиндр (половинки отверстия из разных граней сливаются)
          var tO = dot(O, Ac), L0 = [O[0] - tO * Ac[0], O[1] - tO * Ac[1], O[2] - tO * Ac[2]];
          var A0 = norm(s2.A || [0, 0, 1]), sg = dot(A0, Ac) < 0 ? -1 : 1, t1 = f2.tmin * sg, t2 = f2.tmax * sg; if (t1 > t2) { var tw = t1; t1 = t2; t2 = tw; }
          t1 += tO; t2 += tO; // параметр вдоль Ac от L0
          var ck = f2.body + '|' + Ac.map(function (x) { return x.toFixed(4); }).join(',') + '|' + L0.map(function (x) { return x.toFixed(2); }).join(',') + '|' + Dm.toFixed(3) + '|' + (inner ? 'i' : 'o');
          // сливаем только перекрывающиеся/соприкасающиеся по оси участки (соосные отверстия в ряд — разные элементы)
          var lst = cyl[ck] || (cyl[ck] = []), hit = null;
          for (var li = 0; li < lst.length; li++) if (t1 <= lst[li].t2 + 0.05 && t2 >= lst[li].t1 - 0.05) { hit = lst[li]; break; }
          if (hit) { stat.merged++; if (t1 < hit.t1) hit.t1 = t1; if (t2 > hit.t2) hit.t2 = t2; hit.nf++; }
          else lst.push({ L0: L0, A: Ac, t1: t1, t2: t2, D: Dm, inner: inner, body: f2.body, nf: 1 });
        } else {
          var sk = f2.body + '|' + O.map(function (x) { return x.toFixed(3); }).join(',') + '|' + Dm.toFixed(3);
          if (sph[sk]) { stat.merged++; continue; }
          sph[sk] = { type: 'sphere', base: 'CAD_SPH', p: O.slice(), w: Ac, extra: { diam: String(r3(Dm)) }, body: f2.body, info: (inner ? 'вогнутая' : 'выпуклая') + ' Ø' + r3(Dm) };
        }
      }
    }
    var els = [];
    pls.sort(function (a, b) { return b.area - a.area; });
    var cl = [].concat.apply([], Object.keys(cyl).map(function (k2) { return cyl[k2]; })).map(function (c2) { var P0 = [c2.L0[0] + c2.A[0] * c2.t1, c2.L0[1] + c2.A[1] * c2.t1, c2.L0[2] + c2.A[2] * c2.t1];
      return { type: 'cylinder', base: c2.inner ? 'CAD_HOLE' : 'CAD_CYL', p: P0, w: c2.A, extra: { diam: String(r3(c2.D)), depth: String(r3(c2.t2 - c2.t1)) }, body: c2.body, D: c2.D, inner: c2.inner,
        info: (c2.inner ? 'отверстие' : 'вал') + ' Ø' + r3(c2.D) + ' L=' + r3(c2.t2 - c2.t1) + (c2.nf > 1 ? ' (граней ' + c2.nf + ')' : '') }; });
    cl.sort(function (a, b) { return (b.inner - a.inner) || (a.D - b.D); });
    els = els.concat(pls, cl, Object.keys(sph).map(function (k3) { return sph[k3]; }));
    stat.plane = pls.length; stat.cylinder = cl.length; stat.sphere = els.length - pls.length - cl.length;
    stat.holes = cl.filter(function (c3) { return c3.inner; }).length;
    return { els: els, stat: stat };
  }
  root.PcdCadFeatures = { collect: collect };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.PcdCadFeatures;
})(typeof window !== 'undefined' ? window : globalThis);
