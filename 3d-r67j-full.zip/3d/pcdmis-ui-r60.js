/* r60: интерфейс 3D-окна «как в PC-DMIS» (своя реализация по мотивам окна графики PC-DMIS 2025).
 *  • панели «Вид графики» и «Режимы графики» в 3D-окне: Z+ Z− Y− Y+ X− X+ ISO, Вписать, Зум ±,
 *    Сплошной / Каркас / Полупрозрачный, Вид PC-DMIS, Размеры, ID, DIMINFO, Касания, Анализ;
 *  • градиентный фон окна графики (ICadWindow.BackgroundGradientType / BackgroundColor / BackgroundColor2);
 *  • колесо — зум к курсору, средняя кнопка — сдвиг, курсор-перекрестье;
 *  • подсветка элемента под курсором и выбранного элемента (каркасы r59);
 *  • подпись текущего вида и масштаба в углу окна.
 * Работает, когда включён «Вид PC-DMIS» (r59); панель видна всегда. */
(function () {
  'use strict';
  if (window.__p60) return; window.__p60 = true;
  function G(n) { try { return eval(n); } catch (e) { return undefined; } } // eslint-disable-line no-eval
  function $(id) { return document.getElementById(id); }
  function on() { return !!(window.pcdP59 && window.pcdP59.cfg.on); }
  function LS(k, d) { try { var v = localStorage.getItem('p60.' + k); return v == null ? d : v; } catch (e) { return d; } }
  function LSset(k, v) { try { localStorage.setItem('p60.' + k, String(v)); } catch (e) {} }

  var BG = { top: LS('bg1', '#9fb4d3'), bottom: LS('bg2', '#f3f6fa') };
  var HOVER = 0xffd400, SELECT = 0xff2bd6;

  /* ---------- стили ---------- */
  var css = [
    '#p60Tb{position:absolute;left:6px;top:6px;z-index:30;display:flex;flex-wrap:wrap;gap:4px;max-width:calc(100% - 330px);pointer-events:auto;user-select:none;}',
    '#p60Tb .grp{display:flex;background:linear-gradient(#fbfbfb,#e6e6e6);border:1px solid #a0a0a0;padding:1px;box-shadow:0 1px 2px rgba(0,0,0,.18);}',
    '#p60Tb .grp::before{content:"";width:3px;margin:2px 2px 2px 1px;background:repeating-linear-gradient(#999 0 1px,transparent 1px 3px);}',
    '#p60Tb button{width:24px;height:24px;padding:0;margin:0;border:1px solid transparent;background:transparent;cursor:pointer;display:flex;align-items:center;justify-content:center;}',
    '#p60Tb button:hover{background:#e5f1fb;border-color:#0078d7;}',
    '#p60Tb button.on{background:#cce4f7;border-color:#0078d7;}',
    '#p60Tb button svg{width:18px;height:18px;}',
    '#p60Tb button.txt{width:auto;padding:0 4px;font:600 10px "Segoe UI",Tahoma,sans-serif;color:#111;}',
    '#p60Info{position:absolute;left:8px;bottom:30px;z-index:20;font:11px "Segoe UI",Tahoma,sans-serif;color:#1d2b3e;background:rgba(255,255,255,.55);padding:1px 6px;border:1px solid rgba(0,0,0,.15);pointer-events:none;}',
    '#threeContainer.p60on canvas{cursor:crosshair !important;}'
  ].join('\n');
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  /* ---------- иконки (свои SVG в духе панелей PC-DMIS) ---------- */
  function cube(face, lbl) {
    var f = { top: '<path d="M3 7l6-3 6 3-6 3z" fill="#4f8fe0"/>', front: '<path d="M3 7l6 3v7l-6-3z" fill="#4f8fe0"/>', right: '<path d="M9 10l6-3v7l-6 3z" fill="#4f8fe0"/>', iso: '<path d="M3 7l6-3 6 3-6 3z" fill="#8fbaf0"/><path d="M3 7l6 3v7l-6-3z" fill="#4f8fe0"/><path d="M9 10l6-3v7l-6 3z" fill="#2c6cc0"/>' }[face] || '';
    return '<svg viewBox="0 0 24 20"><path d="M3 7l6-3 6 3v7l-6 3-6-3z" fill="#f4f4f4" stroke="#333" stroke-width=".8"/>' + f +
      '<path d="M3 7l6 3 6-3M9 10v7" fill="none" stroke="#333" stroke-width=".8"/>' + (lbl ? '<text x="23.5" y="19" font-size="8" font-family="Segoe UI,Arial" font-weight="700" text-anchor="end" fill="#b00">' + lbl + '</text>' : '') + '</svg>';
  }
  var IC = {
    fit: '<svg viewBox="0 0 20 20"><rect x="5" y="5" width="10" height="10" fill="#9cc3ef" stroke="#2c6cc0"/><path d="M1 6V1h5M14 1h5v5M19 14v5h-5M6 19H1v-5" fill="none" stroke="#111" stroke-width="1.6"/></svg>',
    zin: '<svg viewBox="0 0 20 20"><circle cx="8" cy="8" r="6" fill="#e9f3ff" stroke="#111" stroke-width="1.5"/><path d="M12.5 12.5L19 19" stroke="#111" stroke-width="2.4"/><path d="M5 8h6M8 5v6" stroke="#0a6" stroke-width="1.8"/></svg>',
    zout: '<svg viewBox="0 0 20 20"><circle cx="8" cy="8" r="6" fill="#e9f3ff" stroke="#111" stroke-width="1.5"/><path d="M12.5 12.5L19 19" stroke="#111" stroke-width="2.4"/><path d="M5 8h6" stroke="#c00" stroke-width="1.8"/></svg>',
    solid: '<svg viewBox="0 0 20 20"><path d="M3 6l7-4 7 4v8l-7 4-7-4z" fill="#6aa3e8" stroke="#1d4f91"/><path d="M3 6l7 4 7-4M10 10v8" fill="none" stroke="#1d4f91"/></svg>',
    wire: '<svg viewBox="0 0 20 20"><path d="M3 6l7-4 7 4v8l-7 4-7-4z M3 6l7 4 7-4M10 10v8" fill="none" stroke="#1d4f91" stroke-width="1.1"/><path d="M3 14l7-4 7 4M10 2v8" fill="none" stroke="#1d4f91" stroke-width=".6" stroke-dasharray="1.5 1"/></svg>',
    xray: '<svg viewBox="0 0 20 20"><path d="M3 6l7-4 7 4v8l-7 4-7-4z" fill="rgba(106,163,232,.35)" stroke="#1d4f91"/><path d="M3 6l7 4 7-4M10 10v8M3 14l7-4 7 4M10 2v8" fill="none" stroke="#1d4f91" stroke-width=".7"/></svg>',
    feat: '<svg viewBox="0 0 20 20"><ellipse cx="10" cy="5" rx="6" ry="2.3" fill="none" stroke="#1fb6ff" stroke-width="1.3"/><ellipse cx="10" cy="15" rx="6" ry="2.3" fill="none" stroke="#1fb6ff" stroke-width="1.3"/><path d="M4 5v10M16 5v10M10 1v18" stroke="#1fb6ff" stroke-width="1.1"/><path d="M10 1v18" stroke="#1fb6ff" stroke-dasharray="2 1.5"/></svg>',
    dims: '<svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="6.5" fill="none" stroke="#d00" stroke-width="1.6"/><path d="M2 18L18 2" stroke="#d00" stroke-width="1.6"/></svg>',
    id: '<svg viewBox="0 0 20 20"><rect x="2" y="5" width="16" height="10" fill="#fff" stroke="#333"/><text x="10" y="13.3" font-size="7.5" font-family="Segoe UI,Arial" font-weight="700" text-anchor="middle" fill="#0b5cad">ID</text></svg>',
    di: '<svg viewBox="0 0 20 20"><rect x="1.5" y="3" width="17" height="14" fill="#fff" stroke="#333"/><rect x="1.5" y="3" width="17" height="4" fill="#16a34a"/><path d="M1.5 10.5h17M1.5 13.8h17M7 7v10M13 7v10" stroke="#888" stroke-width=".7"/></svg>',
    hits: '<svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="7" fill="none" stroke="#1fb6ff" stroke-width="1"/><g fill="#ff7f00"><circle cx="10" cy="3" r="1.8"/><circle cx="17" cy="10" r="1.8"/><circle cx="10" cy="17" r="1.8"/><circle cx="3" cy="10" r="1.8"/></g></svg>',
    ana: '<svg viewBox="0 0 20 20"><circle cx="9" cy="11" r="6" fill="none" stroke="#1fb6ff"/><circle cx="11" cy="9" r="6.8" fill="none" stroke="#16a34a" stroke-dasharray="2 1.3"/><path d="M9 11L17 3" stroke="#dc2626" stroke-width="1.5"/><path d="M17 3l-1 4-3-3z" fill="#dc2626"/></svg>',
    ord: '<svg viewBox="0 0 20 20"><path d="M3 17V3M3 17h14" stroke="#333" stroke-width="1.3"/><path d="M3 9h9M12 17V9" stroke="#d946ef" stroke-dasharray="2 1.3"/><circle cx="12" cy="9" r="1.8" fill="#d946ef"/></svg>',
    bg: '<svg viewBox="0 0 20 20"><defs><linearGradient id="p60g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9fb4d3"/><stop offset="1" stop-color="#f3f6fa"/></linearGradient></defs><rect x="2" y="2" width="16" height="16" fill="url(#p60g)" stroke="#333"/></svg>'
  };

  /* ---------- камера ---------- */
  var VIEWNAME = { top: 'Z+', bottom: 'Z−', front: 'Y−', back: 'Y+', left: 'X−', right: 'X+', iso: 'ISO' };
  var curView = '';
  function view(k) { curView = VIEWNAME[k] || ''; try { window.pcdView3(k); } catch (e) {} }
  function zoom(f) {
    try { var d = G('camDist3'); (0, eval)('camDist3 = Math.max(0.5, camDist3 * ' + f + ')'); G('updateCamera3')(); G('persistProjectView3')(); } catch (e) {}
  }
  function blocked(e) {
    if (G('spectateMode3') || G('grabMode3')) return true;
    try { var f = G('mvHitRect3'); if (typeof f === 'function' && f(e)) return true; } catch (x) {}
    return false;
  }
  function hookMouse() {
    var r = G('renderer3'); if (!r || !r.domElement) return false;
    var dom = r.domElement; if (dom.__p60) return true; dom.__p60 = 1;
    // колесо: зум к точке под курсором (как в PC-DMIS)
    dom.addEventListener('wheel', function (e) {
      if (!on() || blocked(e)) return;
      var T = window.THREE, cam = G('camera3'), tgt = G('camTarget3'); if (!T || !cam || !tgt) return;
      e.preventDefault(); e.stopImmediatePropagation();
      var rc = dom.getBoundingClientRect(), nd = new T.Vector2(((e.clientX - rc.left) / rc.width) * 2 - 1, -((e.clientY - rc.top) / rc.height) * 2 + 1);
      var ray = new T.Raycaster(); ray.setFromCamera(nd, cam);
      var dir = new T.Vector3(); cam.getWorldDirection(dir);
      var pl = new T.Plane().setFromNormalAndCoplanarPoint(dir, tgt), P = new T.Vector3();
      var f = e.deltaY > 0 ? 1.12 : 1 / 1.12;
      var d0 = G('camDist3'), d1 = Math.max(0.5, d0 * f); f = d1 / d0;
      if (ray.ray.intersectPlane(pl, P)) { tgt.copy(P.clone().add(tgt.clone().sub(P).multiplyScalar(f))); }
      (0, eval)('camDist3 = ' + d1);
      G('updateCamera3')(); try { G('persistProjectView3')(); } catch (x) {}
      curView = '';
    }, { capture: true, passive: false });
    // средняя кнопка: сдвиг вида
    var pan = null;
    dom.addEventListener('mousedown', function (e) {
      if (e.button !== 1 || !on() || blocked(e)) return;
      e.preventDefault(); e.stopImmediatePropagation(); pan = [e.clientX, e.clientY];
    }, true);
    window.addEventListener('mousemove', function (e) {
      if (!pan) return;
      var T = window.THREE, cam = G('camera3'), tgt = G('camTarget3'), dx = e.clientX - pan[0], dy = e.clientY - pan[1]; pan = [e.clientX, e.clientY];
      var H = dom.clientHeight || 600, s = 2 * G('camDist3') * Math.tan((cam.fov || 45) * Math.PI / 360) / H;
      var dir = new T.Vector3(); cam.getWorldDirection(dir);
      var right = new T.Vector3().crossVectors(dir, cam.up).normalize(), up = new T.Vector3().crossVectors(right, dir).normalize();
      tgt.addScaledVector(right, -dx * s).addScaledVector(up, dy * s); G('updateCamera3')();
    });
    window.addEventListener('mouseup', function (e) { if (pan && e.button === 1) { pan = null; try { G('persistProjectView3')(); } catch (x) {} } });
    dom.addEventListener('auxclick', function (e) { if (e.button === 1 && on()) e.preventDefault(); });
    // подсветка элемента под курсором
    var hT = 0;
    dom.addEventListener('mousemove', function (e) {
      if (!on() || pan || e.buttons) return;
      var now = performance.now(); if (now - hT < 40) return; hT = now;
      var id = null; try { id = G('pickProgramAt')(e.clientX, e.clientY); } catch (x) {}
      setHover(id);
    });
    dom.addEventListener('mouseleave', function () { setHover(null); });
    return true;
  }

  /* ---------- подсветка каркасов r59 ---------- */
  var hoverId = null, paintedSig = '';
  function setHover(id) { if (id === hoverId) return; hoverId = id; paint(); }
  function paint() {
    var eg = G('elementsGroup3'); if (!eg) return;
    var sel = G('selectedElementId');
    eg.children.forEach(function (g) {
      var id = g.userData && g.userData.elementId; if (!id) return;
      var c = on() ? (id === sel ? SELECT : id === hoverId ? HOVER : null) : null;
      g.traverse(function (o) {
        if (o.userData.kind !== 'p59' || !o.material || !o.material.color || o.isSprite) return;
        if (o.userData.p60c == null) o.userData.p60c = o.material.color.getHex();
        var isWire = !!(o.parent && o.parent.userData.p59wire);
        o.material.color.setHex(c != null && isWire ? c : o.userData.p60c);
      });
    });
    paintedSig = (sel || '') + '|' + (hoverId || '') + '|' + on();
  }
  setInterval(function () {
    try {
      var sig = (G('selectedElementId') || '') + '|' + (hoverId || '') + '|' + on() + '|' + ((G('elementsGroup3') || {}).children || []).length;
      if (sig !== paintedSig + '|' + ((G('elementsGroup3') || {}).children || []).length || paint.__n !== (window.__p59n || 0)) { paint.__n = window.__p59n || 0; paint(); }
    } catch (e) {}
  }, 300);

  /* ---------- фон окна графики ---------- */
  var bgTex = null, bgSaved = undefined;
  function makeBg() {
    var T = window.THREE, cv = document.createElement('canvas'); cv.width = 4; cv.height = 256;
    var x = cv.getContext('2d'), gr = x.createLinearGradient(0, 0, 0, 256);
    gr.addColorStop(0, BG.top); gr.addColorStop(1, BG.bottom); x.fillStyle = gr; x.fillRect(0, 0, 4, 256);
    var t = new T.CanvasTexture(cv); try { t.colorSpace = T.SRGBColorSpace; } catch (e) {} return t;
  }
  function applyBg() {
    var sc = G('scene3'), T = window.THREE; if (!sc || !T) return;
    if (on() && LS('bg', '1') === '1') {
      if (!bgTex) bgTex = makeBg();
      if (sc.background !== bgTex) { if (bgSaved === undefined) bgSaved = sc.background; sc.background = bgTex; }
    } else if (sc.background === bgTex) { sc.background = bgSaved === undefined ? null : bgSaved; bgSaved = undefined; }
    var cont = $('threeContainer'); if (cont) cont.classList.toggle('p60on', on());
  }
  setInterval(function () { try { applyBg(); syncTb(); info(); } catch (e) {} }, 500);

  /* ---------- панели инструментов ---------- */
  function rm(m) { try { window.pcdRenderMode3(m); } catch (e) {} LSset('rm', m); syncTb(); }
  function p59(k) { if (window.pcdP59) window.pcdP59.set(k, !window.pcdP59.cfg[k]); syncTb(); }
  var GROUPS = [
    ['Вид графики', [
      ['top', cube('top', 'Z+'), 'Вид Z+ (сверху)', function () { view('top'); }],
      ['bottom', cube('top', 'Z−'), 'Вид Z− (снизу)', function () { view('bottom'); }],
      ['front', cube('front', 'Y−'), 'Вид Y− (спереди)', function () { view('front'); }],
      ['back', cube('front', 'Y+'), 'Вид Y+ (сзади)', function () { view('back'); }],
      ['left', cube('right', 'X−'), 'Вид X− (слева)', function () { view('left'); }],
      ['right', cube('right', 'X+'), 'Вид X+ (справа)', function () { view('right'); }],
      ['iso', cube('iso', ''), 'Изометрия (ISO)', function () { view('iso'); }],
      ['fit', IC.fit, 'Масштабировать по размеру окна', function () { try { window.pcdView3('fit'); } catch (e) {} }],
      ['zin', IC.zin, 'Увеличить', function () { zoom(1 / 1.25); }],
      ['zout', IC.zout, 'Уменьшить', function () { zoom(1.25); }]
    ]],
    ['Режимы графики', [
      ['rm:solid', IC.solid, 'Сплошной (CAD)', function () { rm('solid'); }],
      ['rm:wire', IC.wire, 'Каркас (CAD)', function () { rm('wire'); }],
      ['rm:xray', IC.xray, 'Полупрозрачный (CAD)', function () { rm('xray'); }],
      ['bg', IC.bg, 'Градиентный фон окна графики (ПКМ — цвета)', function () { LSset('bg', LS('bg', '1') === '1' ? '0' : '1'); applyBg(); syncTb(); }, function () { pickBg(); }]
    ]],
    ['Элементы и размеры', [
      ['p59:on', IC.feat, 'Вид PC-DMIS: элементы каркасом', function () { p59('on'); }],
      ['p59:dims', IC.dims, 'Графика размеров (Ø, R, L, расстояния, рамки допуска)', function () { p59('dims'); }],
      ['p59:ord', IC.ord, 'Ординаты X/Y/Z', function () { p59('ord'); }],
      ['p59:ana', IC.ana, 'Графический анализ (ПКМ на кнопке «Анализ» внизу — множитель)', function () { p59('ana'); }],
      ['id', IC.id, 'Метки ID', function () { try { window.pcdIdLabelsToggle(); } catch (e) {} setTimeout(syncTb, 50); }],
      ['di', IC.di, 'Окна DIMINFO', function () { try { window.pcdDimInfoToggle(); } catch (e) {} setTimeout(syncTb, 50); }],
      ['hits', IC.hits, 'Касания всех элементов', function () { try { window.pcdHitsToggle(); } catch (e) {} setTimeout(syncTb, 50); }]
    ]]
  ];
  function pickBg() {
    var a = prompt('Цвет фона сверху (как BackgroundColor), например #9fb4d3:', BG.top); if (a == null) return;
    var b = prompt('Цвет фона снизу (BackgroundColor2), например #f3f6fa:', BG.bottom); if (b == null) return;
    BG.top = a.trim() || BG.top; BG.bottom = b.trim() || BG.bottom; LSset('bg1', BG.top); LSset('bg2', BG.bottom);
    var sc = G('scene3'); if (sc && sc.background === bgTex) sc.background = null;
    if (bgTex) bgTex.dispose(); bgTex = null; LSset('bg', '1'); applyBg();
  }
  function addTb() {
    var cont = $('threeContainer'); if (!cont) return false;
    if ($('p60Tb')) return true;
    var tb = document.createElement('div'); tb.id = 'p60Tb';
    GROUPS.forEach(function (gr) {
      var g = document.createElement('div'); g.className = 'grp'; g.title = gr[0];
      gr[1].forEach(function (b) {
        var bt = document.createElement('button'); bt.dataset.k = b[0]; bt.title = b[2]; bt.innerHTML = b[1];
        bt.addEventListener('click', function (e) { e.stopPropagation(); b[3](); });
        bt.addEventListener('mousedown', function (e) { e.stopPropagation(); });
        if (b[4]) bt.addEventListener('contextmenu', function (e) { e.preventDefault(); e.stopPropagation(); b[4](); });
        g.appendChild(bt);
      });
      tb.appendChild(g);
    });
    tb.addEventListener('wheel', function (e) { e.stopPropagation(); }, { passive: true });
    cont.appendChild(tb);
    var inf = document.createElement('div'); inf.id = 'p60Info'; cont.appendChild(inf);
    syncTb(); return true;
  }
  function stripOn(sel) { var b = document.querySelector(sel); return !!(b && b.classList.contains('on')); }
  function syncTb() {
    var tb = $('p60Tb'); if (!tb) return;
    var c = window.pcdP59 ? window.pcdP59.cfg : {}, rmode = 'solid'; try { rmode = localStorage.getItem('pcdmis3d.pcdRender') || 'solid'; } catch (e) {}
    [].forEach.call(tb.querySelectorAll('button'), function (b) {
      var k = b.dataset.k, v = false;
      if (k.indexOf('p59:') === 0) v = !!c[k.slice(4)];
      else if (k.indexOf('rm:') === 0) v = k.slice(3) === rmode;
      else if (k === 'bg') v = LS('bg', '1') === '1' && on();
      else if (k === 'id') v = stripOn('.p57tg[data-k="id"]');
      else if (k === 'di') v = stripOn('.p57tg[data-k="di"]');
      else if (k === 'hits') v = stripOn('.p58hits');
      b.classList.toggle('on', v);
    });
  }
  function info() {
    var el = $('p60Info'); if (!el) return;
    if (!on()) { el.style.display = 'none'; return; }
    var cam = G('camera3'), r = G('renderer3'); if (!cam || !r) return;
    var H = r.domElement.clientHeight || 600, mmPerPx = 2 * G('camDist3') * Math.tan((cam.fov || 45) * Math.PI / 360) / H;
    var ph = G('camPhi3'), th = G('camTheta3'), v = curView;
    if (v) {
      var want = { 'Z+': [0.06, 0], 'Z−': [Math.PI - 0.06, 0], 'Y−': [Math.PI / 2, 0], 'Y+': [Math.PI / 2, Math.PI], 'X−': [Math.PI / 2, -Math.PI / 2], 'X+': [Math.PI / 2, Math.PI / 2], 'ISO': [Math.PI / 3.2, Math.PI / 4] }[v];
      if (!want || Math.abs(want[0] - ph) > 1e-3 || Math.abs(want[1] - th) > 1e-3) v = curView = '';
    }
    el.style.display = '';
    el.textContent = 'Вид: ' + (v || 'произвольный') + '   ·   1 пикс. = ' + (mmPerPx >= 1 ? mmPerPx.toFixed(2) : mmPerPx.toFixed(3)) + ' мм   ·   колесо — зум к курсору, ср. кнопка — сдвиг';
  }

  /* ---------- запуск ---------- */
  var n = 0;
  (function wait() {
    var a = false, b = false;
    try { a = addTb(); } catch (e) { console.warn('p60 tb', e); }
    try { b = hookMouse(); } catch (e) { console.warn('p60 mouse', e); }
    if ((!a || !b) && ++n < 200) setTimeout(wait, 500);
  })();
  function ver() { try { var vv = document.querySelector('[title*="Версия приложения"]'); if (vv) { vv.textContent = 'r60'; vv.title = 'Версия приложения (должно быть r60 после перезагрузки)'; } } catch (e) {} }
  ver(); setTimeout(ver, 3500);
})();
