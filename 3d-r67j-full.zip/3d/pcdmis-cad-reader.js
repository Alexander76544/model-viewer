/* pcdmis-cad-reader.js — чтение PC-DMIS .CAD (r64)
 * Формат восстановлен по CADDLL.DLL (Ghidra): CADCollSerializeFromArchive → FUN_180085660.
 *   .CAD = поток MFC CArchive (LE, без выравнивания).
 * Точно читается: заголовок (схема, сборка, таблица схем, единицы, допуски, версии типов,
 *   число объектов по типам). Геометрия: эвристический поиск сохранённой тесселяции
 *   (CCadSurfaceTessellation: полосы индексов u32 + вершины float3 + нормали float3)
 *   с проверкой по нормалям.  API: window.PcdCadReader.read(u8) */
(function (root) {
  'use strict';
  var TYPES = ['view','point','line','plane','circle','arc','conicarc','surfrev','surfruled','compcurve','bsplinecurve','bsplinesurf',
    'parsplinecurve','parsplinesurf','curveonparsurf','trimmedsurf','copdata','tabcyl','offsetsurf','pntvec','desline','polyline','sphere',
    'cylinder','slot','cone','solidface','contour','boundary','boundedsurf','Acis_edge','Acis_face','Catia_conicarc','Catia_curve','Catia_edge',
    'Catia_face','Ideas_wire','Ideas_face','PROE_spline','PROE_face','UG_conicarc','UG_spline','UG_face','transmat','assoc','subfigdef',
    'subfiginst','colordef','facetedface','SolidWorks_Face','SolidWorks_Curve','Catia5_face','Catia5_edge','Datum','Dimension','Tolerance',
    '#56','UG_point','UG_line','UG_circulararc','Catia_bsurf','pointcloud','#62','#63','PdeLib_face','PdeLib_curve','#66','#67','Aims_curve',
    'Aims_face','Aims_surface','Text','OffsetCurve','IgesManifoldSolidBRep','PlaneSurface','CylindricalSurface','ConicalSurface',
    'SphericalSurface','ToroidalSurface','IgesEdge','IgesLoop','IgesFace','IgesShell','DatumTarget','IgesVertex','Direction','TrimmedCurve',
    'TrimmedSurface','SuperSurface','Property'];
  // 101–107 — топология B-rep (порядок и счётчики совпали: граней = поверхностей)
  TYPES[101] = 'BodyEntity'; TYPES[102] = 'ShellEntity'; TYPES[103] = 'FaceEntity'; TYPES[104] = 'LoopEntity'; TYPES[105] = 'CoedgeEntity'; TYPES[106] = 'EdgeEntity'; TYPES[107] = 'VertexEntity';
  var RU = { BodyEntity: 'тела', ShellEntity: 'оболочки', FaceEntity: 'грани', LoopEntity: 'циклы', CoedgeEntity: 'коребра', EdgeEntity: 'рёбра', VertexEntity: 'вершины', point: 'точки', line: 'линии', plane: 'плоскости', circle: 'окружности', arc: 'дуги', bsplinecurve: 'NURBS-кривые',
    bsplinesurf: 'NURBS-поверхности', trimmedsurf: 'обрезанные поверхности', polyline: 'полилинии', sphere: 'сферы', cylinder: 'цилиндры',
    cone: 'конусы', boundary: 'границы', boundedsurf: 'ограниченные поверхности', colordef: 'цвета', facetedface: 'грани-сетки',
    Datum: 'базы', Dimension: 'размеры', Tolerance: 'допуски', Text: 'текст', PlaneSurface: 'плоск. поверхности',
    CylindricalSurface: 'цил. поверхности', ConicalSurface: 'кон. поверхности', SphericalSurface: 'сфер. поверхности',
    ToroidalSurface: 'тор. поверхности', IgesEdge: 'рёбра B-rep', IgesLoop: 'контуры B-rep', IgesFace: 'грани B-rep', IgesShell: 'оболочки',
    IgesVertex: 'вершины B-rep', IgesManifoldSolidBRep: 'тела B-rep', TrimmedCurve: 'обрез. кривые', TrimmedSurface: 'обрез. поверхности',
    pointcloud: 'облака точек', compcurve: 'составные кривые', curveonparsurf: 'кривые на поверхности', surfrev: 'пов. вращения',
    surfruled: 'линейчатые пов.', tabcyl: 'пов. выдавливания', offsetsurf: 'эквидист. пов.', subfigdef: 'подфигуры', subfiginst: 'вставки' };
  var UNITS = { 0: 'дюйм?', 1: 'мм', 2: 'дюйм', 3: 'фут', 4: 'см', 5: 'м', 99: 'не задано' };

  function Rd(u8, pos) { this.u8 = u8; this.dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength); this.p = pos || 0; }
  Rd.prototype = {
    need: function (n) { if (this.p + n > this.u8.length) throw new Error('конец файла @0x' + this.p.toString(16)); },
    u8v: function () { this.need(1); return this.u8[this.p++]; },
    u16: function () { this.need(2); var v = this.dv.getUint16(this.p, true); this.p += 2; return v; },
    i16: function () { this.need(2); var v = this.dv.getInt16(this.p, true); this.p += 2; return v; },
    u32: function () { this.need(4); var v = this.dv.getUint32(this.p, true); this.p += 4; return v; },
    i32: function () { this.need(4); var v = this.dv.getInt32(this.p, true); this.p += 4; return v; },
    f64: function () { this.need(8); var v = this.dv.getFloat64(this.p, true); this.p += 8; return v; },
    u64: function () { var lo = this.u32(), hi = this.u32(); return hi * 4294967296 + lo; },
    skip: function (n) { this.need(n); this.p += n; },
    count: function () { var w = this.u16(); if (w !== 0xffff) return w; var d = this.u32(); if (d !== 0xffffffff) return d; return this.u64(); }, // CArchive::ReadCount
    cstr: function () { // AfxReadStringLength + символы (MFC CString)
      var wide = false, n = this.u8v();
      if (n === 0xff) { n = this.u16(); if (n === 0xfffe) { wide = true; n = this.u8v(); if (n === 0xff) { n = this.u16(); if (n === 0xffff) n = this.u32(); } } else if (n === 0xffff) n = this.u32(); }
      var s = ''; for (var i = 0; i < n; i++) s += String.fromCharCode(wide ? this.u16() : this.u8v()); return s;
    }
  };

  function readHeader(u8) {
    var r = new Rd(u8), h = { warn: [] };
    var tag = r.i16(); if (tag !== -1) throw new Error('нет заголовка MFC (FF FF)');
    h.schema = r.u16(); var L = r.u16(); if (L > 63) throw new Error('длина имени класса ' + L);
    var nm = ''; for (var i = 0; i < L; i++) nm += String.fromCharCode(r.u8v()); h.cls = nm;
    if (nm !== 'CPCDbc_coll') throw new Error('класс «' + nm + '», ожидался CPCDbc_coll');
    if (h.schema > 0x1a6) h.warn.push('схема новее известной (0x1A6)');
    if (h.schema < 0x12e) throw new Error('старая схема 0x' + h.schema.toString(16) + ' (до PC-DMIS 2009) — не поддерживается');
    var s = h.schema;
    if (s > 200) h.build = r.i32();
    if (s >= 0x10) { var n = r.i32(); h.schemaTable = []; for (i = 0; i < n; i++) h.schemaTable.push(r.u16()); h.tessSchema = h.schemaTable[0]; }
    h.resolution = r.f64();
    if (s >= 0x191) { h.d1 = r.f64(); h.d2 = r.f64(); h.d3 = r.f64(); }
    if (s >= 0x19d) h.q1 = r.u64();
    if (s >= 0xe) {
      h.flags = r.u8v(); h.unicode = !!(h.flags & 1); h.strMode = r.u16();
      if (s > 0x1c) h.wideFlags = r.u16(); if (s > 0x196) h.argb = r.u16(); if (s > 99) { h.f79c = r.u16(); h.f7a0 = r.u16(); }
      var nt = r.i32(); h.typeVer = []; for (i = 0; i < nt; i++) h.typeVer.push(r.u16());
    }
    // s >= 0xca: ссылки на внешнюю модель не пишутся
    if (s > 0x13) { r.u16(); var nb = r.u32(); h.blobLen = nb; r.skip(nb); }           // FUN_180153d60
    if (s - 0x65 < 0x65 || s > 0x191) {                                                  // CCadIPData
      var ns = r.count(); h.ipStrings = []; for (i = 0; i < ns; i++) h.ipStrings.push(r.cstr()); var nip = r.u32(); r.skip(nip);
    }
    if (s - 0x15 < 0x17f) throw new Error('схема 0x' + s.toString(16) + ': блок GDX не поддержан');
    var c = r.i32(); if (c < 0) { h.ntypes = -c; h.nobj = r.i32(); } else { h.ntypes = 0x1a; h.nobj = c; }
    h.w0 = r.u16(); h.w1 = r.u16(); h.collFlags = r.u32(); if (s >= 3) h.i48 = r.i32();
    h.tol = r.f64(); if (s >= 0x199) h.angTol = r.f64(); if (s > 0x12e) h.tol70 = r.f64(); if (s >= 0x19a) h.tol380 = r.f64();
    h.units = r.u16(); if (s >= 200) h.units2 = r.u16(); if (s < 0xca) r.f64(); if (s < 0x193) { r.u16(); r.i32(); }
    h.typeCount = [];
    if (h.nobj > 0) for (i = 0; i < h.ntypes; i++) h.typeCount.push(r.i32());
    h.objStart = r.p;
    return h;
  }

  /* ---------- эвристика: тесселяция поверхностей ---------- */
  function f32(dv, p) { return dv.getFloat32(p, true); }
  function readCountAt(dv, p, end) { if (p + 2 > end) return null; var w = dv.getUint16(p, true); if (w !== 0xffff) return [w, 2]; if (p + 6 > end) return null; var d = dv.getUint32(p + 2, true); if (d === 0xffffffff) return null; return [d, 6]; }
  function arrOk(dv, p, n, unit, lim) {
    for (var i = 0; i < n; i++) {
      var x = f32(dv, p), y = f32(dv, p + 4), z = f32(dv, p + 8); p += 12;
      if (!(Math.abs(x) < lim && Math.abs(y) < lim && Math.abs(z) < lim)) return false;
      if (unit) { var l = x * x + y * y + z * z; if (l < 0.9 || l > 1.1) return false; }
    }
    return true;
  }
  // полосы индексов перед массивом вершин: k × (count m, m×u32, u8 флаг), впереди count k
  function stripsBack(dv, end, nv, budget) {
    var lists = [];
    function rec(pos, depth) {
      if (--budget.n < 0 || depth > 200000) return false;
      // вариант «здесь начало»: count k == число полос
      var cands = [];
      if (lists.length) { if (pos >= 2 && dv.getUint16(pos - 2, true) === lists.length) return (budget.start = pos - 2), true; if (pos >= 6 && dv.getUint16(pos - 6, true) === 0xffff && dv.getUint32(pos - 4, true) === lists.length) return (budget.start = pos - 6), true; }
      var fl = pos - 1; if (fl < 0 || dv.getUint8(fl) > 7) return false;
      var q = fl, m = 0, maxRun = 0;
      while (q - 4 >= 0 && dv.getUint32(q - 4, true) < nv && maxRun < 4e6) { q -= 4; maxRun++; }
      for (m = 1; m <= maxRun; m++) {
        var cp = fl - 4 * m, ok = false, hp = 0;
        if (cp >= 2 && dv.getUint16(cp - 2, true) === m && m < 0xffff) { ok = true; hp = cp - 2; }
        else if (m >= 0xffff && cp >= 6 && dv.getUint16(cp - 6, true) === 0xffff && dv.getUint32(cp - 4, true) === m) { ok = true; hp = cp - 6; }
        if (!ok) continue;
        lists.unshift({ p: cp, m: m, flag: dv.getUint8(fl) });
        if (rec(hp, depth + 1)) return true;
        lists.shift();
        if (budget.n < 0) return false;
      }
      return false;
    }
    return rec(end, 0) ? lists : null;
  }
  function triNormalScore(V, N, a, b, c) {
    var ax = V[b * 3] - V[a * 3], ay = V[b * 3 + 1] - V[a * 3 + 1], az = V[b * 3 + 2] - V[a * 3 + 2];
    var bx = V[c * 3] - V[a * 3], by = V[c * 3 + 1] - V[a * 3 + 1], bz = V[c * 3 + 2] - V[a * 3 + 2];
    var nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx, l = Math.hypot(nx, ny, nz); if (!l) return 0;
    return (nx * (N[a * 3] + N[b * 3] + N[c * 3]) + ny * (N[a * 3 + 1] + N[b * 3 + 1] + N[c * 3 + 1]) + nz * (N[a * 3 + 2] + N[b * 3 + 2] + N[c * 3 + 2])) / (3 * l);
  }
  function trisOf(idx, mode) { // 0 список, 1 полоса, 2 веер
    var t = [], i;
    if (mode === 0) { for (i = 0; i + 2 < idx.length; i += 3) t.push(idx[i], idx[i + 1], idx[i + 2]); }
    else if (mode === 1) { for (i = 0; i + 2 < idx.length; i++) { if (i & 1) t.push(idx[i + 1], idx[i], idx[i + 2]); else t.push(idx[i], idx[i + 1], idx[i + 2]); } }
    else { for (i = 1; i + 1 < idx.length; i++) t.push(idx[0], idx[i], idx[i + 1]); }
    return t;
  }
  // сканер по шагам: step(мс) → true, когда файл пройден (для асинхронного режима с прогрессом)
  function makeScanner(u8, from, opt) {
    opt = opt || {}; var dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength), end = u8.length, lim = opt.lim || 1e6;
    var meshes = [], p = from || 0, modeStat = [0, 0, 0];
    function step(ms) {
    var tStop = Date.now() + ms, cnt = 0;
    while (p + 2 < end) {
      if ((++cnt & 0xffff) === 0 && Date.now() > tStop) return false;
      // быстрый префильтр (u16-счётчик вершин повторяется перед нормалями)
      var w0 = u8[p] | (u8[p + 1] << 8);
      if (w0 !== 0xffff) { if (w0 < 3) { p++; continue; } var q0 = p + 2 + w0 * 12; if (q0 + 2 > end || (u8[q0] | (u8[q0 + 1] << 8)) !== w0) { p++; continue; } }
      var rc = readCountAt(dv, p, end); if (!rc) { p++; continue; }
      var nv = rc[0], vp = p + rc[1];
      if (nv < 3 || nv > 5e6 || vp + nv * 12 + 2 > end) { p++; continue; }
      var rc2 = readCountAt(dv, vp + nv * 12, end);
      if (!rc2 || rc2[0] !== nv) { p++; continue; }
      var np = vp + nv * 12 + rc2[1]; if (np + nv * 12 > end) { p++; continue; }
      if (!arrOk(dv, np, Math.min(nv, 64), true, 2) || !arrOk(dv, vp, Math.min(nv, 64), false, lim)) { p++; continue; }
      if (!arrOk(dv, np, nv, true, 2) || !arrOk(dv, vp, nv, false, lim)) { p++; continue; }
      var V = new Float32Array(nv * 3), N = new Float32Array(nv * 3), i;
      for (i = 0; i < nv * 3; i++) { V[i] = f32(dv, vp + i * 4); N[i] = f32(dv, np + i * 4); }
      var lists = stripsBack(dv, p, nv, { n: 20000 }), tri = [];
      if (lists) lists.forEach(function (L) {
        var idx = new Array(L.m); for (var k = 0; k < L.m; k++) idx[k] = dv.getUint32(L.p + 4 * k, true);
        var best = 0, bt = null, bm = 0;
        for (var mode = 0; mode < 3; mode++) { if (mode === 0 && L.m % 3) continue; var t = trisOf(idx, mode), sc = 0; for (var j = 0; j < t.length; j += 3) sc += triNormalScore(V, N, t[j], t[j + 1], t[j + 2]); sc /= Math.max(1, t.length / 3); if (Math.abs(sc) > Math.abs(best)) { best = sc; bt = t; bm = mode; } }
        if (bt) { if (best < 0) { for (var j2 = 0; j2 < bt.length; j2 += 3) { var x = bt[j2 + 1]; bt[j2 + 1] = bt[j2 + 2]; bt[j2 + 2] = x; } } modeStat[bm]++; Array.prototype.push.apply(tri, bt); }
      });
      cnt += 0x2000; meshes.push({ at: p, nv: nv, V: V, N: N, tri: tri, strips: lists ? lists.length : 0 });
      p = np + nv * 12;
    }
    return true;
    }
    return { step: step, pos: function () { return p / end; }, result: { meshes: meshes, modeStat: modeStat } };
  }
  function scanMeshes(u8, from, opt) { var sc = makeScanner(u8, from, opt); sc.step(Infinity); return sc.result; }

  function read(u8, opt) {
    var out = { header: null, error: null, meshes: [], log: [] };
    try { out.header = readHeader(u8); } catch (e) { out.error = e.message; }
    var h = out.header;
    if (h) {
      var b = h.build, ver = b ? 'сборка ' + b : '';
      out.log.push('PC-DMIS .CAD: схема 0x' + h.schema.toString(16).toUpperCase() + (ver ? ', ' + ver : '') + ', единицы: ' + (UNITS[h.units] || h.units) + ', объектов: ' + h.nobj.toLocaleString('ru'));
      out.log.push('  допуск ' + h.tol + (h.angTol != null ? ', угл. ' + h.angTol.toFixed(5) : '') + ', разрешение ' + h.resolution + ', схема тесселяции ' + h.tessSchema);
      var rows = []; h.typeCount.forEach(function (c, i) { if (c > 0) rows.push([c, TYPES[i] || ('#' + i)]); });
      rows.sort(function (a, b) { return b[0] - a[0]; });
      out.log.push('  по типам: ' + rows.map(function (r) { return (RU[r[1]] || r[1]) + ' ' + r[0]; }).join(', '));
      if (h.ipStrings && h.ipStrings.length) out.log.push('  строки: ' + h.ipStrings.slice(0, 5).join(' | '));
    } else out.log.push('Заголовок не прочитан: ' + out.error);
    if (opt && opt.async) return out;
    return finish(out, scanMeshes(u8, h ? h.objStart : 0, opt));
  }
  function finish(out, sc) {
    var h = out.header;
    out.meshes = sc.meshes;
    var nt = 0, nv = 0, withTri = 0; sc.meshes.forEach(function (m) { nt += m.tri.length / 3; nv += m.nv; if (m.tri.length) withTri++; });
    out.log.push('Тесселяция: сеток ' + sc.meshes.length + ' (с треугольниками ' + withTri + '), вершин ' + nv.toLocaleString('ru') + ', треугольников ' + nt.toLocaleString('ru') + ' [список/полоса/веер: ' + sc.modeStat.join('/') + ']');
    out.units = h ? h.units : 1;
    return out;
  }
  // асинхронно, не блокируя страницу: opt.progress(доля 0..1)
  function readAsync(u8, opt) {
    opt = opt || {}; var out = read(u8, { async: true }), h = out.header;
    var sc = makeScanner(u8, h ? h.objStart : 0, opt);
    return new Promise(function (res, rej) {
      (function tick() {
        try { if (sc.step(120)) return res(finish(out, sc.result)); } catch (e) { return rej(e); }
        if (opt.progress) try { opt.progress(sc.pos()); } catch (e) {}
        setTimeout(tick, 0);
      })();
    });
  }
  root.PcdCadReader = { read: read, readAsync: readAsync, readHeader: readHeader, scanMeshes: scanMeshes, TYPES: TYPES };
})(typeof window !== 'undefined' ? window : globalThis);
