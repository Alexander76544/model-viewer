/* r61: «Импорт CAD» как в PC-DMIS (Файл → Импорт → CAD).
 * Из managed_cs взят CadImport: это мастер, который через COM вызывает PartProgram.Import / Import2(MERGE)
 * у запущенного PC-DMIS, а сами трансляторы (DCT) — нативные и в архив не входят. Поэтому список форматов,
 * множественный выбор файлов и режим «объединить» повторены по CadImport, а чтение файлов сделано своим:
 *   STEP / IGES / BREP — OpenCascade (occt-import-js, WASM, LGPL) — полноценные B-rep, сплайны, сборки, цвета;
 *   STL / OBJ — штатные парсеры генератора; XYZ — облако точек; DXF — каркас + 3DFACE.
 * Файлы движка: cad/occt-import-js.js + cad/occt-wasm-b64.js (офлайн, file://) или cad/occt-import-js.wasm (сервер). */
(function () {
  'use strict';
  if (window.__p61) return; window.__p61 = true;
  function G(n) { try { return eval(n); } catch (e) { return undefined; } } // eslint-disable-line no-eval
  function $(id) { return document.getElementById(id); }
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function toast(m) { try { (window.__p57api && window.__p57api.toast) ? window.__p57api.toast(m) : G('toast')(m.replace(/<[^>]+>/g, '')); } catch (e) {} }
  function LS(k, d) { try { var v = localStorage.getItem('p61.' + k); return v == null ? d : v; } catch (e) { return d; } }
  function LSset(k, v) { try { localStorage.setItem('p61.' + k, String(v)); } catch (e) {} }

  /* ---------- форматы (по CadImport str103…str123) ---------- */
  var FMT = [
    { n: 'STEP', ext: ['stp', 'step', 'p21'], ok: 'OpenCascade' },
    { n: 'IGES', ext: ['igs', 'iges', 'ige'], ok: 'OpenCascade' },
    { n: 'BREP (OpenCascade)', ext: ['brep', 'brp'], ok: 'OpenCascade' },
    { n: 'STL', ext: ['stl'], ok: 'сетка' },
    { n: 'OBJ', ext: ['obj'], ok: 'сетка' },
    { n: 'AutoCAD DXF', ext: ['dxf'], ok: 'каркас, 3DFACE' },
    { n: 'XYZ — облако точек', ext: ['xyz', 'asc', 'pts', 'csv'], ok: 'точки' },
    { n: 'AutoCAD DWG', ext: ['dwg'], no: 'закрытый формат — сохраните в DXF' },
    { n: 'VDAFS', ext: ['vda'], no: 'нужен транслятор PC-DMIS — экспортируйте в STEP/IGES' },
    { n: 'CATIA 5', ext: ['catpart', 'catproduct'], no: 'нужен транслятор PC-DMIS (DCT) — экспортируйте в STEP' },
    { n: 'CATIA 4', ext: ['model', 'exp', 'cat'], no: 'нужен транслятор PC-DMIS — экспортируйте в STEP' },
    { n: 'Unigraphics / Parasolid', ext: ['prt', 'x_t', 'x_b', 'xmt_txt', 'xmt_bin'], no: 'нужен транслятор PC-DMIS — экспортируйте в STEP' },
    { n: 'Pro/ENGINEER', ext: ['asm'], no: 'нужен транслятор PC-DMIS — экспортируйте в STEP' },
    { n: 'PC-DMIS CAD (.cad)', ext: ['cad'], ok: 'анализ + встроенные STEP/IGES/STL; иначе — cad-export' },
    { n: 'GDX / DES', ext: ['gdx', 'des'], no: 'внутренний формат PC-DMIS — экспортируйте в STEP' },
    { n: 'DMIS', ext: ['dmi', 'dms'], no: 'используйте «Файл → Импорт результатов / DMIS»' }
  ];
  function fmtOf(name) { var e = String(name).split('.').pop().toLowerCase(); for (var i = 0; i < FMT.length; i++) if (FMT[i].ext.indexOf(e) >= 0) return FMT[i]; return null; }
  var OURS = ['cad', 'stp', 'step', 'p21', 'igs', 'iges', 'ige', 'brep', 'brp', 'dxf', 'xyz', 'asc', 'pts'];
  var ACCEPT = FMT.filter(function (f) { return f.ok; }).map(function (f) { return f.ext.map(function (e) { return '.' + e; }).join(','); }).join(',');

  /* ---------- OpenCascade ---------- */
  var occtP = null;
  function loadScript(src) { return new Promise(function (res, rej) { var s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = function () { rej(new Error('не найден ' + src)); }; document.head.appendChild(s); }); }
  function occt() {
    if (occtP) return occtP;
    occtP = (window.occtimportjs ? Promise.resolve() : loadScript('cad/occt-import-js.js')).then(function () {
      var viaFile = location.protocol === 'file:';
      var bin = viaFile ? null : fetch('cad/occt-import-js.wasm').then(function (r) { if (!r.ok) throw 0; return r.arrayBuffer(); }).catch(function () { return null; });
      return Promise.resolve(bin).then(function (ab) {
        if (ab) return new Uint8Array(ab);
        return (window.__OCCT_WASM_B64 ? Promise.resolve() : loadScript('cad/occt-wasm-b64.js')).then(function () {
          var s = atob(window.__OCCT_WASM_B64), u = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) u[i] = s.charCodeAt(i);
          window.__OCCT_WASM_B64 = null; return u;
        });
      }).then(function (u8) { return window.occtimportjs({ wasmBinary: u8 }); });
    });
    occtP.catch(function () { occtP = null; });
    return occtP;
  }
  var QUAL = { coarse: [0.003, 0.8], normal: [0.001, 0.5], fine: [0.0003, 0.25] };
  function readBrep(file, buf, q) {
    var ext = file.name.split('.').pop().toLowerCase();
    return occt().then(function (oc) {
      var p = { linearUnit: 'millimeter', linearDeflectionType: 'bounding_box_ratio', linearDeflection: QUAL[q][0], angularDeflection: QUAL[q][1] };
      var u8 = new Uint8Array(buf), r;
      if (ext === 'igs' || ext === 'iges' || ext === 'ige') r = oc.ReadIgesFile(u8, p);
      else if (ext === 'brep' || ext === 'brp') r = oc.ReadBrepFile(u8, p);
      else r = oc.ReadStepFile(u8, p);
      if (!r || !r.success) throw new Error('OpenCascade не смог прочитать файл');
      // имена тел из дерева сборки
      var path = {};
      (function walk(nd, pre) { var nm = nd.name ? (pre ? pre + ' / ' : '') + nd.name : pre; (nd.meshes || []).forEach(function (i) { path[i] = nm; }); (nd.children || []).forEach(function (c) { walk(c, nm); }); })(r.root || {}, '');
      var tri = 0; r.meshes.forEach(function (m) { tri += m.index.array.length / 3; });
      var pos = new Float32Array(tri * 9), col = new Float32Array(tri * 9), anyCol = false, o = 0, bodies = [];
      r.meshes.forEach(function (m, mi) {
        var P = m.attributes.position.array, I = m.index.array, mc = m.color || null, nt = I.length / 3, faceCol = new Array(nt);
        (m.brep_faces || []).forEach(function (f) { if (f.color) for (var t = f.first; t <= f.last; t++) faceCol[t] = f.color; });
        if (mc || (m.brep_faces || []).some(function (f) { return f.color; })) anyCol = true;
        var t0 = o / 9;
        for (var t = 0; t < nt; t++) {
          var c = faceCol[t] || mc || [0.72, 0.75, 0.8];
          for (var k = 0; k < 3; k++) { var vi = I[t * 3 + k] * 3; pos[o] = P[vi]; pos[o + 1] = P[vi + 1]; pos[o + 2] = P[vi + 2]; col[o] = c[0]; col[o + 1] = c[1]; col[o + 2] = c[2]; o += 3; }
        }
        bodies.push({ name: (path[mi] ? path[mi] + (m.name && m.name !== path[mi].split(' / ').pop() ? ' / ' + m.name : '') : (m.name || ('Тело ' + (mi + 1)))), tris: [t0, o / 9] });
      });
      return { pos: pos, col: anyCol ? col : null, bodies: bodies };
    });
  }

  /* ---------- DXF / XYZ ---------- */
  function parseDXF(text, k) {
    var L = text.split(/\r?\n/), pairs = [];
    for (var i = 0; i + 1 < L.length; i += 2) pairs.push([parseInt(L[i], 10), L[i + 1].trim()]);
    var segs = [], tris = [], pts = [], i0 = 0;
    while (i0 < pairs.length && !(pairs[i0][0] === 2 && pairs[i0][1] === 'ENTITIES')) i0++;
    var ent = null, list = [];
    for (var j = i0; j < pairs.length; j++) {
      var c = pairs[j][0], v = pairs[j][1];
      if (c === 0) { if (ent) list.push(ent); if (v === 'ENDSEC') { ent = null; break; } ent = { t: v, g: [] }; continue; }
      if (ent) ent.g.push([c, v]);
    }
    if (ent) list.push(ent);
    function gv(e, code, d) { for (var q = 0; q < e.g.length; q++) if (e.g[q][0] === code) return parseFloat(e.g[q][1]); return d; }
    function P(x, y, z) { return [x * k, y * k, (z || 0) * k]; }
    function arc(cx, cy, cz, r, a0, a1) { if (a1 <= a0) a1 += 360; var n = Math.max(8, Math.ceil((a1 - a0) / 6)), prev = null; for (var s = 0; s <= n; s++) { var a = (a0 + (a1 - a0) * s / n) * Math.PI / 180, p = P(cx + r * Math.cos(a), cy + r * Math.sin(a), cz); if (prev) segs.push(prev, p); prev = p; } }
    var poly = null;
    list.forEach(function (e) {
      if (e.t === 'LINE') segs.push(P(gv(e, 10, 0), gv(e, 20, 0), gv(e, 30, 0)), P(gv(e, 11, 0), gv(e, 21, 0), gv(e, 31, 0)));
      else if (e.t === 'CIRCLE') arc(gv(e, 10, 0), gv(e, 20, 0), gv(e, 30, 0), gv(e, 40, 1), 0, 360);
      else if (e.t === 'ARC') arc(gv(e, 10, 0), gv(e, 20, 0), gv(e, 30, 0), gv(e, 40, 1), gv(e, 50, 0), gv(e, 51, 360));
      else if (e.t === 'POINT') pts.push(P(gv(e, 10, 0), gv(e, 20, 0), gv(e, 30, 0)));
      else if (e.t === '3DFACE') {
        var v = [0, 1, 2, 3].map(function (q) { return P(gv(e, 10 + q, 0), gv(e, 20 + q, 0), gv(e, 30 + q, 0)); });
        tris.push(v[0], v[1], v[2]); if (v[3].join() !== v[2].join()) tris.push(v[0], v[2], v[3]);
      } else if (e.t === 'LWPOLYLINE') {
        var el = gv(e, 38, 0), closed = (gv(e, 70, 0) & 1) === 1, vs = [], cx = null;
        e.g.forEach(function (g) { if (g[0] === 10) cx = parseFloat(g[1]); else if (g[0] === 20 && cx != null) { vs.push(P(cx, parseFloat(g[1]), el)); cx = null; } });
        for (var q = 1; q < vs.length; q++) segs.push(vs[q - 1], vs[q]); if (closed && vs.length > 2) segs.push(vs[vs.length - 1], vs[0]);
      } else if (e.t === 'POLYLINE') { poly = { closed: (gv(e, 70, 0) & 1) === 1, vs: [] }; }
      else if (e.t === 'VERTEX' && poly) poly.vs.push(P(gv(e, 10, 0), gv(e, 20, 0), gv(e, 30, 0)));
      else if (e.t === 'SEQEND' && poly) { var w = poly.vs; for (var z = 1; z < w.length; z++) segs.push(w[z - 1], w[z]); if (poly.closed && w.length > 2) segs.push(w[w.length - 1], w[0]); poly = null; }
    });
    return { segs: segs, tris: tris, pts: pts };
  }
  function parseXYZ(text, k) {
    var out = [];
    text.split(/\r?\n/).forEach(function (ln) {
      var m = ln.trim().replace(/,(?=\d)/g, '.').split(/[\s;,\t]+/).map(parseFloat);
      if (m.length >= 3 && isFinite(m[0]) && isFinite(m[1]) && isFinite(m[2])) out.push([m[0] * k, m[1] * k, m[2] * k]);
    });
    return out;
  }

  /* ---------- вспомогательная графика (облака/каркас DXF) ---------- */
  var extras = [];
  function clearExtras() { var sc = G('scene3'); extras.forEach(function (o) { if (sc) sc.remove(o); o.traverse(function (x) { if (x.geometry) x.geometry.dispose(); if (x.material) x.material.dispose(); }); }); extras = []; }
  function addExtra(obj) { var sc = G('scene3'); if (!sc) return; obj.userData.p61 = 1; obj.renderOrder = 980; sc.add(obj); extras.push(obj); }
  function tv(p) { return [p[0], p[2], p[1]]; } // деталь → three
  function fitTo(box) {
    var T = window.THREE; if (box.isEmpty()) return;
    try { G('camTarget3').copy(box.getCenter(new T.Vector3())); var s = box.getSize(new T.Vector3()); (0, eval)('camDist3 = ' + Math.max(s.x, s.y, s.z, 20) * 1.6); G('updateCamera3')(); } catch (e) {}
  }

  /* ---------- импорт ---------- */

  /* ---------- PC-DMIS .CAD: анализ контейнера ----------
   * Формат .CAD закрытый (пишет нативный PCDLRN.exe; в managed_cs его нет — только COM
   * PartPrograms.OpenRoutine(prg, cad) / PartProgram.Export). Здесь: ищем встроенные
   * STEP/IGES/STL (в т.ч. в потоках OLE и zlib-блоках); если нет — отчёт + cad-export. */
  function asc(u8, a, n) { var s = ''; for (var i = a; i < Math.min(u8.length, a + n); i++) s += String.fromCharCode(u8[i]); return s; }
  function findAscii(u8, str, from) { var c0 = str.charCodeAt(0), L = str.length; outer: for (var i = from || 0; i <= u8.length - L; i++) { if (u8[i] !== c0) continue; for (var j = 1; j < L; j++) if (u8[i + j] !== str.charCodeAt(j)) continue outer; return i; } return -1; }
  function scanPayload(u8, where) {
    var i = findAscii(u8, 'ISO-10303-21;'); if (i >= 0) { var e = findAscii(u8, 'END-ISO-10303-21;', i); return { kind: 'stp', buf: u8.subarray(i, e > 0 ? e + 17 : u8.length), where: where }; }
    // IGES: 80-симв. строки, в колонке 73 буква S, 74..80 — номер
    for (var k = 0; k + 80 <= u8.length && k < 4e6; k++) {
      if (u8[k + 72] === 83 && asc(u8, k + 73, 7) === '      1' && (k === 0 || u8[k - 1] === 10 || u8[k - 1] === 13)) {
        var t = findAscii(u8, 'T      1', k); return { kind: 'igs', buf: u8.subarray(k, t > 0 ? t + 8 : u8.length), where: where };
      }
    }
    if (asc(u8, 0, 6) === 'solid ' && findAscii(u8, 'facet normal') > 0) return { kind: 'stl', buf: u8, where: where };
    if (u8.length > 84) { var n = new DataView(u8.buffer, u8.byteOffset).getUint32(80, true); if (n > 0 && 84 + n * 50 === u8.length) return { kind: 'stl', buf: u8, where: where }; }
    return null;
  }
  function inflate(u8, raw) {
    if (typeof DecompressionStream === 'undefined') return Promise.resolve(null);
    try {
      var ds = new DecompressionStream(raw ? 'deflate-raw' : 'deflate'), w = ds.writable.getWriter();
      w.write(u8).catch(function () {}); w.close().catch(function () {});
      var rd = ds.readable.getReader(), chunks = [], n = 0;
      var done = function () { if (!n) return null; var o = new Uint8Array(n), p = 0; chunks.forEach(function (c) { o.set(c, p); p += c.length; }); return o; };
      var pump = function () { return rd.read().then(function (r) { if (r.done || n > 2e8) return done(); chunks.push(r.value); n += r.value.length; return pump(); }, function () { return done(); }); };
      return pump();
    } catch (e) { return Promise.resolve(null); }
  }
  function strings(u8, max) {
    var out = [], cur = '', i, c;
    for (i = 0; i < u8.length && out.length < max; i++) { c = u8[i]; if (c >= 32 && c < 127) cur += String.fromCharCode(c); else { if (cur.length >= 6) out.push(cur); cur = ''; } }
    cur = ''; for (i = 0; i + 1 < u8.length && out.length < max * 2; i += 2) { c = u8[i] | (u8[i + 1] << 8); if (c >= 32 && c < 0x500 && c !== 0x7f) cur += String.fromCharCode(c); else { if (cur.length >= 6) out.push('u16: ' + cur); cur = ''; } }
    return out;
  }
  function hex(u8, n) { var s = []; for (var i = 0; i < Math.min(n, u8.length); i++) s.push((u8[i] < 16 ? '0' : '') + u8[i].toString(16)); return s.join(' '); }

  // MFC CArchive: новый класс = FF FF, WORD схема, WORD длина, ASCII имя (CRuntimeClass::Store)
  function mfcClasses(u8) {
    var res = [], seen = {};
    for (var i = 0; i + 6 < u8.length && res.length < 300; i++) {
      if (u8[i] !== 0xff || u8[i + 1] !== 0xff) continue;
      var len = u8[i + 4] | (u8[i + 5] << 8); if (len < 2 || len > 64 || i + 6 + len > u8.length) continue;
      var nm = '', ok = true; for (var j = 0; j < len; j++) { var c = u8[i + 6 + j]; if (!((c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c === 95)) { ok = false; break; } nm += String.fromCharCode(c); }
      if (!ok || !/^[A-Za-z_]/.test(nm)) continue;
      var key = nm; if (!seen[key]) { seen[key] = 1; res.push({ off: i, schema: u8[i + 2] | (u8[i + 3] << 8), name: nm }); }
      i += 5 + len;
    }
    return res;
  }
  function probeCad(file, u8) {
    var R = window.PcdCadReader;
    if (R && u8.length > 17 && u8[0] === 0xff && u8[1] === 0xff && asc(u8, 6, 11) === 'CPCDbc_coll') {
      status('Чтение PC-DMIS .CAD: ' + file.name + '…');
      return (R.readAsync ? R.readAsync(u8, { progress: function (x) { status('Чтение PC-DMIS .CAD: ' + file.name + ' — ' + Math.round(x * 100) + '%'); } }) : Promise.resolve(R.read(u8))).then(function (res) { return cadResult(file, u8, res); });
    }
    return probeOther(file, u8);
  }
  function cadResult(file, u8, res) {
    status('PC-DMIS .CAD: ' + file.name + ' — прочитан, строю модель…');
    {
      var tri = 0, pts = 0;
      res.meshes.forEach(function (m) { tri += m.tri.length / 3; if (!m.tri.length) pts += m.nv; });
      if (tri || pts) {
        var pos = new Float32Array(tri * 9), o = 0, pa = new Float32Array(pts * 3), q = 0;
        res.meshes.forEach(function (m) {
          if (!m.tri.length) { for (var k = 0; k < m.nv * 3; k += 3) { pa[q++] = m.V[k]; pa[q++] = m.V[k + 2]; pa[q++] = m.V[k + 1]; } return; }
          for (var j = 0; j < m.tri.length; j++) { var v = m.tri[j] * 3; pos[o++] = m.V[v]; pos[o++] = m.V[v + 1]; pos[o++] = m.V[v + 2]; }
        });
        var ex = cadExtras(u8, res, pos);
        return Promise.resolve({ kind: 'mesh', pos: ex.pos || pos, pts: pa, log: res.log.concat(ex.log), col: ex.col, wire: ex.wire, wireBody: ex.wireBody, groups: ex.groups, triFace: ex.triFace, cad: ex.cad, cadBodies: ex.bodies });
      }
      var rep0 = ['Файл: ' + file.name + ' (' + u8.length.toLocaleString('ru') + ' Б)'].concat(res.log, ['', 'Сохранённой тесселяции не найдено — модель хранится только как точная геометрия (NURBS/B-rep).', 'Её разбор — следующий этап; пока используйте cad-export (PC-DMIS → STEP).']);
      showCadReport(file.name, rep0.join('\n'));
      return Promise.reject(new Error('в .CAD нет сохранённой тесселяции — см. отчёт'));
    }
  }
  // r66: точные объекты .CAD (pcdmis-cad-objects.js) — каркас из линий/дуг и цвета граней
  function cadExtras(u8, res, pos) {
    var O = window.PcdCadObjects, out = { log: [], col: null, wire: null, groups: [] };
    if (!O || !res.header) return out;
    var t0 = performance.now(), o;
    try { o = O.parse(u8, res.header); } catch (e) { out.log.push('Объекты .CAD: не разобраны — ' + e.message); return out; }
    var st = o.start, ty = o.type, N = o.N;
    function recOf(at) { var lo = 1, hi = N; while (lo < hi) { var m = (lo + hi + 1) >> 1; if (st[m] <= at) lo = m; else hi = m - 1; } return lo; }
    // цвет: сетка лежит внутри записи FaceEntity (103) → её ARGB
    var col = new Float32Array(pos.length), q = 0, grp = {}, faces = 0, triFace = new Int32Array(pos.length / 9), tq = 0, bodyT = {}, bodyF = {};
    res.meshes.forEach(function (m) {
      if (!m.tri.length) return;
      var i = recOf(m.at), c = ty[i] === 103 ? o.colors[i] : 0, r = 0.72, g = 0.72, b = 0.72;
      if (c) { r = ((c >> 16) & 255) / 255; g = ((c >> 8) & 255) / 255; b = (c & 255) / 255; faces++; }
      var key = c ? '#' + (c & 0xffffff).toString(16).padStart(6, '0') : 'без цвета';
      var G0 = grp[key] || (grp[key] = { name: key, tris: 0, faces: 0 }); G0.tris += m.tri.length / 3; G0.faces++;
      for (var j = 0; j < m.tri.length; j++) { col[q++] = r; col[q++] = g; col[q++] = b; }
      var fh = ty[i] === 103 ? i : 0; for (var j2 = 0; j2 < m.tri.length / 3; j2++) triFace[tq++] = fh;
      var bh = fh ? o.faceBody[fh] : 0; bodyT[bh] = (bodyT[bh] || 0) + m.tri.length / 3; bodyF[bh] = (bodyF[bh] || 0) + 1;
    });
    // r66k: треугольники сетки файла, стягивающие отверстие поперёк (вершины на поверхности, а сам треугольник поперёк оси),
    // схлопываем в точку: цилиндр — нормаль треугольника почти ∥ оси; тор — центр треугольника далеко от поверхности
    try {
      var nDrop = 0, nTri0 = pos.length / 9;
      for (var tI = 0; tI < nTri0; tI++) {
        var fI = triFace[tI]; if (!fI) continue; var sf = o.surfaces[o.faceSurf[fI]]; if (!sf || (sf.k !== 'CYLINDER' && sf.k !== 'TORUS')) continue;
        var b9 = tI * 9, ax = pos[b9], ay = pos[b9 + 1], az = pos[b9 + 2], ux = pos[b9 + 3] - ax, uy = pos[b9 + 4] - ay, uz = pos[b9 + 5] - az, vx = pos[b9 + 6] - ax, vy = pos[b9 + 7] - ay, vz = pos[b9 + 8] - az;
        var A = sf.A, drop = false;
        if (sf.k === 'CYLINDER') {
          var nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx, nl = Math.sqrt(nx * nx + ny * ny + nz * nz);
          if (nl > 1e-12 && Math.abs(nx * A[0] + ny * A[1] + nz * A[2]) / nl > 0.7) drop = true;
        } else {
          var cx = ax + (ux + vx) / 3 - sf.O[0], cy = ay + (uy + vy) / 3 - sf.O[1], cz = az + (uz + vz) / 3 - sf.O[2], tt = cx * A[0] + cy * A[1] + cz * A[2];
          var rx = cx - tt * A[0], ry = cy - tt * A[1], rz = cz - tt * A[2], rho = Math.sqrt(rx * rx + ry * ry + rz * rz), dv = Math.abs(Math.sqrt((rho - sf.Rmaj) * (rho - sf.Rmaj) + tt * tt) - sf.R);
          if (dv > Math.max(0.5 * sf.R, 0.2 * sf.Rmaj)) drop = true;
        }
        if (drop) { pos[b9 + 3] = pos[b9 + 6] = ax; pos[b9 + 4] = pos[b9 + 7] = ay; pos[b9 + 5] = pos[b9 + 8] = az; nDrop++; }
      }
      if (nDrop) out.log.push('Убрано треугольников, закрывавших отверстия: ' + nDrop.toLocaleString('ru'));
      out.pos = pos; out.nDropHole = nDrop;
    } catch (e) { out.log.push('Фильтр треугольников отверстий: ошибка — ' + e.message); }
    // r66c: плоские грани без сетки в файле — строим по контуру (pcdmis-cad-planes.js)
    if (window.PcdCadPlanes) {
      try {
        var pl = window.PcdCadPlanes.build(o), nT = pl.face.length;
        if (nT) {
          var pos2 = new Float32Array(pos.length + pl.pos.length); pos2.set(pos, 0); pos2.set(pl.pos, pos.length);
          var col2 = new Float32Array(pos2.length); col2.set(col, 0); var tf2 = new Int32Array(triFace.length + nT); tf2.set(triFace, 0); tf2.set(pl.face, triFace.length);
          var qq = col.length, cnt = {};
          for (var t = 0; t < nT; t++) {
            var fh2 = pl.face[t], c2 = o.colors[fh2], r2 = 0.72, g2 = 0.72, b2 = 0.72; if (c2) { r2 = ((c2 >> 16) & 255) / 255; g2 = ((c2 >> 8) & 255) / 255; b2 = (c2 & 255) / 255; faces++; }
            for (var k2 = 0; k2 < 3; k2++) { col2[qq++] = r2; col2[qq++] = g2; col2[qq++] = b2; }
            var bh2 = o.faceBody[fh2]; bodyT[bh2] = (bodyT[bh2] || 0) + 1; if (!cnt[fh2]) { cnt[fh2] = 1; bodyF[bh2] = (bodyF[bh2] || 0) + 1; }
          }
          pos = pos2; col = col2; triFace = tf2; out.pos = pos2;
        }
        out.log.push('Плоские грани (в файле без сетки): построено по контуру ' + pl.nFaces.toLocaleString('ru') + ', не удалось ' + pl.nFail + '; треуг. ' + nT.toLocaleString('ru'));
      } catch (e) { out.log.push('Плоские грани: ошибка — ' + e.message); }
    }
    if (faces) out.col = col;
    out.groups = Object.keys(grp).map(function (k) { return grp[k]; }).sort(function (a, b) { return b.tris - a.tris; });
    out.triFace = triFace; out.cad = o;
    var bn = 0; out.bodies = Object.keys(bodyT).map(function (bh) { var c = o.colors[+bh]; bn++; return { name: (+bh ? 'Тело #' + bh : 'без тела') + (c ? ' · #' + (c & 0xffffff).toString(16).padStart(6, '0') : '') + ' · граней ' + bodyF[bh], tris: bodyT[bh], bh: +bh }; }).sort(function (a, b) { return b.tris - a.tris; });
    // каркас: линии + дуги (оси детали → three: y↔z)
    var w = [], nArcSeg = 0, wb = [], curB = 0, cBody = {};
    // r66f: тело каждой кривой (коребро → цикл → грань → тело) — чтобы скрывать каркас вместе с телом
    o.coedges.forEach(function (c) { var e = o.edges[c.edge], f = o.loopFace[c.loop]; if (e && f && o.faceBody[f]) cBody[e.curve] = o.faceBody[f]; });
    function push(p) { w.push(p[0], p[2], p[1]); if (!(w.length % 6)) wb.push(curB); }
    o.lines.forEach(function (l) { curB = cBody[l.h] || 0; push(l.P1); push(l.P2); });
    o.arcs.forEach(function (a) {
      curB = cBody[a.h] || 0; var a0 = a.a0, a1 = a.a1; if (!(a.R > 0) || !isFinite(a0) || !isFinite(a1)) return;
      if (a1 < a0) a1 += 2 * Math.PI;
      var n = Math.max(4, Math.min(96, Math.ceil((a1 - a0) / (Math.PI / 24)))), prev = O.arcPoint(a, a0);
      for (var k = 1; k <= n; k++) { var p = O.arcPoint(a, a0 + (a1 - a0) * k / n); push(prev); push(p); prev = p; }
      nArcSeg += n;
    });
    // r66d: NURBS-кривые рёбер
    var nNurbs = 0; if (O.curveAt) { for (var eh in o.edges) { var ee = o.edges[eh]; if (o.type[ee.curve] !== 10) continue; var cc = O.curveAt(u8, o, ee.curve); if (!cc) continue; curB = cBody[ee.curve] || 0; var CP = O.curvePoints(cc, 3); for (var ci = 1; ci < CP.length; ci++) { push(CP[ci - 1]); push(CP[ci]); } nNurbs++; } }
    out.wire = new Float32Array(w); out.wireBody = new Int32Array(wb);
    var ns = Object.keys(o.surfaces).length;
    out.log.push('Объекты .CAD (точно): ' + N.toLocaleString('ru') + ' записей за ' + ((performance.now() - t0) / 1000).toFixed(1) + ' с; каркас: линий ' + o.lines.length.toLocaleString('ru') + ', дуг ' + o.arcs.length.toLocaleString('ru') + ', NURBS-рёбер ' + nNurbs.toLocaleString('ru') + '; точных поверхностей ' + ns.toLocaleString('ru'));
    out.log.push('Цвета граней: ' + out.groups.map(function (g) { return g.name + ' — ' + g.faces + ' гр.'; }).join(', '));
    window.__p66cad = o; // для следующего шага: клик по грани → элемент
    return out;
  }
  // r66: каркас поверх модели — переключатель и прозрачность
  var p66wire = null;
  function p66setWire(on) { if (p66wire) p66wire.visible = !!on; LSset('wire', on ? '1' : '0'); try { G('render3') && G('render3')(); } catch (e) {} }
  // r66: Alt+клик по грани → точный элемент (CYLINDER / SPHERE / TORUS / POINT)
  var p66hi = null, p66n = { CYL: 0, SPH: 0, TOR: 0, PNT: 0, PLN: 0 };
  function p66fmt(x) { return (Math.abs(x) < 5e-7 ? 0 : x).toFixed(4); }
  function p66v(a) { return '<' + a.map(p66fmt).join(',') + '>'; }
  function p66norm(a) { var l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; }
  function p66dot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
  function p66feature(P, h, hitPart, viewPart, triNPart, vertsPart) {
    var o = P.cad, sh = o.faceSurf[h], s = o.surfaces[sh], tN = o.type[sh], L = [], info = [], E = [];
    var nm = { 7: 'поверхность вращения', 11: 'B-сплайн (NURBS)', 74: 'плоскость', 75: 'цилиндр', 77: 'сфера', 78: 'тор' }[tN] || ('тип ' + tN);
    info.push('Грань #' + h + ' · тело #' + (o.faceBody[h] || '?') + ' · поверхность #' + sh + ': ' + nm);
    if (s && s.k === 'PLANE') {
      var Np = p66norm(s.N); if (p66dot(Np, viewPart) > 0) Np = [-Np[0], -Np[1], -Np[2]]; // нормаль — к наблюдателю (из материала)
      var cx = 0, cy = 0, cz = 0, nv = vertsPart.length / 3; for (var kk = 0; kk < vertsPart.length; kk += 3) { cx += vertsPart[kk]; cy += vertsPart[kk + 1]; cz += vertsPart[kk + 2]; }
      var Cp = nv ? [cx / nv, cy / nv, cz / nv] : hitPart.slice(), dp = (Cp[0] - s.O[0]) * Np[0] + (Cp[1] - s.O[1]) * Np[1] + (Cp[2] - s.O[2]) * Np[2];
      Cp = [Cp[0] - dp * Np[0], Cp[1] - dp * Np[1], Cp[2] - dp * Np[2]]; // центр сетки грани, спроецированный на точную плоскость
      var idp = 'PLN' + (++p66n.PLN);
      L.push(idp + '     =FEAT/PLANE,CARTESIAN,OUTLINE,LEAST_SQR');
      L.push('            THEO/' + p66v(Cp) + ',' + p66v(Np)); E.push({ type: 'plane', base: 'CAD_PL', p: Cp, w: Np });
      info.push('Точка плоскости — центр грани (по вершинам сетки), нормаль — точная из .CAD.');
    }
    if (s && (s.k === 'CYLINDER' || s.k === 'SPHERE' || s.k === 'TORUS')) {
      var A = p66norm(s.A), d = [hitPart[0] - s.O[0], hitPart[1] - s.O[1], hitPart[2] - s.O[2]], t = p66dot(d, A);
      var rad = [d[0] - t * A[0], d[1] - t * A[1], d[2] - t * A[2]];
      var inner = p66dot(rad, viewPart) > 0; // видим внутреннюю сторону → отверстие
      if (p66dot(A, viewPart) > 0) A = [-A[0], -A[1], -A[2]]; // ось — к наблюдателю (из материала)
      if (s.k === 'CYLINDER') {
        var mn = 1e30, mx = -1e30; for (var k = 0; k < vertsPart.length; k += 3) { var tt = (vertsPart[k] - s.O[0]) * A[0] + (vertsPart[k + 1] - s.O[1]) * A[1] + (vertsPart[k + 2] - s.O[2]) * A[2]; if (tt < mn) mn = tt; if (tt > mx) mx = tt; }
        if (!(mx > mn)) { mn = mx = t; }
        var C = [s.O[0] + A[0] * mn, s.O[1] + A[1] * mn, s.O[2] + A[2] * mn]; // начало — нижний конец по оси
        var Cm = [s.O[0] + A[0] * (mn + mx) / 2, s.O[1] + A[1] * (mn + mx) / 2, s.O[2] + A[2] * (mn + mx) / 2];
        var id = 'CYL' + (++p66n.CYL);
        L.push(id + '     =FEAT/CYLINDER,CARTESIAN,' + (inner ? 'IN' : 'OUT') + ',LEAST_SQR');
        L.push('            THEO/' + p66v(C) + ',' + p66v(A) + ',' + p66fmt(2 * s.R) + ',' + p66fmt(mx - mn)); E.push({ type: 'cylinder', base: 'CAD_CYL', p: C, w: A, extra: { diam: p66fmt(2 * s.R), depth: p66fmt(mx - mn) } });
        info.push((inner ? 'Отверстие' : 'Вал') + ' Ø' + p66fmt(2 * s.R) + ', длина ' + p66fmt(mx - mn) + '; середина оси ' + p66v(Cm));
      } else if (s.k === 'SPHERE') {
        var id2 = 'SPH' + (++p66n.SPH);
        var inS = p66dot(d, viewPart) > 0;
        L.push(id2 + '     =FEAT/SPHERE,CARTESIAN,' + (inS ? 'IN' : 'OUT') + ',LEAST_SQR');
        L.push('            THEO/' + p66v(s.O) + ',' + p66v(A) + ',' + p66fmt(2 * s.R)); E.push({ type: 'sphere', base: 'CAD_SPH', p: s.O, w: A, extra: { diam: p66fmt(2 * s.R) } });
      } else {
        var id3 = 'TOR' + (++p66n.TOR);
        L.push('$$ ' + id3 + ': ТОР центр ' + p66v(s.O) + ' ось ' + p66v(A) + ' Rбол=' + p66fmt(s.Rmaj) + ' Rмал=' + p66fmt(s.R));
        info.push('Тор обычно — скругление/фаска; меряется точками или сечением.');
      }
    }
    if (!L.length || (s && s.k === 'TORUS')) { // свободная поверхность → точка (нормаль пока по треугольнику)
      var Nn = triNPart; if (p66dot(Nn, viewPart) > 0) Nn = [-Nn[0], -Nn[1], -Nn[2]];
      if (s && s.k === 'TORUS') { var Ad = p66norm(s.A), dd = [hitPart[0] - s.O[0], hitPart[1] - s.O[1], hitPart[2] - s.O[2]], ta = p66dot(dd, Ad), rr = p66norm([dd[0] - ta * Ad[0], dd[1] - ta * Ad[1], dd[2] - ta * Ad[2]]), Ct = [s.O[0] + rr[0] * s.Rmaj, s.O[1] + rr[1] * s.Rmaj, s.O[2] + rr[2] * s.Rmaj]; Nn = p66norm([hitPart[0] - Ct[0], hitPart[1] - Ct[1], hitPart[2] - Ct[2]]); if (p66dot(Nn, viewPart) > 0) Nn = [-Nn[0], -Nn[1], -Nn[2]]; info.push('Нормаль точки — точная, по тору.'); }
      else if (tN === 11 && window.PcdCadNurbs && o.__u8) {
        var ns = null; try { ns = window.PcdCadNurbs.read(o.__u8, o, sh); } catch (e) { ns = null; }
        var pr = ns ? window.PcdCadNurbs.project(ns, hitPart, 24) : null;
        if (pr && pr.N && pr.dist < 0.5) { hitPart = pr.P; Nn = pr.N; if (p66dot(Nn, viewPart) > 0) Nn = [-Nn[0], -Nn[1], -Nn[2]]; info.push('Точка спроецирована на точную NURBS-поверхность (сдвиг ' + pr.dist.toFixed(4) + ' мм), нормаль — точная.'); }
        else info.push('NURBS не удалось спроецировать — нормаль по треугольнику сетки.');
      }
      else info.push('Нормаль точки — по треугольнику сетки (поверхность вращения — следующий шаг).');
      var id4 = 'PNT' + (++p66n.PNT);
      L.push(id4 + '     =FEAT/POINT,CARTESIAN');
      L.push('            THEO/' + p66v(hitPart) + ',' + p66v(p66norm(Nn))); E.push({ type: 'point_measured', base: 'CAD_PT', p: hitPart, w: p66norm(Nn) });
    }
    return { text: L.join('\n'), info: info, els: E };
  }
  /* r66g: добавить элемент(ы) по грани в активную операцию генератора */
  function p66addToProgram(els) {
    var mk = window.__pcdMkBaseEl, fnm = window.__pcdFreeName, prog = null;
    if (!mk || !fnm) { toast('Генератор не готов (нет __pcdMkBaseEl)'); return []; }
    try { prog = (typeof cur === 'function') ? cur() : null; } catch (e) { prog = null; }
    if (!prog) { try { var A = window.__p57api; prog = A && A.S && A.S(); } catch (e2) { prog = null; } }
    if (!prog || !prog.elements) { toast('Нет активной операции — создайте или выберите её'); return []; }
    var made = [], have = {}; prog.elements.forEach(function (x) { if (x && x.name) have[x.name] = 1; });
    (els || []).forEach(function (f) {
      var ni = 1; while (have[f.base + ni]) ni++; var nm = f.base + ni; have[nm] = 1; var P3 = { x: f.p[0], y: f.p[1], z: f.p[2] }, W3 = { x: f.w[0], y: f.w[1], z: f.w[2] };
      var e = mk(f.type, nm, P3, W3, f.extra); e.group = 'CAD'; prog.elements.push(e); made.push(nm);
    });
    try { if (typeof reRender === 'function') reRender(); else if (window.__p57api && window.__p57api.refresh) window.__p57api.refresh(); } catch (e3) {}
    try { window.__p57api && window.__p57api.dirty && window.__p57api.dirty(); } catch (e4) {}
    toast(made.length ? 'Добавлено в программу: ' + (made.length > 6 ? made.length + ' элементов' : made.join(', ')) : 'Нечего добавлять');
    return made;
  }
  window.pcdCadAddToProgram = p66addToProgram;
  /* r66h: все элементы из .CAD сразу */
  function p66bulkCollect() {
    var P = window.__p66pick, mesh = G('stlMesh3'); if (!P || !P.cad || !mesh || !window.PcdCadFeatures) return null;
    var g = function (id) { return $(id); }, num = function (id, d) { var x = parseFloat(String((g(id) || {}).value || '').replace(',', '.')); return isFinite(x) ? x : d; };
    var types = { plane: g('p66kPl') && g('p66kPl').checked ? 1 : 0, cylinder: (g('p66kHo') && g('p66kHo').checked) || (g('p66kSh') && g('p66kSh').checked) ? 1 : 0, sphere: g('p66kSp') && g('p66kSp').checked ? 1 : 0 };
    var r = window.PcdCadFeatures.collect(P, P.bak || mesh.geometry.attributes.position.array, { swapped: true, visibleOnly: g('p66kVis') ? g('p66kVis').checked : true, types: types, minPlaneArea: num('p66kA', 5), minDiam: num('p66kD1', 1), maxDiam: num('p66kD2', 1e9) });
    var ho = g('p66kHo') && g('p66kHo').checked, sh = g('p66kSh') && g('p66kSh').checked;
    r.els = r.els.filter(function (e) { return e.type !== 'cylinder' || (e.inner ? ho : sh); });
    var c = { plane: 0, hole: 0, shaft: 0, sphere: 0 }; r.els.forEach(function (e) { if (e.type === 'cylinder') c[e.inner ? 'hole' : 'shaft']++; else c[e.type]++; });
    r.cnt = c; return r;
  }
  function p66bulkDialog() {
    var P = window.__p66pick; if (!P || !P.cad) { toast('Сначала загрузите .CAD'); return; }
    var d = $('p66bulk'); if (d) d.remove(); d = document.createElement('div'); d.id = 'p66bulk';
    d.style.cssText = 'position:fixed;right:16px;top:70px;z-index:99999;background:#fff;border:1px solid #8aa;box-shadow:0 4px 16px rgba(0,0,0,.25);padding:8px 10px;font:12px Segoe UI,Arial;width:380px';
    var cb = function (id, t, on) { return '<label style="display:block"><input type="checkbox" id="' + id + '"' + (on ? ' checked' : '') + '> ' + t + '</label>'; };
    var ip = function (id, v) { return '<input id="' + id + '" value="' + v + '" style="width:60px">'; };
    d.innerHTML = '<div style="font-weight:600;margin-bottom:6px">Все элементы из .CAD → программа</div>' +
      cb('p66kHo', 'Отверстия (цилиндры IN)', 1) + cb('p66kSh', 'Валы / бобышки (цилиндры OUT)', 1) + cb('p66kPl', 'Плоскости', 1) + cb('p66kSp', 'Сферы', 1) +
      cb('p66kVis', 'Только видимые тела (скрытую оснастку не брать)', 1) +
      '<div style="margin-top:4px">Ø от ' + ip('p66kD1', 1) + ' до ' + ip('p66kD2', 1000) + ' мм</div>' +
      '<div style="margin-top:4px">Плоскости площадью от ' + ip('p66kA', 100) + ' мм²</div>' +
      '<div id="p66kRes" style="margin:6px 0;padding:4px;background:#f4f7fa;border:1px solid #d5dde5;min-height:16px"></div>' +
      '<button id="p66kAdd" style="font-weight:600">Добавить в программу</button> <button id="p66kClose">Закрыть</button>';
    document.body.appendChild(d);
    var cur0 = null;
    function upd() { var r = p66bulkCollect(); cur0 = r; var x = $('p66kRes'); if (!x) return; if (!r) { x.textContent = 'Нет данных .CAD'; return; }
      x.innerHTML = 'Будет добавлено: <b>' + r.els.length.toLocaleString('ru') + '</b> — отверстий ' + r.cnt.hole + ', валов ' + r.cnt.shaft + ', плоскостей ' + r.cnt.plane + ', сфер ' + r.cnt.sphere +
        '<div style="color:#678">Половинки одного отверстия слиты: ' + r.stat.merged + '; мелких плоскостей пропущено: ' + r.stat.skippedSmall + '</div>'; }
    ['p66kHo', 'p66kSh', 'p66kPl', 'p66kSp', 'p66kVis', 'p66kD1', 'p66kD2', 'p66kA'].forEach(function (id) { var e = $(id); if (e) { e.onchange = upd; e.oninput = upd; } });
    $('p66kClose').onclick = function () { d.remove(); };
    $('p66kAdd').onclick = function () { var r = cur0 || p66bulkCollect(); if (!r || !r.els.length) { toast('Нечего добавлять'); return; }
      if (r.els.length > 300 && !confirm('Добавить ' + r.els.length + ' элементов в активную операцию?')) return;
      var m = p66addToProgram(r.els); if (m.length) { this.disabled = true; this.textContent = 'Добавлено: ' + m.length; } };
    upd();
  }
  window.pcdCadAddAll = p66bulkDialog;
  function p66show(r) {
    var d = $('p66feat'); if (!d) { d = document.createElement('div'); d.id = 'p66feat'; d.style.cssText = 'position:fixed;right:16px;top:70px;z-index:99999;background:#fff;border:1px solid #8aa;box-shadow:0 4px 16px rgba(0,0,0,.25);padding:8px 10px;font:12px Segoe UI,Arial;max-width:560px'; document.body.appendChild(d); }
    d.innerHTML = '<div style="font-weight:600;margin-bottom:4px">Элемент по грани (точно из .CAD)</div>' + r.info.map(function (x) { return '<div style="color:#345">' + esc(x) + '</div>'; }).join('') +
      '<pre id="p66txt" style="margin:6px 0;padding:6px;background:#f4f7fa;border:1px solid #d5dde5;font:12px Consolas,monospace;white-space:pre">' + esc(r.text) + '</pre>' +
      (r.els && r.els.length ? '<button id="p66add" style="font-weight:600">В программу</button> ' : '') + '<button id="p66copy">Копировать</button> <button id="p66all">Все из CAD…</button> <button id="p66qfB">Оснастка…</button> <button id="p66close">Закрыть</button> <span style="color:#888">Alt+клик — следующая грань</span>';
    if ($('p66add')) $('p66add').onclick = function () { var m = p66addToProgram(r.els); if (m.length) { this.disabled = true; this.textContent = 'Добавлено: ' + m.join(', '); } };
    if ($('p66all')) $('p66all').onclick = p66bulkDialog; if ($('p66qfB')) $('p66qfB').onclick = function () { qfDialog(); };
    $('p66copy').onclick = function () { try { navigator.clipboard.writeText(r.text); toast('Скопировано'); } catch (e) {} };
    $('p66close').onclick = function () { d.remove(); p66clearHi(); };
  }
  function p66clearHi() { var sc = G('scene3'); if (p66hi && sc) { sc.remove(p66hi); p66hi.geometry.dispose(); p66hi.material.dispose(); } p66hi = null; }
  function p66pick(e) {
    if (!e.altKey) return;
    var P = window.__p66pick, mesh = G('stlMesh3'), cam = G('camera3'), dom = e.currentTarget; if (!P || !mesh || !cam || !mesh.isMesh) return;
    var r = dom.getBoundingClientRect(), rc = new T.Raycaster(), pt = new T.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    rc.setFromCamera(pt, cam); var hs = rc.intersectObject(mesh, false); if (!hs.length) return;
    var H = hs[0], ti = H.faceIndex - P.off; if (ti < 0 || ti >= P.n) return; var h = P.triFace[ti]; if (!h) { toast('Треугольник без грани'); return; }
    e.preventDefault(); e.stopPropagation();
    var pa = mesh.geometry.attributes.position.array, sw = function (a) { return [a[0], a[2], a[1]]; }; // three → оси детали
    var XM = P.xf && P.cad && P.xf[P.cad.faceBody[h]], XI = XM ? XM.clone().invert() : null;
    var lp = mesh.worldToLocal(H.point.clone()); if (XI) lp.applyMatrix4(XI); var hitPart = sw([lp.x, lp.y, lp.z]);
    var c0 = cam.position.clone(); mesh.worldToLocal(c0); if (XI) c0.applyMatrix4(XI); var vp = p66norm(sw([lp.x - c0.x, lp.y - c0.y, lp.z - c0.z]));
    var verts = [], hiPos = [], base = P.off * 9, src = XM && P.bak ? P.bak : pa, sb = XM && P.bak ? 0 : base;
    for (var k = 0; k < P.n; k++) if (P.triFace[k] === h) { for (var j = 0; j < 9; j += 3) { var q = base + k * 9 + j, qs = sb + k * 9 + j; verts.push(src[qs], src[qs + 2], src[qs + 1]); hiPos.push(pa[q], pa[q + 1], pa[q + 2]); } }
    var q0 = sb + ti * 9, a = [src[q0], src[q0 + 2], src[q0 + 1]], b = [src[q0 + 3], src[q0 + 5], src[q0 + 4]], c = [src[q0 + 6], src[q0 + 8], src[q0 + 7]];
    var u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], w = [c[0] - a[0], c[1] - a[1], c[2] - a[2]], tn = p66norm([u[1] * w[2] - u[2] * w[1], u[2] * w[0] - u[0] * w[2], u[0] * w[1] - u[1] * w[0]]);
    p66clearHi(); var g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(new Float32Array(hiPos), 3));
    p66hi = new T.Mesh(g, new T.MeshBasicMaterial({ color: 0xff3b30, transparent: true, opacity: 0.55, side: T.DoubleSide, depthTest: false, toneMapped: false }));
    p66hi.matrixAutoUpdate = false; p66hi.matrix.copy(mesh.matrixWorld); p66hi.renderOrder = 990; G('scene3').add(p66hi);
    p66show(p66feature(P, h, hitPart, vp, tn, verts));
  }
  (function p66hook() { var rd = G('renderer3'); if (!rd || !rd.domElement) { setTimeout(p66hook, 1000); return; } if (rd.domElement.__p66) return; rd.domElement.__p66 = 1; rd.domElement.addEventListener('click', p66pick, true); })();
  window.pcdCadWire = { set: p66setWire, get: function () { return p66wire; } };
  function probeOther(file, u8) {
    var parts = [{ where: 'файл', u8: u8 }], rep = ['Файл: ' + file.name + ' (' + u8.length.toLocaleString('ru') + ' Б)', 'Заголовок: ' + hex(u8, 32)];
    var PR = window.PrgRealImport;
    if (PR && PR.isOle && PR.isOle(u8)) {
      rep.push('Контейнер: OLE/CFB (как .PRG). Потоки:');
      try { var st = PR.cfbStreams(u8); Object.keys(st).forEach(function (k) { rep.push('  ' + k + ' — ' + st[k].length.toLocaleString('ru') + ' Б, ' + hex(st[k], 16)); parts.push({ where: 'поток ' + k, u8: st[k] }); }); } catch (e) { rep.push('  ошибка разбора: ' + e.message); }
    } else rep.push('Контейнер: не OLE (собственный двоичный формат)');
    var hit = null; parts.some(function (p) { return (hit = scanPayload(p.u8, p.where)); });
    if (hit) return Promise.resolve(hit);
    // zlib-блоки (78 01/5E/9C/DA) — пробуем распаковать
    var z = [];
    parts.forEach(function (p) { for (var i = 0; i + 2 < p.u8.length && z.length < 40; i++) if (p.u8[i] === 0x78 && (p.u8[i + 1] === 0x9c || p.u8[i + 1] === 0xda || p.u8[i + 1] === 0x01 || p.u8[i + 1] === 0x5e) && ((p.u8[i] << 8) | p.u8[i + 1]) % 31 === 0) z.push({ where: p.where + ' @0x' + i.toString(16), u8: p.u8.subarray(i) }); });
    var ch = Promise.resolve(null), unz = [];
    z.forEach(function (zz) { ch = ch.then(function (h) { if (h) return h; return inflate(zz.u8).then(function (d) { if (!d || d.length < 64) return null; unz.push(zz.where + ' → ' + d.length.toLocaleString('ru') + ' Б'); return scanPayload(d, 'zlib ' + zz.where); }); }); });
    return ch.then(function (h) {
      if (h) return h;
      if (z.length) rep.push('zlib-блоков: ' + z.length + (unz.length ? '; распаковано: ' + unz.join('; ') : ''));
      var cls = []; parts.forEach(function (p) { mfcClasses(p.u8).forEach(function (c) { cls.push('  ' + p.where + ' @0x' + c.off.toString(16) + '  ' + c.name + ' (схема ' + c.schema + ')'); }); });
      rep.push(cls.length ? 'Классы MFC CArchive (CADCollSerializeFromFile пишет .CAD через CArchive): ' + cls.length : 'Классы MFC CArchive: не найдены (возможно, сжатие)');
      cls.slice(0, 120).forEach(function (c) { rep.push(c); });
      rep.push('Встроенных STEP/IGES/STL не найдено.', '', 'Строки (первые):'); strings(u8, 40).forEach(function (s) { rep.push('  ' + s.slice(0, 120)); });
      showCadReport(file.name, rep.join('\n'));
      throw new Error('внутренний формат PC-DMIS: встроенной STEP/IGES/STL-модели нет — экспортируйте через cad-export (см. отчёт)');
    });
  }
  function showCadReport(name, text) {
    var api = window.__p57api, body = '<div style="font:12px Segoe UI,Arial;max-width:640px"><p><b>' + esc(name) + '</b> — внутренний формат PC-DMIS (.CAD). Это поток MFC CArchive (CADDLL.DLL → CADCollSerializeFromFile). Заголовок и тесселяция читаются (pcdmis-cad-reader.js); точная геометрия NURBS/B-rep — в работе.</p>' +
      '<p><b>Как открыть:</b> на ПК с PC-DMIS перетащите .CAD или .PRG на <code>3d\\cad-export\\Экспорт-CAD-из-PC-DMIS.bat</code> — скрипт через COM (PartPrograms.OpenRoutine → PartProgram.Export) сохранит рядом .stp/.igs/.stl. Их откройте здесь.</p>' +
      '<p>Чтобы научить программу читать .CAD напрямую, пришлите этот отчёт, сам .CAD и ту же модель в STEP.</p>' +
      '<textarea readonly style="width:100%;height:220px;font:11px Consolas,monospace">' + esc(text) + '</textarea>' +
      '<div style="margin-top:6px"><button id="p61repSave">Сохранить отчёт…</button></div></div>';
    try { if (api && api.win) { var w = api.win('p61cadrep', 'PC-DMIS .CAD — анализ', 'cube', 680); w.body.innerHTML = body; } else alert(text); } catch (e) { alert(text); }
    var b = document.getElementById('p61repSave'); if (b) b.onclick = function () { var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: 'text/plain' })); a.download = name.replace(/\.[^.]+$/, '') + '-cad-report.txt'; a.click(); };
  }

  function readAs(file, kind) { return new Promise(function (res, rej) { var r = new FileReader(); r.onload = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; if (kind === 'text') r.readAsText(file); else r.readAsArrayBuffer(file); }); }
  function status(t) { var n = $('stlFileName'); if (n) n.textContent = t; var s = $('p61Status'); if (s) s.innerHTML = t; }
  function importFiles(files, opt) {
    opt = opt || {};
    var T = window.THREE, q = opt.quality || LS('q', 'normal'), unitK = (opt.unit || LS('unit', 'mm')) === 'in' ? 25.4 : 1;
    var merge = opt.merge != null ? opt.merge : LS('merge', '0') === '1';
    files = [].slice.call(files || []);
    var bad = files.filter(function (f) { var ff = fmtOf(f.name); return !ff || !ff.ok; });
    if (bad.length) { var ff = fmtOf(bad[0].name); alert('Формат «' + bad[0].name + '» не поддерживается' + (ff && ff.no ? ': ' + ff.no : '') + '.'); files = files.filter(function (f) { return bad.indexOf(f) < 0; }); }
    if (!files.length) return Promise.resolve();
    try { if (G('threeInitialized') === false) G('initThree')(); } catch (e) {}
    var t0 = performance.now(), meshMeta = {}, meshPos = [], meshCol = [], anyCol = false, bodies = [], extraObjs = [], box = new T.Box3(), log = [];
    var chain = Promise.resolve();
    files.forEach(function (f) {
      chain = chain.then(function () {
        var ext = f.name.split('.').pop().toLowerCase();
        status('Импорт CAD: ' + esc(f.name) + '…' + (/stp|step|igs|iges|brep|brp|ige|p21/.test(ext) ? ' (OpenCascade, огранка)' : ''));
        return new Promise(function (r) { setTimeout(r, 30); }).then(function () {
          if (ext === 'cad') return readAs(f).then(function (b) { return probeCad(f, new Uint8Array(b)); }).then(function (hit) {
            if (hit.kind === 'mesh') {
              if (hit.triFace) meshMeta[meshPos.length] = { triFace: hit.triFace, cad: hit.cad };
              meshPos.push(hit.pos); meshCol.push(hit.col || null); if (hit.col) anyCol = true; hit.log.forEach(function (l) { log.push(l); });
              if (hit.wire && hit.wire.length) {
                var gw = new T.BufferGeometry(); gw.setAttribute('position', new T.BufferAttribute(hit.wire, 3));
                p66wire = new T.LineSegments(gw, new T.LineBasicMaterial({ color: 0x1f2a37, toneMapped: false, fog: false }));
                p66wire.userData.p66wire = 1; p66wire.userData.wb = hit.wireBody || null; p66wire.visible = LS('wire', '1') === '1'; extraObjs.push(p66wire); window.__p66wantAlpha = LS('alpha', '0') === '1' ? 0.45 : 1;
              }
              if (hit.cadBodies && hit.cadBodies.length > 1) { hit.cadBodies.forEach(function (g) { bodies.push({ file: f.name, name: g.name, tris: g.tris, bh: g.bh }); }); log.push('Тел в файле: ' + hit.cadBodies.length + ' (грань → оболочка → тело)'); return; }
              if (hit.groups && hit.groups.length > 1) { hit.groups.forEach(function (g) { bodies.push({ file: f.name, name: 'цвет ' + g.name + ' · граней ' + g.faces, tris: g.tris }); }); return; }
              if (hit.pts && hit.pts.length) { var gp = new T.BufferGeometry(); gp.setAttribute('position', new T.BufferAttribute(hit.pts, 3)); extraObjs.push(new T.Points(gp, new T.PointsMaterial({ color: 0x0b6bd8, size: 2, sizeAttenuation: false, toneMapped: false }))); }
              bodies.push({ file: f.name, name: 'тесселяция PC-DMIS', tris: hit.pos.length / 9 }); return;
            }
            if (hit.kind === 'stl') { var p = G('parseSTL')(hit.buf.buffer.slice(hit.buf.byteOffset, hit.buf.byteOffset + hit.buf.byteLength)); meshPos.push(p.positions); meshCol.push(p.colors || null); log.push(f.name + ' → встроенный STL (' + hit.where + '): треуг. ' + (p.positions.length / 9).toLocaleString('ru')); return; }
            return readBrep({ name: 'x.' + hit.kind }, hit.buf.buffer.slice(hit.buf.byteOffset, hit.buf.byteOffset + hit.buf.byteLength), q).then(function (res) {
              meshPos.push(res.pos); meshCol.push(res.col); if (res.col) anyCol = true;
              res.bodies.forEach(function (b) { bodies.push({ file: f.name, name: b.name, tris: b.tris[1] - b.tris[0] }); });
              log.push(f.name + ' → встроенный ' + hit.kind.toUpperCase() + ' (' + hit.where + '): тел ' + res.bodies.length + ', треуг. ' + (res.pos.length / 9).toLocaleString('ru'));
            });
          });
          if (/^(stp|step|p21|igs|iges|ige|brep|brp)$/.test(ext)) return readAs(f).then(function (b) { return readBrep(f, b, q); }).then(function (res) {
            meshPos.push(res.pos); meshCol.push(res.col); if (res.col) anyCol = true;
            res.bodies.forEach(function (b) { bodies.push({ file: f.name, name: b.name, tris: b.tris[1] - b.tris[0] }); });
            log.push(f.name + ': тел ' + res.bodies.length + ', треуг. ' + (res.pos.length / 9).toLocaleString('ru'));
          });
          if (ext === 'stl') return readAs(f).then(function (b) { var p = G('parseSTL')(b); var pos = p.positions; if (unitK !== 1) for (var i = 0; i < pos.length; i++) pos[i] *= unitK; meshPos.push(pos); meshCol.push(p.colors || null); if (p.colors) anyCol = true; log.push(f.name + ': треуг. ' + (pos.length / 9).toLocaleString('ru')); });
          if (ext === 'obj') return readAs(f, 'text').then(function (t) { var pos = G('parseOBJ')(t); if (!(pos instanceof Float32Array)) pos = new Float32Array(pos); if (unitK !== 1) for (var i = 0; i < pos.length; i++) pos[i] *= unitK; meshPos.push(pos); meshCol.push(null); log.push(f.name + ': треуг. ' + (pos.length / 9).toLocaleString('ru')); });
          if (ext === 'dxf') return readAs(f, 'text').then(function (t) {
            var d = parseDXF(t, unitK);
            if (d.tris.length) { var pos = new Float32Array(d.tris.length * 3); d.tris.forEach(function (p, i) { pos[i * 3] = p[0]; pos[i * 3 + 1] = p[1]; pos[i * 3 + 2] = p[2]; }); meshPos.push(pos); meshCol.push(null); }
            if (d.segs.length) { var a = []; d.segs.forEach(function (p) { a.push.apply(a, tv(p)); }); var g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(a, 3)); extraObjs.push(new T.LineSegments(g, new T.LineBasicMaterial({ color: 0x0b6bd8, toneMapped: false, fog: false }))); }
            if (d.pts.length) { var b2 = []; d.pts.forEach(function (p) { b2.push.apply(b2, tv(p)); }); var g2 = new T.BufferGeometry(); g2.setAttribute('position', new T.Float32BufferAttribute(b2, 3)); extraObjs.push(new T.Points(g2, new T.PointsMaterial({ color: 0x0b6bd8, size: 5, sizeAttenuation: false, toneMapped: false }))); }
            log.push(f.name + ': линий ' + d.segs.length / 2 + ', граней ' + d.tris.length / 3 + ', точек ' + d.pts.length);
          });
          return readAs(f, 'text').then(function (t) {
            var p = parseXYZ(t, unitK); if (!p.length) throw new Error('в файле нет строк «X Y Z»');
            var a = new Float32Array(p.length * 3); p.forEach(function (q2, i) { var w = tv(q2); a[i * 3] = w[0]; a[i * 3 + 1] = w[1]; a[i * 3 + 2] = w[2]; });
            var g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(a, 3));
            extraObjs.push(new T.Points(g, new T.PointsMaterial({ color: 0xff7f00, size: 4, sizeAttenuation: false, toneMapped: false, fog: false })));
            log.push(f.name + ': точек ' + p.length.toLocaleString('ru'));
          });
        }).catch(function (e) { log.push('✖ ' + f.name + ': ' + (e && e.message || e)); console.warn('p61', f.name, e); });
      });
    });
    return chain.then(function () {
      if (!merge) clearExtras();
      extraObjs.forEach(function (o) { addExtra(o); box.expandByObject(o); });
      var nNew = meshPos.reduce(function (a, p) { return a + p.length; }, 0);
      if (nNew) {
        var old = merge ? G('lastModelPositions') : null, oldC = merge ? G('lastModelColors') : null, nOld = old ? old.length : 0;
        var all = new Float32Array(nOld + nNew), cols = (anyCol || (oldC && nOld)) ? new Float32Array(nOld + nNew) : null, o = 0;
        if (nOld) { all.set(old, 0); if (cols) { if (oldC) cols.set(oldC, 0); else cols.fill(0.72, 0, nOld); } o = nOld; }
        if (!merge) window.__p66pick = null;
        meshPos.forEach(function (p, i) {
          if (meshMeta[i]) window.__p66pick = { off: o / 9, n: p.length / 9, triFace: meshMeta[i].triFace, cad: meshMeta[i].cad };
          // новые — в осях детали; переставляем y↔z сами, чтобы склеить с уже переставленной старой моделью
          for (var j = 0; j + 2 < p.length; j += 3) { all[o + j] = p[j]; all[o + j + 1] = p[j + 2]; all[o + j + 2] = p[j + 1]; }
          if (cols) { if (meshCol[i]) cols.set(meshCol[i], o); else cols.fill(0.72, o, o + p.length); }
          o += p.length;
        });
        G('buildStlMesh')(all, cols, true);
        if (window.__p66wantAlpha) { p66setAlpha(window.__p66wantAlpha < 1); window.__p66wantAlpha = 0; }
        try { if (!merge) G('clearProjectsTransform3')(); } catch (e) {}
      } else if (extraObjs.length) fitTo(box);
      var nm = files.map(function (f) { return f.name; }).join(', ');
      status(esc(nm));
      window.__p61bodies = merge ? (window.__p61bodies || []).concat(bodies) : bodies;
      var dt = ((performance.now() - t0) / 1000).toFixed(1);
      toast('Импорт CAD: <b>' + esc(nm) + '</b> — ' + dt + ' с');
      showResult(log, dt);
      try { window.pcdP59 && window.pcdP59.rebuild(); } catch (e) {}
    });
  }

  /* r66i: модель .CAD по умолчанию сплошная (непрозрачная, с буфером глубины); полупрозрачность — по галочке */
  function p66setAlpha(on) {
    try { var sm = G('stlMesh3'); if (!sm || !sm.material) return; var m = sm.material, a = on ? 0.45 : 1;
      m.transparent = !!on; m.opacity = a; m.depthWrite = !on; m.depthTest = true;
      m.polygonOffset = true; m.polygonOffsetFactor = 1; m.polygonOffsetUnits = 1; // каркас поверх граней без «ряби»
      if (m.metalness != null) { m.metalness = 0.1; m.roughness = 0.65; }
      m.needsUpdate = true;
      var op = $('stlOpacity'); if (op) op.value = a; var ov = $('stlOpacityVal'); if (ov) ov.textContent = a.toFixed(2);
      try { G('render3') && G('render3')(); } catch (e2) {}
    } catch (e) {}
  }
  window.pcdCadAlpha = p66setAlpha;
  /* r66f: показ/скрытие тел .CAD — треугольники скрытого тела стягиваются в точку (не рисуются и не кликаются), оригинал хранится */
  function p66applyVis() {
    var P = window.__p66pick, mesh = G('stlMesh3'); if (!P || !P.cad || !mesh || !mesh.geometry) return 0;
    var at = mesh.geometry.attributes.position, A = at.array, o0 = P.off * 9, n = P.n, hid = P.hidden || {}, fb = P.cad.faceBody, tf = P.triFace, cnt = 0;
    if (!P.bak) P.bak = A.slice(o0, o0 + n * 9);
    var B = P.bak, XF = P.xf;
    for (var t = 0; t < n; t++) {
      var q = o0 + t * 9, r = t * 9, h = tf[t], off = h && hid[fb[h]];
      var M = h && XF && XF[fb[h]];
      if (off) { cnt++; for (var k = 0; k < 9; k += 3) { A[q + k] = B[r]; A[q + k + 1] = B[r + 1]; A[q + k + 2] = B[r + 2]; } }
      else if (M) { var e = M.elements; for (var k3 = 0; k3 < 9; k3 += 3) { var x = B[r + k3], y = B[r + k3 + 1], z = B[r + k3 + 2]; A[q + k3] = e[0] * x + e[4] * y + e[8] * z + e[12]; A[q + k3 + 1] = e[1] * x + e[5] * y + e[9] * z + e[13]; A[q + k3 + 2] = e[2] * x + e[6] * y + e[10] * z + e[14]; } }
      else for (var k2 = 0; k2 < 9; k2++) A[q + k2] = B[r + k2];
    }
    var Wm = p66wire; if (Wm && Wm.userData.wb && Wm.geometry) { var wa = Wm.geometry.attributes.position, WA = wa.array, WB = Wm.userData.wb; if (!Wm.userData.bak) Wm.userData.bak = WA.slice(); var WK = Wm.userData.bak;
      for (var sg = 0; sg < WB.length; sg++) { var z = sg * 6, WM = WB[sg] && XF && XF[WB[sg]];
        if (WM) { var we = WM.elements; for (var wk = 0; wk < 6; wk += 3) { var wx = WK[z + wk], wy = WK[z + wk + 1], wz = WK[z + wk + 2]; WA[z + wk] = we[0] * wx + we[4] * wy + we[8] * wz + we[12]; WA[z + wk + 1] = we[1] * wx + we[5] * wy + we[9] * wz + we[13]; WA[z + wk + 2] = we[2] * wx + we[6] * wy + we[10] * wz + we[14]; } }
        else { WA[z] = WK[z]; WA[z + 1] = WK[z + 1]; WA[z + 2] = WK[z + 2]; }
        if (WB[sg] && hid[WB[sg]]) { WA[z + 3] = WA[z]; WA[z + 4] = WA[z + 1]; WA[z + 5] = WA[z + 2]; } else if (!WM) { WA[z + 3] = WK[z + 3]; WA[z + 4] = WK[z + 4]; WA[z + 5] = WK[z + 5]; } }
      wa.needsUpdate = true; }
    at.needsUpdate = true; try { mesh.geometry.computeBoundingSphere(); mesh.geometry.computeBoundingBox(); } catch (e) {}
    try { G('render3') && G('render3')(); } catch (e) {}
    return cnt;
  }
  function p66setBody(bh, on) { var P = window.__p66pick; if (!P) return; P.hidden = P.hidden || {}; if (on) delete P.hidden[bh]; else P.hidden[bh] = 1; p66applyVis(); }
  function p66setAll(mode) { // 'all' | 'main'
    var P = window.__p66pick, B = (window.__p61bodies || []).filter(function (b) { return b.bh; }); if (!P || !B.length) return;
    P.hidden = {}; if (mode === 'main') { var big = B.reduce(function (a, b) { return b.tris > a.tris ? b : a; }); B.forEach(function (b) { if (b.bh !== big.bh) P.hidden[b.bh] = 1; }); }
    p66applyVis(); var r = document.querySelectorAll('input.p66bv'); for (var i = 0; i < r.length; i++) r[i].checked = !P.hidden[r[i].getAttribute('data-bh')];
  }
  /* r66l: «Уложить деталь на оснастку» по образцу PC-DMIS Quick Fixture (GraphicsUI.dll: CQuickFixtureAdjustDlg —
     OnDrop / OnLevel / OnSquare / OnX OnY OnZ / OnRotate*, CGDispView::QuickFixtureDropAndAlign). Тела «детали» двигаются
     как одно целое (матрица P.xf[тело] в осях three), остальные тела — неподвижная оснастка. */
  var QF = { mov: null, op: null, pick: [], hist: [], base: null, pin: null, down: null };
  function qfT() { return window.THREE; }
  function qfSw(a) { return [a[0], a[2], a[1]]; } // оси детали ↔ three (y↔z)
  function qfMain() { var B = (window.__p61bodies || []).filter(function (b) { return b.bh; }); if (!B.length) return null; return B.reduce(function (a, b) { return b.tris > a.tris ? b : a; }).bh; }
  function qfMov() { if (!QF.mov) { QF.mov = {}; var m = qfMain(); if (m) QF.mov[m] = 1; } return QF.mov; }
  function qfCur() { var T3 = qfT(), P = window.__p66pick; if (!P) return new T3.Matrix4(); P.xf = P.xf || {}; var ks = Object.keys(qfMov()); var M = ks.length && P.xf[ks[0]]; return M ? M.clone() : new T3.Matrix4(); }
  function qfSet(M, noHist) { var P = window.__p66pick; if (!P) return; P.xf = P.xf || {}; if (!noHist) QF.hist.push(qfCur()); Object.keys(qfMov()).forEach(function (bh) { P.xf[bh] = M.clone(); }); p66applyVis(); qfUpd(); }
  function qfPre(D) { qfSet(D.clone().multiply(qfCur())); } // D — дополнительное движение в осях оснастки
  function qfAbout(R, p) { var T3 = qfT(); return new T3.Matrix4().makeTranslation(p.x, p.y, p.z).multiply(R).multiply(new T3.Matrix4().makeTranslation(-p.x, -p.y, -p.z)); }
  function qfRotTo(a, b) { var T3 = qfT(); return new T3.Matrix4().makeRotationFromQuaternion(new T3.Quaternion().setFromUnitVectors(a.clone().normalize(), b.clone().normalize())); }
  // точная геометрия кликнутой грани в текущем положении (three-локальные оси модели)
  function qfFeat(ti, rayDir) {
    var T3 = qfT(), P = window.__p66pick, h = P.triFace[ti]; if (!h) return { err: 'треугольник без грани' };
    var o = P.cad, s = o.surfaces[o.faceSurf[h]], bh = o.faceBody[h]; if (!s) return { err: 'у грани нет точной поверхности (NURBS) — выберите плоскость или цилиндр', bh: bh };
    var M = (P.xf && P.xf[bh]) || new T3.Matrix4(), R3 = new T3.Matrix3().setFromMatrix4(M);
    function pt(a) { return new T3.Vector3().fromArray(qfSw(a)).applyMatrix4(M); }
    function dir(a) { return new T3.Vector3().fromArray(qfSw(a)).applyMatrix3(R3).normalize(); }
    if (s.k === 'PLANE') { var n = dir(s.N); if (rayDir && n.dot(rayDir) > 0) n.negate(); return { k: 'PLANE', h: h, bh: bh, O: pt(s.O), N: n }; } // нормаль — к смотрящему (наружу из материала)
    if (s.k === 'CYLINDER') return { k: 'CYL', h: h, bh: bh, O: pt(s.O), A: dir(s.A), R: s.R };
    return { err: 'грань ' + s.k + ' — нужна плоскость или цилиндр', bh: bh };
  }
  // Положить (Drop/Level): плоскость детали на плоскость оснастки, нормали навстречу
  function qfDrop(pp, fp) {
    var T3 = qfT(), R = qfAbout(qfRotTo(pp.N, fp.N.clone().negate()), pp.O), d = fp.N.dot(fp.O.clone().sub(pp.O));
    qfPre(new T3.Matrix4().makeTranslation(fp.N.x * d, fp.N.y * d, fp.N.z * d).multiply(R)); QF.base = fp.N.clone(); QF.pin = null;
    return 'Деталь положена на опорную плоскость';
  }
  // Упор (Square): боковая грань детали к упору оснастки — поворот вокруг нормали опоры и сдвиг вдоль опоры
  function qfSquare(pp, fp) {
    var T3 = qfT(), up = QF.base || new T3.Vector3(0, 1, 0), a = pp.N.clone().projectOnPlane(up), b = fp.N.clone().negate().projectOnPlane(up);
    if (a.length() < 1e-6 || b.length() < 1e-6) return 'Упорная грань параллельна опорной — выберите боковую';
    a.normalize(); b.normalize(); var ang = Math.atan2(a.clone().cross(b).dot(up), a.dot(b));
    var R = qfAbout(new T3.Matrix4().makeRotationAxis(up.clone().normalize(), ang), pp.O), dir = fp.N.clone().projectOnPlane(up).normalize(), k = fp.N.dot(dir);
    var d = fp.N.dot(fp.O.clone().sub(pp.O)) / (Math.abs(k) > 1e-6 ? k : 1);
    qfPre(new T3.Matrix4().makeTranslation(dir.x * d, dir.y * d, dir.z * d).multiply(R));
    return 'Деталь подведена к упору (поворот ' + (ang * 180 / Math.PI).toFixed(3) + '°)';
  }
  // Штифт 1: отверстие детали на штифт оснастки — соосно, без сдвига вдоль оси (контакт с опорой сохраняется)
  function qfPin(pc, fc) {
    var T3 = qfT(), a = pc.A.clone(), b = fc.A.clone(); if (a.dot(b) < 0) b.negate();
    var R = qfAbout(qfRotTo(a, b), pc.O), dl = fc.O.clone().sub(pc.O); dl.sub(b.clone().multiplyScalar(dl.dot(b)));
    qfPre(new T3.Matrix4().makeTranslation(dl.x, dl.y, dl.z).multiply(R)); QF.pin = { O: fc.O.clone(), A: b.clone() };
    var msg = 'Отверстие Ø' + (2 * pc.R).toFixed(3) + ' надето на Ø' + (2 * fc.R).toFixed(3);
    if (QF.base && Math.abs(b.dot(QF.base)) < 0.999) msg += ' — внимание: ось не перпендикулярна опоре, контакт с опорой мог нарушиться';
    return msg;
  }
  // Штифт 2: поворот вокруг первого штифта, чтобы второе отверстие (паз) встало на второй штифт
  function qfPin2(pc, fc) {
    if (!QF.pin) return 'Сначала выполните «Штифт 1»';
    var T3 = qfT(), ax = QF.pin.A, c = QF.pin.O, a = pc.O.clone().sub(c).projectOnPlane(ax), b = fc.O.clone().sub(c).projectOnPlane(ax);
    if (a.length() < 1e-6 || b.length() < 1e-6) return 'Второй штифт на оси первого — невозможно сориентировать';
    var la = a.length(), lb = b.length(); a.normalize(); b.normalize(); var ang = Math.atan2(a.clone().cross(b).dot(ax), a.dot(b));
    qfPre(qfAbout(new T3.Matrix4().makeRotationAxis(ax.clone().normalize(), ang), c));
    return 'Поворот вокруг штифта 1 на ' + (ang * 180 / Math.PI).toFixed(3) + '°; расстояния до центров: деталь ' + la.toFixed(3) + ', оснастка ' + lb.toFixed(3) + ' мм';
  }
  var QF_OPS = {
    drop: { t: 'Положить: плоскость на плоскость', k: 'PLANE', f: qfDrop },
    square: { t: 'Упор: боковая грань к упору', k: 'PLANE', f: qfSquare },
    pin: { t: 'Штифт 1: отверстие на штифт', k: 'CYL', f: qfPin },
    pin2: { t: 'Штифт 2: довернуть по второму', k: 'CYL', f: qfPin2 }
  };
  function qfMsg(m, bad) { var e = $('p66qfMsg'); if (e) { e.textContent = m; e.style.color = bad ? '#b00' : '#060'; } }
  function qfStart(op) { QF.op = op; QF.pick = []; qfMsg(op === 'body' ? 'Кликните по телу — включить/исключить его из детали (Esc — готово)' : QF_OPS[op].t + ': кликните грань ДЕТАЛИ и грань ОСНАСТКИ (в любом порядке)'); qfUpd(); }
  function qfStop() { QF.op = null; QF.pick = []; qfUpd(); }
  function qfOnPick(ti, rayDir) {
    var P = window.__p66pick, mov = qfMov();
    if (QF.op === 'body') { var h0 = P.triFace[ti], bh0 = h0 && P.cad.faceBody[h0]; if (!bh0) return; if (mov[bh0]) { delete mov[bh0]; if (P.xf) delete P.xf[bh0]; } else { mov[bh0] = 1; P.xf = P.xf || {}; var ks = Object.keys(mov).filter(function (k) { return +k !== bh0 && P.xf[k]; }); if (ks.length) P.xf[bh0] = P.xf[ks[0]].clone(); } p66applyVis(); qfUpd(); qfMsg('Деталь: ' + Object.keys(mov).map(function (k) { return '#' + k; }).join(', ')); return; }
    var op = QF_OPS[QF.op], F = qfFeat(ti, rayDir); if (F.err) { qfMsg(F.err, true); return; }
    if (F.k !== op.k) { qfMsg('Нужен ' + (op.k === 'PLANE' ? 'плоская грань' : 'цилиндр (отверстие или штифт)') + ', а выбрано: ' + (F.k === 'CYL' ? 'цилиндр' : 'плоскость'), true); return; }
    F.part = !!mov[F.bh]; QF.pick = QF.pick.filter(function (x) { return x.part !== F.part; }); QF.pick.push(F);
    if (QF.pick.length < 2) { qfMsg((F.part ? 'Грань детали' : 'Грань оснастки') + ' выбрана (грань #' + F.h + '). Теперь — ' + (F.part ? 'ОСНАСТКИ' : 'ДЕТАЛИ')); return; }
    var pp = QF.pick.filter(function (x) { return x.part; })[0], fp = QF.pick.filter(function (x) { return !x.part; })[0];
    var m = op.f(pp, fp); QF.pick = []; qfMsg(m, /Сначала|невозможно|параллельна/.test(m)); QF.op = null; qfUpd();
  }
  function qfUpd() {
    var d = $('p66qfInfo'); if (!d) return; var T3 = qfT(), M = qfCur(), e = M.elements, sw = qfSw;
    var t = sw([e[12], e[13], e[14]]), X = sw([e[0], e[1], e[2]]), Y = sw([e[8], e[9], e[10]]), Z = sw([e[4], e[5], e[6]]);
    function f(v) { return v.map(function (x) { return (Math.abs(x) < 5e-7 ? 0 : x).toFixed(4); }).join(', '); }
    d.textContent = 'Деталь (тела ' + Object.keys(qfMov()).map(function (k) { return '#' + k; }).join(', ') + ') в координатах оснастки:\nсмещение X,Y,Z = ' + f(t) + '\nось X детали = ' + f(X) + '\nось Y детали = ' + f(Y) + '\nось Z детали = ' + f(Z);
    var bs = document.querySelectorAll('#p66qf button[data-op]'); for (var i = 0; i < bs.length; i++) bs[i].style.outline = bs[i].getAttribute('data-op') === QF.op ? '2px solid #2a7' : '';
    var u = $('p66qfUndo'); if (u) u.disabled = !QF.hist.length;
  }
  function qfMove(ax, sgn) { var T3 = qfT(), st = parseFloat(($('p66qfStep') || {}).value) || 1, v = [0, 0, 0]; v[ax] = sgn * st; var w = qfSw(v); qfPre(new T3.Matrix4().makeTranslation(w[0], w[1], w[2])); }
  function qfRot(ax, sgn) { // поворот вокруг оси оснастки X/Y/Z через центр детали
    var T3 = qfT(), an = (parseFloat(($('p66qfAng') || {}).value) || 90) * Math.PI / 180 * sgn, v = [0, 0, 0]; v[ax] = 1; var w = qfSw(v), axis = new T3.Vector3(w[0], w[1], w[2]);
    an = -an; // y↔z — отражение: направление поворота в осях детали меняется
    var c = qfCenter(); qfPre(qfAbout(new T3.Matrix4().makeRotationAxis(axis, an), c));
  }
  function qfCenter() { var T3 = qfT(), P = window.__p66pick, mesh = G('stlMesh3'), mov = qfMov(), A = mesh.geometry.attributes.position.array, o0 = P.off * 9, s = [0, 0, 0], n = 0;
    for (var t = 0; t < P.n; t += 7) { var h = P.triFace[t]; if (h && mov[P.cad.faceBody[h]]) { var q = o0 + t * 9; s[0] += A[q]; s[1] += A[q + 1]; s[2] += A[q + 2]; n++; } }
    return n ? new T3.Vector3(s[0] / n, s[1] / n, s[2] / n) : new T3.Vector3(); }
  function qfDialog() {
    var P = window.__p66pick; if (!P || !P.cad) { toast('Сначала импортируйте .CAD'); return; }
    var d = $('p66qf'); if (d) d.remove(); d = document.createElement('div'); d.id = 'p66qf';
    d.style.cssText = 'position:fixed;left:16px;top:70px;z-index:99999;background:#fff;border:1px solid #8aa;box-shadow:0 4px 16px rgba(0,0,0,.25);padding:8px 10px;font:12px Segoe UI,Arial;width:430px';
    var B = function (id, t, op) { return '<button type="button" ' + (id ? 'id="' + id + '" ' : '') + (op ? 'data-op="' + op + '" ' : '') + 'style="margin:2px">' + t + '</button>'; };
    d.innerHTML = '<div style="font-weight:600;margin-bottom:4px">Оснастка — уложить деталь (как Quick Fixture в PC-DMIS)</div>' +
      '<div style="color:#456">Двигается только деталь, остальные тела — неподвижная оснастка. После выбора шага кликайте грани обычным кликом.</div>' +
      '<div style="margin-top:4px">' + B('', 'Выбрать тела детали…', 'body') + '</div>' +
      '<div style="margin-top:4px;font-weight:600">Укладка по граням</div><div>' + B('', '1. Положить (плоскость → опора)', 'drop') + B('', '2. Штифт 1 (отверстие → штифт)', 'pin') + B('', '3. Штифт 2 (довернуть)', 'pin2') + B('', 'Упор (боковая грань → упор)', 'square') + '</div>' +
      '<div id="p66qfMsg" style="margin:4px 0;min-height:16px;color:#060"></div>' +
      '<div style="font-weight:600">Ручная подводка (оси оснастки)</div>' +
      '<div>шаг, мм <input id="p66qfStep" value="1" style="width:60px"> ' + ['X', 'Y', 'Z'].map(function (a, i) { return B('', a + '−') .replace('<button', '<button data-mv="' + i + ',-1"') + B('', a + '+').replace('<button', '<button data-mv="' + i + ',1"'); }).join('') + '</div>' +
      '<div>угол, ° <input id="p66qfAng" value="90" style="width:60px"> ' + ['X', 'Y', 'Z'].map(function (a, i) { return B('', '⟲' + a).replace('<button', '<button data-rt="' + i + ',1"') + B('', '⟳' + a).replace('<button', '<button data-rt="' + i + ',-1"'); }).join('') + '</div>' +
      '<pre id="p66qfInfo" style="margin:6px 0;padding:6px;background:#f4f7fa;border:1px solid #d5dde5;font:11px Consolas,monospace;white-space:pre"></pre>' +
      B('p66qfUndo', 'Отменить шаг') + B('p66qfReset', 'Сброс (как в файле)') + B('p66qfClose', 'Закрыть');
    document.body.appendChild(d);
    var bs = d.querySelectorAll('button[data-op]'); for (var i = 0; i < bs.length; i++) bs[i].onclick = function () { var op = this.getAttribute('data-op'); if (QF.op === op) { qfStop(); qfMsg(''); } else qfStart(op); };
    var mv = d.querySelectorAll('button[data-mv]'); for (i = 0; i < mv.length; i++) mv[i].onclick = function () { var a = this.getAttribute('data-mv').split(','); qfMove(+a[0], +a[1]); };
    var rt = d.querySelectorAll('button[data-rt]'); for (i = 0; i < rt.length; i++) rt[i].onclick = function () { var a = this.getAttribute('data-rt').split(','); qfRot(+a[0], +a[1]); };
    $('p66qfUndo').onclick = function () { if (QF.hist.length) qfSet(QF.hist.pop(), true); };
    $('p66qfReset').onclick = function () { QF.hist.push(qfCur()); var Pp = window.__p66pick; if (Pp && Pp.xf) Object.keys(qfMov()).forEach(function (k) { delete Pp.xf[k]; }); QF.base = QF.pin = null; p66applyVis(); qfUpd(); qfMsg('Деталь возвращена в положение из файла'); };
    $('p66qfClose').onclick = function () { qfStop(); d.remove(); };
    qfUpd();
  }
  window.pcdCadQuickFixture = { open: qfDialog, state: QF, drop: qfDrop, square: qfSquare, pin: qfPin, pin2: qfPin2, feat: qfFeat, set: qfSet, cur: qfCur };
  (function qfHook() { var rd = G('renderer3'); if (!rd || !rd.domElement) { setTimeout(qfHook, 1000); return; } var el = rd.domElement; if (el.__qf) return; el.__qf = 1;
    el.addEventListener('pointerdown', function (e) { QF.down = [e.clientX, e.clientY]; }, true);
    el.addEventListener('click', function (e) {
      if (!QF.op || e.altKey) return; if (QF.down && Math.abs(e.clientX - QF.down[0]) + Math.abs(e.clientY - QF.down[1]) > 5) return; // это был поворот камеры
      var T3 = qfT(), P = window.__p66pick, mesh = G('stlMesh3'), cam = G('camera3'); if (!P || !mesh || !cam) return;
      var r = el.getBoundingClientRect(), rc = new T3.Raycaster(); rc.setFromCamera(new T3.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1), cam);
      var hs = rc.intersectObject(mesh, false); if (!hs.length) return; var ti = hs[0].faceIndex - P.off; if (ti < 0 || ti >= P.n) return;
      e.preventDefault(); e.stopPropagation();
      var dirL = rc.ray.direction.clone().transformDirection(new T3.Matrix4().copy(mesh.matrixWorld).invert());
      qfOnPick(ti, dirL);
    }, true);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && QF.op) { qfStop(); qfMsg(''); }
      if (e.ctrlKey && e.shiftKey && (e.key === 'F' || e.key === 'f' || e.code === 'KeyF')) { e.preventDefault(); qfDialog(); } });
    var fb = document.createElement('button'); fb.id = 'p66qfFab'; fb.type = 'button'; fb.textContent = '🧲 Оснастка / уложить деталь';
    fb.title = 'Как Quick Fixture в PC-DMIS: положить деталь на опору, надеть на штифты, подвести к упору (Ctrl+Shift+F)';
    fb.style.cssText = 'position:fixed;z-index:99998;display:none;padding:6px 10px;font:600 13px Segoe UI,Arial;background:#2a7;color:#fff;border:0;border-radius:4px;box-shadow:0 2px 8px rgba(0,0,0,.3);cursor:pointer';
    fb.onclick = qfDialog; document.body.appendChild(fb);
    setInterval(function () { var P = window.__p66pick, r = el.getBoundingClientRect(), vis = !!(P && P.cad) && r.width > 50 && r.height > 50;
      fb.style.display = vis ? 'block' : 'none'; if (vis) { fb.style.left = Math.round(r.left + 10) + 'px'; fb.style.top = Math.round(r.top + 10) + 'px'; } }, 700);
  })();
  window.pcdCadBodies = { set: p66setBody, all: function () { p66setAll('all'); }, onlyMain: function () { p66setAll('main'); } };

  /* ---------- окно «Импорт CAD» ---------- */
  var lastWin = null;
  function showResult(log, dt) {
    var r = $('p61Res'); if (!r) return;
    var bodies = window.__p61bodies || [];
    r.innerHTML = '<div style="margin:4px 0 2px;font-weight:600">Результат (' + dt + ' с)</div>' + log.map(function (l) { return '<div>' + esc(l) + '</div>'; }).join('') +
      (bodies.length ? '<div style="margin-top:4px;font-weight:600">Тела модели: ' + bodies.length + '</div><div style="max-height:130px;overflow:auto;border:1px solid #c9d3dc;background:#fff;padding:2px 4px;font:11px Consolas,monospace">' +
        bodies.slice(0, 400).map(function (b) { var hidP = window.__p66pick && window.__p66pick.hidden; return '<div>' + (b.bh ? '<label style="cursor:pointer"><input type="checkbox" class="p66bv" data-bh="' + b.bh + '"' + (hidP && hidP[b.bh] ? '' : ' checked') + ' style="vertical-align:-2px;margin:0 4px 0 0">' : '') + esc(b.name) + ' <span style="color:#888">· ' + b.tris.toLocaleString('ru') + ' тр.</span>' + (b.bh ? '</label>' : '') + '</div>'; }).join('') + '</div>' +
        (bodies.some(function (b) { return b.bh; }) ? '<div style="margin-top:4px;display:flex;gap:6px"><button type="button" id="p66bAll">Показать все</button><button type="button" id="p66bMain">Только самое большое тело (деталь)</button></div><div style="margin-top:4px"><button type="button" id="p66bFeat" style="font-weight:600">Все элементы из CAD → программа…</button> <button type="button" id="p66bQF" style="font-weight:600">Оснастка: уложить деталь…</button></div>' : '') : '');
    var cbs = r.querySelectorAll('input.p66bv'); for (var ci = 0; ci < cbs.length; ci++) cbs[ci].onchange = function () { p66setBody(+this.getAttribute('data-bh'), this.checked); };
    var ba = $('p66bAll'), bm = $('p66bMain'); if (ba) ba.onclick = function () { p66setAll('all'); }; if (bm) bm.onclick = function () { p66setAll('main'); }; var bf = $('p66bFeat'); if (bf) bf.onclick = p66bulkDialog; var bq = $('p66bQF'); if (bq) bq.onclick = qfDialog;
  }
  function openDialog() {
    var A = window.__p57api; if (!A) { pickFiles(); return; }
    var w = A.win('p61cad', 'Импорт CAD', 'cube', 460); lastWin = w;
    w.body.innerHTML = '';
    var html = '<div style="font:12px Segoe UI,Tahoma,sans-serif">' +
      '<div style="margin-bottom:4px">Тип файла:</div>' +
      '<div id="p61List" style="border:1px solid #9aa7b3;background:#fff;height:190px;overflow:auto">' +
      FMT.map(function (f, i) {
        return '<div class="p61f" data-i="' + i + '" style="display:flex;gap:6px;padding:2px 6px;cursor:' + (f.ok ? 'pointer' : 'default') + ';color:' + (f.ok ? '#111' : '#8a8a8a') + '">' +
          '<span style="width:14px;color:' + (f.ok ? '#16a34a' : '#c0392b') + '">' + (f.ok ? '✔' : '✖') + '</span><span style="flex:1">' + esc(f.n) + ' <span style="color:#666">(' + f.ext.map(function (e) { return '*.' + e; }).join(';') + ')</span></span>' +
          '<span style="color:#888;font-size:11px">' + esc(f.ok || f.no) + '</span></div>';
      }).join('') + '</div>' +
      '<div style="display:grid;grid-template-columns:auto 1fr;gap:6px 10px;margin-top:8px;align-items:center">' +
      '<span>Огранка B-rep:</span><select id="p61Q"><option value="coarse">Грубо (быстро)</option><option value="normal">Обычно</option><option value="fine">Точно (медленнее)</option></select>' +
      '<span>Единицы STL/OBJ/DXF/XYZ:</span><select id="p61U"><option value="mm">Миллиметры</option><option value="in">Дюймы (×25.4)</option></select>' +
      '</div>' +
      '<label style="display:flex;gap:6px;align-items:center;margin-top:8px"><input type="checkbox" id="p66W"> Каркас (рёбра модели PC-DMIS .CAD)</label>' +
      '<label style="display:flex;gap:6px;align-items:center;margin-top:4px"><input type="checkbox" id="p66A"> Полупрозрачная модель (видно каркас сквозь деталь)</label>' +
      '<label style="display:flex;gap:6px;align-items:center;margin-top:4px"><input type="checkbox" id="p61M"> Объединить с текущей моделью (Import2, MERGE)</label>' +
      '<div style="color:#555;margin-top:6px;font-size:11px">Можно выбрать сразу несколько файлов — они будут объединены в одну модель. Файлы можно также перетащить в 3D-окно.</div>' +
      '<div id="p61Status" style="margin-top:6px;color:#0b5cad"></div><div id="p61Res" style="font-size:11px"></div></div>';
    w.body.innerHTML = html;
    $('p61Q').value = LS('q', 'normal'); $('p61U').value = LS('unit', 'mm'); $('p61M').checked = LS('merge', '0') === '1'; $('p66W').checked = LS('wire', '1') === '1'; $('p66W').onchange = function () { p66setWire(this.checked); }; $('p66A').checked = LS('alpha', '0') === '1'; $('p66A').onchange = function () { try { localStorage.setItem('p61.alpha', this.checked ? '1' : '0'); } catch (e) {} p66setAlpha(this.checked); };
    $('p61Q').onchange = function () { LSset('q', this.value); }; $('p61U').onchange = function () { LSset('unit', this.value); }; $('p61M').onchange = function () { LSset('merge', this.checked ? '1' : '0'); };
    var selI = -1;
    [].forEach.call(w.body.querySelectorAll('.p61f'), function (row) {
      row.addEventListener('click', function () {
        [].forEach.call(w.body.querySelectorAll('.p61f'), function (x) { x.style.background = ''; });
        row.style.background = '#cce4f7'; selI = +row.dataset.i;
      });
      row.addEventListener('dblclick', function () { if (FMT[+row.dataset.i].ok) pickFiles(FMT[+row.dataset.i]); });
    });
    w.foot.innerHTML = '';
    w.foot.appendChild(A.btn('Импорт…', function () { var f = FMT[selI]; if (f && !f.ok) { alert(f.n + ': ' + f.no); return; } pickFiles(f && f.ok ? f : null); }, 'def'));
    w.foot.appendChild(A.btn('Закрыть', function () { w.close(); }));
    if (window.__p61bodies && window.__p61bodies.length) showResult([], '—');
  }
  function pickFiles(fmt) {
    var inp = document.createElement('input'); inp.type = 'file'; inp.multiple = true;
    inp.accept = fmt ? fmt.ext.map(function (e) { return '.' + e; }).join(',') : ACCEPT;
    inp.onchange = function () { if (inp.files && inp.files.length) importFiles(inp.files); };
    inp.click();
  }
  window.pcdCadImportOpen = openDialog;
  window.pcdCadImport = importFiles;

  /* ---------- встраивание в приложение ---------- */
  function wrapLoader() {
    var f = G('loadModelFile'); if (typeof f !== 'function') return false; if (f.__p61) return true;
    var w = function (file) {
      var ext = String(file && file.name || '').split('.').pop().toLowerCase();
      if (OURS.indexOf(ext) >= 0) {
        try { G('resetModelViewState3')(); } catch (e) {}
        return importFiles([file], { merge: false }).catch(function (e) { console.warn('p61 → штатный загрузчик', e); return f(file); });
      }
      return f.apply(this, arguments);
    };
    w.__p61 = 1;
    try { window.loadModelFile = w; } catch (e) {}
    try { loadModelFile = w; } catch (e) {} // eslint-disable-line no-func-assign
    var inp = $('stlFileInput'); if (inp) inp.accept = ACCEPT + ',.STL,.OBJ,.STP,.STEP,.IGS,.IGES';
    return true;
  }
  function addMenu() {
    var items = document.querySelectorAll('.mi .sub .si'), ins = null;
    [].forEach.call(items, function (s) { if (/pcdAct\('model'\)/.test(s.getAttribute('onclick') || '')) ins = s; });
    if (!ins) return false; if (ins.parentNode.querySelector('.p61mi')) return true;
    var s = document.createElement('span'); s.className = 'si p61mi'; s.textContent = 'Импорт CAD (STEP / IGES / BREP / DXF / XYZ)…';
    s.addEventListener('click', function (ev) { ev.stopPropagation(); try { document.querySelectorAll('.mi.open').forEach(function (x) { x.classList.remove('open'); }); } catch (_) {} openDialog(); });
    ins.parentNode.insertBefore(s, ins.nextSibling);
    return true;
  }
  function addButtons() {
    var ok = false, up = $('stlUploadBtn');
    if (up && !$('p61Btn')) {
      var b = document.createElement('button'); b.id = 'p61Btn'; b.className = up.className; b.textContent = '📥 Импорт CAD'; b.title = 'Импорт CAD как в PC-DMIS: STEP, IGES, BREP (OpenCascade), STL, OBJ, DXF, XYZ';
      b.addEventListener('click', openDialog); up.parentNode.insertBefore(b, up.nextSibling);
    }
    if (up) ok = true;
    var tb = document.querySelector('#p60Tb .grp:nth-child(2)');
    if (tb && !tb.querySelector('[data-k="cad"]')) {
      var c = document.createElement('button'); c.dataset.k = 'cad'; c.title = 'Импорт CAD…';
      c.innerHTML = '<svg viewBox="0 0 20 20"><path d="M3 7l7-4 7 4v8l-7 4-7-4z" fill="#e8eef6" stroke="#1d4f91"/><path d="M10 6v8M6.5 10.5L10 14l3.5-3.5" stroke="#16a34a" stroke-width="2" fill="none"/></svg>';
      c.addEventListener('click', function (e) { e.stopPropagation(); openDialog(); }); c.addEventListener('mousedown', function (e) { e.stopPropagation(); });
      tb.insertBefore(c, tb.firstChild);
    }
    return ok && !!tb;
  }
  function addDrop() {
    var cont = $('threeContainer'); if (!cont || cont.__p61) return !!cont; cont.__p61 = 1;
    cont.addEventListener('dragover', function (e) { if (e.dataTransfer && [].some.call(e.dataTransfer.items || [], function (it) { return it.kind === 'file'; })) { e.preventDefault(); } });
    cont.addEventListener('drop', function (e) {
      var fs = e.dataTransfer && e.dataTransfer.files; if (!fs || !fs.length) return;
      var mine = [].filter.call(fs, function (f) { var ff = fmtOf(f.name); return ff && ff.ok; });
      if (!mine.length) return;
      e.preventDefault(); e.stopPropagation();
      importFiles(mine, { merge: e.shiftKey || undefined });
    }, true);
    return true;
  }
  var n = 0;
  (function wait() {
    var a = false, b = false, c = false, d = false;
    try { a = wrapLoader(); } catch (e) {} try { b = addMenu(); } catch (e) {} try { c = addButtons(); } catch (e) {} try { d = addDrop(); } catch (e) {}
    if (!(a && b && c && d) && ++n < 200) setTimeout(wait, 500);
  })();
  function ver() { try { var vv = document.querySelector('[title*="Версия приложения"]'); if (vv) { vv.textContent = 'r62'; vv.title = 'Версия приложения (должно быть r61 после перезагрузки)'; } } catch (e) {} }
  ver(); setTimeout(ver, 4000);
})();
