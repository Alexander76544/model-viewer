/* prg-commands.js — r67: полноценный обход команд PARTPROG (PC-DMIS .prg).
 *
 * Кадр команды (подтверждено по PCDLRN.exe + реальным файлам):
 *   u16 OBTYPE (знаковый: отрицательный = команда нового образца, тип = -значение)
 *   u32 длина тела
 *   тело: начинается со строки CString (FF FE FF + len + UTF-16) — имя команды
 * Начало потока: u32 версия формата, u32 2, затем первая команда — Заголовок файла (0x3039).
 *
 * Автоэлементы КОНТАКТ (612..619): имя элемента = 2-я строка тела; от её позиции n:
 *   X = n-92, Y = n-56, Z = n-20 (double), I/J/K = +8 к каждому;
 *   Ø — double, за которым через 16/24 байта идут начальный/конечный угол.
 */
(function (root) {
  'use strict';
  var OBT = (root && root.PcdObtype) || (typeof require === 'function' ? (function () { try { return require('./pcdmis-obtype.js'); } catch (e) { return null; } })() : null);
  function obt(code) {
    if (code === 12345) return { id: 'FILE_HEADER', ru: 'Заголовок файла', cat: 'setting' };
    if (!OBT) return null;
    var t = OBT.get ? OBT.get(code) : null;
    return t && t.id && t.id !== '?' && !/^UNKNOWN/.test(t.id) ? t : (OBT.has && OBT.has(code) ? t : t);
  }
  function known(code) {
    if (code === 12345) return true;
    if (!OBT) return code > 0 && code < 3000;
    if (OBT.has) return OBT.has(code);
    var t = OBT.get(code); return !!(t && t.id && !/^(UNKNOWN|\?)/.test(t.id) && !/^\d+$/.test(t.id));
  }
  var UTF16 = new TextDecoder('utf-16le');
  function u16(b, p) { return b[p] | (b[p + 1] << 8); }
  function u32(b, p) { return (b[p] | (b[p + 1] << 8) | (b[p + 2] << 16)) + b[p + 3] * 16777216; }
  function dbl(b, p) {
    if (p < 0 || p + 8 > b.length) return null;
    var v = new DataView(b.buffer, b.byteOffset + p, 8).getFloat64(0, true);
    return isFinite(v) ? v : null;
  }
  function str(b, p, end) {
    if (p + 4 > end || b[p] !== 0xff || b[p + 1] !== 0xfe || b[p + 2] !== 0xff) return null;
    var n = b[p + 3], q = p + 4;
    if (n === 0xff) { n = u16(b, q); q += 2; }
    if (q + n * 2 > end) return null;
    return { text: UTF16.decode(b.subarray(q, q + n * 2)), next: q + n * 2 };
  }
  function strings(b, q, end, max) {
    var out = [], k = q, lim = Math.min(end, q + 4000);
    while (k < lim && out.length < (max || 6)) {
      if (b[k] === 0xff && b[k + 1] === 0xfe && b[k + 2] === 0xff) {
        var s = str(b, k, end);
        if (s) { if (s.text) out.push({ off: k - q, text: s.text }); k = s.next; continue; }
      }
      k++;
    }
    return out;
  }
  function r3n(v) { return Math.round(v * 1e6) / 1e6; }
  function r3(v) { return Math.round(v * 1000) / 1000; }

  /* candidates = positions of command-name strings preceded by a valid OBTYPE + length */
  function walk(b) {
    var cands = [];
    for (var p = 6; p + 4 <= b.length; p++) {
      if (b[p] !== 0xff || b[p + 1] !== 0xfe || b[p + 2] !== 0xff) continue;
      var t = u16(b, p - 6), L = u32(b, p - 4);
      var code = t >= 0x8000 ? -(0x10000 - t) : t;
      if (!known(Math.abs(code)) || L < 4 || p + L > b.length) continue;
      cands.push({ q: p, code: code, len: L });
    }
    // chain: each next command starts after the previous body ends
    var cmds = [], i = 0, end = 0;
    for (var c = 0; c < cands.length; c++) {
      var x = cands[c];
      if (x.q - 6 < end) continue;
      cmds.push(x); end = x.q + x.len;
    }
    return cmds;
  }

  function contactFeature(b, cmd, names) {
    var nm = names[1]; if (!nm) return null;
    var n = cmd.q + nm.off;
    var X = dbl(b, n - 92), Y = dbl(b, n - 56), Z = dbl(b, n - 20);
    var I = dbl(b, n - 84), J = dbl(b, n - 48), K = dbl(b, n - 12);
    var ok = function (v) { return v !== null && Math.abs(v) < 1e5; };
    if (!ok(X) || !ok(Y) || !ok(Z)) return null;
    var vec = null;
    if (ok(I) && ok(J) && ok(K) && Math.abs(Math.hypot(I, J, K) - 1) < 1e-3) vec = [I, J, K];
    var dia = null, sa = null, ea = null;
    for (var o = n + 300; o < Math.min(n + 900, cmd.q + cmd.len - 32); o++) {
      var d = dbl(b, o), s = dbl(b, o + 16), e = dbl(b, o + 24);
      if (d === null || s === null || e === null) continue;
      if (d > 0.05 && d < 5000 && Math.abs(s) <= 720 && e - s > 0.5 && e - s <= 360.0001 && Math.abs(d * 1e4 - Math.round(d * 1e4)) < 1e-3 &&
          (Math.abs(e - s - 360) < 1e-6 || Math.abs(e) <= 720)) { dia = d; sa = s; ea = e; break; }
    }
    return { name: nm.text, X: r3(X), Y: r3(Y), Z: r3(Z), vec: vec, diam: dia === null ? null : r3(dia), startAngle: sa, endAngle: ea };
  }

  /* r67b hits: касания внутри автоэлемента — записи фикс. длины (в op5: 308 Б):
     X Y Z I J K (double) + служебные поля; перед каждой — 16-байтный идентификатор + пустая CString. */
  function unitAt(b, o) {
    var i = dbl(b, o), j = dbl(b, o + 8), k = dbl(b, o + 16);
    if (i === null || j === null || k === null) return false;
    var l = i * i + j * j + k * k; return Math.abs(l - 1) < 2e-6 && (i !== 0 || j !== 0 || k !== 0);
  }
  function xyzOk(b, o) { for (var c = 0; c < 3; c++) { var v = dbl(b, o + c * 8); if (v === null || Math.abs(v) > 1e5 || (v !== 0 && Math.abs(v) < 1e-9)) return false; } return true; }
  function readHits(b, from, end, near, maxPts) {
    for (var o = from; o + 48 < end; o++) {
      if (b[o + 31] !== 0xbf && b[o + 31] !== 0x3f && b[o + 47] !== 0xbf && b[o + 47] !== 0x3f && b[o + 39] !== 0xbf && b[o + 39] !== 0x3f) continue;
      if (!unitAt(b, o + 24) || !xyzOk(b, o)) continue;
      var x = dbl(b, o), y = dbl(b, o + 8), z = dbl(b, o + 16);
      if (near && Math.hypot(x - near[0], y - near[1], z - near[2]) > near[3]) continue;
      for (var S = 64; S <= 700; S++) {
        if (o + S + 48 > end || !unitAt(b, o + S + 24) || !xyzOk(b, o + S)) continue;
        var pts = [], p = o;
        while (p + 48 <= end && unitAt(b, p + 24) && xyzOk(b, p) && pts.length < maxPts) {
          pts.push([r3(dbl(b, p)), r3(dbl(b, p + 8)), r3(dbl(b, p + 16)), Math.round(dbl(b, p + 24) * 1e6) / 1e6, Math.round(dbl(b, p + 32) * 1e6) / 1e6, Math.round(dbl(b, p + 40) * 1e6) / 1e6]);
          p += S;
        }
        var total = pts.length; while (p + 48 <= end && unitAt(b, p + 24) && xyzOk(b, p)) { total++; p += S; }
        var distinct = pts.length > 1 && pts.some(function (q2) { return q2[0] !== pts[0][0] || q2[1] !== pts[0][1] || q2[2] !== pts[0][2]; });
        var isNom = near && Math.abs(x - near[0]) < 1e-6 && Math.abs(y - near[1]) < 1e-6 && Math.abs(z - near[2]) < 1e-6;
        if (total >= 3 && distinct && !isNom) return { stride: S, at: o, count: total, pts: pts };
      }
    }
    return null;
  }

  var KIND = { 612: 'circle', 613: 'sphere', 614: 'line', 615: 'cone', 616: 'cylinder', 617: 'plane', 618: 'slot', 619: 'slot',
    647: 'plane', 648: 'circle', 656: 'cylinder', 655: 'cone', 657: 'sphere', 646: 'line', 640: 'point', 641: 'point', 642: 'point' };

  function parse(part) {
    var cmds = walk(part), out = [], feats = [], depth = 0, groups = [];
    var version = u32(part, 0);
    for (var i = 0; i < cmds.length; i++) {
      var c = cmds[i], ac = Math.abs(c.code), t = obt(ac) || { id: String(ac), ru: 'Команда ' + ac, cat: '' };
      var ss = strings(part, c.q, c.q + c.len, 6);
      var label = ss[0] ? ss[0].text : t.ru, arg = ss[1] ? ss[1].text : '';
      var rec = { i: i, at: c.q - 6, code: ac, newStyle: c.code < 0, id: t.id, ru: t.ru, cat: t.cat, label: label, arg: arg, len: c.len, depth: depth };
      if (t.id === 'EW_GROUP_END' || t.id === 'END_IF_COMMAND' || t.id === 'END_ELSE_COMMAND' || t.id === 'END_WHILE' || t.id === 'END_DO') { depth = Math.max(0, depth - 1); rec.depth = depth; groups.pop(); }
      if (t.id === 'EW_GROUP_START' || t.id === 'IF_BLOCK_COMMAND' || t.id === 'WHILE_COMMAND' || t.id === 'DO_COMMAND') { depth++; groups.push(arg || label); }
      rec.group = groups.length ? groups[groups.length - 1] : '';
      if ((ac >= 612 && ac <= 619) || KIND[ac] && t.cat === 'feature') {
        var f = contactFeature(part, c, ss);
        if (f) {
          var nmOff = ss[1] ? c.q + ss[1].off : c.q;
          var rad = Math.max(50, (f.diam || 0) * 2 + 50);
          var h = readHits(part, nmOff + 600, c.q + c.len, [f.X, f.Y, f.Z, f.kind === 'plane' ? 5000 : rad], 2000);
          if (h) { f.hits = h.pts; f.hitCount = h.count; f.hitStride = h.stride; }
          f.kind = KIND[ac] || 'point'; f.obtype = t.id; f.group = rec.group; f.cmd = label; feats.push(f); rec.feature = f; }
      }
      out.push(rec);
    }
    /* r67 dims: блоки размеров. Ось 1002..1009: номинал +154, +доп +162, -доп +170 (от начала тела).
       Истинная позиция 1202..1209: номинал +190, допуск +198. Расстояние/угол 11xx: номинал +192, +доп +200, -доп +208. */
    var AX = { 1002: 'X', 1003: 'Y', 1004: 'Z', 1005: 'D', 1006: 'R', 1007: 'A', 1008: 'T', 1009: 'V',
      1202: 'X', 1203: 'Y', 1204: 'Z', 1205: 'D', 1206: 'DF', 1207: 'PA', 1208: 'PR', 1209: 'TP' };
    var dims = [], blk = null;
    function rd(q, o) { var v = dbl(part, q + o); return v === null || Math.abs(v) > 1e6 ? null : r3n(v); }
    for (var di = 0; di < out.length; di++) {
      var r = out[di], q = cmds[di].q;
      if (r.code === 1000 || r.code === 1200) { blk = { name: r.arg || r.label, kind: r.code === 1200 ? 'ПОЗИЦИЯ' : 'ПОЛОЖЕНИЕ', axes: [], group: r.group, at: r.at }; dims.push(blk); continue; }
      if (r.code === 1001 || r.code === 1201) { blk = null; continue; }
      if (AX[r.code] && blk) {
        if (r.code >= 1200) blk.axes.push(version >= 7000 ? { axis: AX[r.code], nominal: rd(q, 190), plusTol: rd(q, 198), minusTol: null } : (r.code === 1209 ? { axis: 'TP', nominal: null, plusTol: rd(q, 160), minusTol: null } : r.code === 1206 ? { axis: 'DF', nominal: rd(q, 144), plusTol: rd(q, 160), minusTol: rd(q, 168) } : { axis: AX[r.code], nominal: rd(q, 142), plusTol: null, minusTol: null }));
        else blk.axes.push({ axis: AX[r.code], nominal: rd(q, 154), plusTol: rd(q, 162), minusTol: rd(q, 170) });
        continue;
      }
      if (r.code >= 1100 && r.code < 1200) {
        dims.push({ name: r.arg || r.label, kind: r.ru, code: r.code, group: r.group, at: r.at,
          axes: [{ axis: r.code === 1109 ? 'A' : 'M', nominal: rd(q, 192), plusTol: rd(q, 200), minusTol: rd(q, 208) }] });
      }
    }
    var hist = {};
    out.forEach(function (r) { hist[r.id] = (hist[r.id] || 0) + 1; });
    return { version: version, commands: out, features: feats, dims: dims, histogram: hist };
  }

  function outline(res, max) {
    return res.commands.slice(0, max || 3000).map(function (r) {
      var s = new Array(r.depth + 1).join('   ') + r.ru + (r.label && r.label !== r.ru ? ' «' + r.label + '»' : '') + (r.arg ? '  ' + r.arg : '');
      var f = r.feature;
      if (f && f.hitCount) s += '   [касаний ' + f.hitCount + ']';
      if (f) s += '   X' + f.X + ' Y' + f.Y + ' Z' + f.Z + (f.vec ? '  IJK ' + f.vec.map(function (v) { return Math.round(v * 1e4) / 1e4; }).join(',') : '') + (f.diam !== null ? '  Ø' + f.diam : '');
      return s;
    });
  }

  var api = { parse: parse, walk: walk, outline: outline };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.PrgCommands = api;
})(typeof window !== 'undefined' ? window : globalThis);
