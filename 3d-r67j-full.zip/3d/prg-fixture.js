/* r67d - загрузка оснастки (osnastka.qfxt.json + osnastka.stl) прямо в программу.
   Оснастка ставится относительно детали по сдвигу укладки из json (placement.shiftSTL),
   оси STL -> CAD: CAD X = X, CAD Y = Z, CAD Z = -Y.
   Кнопка «Оснастка» (Ctrl+Shift+O): выбрать сразу оба файла. */
(function(){
  'use strict';
  var W = (typeof window !== 'undefined') ? window : globalThis;
  var fx = { mesh: null, json: null, visible: true, opacity: 0.85 };
  W.__pcdFixture = fx;

  function T(){ return W.THREE; }
  function scene(){ try { return W.scene3 || (typeof scene3 !== 'undefined' ? scene3 : null); } catch(e){ return null; } }
  function hint(){ try { (W.proRenderHint3 || proRenderHint3)(); } catch(e){} }
  function say(m){ try { (W.toast || toast)(m); } catch(e){ console.log(m); } }

  function stlPositions(buf){
    try { if (typeof W.parseSTL === 'function') return W.parseSTL(buf).positions; } catch(e){}
    try { return parseSTL(buf).positions; } catch(e){}
    var dv = new DataView(buf), n = dv.getUint32(80, true), p = new Float32Array(n*9), o = 84;
    for (var i=0;i<n;i++){ o += 12; for (var k=0;k<9;k++){ p[i*9+k] = dv.getFloat32(o, true); o += 4; } o += 2; }
    return p;
  }

  /* STL (координаты сборки) -> CAD детали */
  fx.toCad = function(pos, json){
    var sh = (json && json.placement && json.placement.shiftSTL) || [0,0,0];
    var out = new Float32Array(pos.length);
    for (var i=0;i<pos.length;i+=3){
      var x = pos[i]-sh[0], y = pos[i+1]-sh[1], z = pos[i+2]-sh[2];
      out[i] = x; out[i+1] = z; out[i+2] = -y;
    }
    return out;
  };

  function remove(){
    var s = scene();
    if (fx.mesh && s){ s.remove(fx.mesh); fx.mesh.traverse(function(o){ if(o.geometry) o.geometry.dispose(); if(o.material) o.material.dispose(); }); }
    fx.mesh = null; hint();
  }

  function build(pos, json){
    var THREE = T(), s = scene();
    if (!THREE || !s){ say('3D-окно ещё не открыто'); return; }
    remove();
    var out = fx.toCad(pos, json);
    var g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(out, 3));
    g.computeVertexNormals(); g.computeBoundingBox();
    var m = new THREE.MeshStandardMaterial({ color: 0x7d8792, metalness: 0.35, roughness: 0.6,
      transparent: fx.opacity < 1, opacity: fx.opacity, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 1 });
    var mesh = new THREE.Mesh(g, m);
    mesh.add(new THREE.LineSegments(new THREE.EdgesGeometry(g, 30), new THREE.LineBasicMaterial({ color: 0x2a3036 })));
    mesh.name = 'pcdFixture'; mesh.userData.isFixture = true;
    mesh.raycast = function(){};   // клики идут в деталь, а не в оснастку
    s.add(mesh); fx.mesh = mesh; fx.visible = true;
    var b = g.boundingBox;
    say('Оснастка: ' + (pos.length/9|0) + ' треуг., габарит ' + (b.max.x-b.min.x).toFixed(0) + 'x' + (b.max.y-b.min.y).toFixed(0) + 'x' + (b.max.z-b.min.z).toFixed(0) + ' мм');
    hint();
  }

  function readFile(f, asText){
    return new Promise(function(res, rej){ var r = new FileReader(); r.onload = function(){ res(r.result); }; r.onerror = rej; asText ? r.readAsText(f) : r.readAsArrayBuffer(f); });
  }

  fx.pick = function(){
    var inp = document.createElement('input'); inp.type = 'file'; inp.multiple = true; inp.accept = '.stl,.json';
    inp.onchange = async function(){
      var stl = null, js = null;
      for (var i=0;i<inp.files.length;i++){ var f = inp.files[i]; if (/\.json$/i.test(f.name)) js = f; else if (/\.stl$/i.test(f.name)) stl = f; }
      if (!stl){ say('Выберите osnastka.stl (и osnastka.qfxt.json)'); return; }
      try {
        if (js) fx.json = JSON.parse(await readFile(js, true));
        build(stlPositions(await readFile(stl, false)), fx.json);
        if (!fx.json) say('json не выбран - оснастка без сдвига укладки');
      } catch(e){ console.error(e); say('Ошибка загрузки оснастки: ' + e.message); }
    };
    inp.click();
  };
  fx.toggle = function(){ if (!fx.mesh) return fx.pick(); fx.visible = !fx.visible; fx.mesh.visible = fx.visible; hint(); };
  fx.remove = remove;
  fx.setOpacity = function(a){ fx.opacity = a; if (fx.mesh){ fx.mesh.material.opacity = a; fx.mesh.material.transparent = a < 1; fx.mesh.material.needsUpdate = true; hint(); } };

  /* Строки PC-DMIS для загрузки оснастки (синтаксис в PC-DMIS не проверен). */
  fx.pcdmisText = function(){
    var j = fx.json || {}, sh = (j.placement && j.placement.shiftCAD) || [0,0,0];
    var name = (j.pcdmis && j.pcdmis.name) || 'OSNASTKA_770_OP5';
    return [
      '            COMMENT/DOC,NO,Оснастка: ' + name + ', сдвиг укладки CAD ' + sh.map(function(v){ return (+v).toFixed(3); }).join(', '),
      name + '      =LOAD_FIXTURE/' + name + '.qfxt,TOG1=ON'
    ].join('\r\n');
  };
  fx.exportText = function(){
    var t = fx.pcdmisText();
    try { (W.downloadText || downloadText)(t + '\r\n', 'osnastka-pcdmis.txt'); } catch(e){ console.log(t); }
  };

  function ui(){
    if (document.getElementById('p67fxBar')) return;
    var bar = document.createElement('div'); bar.id = 'p67fxBar';
    bar.style.cssText = 'position:fixed;right:14px;bottom:110px;z-index:9998;display:flex;gap:6px;flex-wrap:wrap;';
    function btn(t, tip, fn){ var b = document.createElement('button'); b.textContent = t; b.title = tip;
      b.style.cssText = 'padding:6px 10px;border-radius:8px;border:1px solid #556;background:#2b3442;color:#e8eef6;cursor:pointer;font:12px sans-serif;';
      b.onclick = fn; bar.appendChild(b); }
    btn('Оснастка', 'Загрузить osnastka.stl + osnastka.qfxt.json (Ctrl+Shift+O)', fx.pick);
    btn('Показ осн.', 'Показать/скрыть оснастку', fx.toggle);
    btn('Прозр.', 'Прозрачность оснастки', function(){ fx.setOpacity(fx.opacity > 0.6 ? 0.35 : (fx.opacity > 0.3 ? 1 : 0.85)); });
    btn('LOAD_FIXTURE', 'Строки PC-DMIS для загрузки оснастки', fx.exportText);
    document.body.appendChild(bar);
    document.addEventListener('keydown', function(e){ if (e.ctrlKey && e.shiftKey && (e.code === 'KeyO')){ e.preventDefault(); fx.pick(); } });
  }
  if (typeof document !== 'undefined'){
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ui); else ui();
  }
  if (typeof module !== 'undefined') module.exports = fx;
})();
