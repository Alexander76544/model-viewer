/* r67h - наведение порядка в интерфейсе 3D.
   Плавающие кнопки поверх 3D (виды, Тв/Карк/Рентг, Касания, IP, DIMINFO, Вид PC-DMIS, Размеры, Коорд., Анализ,
   Оснастка/Показ осн./Прозр./LOAD_FIXTURE, Касания FAB, Quick Fixture FAB) накладывались друг на друга.
   Все они скрыты; то, чего не было в меню «CAD / 3D», добавляется туда автоматически (с галочкой состояния).
   ViewCube остаётся. Вернуть панель: «CAD / 3D» -> «Панель кнопок на 3D». */
(function(){
  'use strict';
  if (typeof document === 'undefined') return;
  var KEY = 'pcd67tidyStrip';
  var showStrip = false; try { showStrip = localStorage.getItem(KEY) === '1'; } catch(e){}
  var st = document.createElement('style'); st.id = 'p67tidyCss';
  function css(){
    st.textContent = '#p67fxBar,#p67hitsFab,#p66qfFab{display:none!important}' +
      (showStrip ? '' : '#pcdViewsStrip3{display:none!important}') +
      '#p67cadMi .sub .p67tdh{display:block;padding:4px 12px 2px;color:#6b7684;font-size:11px;border-top:1px solid #c9ced6;margin-top:3px;cursor:default}' +
      '#p67cadMi .sub .p67td.on::before{content:"✓ ";color:#1f6fb2;font-weight:700}';
  }
  css(); (document.head || document.documentElement).appendChild(st);

  function norm(s){ return String(s || '').toLowerCase().replace(/\(.*?\)/g, '').replace(/[^a-zа-яё0-9]+/g, ' ').trim(); }
  // кнопки панели, уже представленные в меню под другим именем
  var ALIAS = { 'изо': 'изометрия', 'вх': 'сверху', 'сп': 'спереди', '⌖': 'вписать', 'тв': 'твёрдое', 'карк': 'каркас', 'рентг': 'рентген', 'касания': 'касания' };
  function labelOf(b){
    var t = (b.textContent || '').trim(), tip = (b.title || '').trim();
    var nice = tip ? tip.split(/[—.:(]/)[0].trim() : t;
    if (!nice || nice.length > 48) nice = t;
    if (nice.toLowerCase() !== t.toLowerCase() && t.length <= 14 && !/вид \d/.test(nice)) nice = nice + ' [' + t + ']';
    return nice;
  }
  function sync(){
    var sub = document.querySelector('#p67cadMi .sub'), strip = document.getElementById('pcdViewsStrip3');
    if (!sub) return false;
    var have = [].map.call(sub.querySelectorAll('.si:not(.p67td)'), function(s){ return norm(s.childNodes[0] && s.childNodes[0].textContent); });
    function inMenu(b){
      var t = norm(b.textContent), a = ALIAS[(b.textContent || '').trim().toLowerCase()];
      return have.some(function(h){ return (a && h.indexOf(a) === 0) || (t.length > 3 && h.indexOf(t) === 0); });
    }
    // заголовок группы + переключатель панели
    var head = sub.querySelector('.p67tdh');
    if (!head){
      head = document.createElement('span'); head.className = 'p67tdh'; head.textContent = 'Вид и отображение';
      head.addEventListener('click', function(e){ e.stopPropagation(); });
      sub.appendChild(head);
      var tg = document.createElement('span'); tg.className = 'si p67td p67tdStrip'; tg.textContent = 'Панель кнопок на 3D (старая)';
      tg.addEventListener('click', function(e){ e.stopPropagation(); closeMenus(); showStrip = !showStrip; try { localStorage.setItem(KEY, showStrip ? '1' : '0'); } catch(_){} css(); mark(); });
      sub.appendChild(tg);
    }
    if (strip){
      [].forEach.call(strip.querySelectorAll('button'), function(b){
        if (b.__p67td || inMenu(b)) return;
        b.__p67td = true;
        var s = document.createElement('span'); s.className = 'si p67td'; s.textContent = labelOf(b);
        s.__btn = b;
        s.addEventListener('click', function(e){ e.stopPropagation(); closeMenus(); b.click(); setTimeout(mark, 50); });
        s.addEventListener('contextmenu', function(e){ e.preventDefault(); e.stopPropagation(); closeMenus(); b.dispatchEvent(new MouseEvent('contextmenu', { bubbles: true, cancelable: true })); });
        sub.insertBefore(s, sub.querySelector('.p67tdStrip'));
      });
    }
    mark(); return true;
  }
  function mark(){
    [].forEach.call(document.querySelectorAll('#p67cadMi .sub .p67td'), function(s){
      if (s.classList.contains('p67tdStrip')) { s.classList.toggle('on', showStrip); return; }
      var b = s.__btn; if (!b) return;
      var on = b.classList.contains('on') || b.classList.contains('active') || b.getAttribute('aria-pressed') === 'true' || /●|✓/.test(b.textContent || '');
      s.classList.toggle('on', !!on);
      s.style.opacity = b.disabled ? '.5' : '';
      var lab = labelOf(b); if (s.textContent !== lab) s.textContent = lab; // напр. «Анализ ×10»
    });
  }
  function closeMenus(){ [].forEach.call(document.querySelectorAll('.mi.open'), function(x){ x.classList.remove('open'); }); }
  var n = 0, iv = setInterval(function(){ sync(); if (++n > 40) clearInterval(iv); }, 500);
  document.addEventListener('mouseover', function(e){ var mi = document.getElementById('p67cadMi'); if (mi && mi.contains(e.target)) sync(); }, true);
  document.addEventListener('click', function(e){ var mi = document.getElementById('p67cadMi'); if (mi && mi.contains(e.target)) sync(); }, true);
  window.pcdTidy = { sync: sync, strip: function(on){ showStrip = !!on; css(); mark(); } };
})();
