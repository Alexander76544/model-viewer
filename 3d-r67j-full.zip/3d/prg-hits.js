/* r67c: касания из .PRG — показ в 3D и выгрузка в текст программы PC-DMIS.
   Координаты детали → three: (x, z, y), как у облака точек. */
(function () {
  'use strict';
  var hitsObj = null, selObj = null, visible = true, lastSig = '';
  function S() { try { return (typeof state !== 'undefined' && state) ? state : null; } catch (e) { return null; } }
  function els() { var p = S(); return (p && p.elements) || []; }
  function sc() { try { return (typeof scene3 !== 'undefined' && scene3) ? scene3 : null; } catch (e) { return null; } }
  function selId() { try { return typeof selectedElementId !== 'undefined' ? selectedElementId : null; } catch (e) { return null; } }
  function drop(o) { var s = sc(); if (!o) return; try { if (s) s.remove(o); o.geometry && o.geometry.dispose(); o.material && o.material.dispose(); } catch (e) {} }
  function mk(pts, color, size, order) {
    var pos = new Float32Array(pts.length * 3);
    for (var i = 0; i < pts.length; i++) { pos[i * 3] = pts[i][0]; pos[i * 3 + 1] = pts[i][2]; pos[i * 3 + 2] = pts[i][1]; }
    var g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    var m = new THREE.PointsMaterial({ size: size, color: color, sizeAttenuation: true, depthTest: false, transparent: true, opacity: 0.95 });
    var o = new THREE.Points(g, m); o.renderOrder = order; o.frustumCulled = false; o.raycast = function () {}; o.userData.kind = 'prgHits';
    return o;
  }
  function rebuild(force) {
    var s = sc(); if (!s || typeof THREE === 'undefined') return;
    var list = els(), sid = selId(), n = 0;
    list.forEach(function (e) { if (e && e._hits) n += e._hits.length; });
    var sig = list.length + ':' + n + ':' + sid + ':' + visible;
    if (!force && sig === lastSig) return; lastSig = sig;
    drop(hitsObj); drop(selObj); hitsObj = selObj = null;
    if (!visible || !n) return;
    var all = [], sel = [];
    list.forEach(function (e) { if (!e || !e._hits) return; (e.id === sid ? sel : all).push.apply(e.id === sid ? sel : all, e._hits); });
    if (all.length) { hitsObj = mk(all, 0xff9a2e, 1.4, 996); s.add(hitsObj); }
    if (sel.length) { selObj = mk(sel, 0xff2e6a, 2.6, 997); s.add(selObj); }
    try { if (typeof proRenderHint3 === 'function') proRenderHint3(); } catch (e) {}
  }
  function nv(v, d) { var n = parseFloat(v); return isFinite(n) ? n : d; }
  function f4(v) { return (Math.round(v * 10000) / 10000).toFixed(4); }
  function f6(v) { return (Math.round(v * 1e6) / 1e6).toFixed(6); }
  var TYPE = { cylinder: 'CYLINDER', circle: 'CIRCLE', plane: 'PLANE', point: 'POINT', sphere: 'SPHERE', cone: 'CONE', line: 'LINE', slot: 'SLOT' };
  function toText(maxPer) {
    var out = ['$$ NO,', '            Касания, прочитанные из исходного .PRG (r67c). Блоки MEAS/HIT/BASIC — теоретические точки.', '            '];
    var cnt = 0;
    els().forEach(function (e) {
      if (!e || !e._hits || !e._hits.length) return;
      var t = TYPE[String(e.type || '').toLowerCase()] || (e.diam ? 'CIRCLE' : 'POINT');
      var h = e._hits, step = Math.max(1, Math.ceil(h.length / (maxPer || h.length)));
      var use = []; for (var i = 0; i < h.length; i += step) use.push(h[i]);
      out.push(e.name + '      =FEAT/' + t + ',CARTESIAN' + (t === 'CIRCLE' || t === 'CYLINDER' ? ',IN,LEAST_SQR' : ''));
      out.push('            THEO/<' + f4(+e.x || 0) + ',' + f4(+e.y || 0) + ',' + f4(+e.z || 0) + '>,<' + f6(nv(e.i, 0)) + ',' + f6(nv(e.j, 0)) + ',' + f6(nv(e.k, 1)) + '>' + (e.diam ? ',' + f4(+e.diam) : ''));
      out.push('            MEAS/' + t + ',' + e.name + ',' + use.length + ',WORKPLANE');
      use.forEach(function (p) { out.push('              HIT/BASIC,NORMAL,<' + f4(p[0]) + ',' + f4(p[1]) + ',' + f4(p[2]) + '>,<' + f6(p[3]) + ',' + f6(p[4]) + ',' + f6(p[5]) + '>,<' + f4(p[0]) + ',' + f4(p[1]) + ',' + f4(p[2]) + '>,USE THEO = YES'); });
      out.push('            ENDMEAS/'); cnt++;
    });
    return { text: out.join('\r\n') + '\r\n', count: cnt };
  }
  function note(m) { try { if (typeof toast === 'function') return toast(m); } catch (e) {} try { console.log(m); } catch (e) {} }
  window.prgHits = {
    rebuild: function () { rebuild(true); },
    toggle: function () { visible = !visible; rebuild(true); note(visible ? 'Касания показаны' : 'Касания скрыты'); },
    toText: toText,
    exportText: function () {
      var mx = prompt('Сколько точек максимум на элемент (пусто — все)?', '50');
      if (mx === null) return;
      var r = toText(parseInt(mx, 10) || 0);
      if (!r.count) return note('В элементах нет касаний — импортируйте .PRG');
      var name = 'kasaniya.txt';
      if (typeof downloadText === 'function') downloadText(r.text, name);
      else { var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([r.text], { type: 'text/plain' })); a.download = name; a.click(); }
      note('Выгружено элементов с касаниями: ' + r.count);
    }
  };
  function fab() {
    if (typeof document === 'undefined' || document.getElementById('p67hitsFab')) return;
    var b = document.createElement('div'); b.id = 'p67hitsFab';
    b.style.cssText = 'position:fixed;right:14px;bottom:120px;z-index:9998;display:flex;flex-direction:column;gap:6px';
    function btn(t, tip, fn) { var x = document.createElement('button'); x.textContent = t; x.title = tip; x.style.cssText = 'padding:6px 10px;border-radius:8px;border:1px solid #c77a1a;background:#2a2016;color:#ffb35c;font:12px sans-serif;cursor:pointer'; x.onclick = fn; b.appendChild(x); }
    btn('● Касания', 'Показать/скрыть касания из .PRG (Ctrl+Shift+H)', function () { window.prgHits.toggle(); });
    btn('⤓ Касания', 'Выгрузить касания в текст PC-DMIS', function () { window.prgHits.exportText(); });
    document.body.appendChild(b);
  }
  if (typeof window !== 'undefined' && typeof document !== 'undefined') {
    document.addEventListener('keydown', function (ev) { if (ev.ctrlKey && ev.shiftKey && (ev.key === 'H' || ev.key === 'h' || ev.key === 'Р' || ev.key === 'р')) { ev.preventDefault(); window.prgHits.toggle(); } });
    var start = function () { fab(); setInterval(function () { rebuild(false); }, 700); };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
  }
  if (typeof module !== 'undefined') module.exports = window.prgHits;
})();
