# Формат PC-DMIS .CAD — находки (по CADDLL.DLL, Ghidra, 12 825 функций)

## 1. Контейнер
* `.CAD` — **поток MFC CArchive**, без OLE: `CFile::Open` → `CArchive(load, буфер 32000)` →
  `CADCollSerializeFromArchive` (CADDLL.DLL @18010e540).
* `.PlanCAD` — OLE/CFB, внутри поток с тем же CArchive (`CADCollSerializeFromStream`).
* Порядок байтов LE; числа — сырые `double`/`float`/`int32`/`uint16`/`uint8` (CArchive без выравнивания).
* `CArchive::ReadObject` **не используется** → имён классов MFC в файле нет; тип объекта —
  собственный код (виртуальный метод vtable+0x38 = GetType, значения < 0x6C, т.е. ≤108 типов).

## 2. Цепочка загрузки
```
CADCollSerializeFromArchive(ar)
  new CCadCollection(0x408)            FUN_18005d160
  FUN_180085660(coll, ar, headerOnly)  ← ГЛАВНЫЙ СЕРИАЛИЗАТОР (не декомпилирован: timeout 60 с)
  FUN_18006e6b0(coll, ar)              пост-обработка: имя файла, единицы, разрешение, ссылки
CADCollHasValidSchema(file) = FUN_180085660(..., 1) — читает только заголовок
```

## 3. Версия файла
`FUN_18007b800(build)`: из номера сборки PC-DMIS в заголовке выставляются ~60 глобальных флагов
схемы. Главный — `DAT_1805c0028` (версия схемы): 0x1A6 — текущая; 0x12D/0x12E/0x12F/300/0xCB —
сборки 4000–4200; 0x65/0x66/0xC9/0xCA — сборки 3800–3900 (0xDC4…0xEF2). Ниже 0x1068 — старые ветки.
`DAT_1805cb6b8`, `DAT_1805cb798` — флаги ширины полей (u16→u32, цвет RGB→ARGB).
Таблица `DAT_1805cb6c0[type]` — флаги «новый формат» по каждому типу объекта.

## 4. Базовые классы (порядок вызовов в Serialize)
```
CPCDbasic_cad        FUN_18012f150   (общие поля объекта; разобрать)
 └ CPCDbc_dispattr   FUN_1802b5e70   u16 maskA;
                                     if mask&1: (mask&0x40 ? int32 @0x94 : uint32 цвет @0x98 [|0xFF000000 если DAT_1805cb798==0])
                                     if mask&2: u8 @0x9c ; if mask&8: int32 @0xa4 ; if mask&4: int32 @0xa0
                                     (FUN_180028580 читает maskA)
   └ CPCDbc_geom     FUN_18031b8b0   флаги @0xa8: u16 (старые) или u32 (DAT_1805cb6b8!=0)
     ├ CPCDbc_curve  FUN_180094450   (данных нет, только сброс кэшей)
     └ CPCDbc_surface FUN_1800d0470  (разобрать)
```

## 5. Простые объекты (подтверждено)
| класс | Serialize | поля после базы |
|---|---|---|
| CPCDbc_line   | FUN_1800ab2c0 | CadPoint<double,3> P1 (24 Б), CadPoint<double,3> P2 |
| CPCDbc_pntvec | FUN_1800b2430 | (geom) CadPoint<double,3>, CadVector<double,3> |
| CPCDbc_sphere | FUN_1800b4f00 | (surface) центр double×3, вектор double×3, радиус double |
| CPCDbc_facetedface | FUN_1800a7d90 | (geom) схема<0x10: int32 + массив точек FUN_1802b91d0 + сетка FUN_180410220; иначе тесселяция FUN_1803ae8e0 + вершины FUN_18038fe00 |

Остальные кандидаты (Serialize рядом с конструкторами): arc FUN_180039d00, boundary FUN_180040200,
boundedsurf FUN_180047140, cylinder FUN_18009bd60, cone FUN_18008afc0, plane FUN_1800b13a0,
surfruled FUN_1800d5ee0, tabcyl FUN_1800d9900, circle FUN_18019d6f0, conicarc FUN_1801b8970,
ConicalSurface FUN_1801bd4a0, CylindricalSurface FUN_18027fe60, curveonparsurf FUN_18027c9b0,
Datum FUN_18009db70, DatumTarget FUN_1800a12f0, Dimension FUN_1800a3a90, Tolerance FUN_1800df760, Text FUN_1800da940.

## 6. Классы (RTTI, 120+)
CPCDbc_: line arc circle conicarc polyline compcurve bsplinecurve parsplinecurve curveonparsurf
TrimmedCurve OffsetCurve point pntvec pointcloud copdata plane cylinder cone sphere slot
PlaneSurface CylindricalSurface ConicalSurface SphericalSurface ToroidalSurface SuperSurface
bsplinesurf parsplinesurf surfrev surfruled tabcyl offsetsurf trimmedsurf boundedsurf boundary
facetedface solidface contour Datum DatumTarget Dimension Tolerance Gdt Text Property colordef
dispattr transmat view subfigdef subfiginst assoc + обёртки трансляторов (Iges*, Acis_*, Catia*,
UG_*, PROE_*, SolidWorks_*, Ideas_*, Aims_*, PdeLib_*).
Сборка: CCadAssembly, CCadPart, CCadInstance, CCadPartInstance, CCadComponent; слои/группы/виды.

## 7. Что нужно для читалки
1. `FUN_180085660` (главный цикл: заголовок, коды типов, фабрика объектов) — скрипт
   `DumpCadSerializer.java` (таймаут 30 мин + дизассемблер + vtable всех классов).
2. 2–3 реальных `.CAD` + та же модель в STEP — для сверки.

---
# r64: разобрано по ghidra_full2 (FUN_180085660 + vtables)

## Заголовок (загрузка, схема ≥ 0x12E) — реализовано в pcdmis-cad-reader.js
```
i16 FFFF, u16 схема (0x1A6 = 2025), u16 11, "CPCDbc_coll"          FUN_180089010
i32 сборка (схема>200)
i32 n, n×u16 — таблица схем подсистем; [0] = схема тесселяции        FUN_180349280
f64 разрешение; 3×f64 (≥0x191); u64 (≥0x19D)
u8 флаги(bit0 = unicode); u16 strMode; u16 wide(>0x1C); u16 argb(>0x196); u16,u16 (>99)
i32 nt, nt×u16 — версии типов (DAT_1805cb6c0[type])
u16, u32 n, n Б (FUN_180153d60, превью/данные)
CCadIPData: ReadCount n, n×CString, u32 m, m Б
i32 c: если <0 — nTypes=-c, i32 nObj; иначе nTypes=26, nObj=c
u16,u16, u32 флаги, i32, f64 допуск, f64 угл.допуск(≥0x199), f64 (>0x12E), f64 (≥0x19A), u16 единицы, u16 (≥200)
nTypes × i32 — число объектов каждого типа
объекты: { u8 код типа, i32 handle, Serialize(vtable[1]) } × nObj, затем u8 0xFF
далее: уровни (CCadLevels), системы координат, группы, сборка…
```
## Коды типов (GetType = vtable[7]) и Serialize (vtable[1])
0 view · 1 point · 2 line · 3 plane · 4 circle · 5 arc · 6 conicarc · 7 surfrev · 8 surfruled · 9 compcurve ·
10 bsplinecurve · 11 bsplinesurf · 12 parsplinecurve · 13 parsplinesurf · 14 curveonparsurf · 15 trimmedsurf ·
16 copdata · 17 tabcyl · 18 offsetsurf · 19 pntvec · 20 desline · 21 polyline · 22 sphere · 23 cylinder · 24 slot ·
25 cone · 26 solidface · 27 contour · 28 boundary · 29 boundedsurf · 43 transmat · 44 assoc · 45 subfigdef ·
46 subfiginst · 47 colordef · 48 facetedface · 53 Datum · 54 Dimension · 55 Tolerance · 61 pointcloud · 71 Text ·
72 OffsetCurve · 73 IgesManifoldSolidBRep · 74 PlaneSurface · 75 CylindricalSurface · 76 ConicalSurface ·
77 SphericalSurface · 78 ToroidalSurface · 79 IgesEdge · 80 IgesLoop · 81 IgesFace · 82 IgesShell · 83 DatumTarget ·
84 IgesVertex · 85 Direction · 86 TrimmedCurve · 87 TrimmedSurface · 88 SuperSurface · 89 Property (+ трансляторные 30–42, 49–52, 57–60, 64–70).
Полная таблица адресов Serialize — gh2/types.json.

## Базовая цепочка Serialize
basic_cad FUN_18012f150: u64 id, 8 Б, строка (SerializeReadString<wchar_t>)
dispattr  FUN_1802b5e70: u16 маска; бит0 → u32 цвет (или i32 при бите6); бит1 u8; бит3 i32; бит2 i32
geom      FUN_18031b8b0: u32 флаги (wide) / u16
curve     FUN_180094450: —
surface   FUN_1800c4f30: (cb7a0) u64; u8 маска: 1 → тесселяция FUN_1803ae8e0; 8 → вершины; 2 → FUN_1803be270; 4 → FUN_1800b51c0; 0x10 → набор тесселяций FUN_180389c60
line: 2×P3d · point: P3d · pntvec: P3d+V3d · sphere(surfrev): P3d, V3d, f64 R ·
circle: [кривая-тесселяция FUN_1803995e0 + u32[]] P3d центр, V3d нормаль, (верс.≠0) V3d начало + f64 R

## Тесселяция (CCadSurfaceTessellation FUN_1803ae8e0, схема ≥ 0xC)
u8 флаги, float3 min, float3 max, вложенный GdtTriangleMesh (FUN_18037f2b0), [>6] ReadCount n + n Б,
полосы: ReadCount k, k×(ReadCount m, m×u32 индексов, u8 флаг), вершины: ReadCount n, n×float3,
нормали: ReadCount n, n×float3, float3, [≠0] ReadCount + u32[] …
В r64 тесселяция ищется по сигнатуре «вершины + столько же единичных нормалей», полосы — обратным
разбором; тип полосы (список/strip/fan) выбирается по совпадению с нормалями.

## r65 — проверка на реальном файле (770.1003014-10_op5.CAD, 286 МБ)
- Заголовок читается полностью: схема 0x1A6, сборка 7406, мм, 471 405 объектов, 108 типов.
- Типы 101–107 = топология B-rep (классы BodyEntity, ShellEntity, FaceEntity, LoopEntity, CoedgeEntity, EdgeEntity, VertexEntity).
  Подтверждение: граней 24 239 = сумме всех поверхностей (NURBS 11 070 + цил. 4 652 + вращ. 3 385 + плоск. 2 472 + тор. 2 189 + сфер. 471); тел = оболочек = 107.
- Тесселяция: найдено 21 752 сетки, 459 604 вершины, 318 211 треугольников; габарит 1591×841×1273 мм; деталь (6-цилиндровая головка + оснастка) узнаваема.
  Режимы индексов: веер 17 473, список 3 220, полоса 1 102 (выбор по согласию с нормалями вершин).
- Скорость: ~2 с в Node, ~15 с в браузере вместе с построением; чтение асинхронное с прогрессом (PcdCadReader.readAsync).
- Ограничение: читаются только сохранённые сетки граней; грани без тесселяции (если PC-DMIS её не сохранил) не показываются; точная NURBS-геометрия не разбирается.
