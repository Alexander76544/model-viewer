/* pcdmis-cad-nurbs.js (r66e) — NURBS-поверхности PC-DMIS .CAD (тип 11): чтение, вычисление, проекция точки и точная нормаль.
 * Раскладка (по CPCDbc_bsplinesurf::Serialize, FUN_1800545f0): [базовая часть переменной длины]
 *   count+f64 knotsA[], count+f64 knotsB[], count+f64 weights[] (0 или np), count+f64[3] P[np], хвост 54 байта.
 *   count = MFC ReadCount (u16, 0xFFFF → u32). Начало массивов ищется по структуре (на файле 11 070 из 11 070).
 * Степени и порядок индексации точек выбираются по кратности крайних узлов (clamped: кратность = степень+1). */
(function (root) {
  function mult(K) { var m = 1; while (m < K.length && K[m] === K[0]) m++; return m; }
  function read(u8, o, h) {
    if (o.type[h] !== 11) return null; o.__sc = o.__sc || {}; if (h in o.__sc) return o.__sc[h];
    var dv = o.__dv || (o.__dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength));
    var b = root.PcdCadObjects.baseAt(u8, dv, o.start[h]), e = h < o.N ? o.start[h + 1] : u8.length, r = null;
    function cnt(p) { var n = dv.getUint16(p, true); return n === 0xffff ? [dv.getUint32(p + 2, true), 6] : [n, 2]; }
    function knots(p) { var c = cnt(p), n = c[0]; if (n < 2 || n > 4000 || p + c[1] + n * 8 > e) return null; var K = new Float64Array(n), q = p + c[1]; for (var i = 0; i < n; i++) { var v = dv.getFloat64(q, true); q += 8; if (!isFinite(v) || Math.abs(v) > 1e7 || (i && v < K[i - 1] - 1e-12)) return null; K[i] = v; } if (!(K[n - 1] > K[0])) return null; return { K: K, end: q }; }
    for (var p = b.body; p < e - 20 && !r; p++) {
      var A = knots(p); if (!A) continue; var B = knots(A.end); if (!B) continue;
      var q = B.end, cw = cnt(q), nw = cw[0]; if (q + cw[1] + nw * 8 > e) continue; var wq = q + cw[1]; q = wq + nw * 8;
      var cp = cnt(q), np = cp[0]; if (np < 4 || q + cp[1] + np * 24 > e || (nw && nw !== np)) continue;
      var da = mult(A.K) - 1, db = mult(B.K) - 1, na = A.K.length - da - 1, nb = B.K.length - db - 1;
      if (na * nb !== np || da < 1 || db < 1) continue;
      var P = new Float64Array(np * 3); q += cp[1]; for (var i = 0; i < np * 3; i++) { P[i] = dv.getFloat64(q, true); q += 8; }
      var W = null; if (nw) { W = new Float64Array(np); for (i = 0; i < np; i++) W[i] = dv.getFloat64(wq + i * 8, true); }
      r = { Ka: A.K, Kb: B.K, da: da, db: db, na: na, nb: nb, P: P, W: W, order: 1 };
    }
    o.__sc[h] = r; return r;
  }
  function basis(K, d, n, t) { var k = d; while (k < n - 1 && t >= K[k + 1]) k++; var N = [1], left = [], right = []; for (var j = 1; j <= d; j++) { left[j] = t - K[k + 1 - j]; right[j] = K[k + j] - t; var saved = 0, Nn = []; for (var r = 0; r < j; r++) { var den = right[r + 1] + left[j - r], tmp = den ? N[r] / den : 0; Nn[r] = saved + right[r + 1] * tmp; saved = left[j - r] * tmp; } Nn[j] = saved; N = Nn; } return { k: k, N: N }; }
  // order 0: P[ia*nb+ib]; order 1: P[ib*na+ia]
  function point(s, a, b) {
    var A = basis(s.Ka, s.da, s.na, a), B = basis(s.Kb, s.db, s.nb, b), x = 0, y = 0, z = 0, w = 0;
    for (var i = 0; i <= s.da; i++) for (var j = 0; j <= s.db; j++) { var ia = A.k - s.da + i, ib = B.k - s.db + j, idx = s.order ? ib * s.na + ia : ia * s.nb + ib, c = A.N[i] * B.N[j] * (s.W ? s.W[idx] : 1); x += c * s.P[idx * 3]; y += c * s.P[idx * 3 + 1]; z += c * s.P[idx * 3 + 2]; w += c; }
    return w ? [x / w, y / w, z / w] : [x, y, z];
  }
  function sub(p, q) { return [p[0] - q[0], p[1] - q[1], p[2] - q[2]]; }
  function dot(p, q) { return p[0] * q[0] + p[1] * q[1] + p[2] * q[2]; }
  function cross(p, q) { return [p[1] * q[2] - p[2] * q[1], p[2] * q[0] - p[0] * q[2], p[0] * q[1] - p[1] * q[0]]; }
  function frame(s, a, b) {
    var ra = s.Ka[s.Ka.length - 1] - s.Ka[0], rb = s.Kb[s.Kb.length - 1] - s.Kb[0], ea = ra * 1e-6, eb = rb * 1e-6;
    var a0 = Math.max(s.Ka[0], a - ea), a1 = Math.min(s.Ka[s.Ka.length - 1], a + ea), b0 = Math.max(s.Kb[0], b - eb), b1 = Math.min(s.Kb[s.Kb.length - 1], b + eb);
    var Pa = sub(point(s, a1, b), point(s, a0, b)).map(function (v) { return v / (a1 - a0); }), Pb = sub(point(s, a, b1), point(s, a, b0)).map(function (v) { return v / (b1 - b0); });
    return { P: point(s, a, b), Sa: Pa, Sb: Pb };
  }
  function clamp(v, K) { return Math.max(K[0], Math.min(K[K.length - 1], v)); }
  // ближайшая точка поверхности к X: сетка + Гаусс–Ньютон
  function project(s, X, grid) {
    grid = grid || 24; var Ka = s.Ka, Kb = s.Kb, best = 1e300, ba = 0, bb = 0;
    for (var i = 0; i <= grid; i++) for (var j = 0; j <= grid; j++) { var a = Ka[0] + (Ka[Ka.length - 1] - Ka[0]) * i / grid, b = Kb[0] + (Kb[Kb.length - 1] - Kb[0]) * j / grid, d = sub(point(s, a, b), X), dd = dot(d, d); if (dd < best) { best = dd; ba = a; bb = b; } }
    for (var it = 0; it < 20; it++) {
      var F = frame(s, ba, bb), r = sub(F.P, X), g11 = dot(F.Sa, F.Sa), g12 = dot(F.Sa, F.Sb), g22 = dot(F.Sb, F.Sb), r1 = dot(F.Sa, r), r2 = dot(F.Sb, r), det = g11 * g22 - g12 * g12;
      if (!(Math.abs(det) > 1e-30)) break; var da = (g22 * r1 - g12 * r2) / det, db = (g11 * r2 - g12 * r1) / det;
      var na = clamp(ba - da, Ka), nb = clamp(bb - db, Kb); if (Math.abs(na - ba) < 1e-12 && Math.abs(nb - bb) < 1e-12) break; ba = na; bb = nb;
    }
    var F2 = frame(s, ba, bb), n = cross(F2.Sa, F2.Sb), L = Math.hypot(n[0], n[1], n[2]);
    return { a: ba, b: bb, P: F2.P, N: L ? [n[0] / L, n[1] / L, n[2] / L] : null, dist: Math.hypot.apply(null, sub(F2.P, X)) };
  }
  root.PcdCadNurbs = { read: read, point: point, project: project };
})(typeof window !== 'undefined' ? window : globalThis);
