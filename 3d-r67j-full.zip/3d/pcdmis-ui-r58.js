/* r58: контекстное меню окна правки (как в PC-DMIS: Изменить F9, Свойства, Вырезать/Копировать/Вставить/Удалить,
 * Пометить F3, Точка останова, Начало выполнения, Найти Ctrl+F, Развернуть/Свернуть), окно «Свойства»,
 * видимость/цвет элементов в графике, касания всех элементов (HITS), меню графики по правой кнопке на пустом месте. */
(function () {
  'use strict';
  if (window.__p58) return; window.__p58 = true;
  function boot() {
    var A = window.__p57api;
    if (!A) { if ((boot._n = (boot._n || 0) + 1) < 100) setTimeout(boot, 100); return; }
    var h = A.h, btn = A.btn, inp = A.inp, esc = A.esc, num = A.num, toast = A.toast, G = A.G, S = A.S, icon = A.icon;
    function $(id) { return document.getElementById(id); }

    /* ---------- состояние (хранится в операции → автосохранение) ---------- */
    function P() { var s = S(); if (!s) return { marks: {}, bps: {}, start: '', hidden: {}, color: {}, noId: {} }; s._p58 = s._p58 || {}; var p = s._p58;
      ['marks', 'bps', 'hidden', 'color', 'noId'].forEach(function (k) { p[k] = p[k] || {}; }); if (p.start == null) p.start = ''; return p; }
    function save() { try { scheduleAutosave(); } catch (e) {} }
    function dimByName(n) { return A.dims().filter(function (d) { return d.name === n; })[0] || null; }

    /* ---------- CSS ---------- */
    var css = [
      '#pcdProgText .ln.p58m{background:#cfe8ff !important;}',
      '#pcdProgText .ln.p58b{background:#ffd9d9 !important;}',
      '#pcdProgText .ln.p58h{color:#8a8a8a !important;}',
      '#pcdProgText .ln.p58bp::before{content:"●";color:#d00000;position:absolute;left:1px;font-size:10px;}',
      '#pcdProgText .ln.p58st::before{content:"▶";color:#00a000;position:absolute;left:1px;font-size:9px;}',
      '#pcdProgText .ln.p58bp.p58st::before{content:"●▶";}',
      '#pcdProgText .ln{position:relative;}',
      '#pcdProgText .ln.p58sel{outline:1px dotted #0078d7;outline-offset:-1px;}',
      '#pcd25Sum .n.p58m{background:#cfe8ff;}',
      '#pcd25Sum .n.p58h>span:last-child{color:#8a8a8a;font-style:italic;}',
      '#pcd25Sum .n .p58g{width:12px;flex:none;font-size:9px;text-align:center;}',
      '#pcd25Sum .n .p58g.bp{color:#d00000;} #pcd25Sum .n .p58g.st{color:#00a000;}',
      '.p58sw{display:inline-block;width:12px;height:12px;border:1px solid #555;vertical-align:middle;margin-right:4px;}',
      '.p58tbl{border-collapse:collapse;width:100%;}',
      '.p58tbl td,.p58tbl th{border:1px solid #d5dfe5;padding:1px 5px;background:#fff;text-align:right;white-space:nowrap;}',
      '.p58tbl th{font-weight:normal;color:#444;text-align:center;}',
      '.p58tbl td.l{text-align:left;}',
      '.p58tbl td.bad{background:#ff9a9a;} .p58tbl td.ok{background:#bdf3bd;}',
      '.p58kv{display:grid;grid-template-columns:auto 1fr;gap:3px 10px;}',
      '.p58kv span:nth-child(odd){color:#555;text-align:right;}',
      '.p58kv span:nth-child(even){font-family:Consolas,monospace;}',
      '.p58lnk{color:#0066cc;cursor:pointer;text-decoration:underline;}'
    ].join('\n');
    var st = document.createElement('style'); st.id = 'p58css'; st.textContent = css; document.head.appendChild(st);

    /* ---------- разбор окна «Команды» на блоки ---------- */
    var RE_EL = /^\s*([^\s=]+)\s*=\s*(ЭЛТ|ПОСТР|ЭЛЕМ|FEAT|AUTO|CONST|ИЗМЕР)\b|^\s*([^\s=]+)\s*=\s*(ЭЛТ|ПОСТР)\//i;
    function blocks() {
      var pre = $('pcdProgText'); if (!pre) return [];
      var out = [], cur = null, kids = pre.children;
      for (var i = 0; i < kids.length; i++) {
        var t = kids[i].textContent || '', m;
        if ((m = /^\s*РАЗМ\.\s+([^=\s]+)\s*=/.exec(t))) { cur = { kind: 'dim', name: m[1], from: i, to: i }; out.push(cur); continue; }
        if ((m = /^\s*([^\s=]+)\s*=\s*(ЭЛТ|ПОСТР)/.exec(t)) && !/ГРУППА/.test(t)) { cur = { kind: 'el', name: m[1], from: i, to: i }; out.push(cur); continue; }
        if (/^\s*([^\s=]+)\s*=\s*ГРУППА/.test(t) || /КОНЕЦ_ГРУППЫ/.test(t) || /^\S/.test(t) && cur && cur.kind === 'el') { cur = null; continue; }
        if (cur) { cur.to = i; if (cur.kind === 'dim' && /^\s*КОНЕЦ РАЗМЕРА/.test(t)) cur = null; }
      }
      return out;
    }
    function blockAt(i) { var b = blocks(); for (var k = 0; k < b.length; k++) if (i >= b[k].from && i <= b[k].to) return b[k]; return null; }
    function targetOf(b) {
      if (!b) return null;
      if (b.kind === 'el') { var e = A.elByName(b.name); return e ? { kind: 'el', obj: e, name: e.name } : null; }
      var d = dimByName(b.name); return d ? { kind: 'dim', obj: d, name: d.name } : null;
    }

    var deco = 0;
    function decorate() {
      deco = 0;
      var p = P(), pre = $('pcdProgText');
      if (pre) {
        var kids = pre.children;
        for (var i = 0; i < kids.length; i++) kids[i].classList.remove('p58m', 'p58b', 'p58h', 'p58bp', 'p58st', 'p58sel');
        if (kids.length < 20000) blocks().forEach(function (b) {
          var e = b.kind === 'el' ? A.elByName(b.name) : null;
          for (var j = b.from; j <= b.to; j++) {
            var c = kids[j]; if (!c) continue;
            if (p.marks[b.name]) c.classList.add('p58m');
            if (e && p.hidden[e.id]) c.classList.add('p58h');
            if (p.bps[b.name] && j === b.from) c.classList.add('p58b');
          }
          if (p.bps[b.name] && kids[b.from]) kids[b.from].classList.add('p58bp');
          if (p.start === b.name && kids[b.from]) kids[b.from].classList.add('p58st');
          if (ctxSel && ctxSel.name === b.name) for (var q = b.from; q <= b.to; q++) if (kids[q]) kids[q].classList.add('p58sel');
        });
      }
      var sum = $('pcd25Sum');
      if (sum) [].forEach.call(sum.querySelectorAll('.n[data-k]'), function (r) {
        var k = r.getAttribute('data-k'), name = null, hid = false;
        if (k.indexOf('e:') === 0) { var e = A.elById(k.slice(2)); if (e) { name = e.name; hid = !!p.hidden[e.id]; } }
        else if (k.indexOf('d:') === 0) { var d = A.dims().filter(function (x) { return x.id === k.slice(2); })[0]; if (d) name = d.name; }
        r.classList.toggle('p58m', !!(name && p.marks[name])); r.classList.toggle('p58h', hid);
        var g = r.querySelector('.p58g'); if (!g) { g = h('span', { class: 'p58g' }); r.insertBefore(g, r.firstChild); }
        g.className = 'p58g' + (name && p.bps[name] ? ' bp' : name && p.start === name ? ' st' : '');
        g.textContent = name && p.bps[name] ? '●' : name && p.start === name ? '▶' : '';
      });
    }
    function redeco() { if (!deco) deco = requestAnimationFrame(decorate); }
    function observe(id) {
      var el = $(id); if (!el || el.__p58o) return !!el; el.__p58o = 1;
      new MutationObserver(function (ms) { if (ms.some(function (m) { return m.type === 'childList' && m.target === el; })) redeco(); }).observe(el, { childList: true });
      return true;
    }

    /* ---------- действия ---------- */
    var clip = null, ctxSel = null;
    function after() { A.refresh(); A.dirty(); redeco(); save(); try { rebuildElementsGroup3(); } catch (e) {} }
    function toggleMark(t) { var p = P(); if (p.marks[t.name]) delete p.marks[t.name]; else p.marks[t.name] = 1; redeco(); save(); }
    function markAll(on) { var p = P(); p.marks = {}; if (on) { A.elements().forEach(function (e) { p.marks[e.name] = 1; }); A.dims().forEach(function (d) { p.marks[d.name] = 1; }); } redeco(); save(); toast(on ? 'Помечено всё' : 'Пометки сняты'); }
    function toggleBp(t) { var p = P(); if (p.bps[t.name]) delete p.bps[t.name]; else p.bps[t.name] = 1; redeco(); save(); toast((p.bps[t.name] ? 'Точка останова установлена: ' : 'Точка останова снята: ') + '<b>' + esc(t.name) + '</b>'); }
    function setStart(t) { var p = P(); p.start = p.start === t.name ? '' : t.name; redeco(); save(); toast(p.start ? 'Начало выполнения: <b>' + esc(t.name) + '</b>' : 'Начало выполнения сброшено'); }
    function toggleHidden(e, v) { var p = P(); var hide = v == null ? !p.hidden[e.id] : v; if (hide) p.hidden[e.id] = 1; else delete p.hidden[e.id]; after(); }
    function copy(t) {
      if (t.kind === 'el') {
        var rel = A.dims().filter(function (d) { return d.refElement === t.name; });
        clip = { kind: 'el', obj: JSON.parse(JSON.stringify(t.obj)), dims: JSON.parse(JSON.stringify(rel)) };
      } else clip = { kind: 'dim', obj: JSON.parse(JSON.stringify(t.obj)) };
      try { navigator.clipboard && navigator.clipboard.writeText(blockText(t.name)); } catch (e) {}
      toast('Скопировано: <b>' + esc(t.name) + '</b>' + (clip.dims && clip.dims.length ? ' (+ размеров: ' + clip.dims.length + ')' : ''));
    }
    function blockText(name) {
      var b = blocks().filter(function (x) { return x.name === name; })[0], pre = $('pcdProgText'); if (!b || !pre) return name;
      var out = []; for (var i = b.from; i <= b.to; i++) out.push(pre.children[i].textContent); return out.join('\n');
    }
    function paste(t) {
      if (!clip) { toast('Буфер пуст — сначала «Копировать»'); return; }
      var s = S();
      if (clip.kind === 'el') {
        var e = JSON.parse(JSON.stringify(clip.obj)), old = e.name; e.id = A.newId(); e.name = A.uniqueName(old.replace(/(_\d+)?$/, '') + '_1', s.elements);
        var at = t && t.kind === 'el' ? s.elements.indexOf(t.obj) + 1 : s.elements.length; s.elements.splice(at, 0, e);
        (clip.dims || []).forEach(function (d0) { var d = JSON.parse(JSON.stringify(d0)); d.id = A.newId(); d.name = A.uniqueName(d.name + '_1', s.dimensions); d.refElement = e.name; d.rawBlock = null; (d.axes || []).forEach(function (a) { a.id = A.newId(); a.rawLine = null; }); s.dimensions.push(d); });
        after(); toast('Вставлен элемент <b>' + esc(e.name) + '</b>');
      } else {
        var d = JSON.parse(JSON.stringify(clip.obj)); d.id = A.newId(); d.name = A.uniqueName(d.name + '_1', s.dimensions); d.rawBlock = null;
        (d.axes || []).forEach(function (a) { a.id = A.newId(); a.rawLine = null; });
        var at2 = t && t.kind === 'dim' ? s.dimensions.indexOf(t.obj) + 1 : s.dimensions.length; s.dimensions.splice(at2, 0, d);
        after(); toast('Вставлен размер <b>' + esc(d.name) + '</b>');
      }
    }
    function del(t, silent) {
      var s = S();
      if (t.kind === 'el') {
        var rel = s.dimensions.filter(function (d) { return d.refElement === t.name || d.refElement2 === t.name; });
        if (!silent && !confirm('Удалить элемент «' + t.name + '»' + (rel.length ? ' и связанные размеры (' + rel.length + ')' : '') + '?')) return false;
        s.elements.splice(s.elements.indexOf(t.obj), 1);
        s.dimensions = s.dimensions.filter(function (d) { return rel.indexOf(d) < 0; });
      } else {
        if (!silent && !confirm('Удалить размер «' + t.name + '»?')) return false;
        s.dimensions.splice(s.dimensions.indexOf(t.obj), 1);
      }
      var p = P(); delete p.marks[t.name]; delete p.bps[t.name]; if (p.start === t.name) p.start = '';
      if (ctxSel && ctxSel.name === t.name) ctxSel = null;
      after(); return true;
    }
    function edit(t) { if (t.kind === 'el') window.pcdAutoFeatureOpen(t.obj); else A.editDimension(t.obj); }
    function show(t) { var e = t.kind === 'el' ? t.obj : A.elByName(t.obj.refElement); if (e) { try { pcdAct('tab:model'); } catch (_) {} try { selectElementInScene(e.id); } catch (_) {} } }

    function summaryOpenAll(on) {
      var sum = $('pcd25Sum'); if (!sum) return;
      // у «Сводки» своё состояние раскрытия: щёлкаем по кнопкам +/− нужных узлов
      var guard = 0;
      (function pass() {
        var tws = [].filter.call(sum.querySelectorAll('.n .tw'), function (t) { return t.textContent === (on ? '+' : '−'); });
        if (!on) tws = tws.filter(function (t) { return t.parentNode.getAttribute('data-k') !== 'root'; });
        if (!tws.length || ++guard > 40) return;
        tws[0].dispatchEvent(new MouseEvent('click', { bubbles: true })); setTimeout(pass, 0);
      })();
    }

    function editMenu(x, y, t, where) {
      var p = P(), items = [];
      var ttl = t ? (t.kind === 'el' ? 'Элемент ' : 'Размер ') + t.name : 'Окно правки';
      if (t) {
        items.push(['Изменить…    F9', function () { edit(t); }, 'edit']);
        items.push(['Свойства…    Alt+Enter', function () { window.pcdPropsOpen(t.obj); }, 'header']);
        items.push('-');
        items.push(['Вырезать    Ctrl+X', function () { copy(t); del(t, true); }, null]);
        items.push(['Копировать    Ctrl+C', function () { copy(t); }, 'copy']);
      }
      items.push(['Вставить    Ctrl+V' + (clip ? '  (' + (clip.kind === 'el' ? clip.obj.name : clip.obj.name) + ')' : ''), function () { paste(t); }, null]);
      if (t) items.push(['Удалить    Del', function () { del(t); }, null]);
      items.push('-');
      if (t) {
        items.push([(p.marks[t.name] ? 'Снять пометку' : 'Пометить') + '    F3', function () { toggleMark(t); }, null]);
      }
      items.push(['Пометить всё    Ctrl+Shift+A', function () { markAll(true); }, null]);
      items.push(['Снять все пометки', function () { markAll(false); }, null]);
      if (t) {
        items.push([(p.bps[t.name] ? 'Удалить точку останова' : 'Вставить точку останова') + '    Ctrl+B', function () { toggleBp(t); }, null]);
        items.push([p.start === t.name ? 'Сбросить начало выполнения' : 'Установить начало выполнения', function () { setStart(t); }, 'play']);
        items.push(['Выполнить с этого места (виртуально)', function () { setStart(t); try { pcdAct('vp'); } catch (_) {} }, 'play']);
      }
      items.push('-');
      if (t) {
        items.push(['Показать в графике', function () { show(t); }, 'gfx']);
        if (t.kind === 'el') items.push([p.hidden[t.obj.id] ? 'Показать элемент в графике' : 'Скрыть элемент в графике', function () { toggleHidden(t.obj); }, null]);
        if (t.kind === 'el') {
          items.push(['Размер: положение…', function () { window.pcdLocationOpen([t.name]); }, 'dim']);
          items.push(['Размер: расстояние / угол…', function () { window.pcdDistanceOpen('РАССТОЯНИЕ 2D', [t.name]); }, 'dim']);
          items.push(['GD&T: позиция…', function () { A.openGdt('ПОЗИЦИЯ', t.name); }, 'pos']);
        }
        items.push('-');
      }
      if (where === 'sum') { items.push(['Развернуть всё', function () { summaryOpenAll(true); }, null]); items.push(['Свернуть всё', function () { summaryOpenAll(false); }, null]); }
      items.push(['Найти…    Ctrl+F', function () { findOpen(); }, null]);
      items.push(['Показать все скрытые элементы', function () { P().hidden = {}; after(); }, null]);
      A.menu(x, y, ttl, items);
    }

    /* ---------- привязка к окну правки ---------- */
    var focusEdit = false;
    document.addEventListener('mousedown', function (e) {
      var inEdit = !!(e.target.closest && (e.target.closest('#pcdProgPane') || e.target.closest('#pcd25Sum')));
      if (!e.target.closest || !e.target.closest('#p57Menu')) focusEdit = inEdit;
    }, true);
    function targetFromEvent(e) {
      var ln = e.target.closest && e.target.closest('#pcdProgText > .ln');
      if (ln) { var i = Array.prototype.indexOf.call(ln.parentNode.children, ln); return { t: targetOf(blockAt(i)), where: 'cmd', line: i }; }
      var row = e.target.closest && e.target.closest('#pcd25Sum .n[data-k]');
      if (row) {
        var k = row.getAttribute('data-k');
        if (k.indexOf('e:') === 0) { var el = A.elById(k.slice(2)); return { t: el ? { kind: 'el', obj: el, name: el.name } : null, where: 'sum' }; }
        if (k.indexOf('d:') === 0) { var d = A.dims().filter(function (x) { return x.id === k.slice(2); })[0]; return { t: d ? { kind: 'dim', obj: d, name: d.name } : null, where: 'sum' }; }
        return { t: null, where: 'sum' };
      }
      if (e.target.closest && e.target.closest('#pcd25Sum')) return { t: null, where: 'sum' };
      if (e.target.closest && e.target.closest('#pcdProgPane .pcd-prog-body')) return { t: null, where: 'cmd' };
      return null;
    }
    document.addEventListener('contextmenu', function (e) {
      var r = targetFromEvent(e); if (!r) return;
      if ($('pcdProgEdit') && $('pcdProgEdit').style.display !== 'none' && e.target.closest('#pcdProgEdit')) return; // текстовый режим — обычное меню
      e.preventDefault(); e.stopPropagation();
      ctxSel = r.t; redeco();
      if (r.t && r.where === 'cmd') { try { pcdMarkCurLine(r.line, 1); } catch (_) {} }
      editMenu(e.clientX, e.clientY, r.t, r.where);
    }, true);
    document.addEventListener('click', function (e) { var r = targetFromEvent(e); if (r && r.t) { ctxSel = r.t; redeco(); } }, true);
    document.addEventListener('dblclick', function (e) {
      var ln = e.target.closest && e.target.closest('#pcdProgText > .ln'); if (!ln) return;
      var t = targetOf(blockAt(Array.prototype.indexOf.call(ln.parentNode.children, ln))); if (t) { e.preventDefault(); edit(t); }
    }, true);
    function curTarget() {
      if (ctxSel) { var t = ctxSel.kind === 'el' ? A.elByName(ctxSel.name) : dimByName(ctxSel.name); if (t) return { kind: ctxSel.kind, obj: t, name: t.name }; }
      var id = G('selectedElementId'), e = id && A.elById(id); return e ? { kind: 'el', obj: e, name: e.name } : null;
    }
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { var mm = $('p57Menu'); if (mm && mm.style.display === 'block') { mm.style.display = 'none'; e.preventDefault(); return; } }
      var tag = (e.target && e.target.tagName) || '', typing = /INPUT|TEXTAREA|SELECT/.test(tag) || (e.target && e.target.isContentEditable);
      if (typing) return;
      var t = curTarget();
      if (e.key === 'F3') { e.preventDefault(); if (t) toggleMark(t); return; }
      if (e.key === 'Enter' && e.altKey && t) { e.preventDefault(); window.pcdPropsOpen(t.obj); return; }
      if (e.ctrlKey && e.shiftKey && (e.key === 'A' || e.key === 'a' || e.key === 'Ф' || e.key === 'ф')) { e.preventDefault(); markAll(true); return; }
      if (e.ctrlKey && !e.shiftKey && (e.key === 'f' || e.key === 'F' || e.key === 'а' || e.key === 'А') && focusEdit) { e.preventDefault(); findOpen(); return; }
      if (!focusEdit) return;
      if (e.ctrlKey && (e.key === 'b' || e.key === 'B' || e.key === 'и') && t) { e.preventDefault(); toggleBp(t); }
      else if (e.ctrlKey && (e.key === 'c' || e.key === 'с') && t && !String(window.getSelection() || '')) { e.preventDefault(); copy(t); }
      else if (e.ctrlKey && (e.key === 'x' || e.key === 'ч') && t) { e.preventDefault(); copy(t); del(t, true); }
      else if (e.ctrlKey && (e.key === 'v' || e.key === 'м')) { e.preventDefault(); paste(t); }
      else if (e.key === 'Delete' && t) { e.preventDefault(); del(t); }
    });

    /* ---------- Найти ---------- */
    function findOpen() {
      var w = A.win('find', 'Найти', 'prg', 380); w.body.innerHTML = ''; w.foot.innerHTML = '';
      var q = inp(findOpen._q || ''); q.style.width = '100%';
      var cs = h('input', { type: 'checkbox' }), info = h('div', { class: 'p57muted', style: 'margin-top:6px' });
      w.body.appendChild(h('div', { class: 'p57row' }, [h('span', { text: 'Найти:' }), q]));
      w.body.appendChild(h('label', {}, [cs, 'С учётом регистра'])); w.body.appendChild(info);
      var pos = -1;
      function go(dir) {
        var pre = $('pcdProgText'); if (!pre) return; findOpen._q = q.value;
        var s = cs.checked ? q.value : q.value.toUpperCase(); if (!s) return;
        var n = pre.children.length, hits = 0;
        for (var k = 0; k < n; k++) { var tt = pre.children[k].textContent; if ((cs.checked ? tt : tt.toUpperCase()).indexOf(s) >= 0) hits++; }
        for (var j = 1; j <= n; j++) {
          var i = ((pos + dir * j) % n + n) % n, txt = pre.children[i].textContent;
          if ((cs.checked ? txt : txt.toUpperCase()).indexOf(s) >= 0) {
            pos = i;
            try { if (document.body.classList.contains('pcd25-summary')) { var mb = document.querySelector('.pcd25-mode button[data-m=cmd]'); if (mb) mb.click(); } } catch (_) {}
            pre.children[i].scrollIntoView({ block: 'center' });
            try { pcdMarkCurLine(i, 1); } catch (_) {}
            var t = targetOf(blockAt(i)); ctxSel = t; redeco();
            info.textContent = 'Строка ' + (i + 1) + (t ? ' · ' + (t.kind === 'el' ? 'элемент ' : 'размер ') + t.name : '') + ' · совпадений: ' + hits;
            return;
          }
        }
        info.textContent = 'Не найдено';
      }
      w.foot.appendChild(h('span', { class: 'sp' }));
      w.foot.appendChild(btn('Найти далее', function () { go(1); }, 'def'));
      w.foot.appendChild(btn('Назад', function () { go(-1); }));
      w.foot.appendChild(btn('Закрыть', function () { w.close(); }));
      setTimeout(function () { q.focus(); q.select(); }, 10);
    }
    window.pcdFindOpen = findOpen;

    /* ---------- Свойства ---------- */
    var TYPE_RU = { plane: 'Плоскость', cylinder: 'Цилиндр', cone: 'Конус', circle: 'Окружность', point_measured: 'Точка', point_constructed: 'Точка (построенная)',
      circle_constructed: 'Окружность (построенная)', line_constructed: 'Прямая (построенная)', sphere: 'Сфера', ellipse: 'Эллипс', torus: 'Тор' };
    window.pcdPropsOpen = function (obj) {
      if (!obj) return;
      var isEl = A.elements().indexOf(obj) >= 0;
      var w = A.win('props', 'Свойства — ' + obj.name, 'header', 520); w.body.innerHTML = ''; w.foot.innerHTML = '';
      var p = P();
      function kv(pairs) { var g = h('div', { class: 'p58kv' }); pairs.forEach(function (x) { g.appendChild(h('span', { text: x[0] })); g.appendChild(h('span', { text: x[1] == null || x[1] === '' ? '—' : String(x[1]) })); }); return g; }
      function fs(title, kids) { return h('fieldset', {}, [h('legend', { text: title })].concat(kids)); }
      if (isEl) {
        var e = obj, strat = e.strategy || '', hits = A.hitsFor(e).length;
        var src = e._profile ? 'импорт из родного .PRG (' + e._profile + ')' : (e.rawBlock ? 'импорт из текста программы' : 'создан в программе');
        w.body.appendChild(fs('Общие', [kv([['ID', e.name], ['Тип', (TYPE_RU[e.type] || e.type) + (e._obtype ? ' · ' + e._obtype : '')], ['Группа', e.group], ['Источник', src], ['Команда', e._cmd || ''], ['Стратегия', strat]])]));
        var dx = num(e.factX, NaN) - num(e.x), dy = num(e.factY, NaN) - num(e.y), dz = num(e.factZ, NaN) - num(e.z), dd = num(e.factDiam, NaN) - num(e.diam);
        var hasF = !e.factSameAsNominal;
        var t = h('table', { class: 'p58tbl' });
        t.innerHTML = '<tr><th></th><th>Теор.</th><th>Факт</th><th>Откл.</th></tr>' +
          [['X', e.x, e.factX, dx], ['Y', e.y, e.factY, dy], ['Z', e.z, e.factZ, dz], ['I', e.i, e.factI], ['J', e.j, e.factJ], ['K', e.k, e.factK]]
            .concat(/cylinder|circle|sphere|ellipse/.test(e.type) ? [['Ø', e.diam, e.factDiam, dd]] : []).concat(e.type === 'cylinder' ? [['Длина', e.depth, e.factDepth]] : [])
            .map(function (r) { return '<tr><td class="l">' + r[0] + '</td><td>' + esc(A.fs(r[1])) + '</td><td>' + (hasF ? esc(A.fs(r[2])) : '') + '</td><td>' + (hasF && isFinite(r[3]) ? r[3].toFixed(3) : '') + '</td></tr>'; }).join('');
        var d3 = hasF && isFinite(dx) && isFinite(dy) && isFinite(dz) ? Math.hypot(dx, dy, dz) : NaN;
        w.body.appendChild(fs('Геометрия', [t, h('div', { class: 'p57muted', style: 'margin-top:4px', text: hasF ? (isFinite(d3) ? 'Отклонение центра 3D: ' + d3.toFixed(3) + ' мм' : '') : 'Факт = теор. (измерений нет)' })]));
        w.body.appendChild(fs('Касания', [kv([['Касаний × рядов', (e.points || '—') + ' × ' + (e.rows || '1')], ['Глубина / отступ', (e.depthParam || '—') + ' / ' + (e.finishOffset || '—')], ['Углы', (e.startAngle || 0) + '° … ' + (e.endAngle || 360) + '°  ' + (e.direction || '')], ['Теор. касаний', hits]])]));
        var rel = A.dims().filter(function (d) { return d.refElement === e.name || d.refElement2 === e.name; });
        var dl = h('div');
        if (!rel.length) dl.appendChild(h('span', { class: 'p57muted', text: 'Нет размеров — «Создать размер» ниже' }));
        rel.forEach(function (d) {
          var rows = A.axisRows(Object.assign({}, e, { name: d.refElement })).filter(function (r) { return r.dim === d.name; });
          var bad = rows.some(function (r) { return r.out > 0; }), meas = rows.some(function (r) { return isFinite(r.meas); });
          var a = h('span', { class: 'p58lnk', text: d.name }); a.addEventListener('click', function () { A.editDimension(d); });
          dl.appendChild(h('div', {}, [a, ' — ' + d.dimType + ' · оси: ' + (d.axes || []).map(function (x) { return x.axis; }).join(' ') + (meas ? (bad ? ' · ВНЕ ДОПУСКА' : ' · в допуске') : '')]));
        });
        w.body.appendChild(fs('Размеры (' + rel.length + ')', [dl]));
        var vis = h('input', { type: 'checkbox' }); vis.checked = !p.hidden[e.id];
        var lid = h('input', { type: 'checkbox' }); lid.checked = !p.noId[e.id];
        var col = h('input', { type: 'color' }); col.value = p.color[e.id] || '#22d3ee'; col.style.cssText = 'width:40px;height:21px;padding:0;border:1px solid #7a7a7a;';
        var colReset = btn('По умолчанию', function () { delete P().color[e.id]; col.value = '#22d3ee'; after(); }); colReset.style.minWidth = '0';
        vis.addEventListener('change', function () { toggleHidden(e, !vis.checked); });
        lid.addEventListener('change', function () { if (lid.checked) delete P().noId[e.id]; else P().noId[e.id] = 1; after(); });
        col.addEventListener('input', function () { P().color[e.id] = col.value; after(); });
        w.body.appendChild(fs('Отображение в графике', [h('div', { class: 'p57row' }, [h('label', {}, [vis, 'Показывать']), h('label', {}, [lid, 'Метка ID']), h('span', { text: 'Цвет:' }), col, colReset])]));
      } else {
        var d = obj, ref = A.elByName(d.refElement);
        w.body.appendChild(fs('Общие', [kv([['ID', d.name], ['Тип', d.dimType], ['Элемент', d.refElement], ['Относительно', d.refElement2], ['Базы', d.datumRef || ''], ['Модификатор', d.mod || ''], ['Вывод', (/ВЫВОД=(\S+)/.exec(d.optLine || '') || [0, 'ОБА'])[1]], ['Группа', (d.groupPath || []).join(' / ')]])]));
        var rows2 = ref ? A.axisRows(ref).filter(function (r) { return r.dim === d.name; }) : [];
        var t2 = h('table', { class: 'p58tbl' });
        t2.innerHTML = '<tr><th>Ось</th><th>Номинал</th><th>+Доп</th><th>−Доп</th><th>Измер.</th><th>Откл.</th><th>Вне доп.</th></tr>' + (d.axes || []).map(function (a, i) {
          var r = rows2[i] || {};
          return '<tr><td class="l">' + esc(a.axis) + '</td><td>' + esc(a.nominal) + '</td><td>' + esc(a.plusTol) + '</td><td>' + esc(a.minusTol) + '</td><td>' + (isFinite(r.meas) ? r.meas.toFixed(3) : '') +
            '</td><td>' + (isFinite(r.dev) ? r.dev.toFixed(3) : '') + '</td><td class="' + (r.out > 0 ? 'bad' : isFinite(r.out) ? 'ok' : '') + '">' + (isFinite(r.out) ? r.out.toFixed(3) : '') + '</td></tr>';
        }).join('');
        w.body.appendChild(fs('Оси', [t2]));
        var hist = d.protocolHistory || [];
        if (hist.length) w.body.appendChild(fs('История протоколов (' + hist.length + ')', [h('div', { text: hist.slice(-8).map(function (x) { return (x.partLabel || '?') + ': ' + (x.outOfTol ? 'ВНЕ' : 'ок') + (x.measured != null ? ' (' + x.measured + ')' : ''); }).join(' · ') })]));
      }
      var mk = h('input', { type: 'checkbox' }); mk.checked = !!p.marks[obj.name];
      var bp = h('input', { type: 'checkbox' }); bp.checked = !!p.bps[obj.name];
      var sp = h('input', { type: 'checkbox' }); sp.checked = p.start === obj.name;
      mk.addEventListener('change', function () { if (mk.checked) P().marks[obj.name] = 1; else delete P().marks[obj.name]; redeco(); save(); });
      bp.addEventListener('change', function () { if (bp.checked) P().bps[obj.name] = 1; else delete P().bps[obj.name]; redeco(); save(); });
      sp.addEventListener('change', function () { P().start = sp.checked ? obj.name : ''; redeco(); save(); });
      w.body.appendChild(h('fieldset', {}, [h('legend', { text: 'Выполнение' }), h('div', { class: 'p57row' }, [h('label', {}, [mk, 'Помечено (F3)']), h('label', {}, [bp, 'Точка останова']), h('label', {}, [sp, 'Начало выполнения'])])]));
      w.foot.appendChild(h('span', { class: 'sp' }));
      w.foot.appendChild(btn('Изменить… (F9)', function () { if (isEl) window.pcdAutoFeatureOpen(obj); else A.editDimension(obj); }));
      if (isEl) w.foot.appendChild(btn('Создать размер…', function () { window.pcdLocationOpen([obj.name]); }));
      w.foot.appendChild(btn('Закрыть', function () { w.close(); }, 'def'));
    };

    /* ---------- 3D: скрытие, цвет, метки, касания всех элементов ---------- */
    var showHits = localStorage.getItem('p58.hits') === '1', allHits = null;
    function applyDisplay() {
      var eg = G('elementsGroup3'); if (!eg) return;
      var p = P();
      eg.children.forEach(function (g) {
        var id = g.userData && g.userData.elementId; if (!id) return;
        g.visible = !p.hidden[id];
        var c = p.color[id];
        g.traverse(function (o) {
          if (c && o.material && o.userData && o.userData.kind === 'nominal' && o.material.color) { o.material = o.material.clone(); o.material.color.set(c); }
          if (o.userData && o.userData.kind === 'label' && p.noId[id]) o.visible = false;
        });
      });
      drawAllHits();
    }
    function drawAllHits() {
      var THREE_ = window.THREE, scene = G('scene3');
      if (allHits && allHits.parent) { allHits.parent.remove(allHits); allHits.traverse(function (o) { if (o.geometry) o.geometry.dispose(); if (o.material) o.material.dispose(); }); }
      allHits = null;
      if (!showHits || !THREE_ || !scene) return;
      var tv = G('toThreeVec'), td = G('toThreeDir'), p = P(); if (typeof tv !== 'function') return;
      var pts = [], vec = [], cap = 6000;
      A.elements().forEach(function (e) {
        if (p.hidden[e.id] || pts.length > cap) return;
        A.hitsFor(e).forEach(function (hh) {
          if (pts.length > cap) return;
          var P0 = tv(hh.p[0], hh.p[1], hh.p[2]), D = td(hh.n[0], hh.n[1], hh.n[2]), L = Math.max(1.5, Math.min(8, num(e.diam, 10) * 0.2));
          pts.push(P0); vec.push(P0, P0.clone().addScaledVector(D, L));
        });
      });
      if (!pts.length) return;
      allHits = new THREE_.Group(); allHits.name = 'p58AllHits';
      var pg = new THREE_.BufferGeometry().setFromPoints(pts);
      allHits.add(new THREE_.Points(pg, new THREE_.PointsMaterial({ color: 0xff7f00, size: 6, sizeAttenuation: false, depthTest: false, transparent: true, fog: false, toneMapped: false })));
      var lg = new THREE_.BufferGeometry().setFromPoints(vec);
      allHits.add(new THREE_.LineSegments(lg, new THREE_.LineBasicMaterial({ color: 0xffa040, depthTest: false, transparent: true, fog: false, toneMapped: false })));
      allHits.children.forEach(function (o) { o.renderOrder = 997; });
      var eg = G('elementsGroup3'); if (eg) { eg.updateMatrixWorld(); allHits.matrixAutoUpdate = false; allHits.matrix.copy(eg.matrixWorld); }
      scene.add(allHits);
      var info = $('p58HitsInfo'); if (info) info.textContent = pts.length;
    }
    window.pcdHitsToggle = function (on) {
      showHits = on == null ? !showHits : !!on; localStorage.setItem('p58.hits', showHits ? '1' : '0');
      [].forEach.call(document.querySelectorAll('.p58hits'), function (b) { b.classList.toggle('on', showHits); });
      drawAllHits();
    };
    function wrapRebuild() {
      var f = G('rebuildElementsGroup3'); if (typeof f !== 'function' || f.__p58) return typeof f === 'function';
      var w = function () { var r = f.apply(this, arguments); try { applyDisplay(); } catch (e) { console.warn('p58 display', e); } return r; };
      w.__p58 = 1;
      try { window.rebuildElementsGroup3 = w; } catch (e) {}
      try { rebuildElementsGroup3 = w; } catch (e) {} // eslint-disable-line no-func-assign
      return true;
    }
    function addStrip() {
      var strip = $('pcdViewsStrip3'); if (!strip) return false;
      var row = strip.querySelector('.p57tg') && strip.querySelector('.p57tg').parentNode; if (!row) return false;
      if (row.querySelector('.p58hits')) return true;
      var b = h('button', { class: 'p57tg p58hits', title: 'Теоретические касания всех элементов в графике', text: 'Касания' }); b.style.cssText = 'font-size:10px;padding:3px 7px;cursor:pointer;';
      b.addEventListener('click', function () { window.pcdHitsToggle(); });
      row.insertBefore(b, row.firstChild); b.classList.toggle('on', showHits);
      return true;
    }

    /* ---------- меню графики по правой кнопке на пустом месте ---------- */
    function gfxMenu(x, y) {
      var p = P(), nh = Object.keys(p.hidden).length;
      function v(k) { return function () { try { window.pcdView3(k); } catch (_) {} }; }
      function rm(k) { return function () { try { window.pcdRenderMode3(k); } catch (_) {} }; }
      A.menu(x, y, 'Окно графики', [
        ['Вписать в окно', v('fit'), 'gfx'], ['Изометрия', v('iso'), 'cube'], ['Сверху (Z+)', v('top'), null], ['Спереди', v('front'), null], ['Слева', v('left'), null], ['Справа', v('right'), null],
        '-',
        ['Твёрдое отображение', rm('solid'), null], ['Каркас', rm('wire'), null], ['Рентген', rm('xray'), null],
        '-',
        ['Метки ID: вкл/выкл', function () { window.pcdIdLabelsToggle(); }, null],
        ['DIMINFO: вкл/выкл', function () { window.pcdDimInfoToggle(); }, null],
        ['Касания всех элементов: ' + (showHits ? 'выкл' : 'вкл'), function () { window.pcdHitsToggle(); }, null],
        ['Показать все скрытые' + (nh ? ' (' + nh + ')' : ''), function () { P().hidden = {}; after(); }, null],
        '-',
        ['Вставить автоэлемент: окружность…', function () { window.pcdAutoFeatureOpen('circle'); }, 'circle'],
        ['Вставить автоэлемент: плоскость…', function () { window.pcdAutoFeatureOpen('plane'); }, 'plane'],
        ['Размер: положение…', function () { window.pcdLocationOpen(); }, 'dim']
      ]);
    }
    function hookGfx() {
      var r = G('renderer3'); if (!r || !r.domElement) return false;
      var cv = r.domElement; if (cv.__p58) return true; cv.__p58 = 1;
      cv.addEventListener('mousedown', function (ev) { if (ev.button === 2) cv.__rd58 = [ev.clientX, ev.clientY]; }, true);
      cv.addEventListener('contextmenu', function (ev) {
        if (cv.__rd58 && Math.hypot(ev.clientX - cv.__rd58[0], ev.clientY - cv.__rd58[1]) > 5) return;
        try { if (pickProgramAt(ev.clientX, ev.clientY)) return; } catch (_) {}
        var m = G('stlMesh3');
        if (m && window.THREE) {
          try {
            var rect = cv.getBoundingClientRect(), rc = new THREE.Raycaster(), v = new THREE.Vector2(((ev.clientX - rect.left) / rect.width) * 2 - 1, -((ev.clientY - rect.top) / rect.height) * 2 + 1);
            rc.setFromCamera(v, G('camera3')); if (rc.intersectObject(m, true).length) return; // по модели — меню тел
          } catch (_) {}
        }
        ev.preventDefault(); ev.stopImmediatePropagation(); gfxMenu(ev.clientX, ev.clientY);
      }, true);
      return true;
    }

    /* ---------- запуск ---------- */
    var n = 0;
    (function wait() {
      var a = observe('pcdProgText'), b = observe('pcd25Sum'), c = wrapRebuild(), d = addStrip(), e = hookGfx();
      if (a && b && c && d && e) { redeco(); try { rebuildElementsGroup3(); } catch (_) {} } else if (++n < 120) setTimeout(wait, 500);
    })();
    setInterval(redeco, 2500); // на случай перерисовки без изменения набора строк
    try { var vv = document.querySelector('[title*="Версия приложения"]'); if (vv) { vv.textContent = 'r58'; vv.title = 'Версия приложения (должно быть r58 после перезагрузки)'; } } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else setTimeout(boot, 0);
})();
