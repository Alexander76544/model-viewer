/* pcdmis-cad-objects.js — r66: точный разбор потока объектов PC-DMIS .CAD (дополнение к pcdmis-cad-reader.js)
 * 1) Сегментация: записи { u8 тип, i32 handle (1,2,3… подряд), basic_cad: u64 id, 8 Б, CString } — границы
 *    находятся по следующему handle (проверка: тип из таблицы + маркер строки FF FE FF). 471 405 / 471 405 записей.
 * 2) База: dispattr u16 маска (бит0 цвет ARGB u32 | бит6 индекс i32; бит1 u8 уровень/видимость; бит3 i32; бит2 i32), geom u32.
 * 3) Геометрия (подтверждено на 770.1003014-10_op5.CAD):
 *    line(2):  P1, P2 (6×f64)                      — запись 92 Б
 *    arc(5):   хвост 96 Б: C, N, X, R, a0, a1     — точка = C + R(cos a·X + sin a·(N×X))
 *    PlaneSurface(74):       хвост 72 Б: O, N, X
 *    CylindricalSurface(75): хвост 80 Б: R, O, A, X
 *    SphericalSurface(77):   хвост 80 Б: R, C, A, X
 *    ToroidalSurface(78):    хвост 88 Б: Rбольш, Rмал, C, A, X
 * 4) Топология: EdgeEntity(106): i32 кривая, i32 верш1, i32 верш2; CoedgeEntity(105): i32 ребро, i32 след., i32 цикл, i32 поверхность.
 * API: PcdCadObjects.parse(u8, header) → { recs, lines, arcs, surfaces, edges, coedges, colorOf(handle) } */
(function (root) {
  'use strict';
  function segment(u8, h) {
    var dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength), N = h.nobj, valid = new Uint8Array(256);
    h.typeCount.forEach(function (c, i) { if (c > 0) valid[i] = 1; });
    var start = new Int32Array(N + 2), type = new Uint8Array(N + 2), p = h.objStart, hd = 1;
    function ok(q, hh) { return q >= 0 && q + 24 <= u8.length && valid[u8[q]] && dv.getInt32(q + 1, true) === hh && u8[q + 21] === 0xff && u8[q + 22] === 0xfe && u8[q + 23] === 0xff; }
    if (!ok(p, 1)) throw new Error('первая запись не найдена');
    for (;;) {
      start[hd] = p; type[hd] = u8[p];
      if (hd === N) break;
      var nx = hd + 1, b0 = nx & 255, b1 = (nx >> 8) & 255, b2 = (nx >> 16) & 255, b3 = (nx >>> 24) & 255, q = p + 24, f = -1;
      for (; q + 4 < u8.length; q++) if (u8[q] === b0 && u8[q + 1] === b1 && u8[q + 2] === b2 && u8[q + 3] === b3 && ok(q - 1, nx)) { f = q - 1; break; }
      if (f < 0) throw new Error('потерян объект ' + nx);
      p = f; hd = nx;
    }
    // конец последней записи: маркер 0xFF после неё (ищем вперёд не далее 16 МБ)
    start[N + 1] = Math.min(u8.length, u8.indexOf(0xff, p + 24) > 0 ? u8.length : u8.length);
    return { start: start, type: type, N: N, dv: dv };
  }
  function baseAt(u8, dv, p) {
    var o = { p: p }; p += 21;
    var n = u8[p++], wide = false;
    if (n === 0xff) { n = dv.getUint16(p, true); p += 2; if (n === 0xfffe) { wide = true; n = u8[p++]; if (n === 0xff) { n = dv.getUint16(p, true); p += 2; if (n === 0xffff) { n = dv.getUint32(p, true); p += 4; } } } else if (n === 0xffff) { n = dv.getUint32(p, true); p += 4; } }
    var s = ''; for (var i = 0; i < n; i++) { s += String.fromCharCode(wide ? dv.getUint16(p, true) : u8[p]); p += wide ? 2 : 1; } o.name = s;
    var m = dv.getUint16(p, true); p += 2; o.mask = m;
    if (m & 1) { if (m & 0x40) o.colorIndex = dv.getInt32(p, true); else o.color = dv.getUint32(p, true); p += 4; }
    if (m & 2) { o.attr = u8[p]; p += 1; } if (m & 8) { o.a8 = dv.getInt32(p, true); p += 4; } if (m & 4) { o.a4 = dv.getInt32(p, true); p += 4; }
    o.geom = dv.getUint32(p, true); p += 4; o.body = p; return o;
  }

  // r66d: B-сплайн-кривая (тип 10): u16 nk, f64 knots[nk], u16 flag, u16 nc, f64[3] P[nc], далее хвост (26 байт; у части + nc*8). Степень = nk-nc-1 (на файле всегда 3). Веса пока не учитываются.
  function curveAt(u8, o, h) {
    if (o.type[h] !== 10) return null; o.__cc = o.__cc || {}; if (h in o.__cc) return o.__cc[h];
    var dv = o.__dv || (o.__dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength)), b = baseAt(u8, dv, o.start[h]), e = h < o.N ? o.start[h + 1] : u8.length, p = b.body, r = null;
    var nk = dv.getUint16(p, true); p += 2;
    if (nk >= 8 && p + nk * 8 + 4 <= e) {
      var K = new Float64Array(nk); for (var i = 0; i < nk; i++) { K[i] = dv.getFloat64(p, true); p += 8; }
      // r66j: ReadCount весов (0 — нерациональная) + веса, затем ReadCount точек + точки
      var nw = dv.getUint16(p, true); p += 2; var W = null;
      if (nw > 0 && p + nw * 8 + 2 <= e) { W = new Float64Array(nw); for (i = 0; i < nw; i++) { W[i] = dv.getFloat64(p, true); p += 8; } }
      var nc = dv.getUint16(p, true); p += 2;
      var deg = 0; while (deg + 1 < nk && K[deg + 1] === K[0]) deg++; // степень по кратности первого узла
      if (W && W.length !== nc) W = null;
      if (nc >= 2 && deg >= 1 && nk === nc + deg + 1 && p + nc * 24 <= e) { var P = new Float64Array(nc * 3); for (i = 0; i < nc * 3; i++) { P[i] = dv.getFloat64(p, true); p += 8; } r = { K: K, P: P, W: W, nc: nc, deg: deg }; }
    }
    o.__cc[h] = r; return r;
  }
  function curvePoint(c, t) {
    var p = c.deg, K = c.K, k = p; while (k < c.nc - 1 && t >= K[k + 1]) k++;
    var W = c.W, d = []; for (var j = 0; j <= p; j++) { var q = (k - p + j) * 3, w = W ? W[k - p + j] : 1; d.push([c.P[q] * w, c.P[q + 1] * w, c.P[q + 2] * w, w]); }
    for (var r = 1; r <= p; r++) for (j = p; j >= r; j--) { var i = k - p + j, den = K[i + p - r + 1] - K[i], a = den > 0 ? (t - K[i]) / den : 0; for (var z = 0; z < 4; z++) d[j][z] = (1 - a) * d[j - 1][z] + a * d[j][z]; }
    var ww = d[p][3] || 1; return [d[p][0] / ww, d[p][1] / ww, d[p][2] / ww];
  }
  function curvePoints(c, perSpan) {
    perSpan = perSpan || 6; var K = c.K, out = [], p = c.deg;
    for (var s = p; s < c.nc; s++) { var a = K[s], b = K[s + 1]; if (!(b > a)) continue; for (var j = out.length ? 1 : 0; j <= perSpan; j++) out.push(curvePoint(c, a + (b - a) * j / perSpan)); }
    return out;
  }
  function parse(u8, h) {
    var S = segment(u8, h), dv = S.dv, st = S.start, ty = S.type, N = S.N;
    function d(q) { return dv.getFloat64(q, true); }
    function v(q) { return [d(q), d(q + 8), d(q + 16)]; }
    function end(i) { return i < N ? st[i + 1] : u8.length; }
    var out = { N: N, type: ty, start: st, lines: [], arcs: [], surfaces: {}, edges: {}, coedges: [], colors: new Uint32Array(N + 1), loopFace: {}, loops: {}, verts: {}, shells: {}, bodies: {}, faceSurf: new Int32Array(N + 1), faceBody: new Int32Array(N + 1) };
    out.__u8 = u8;
    var lastEnd = end(N); // для последней записи хвост не используется
    for (var i = 1; i <= N; i++) {
      var t = ty[i], e = end(i), b;
      if (t === 2) { b = baseAt(u8, dv, st[i]); out.lines.push({ h: i, P1: v(b.body), P2: v(b.body + 24) }); }
      else if (t === 5) out.arcs.push({ h: i, C: v(e - 96), N: v(e - 72), X: v(e - 48), R: d(e - 24), a0: d(e - 16), a1: d(e - 8) });
      else if (t === 74) out.surfaces[i] = { k: 'PLANE', O: v(e - 72), N: v(e - 48), X: v(e - 24) };
      else if (t === 75) out.surfaces[i] = { k: 'CYLINDER', R: d(e - 80), O: v(e - 72), A: v(e - 48), X: v(e - 24) };
      else if (t === 77) out.surfaces[i] = { k: 'SPHERE', R: d(e - 80), O: v(e - 72), A: v(e - 48), X: v(e - 24) };
      else if (t === 78) out.surfaces[i] = { k: 'TORUS', Rmaj: d(e - 88), R: d(e - 80), O: v(e - 72), A: v(e - 48), X: v(e - 24) };
      else if (t === 106) { b = baseAt(u8, dv, st[i]); out.edges[i] = { curve: dv.getInt32(b.body, true), v1: dv.getInt32(b.body + 4, true), v2: dv.getInt32(b.body + 8, true) }; }
      else if (t === 105) { b = baseAt(u8, dv, st[i]); out.coedges.push({ h: i, edge: dv.getInt32(b.body, true), next: dv.getInt32(b.body + 4, true), loop: dv.getInt32(b.body + 8, true), surf: dv.getInt32(b.body + 12, true) }); }
      else if (t === 107) { b = baseAt(u8, dv, st[i]); out.verts[i] = v(b.body); }
      else if (t === 104 || t === 102 || t === 101) { // цикл/оболочка/тело: u16 n, i32[n] дети (у цикла далее i32 0, i32 грань)
        b = baseAt(u8, dv, st[i]); var n = dv.getUint16(b.body, true), q = b.body + 2, ch = [];
        if (q + n * 4 <= e) { for (var k = 0; k < n; k++, q += 4) ch.push(dv.getInt32(q, true)); }
        if (t === 104) out.loops[i] = ch;
        if (t === 104) out.loopFace[i] = q + 8 <= e ? dv.getInt32(q + 4, true) : 0;
        else if (t === 102) out.shells[i] = ch; else out.bodies[i] = ch;
      }
      if (t >= 101 && t <= 107) { b = b && b.p === st[i] ? b : baseAt(u8, dv, st[i]); if (b.color != null) out.colors[i] = b.color; }
      b = null;
    }
    // грань → поверхность: коребро.цикл → цикл.грань, коребро.поверхность
    out.coedges.forEach(function (c) { var f = out.loopFace[c.loop]; if (f > 0 && f <= N && ty[f] === 103 && !out.faceSurf[f]) out.faceSurf[f] = c.surf; });
    // грань → тело: грани тела идут в файле перед его оболочкой (список оболочки — для проверки)
    var shellBody = {}; Object.keys(out.bodies).forEach(function (bh) { out.bodies[bh].forEach(function (sh) { shellBody[sh] = +bh; }); });
    // грань → оболочка (список оболочки) → тело (ссылка тела, иначе ближайшая запись BodyEntity после оболочки)
    Object.keys(out.shells).forEach(function (sk) {
      var sh = +sk, bh = shellBody[sh] || 0; if (!bh) for (var j = sh + 1; j <= N; j++) if (ty[j] === 101) { bh = j; break; }
      out.shells[sk].forEach(function (f) { if (f > 0 && f <= N && ty[f] === 103) out.faceBody[f] = bh; });
    });
    return out;
  }
  // точка дуги / окружности
  function arcPoint(a, ang) { var Y = [a.N[1] * a.X[2] - a.N[2] * a.X[1], a.N[2] * a.X[0] - a.N[0] * a.X[2], a.N[0] * a.X[1] - a.N[1] * a.X[0]], c = Math.cos(ang) * a.R, s = Math.sin(ang) * a.R; return [a.C[0] + c * a.X[0] + s * Y[0], a.C[1] + c * a.X[1] + s * Y[1], a.C[2] + c * a.X[2] + s * Y[2]]; }
  root.PcdCadObjects = { curveAt: curveAt, curvePoint: curvePoint, curvePoints: curvePoints, parse: parse, segment: segment, baseAt: baseAt, arcPoint: arcPoint };
})(typeof window !== 'undefined' ? window : globalThis);
