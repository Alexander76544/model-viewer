@echo off
chcp 65001 >nul
rem Перетащите на этот файл .CAD или .PRG (можно несколько)
if "%~1"=="" (echo Перетащите .CAD/.PRG на этот .bat & pause & exit /b)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PCDMIS-CAD-Export.ps1" %*
pause
