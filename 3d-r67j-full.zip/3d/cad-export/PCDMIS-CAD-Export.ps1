﻿<#  r62 — экспорт внутренней CAD-модели PC-DMIS (.CAD) в STEP / IGES / STL
    Использует COM API PC-DMIS из Interop.pcdlrn (managed_cs):
      PartPrograms.OpenRoutine(prg, cad, "OFFLINE")  или  CreateRoutine(tmp.prg, cad, "OFFLINE", "")
      PartProgram.Export(имя.ext)  — формат по расширению, Close()
    Требуется установленный PC-DMIS (лицензия) на этом ПК.
    Запуск:  powershell -ExecutionPolicy Bypass -File PCDMIS-CAD-Export.ps1 файл.CAD|файл.PRG [...] [-Formats stp,igs,stl]
#>
param(
  [Parameter(Mandatory=$true, ValueFromRemainingArguments=$true)][string[]]$Files,
  [string[]]$Formats = @('stp','igs','stl')
)
$ErrorActionPreference = 'Stop'
Write-Host "Подключаюсь к PC-DMIS (PCDLRN.Application)..."
$app = New-Object -ComObject PCDLRN.Application
try { [void]$app.WaitUntilReady(120) } catch {}
$app.Visible = $true

foreach ($f in $Files) {
  $f = (Resolve-Path $f).Path
  $dir = Split-Path $f; $base = [IO.Path]::GetFileNameWithoutExtension($f); $ext = [IO.Path]::GetExtension($f).ToLower()
  $prg = Join-Path $dir ($base + '.PRG'); $cad = Join-Path $dir ($base + '.CAD')
  Write-Host "`n=== $f"
  $pp = $null; $tmp = $null
  try {
    if ((Test-Path $prg) -and (Test-Path $cad)) {
      $pp = $app.PartPrograms.OpenRoutine($prg, $cad, 'OFFLINE')
    } elseif ($ext -eq '.prg') {
      $pp = $app.PartPrograms.Open($prg, 'OFFLINE')
    } else {
      # .CAD без своей .PRG: создаём временную программу с этой моделью
      $tmp = Join-Path $env:TEMP ("cadexp_" + [guid]::NewGuid().ToString('N') + '.PRG')
      $pp = $app.PartPrograms.CreateRoutine($tmp, $cad, 'OFFLINE', '')
    }
    if (-not $pp) { throw 'PC-DMIS не открыл программу' }
    Start-Sleep -Seconds 2
    foreach ($fmt in $Formats) {
      $out = Join-Path $dir ($base + '.' + $fmt)
      $ok = $false
      try { $ok = $pp.Export($out) } catch { Write-Host "  ${fmt}: ошибка $($_.Exception.Message)" }
      if ($ok -and (Test-Path $out)) { Write-Host "  OK  $out ($((Get-Item $out).Length) Б)" }
      else { Write-Host "  --  ${fmt}: PC-DMIS не экспортировал (нет транслятора/лицензии на этот формат)" }
    }
  } catch { Write-Host "  ОШИБКА: $($_.Exception.Message)" }
  finally {
    if ($pp) { try { $pp.Close() } catch {} }
    if ($tmp) { Remove-Item ($tmp -replace '\.PRG$','.*') -ErrorAction SilentlyContinue }
  }
}
Write-Host "`nГотово. Полученные .stp/.igs/.stl откройте в 3D: Файл → Импорт CAD."
