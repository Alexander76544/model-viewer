/* r67f - 3-2-1 по щелчкам на модели (как «Выравнивание 3-2-1» в PC-DMIS):
   3 точки -> LEVEL (плоскость), 2 точки -> ROTATE (линия), 1 точка -> ORIGIN.
   Создаёт элементы + выравнивание VALIGN/3-2-1 и умеет перенести модель в СК детали.
   Координаты: деталь (x,y,z) <-> three.js (x,z,y). */
(function(){
  'use strict';
  var W = (typeof window !== 'undefined') ? window : globalThis;
  var A = { on: false, pts: [], marks: [], lastMatrix: null };
  W.pcdAlign3d = A;
  var STEPS = [['LEVEL',3,'плоскость уровня'],['ROTATE',2,'линия поворота'],['ORIGIN',1,'начало']];
  function say(m){ try { toast(m); } catch(e){ console.log(m); } }
  function hint(){ try { proRenderHint3(); } catch(e){} }
  function g(n){ try { return eval(n); } catch(e){ return null; } } // доступ к let-переменным приложения

  /* ---------- чистая математика (проверяется в node) ---------- */
  function sub(a,b){ return [a[0]-b[0],a[1]-b[1],a[2]-b[2]]; }
  function dot(a,b){ return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]; }
  function crs(a,b){ return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]; }
  function nrm(a){ var l=Math.hypot(a[0],a[1],a[2])||1; return [a[0]/l,a[1]/l,a[2]/l]; }
  /* pts: 6 точек детали, hint: нормаль грани в 1-й точке (для направления). Возвращает СК. */
  A.solve = function(pts, hintN){
    var p1=pts[0],p2=pts[1],p3=pts[2];
    var Z = nrm(crs(sub(p2,p1), sub(p3,p1)));
    if (hintN && dot(Z,hintN) < 0) Z = [-Z[0],-Z[1],-Z[2]];
    var d = sub(pts[4], pts[3]); var X = nrm(sub(d, Z.map(function(v){ return v*dot(d,Z); })));
    var Y = crs(Z, X);
    var c = [(p1[0]+p2[0]+p3[0])/3,(p1[1]+p2[1]+p3[1])/3,(p1[2]+p2[2]+p3[2])/3];
    var o = pts[5];
    // начало: проекция точки начала на плоскость уровня по Z, по X/Y — сама точка
    var hz = dot(sub(o,c),Z), O = [o[0]-Z[0]*hz, o[1]-Z[1]*hz, o[2]-Z[2]*hz];
    return { X:X, Y:Y, Z:Z, O:O, levelC:c, toPart:function(p){ var v=sub(p,O); return [dot(v,X),dot(v,Y),dot(v,Z)]; } };
  };

  /* ---------- 3D: щелчки ---------- */
  function targets(){
    var s = g('scene3'), out = [];
    if (!s) return out;
    s.traverse(function(o){ if (o.isMesh && o.visible && !(o.userData && (o.userData.isFixture || o.userData.p67mark))) out.push(o); });
    var m = g('stlMesh3'); if (m && out.indexOf(m) < 0) out.unshift(m);
    return out;
  }
  function mark(p3, color){
    var T = W.THREE, s = g('scene3'); if (!T || !s) return;
    var r = 2.5; try { var bb = new T.Box3().setFromObject(g('stlMesh3') || s); r = Math.max(1, bb.getSize(new T.Vector3()).length()/250); } catch(e){}
    var m = new T.Mesh(new T.SphereGeometry(r, 12, 8), new T.MeshBasicMaterial({ color: color, depthTest: false }));
    m.renderOrder = 999; m.position.copy(p3); m.userData.p67mark = true; s.add(m); A.marks.push(m); hint();
  }
  function clearMarks(){ var s = g('scene3'); A.marks.forEach(function(m){ s && s.remove(m); m.geometry.dispose(); m.material.dispose(); }); A.marks = []; hint(); }
  function stepInfo(){ var n = A.pts.length, k = 0; for (var i=0;i<STEPS.length;i++){ if (n < k + STEPS[i][1]) return [STEPS[i], n-k+1]; k += STEPS[i][1]; } return null; }
  function banner(){
    var b = document.getElementById('p67alB');
    if (!A.on){ if (b) b.remove(); return; }
    if (!b){ b = document.createElement('div'); b.id = 'p67alB'; b.style.cssText = 'position:fixed;left:50%;top:70px;transform:translateX(-50%);z-index:99990;background:#245a8c;color:#fff;padding:7px 14px;border-radius:6px;font:12px Segoe UI,sans-serif;box-shadow:0 4px 14px rgba(0,0,0,.3)'; document.body.appendChild(b); }
    var si = stepInfo();
    b.innerHTML = '3-2-1 по модели: ' + (si ? '<b>' + si[0][0] + '</b> — ' + si[0][2] + ', точка ' + si[1] + ' из ' + si[0][1] : 'готово') +
      ' &nbsp; <span style="opacity:.75">щёлкните по модели · Backspace — назад · Esc — отмена</span>';
  }
  var down = null;
  function onDown(e){ if (A.on) down = [e.clientX, e.clientY]; }
  function onUp(e){
    if (!A.on || !down) return;
    var moved = Math.hypot(e.clientX-down[0], e.clientY-down[1]); down = null;
    if (moved > 4 || e.button !== 0) return;
    e.stopPropagation(); e.preventDefault();
    var T = W.THREE, cam = g('camera3'), ren = g('renderer3'); if (!T || !cam || !ren) return;
    var r = ren.domElement.getBoundingClientRect();
    var ray = new T.Raycaster(); ray.setFromCamera(new T.Vector2((e.clientX-r.left)/r.width*2-1, -(e.clientY-r.top)/r.height*2+1), cam);
    var hit = ray.intersectObjects(targets(), false)[0];
    if (!hit){ say('Мимо модели'); return; }
    var p = hit.point, n = null;
    if (hit.face){ var nm = new T.Matrix3().getNormalMatrix(hit.object.matrixWorld); var v = hit.face.normal.clone().applyMatrix3(nm).normalize(); n = [v.x, v.z, v.y]; }
    A.pts.push({ p: [p.x, p.z, p.y], n: n });
    var si = A.pts.length; mark(p, si <= 3 ? 0x1e88e5 : si <= 5 ? 0x43a047 : 0xe53935);
    if (A.pts.length >= 6) finish(); else banner();
  }
  function onKey(e){
    if (!A.on) return;
    if (e.key === 'Escape'){ A.stop(); say('3-2-1 отменено'); }
    else if (e.key === 'Backspace'){ e.preventDefault(); A.pts.pop(); var m = A.marks.pop(); if (m){ var s = g('scene3'); s && s.remove(m); hint(); } banner(); }
  }
  A.start = function(){
    var ren = g('renderer3'); if (!ren){ say('Сначала откройте 3D-модель'); try { pcdAct('tab:model'); } catch(e){} return; }
    clearMarks(); A.pts = []; A.on = true;
    if (!A._bound){ ren.domElement.addEventListener('pointerdown', onDown, true); ren.domElement.addEventListener('pointerup', onUp, true);
      ren.domElement.addEventListener('click', function(e){ if (A.on || A._eat){ e.stopPropagation(); e.preventDefault(); A._eat = false; } }, true);
      document.addEventListener('keydown', onKey, true); A._bound = true; }
    banner();
  };
  A.stop = function(){ A.on = false; A._eat = true; setTimeout(function(){ A._eat = false; }, 300); banner(); clearMarks(); };

  function f3(v){ return (Math.round(v*1000)/1000).toFixed(3); }
  function uniq(base){ var s = g('state'), names = {}; ((s && s.elements) || []).forEach(function(e){ names[e.name] = 1; }); var n = base, i = 1; while (names[n]) n = base + '_' + (++i); return n; }
  function mkEl(type, name, xyz, ijk){
    var e = (typeof newElement === 'function') ? newElement(type) : { id: 'e' + Math.random().toString(36).slice(2), type: type };
    e.name = uniq(name); e.x = f3(xyz[0]); e.y = f3(xyz[1]); e.z = f3(xyz[2]);
    if (ijk){ e.i = f3(ijk[0]); e.j = f3(ijk[1]); e.k = f3(ijk[2]); }
    e.group = '3-2-1'; e._from3d = true; return e;
  }
  /* создать элементы и выравнивание из 6 точек (в координатах детали) */
  A.build = function(pts, hintN, proj){
    var cs = A.solve(pts, hintN), p = proj || g('state');
    var pl = mkEl('plane', 'ПЛОСК_УР', cs.levelC, cs.Z); pl.points = '3';
    var mid = [(pts[3][0]+pts[4][0])/2,(pts[3][1]+pts[4][1])/2,(pts[3][2]+pts[4][2])/2];
    var ln = mkEl('line_constructed', 'ЛИН_ПОВ', mid, cs.X);
    var org = mkEl('point', 'ТЧК_НАЧ', cs.O, cs.Z);
    var al = { id: 'a' + Math.random().toString(36).slice(2), name: 'AL321_3D', method: '321', p1: pl.name, p2: ln.name, p3: org.name, cs: cs, from3d: true };
    if (p){
      p.elements = p.elements || []; p.elements.push(pl, ln, org);
      p.alignments = p.alignments || []; var i = p.alignments.findIndex(function(a){ return a && a.name === al.name; });
      if (i >= 0) p.alignments[i] = al; else p.alignments.push(al);
    }
    return { cs: cs, plane: pl, line: ln, origin: org, alignment: al };
  };
  function finish(){
    var hintN = A.pts[0].n, pts = A.pts.map(function(q){ return q.p; });
    var r = A.build(pts, hintN);
    A.on = false; banner();
    try { renderElementsList(); } catch(e){} try { renderOutput(); } catch(e){}
    var cs = r.cs;
    var ok = confirm('Выравнивание AL321_3D создано (' + r.plane.name + ', ' + r.line.name + ', ' + r.origin.name + ').\n' +
      'Начало: ' + cs.O.map(f3).join(', ') + '\nZ: ' + cs.Z.map(f3).join(', ') + '   X: ' + cs.X.map(f3).join(', ') +
      '\n\nПеренести модель в эту систему координат (СК детали)?');
    clearMarks();
    if (ok) A.applyToModel(cs);
  }

  /* перенос модели в СК детали (в координатах three.js), с откатом */
  A.threeMatrix = function(cs){
    var T = W.THREE; function t(v){ return new T.Vector3(v[0], v[2], v[1]); }
    var X = t(cs.X), Y = t(cs.Y), Z = t(cs.Z), O = t(cs.O);
    // новая детальная точка (a,b,c) -> three (a,c,b): строки матрицы = X, Z, Y
    var R = new T.Matrix4().set(X.x,X.y,X.z,0, Z.x,Z.y,Z.z,0, Y.x,Y.y,Y.z,0, 0,0,0,1);
    return R.multiply(new T.Matrix4().makeTranslation(-O.x, -O.y, -O.z));
  };
  A.applyToModel = function(cs){
    var m = g('stlMesh3'); if (!m || !W.THREE){ say('Модель не загружена'); return; }
    var M = A.threeMatrix(cs); A.lastMatrix = M.clone().invert();
    m.applyMatrix4(M); m.updateMatrixWorld(true);
    var fx = W.__pcdFixture && W.__pcdFixture.mesh; if (fx && fx.parent !== m){ fx.matrixAutoUpdate ? fx.applyMatrix4(M) : fx.matrix.premultiply(M); fx.updateMatrixWorld(true); }
    (g('state') && g('state').elements || []).forEach(function(e){
      if (!e || e.x == null) return;
      var q = cs.toPart([+e.x||0, +e.y||0, +e.z||0]); e.x = f3(q[0]); e.y = f3(q[1]); e.z = f3(q[2]);
      if (e.i != null){ var v = [+e.i||0, +e.j||0, +e.k||0]; e.i = f3(dot(v,cs.X)); e.j = f3(dot(v,cs.Y)); e.k = f3(dot(v,cs.Z)); }
    });
    A.lastCs = cs;
    try { renderElementsList(); } catch(e){} try { renderOutput(); } catch(e){} try { __pcdRebuildHits3 && __pcdRebuildHits3(); } catch(e){} try { W.prgHits && W.prgHits.rebuild(); } catch(e){}
    hint(); say('Модель и элементы перенесены в СК детали (отмена: CAD / 3D → Вернуть СК CAD)');
  };
  A.undo = function(){
    var m = g('stlMesh3'); if (!A.lastMatrix || !m){ say('Нечего возвращать'); return; }
    m.applyMatrix4(A.lastMatrix); var fx = W.__pcdFixture && W.__pcdFixture.mesh; if (fx && fx.parent !== m){ fx.matrixAutoUpdate ? fx.applyMatrix4(A.lastMatrix) : fx.matrix.premultiply(A.lastMatrix); fx.updateMatrixWorld(true); }
    var cs = A.lastCs;
    (g('state') && g('state').elements || []).forEach(function(e){
      if (!e || e.x == null) return;
      var a = +e.x||0, b = +e.y||0, c = +e.z||0;
      e.x = f3(cs.O[0]+a*cs.X[0]+b*cs.Y[0]+c*cs.Z[0]); e.y = f3(cs.O[1]+a*cs.X[1]+b*cs.Y[1]+c*cs.Z[1]); e.z = f3(cs.O[2]+a*cs.X[2]+b*cs.Y[2]+c*cs.Z[2]);
      if (e.i != null){ var i = +e.i||0, j = +e.j||0, k = +e.k||0; e.i = f3(i*cs.X[0]+j*cs.Y[0]+k*cs.Z[0]); e.j = f3(i*cs.X[1]+j*cs.Y[1]+k*cs.Z[1]); e.k = f3(i*cs.X[2]+j*cs.Y[2]+k*cs.Z[2]); }
    });
    A.lastMatrix = null; A.lastCs = null;
    try { renderElementsList(); } catch(e){} try { renderOutput(); } catch(e){} try { W.prgHits && W.prgHits.rebuild(); } catch(e){}
    hint(); say('Возвращена СК CAD');
  };

  /* пункты в меню «CAD / 3D» и «Измерение» */
  function addMenu(){
    var sub = document.querySelector('#p67cadMi .sub'); if (!sub) return false;
    if (sub.querySelector('.p67al')) return true;
    function si(t, k, fn){ var s = document.createElement('span'); s.className = 'si p67mi p67al'; s.textContent = t;
      if (k){ var kk = document.createElement('span'); kk.className = 'k'; kk.textContent = k; s.appendChild(kk); }
      s.addEventListener('click', function(ev){ ev.stopPropagation(); document.querySelectorAll('.mi.open').forEach(function(x){ x.classList.remove('open'); }); fn(); }); return s; }
    var hr = document.createElement('hr'); hr.className = 'p67al';
    sub.insertBefore(hr, sub.firstChild);
    sub.insertBefore(si('Вернуть СК CAD', '', A.undo), sub.firstChild);
    sub.insertBefore(si('3-2-1 по модели: 3+2+1 щелчка → СК детали', 'Ctrl+Shift+L', A.start), sub.firstChild);
    var meas = null; document.querySelectorAll('#pcdMenu > .mi').forEach(function(m){ if (/^Измерение/.test(m.textContent)) meas = m; });
    var ms = meas && meas.querySelector('.sub'); if (ms) ms.appendChild(si('🎯 3-2-1 по щелчкам на модели…', 'Ctrl+Shift+L', A.start));
    return true;
  }
  if (typeof document !== 'undefined'){
    var tries = 0, iv = setInterval(function(){ if (addMenu() || ++tries > 40) clearInterval(iv); }, 500);
    document.addEventListener('keydown', function(e){ if (e.ctrlKey && e.shiftKey && e.code === 'KeyL'){ e.preventDefault(); A.start(); } });
  }
  if (typeof module !== 'undefined') module.exports = A;
})();
