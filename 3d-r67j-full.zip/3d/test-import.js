const fs = require('fs');
const { parseRealPrg } = require('./prg-real-import.js');

const files = fs.readdirSync('.').filter(f => f.endsWith('.PRG') || f.endsWith('.prg'));

for (const file of files) {
  console.log('\n==========', file, '==========');
  try {
    const data = fs.readFileSync(file);
    const result = parseRealPrg(data);
    console.log('Header:', result.header);
    console.log('Elements:', result.elements.length);
    console.log('Dimensions:', result.dimensions.length);
    console.log('Stats:', result.stats);
    console.log('Warnings:');
    result.warnings.forEach(w => console.log('  -', w));
    if (result.elements.length > 0) {
      console.log('First element:', JSON.stringify(result.elements[0], null, 2));
    }
  } catch (e) {
    console.error('ERROR:', e.message);
    console.error(e.stack);
  }
}