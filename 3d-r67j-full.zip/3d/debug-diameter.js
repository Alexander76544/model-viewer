const fs = require('fs');
const { cfbStreams, walkRecords, stringsOf, dblAt, dblFromEnd } = require('./prg-real-import.js');

const file = 'E01--缸盖凸轮轴孔.PRG';
const data = fs.readFileSync(file);
const streams = cfbStreams(data);
const part = streams['PARTPROG'];
const recs = walkRecords(part);

console.log('Total records:', recs.length);

const namePattern = /D(\d+(?:\.\d+)?)/i;
let foundElements = 0;

for (let i = 0; i < recs.length; i++) {
  const strs = stringsOf(recs[i]);
  if (!strs.length) continue;
  
  const normStrs = strs.map(s => s.text.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim());
  
  // Check for element name with diameter
  let elName = null, nominalName = null;
  for (const n of normStrs) {
    const mm = namePattern.exec(n);
    if (mm) { elName = n; nominalName = parseFloat(mm[1]); break; }
  }
  
  if (elName) {
    console.log('\nRecord', i, '->', elName);
    console.log('  All strings:', normStrs.join(' | '));
    
    // Check various offsets for diameter
    for (const off of [60, 68, 70, 78, 86, 110, 158, 272, 308, 344, 382]) {
      const v = dblFromEnd(recs[i], off);
      if (v !== null && Math.abs(v) > 0.001 && Math.abs(v) < 5000) {
        console.log(`  End-${off}: ${v}`);
      }
    }
    // Check absolute offsets
    for (const off of [86, 122, 158, 272, 308, 344]) {
      const v = dblAt(recs[i], off);
      if (v !== null && Math.abs(v) > 0.001 && Math.abs(v) < 5000) {
        console.log(`  Abs-${off}: ${v}`);
      }
    }
    foundElements++;
  }
}
console.log('\nTotal elements with diameter in name:', foundElements);