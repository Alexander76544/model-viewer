/* r67g - перемещение оснастки координатами и мышью + закрепление оснастки к детали.
   Смещение в координатах детали: dX, dY, dZ (мм) + поворот вокруг Z (°) вокруг центра оснастки.
   Деталь (x,y,z) <-> three.js (x,z,y).
   Мышь: режим «Двигать мышью» -> тянем оснастку в плоскости XY, с Shift - по Z, с Ctrl - поворот вокруг Z.
   Закрепление: оснастка становится дочерним объектом модели детали и движется вместе с ней
   (3-2-1, «Взять модель», повороты); собственные координаты оснастки при этом заблокированы. */
(function(){
  'use strict';
  var W = (typeof window !== 'undefined') ? window : globalThis;
  function FX(){ return W.__pcdFixture; }
  function g(n){ try { return eval(n); } catch(e){ return null; } }
  function say(m){ try { toast(m); } catch(e){ console.log(m); } }
  function hint(){ try { proRenderHint3(); } catch(e){} }
  function f3(v){ return (Math.round(v*1000)/1000).toFixed(3); }
  var M = { offset: { x:0, y:0, z:0, rz:0 }, step: 1, drag: false, locked: false };
  W.pcdFixtureMove = M;

  /* ---------- матрица смещения в координатах детали (4x4 по строкам), чистая математика ---------- */
  M.partMatrix = function(o, c){
    var a = (o.rz||0)*Math.PI/180, cs = Math.cos(a), sn = Math.sin(a);
    // p' = R(p - c) + c + d
    var tx = c[0] - (cs*c[0] - sn*c[1]) + (o.x||0), ty = c[1] - (sn*c[0] + cs*c[1]) + (o.y||0), tz = (o.z||0);
    return [cs,-sn,0,tx, sn,cs,0,ty, 0,0,1,tz, 0,0,0,1];
  };
  M.applyPart = function(m, p){ return [m[0]*p[0]+m[1]*p[1]+m[2]*p[2]+m[3], m[4]*p[0]+m[5]*p[1]+m[6]*p[2]+m[7], m[8]*p[0]+m[9]*p[1]+m[10]*p[2]+m[11]]; };
  /* то же в three.js: сопряжение перестановкой осей y<->z */
  M.threeMatrix = function(o, c){
    var m = M.partMatrix(o, c), P = [0,2,1];
    var e = new W.THREE.Matrix4(), r = [];
    for (var i=0;i<3;i++){ for (var j=0;j<3;j++) r.push(m[P[i]*4+P[j]]); r.push(m[P[i]*4+3]); }
    e.set(r[0],r[1],r[2],r[3], r[4],r[5],r[6],r[7], r[8],r[9],r[10],r[11], 0,0,0,1);
    return e;
  };

  function mesh(){ var f = FX(); return f && f.mesh; }
  function center(){
    var m = mesh(); if (!m) return [0,0,0];
    var g0 = m.geometry; if (!g0.boundingBox) g0.computeBoundingBox();
    var b = g0.boundingBox; return [(b.min.x+b.max.x)/2, (b.min.z+b.max.z)/2, (b.min.y+b.max.y)/2]; // в детали
  }
  M.apply = function(){
    var m = mesh(); if (!m || !W.THREE) return;
    if (M.locked){ say('Оснастка закреплена к детали — сначала открепите'); return; }
    m.matrixAutoUpdate = false;
    m.matrix.copy(M.threeMatrix(M.offset, center()));
    m.matrixWorldNeedsUpdate = true; m.updateMatrixWorld(true);
    fill(); hint();
  };
  M.set = function(o){ for (var k in o) if (o[k] != null && isFinite(+o[k])) M.offset[k] = +o[k]; M.apply(); };
  M.nudge = function(k, sgn){ var s = k === 'rz' ? (M.step >= 1 ? M.step : 1) : M.step; M.offset[k] = +(M.offset[k] + sgn*s).toFixed(4); M.apply(); };
  M.reset = function(){ M.offset = { x:0, y:0, z:0, rz:0 }; M.apply(); say('Оснастка: исходная укладка'); };

  /* посадить: верх оснастки под низ детали по Z детали (в текущем положении) */
  M.seat = function(){
    var m = mesh(), part = g('stlMesh3'); if (!m || !part){ say('Нужны и деталь, и оснастка'); return; }
    if (M.locked){ say('Оснастка закреплена'); return; }
    var T = W.THREE, bf = new T.Box3().setFromObject(m), bp = new T.Box3().setFromObject(part);
    var dz = bp.min.y - bf.max.y;   // three Y = Z детали
    M.offset.z = +(M.offset.z + dz).toFixed(4); M.apply();
    say('Оснастка поднята под деталь: dZ ' + f3(dz) + ' мм');
  };

  /* ---------- закрепление к детали ---------- */
  M.lock = function(){
    var m = mesh(), part = g('stlMesh3'), s = g('scene3');
    if (!m){ say('Оснастка не загружена'); return; }
    if (!part){ say('Деталь не загружена'); return; }
    if (M.locked) return;
    m.updateMatrixWorld(true);
    var world = m.matrixWorld.clone();
    part.updateMatrixWorld(true);
    var local = part.matrixWorld.clone().invert().multiply(world);
    if (m.parent) m.parent.remove(m);
    part.add(m); m.matrixAutoUpdate = false; m.matrix.copy(local); m.updateMatrixWorld(true);
    M.locked = true; M.drag = false; fill(); hint();
    say('Оснастка закреплена к детали — движется вместе с ней');
  };
  M.unlock = function(){
    var m = mesh(), s = g('scene3'); if (!m || !M.locked) return;
    m.updateMatrixWorld(true);
    var world = m.matrixWorld.clone(), par = m.parent;
    if (par) par.remove(m);
    s.add(m); m.matrixAutoUpdate = false; m.matrix.copy(world); m.updateMatrixWorld(true);
    M.locked = false;
    // пересчитать смещение из итоговой матрицы (если деталь поворачивали только вокруг Z, точно; иначе сохраняем матрицу)
    var e = world.elements, c = center();
    var tilt = Math.abs(e[5] - 1) > 1e-6; // three Y ось должна остаться вертикальной
    if (!tilt){
      var rz = Math.atan2(-e[8], e[0]) * 180 / Math.PI; // поворот вокруг three Y = -rz
      var o = { x:0, y:0, z:0, rz:rz }, base = M.partMatrix(o, c);
      M.offset = { x: +(e[12] - base[3]).toFixed(4), y: +(e[14] - base[7]).toFixed(4), z: +(e[13] - base[11]).toFixed(4), rz: +rz.toFixed(4) };
    }
    fill(); hint(); say('Оснастка откреплена' + (tilt ? ' (деталь была наклонена — положение сохранено как есть)' : ''));
  };
  M.toggleLock = function(){ M.locked ? M.unlock() : M.lock(); };

  /* ---------- мышь ---------- */
  var dr = null;
  function rayAt(e){
    var T = W.THREE, cam = g('camera3'), ren = g('renderer3'); if (!T || !cam || !ren) return null;
    var r = ren.domElement.getBoundingClientRect(), ray = new T.Raycaster();
    ray.setFromCamera(new T.Vector2((e.clientX-r.left)/r.width*2-1, -(e.clientY-r.top)/r.height*2+1), cam);
    return ray;
  }
  function onDown(e){
    if (!M.drag || M.locked || e.button !== 0) return;
    var m = mesh(), ray = rayAt(e); if (!m || !ray) return;
    var hits = []; W.THREE.Mesh.prototype.raycast.call(m, ray, hits); // у оснастки свой raycast отключён
    if (!hits.length) return;
    hits.sort(function(a,b){ return a.distance - b.distance; });
    e.stopImmediatePropagation(); e.preventDefault();
    var T = W.THREE, p = hits[0].point.clone(), mode = e.ctrlKey ? 'rot' : (e.shiftKey ? 'z' : 'xy'), plane;
    if (mode === 'z'){ var cam = g('camera3'), n = new T.Vector3().subVectors(cam.position, p); n.y = 0; if (n.lengthSq() < 1e-9) n.set(1,0,0); plane = new T.Plane().setFromNormalAndCoplanarPoint(n.normalize(), p); }
    else plane = new T.Plane().setFromNormalAndCoplanarPoint(new T.Vector3(0,1,0), p);
    var c = center(), cw = M.applyPart(M.partMatrix(M.offset, c), c);
    dr = { mode: mode, plane: plane, start: p, o0: JSON.parse(JSON.stringify(M.offset)), cw: cw };
    try { (e.target.setPointerCapture && e.pointerId != null) && e.target.setPointerCapture(e.pointerId); } catch(_){}
  }
  function onMove(e){
    if (!dr) return;
    e.stopImmediatePropagation(); e.preventDefault();
    var ray = rayAt(e); if (!ray) return;
    var q = new W.THREE.Vector3(); if (!ray.ray.intersectPlane(dr.plane, q)) return;
    var st = e.altKey ? 0 : M.step; function sn(v){ return st ? Math.round(v/st)*st : +v.toFixed(3); }
    if (dr.mode === 'xy'){ M.offset.x = sn(dr.o0.x + (q.x - dr.start.x)); M.offset.y = sn(dr.o0.y + (q.z - dr.start.z)); }
    else if (dr.mode === 'z'){ M.offset.z = sn(dr.o0.z + (q.y - dr.start.y)); }
    else {
      var a0 = Math.atan2(dr.start.z - dr.cw[1], dr.start.x - dr.cw[0]), a1 = Math.atan2(q.z - dr.cw[1], q.x - dr.cw[0]);
      var d = (a1 - a0) * 180 / Math.PI, s2 = e.altKey ? 0 : Math.max(1, M.step);
      M.offset.rz = s2 ? Math.round((dr.o0.rz + d)/s2)*s2 : +(dr.o0.rz + d).toFixed(3);
    }
    M.apply();
  }
  function onUp(e){ if (!dr) return; e.stopImmediatePropagation(); e.preventDefault(); dr = null; }
  function bind(){
    var ren = g('renderer3'); if (!ren || M._bound) return !!ren;
    var el = ren.domElement;
    ['pointerdown','mousedown'].forEach(function(t){ el.addEventListener(t, function(e){ if (t === 'mousedown' && (dr || M._eatDown)){ e.stopImmediatePropagation(); e.preventDefault(); M._eatDown = false; return; } onDown(e); if (dr) M._eatDown = true; }, true); });
    ['pointermove','mousemove'].forEach(function(t){ el.addEventListener(t, onMove, true); });
    ['pointerup','mouseup'].forEach(function(t){ el.addEventListener(t, onUp, true); });
    el.addEventListener('click', function(e){ if (M._eatClick){ e.stopImmediatePropagation(); M._eatClick = false; } }, true);
    M._bound = true; return true;
  }
  M.setDrag = function(on){
    if (on && M.locked){ say('Оснастка закреплена — сначала открепите'); on = false; }
    if (on && !mesh()){ say('Сначала загрузите оснастку'); on = false; }
    M.drag = !!on; if (on) bind(); fill();
    if (on) say('Тяните оснастку: левая кнопка — X/Y, Shift — Z, Ctrl — поворот, Alt — без шага');
  };

  /* ---------- окно «Положение оснастки» ---------- */
  function fill(){
    var w = document.getElementById('p67fm'); if (!w) return;
    ['x','y','z','rz'].forEach(function(k){ var i = w.querySelector('[data-k="'+k+'"]'); if (i && document.activeElement !== i) i.value = f3(M.offset[k]); i && (i.disabled = M.locked); });
    var d = w.querySelector('[data-b="drag"]'); if (d){ d.textContent = M.drag ? '✋ Мышь: ВКЛ' : '✋ Двигать мышью'; d.style.background = M.drag ? '#cfe3f7' : ''; }
    var l = w.querySelector('[data-b="lock"]'); if (l){ l.textContent = M.locked ? '🔒 Закреплена (открепить)' : '🔓 Закрепить к детали'; l.style.background = M.locked ? '#fde7c8' : ''; }
    w.querySelectorAll('[data-n]').forEach(function(b){ b.disabled = M.locked; });
  }
  M.open = function(){
    if (!mesh()){ var f = FX(); if (f) { say('Сначала загрузите оснастку'); f.pick(); } return; }
    var w = document.getElementById('p67fm');
    if (w){ w.style.display = ''; fill(); return; }
    w = document.createElement('div'); w.id = 'p67fm';
    w.style.cssText = 'position:fixed;right:14px;top:120px;z-index:99980;background:#f0f0f0;border:1px solid #7a8594;box-shadow:0 6px 24px rgba(0,0,0,.3);font:12px Segoe UI,sans-serif;color:#1c2128;width:300px';
    var row = function(k, lab, unit){ return '<div style="display:flex;align-items:center;gap:4px;margin:3px 0"><b style="width:28px">' + lab + '</b>' +
      '<button data-n="' + k + '" data-s="-1">−</button><input data-k="' + k + '" style="width:90px;padding:2px 4px;border:1px solid #9aa4b1;text-align:right">' +
      '<button data-n="' + k + '" data-s="1">+</button><span style="color:#5a6472">' + unit + '</span></div>'; };
    w.innerHTML = '<div id="p67fmT" style="background:linear-gradient(#2f6ea8,#245a8c);color:#fff;padding:5px 8px;font-weight:600;display:flex;justify-content:space-between;cursor:move">Положение оснастки<b data-b="x" style="cursor:pointer">✕</b></div>' +
      '<div style="padding:8px"><div style="color:#5a6472;margin-bottom:4px">Смещение от укладки, СК детали</div>' +
      row('x','dX','мм') + row('y','dY','мм') + row('z','dZ','мм') + row('rz','∠Z','°') +
      '<div style="display:flex;align-items:center;gap:6px;margin:6px 0">Шаг: <select data-b="step"><option>0.01</option><option>0.1</option><option selected>1</option><option>5</option><option>10</option><option>50</option></select>' +
      '<span style="color:#5a6472">(угол — не менее 1°)</span></div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px">' +
      '<button data-b="drag"></button><button data-b="seat" data-n="seat">⬆ Подвести под деталь</button>' +
      '<button data-b="reset" data-n="reset">↩ Исходная укладка</button><button data-b="txt">LOAD_FIXTURE</button>' +
      '<button data-b="lock" style="grid-column:1/3;font-weight:600"></button></div>' +
      '<div style="color:#5a6472;margin-top:6px;line-height:1.35">Мышь: тянуть — X/Y, Shift — Z, Ctrl — поворот, Alt — без шага. Закреплённая оснастка движется вместе с деталью.</div></div>';
    w.querySelectorAll('button').forEach(function(b){ b.style.cssText += ';padding:3px 8px;border:1px solid #8a94a3;background:linear-gradient(#fdfdfd,#e3e6ea);cursor:pointer;font:12px Segoe UI,sans-serif'; });
    document.body.appendChild(w);
    w.querySelectorAll('button[data-s]').forEach(function(b){ b.onclick = function(){ M.nudge(b.getAttribute('data-n'), +b.getAttribute('data-s')); }; });
    w.querySelectorAll('input[data-k]').forEach(function(i){ i.onchange = function(){ var o = {}; o[i.getAttribute('data-k')] = parseFloat(String(i.value).replace(',', '.')); M.set(o); }; i.onkeydown = function(e){ if (e.key === 'Enter') i.onchange(); e.stopPropagation(); }; });
    w.querySelector('[data-b="step"]').onchange = function(){ M.step = +this.value; };
    w.querySelector('[data-b="drag"]').onclick = function(){ M.setDrag(!M.drag); };
    w.querySelector('[data-b="seat"]').onclick = M.seat;
    w.querySelector('[data-b="reset"]').onclick = M.reset;
    w.querySelector('[data-b="txt"]').onclick = function(){ var f = FX(); f && f.exportText(); };
    w.querySelector('[data-b="lock"]').onclick = M.toggleLock;
    w.querySelector('[data-b="x"]').onclick = function(){ w.style.display = 'none'; M.setDrag(false); };
    // перетаскивание окна
    var t = w.querySelector('#p67fmT'), sx, sy, ox, oy;
    t.onmousedown = function(e){ if (e.target.getAttribute('data-b')) return; sx = e.clientX; sy = e.clientY; var r = w.getBoundingClientRect(); ox = r.left; oy = r.top;
      function mv(ev){ w.style.left = (ox + ev.clientX - sx) + 'px'; w.style.top = (oy + ev.clientY - sy) + 'px'; w.style.right = 'auto'; }
      function up(){ document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up); }
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up); };
    fill();
  };

  /* в текст LOAD_FIXTURE добавляем смещение и флаг закрепления */
  function wrapText(){
    var f = FX(); if (!f || f._p67wrap) return !!f;
    var orig = f.pcdmisText;
    f.pcdmisText = function(){
      var o = M.offset;
      return orig.call(f) + '\r\n            COMMENT/DOC,NO,Смещение оснастки: dX ' + f3(o.x) + ', dY ' + f3(o.y) + ', dZ ' + f3(o.z) + ', поворот Z ' + f3(o.rz) + '°' +
        (M.locked ? ', закреплена к детали' : '');
    };
    // при новой загрузке оснастки — сброс смещения и закрепления
    var origRemove = f.remove;
    f.remove = function(){ if (M.locked){ var m = f.mesh; if (m && m.parent) m.parent.remove(m); var s = g('scene3'); if (m && s) s.add(m); M.locked = false; } return origRemove.apply(f, arguments); };
    var lastMesh = null; setInterval(function(){ if (f.mesh && f.mesh !== lastMesh){ lastMesh = f.mesh; M.offset = { x:0, y:0, z:0, rz:0 }; M.locked = false; fill(); } }, 700);
    f._p67wrap = true; return true;
  }

  function addUi(){
    var bar = document.getElementById('p67fxBar');
    if (bar && !bar.querySelector('.p67mv')){
      [['✥ Двигать', 'Положение оснастки: координаты / мышь (Ctrl+Shift+M)', M.open], ['🔒 Закрепить', 'Закрепить / открепить оснастку к детали (Ctrl+Shift+K)', M.toggleLock]].forEach(function(a){
        var b = document.createElement('button'); b.className = 'p67mv'; b.textContent = a[0]; b.title = a[1]; b.onclick = a[2];
        b.style.cssText = 'padding:6px 10px;border-radius:8px;border:1px solid #556;background:#2b3442;color:#e8eef6;cursor:pointer;font:12px sans-serif;';
        bar.appendChild(b); });
    }
    var sub = document.querySelector('#p67cadMi .sub');
    if (sub && !sub.querySelector('.p67mvm')){
      var ref = null; sub.querySelectorAll('.si').forEach(function(s){ if (!ref && /Оснастка: прозрачность/.test(s.textContent)) ref = s; });
      [['Оснастка: двигать (координаты / мышь)…', 'Ctrl+Shift+M', M.open], ['Оснастка: закрепить / открепить от детали', 'Ctrl+Shift+K', M.toggleLock], ['Оснастка: подвести под деталь', '', M.seat]].forEach(function(a){
        var s = document.createElement('span'); s.className = 'si p67mi p67mvm'; s.textContent = a[0];
        if (a[1]){ var k = document.createElement('span'); k.className = 'k'; k.textContent = a[1]; s.appendChild(k); }
        s.addEventListener('click', function(ev){ ev.stopPropagation(); document.querySelectorAll('.mi.open').forEach(function(x){ x.classList.remove('open'); }); a[2](); });
        if (ref) sub.insertBefore(s, ref.nextSibling); else sub.appendChild(s); ref = s; });
    }
    return !!(bar && sub);
  }
  if (typeof document !== 'undefined'){
    var n = 0, iv = setInterval(function(){ var a = wrapText(), b = addUi(); if ((a && b) || ++n > 60) clearInterval(iv); }, 500);
    document.addEventListener('keydown', function(e){
      if (!(e.ctrlKey && e.shiftKey)) return;
      if (e.code === 'KeyM'){ e.preventDefault(); M.open(); } else if (e.code === 'KeyK'){ e.preventDefault(); M.toggleLock(); }
    });
  }
  if (typeof module !== 'undefined') module.exports = M;
})();
