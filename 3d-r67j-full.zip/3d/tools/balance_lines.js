const s = require('fs').readFileSync(process.argv[2], 'utf8');
let line = 1, i = 0, n = s.length, p = 0, b = 0;
let lp = 0, lb = 0; // balance at line start
const marks = [];
while (i < n) {
  const c = s[i];
  if (c === '\n') { line++; lp = p; lb = b; i++; continue; }
  if (c === '"' || c === "'" || c === '`') {
    const q = c; i++;
    while (i < n && s[i] !== q) { if (s[i] === '\\') i++; if (s[i] === '\n') { line++; lp = p; lb = b; } i++; }
    i++; continue;
  }
  if (c === '/' && s[i + 1] === '/') { while (i < n && s[i] !== '\n') i++; continue; }
  if (c === '/' && s[i + 1] === '*') { i += 2; while (i < n && !(s[i] === '*' && s[i + 1] === '/')) { if (s[i] === '\n') { line++; lp = p; lb = b; } i++; } i += 2; continue; }
  if (c === '(') p++;
  if (c === ')') p--;
  if (c === '{') b++;
  if (c === '}') b--;
  i++;
}
// распечатка: строки, где баланс изменился
let line2 = 1, i2 = 0, p2 = 0, b2 = 0, prevp = 0, prevb = 0, startp = 0, startb = 0;
const rows = [];
while (i2 < n) {
  const c = s[i2];
  if (c === '\n') {
    rows.push([line2, p2 - startp, b2 - startb]);
    line2++; startp = p2; startb = b2; i2++; continue;
  }
  if (c === '"' || c === "'" || c === '`') {
    const q = c; i2++;
    while (i2 < n && s[i2] !== q) { if (s[i2] === '\\') i2++; if (s[i2] === '\n') { rows.push([line2, p2 - startp, b2 - startb]); line2++; startp = p2; startb = b2; } i2++; }
    i2++; continue;
  }
  if (c === '/' && s[i2 + 1] === '/') { while (i2 < n && s[i2] !== '\n') i2++; continue; }
  if (c === '/' && s[i2 + 1] === '*') { i2 += 2; while (i2 < n && !(s[i2] === '*' && s[i2 + 1] === '/')) { if (s[i2] === '\n') { rows.push([line2, p2 - startp, b2 - startb]); line2++; startp = p2; startb = b2; } i2++; } i2 += 2; continue; }
  if (c === '(') p2++;
  if (c === ')') p2--;
  if (c === '{') b2++;
  if (c === '}') b2--;
  i2++;
}
// найти участки, где net-баланс строки > 0 и накапливается (кандидаты на незакрытые блоки)
let runP = 0, runB = 0;
for (const [ln, dp, db] of rows) {
  runP += dp; runB += db;
  if ((dp !== 0 || db !== 0) && (ln % 25 === 0 || runB === 1 || runP === 1 || ln < 20 || ln > 600))
    console.log(String(ln).padStart(4), 'dP=' + dp, 'dB=' + db, 'runP=' + runP, 'runB=' + runB);
}
