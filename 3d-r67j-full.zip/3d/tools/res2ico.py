import struct, os, subprocess, json, shutil
b = open('/data/in/res/cs.res', 'rb').read(); o = 0; R = {}
def rd(o):
    if struct.unpack_from('<H', b, o)[0] == 0xFFFF: return struct.unpack_from('<H', b, o + 2)[0], o + 4
    s = ''
    while True:
        ch = struct.unpack_from('<H', b, o)[0]; o += 2
        if ch == 0: break
        s += chr(ch)
    return s, o
while o + 8 <= len(b):
    ds, hs = struct.unpack_from('<II', b, o)
    t, p = rd(o + 8); n, p = rd(p)
    if ds: R[(t, n)] = b[o + hs:o + hs + ds]
    o += hs + ds; o = (o + 3) & ~3
g = R[(14, 2)]; cnt = struct.unpack_from('<H', g, 4)[0]
ents = [struct.unpack_from('<BBBBHHIH', g, 6 + i * 14) for i in range(cnt)]
hdr = struct.pack('<HHH', 0, 1, cnt); dirs = b''; data = b''; off = 6 + 16 * cnt
for w, h, c, r, pl, bc, sz, id_ in ents:
    d = R[(3, id_)]; dirs += struct.pack('<BBBBHHII', w, h, c, r, pl, bc, len(d), off + len(data)); data += d
OUT = '/data/in/fullpkg/3d/pcdmis-assets'
ico = OUT + '/orig/PCDLRN__app.ico'; open(ico, 'wb').write(hdr + dirs + data)
print('frames', [(e[0] or 256, e[5]) for e in ents])
# самый крупный кадр + 16/32/48 для favicon
best = max(range(cnt), key=lambda i: ((ents[i][0] or 256), ents[i][5]))
subprocess.run(['magick', ico + '[%d]' % best, OUT + '/img/PCDLRN__app.png'], check=True)
for sz in (16, 32, 48):
    k = [i for i in range(cnt) if (ents[i][0] or 256) == sz]
    if k: subprocess.run(['magick', ico + '[%d]' % max(k, key=lambda i: ents[i][5]), OUT + '/img/PCDLRN__app%d.png' % sz], check=True)
shutil.copy(ico, '/data/in/fullpkg/3d/favicon.ico')
# диалоги/версия/manifest — в orig для справки
open(OUT + '/orig/PCDLRN__manifest.xml', 'wb').write(R[(24, 1)])
shutil.copy('/data/in/res/cs.rc', OUT + '/orig/PCDLRN__cs.rc')
m = json.load(open(OUT + '/manifest.json'))
m['images'] = [i for i in m['images'] if not i['name'].startswith('PCDLRN__')]
for nm in ['PCDLRN__app', 'PCDLRN__app16', 'PCDLRN__app32', 'PCDLRN__app48']:
    p = OUT + '/img/' + nm + '.png'
    if not os.path.exists(p): continue
    wh = subprocess.run(['magick', 'identify', '-format', '%w %h', p], capture_output=True, text=True).stdout.split()
    m['images'].insert(0, {'name': nm, 'src': 'pcdmis-assets/img/' + nm + '.png', 'orig': 'PCDLRN.exe/cs.res ICON 2', 'cat': 'pcdlrn', 'w': int(wh[0]), 'h': int(wh[1]), 'dups': 0})
json.dump(m, open(OUT + '/manifest.json', 'w'), ensure_ascii=False, indent=0)
open(OUT + '/pcdmis-assets.js', 'w').write('/* Графика PC-DMIS (автосборка tools/assets.py + tools/res2ico.py) */\nwindow.PCD_ASSETS = ' + json.dumps(m, ensure_ascii=False) + ';\n')
print('images', len(m['images']), 'res types', sorted(set(str(k[0]) for k in R)))
