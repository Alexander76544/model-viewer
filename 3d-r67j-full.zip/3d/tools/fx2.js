const fs=require('fs');const {P,TF,o,B}=global.__fx;
const L=JSON.parse(fs.readFileSync('/data/out/fx-bodies.json','utf8'));
const part=L[0];
const seen=new Set(),fix=[],dup=[];
for(const e of L.slice(1)){ if(e.min[1]<880) continue; const k=e.min.join()+e.max.join()+'|'+e.faces; if(seen.has(k)){dup.push(e.bh);continue;} seen.add(k); fix.push(e); }
console.log('part',part.bh,'fixture bodies',fix.length,'dups skipped',dup.length);
function tris(bhs){const out=[];bhs.forEach(bh=>B[bh].tris.forEach(t=>out.push(t)));return out;}
const fixT=tris(fix.map(e=>e.bh)), partT=B[part.bh].tris;
// supports = everything above the plate (min y >= 905)
const sup=fix.filter(e=>e.min[1]>=905);
const smin=[1e9,1e9,1e9],smax=[-1e9,-1e9,-1e9];sup.forEach(e=>{for(let c=0;c<3;c++){smin[c]=Math.min(smin[c],e.min[c]);smax[c]=Math.max(smax[c],e.max[c]);}});
const pc=[(part.min[0]+part.max[0])/2,(part.min[2]+part.max[2])/2], sc=[(smin[0]+smax[0])/2,(smin[2]+smax[2])/2];
const dx=sc[0]-pc[0], dz=sc[1]-pc[1];
// heightmaps (Y up), cell 2 mm, sample triangle vertices + centroids + edge midpoints
const CS=2, hm=new Map(), pm=new Map();
function samp(t,cb){const b=t*9;const v=[[P[b],P[b+1],P[b+2]],[P[b+3],P[b+4],P[b+5]],[P[b+6],P[b+7],P[b+8]]];
 const pts=[v[0],v[1],v[2]];for(let i=1;i<4;i++)for(let j=0;j<=4-i;j++){const k=4-i-j;pts.push([(v[0][0]*i+v[1][0]*j+v[2][0]*k)/4,(v[0][1]*i+v[1][1]*j+v[2][1]*k)/4,(v[0][2]*i+v[1][2]*j+v[2][2]*k)/4]);}
 pts.forEach(cb);}
fixT.forEach(t=>samp(t,p=>{const key=Math.floor(p[0]/CS)+','+Math.floor(p[2]/CS);const h=hm.get(key);if(h===undefined||p[1]>h)hm.set(key,p[1]);}));
partT.forEach(t=>samp(t,p=>{const key=Math.floor((p[0]+dx)/CS)+','+Math.floor((p[2]+dz)/CS);const h=pm.get(key);if(h===undefined||p[1]<h)pm.set(key,p[1]);}));
let gap=1e9,nC=0;for(const [k,y] of pm){const h=hm.get(k);if(h===undefined)continue;nC++;const g=y-h;if(g<gap)gap=g;}
const dy=-gap; // move part down/up so lowest contact touches fixture
let contacts=0;for(const [k,y] of pm){const h=hm.get(k);if(h!==undefined&&Math.abs(y+dy-h)<0.3)contacts++;}
console.log('shift',dx.toFixed(3),dy.toFixed(3),dz.toFixed(3),'overlap cells',nC,'contact cells',contacts);
function stl(file,list,off){const n=list.length;const bb=Buffer.alloc(84+50*n);bb.write('PC-DMIS CAD export r67',0);bb.writeUInt32LE(n,80);let q=84;
 for(const t of list){const b=t*9;const a=[0,1,2].map(k=>[P[b+k*3]+off[0],P[b+k*3+1]+off[1],P[b+k*3+2]+off[2]]);
  const u=[a[1][0]-a[0][0],a[1][1]-a[0][1],a[1][2]-a[0][2]],w=[a[2][0]-a[0][0],a[2][1]-a[0][1],a[2][2]-a[0][2]];let nx=u[1]*w[2]-u[2]*w[1],ny=u[2]*w[0]-u[0]*w[2],nz=u[0]*w[1]-u[1]*w[0];const l=Math.hypot(nx,ny,nz)||1;
  // STL in part axes: CAD (x,y,z) -> (x, -z, y)  i.e. Y-up -> Z-up
  const W=(x,y,z)=>{bb.writeFloatLE(x,q);bb.writeFloatLE(-z,q+4);bb.writeFloatLE(y,q+8);q+=12;};
  W(nx/l,ny/l,nz/l);a.forEach(p=>W(p[0],p[1],p[2]));q+=2;}
 fs.writeFileSync(file,bb);console.log(file,n);}
const D='/data/out/fixture-pkg';fs.mkdirSync(D,{recursive:true});
stl(D+'/osnastka.stl',fixT,[0,0,0]);
stl(D+'/detal-na-osnastke.stl',partT,[dx,dy,dz]);
stl(D+'/sborka-detal+osnastka.stl',fixT.concat(partT.map(t=>t)),[0,0,0]);
// assembly needs shifted part: rewrite properly
{const n=fixT.length+partT.length;const a=fs.readFileSync(D+'/osnastka.stl'),b=fs.readFileSync(D+'/detal-na-osnastke.stl');const out=Buffer.alloc(84+50*n);a.copy(out,0,0,84);out.writeUInt32LE(n,80);a.copy(out,84,84);b.copy(out,84+50*fixT.length,84);fs.writeFileSync(D+'/sborka-detal+osnastka.stl',out);}
const M=[1,0,0,0, 0,1,0,0, 0,0,1,0, dx,-dz,dy,1];
const info={format:'p66-fixture-1',source:'770.1003014-10_op5.CAD',axes:'STL: X=CAD X, Y=-CAD Z, Z=CAD Y (Z — вверх)',
 part:{body:part.bh,triangles:partT.length,bboxCAD:[part.min,part.max]},
 fixture:fix.map(e=>({body:e.bh,triangles:e.n,faces:e.faces,color:'#'+e.col,bboxCAD:[e.min,e.max],role:e.min[1]<905?'плита/основание':'опора/блок'})),
 duplicatesSkipped:dup,
 placement:{method:'центр по опорам + Drop по вертикали',shiftCAD:[+dx.toFixed(4),+dy.toFixed(4),+dz.toFixed(4)],shiftSTL:[+dx.toFixed(4),+(-dz).toFixed(4),+dy.toFixed(4)],matrix4ColumnMajorSTL:M.map(v=>+(+v).toFixed(4)),contactCells2mm:contacts},
 pcdmis:{command:'LOAD_FIXTURE (OBTYPE 172)',line:'FIXTURE: osnastka @ XYZ '+[dx,-dz,dy].map(v=>v.toFixed(4)).join(', ')+' IJK 0, 0, 1'}};
fs.writeFileSync(D+'/osnastka.qfxt.json',JSON.stringify(info,null,1));
console.log(JSON.stringify(info.placement));
