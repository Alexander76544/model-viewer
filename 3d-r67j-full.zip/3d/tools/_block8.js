
/* =====================================================================
   r53 — Модули интерфейса PC-DMIS:
   BestFitAlignment (выравнивание LSQ / 3-2-1) · DatumDef (базы)
   GeometricToleranceView (GDT — рамка допуска) · AutoGdt
   TraceFieldView (поле отклонений) · SettingsView (настройки)
   Оригинальная реализация: открытый синтаксис DMIS (ISO 10360-5)
   и стандартные обозначения GD&T (ASME Y14.5).
   ===================================================================== */
(function(){
"use strict";

/* ---------- helpers ---------- */
function $(id){ return document.getElementById(id); }
function st(){ try{ return (typeof state!=="undefined" && state) ? state : null; }catch(e){ return null; } }
function cur(){ const p=st(); if(!p) throw new Error("нет активной операции"); return p; }
const MEAS = ["plane","cylinder","cone","circle","point_measured"];
function measEls(){ const p=st(); if(!p) return []; return (p.elements||[]).filter(function(e){ return e && e.name && MEAS.indexOf(e.type)>=0; }); }
function elWordRu(e){ var m={plane:"ПЛОСКОСТЬ",cylinder:"ЦИЛИНДР",cone:"КОНУС",circle:"ОКРУЖНОСТЬ",point_measured:"ТОЧКА",point_constructed:"ТОЧКА",line_constructed:"ПРЯМАЯ",circle_constructed:"ОКРУЖНОСТЬ"}; return m[e.type]||"ЭЛТ"; }
function reRender(){
  try{ if(typeof renderElementsList==="function") renderElementsList(); }catch(e){}
  try{ if(typeof renderDimensionsList==="function") renderDimensionsList(); }catch(e){}
  try{ if(typeof refreshStatus==="function") refreshStatus(); }catch(e){}
  try{ if(typeof renderOutput==="function") renderOutput(); }catch(e){}
  try{ if(window.pcdRefreshProg) window.pcdRefreshProg(); }catch(e){}
  try{ if(typeof scheduleAutosave==="function") scheduleAutosave(); }catch(e){}
}
var __toastTimer=null;
function toast(msg){
  var t=$("__pcdToast");
  if(!t){ t=document.createElement("div"); t.id="__pcdToast"; document.body.appendChild(t); }
  t.textContent=msg; t.style.display="block";
  if(__toastTimer) clearTimeout(__toastTimer);
  __toastTimer=setTimeout(function(){ t.style.display="none"; }, 4200);
}
/* toast-стили */
(function(){
  var css = "" +
  "#__pcdToast{position:fixed;right:18px;bottom:44px;z-index:999;background:#10151c;color:#e8ebf0;font-size:12.5px;padding:9px 14px;border-radius:8px;border:1px solid #2f9fe0;box-shadow:0 6px 24px rgba(0,0,0,.45);display:none;max-width:460px;line-height:1.45;font-family:-apple-system,Segoe UI,Roboto,sans-serif;}" +
  ".pcd-dlg-overlay{position:fixed;inset:0;z-index:940;background:rgba(15,20,28,.55);display:flex;align-items:center;justify-content:center;}" +
  ".pcd-dlg{background:#fff;border:1px solid #9aa2ad;border-radius:4px;box-shadow:0 10px 44px rgba(0,0,0,.4);width:780px;max-width:94vw;max-height:90vh;display:flex;flex-direction:column;font-family:-apple-system,Segoe UI,Roboto,sans-serif;font-size:12.5px;color:#1b1f24;}" +
  ".pcd-dlg-hd{display:flex;align-items:center;gap:8px;padding:9px 14px;border-bottom:1px solid #d7dbe0;background:#f0f1f3;border-radius:4px 4px 0 0;font-weight:600;font-size:13px;}" +
  ".pcd-dlg-hd .x{margin-left:auto;cursor:pointer;border:none;background:none;font-size:15px;color:#5b6470;padding:2px 7px;}" +
  ".pcd-dlg-hd .x:hover{color:#c0392b;background:#fdeaea;border-radius:3px;}" +
  ".pcd-dlg-bd{padding:14px;overflow:auto;}" +
  ".pcd-dlg-ft{display:flex;gap:8px;justify-content:flex-end;align-items:center;padding:10px 14px;border-top:1px solid #d7dbe0;background:#f7f8fa;border-radius:0 0 4px 4px;}" +
  ".pcd-dlg .fld{display:flex;flex-direction:column;gap:3px;min-width:0;}" +
  ".pcd-dlg .fld>span{font-size:10.5px;text-transform:uppercase;letter-spacing:.04em;color:#7a828e;}" +
  ".pcd-dlg input[type=text],.pcd-dlg input[type=number],.pcd-dlg select{background:#fff;border:1px solid #b7bdc6;border-radius:3px;padding:4px 7px;font-size:12.5px;color:#1b1f24;outline:none;font-family:Consolas,monospace;}" +
  ".pcd-dlg input:focus,.pcd-dlg select:focus{border-color:#0a6ea8;}" +
  ".pcd-dlg .grid2{display:grid;grid-template-columns:1fr 1fr;gap:10px;}" +
  ".pcd-dlg .grid3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;}" +
  ".pcd-dlg .grid4{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;}" +
  ".pcd-dlg table.t{border-collapse:collapse;width:100%;}" +
  ".pcd-dlg table.t th{font-size:10.5px;text-transform:uppercase;color:#7a828e;text-align:left;padding:4px 6px;border-bottom:1px solid #d7dbe0;font-weight:600;}" +
  ".pcd-dlg table.t td{padding:4px 6px;border-bottom:1px solid #eceef1;vertical-align:middle;}" +
  ".pcd-dlg .chk{display:inline-flex;align-items:center;gap:5px;font-size:12px;cursor:pointer;white-space:nowrap;}" +
  ".pcd-dlg .btn2{display:inline-flex;align-items:center;gap:6px;font-size:12px;padding:6px 12px;border:1px solid #b7bdc6;background:#fff;color:#1b1f24;border-radius:4px;cursor:pointer;}" +
  ".pcd-dlg .btn2:hover{border-color:#0a6ea8;color:#0a6ea8;background:#eaf3f9;}" +
  ".pcd-dlg .btn2.prim{background:#0a6ea8;border-color:#0a6ea8;color:#fff;font-weight:600;}" +
  ".pcd-dlg .btn2.prim:hover{background:#1280bd;}" +
  ".pcd-dlg .btn2.warn:hover{border-color:#c0392b;color:#c0392b;background:#fdeaea;}" +
  ".pcd-dlg .btn2.mini{padding:3px 8px;font-size:11.5px;}" +
  ".pcd-dlg .hint{font-size:11.5px;color:#7a828e;line-height:1.5;margin:8px 0;}" +
  ".pcd-dlg .sect{font-size:10.5px;text-transform:uppercase;letter-spacing:.05em;color:#7a828e;margin:12px 0 6px;font-weight:600;}" +
  ".pcd-fcf{display:inline-table;border-collapse:collapse;font-family:Consolas,monospace;background:#fff;}" +
  ".pcd-fcf td{border:2px solid #1b1f24;padding:3px 12px;text-align:center;font-size:13.5px;font-weight:700;min-width:46px;line-height:1.2;}" +
  ".pcd-fcf td.sym{font-size:17px;font-weight:400;}" +
  ".pcd-fcf td .sub{display:block;font-size:9.5px;font-weight:700;letter-spacing:.05em;}" +
  ".pcd-tr{border-collapse:collapse;font-family:Consolas,monospace;font-size:11.5px;}" +
  ".pcd-tr th,.pcd-tr td{border:1px solid #c9ced5;padding:3px 8px;text-align:right;min-width:64px;}" +
  ".pcd-tr th{background:#f0f1f3;text-align:center;font-weight:600;}" +
  ".pcd-tr td.nm{text-align:left;font-family:inherit;white-space:nowrap;}" +
  ".pcd-tr .ok{background:#e2f4e6;color:#1a7a3a;}" +
  ".pcd-tr .wr{background:#fff4d6;color:#9a6b00;}" +
  ".pcd-tr .er{background:#fde3e1;color:#c0392b;font-weight:700;}" +
  ".pcd-tr .nd{background:#f2f3f5;color:#8a93a0;}";
  var s=document.createElement("style"); s.id="__pcdR53Css"; s.textContent=css; document.head.appendChild(s);
})();

/* ---------- dialog framework ---------- */
function dlg(opts){
  var ov=document.createElement("div"); ov.className="pcd-dlg-overlay";
  var box=document.createElement("div"); box.className="pcd-dlg";
  if(opts.width) box.style.width=opts.width+"px";
  var hd=document.createElement("div"); hd.className="pcd-dlg-hd";
  var tt=document.createElement("span"); tt.textContent=opts.title;
  var x=document.createElement("span"); x.className="x"; x.textContent="✕"; x.title="Закрыть (Esc)";
  hd.appendChild(tt); hd.appendChild(x);
  var bd=document.createElement("div"); bd.className="pcd-dlg-bd";
  if(opts.body) bd.appendChild(opts.body);
  var ft=document.createElement("div"); ft.className="pcd-dlg-ft";
  (opts.footer||[]).forEach(function(f){
    var b=document.createElement("button"); b.className="btn2"+(f.cls?" "+f.cls:""); b.textContent=f.label;
    b.addEventListener("click",function(){ if(f.onClick) f.onClick(box, ft); });
    ft.appendChild(b);
  });
  box.appendChild(hd); box.appendChild(bd); box.appendChild(ft);
  ov.appendChild(box);
  function close(){ try{ ov.remove(); }catch(e){} document.removeEventListener("keydown",onKey,true); }
  function onKey(ev){ if(ev.key==="Escape") close(); }
  ov.addEventListener("mousedown",function(ev){ if(ev.target===ov) close(); });
  document.addEventListener("keydown",onKey,true);
  document.body.appendChild(ov);
  try{ var f0=box.querySelector("input,select,button.btn2.prim"); if(f0) f0.focus(); }catch(e){}
  return { root:ov, box:box, body:bd, close:close };
}
function mk(tag, attrs, html){
  var e=document.createElement(tag);
  if(attrs) Object.keys(attrs).forEach(function(k){ if(k==="class") e.className=attrs[k]; else if(k==="for") e.htmlFor=attrs[k]; else e.setAttribute(k,attrs[k]); });
  if(html!=null) e.innerHTML=html;
  return e;
}
function fld(label, input){
  var w=mk("div",{"class":"fld"}); w.innerHTML=label; w.appendChild(input); return w;
}
function selEl(){ var s=mk("select"); s.appendChild(mk("option",{value:""},"—")); measEls().forEach(function(e){ s.appendChild(mk("option",{value:e.name}, elWordRu(e)+" "+e.name)); }); return s; }
/* =====================================================================
   1. ВЫРАВНИВАНИЕ — Best Fit (МНК/LSQ) и 3-2-1  (BestFitAlignment)
   ===================================================================== */
function nextAlignName(){
  var p=cur(); var i=1; var have={};
  (p.alignments||[]).forEach(function(a){ if(a&&a.name) have[a.name]=1; });
  while(have["AL"+i]||have["ВЫРАВ"+i]) i++;
  return "AL"+i;
}
window.pcdAlignOpen=function(){
  var p=cur();
  var els=measEls();
  if(!els.length){ toast("Сначала добавьте измеряемые элементы (Плоскость, Цилиндр, Окружность, Точка…)"); return; }
  p.alignments = p.alignments||[];
  var body=mk("div");
  body.innerHTML =
    '<div class="grid4" style="margin-bottom:10px;">'+
      '<div class="fld"><span>Существующее выравнивание</span><select id="__alSel"></select></div>'+
      '<div class="fld"><span>Имя (в программе)</span><input type="text" id="__alName" maxlength="13"></div>'+
      '<div class="fld"><span>Метод</span><select id="__alMethod">'+
        '<option value="lsq">МНК / Best Fit (LSQ)</option>'+
        '<option value="321">3-2-1 (по целям)</option>'+
      '</select></div>'+
      '<div class="fld" style="justify-content:flex-end;"><button class="btn2" id="__alDel">✕ Удалить выбранное</button></div>'+
    '</div>'+
    '<div class="sect">Фичи для подгонки (МНК) / точки 3-2-1</div>'+
    '<div id="__alFeats" class="grid4" style="margin-bottom:10px;"></div>'+
    '<div class="sect">Ограничения перемещений (МНК; без ограничений — чистая подгонка наименьших квадратов)</div>'+
    '<div class="grid4" style="margin-bottom:10px;">'+
      '<label class="chk"><input type="checkbox" value="TRANSLATION_X"> Смещение X</label>'+
      '<label class="chk"><input type="checkbox" value="TRANSLATION_Y"> Смещение Y</label>'+
      '<label class="chk"><input type="checkbox" value="TRANSLATION_Z"> Смещение Z</label>'+
      '<label class="chk"><input type="checkbox" value="ROTATION_X"> Поворот X</label>'+
      '<label class="chk"><input type="checkbox" value="ROTATION_Y"> Поворот Y</label>'+
      '<label class="chk"><input type="checkbox" value="ROTATION_Z"> Поворот Z</label>'+
    '</div>'+
    '<div id="__alP321" style="display:none;">'+
      '<div class="grid3">'+
        '<div class="fld"><span>Первичная база (A) — точка/элемент</span><select id="__alP1"></select></div>'+
        '<div class="fld"><span>Вторичная (B) — точка/элемент</span><select id="__alP2"></select></div>'+
        '<div class="fld"><span>Третичная (C) — точка/элемент</span><select id="__alP3"></select></div>'+
      '</div>'+
      '<div class="hint">3-2-1: три точки первичной базы задают ориентацию плоскости, одна точка вторичной — поворот, одна точка третичной — фиксацию позиции (классическая установка детали).</div>'+
    '</div>'+
    '<div class="hint">Блок выравнивания выводится в программе <b>после элементов, до размеров</b>: '+
    '<span class="mono">AL1&nbsp;=&nbsp;VALIGN/LSQ,&nbsp;(PL1_1,&nbsp;CYL1_1),&nbsp;(NO_CONSTRAINT)</span> — фичи, попавшие в подгонку, '+
    'оцениваются относительно новой системы координат (best fit по МНК).</div>';
  var sel=$("__alSel"), nameIn=$("__alName"), meth=$("__alMethod"), p321=$("__alP321");
  var featBox=$("__alFeats");
  els.forEach(function(e){
    featBox.appendChild(mk("label",{"class":"chk"},'<input type="checkbox" data-n="'+e.name.replace(/"/g,"&quot;")+'" value="'+e.name.replace(/"/g,"&quot;")+'"> '+elWordRu(e)+' <b>'+e.name+'</b>'));
  });
  ["__alP1","__alP2","__alP3"].forEach(function(id){
    var s=$(id); s.appendChild(mk("option",{value:""},"—"));
    els.forEach(function(e){ s.appendChild(mk("option",{value:e.name}, elWordRu(e)+" "+e.name)); });
  });
  function paintSel(){
    var cur=p.alignments||[];
    sel.innerHTML="";
    sel.appendChild(mk("option",{value:""},"— новое —"));
    cur.forEach(function(a,i){ sel.appendChild(mk("option",{value:String(i)},(a.name||"("+(i+1)+")")+" · "+(a.method==="321"?"3-2-1":"МНК"))); });
  }
  function fill(a){
    paintSel();
    if(a){
      sel.value=String((p.alignments||[]).indexOf(a));
      nameIn.value=a.name||"";
      meth.value=a.method||"lsq";
      var feats={}; (a.features||[]).forEach(function(n){ feats[n]=1; });
      featBox.querySelectorAll("input[type=checkbox]").forEach(function(cb){ cb.checked=!!feats[cb.value]; });
      var cons={}; (a.cons||[]).forEach(function(c){ cons[c]=1; });
      body.querySelectorAll(".grid4 input[value^='TRANSLATION'],.grid4 input[value^='ROTATION']").forEach(function(cb){ cb.checked=!!cons[cb.value]; });
      if(a.method==="321"){ p321.style.display=""; featBox.style.opacity=".45"; meth.value="321";
        $("__alP1").value=a.p1||""; $("__alP2").value=a.p2||""; $("__alP3").value=a.p3||"";
      } else { p321.style.display="none"; featBox.style.opacity="1"; }
    } else {
      nameIn.value=nextAlignName(); meth.value="lsq"; p321.style.display="none"; featBox.style.opacity="1";
      featBox.querySelectorAll("input[type=checkbox]").forEach(function(cb){ cb.checked=false; });
      body.querySelectorAll("input[value^='TRANSLATION'],input[value^='ROTATION']").forEach(function(cb){ cb.checked=false; });
    }
  }
  sel.addEventListener("change",function(){ var i=+sel.value; fill(isNaN(i)?null:(p.alignments||[])[i]); });
  meth.addEventListener("change",function(){ var m=meth.value; p321.style.display=m==="321"?"":"none"; featBox.style.opacity=m==="321"?".45":"1"; });
  $("__alDel").addEventListener("click",function(){
    var i=+sel.value; if(isNaN(i)||i<0||!p.alignments[i]){ toast("Выберите выравнивание из списка"); return; }
    var nm=p.alignments[i].name;
    p.alignments.splice(i,1); fill(null); reRender(); toast("Выравнивание "+nm+" удалено");
  });
  var d=dlg({
    title:"Выравнивание (ALIGNMENT) — Best Fit / 3-2-1", width:720, body:body,
    footer:[
      {label:"Закрыть", cls:"", onClick:function(){ d.close(); }},
      {label:"💾 Сохранить выравнивание", cls:"prim", onClick:function(){
        var name=(nameIn.value||"").trim();
        if(!name){ toast("Укажите имя выравнивания (напр. AL1)"); return; }
        if(name.length>13){ toast("Имя не длиннее 13 символов"); return; }
        var m=meth.value;
        var rec;
        if(m==="321"){
          rec={ id:(typeof uid==="function"?uid():"a"+Math.random().toString(36).slice(2)), name:name, method:"321",
                p1:$("__alP1").value, p2:$("__alP2").value, p3:$("__alP3").value };
          if(!rec.p1){ toast("Для 3-2-1 укажите точку первичной базы (A)"); return; }
        } else {
          var feats=[]; featBox.querySelectorAll("input[type=checkbox]:checked").forEach(function(cb){ feats.push(cb.value); });
          var cons=[]; body.querySelectorAll("input[value^='TRANSLATION'],input[value^='ROTATION']").forEach(function(cb){ if(cb.checked) cons.push(cb.value); });
          if(!feats.length){ toast("Отметьте хотя бы одну фичу для подгонки МНК"); return; }
          rec={ id:(typeof uid==="function"?uid():"a"+Math.random().toString(36).slice(2)), name:name, method:"lsq", features:feats, cons:cons };
        }
        var i=p.alignments.findIndex(function(a){ return a&&a.name===name; });
        if(i>=0) p.alignments[i]=rec; else p.alignments.push(rec);
        fill(rec); reRender(); toast("Выравнивание "+name+" сохранено — блок VALIGN добавлен в программу");
      }}
    ]
  });
  fill(null);
};

/* Блок выравниваний + баз в генерируемой программе (зывается из generateFullProgram) */
window.genAlignAndDatumBlocks=function(proj){
  var out=[];
  (proj.alignments||[]).forEach(function(a){
    if(!a||!a.name) return;
    if(a.method==="321"){
      var pts=[a.p1,a.p2,a.p3].filter(Boolean);
      if(pts.length) out.push(padStr(a.name,13)+"= VALIGN/3-2-1, "+pts.join(", "));
    } else {
      var feats=(a.features||[]).filter(Boolean);
      if(!feats.length) return;
      var cons=(a.cons&&a.cons.length)?("("+a.cons.join(", ")+")"):"(NO_CONSTRAINT)";
      out.push(padStr(a.name,13)+"= VALIGN/LSQ, ("+feats.join(", ")+"), "+cons);
    }
  });
  (proj.datums||[]).forEach(function(dm){
    if(!dm||!dm.letter||!dm.feature) return;
    var t="// ДАТУМ "+dm.letter+" = "+(dm.kind||"")+" "+dm.feature;
    if(dm.sec) t+=" (вторич.: "+dm.sec+")";
    if(dm.ter) t+=" (третич.: "+dm.ter+")";
    out.push(t);
  });
  return out.join("\n");
};

/* =====================================================================
   2. БАЗЫ (DATUM) — определение баз A–F  (DatumDefView)
   ===================================================================== */
var DATUM_KINDS=["ПЛОСКОСТЬ","ОСЬ","ТОЧКА","ЛИНИЯ"];
window.pcdDatumOpen=function(){
  var p=cur();
  var els=measEls();
  if(!els.length){ toast("Сначала добавьте измеряемые элементы (Плоскость, Цилиндр, Окружность, Точка…)"); return; }
  p.datums=p.datums||[];
  var body=mk("div");
  body.innerHTML=
    '<table class="t" id="__dmT"><thead><tr>'+
    '<th style="width:52px;">База</th><th>Фича (измеряемый элемент)</th><th style="width:110px;">Вид</th>'+
    '<th>Вторичная (фича)</th><th>Третичная (фича)</th><th style="width:34px;"></th></tr></thead><tbody></tbody></table>'+
    '<div style="margin-top:10px;display:flex;gap:8px;">'+
      '<button class="btn2" id="__dmAdd">＋ Строка базы</button>'+
      '<button class="btn2 prim" id="__dm321">🎯 Создать выравнивание 3-2-1 из баз A/B/C</button>'+
    '</div>'+
    '<div class="hint">База (datum) — элемент детали, относительно которого задаются допуски GD&amp;T. Определяйте A (первичная), B (вторичная), C (третичная) — '+
    'диалог GDT подставит буквы баз в рамку допуска, а кнопка 3-2-1 создаст выравнивание установки детали. '+
    'В программу базы выводятся строками <span class="mono">// ДАТУМ A = ОСЬ CYL1_1</span>.</div>';
  var tb=body.querySelector("tbody");
  function featSel(){ var s=mk("select"); s.appendChild(mk("option",{value:""},"—")); els.forEach(function(e){ s.appendChild(mk("option",{value:e.name}, elWordRu(e)+" "+e.name)); }); return s; }
  function addRow(dm){
    dm=dm||{id:(typeof uid==="function"?uid():"d"+Math.random().toString(36).slice(2)), letter:"", feature:"", kind:"ПЛОСКОСТЬ", sec:"", ter:""};
    var tr=mk("tr");
    var tdL=mk("td"); var inL=mk("input",{type:"text",maxlength:"1",style:"width:44px;text-transform:uppercase;"}); inL.value=dm.letter||""; tdL.appendChild(inL);
    var tdF=mk("td"); var sF=featSel(); sF.value=dm.feature||""; tdF.appendChild(sF);
    var tdK=mk("td"); var sK=mk("select"); DATUM_KINDS.forEach(function(k){ sK.appendChild(mk("option",{value:k},k)); }); sK.value=dm.kind||"ПЛОСКОСТЬ"; tdK.appendChild(sK);
    var tdS=mk("td"); var sS=featSel(); sS.value=dm.sec||""; tdS.appendChild(sS);
    var tdT=mk("td"); var sT=featSel(); sT.value=dm.ter||""; tdT.appendChild(sT);
    var tdX=mk("td"); var bx=mk("button",{"class":"btn2 mini warn",title:"Удалить строку"},"✕");
    bx.addEventListener("click",function(){ tr.remove(); });
    tdX.appendChild(bx);
    tr.__get=function(){ return { id:dm.id, letter:(inL.value||"").trim().toUpperCase().slice(0,1), feature:sF.value, kind:sK.value, sec:sS.value, ter:sT.value }; };
    tr.appendChild(tdL); tr.appendChild(tdF); tr.appendChild(tdK); tr.appendChild(tdS); tr.appendChild(tdT); tr.appendChild(tdX);
    tb.appendChild(tr);
    return tr;
  }
  if(!p.datums.length) addRow({letter:"A"});
  else p.datums.forEach(function(dm){ addRow(dm); });
  $("__dmAdd").addEventListener("click",function(){
    var used={}; tb.querySelectorAll("input").forEach(function(i){ if(i.value) used[i.value.toUpperCase()]=1; });
    var L="A"; while(used[L]) L=String.fromCharCode(L.charCodeAt(0)+1);
    addRow({letter:L});
  });
  $("__dm321").addEventListener("click",function(){
    var rows=[]; tb.querySelectorAll("tr").forEach(function(tr){ rows.push(tr.__get()); });
    var A=null,B=null,C=null;
    rows.forEach(function(r){ if(!r.letter) return; if(r.letter==="A"&&!A&&r.feature) A=r; if(r.letter==="B"&&!B&&r.feature) B=r; if(r.letter==="C"&&!C&&r.feature) C=r; });
    if(!A){ toast("Для 3-2-1 определите базу A с фичей"); return; }
    var nm=nextAlignName();
    var rec={ id:(typeof uid==="function"?uid():"a"+Math.random().toString(36).slice(2)), name:nm, method:"321",
      p1:A.feature, p2:(B&&(B.feature||B.sec))||"", p3:(C&&(C.feature||C.sec||C.ter))||"" };
    p.alignments=p.alignments||[];
    var i=p.alignments.findIndex(function(x){ return x&&x.name===nm; });
    if(i>=0) p.alignments[i]=rec; else p.alignments.push(rec);
    reRender(); toast("Создано выравнивание 3-2-1: "+nm+" (A="+A.feature+(rec.p2?", B="+rec.p2:"")+(rec.p3?", C="+rec.p3:"")+")");
  });
  var d=dlg({
    title:"Определение баз (DATUM REFERENCE)", width:860, body:body,
    footer:[
      {label:"Закрыть", cls:"", onClick:function(){ d.close(); }},
      {label:"💾 Сохранить базы", cls:"prim", onClick:function(){
        var out=[], seen={};
        tb.querySelectorAll("tr").forEach(function(tr){
          var r=tr.__get();
          if(!r.letter && !r.feature) return;               // пустая строка
          if(!r.letter){ toast("Каждая база нужна буква (A, B, C…)"); return; }
          if(!r.feature){ toast("У базы "+r.letter+" не выбрана фича"); return; }
          if(seen[r.letter]){ toast("Базы "+r.letter+" дублируется — оставьте одну строку"); return; }
          seen[r.letter]=1; out.push(r);
        });
        out.sort(function(a,b){ return a.letter<b.letter?-1:1; });
        p.datums=out; reRender(); toast("Сохранено баз: "+out.length+" ("+out.map(function(r){return r.letter;}).join(", ")+")");
        d.close();
      }}
    ]
  });
};
/* =====================================================================
   3. GDT — РАМКА ДОПУСКА (FEATURE CONTROL FRAME)  (GeometricToleranceView)
   ===================================================================== */
var GDT_CHARS=["ПОЗИЦИЯ","ПАРАЛЛЕЛЬНОСТЬ","ПЕРПЕНДИКУЛЯРНОСТЬ","УГОЛ","НАКЛОН","СООСНОСТЬ","КОНЦЕНТРИЧНОСТЬ","СИММЕТРИЧНОСТЬ","РАДИАЛЬНОЕ БИЕНИЕ","АКСИАЛЬНОЕ БИЕНИЕ","ЦЕЛОСТНОЕ БИЕНИЕ","ПРЯМОЛИНЕЙНОСТЬ","ЦИЛИНДРИЧНОСТЬ","КРУГЛОСТЬ","ПЛОСКОСТНОСТЬ","ФОРМА"];
var GDT_SYM={"ПОЗИЦИЯ":"◎","ПАРАЛЛЕЛЬНОСТЬ":"∥","ПЕРПЕНДИКУЛЯРНОСТЬ":"⊥","УГОЛ":"∠","НАКЛОН":"∠","СООСНОСТЬ":"⊚","КОНЦЕНТРИЧНОСТЬ":"⊙","СИММЕТРИЧНОСТЬ":"≡","РАДИАЛЬНОЕ БИЕНИЕ":"⌒","АКСИАЛЬНОЕ БИЕНИЕ":"⌒","ЦЕЛОСТНОЕ БИЕНИЕ":"⌒","ПРЯМОЛИНЕЙНОСТЬ":"―","ЦИЛИНДРИЧНОСТЬ":"∅","КРУГЛОСТЬ":"○","ПЛОСКОСТНОСТЬ":"▱","ФОРМА":"⌒"};
var GDT_ABBR={"ПОЗИЦИЯ":"POZ","ПАРАЛЛЕЛЬНОСТЬ":"PAR","ПЕРПЕНДИКУЛЯРНОСТЬ":"PERP","УГОЛ":"ANG","НАКЛОН":"ANG","СООСНОСТЬ":"COAX","КОНЦЕНТРИЧНОСТЬ":"CONC","СИММЕТРИЧНОСТЬ":"SYM","РАДИАЛЬНОЕ БИЕНИЕ":"RRO","АКСИАЛЬНОЕ БИЕНИЕ":"ARO","ЦЕЛОСТНОЕ БИЕНИЕ":"TRO","ПРЯМОЛИНЕЙНОСТЬ":"STRT","ЦИЛИНДРИЧНОСТЬ":"CYLC","КРУГЛОСТЬ":"CIRC","ПЛОСКОСТНОСТЬ":"FLAT","ФОРМА":"PROF"};
/* характеристики, для которых допуск — цилиндрическая зона (∅) */
var GDT_DIAM_OK={"ПОЗИЦИЯ":1,"СООСНОСТЬ":1,"КОНЦЕНТРИЧНОСТЬ":1,"ЦИЛИНДРИЧНОСТЬ":1,"КРУГЛОСТЬ":1,"ПЛОСКОСТНОСТЬ":1,"ФОРМА":1,"РАДИАЛЬНОЕ БИЕНИЕ":1,"АКСИАЛЬНОЕ БИЕНИЕ":1,"ЦЕЛОСТНОЕ БИЕНИЕ":1};
/* характеристики, где применяются модификаторы состояния материала */
var GDT_MOD_OK={"ПОЗИЦИЯ":1,"ПАРАЛЛЕЛЬНОСТЬ":1,"ПЕРПЕНДИКУЛЯРНОСТЬ":1,"УГОЛ":1,"НАКЛОН":1,"СООСНОСТЬ":1,"КОНЦЕНТРИЧНОСТЬ":1,"СИММЕТРИЧНОСТЬ":1,"РАДИАЛЬНОЕ БИЕНИЕ":1,"АКСИАЛЬНОЕ БИЕНИЕ":1,"ЦЕЛОСТНОЕ БИЕНИЕ":1};
var REL_GDT={"ПАРАЛЛЕЛЬНОСТЬ":1,"ПЕРПЕНДИКУЛЯРНОСТЬ":1,"УГОЛ":1,"НАКЛОН":1,"СООСНОСТЬ":1,"КОНЦЕНТРИЧНОСТЬ":1,"СИММЕТРИЧНОСТЬ":1,"РАДИАЛЬНОЕ БИЕНИЕ":1,"АКСИАЛЬНОЕ БИЕНИЕ":1,"ЦЕЛОСТНОЕ БИЕНИЕ":1,"ПОЗИЦИЯ":1};
function gdtAxesFor(type, tol, dec){
  var t=(+tol).toFixed(dec);
  var num=function(v){ return v; };
  if(type==="ПОЗИЦИЯ") return [
    {id:(typeof uid==="function"?uid():"g"+Math.random().toString(36).slice(2)), axis:"X", nominal:"0", plusTol:num("+"+t), minusTol:num("-"+t)},
    {id:(typeof uid==="function"?uid():"g"+Math.random().toString(36).slice(2)), axis:"Y", nominal:"0", plusTol:num("+"+t), minusTol:num("-"+t)},
    {id:(typeof uid==="function"?uid():"g"+Math.random().toString(36).slice(2)), axis:"Z", nominal:"0", plusTol:num("+"+t), minusTol:num("-"+t)}
  ];
  if(type==="УГОЛ"||type==="НАКЛОН") return [
    {id:(typeof uid==="function"?uid():"g"+Math.random().toString(36).slice(2)), axis:"D", nominal:"0", plusTol:num("+"+t), minusTol:num("-"+t)}
  ];
  return [
    {id:(typeof uid==="function"?uid():"g"+Math.random().toString(36).slice(2)), axis:"D", nominal:"0", plusTol:num(t), minusTol:num("0")}
  ];
}
function gdtAutoName(type, feat, p){
  var base=(GDT_ABBR[type]||"GDT")+"_"+feat;
  var nm=base, i=2;
  while((p.dimensions||[]).some(function(d){ return d&&d.name===nm; })) nm=base+"_"+i++;
  return nm;
}
function datumOptions(p){
  var opts=[{v:"",t:"—"}];
  (p.datums||[]).forEach(function(dm){ if(dm&&dm.letter) opts.push({v:dm.letter,t:dm.letter+" · "+(dm.kind||"")+" "+dm.feature}); });
  for(var c=65;c<=70;c++){ var L=String.fromCharCode(c); if(!opts.some(function(o){return o.v===L;})) opts.push({v:L,t:L}); }
  return opts;
}
window.pcdGdtOpen=function(){
  var p=cur();
  var els=measEls();
  if(!els.length){ toast("Сначала добавьте измеряемые элементы — GDT-допуск привязывается к фиче"); return; }
  var body=mk("div");
  var charSel=mk("select"); GDT_CHARS.forEach(function(c){ charSel.appendChild(mk("option",{value:c},c); });
  var featSel=selEl();
  var refSel=selEl();
  var tolIn=mk("input",{type:"text",placeholder:"0.1",style:"width:90px;"}); tolIn.value="0.1";
  var diaChk=mk("input",{type:"checkbox"}); diaChk.checked=true;
  var modSel=mk("select"); [["","— (без модификатора)"],["ММБ","ММБ (MMC)"],["ЛНМ","ЛНМ (LMC)"],["ЛМБ","ЛМБ (LCB)"]].forEach(function(o){ modSel.appendChild(mk("option",{value:o[0]},o[1])); });
  var dSel=[]; for(var i=1;i<=3;i++){ var s=mk("select"); datumOptions(p).forEach(function(o){ s.appendChild(mk("option",{value:o.v},o.t)); }); dSel.push(s); }
  var totChk=mk("input",{type:"checkbox"});
  var nameIn=mk("input",{type:"text",maxlength:"20",style:"width:200px;"});
  var fcf=mk("div",{"class":"sect"},"Предпросмотр рамки допуска (Feature Control Frame)");
  var fcfBox=mk("div",{style:"margin:4px 0 12px;min-height:64px;"});
  var grid1=mk("div",{class:"grid4"});
  grid1.appendChild(fld("Характеристика", charSel));
  grid1.appendChild(fld("Фича (элемент)", featSel));
  grid1.appendChild(fld("Относительная фича (для относительных типов)", refSel));
  grid1.appendChild(fld("Имя размера", nameIn));
  body.appendChild(grid1);
  var row2=mk("div",{class:"grid4"});
  var tolWrap=mk("div",{style:"display:flex;gap:8px;align-items:center;"});
  var diaLbl=mk("label",{"class":"chk",title:"Цилиндрическая зона (∅)"},'∅ диаметр.');
  diaLbl.appendChild(diaChk); tolWrap.appendChild(diaLbl); tolWrap.appendChild(tolIn);
  row2.appendChild(fld("Допуск (значение)", tolWrap));
  row2.appendChild(fld("Модификатор (ММБ/ЛНМ)", modSel));
  row2.appendChild(fld("База 1", dSel[0]));
  var b23=mk("div",{style:"display:flex;gap:6px;"}); b23.appendChild(dSel[1]); b23.appendChild(dSel[2]);
  row2.appendChild(fld("База 2 / База 3", b23));
  body.appendChild(row2);
  var row3=mk("div",{style:"margin-top:10px;display:flex;gap:18px;align-items:center;"});
  var totLbl=mk("label",{"class":"chk"},'TOTALER (позиция)'); totLbl.appendChild(totChk);
  row3.appendChild(totLbl);
  body.appendChild(row3);
  body.appendChild(fcf); body.appendChild(fcfBox);
  body.appendChild(mk("div",{class:"hint"},
    "Рамка: символ характеристики · допуск (∅ — цилиндрическая зона) с модификатором состояния материала · буквы баз. "+
    "Созданный размер попадает на вкладку «Размеры» и в генерируемую программу: "+
    "<span class=\"mono\">РАЗМ. POZ_CYL1_1= ПОЗИЦИЯ ЦИЛИНДР CYL1_1 ∅ ДАТУМ A B C ММБ UNITS=ММ</span>."));
  function paintFcf(){
    var type=charSel.value, tol=(tolIn.value||"").trim()||"0";
    var dia=!!(diaChk.checked&&GDT_DIAM_OK[type]), mod=modSel.value, tot=totChk.checked&&type==="ПОЗИЦИЯ";
    var ds=[dSel[0].value,dSel[1].value,dSel[2].value];
    var html='<table class="pcd-fcf"><tr>';
    html+='<td class="sym">'+(GDT_SYM[type]||"")+'</td>';
    html+='<td>'+((dia?"∅ ":"")+tol)+'<span class="sub">'+(mod||"")+(tot?" TOTALER":"")+'</span></td>';
    html+='<td>'+(ds[0]||"")+'</td><td>'+(ds[1]||"")+'</td><td>'+(ds[2]||"")+'</td>';
    html+='</tr></table>';
    fcfBox.innerHTML=html;
  }
  function autoName(){ if(!nameIn.__userEdit){ nameIn.value=gdtAutoName(charSel.value, featSel.value||"?", p); } }
  nameIn.addEventListener("input",function(){ nameIn.__userEdit=true; });
  featSel.addEventListener("change",function(){ nameIn.__userEdit=false; autoName(); paintFcf(); });
  charSel.addEventListener("change",function(){
    var type=charSel.value;
    diaChk.disabled=!GDT_DIAM_OK[type]; if(diaChk.disabled) diaChk.checked=false;
    modSel.disabled=!GDT_MOD_OK[type]; if(modSel.disabled) modSel.value="";
    refSel.title=REL_GDT[type]?"Для этого типа укажите относительную фичу (или букву базы в поле «База 1»)":"";
    totChk.disabled=type!=="ПОЗИЦИЯ"; if(type!=="ПОЗИЦИЯ") totChk.checked=false;
    nameIn.__userEdit=false; autoName(); paintFcf();
  });
  [diaChk,tolIn,modSel,totChk,dSel[0],dSel[1],dSel[2]].forEach(function(x){ x.addEventListener("change",paintFcf); x.addEventListener("input",paintFcf); });
  var d=dlg({
    title:"GDT — рамка допуска (Geometric Tolerance)", width:760, body:body,
    footer:[
      {label:"Закрыть", cls:"", onClick:function(){ d.close(); }},
      {label:"＋ Создать размер", cls:"prim", onClick:function(){
        var type=charSel.value, feat=featSel.value;
        if(!feat){ toast("Выберите фичу (элемент), к которому применяется допуск"); return; }
        var tol=(tolIn.value||"").trim();
        if(!(parseFloat(tol.replace(",", "."))>0)){ toast("Укажите значение допуска (> 0)"); return; }
        var dec=4; try{ dec=Math.min(6,Math.max(1,+(p.settings&&p.settings.dec)||3)); }catch(e){}
        var nm=(nameIn.value||"").trim(); if(!nm) nm=gdtAutoName(type,feat,p);
        if((p.dimensions||[]).some(function(x){ return x&&x.name===nm; })){ toast("Размер с именем "+nm+" уже есть"); return; }
        var nd=0; try{ nd=(p.datums||[]).length; }catch(e){}
        if(REL_GDT[type] && !dSel[0].value && !refSel.value){ toast("Для "+type+" нужна база: укажите «База 1» (или относительную фичу)"); return; }
        var ddim=(typeof newDimension==="function")?newDimension():{id:(typeof uid==="function"?uid():"g"+Math.random().toString(36).slice(2)),name:nm,dimType:type,refElement:feat,refElement2:"",axes:[]};
        ddim.name=nm; ddim.dimType=type; ddim.refElement=feat;
        ddim.refElement2=refSel.value||"";
        ddim.diamFlag=!!(diaChk.checked&&GDT_DIAM_OK[type]);
        ddim.mod=modSel.value||"";
        ddim.totaler=!!(totChk.checked&&type==="ПОЗИЦИЯ");
        ddim.datumRef=[dSel[0].value,dSel[1].value,dSel[2].value].filter(Boolean).join(" ");
        var tdec=parseFloat(tol.replace(",", ".")).toFixed(dec);
        ddim.axes=gdtAxesFor(type, tdec, dec);
        p.dimensions=p.dimensions||[]; p.dimensions.push(ddim);
        reRender(); toast("Создан GDT-размер "+nm+" ("+type+(ddim.datumRef?", базы: "+ddim.datumRef:"")+")");
        d.close();
      }}
    ]
  });
  charSel.dispatchEvent(new Event("change"));
  autoName(); paintFcf();
};

/* =====================================================================
   4. АВТО-GDT  (AutoGdt)
   ===================================================================== */
window.pcdAutoGdt=function(){
  var p=cur();
  var els=measEls();
  if(!els.length){ toast("Нет измеряемых элементов — нечего оснащать допусками"); return; }
  var dec=3; try{ dec=Math.min(6,Math.max(1,+(p.settings&&p.settings.dec)||3)); }catch(e){}
  var datums=(p.datums||[]).map(function(x){return x&&x.letter;}).filter(Boolean);
  function makeDim(type, el, tol, dia, nDatums){
    var nm=gdtAutoName(type, el.name, p);
    var ddim=(typeof newDimension==="function")?newDimension():{id:uid(),name:nm,dimType:type,refElement:el.name,refElement2:"",axes:[]};
    ddim.name=nm; ddim.dimType=type; ddim.refElement=el.name;
    ddim.diamFlag=!!(dia&&GDT_DIAM_OK[type]);
    ddim.datumRef=datums.slice(0,nDatums||0).join(" ");
    var t=(+tol).toFixed(dec);
    ddim.axes=gdtAxesFor(type, t, dec);
    p.dimensions.push(ddim);
    return ddim;
  }
  var created=0, skipped=0;
  els.forEach(function(el){
    var hasDim=(p.dimensions||[]).some(function(d){ return d&&d.refElement===el.name; });
    if(hasDim){ skipped++; return; }
    if(el.type==="plane"){ makeDim("ПЛОСКОСТНОСТЬ", el, 0.1, true, 0); created++; }
    else if(el.type==="cylinder"){
      if(datums.length>=3) makeDim("ПОЗИЦИЯ", el, 0.2, true, 3);
      else if(datums.length>=1) makeDim("СООСНОСТЬ", el, 0.1, true, datums.length);
      makeDim("КРУГЛОСТЬ", el, 0.02, true, 0);
      created++;
    }
    else if(el.type==="circle"){ makeDim("КРУГЛОСТЬ", el, 0.02, true, 0); created++; }
    else skipped++;
  });
  if(created){ reRender(); toast("Авто-GDT: создано размеров: "+created+(skipped?" · пропущено элементов (уже с допусками/тип не поддерживается): "+skipped:"")); }
  else toast("Авто-GDT: все элементы уже имеют допуски (или типы не поддерживаются: конус, точка)");
};

/* =====================================================================
   5. TRACE FIELD — цветовое поле отклонений  (TraceFieldView)
   ===================================================================== */
var TRACE_AXES=["X","Y","Z","D","DF","M","TP","A"];
window.pcdTraceOpen=function(){
  var p=cur();
  var dims=p.dimensions||[];
  var body=mk("div");
  function paint(){
    var dimsNow=p.dimensions||[];
    var axes={};
    dimsNow.forEach(function(dm){ (dm.axes||[]).forEach(function(a){ if(a&&a.axis) axes[a.axis]=1; }); });
    var axList=TRACE_AXES.filter(function(a){ return axes[a]; });
    var h='<table class="pcd-tr"><tr><th style="text-align:left;">Размер</th>';
    axList.forEach(function(a){ h+='<th>'+a+'</th>'; });
    h+='</tr>';
    var anyData=false;
    h='<div class="sect">Поле отклонений (Trace Field) — операция «'+String(p.name||"").replace(/</g,"&lt;")+'»</div>'+h;
    dimsNow.forEach(function(dm){
      h+='<tr><td class="nm">'+String(dm.name||"").replace(/</g,"&lt;")+(dm.datumRef?' <span style="color:#0a6ea8;">'+dm.datumRef+'</span>':"")+'</td>';
      var byAx={}; (dm.axes||[]).forEach(function(a){ if(a&&a.axis) byAx[a.axis]=a; });
      axList.forEach(function(a){
        var ax=byAx[a];
        if(!ax){ h+='<td class="nd"></td>'; return; }
        var dev=null;
        if(ax.otkl!==undefined&&ax.otkl!==""){ dev=parseFloat(String(ax.otkl).replace(",", ".")); }
        else if(ax.measured!==undefined&&ax.measured!==""){ dev=parseFloat(String(ax.measured).replace(",", "."))-parseFloat(String(ax.nominal||"0").replace(",", ".")); }
        if(!isFinite(dev)){ h+='<td class="nd">—</td>'; return; }
        anyData=true;
        var ptol=Math.abs(parseFloat(String(ax.plusTol||"0").replace(",", ".")));
        var mtol=Math.abs(parseFloat(String(ax.minusTol||"0").replace(",", ".")));
        var tol=Math.max(ptol,mtol);
        var outOfTol = ax.marker!==undefined && String(ax.marker).indexOf("#")>=0;
        var cls="ok";
        if(outOfTol||tol>0&&Math.abs(dev)>tol*2) cls="er";
        else if(tol>0&&Math.abs(dev)>tol) cls="wr";
        h+='<td class="'+cls+'" title="номинал '+ax.nominal+' · +'+ax.plusTol+' / −'+ax.minusTol+' · измерено '+(ax.measured!==undefined?ax.measured:"—")+'">'+dev.toFixed(4)+'</td>';
      });
      h+='</tr>';
    });
    h+='</table>';
    h+='<div class="hint" style="display:flex;gap:14px;align-items:center;flex-wrap:wrap;">'+
      '<span><span style="display:inline-block;width:12px;height:12px;background:#e2f4e6;border:1px solid #b7d9c0;vertical-align:-1px;"></span> в допуске</span>'+
      '<span><span style="display:inline-block;width:12px;height:12px;background:#fff4d6;border:1px solid #e8d5a0;vertical-align:-1px;"></span> вне допуска (≤2T)</span>'+
      '<span><span style="display:inline-block;width:12px;height:12px;background:#fde3e1;border:1px solid #e8b7b3;vertical-align:-1px;"></span> вне допуска / >2T</span>'+
      '<span><span style="display:inline-block;width:12px;height:12px;background:#f2f3f5;border:1px solid #c9ced5;vertical-align:-1px;"></span> нет данных</span>'+
      (anyData?"":"<b>Нет измеренных данных — выполните «Виртуальный прогон» (🎲) или импортируйте результаты (CSV/отчёт).</b>")+'</div>';
    body.innerHTML=h;
  }
  body.innerHTML='<div class="sect">Поле отклонений (Trace Field) — операция «'+String(p.name||"").replace(/</g,"&lt;")+'»</div>';
  paint();
  var d=dlg({
    title:"Trace Field — поле отклонений", width:640, body:body,
    footer:[
      {label:"Обновить", cls:"", onClick:function(){ paint(); }},
      {label:"Закрыть", cls:"prim", onClick:function(){ d.close(); }}
    ]
  });
};

/* =====================================================================
   6. НАСТРОЙКИ  (SettingsView)
   ===================================================================== */
window.pcdSettingsOpen=function(){
  var p=cur();
  p.settings=p.settings||{units:"ММ",dec:3,autosave:true,lang:"ru"};
  var body=mk("div");
  var uSel=mk("select"); [["ММ","Миллиметры (MM)"],["ДЮЙМ","Дюймы (INCH)"]].forEach(function(o){ uSel.appendChild(mk("option",{value:o[0]},o[1])); }); uSel.value=p.settings.units||"ММ";
  var dSel=mk("select"); for(var i2=1;i2<=6;i2++) dSel.appendChild(mk("option",{value:String(i2)},i2+" зн. после запятой")); dSel.value=String(p.settings.dec||3);
  var aChk=mk("input",{type:"checkbox"}); aChk.checked=p.settings.autosave!==false;
  var lSel=mk("select"); [["ru","RU — .txt (русские ключевые слова)"],["en","EN — .prg (английские ключевые слова)"]].forEach(function(o){ lSel.appendChild(mk("option",{value:o[0]},o[1])); }); lSel.value=p.settings.lang||"ru";
  body.appendChild(mk("div",{class:"grid2"},
    fld("Единицы измерения (в строках размеров UNITS=…)", uSel).outerHTML+
    fld("Разрядность для новых допусков", dSel).outerHTML));
  var row=mk("div",{style:"display:flex;gap:20px;margin-top:12px;align-items:flex-start;"});
  var aLbl=mk("label",{"class":"chk"},'вкл.'); aLbl.appendChild(aChk);
  row.appendChild(fld("Автосохранение (localStorage браузера)", aLbl));
  row.appendChild(fld("Язык по умолчанию для «Скачать» (Файл → Скачать .txt)", lSel));
  body.appendChild(row);
  body.appendChild(mk("div",{class:"hint"},
    "Единицы влияют на генерируемые строки размеров (<span class=\"mono\">UNITS=ММ/ИНЧ</span>). "+
    "Разрядность применяется к допускам, создаваемым диалогами GDT и Авто-GDT. "+
    "Настройки сохраняются в каждой операции и попадают в автосохранение."));
  function apply(){
    p.settings.units=uSel.value;
    p.settings.dec=+dSel.value;
    p.settings.autosave=aChk.checked;
    p.settings.lang=lSel.value;
    reRender();
  }
  var d=dlg({
    title:"Настройки (Settings)", width:560, body:body,
    footer:[
      {label:"Закрыть", cls:"", onClick:function(){ d.close(); }},
      {label:"💾 Применить", cls:"prim", onClick:function(){ apply(); toast("Настройки применены"); d.close(); }}
    ]
  });
};

/* ---------- автосохранение: уважаем флажок из настроек ---------- */
(function(){
  if(window.__pcdAutosaveWrapped) return;
  window.__pcdAutosaveWrapped=true;
  var orig=window.scheduleAutosave;
  if(typeof orig!=="function") return;
  window.scheduleAutosave=function(){
    try{ var p=st(); if(p&&p.settings&&p.settings.autosave===false) return; }catch(e){}
    return orig.apply(this, arguments);
  };
})();

/* ---------- кнопки вкладок ---------- */
try{
  var g=$("gdtBtn"); if(g) g.addEventListener("click",function(){ window.pcdGdtOpen(); });
  var ag=$("autoGdtBtn"); if(ag) ag.addEventListener("click",function(){ window.pcdAutoGdt(); });
  var tr=$("traceBtn"); if(tr) tr.addEventListener("click",function(){ window.pcdTraceOpen(); });
}catch(e){}

})();
