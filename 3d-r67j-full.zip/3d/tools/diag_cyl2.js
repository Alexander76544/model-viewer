const fs = require('fs');
const html = fs.readFileSync('C:/Workspace/3d/pcdmis-generator-6.html', 'utf8');
const re = /<script\b([^>]*)>([\s\S]*?)<\/script>/gi;
let m, i = 0, code = '';
while ((m = re.exec(html)) !== null) { i++; if (i === 10) code = m[2]; }
let lastClose = code.lastIndexOf('})();');
let secondLast = code.lastIndexOf('})();', lastClose - 1);
code = code.slice(0, secondLast) + 'window.__dbg={eig3:eig3,covariance:covariance,fitCylinder:fitCylinder};\n' + code.slice(secondLast);
// трассировка итераций fitCylinder
const patch = 'rad/=pts.length;';
const logline = 'rad/=pts.length; console.log("IT",it,"axis="+axis.x.toFixed(3)+","+axis.y.toFixed(3)+","+axis.z.toFixed(3),"oc="+oc.x.toFixed(3)+","+oc.y.toFixed(3)+","+oc.z.toFixed(3),"rad="+rad.toFixed(4),"ciR="+(ci?ci.R.toFixed(4):"null"));';
const idx = code.indexOf(patch);
if (idx < 0) { console.log('PATCH POINT NOT FOUND'); process.exit(1); }
code = code.slice(0, idx) + logline + code.slice(idx + patch.length);

const fakeEl = () => ({ style: {}, setAttribute() {}, appendChild() {}, addEventListener() {}, querySelector() { return null; }, querySelectorAll() { return []; } });
global.window = {};
global.document = { addEventListener() {}, getElementById: () => null, createElement: () => fakeEl(), body: { appendChild() {} }, head: { appendChild() {} } };
eval(code);
const D = global.window.__dbg;

let seed = 999;
function rnd() { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff - 0.5; }
const pts = [];
for (let k = 0; k < 40; k++) {
  const z = -10 + k * (20 / 39);
  for (let a = 0; a < 12; a++) {
    const t = 2 * Math.PI * a / 12;
    pts.push([1 + 5 * Math.cos(t) + rnd() * 0.002, 2 + 5 * Math.sin(t) + rnd() * 0.002, z + rnd() * 0.002]);
  }
}
const r = D.fitCylinder(pts);
console.log('RESULT:', JSON.stringify(r, (k, v) => (typeof v === 'number' ? v.toFixed(4) : v)));
