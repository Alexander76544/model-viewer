const fs = require('fs');
const html = fs.readFileSync('C:/Workspace/3d/pcdmis-generator-6.html', 'utf8');
const re = /<script\b([^>]*)>([\s\S]*?)<\/script>/gi;
let m, i = 0, code = '';
while ((m = re.exec(html)) !== null) { i++; if (i === 10) code = m[2]; }
let lastClose = code.lastIndexOf('})();');
let secondLast = code.lastIndexOf('})();', lastClose - 1);
code = code.slice(0, secondLast) + 'window.__dbg={eig3:eig3,solveLin:solveLin,covariance:covariance,fitCircle2D:fitCircle2D,fitCylinder:fitCylinder,vNorm:vNorm,vCross:vCross,vAdd:vAdd,vSub:vSub,vMul:vMul,vDot:vDot};\n' + code.slice(secondLast);
const fakeEl = () => ({ style: {}, setAttribute() {}, appendChild() {}, addEventListener() {}, querySelector() { return null; }, querySelectorAll() { return []; } });
global.window = {};
global.document = { addEventListener() {}, getElementById: () => null, createElement: () => fakeEl(), body: { appendChild() {} }, head: { appendChild() {} } };
eval(code);
const D = global.window.__dbg;

let seed = 999;
function rnd() { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff - 0.5; }

// Z-цилиндр R=5 через (1,2), h=20
const pts = [];
for (let k = 0; k < 40; k++) {
  const z = -10 + k * (20 / 39);
  for (let a = 0; a < 12; a++) {
    const t = 2 * Math.PI * a / 12;
    pts.push([1 + 5 * Math.cos(t) + rnd() * 0.002, 2 + 5 * Math.sin(t) + rnd() * 0.002, z + rnd() * 0.002]);
  }
}
const cv = D.covariance(pts);
const e = D.eig3(cv.S);
console.log('eigenvalues:', e.values.map(v => v.toFixed(3)));
e.vectors.forEach((v, i) => console.log('evec' + i, v.x.toFixed(4), v.y.toFixed(4), v.z.toFixed(4)));

// проверка: S*v = lambda*v
function evCheck(S, v, lam) {
  const Sv = {
    x: S[0][0] * v.x + S[0][1] * v.y + S[0][2] * v.z,
    y: S[1][0] * v.x + S[1][1] * v.y + S[1][2] * v.z,
    z: S[2][0] * v.x + S[2][1] * v.y + S[2][2] * v.z
  };
  return [Math.abs(Sv.x - lam * v.x), Math.abs(Sv.y - lam * v.y), Math.abs(Sv.z - lam * v.z)];
}
e.vectors.forEach((v, i) => console.log('  check' + i, evCheck(cv.S, v, e.values[i]).map(x => x.toExponential(2)).join(' ')));

const r = D.fitCylinder(pts);
console.log('fitCylinder:', r ? { axis: [r.axis.x, r.axis.y, r.axis.z].map(x => x.toFixed(3)), center: [r.center.x.toFixed(3), r.center.y.toFixed(3), r.center.z.toFixed(3)], R: r.R, h: r.h } : null);
