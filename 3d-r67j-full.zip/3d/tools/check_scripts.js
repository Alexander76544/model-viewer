// Синтаксическая проверка всех <script>-блоков pcdmis-generator-6.html
const fs = require('fs');
const vm = require('vm');
const html = fs.readFileSync(process.argv[2] || 'C:/Workspace/3d/pcdmis-generator-6.html', 'utf8');
const re = /<script\b([^>]*)>([\s\S]*?)<\/script>/gi;
let m, i = 0, errs = 0;
while ((m = re.exec(html)) !== null) {
  i++;
  const attrs = m[1] || '';
  if (/\bsrc\s*=/.test(attrs)) { console.log(`[${i}] external (src) — skip`); continue; }
  const code = m[2];
  try {
    new vm.Script(code, { filename: `block-${i}.js` });
    console.log(`[${i}] OK  (${code.length} chars, starts at offset ${m.index})`);
  } catch (e) {
    errs++;
    console.log(`[${i}] SYNTAX ERROR: ${e.message}`);
    // локализуем строку ошибки
    const mm = /<anonymous>:(\d+)/.exec(e.stack || '') || e.message.match(/:(\d+)/);
  }
}
console.log(errs ? `\n${errs} BLOCK(S) FAILED` : '\nALL SCRIPT BLOCKS OK');
console.log('blocks: ' + i);
process.exit(errs ? 1 : 0);
