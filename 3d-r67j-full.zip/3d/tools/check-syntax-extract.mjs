// syntax-check-extract.mjs — вытащить inline-скрипты из pcdmis-generator-6.html и проверить синтаксис через new Function (без DOM).
// Ищем <script> без src; проверяем синтаксис каждого.
import { readFileSync } from 'node:fs';

const html = readFileSync(process.argv[2] || new URL('../pcdmis-generator-6.html', import.meta.url), 'utf8');

// Разбиваем по <script>...</script> без атрибута src (не трогаем src=...)
const re = /<script\b(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g;
let m; let i = 0; let bad = 0;
while ((m = re.exec(html)) !== null) {
  i++;
  const code = m[1];
  if (!code.trim()) continue;
  try {
    new Function(code);
    console.log(`script #${i}: OK (${code.length} симв.)`);
  } catch (e) {
    bad++;
    console.error(`script #${i}: SYNTAX ERROR — ${e.message}`);
    // Покажем контекст вокруг ошибки: строка в stack-е (col)
    const line = e.message.match(/:\d+:\d+/) ? null : null;
    const pos = String(e).match(/\((\d+):(\d+)\)$/);
    if (pos) {
      const [ln, col] = [parseInt(pos[1]), parseInt(pos[2])];
      const lines = code.split('\n');
      console.error(`  строка ~${ln}: ${lines.slice(Math.max(0,ln-2), ln+2).join('\n').slice(0,400)}`);
    }
  }
}
console.log(`\nИтого скриптов проверено: ${i}, с ошибками: ${bad}`);
process.exit(bad ? 1 : 0);
