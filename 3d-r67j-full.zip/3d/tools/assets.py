import os, re, json, hashlib, subprocess, shutil
SRC = ['/data/in/r_managed_cs/managed_cs', '/data/in/pcdlrn', '/data/in/nc', '/data/in/r_native_c2', '/data/in/r_ghidra_out', '/data/in/gf']
OUT = '/data/in/fullpkg/3d/pcdmis-assets'
shutil.rmtree(OUT, ignore_errors=True); os.makedirs(OUT + '/img'); os.makedirs(OUT + '/orig')
EXT = ('.png', '.ico', '.bmp', '.jpg', '.jpeg', '.gif', '.cur')
seen = {}; items = []
def cat(rel):
    r = rel.lower()
    if '/dimension' in r: return 'dimension'
    if 'strategy' in r or 'toolkitstrateg' in r: return 'strategy'
    if 'launcher' in r: return 'launcher'
    if r.endswith('.ico'): return 'app-icon'
    if 'probe' in r: return 'probe'
    return 'other'
for root in SRC:
    for d, _, fs in os.walk(root):
        for f in fs:
            if not f.lower().endswith(EXT): continue
            p = os.path.join(d, f); b = open(p, 'rb').read()
            h = hashlib.md5(b).hexdigest()[:10]
            rel = os.path.relpath(p, os.path.dirname(root))
            if h in seen: seen[h]['dups'] += 1; continue
            mod = rel.split('/')[1] if rel.count('/') > 1 else rel.split('/')[0]
            base = re.sub(r'[^A-Za-z0-9_.-]+', '_', os.path.splitext(f)[0])[:60]
            name = (re.sub(r'[^A-Za-z0-9_-]+', '_', mod)[:30] + '__' + base).strip('_')
            n0, k = name, 2
            while any(i['name'] == name for i in items): name = n0 + '_' + str(k); k += 1
            o = OUT + '/orig/' + name + os.path.splitext(f)[1].lower(); open(o, 'wb').write(b)
            png = OUT + '/img/' + name + '.png'
            if f.lower().endswith('.png'): shutil.copy(p, png)
            else:
                src = p + ('[0]' if f.lower().endswith(('.gif',)) else '')
                if f.lower().endswith(('.ico', '.cur')):
                    # самый крупный кадр иконки
                    try:
                        idn = subprocess.run(['magick', 'identify', '-format', '%w %p\n', p], capture_output=True, text=True).stdout.split('\n')
                        best = max([l.split() for l in idn if l.strip()], key=lambda x: int(x[0]))[1]; src = p + '[' + best + ']'
                    except Exception: src = p + '[0]'
                r = subprocess.run(['magick', src, png], capture_output=True)
                if r.returncode or not os.path.exists(png):
                    subprocess.run(['convert', src, png], capture_output=True)
            if not os.path.exists(png): continue
            wh = subprocess.run(['magick', 'identify', '-format', '%w %h', png + '[0]'], capture_output=True, text=True).stdout.split()
            it = {'name': name, 'src': 'pcdmis-assets/img/' + name + '.png', 'orig': rel, 'cat': cat(rel), 'w': int(wh[0]) if wh else 0, 'h': int(wh[1]) if len(wh) > 1 else 0, 'dups': 0}
            seen[h] = it; items.append(it)
# ---- векторные иконки из BAML (Path Data) ----
vec = {}; vseen = set()
PATH = re.compile(rb'[MmFf] ?-?[0-9][0-9 ,.\-MmLlHhVvCcSsQqTtAaZzEe]{20,}')
IDENT = re.compile(rb'[A-Za-z_][A-Za-z0-9_.]{2,60}')
for root in SRC:
    for d, _, fs in os.walk(root):
        for f in fs:
            if not f.lower().endswith('.baml'): continue
            p = os.path.join(d, f); b = open(p, 'rb').read()
            for m in PATH.finditer(b):
                s = m.group(0).decode('latin1').strip()
                if s.lower().startswith('m') is False and s[:1] not in 'Ff': continue
                if not re.search(r'[LlCcHhVvAaQqZz]', s): continue
                if s in vseen: continue
                vseen.add(s)
                pre = b[max(0, m.start() - 400):m.start()]
                ids = [x.decode() for x in IDENT.findall(pre) if not x.decode().lower() in ('data', 'path', 'geometry', 'fill', 'stretch', 'uniform', 'width', 'height', 'stroke') and not re.match(r'^(System|Microsoft|PresentationFramework|http)', x.decode())]
                key = ids[-1] if ids else 'path'
                mod = os.path.relpath(p, os.path.dirname(root)).split('/')[1]
                nm = re.sub(r'[^A-Za-z0-9_]+', '_', key)[:50]; n0, k = nm, 2
                while nm in vec: nm = n0 + '_' + str(k); k += 1
                vec[nm] = {'d': s.lstrip('Ff01 ').strip() if s[:1] in 'Ff' else s, 'from': mod + '/' + f}
json.dump({'images': items, 'vectors': vec}, open(OUT + '/manifest.json', 'w'), ensure_ascii=False, indent=0)
open(OUT + '/pcdmis-assets.js', 'w').write('/* Графика PC-DMIS, извлечённая из присланных файлов (автосборка /data/assets.py) */\nwindow.PCD_ASSETS = ' + json.dumps({'images': items, 'vectors': vec}, ensure_ascii=False) + ';\n')
from collections import Counter
print('images', len(items), Counter(i['cat'] for i in items), 'dups', sum(i['dups'] for i in items), 'vectors', len(vec))
print(list(vec.items())[:6])
