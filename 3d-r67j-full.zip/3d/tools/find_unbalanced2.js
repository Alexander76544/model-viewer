const s = require('fs').readFileSync(process.argv[2], 'utf8');
let line = 1, i = 0, n = s.length;
const stack = []; // [type, line]
let desync = -1;
while (i < n) {
  const c = s[i];
  if (c === '\n') line++;
  if (c === '"' || c === "'" || c === '`') {
    const q = c; i++;
    while (i < n && s[i] !== q) { if (s[i] === '\\') i++; if (s[i] === '\n') line++; i++; }
    i++; continue;
  }
  if (c === '/' && s[i + 1] === '/') { while (i < n && s[i] !== '\n') i++; continue; }
  if (c === '/' && s[i + 1] === '*') { i += 2; while (i < n && !(s[i] === '*' && s[i + 1] === '/')) { if (s[i] === '\n') line++; i++; } i += 2; continue; }
  if (c === '{' || c === '(') { stack.push([c, line]); }
  if (c === '}' || c === ')') {
    const want = c === '}' ? '{' : '(';
    if (!stack.length || stack[stack.length - 1][0] !== want) {
      console.log('MISMATCH: found "' + c + '" at line ' + line + ' but top is ' + JSON.stringify(stack.slice(-3)));
      if (desync < 0) desync = line;
    }
    if (stack.length) stack.pop();
  }
  i++;
}
console.log('desync first at line: ' + desync);
console.log('unclosed at EOF: ' + JSON.stringify(stack.slice(-8)));
