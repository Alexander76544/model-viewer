// Проверка математики подгонки (plane/sphere/cylinder) из pcd-r53-mod3
const fs = require('fs');
const html = fs.readFileSync('C:/Workspace/3d/pcdmis-generator-6.html', 'utf8');
const re = /<script\b([^>]*)>([\s\S]*?)<\/script>/gi;
let m, i = 0, code = '';
while ((m = re.exec(html)) !== null) { i++; if (i === 10) code = m[2]; }
if (!code) { console.log('BLOCK 10 NOT FOUND'); process.exit(1); }

// минимальные заглушки DOM
const fakeEl = () => ({ style: {}, setAttribute() {}, appendChild() {}, addEventListener() {}, querySelector() { return null; }, querySelectorAll() { return []; }, classList: { add() {}, remove() {} } });
global.window = {};
global.document = { addEventListener() {}, getElementById: () => null, createElement: () => fakeEl(), body: { appendChild() {} }, head: { appendChild() {} } };
global.navigator = { userAgent: 'node' };

eval(code);

const F = global.window.__pcdFit;
let fails = 0;
function check(name, cond, extra) {
  console.log((cond ? 'PASS' : 'FAIL') + '  ' + name + (extra ? '  ' + extra : ''));
  if (!cond) fails++;
}
// детерминированный шум
let seed = 12345;
function rnd() { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff - 0.5; }

// 1) ПЛОСКОСТЬ z = 2 + 0.5x - 0.25y
{
  const pts = [];
  for (let x = -5; x <= 5; x++) for (let y = -5; y <= 5; y++)
    pts.push([x + rnd() * 0.002, y + rnd() * 0.002, 2 + 0.5 * x - 0.25 * y + rnd() * 0.002]);
  const r = F.plane(pts);
  const n = r.n, d = r.d;
  const len = Math.sqrt(n.x ** 2 + n.y ** 2 + n.z ** 2);
  const nx = n.x / len, ny = n.y / len, nz = n.z / len;
  // нормаль должна быть пропорциональна (0.5, -0.25, -1)
  const ref = [0.5, -0.25, -1];
  const rl = Math.sqrt(ref[0] ** 2 + ref[1] ** 2 + ref[2] ** 2);
  let dot = Math.abs((nx * ref[0] + ny * ref[1] + nz * ref[2]) / rl);
  check('plane normal', dot > 0.999, 'dot=' + dot.toFixed(6) + ' n=(' + nx.toFixed(3) + ',' + ny.toFixed(3) + ',' + nz.toFixed(3) + ')');
  check('plane rms tiny', r.rms < 0.005, 'rms=' + r.rms.toFixed(6));
}
// 2) ЦИЛИНДР: ось Z через (1,2), R=5, h=20
{
  const pts = [];
  for (let k = 0; k < 40; k++) {
    const z = -10 + k * (20 / 39);
    for (let a = 0; a < 12; a++) {
      const t = 2 * Math.PI * a / 12;
      pts.push([1 + 5 * Math.cos(t) + rnd() * 0.002, 2 + 5 * Math.sin(t) + rnd() * 0.002, z + rnd() * 0.002]);
    }
  }
  const r = F.cylinder(pts);
  check('cyl found', !!r);
  if (r) {
    const alen = Math.sqrt(r.axis.x ** 2 + r.axis.y ** 2 + r.axis.z ** 2);
    const az = Math.abs(r.axis.z / alen);
    check('cyl axis ~Z', az > 0.999, 'az=' + az.toFixed(6));
    check('cyl R=5', Math.abs(r.R - 5) < 0.01, 'R=' + r.R.toFixed(5));
    check('cyl center x=1,y=2', Math.abs(r.center.x - 1) < 0.05 && Math.abs(r.center.y - 2) < 0.05, 'c=(' + r.center.x.toFixed(3) + ',' + r.center.y.toFixed(3) + ')');
    check('cyl h=20', Math.abs(r.h - 20) < 0.5, 'h=' + r.h.toFixed(3));
    check('cyl rms tiny', r.rms < 0.01, 'rms=' + r.rms.toFixed(6));
  }
}
// 3) СФЕРА: R=10, центр (3,4,5)
{
  const pts = [];
  for (let i = 0; i < 30; i++) for (let j = 0; j < 30; j++) {
    const th = Math.acos(1 - 2 * (i + 0.5) / 30), ph = 2 * Math.PI * j / 30;
    pts.push([3 + 10 * Math.sin(th) * Math.cos(ph) + rnd() * 0.002,
              4 + 10 * Math.sin(th) * Math.sin(ph) + rnd() * 0.002,
              5 + 10 * Math.cos(th) + rnd() * 0.002]);
  }
  const r = F.sphere(pts);
  check('sphere found', !!r);
  if (r) {
    check('sphere R=10', Math.abs(r.R - 10) < 0.01, 'R=' + r.R.toFixed(5));
    check('sphere center (3,4,5)', Math.abs(r.c.x - 3) < 0.02 && Math.abs(r.c.y - 4) < 0.02 && Math.abs(r.c.z - 5) < 0.02, 'c=(' + r.c.x.toFixed(3) + ',' + r.c.y.toFixed(3) + ',' + r.c.z.toFixed(3) + ')');
    check('sphere rms tiny', r.rms < 0.005, 'rms=' + r.rms.toFixed(6));
  }
}
// 4) ЦИЛИНДР с другой осью (ось X)
{
  const pts = [];
  for (let k = 0; k < 30; k++) {
    const x = -8 + k * (16 / 29);
    for (let a = 0; a < 10; a++) {
      const t = 2 * Math.PI * a / 10;
      pts.push([x + rnd() * 0.002, -3 + 2.5 * Math.cos(t) + rnd() * 0.002, 7 + 2.5 * Math.sin(t) + rnd() * 0.002]);
    }
  }
  const r = F.cylinder(pts);
  check('cyl2 found', !!r);
  if (r) {
    const alen = Math.sqrt(r.axis.x ** 2 + r.axis.y ** 2 + r.axis.z ** 2);
    check('cyl2 axis ~X', Math.abs(r.axis.x / alen) > 0.999, 'ax=' + (r.axis.x / alen).toFixed(6));
    check('cyl2 R=2.5', Math.abs(r.R - 2.5) < 0.02, 'R=' + r.R.toFixed(5));
    check('cyl2 center y=-3,z=7', Math.abs(r.center.y + 3) < 0.05 && Math.abs(r.center.z - 7) < 0.05, 'c=(' + r.center.y.toFixed(3) + ',' + r.center.z.toFixed(3) + ')');
  }
}
console.log(fails ? '\n' + fails + ' CHECKS FAILED' : '\nALL FIT CHECKS PASSED');
process.exit(fails ? 1 : 0);
