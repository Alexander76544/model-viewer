const M=require('../prg-fixture-move.js');
const m=M.partMatrix({x:10,y:0,z:5,rz:90},[100,0,0]);
console.log(M.applyPart(m,[100,0,0]).map(v=>v.toFixed(3)), M.applyPart(m,[110,0,0]).map(v=>v.toFixed(3)));
