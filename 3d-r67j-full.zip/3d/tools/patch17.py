import re
P='/data/in/fullpkg/3d/prg-real-import.js'
s=open(P,encoding='utf-8').read()
anchor="      if (!header.partName && opts.fileName) header.partName"
assert anchor in s and 'r67 PrgCommands' not in s
add = r'''      /* r67 PrgCommands: full command walk (u16 OBTYPE + u32 len framing) */
      var PC = root.PrgCommands || (typeof require === 'function' ? (function () { try { return require('./prg-commands.js'); } catch (e) { return null; } })() : null);
      var cmdRes = null;
      if (PC) {
        try { cmdRes = PC.parse(part); } catch (e) { warnings.push('Обход команд r67: ' + e.message); }
      }
      if (cmdRes) {
        var added = 0, upd = 0;
        cmdRes.features.forEach(function (f) {
          if (!f.name) return;
          var ty = f.kind === 'plane' ? 'plane' : f.kind === 'circle' ? 'circle' : f.kind === 'cylinder' ? 'cylinder' : f.kind;
          var v = f.vec || [0, 0, 1];
          var prev = byName[f.name];
          var vals = { type: ty, group: f.group || (prev && prev.group) || '', x: num(f.X), y: num(f.Y), z: num(f.Z),
            i: fmtVec(v[0]), j: fmtVec(v[1]), k: fmtVec(v[2]), _vectorFromFile: !!f.vec, _axesConfirmed: true, _cmd: f.cmd, _obtype: f.obtype };
          if (f.diam !== null) vals.diam = num(f.diam);
          if (f.startAngle !== null && f.startAngle !== undefined) { vals.startAngle = num(f.startAngle); vals.endAngle = num(f.endAngle); }
          if (prev) { for (var k in vals) prev[k] = vals[k]; upd++; return; }
          var e = {
            id: 'prg' + (++idc), name: f.name, diam: f.diam === null ? '0' : num(f.diam), depth: '10',
            strategy: 'ПО_УМОЛЧ.', entry: 'ВХОД', points: '4', rows: '3', layers: '2', depthParam: '2',
            finishOffset: '5', step: '0', avoidBefore: '0', avoidAfter: '10',
            direction: 'ПРОТИВ ЧАСОВОЙ', angleVec: '0,0,1', startAngle: '0', endAngle: '360',
            constrFrom1: '', constrFrom2: '', outlierRemoval: 'ВЫКЛ,3', filterWave: '0',
            factSameAsNominal: true, hasTarget: true, factX: '', factY: '', factZ: '', factI: '', factJ: '', factK: '',
            factDiam: '', factDepth: '', open: true, extraLines: [], _profile: 'r67_' + f.kind, _axesOk: 3
          };
          for (var k2 in vals) e[k2] = vals[k2];
          byName[f.name] = e; elements.push(e); added++;
          if (ty === 'plane') stats.plane++;
        });
        warnings.push('r67: прочитано команд программы ' + cmdRes.commands.length + ' (формат v' + cmdRes.version + '), автоэлементов с номиналами ' +
          cmdRes.features.length + ' — добавлено ' + added + ', уточнено ' + upd + '.');
      }
'''
s=s.replace(anchor, add+anchor,1)
# use full command outline as preview when available
old="      return {\n        header: header, elements: elements, dimensions: dimensions,"
assert old in s
s=s.replace(old,"      if (cmdRes && PC) { preview = PC.outline(cmdRes, 5000); }\n"+old,1)
s=s.replace("        preview: preview, stats: stats\n","        preview: preview, stats: stats, commands: cmdRes ? cmdRes.commands : [], formatVersion: cmdRes ? cmdRes.version : null\n",1)
open(P,'w',encoding='utf-8').write(s)
H='/data/in/fullpkg/3d/pcdmis-generator-6.html'
h=open(H,encoding='utf-8').read()
if 'prg-commands.js' not in h:
    h=h.replace('<script src="prg-real-import.js"></script>','<script src="prg-commands.js"></script>\n<script src="prg-real-import.js"></script>',1)
open(H,'w',encoding='utf-8').write(h)
print('ok')
