const s = require('fs').readFileSync(process.argv[2], 'utf8');
let line = 1, i = 0, n = s.length;
const stack = [];
while (i < n) {
  const c = s[i];
  if (c === '\n') { if (line >= 630) console.log('line', line, 'stack:', JSON.stringify(stack.slice(-6))); line++; i++; continue; }
  if (c === '"' || c === "'" || c === '`') {
    const q = c; i++;
    while (i < n && s[i] !== q) { if (s[i] === '\\') i++; if (s[i] === '\n') { if (line >= 630) console.log('line', line, 'stack:', JSON.stringify(stack.slice(-6))); line++; } i++; }
    i++; continue;
  }
  if (c === '/' && s[i + 1] === '/') { while (i < n && s[i] !== '\n') i++; continue; }
  if (c === '/' && s[i + 1] === '*') { i += 2; while (i < n && !(s[i] === '*' && s[i + 1] === '/')) { if (s[i] === '\n') { if (line >= 630) console.log('line', line, 'stack:', JSON.stringify(stack.slice(-6))); line++; } i++; } i += 2; continue; }
  if (c === '{' || c === '(') stack.push([c, line]);
  if (c === '}' || c === ')') {
    const want = c === '}' ? '{' : '(';
    const top = stack[stack.length - 1];
    if (line >= 630) console.log('close', c, 'at line', line, 'top=', JSON.stringify(top), top && top[0] === want ? 'OK' : 'MISMATCH');
    if (stack.length) stack.pop();
  }
  i++;
}
console.log('EOF stack:', JSON.stringify(stack));
