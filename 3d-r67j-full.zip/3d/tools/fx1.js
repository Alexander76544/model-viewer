global.window=globalThis;global.performance=require('perf_hooks').performance;
require('/data/in/proj/3d/pcdmis-cad-reader.js');require('./pcdmis-cad-objects.js');require('./pcdmis-cad-planes.js');require('./pcdmis-cad-nurbs.js');
const fs=require('fs');const s=fs.readFileSync('./pcdmis-ui-r61.js','utf8');
const a=s.indexOf('  function cadExtras(');const b=s.indexOf('  // r66: каркас поверх');eval(s.slice(a,b)+';global.cadExtras=cadExtras;');
const buf=fs.readFileSync('/data/in/part.CAD');const u8=new Uint8Array(buf.buffer,buf.byteOffset,buf.length);
const res=PcdCadReader.read(u8);let tri=0;res.meshes.forEach(m=>tri+=m.tri.length/3);const pos=new Float32Array(tri*9);let q=0;res.meshes.forEach(m=>{for(let j=0;j<m.tri.length;j++){const v=m.tri[j]*3;pos[q++]=m.V[v];pos[q++]=m.V[v+1];pos[q++]=m.V[v+2]}});
const ex=cadExtras(u8,res,pos);const P=ex.pos||pos,o=ex.cad,TF=ex.triFace,nT=P.length/9;
// per body: tri indices, bbox
const B={};
for(let t=0;t<nT;t++){const f=TF[t];const bh=(f>0&&o.faceBody[f])||0;let e=B[bh];if(!e)e=B[bh]={bh,tris:[],min:[1e9,1e9,1e9],max:[-1e9,-1e9,-1e9],faces:new Set(),col:o.colors[bh]||0};e.tris.push(t);e.faces.add(f);for(let k=0;k<3;k++)for(let c=0;c<3;c++){const v=P[t*9+k*3+c];if(v<e.min[c])e.min[c]=v;if(v>e.max[c])e.max[c]=v;}}
const L=Object.values(B).map(e=>({bh:e.bh,n:e.tris.length,faces:e.faces.size,col:(e.col&0xffffff).toString(16).padStart(6,'0'),min:e.min.map(v=>+v.toFixed(1)),max:e.max.map(v=>+v.toFixed(1)),vol:(e.max[0]-e.min[0])*(e.max[1]-e.min[1])*(e.max[2]-e.min[2])})).sort((x,y)=>y.vol-x.vol);
fs.writeFileSync('/data/out/fx-bodies.json',JSON.stringify(L));
L.slice(0,40).forEach(e=>console.log(e.bh,e.n,e.faces,e.col,e.min.join(','),'..',e.max.join(','),Math.round(e.vol/1e3)));
console.log('bodies',L.length,'tris',nT);
global.__fx={P,TF,o,B};
if(process.argv[2]==='export'){require('./fx2.js');}
