const A=require('../pcdmis-align3d.js');
// плоскость z=10, линия вдоль (1,1,0), начало (5,5,3)
const pts=[[0,0,10],[10,0,10],[0,10,10],[0,0,4],[10,10,4],[5,5,3]];
const cs=A.solve(pts,[0,0,1]);console.log('Z',cs.Z,'X',cs.X.map(v=>v.toFixed(4)),'O',cs.O);
console.log('origin->',cs.toPart([5,5,10]).map(v=>v.toFixed(3)),'pt->',cs.toPart([15,5,12]).map(v=>v.toFixed(3)));
const p={elements:[],alignments:[]};const r=A.build(pts,[0,0,1],p);console.log(p.elements.map(e=>e.type+' '+e.name+' '+[e.x,e.y,e.z,e.i,e.j,e.k].join(',')),p.alignments[0].p1,p.alignments[0].p2,p.alignments[0].p3);
