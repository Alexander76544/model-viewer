"""Measure real record pitch and re-check nominal alignment with corrected bounds."""
import re
import struct
import sys
from collections import Counter

sys.path.insert(0, r"C:\Workspace\3d\tools\prg")
from probe_prg import Cfb

PATH = sys.argv[1] if len(sys.argv) > 1 else \
    r"C:\Users\diibl\Downloads\Головка\Головка\Не обкатаны\op40.50\770.1003014_op40.50.PRG"
buf = Cfb(open(PATH, "rb").read()).streams()["PARTPROG"]

# dominant terminator: FF FF + 54 zeros
TERM = b"\xff\xff" + b"\x00" * 54
marks, start = [], 0
while True:
    i = buf.find(TERM, start)
    if i < 0:
        break
    marks.append(i)
    start = i + 1
print("terminators found:", len(marks))
pitch = Counter(b - a for a, b in zip(marks, marks[1:]))
print("pitch between terminators (top 8):")
for p, c in pitch.most_common(8):
    print(f"   {p:6d} B x {c}")

recs = []
for a, b in zip([14] + [m + len(TERM) for m in marks[:-1]], marks):
    recs.append(buf[a:b])
print("records rebuilt:", len(recs), "| sizes:", Counter(len(r) for r in recs).most_common(5))

NAME_RE = re.compile(r"^(D|PL|INTR_D|INTR_PL)(\d+(?:\.\d+)?)", re.IGNORECASE)


def strings_of(rec):
    out, p = [], 0
    while True:
        i = rec.find(b"\xff\xfe\xff", p)
        if i < 0:
            break
        p = i + 1
        ln = rec[i + 3]
        if ln and i + 4 + ln * 2 <= len(rec):
            out.append(rec[i + 4:i + 4 + ln * 2].decode("utf-16-le", "replace"))
    return out


hits = Counter()
for idx, rec in enumerate(recs):
    for s in strings_of(rec):
        m = NAME_RE.match(s)
        if not m:
            continue
        nominal = float(m.group(2))
        best = None
        for off in range(0, len(rec) - 7):
            v = struct.unpack_from("<d", rec, off)[0]
            if v == v and abs(abs(v) - nominal) <= max(1e-6, nominal * 1e-9):
                best = (off, off % 8, v)
                break
        if best:
            hits[best[1]] += 1
print("\noffset alignment (mod 8) of the found nominal, corrected bounds:")
for rem, c in hits.most_common():
    print(f"   mod8={rem}  x{c}")
