"""For every marker-framed string in PARTPROG, show the doubles that follow it.

Used to judge whether named element records carry plausible coordinates.
"""
import struct
import sys

sys.path.insert(0, r"C:\Workspace\3d\tools\prg")
from probe_prg import Cfb, TRAILER

PATH = sys.argv[1] if len(sys.argv) > 1 else \
    r"C:\Users\diibl\Downloads\Головка\Головка\Не обкатаны\op40.50\770.1003014_op40.50.PRG"
LIMIT = int(sys.argv[2]) if len(sys.argv) > 2 else 25

buf = Cfb(open(PATH, "rb").read()).streams()["PARTPROG"]

# record boundaries (trailer starts at marks)
marks, start = [], 0
while True:
    i = buf.find(TRAILER, start)
    if i < 0:
        break
    marks.append(i)
    start = i + len(TRAILER)


def rec_of(off):
    lo = 14
    for m in marks:
        if off < m:
            return lo, m
        lo = m + len(TRAILER)
    return lo, len(buf)


def doubles_after(off, count=6, span=400):
    out = []
    for o in range(off, min(off + span, len(buf)) - 7):
        v = struct.unpack_from("<d", buf, o)[0]
        if v == v and 1e-4 <= abs(v) <= 1e5:
            out.append((o, v))
            if len(out) >= count:
                break
    return out


n = 0
pos = 0
while n < LIMIT:
    i = buf.find(b"\xff\xfe\xff", pos)
    if i < 0:
        break
    pos = i + 1
    ln = buf[i + 3]
    if ln == 0 or i + 4 + ln * 2 > len(buf):
        continue
    s = buf[i + 4:i + 4 + ln * 2].decode("utf-16-le", "replace")
    if not s or not any(ch.isalnum() for ch in s):
        continue
    rs, re_ = rec_of(i)
    end = i + 4 + ln * 2
    ds = doubles_after(end)
    print(f"\n0x{i:06x} record[0x{rs:x}..0x{re_:x}] len={re_ - rs + 14:5d} name={s!r}")
    print(f"    after name: {'  '.join(f'{v:.4g}@{o - rs:+d}' for o, v in ds) if ds else '(no plausible doubles within 400 B)'}")
    n += 1
