"""Walk a real PARTPROG stream: stream header, records, framed strings, aligned doubles.

Writes a UTF-8 report (console encoding on this machine mangles Cyrillic).
"""
import json
import struct
import sys

sys.path.insert(0, r"C:\Workspace\3d\tools\prg")
from probe_prg import Cfb, TRAILER


def walk(path, out_path, max_records=200):
    buf = Cfb(open(path, "rb").read()).streams()["PARTPROG"]
    head = buf[:14]
    h_id, h_ver = struct.unpack_from("<II", head, 0)
    h_magic = head[8:10].decode("ascii", "replace")
    h_opt = struct.unpack_from("<I", head, 10)[0]

    marks, start = [], 0
    while True:
        i = buf.find(TRAILER, start)
        if i < 0:
            break
        marks.append(i)
        start = i + len(TRAILER)

    recs = []
    prev = 14
    for m in marks:
        recs.append((prev, m + len(TRAILER)))
        prev = m + len(TRAILER)

    sample = []
    for idx, (a, b) in enumerate(recs[:max_records]):
        body = buf[a:b]
        strs = []
        p = 0
        while True:
            i = body.find(b"\xff\xfe\xff", p)
            if i < 0:
                break
            p = i + 1
            ln = body[i + 3]
            if ln and i + 4 + ln * 2 <= len(body):
                s = body[i + 4:i + 4 + ln * 2].decode("utf-16-le", "replace")
                strs.append({"at": a + i - a, "text": s})
        dbl = []
        for o in range(0, len(body) - 7):
            v = struct.unpack_from("<d", body, o)[0]
            if v == v and 1e-4 <= abs(v) <= 1e5:
                dbl.append(v)
        sample.append({"n": idx, "off": a, "size": b - a, "strings": strs,
                       "doubles": dbl[:10]})

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(f"file: {path}\n")
        f.write(f"PARTPROG: {len(buf)} bytes | header id={h_id} ver={h_ver} "
                f"magic={h_magic!r} opt={h_opt}\n")
        f.write(f"records: {len(recs)}\n")
        sizes = {}
        for a, b in recs:
            sizes[b - a] = sizes.get(b - a, 0) + 1
        top = sorted(sizes.items(), key=lambda kv: -kv[1])[:10]
        f.write("sizes: " + ", ".join(f"{s}B x{c}" for s, c in top) + "\n")
        f.write("\n--- first records (first 60) ---\n")
        for r in sample[:60]:
            names = " | ".join(f"{s['text']!r}@{s['at']}" for s in r["strings"]) or "-"
            nums = ", ".join(f"{v:.6g}" for v in r["doubles"]) or "-"
            f.write(f"#{r['n']:05d} off=0x{r['off']:08x} size={r['size']:5d}\n"
                    f"      names: {names}\n      doubles: {nums}\n")
    print("written:", out_path)


if __name__ == "__main__":
    p = sys.argv[1] if len(sys.argv) > 1 else \
        r"C:\Users\diibl\Downloads\Головка\Головка\Не обкатаны\op40.50\770.1003014_op40.50.PRG"
    o = sys.argv[2] if len(sys.argv) > 2 else r"C:\Workspace\3d\prg-extract-op40.50.txt"
    walk(p, o)
