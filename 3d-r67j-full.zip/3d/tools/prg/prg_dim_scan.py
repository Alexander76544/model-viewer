"""Scan 'Положение позиции ...' records and show nominal/measured/tolerance/deviation.

Used to verify the tolerance block against the PC-DMIS report values.
"""
import struct
import sys

sys.path.insert(0, r"C:\Workspace\3d\tools\prg")
from probe_prg import Cfb, TRAILER

PATH = sys.argv[1]
NEED = sys.argv[2] if len(sys.argv) > 2 else "Диам"
TARGET = float(sys.argv[3]) if len(sys.argv) > 3 else None
OUT = sys.argv[4] if len(sys.argv) > 4 else r"C:\Workspace\3d\prg-dimscan.txt"
LIMIT = int(sys.argv[5]) if len(sys.argv) > 5 else 12

buf = Cfb(open(PATH, "rb").read()).streams()["PARTPROG"]
marks, start = [], 0
while True:
    i = buf.find(TRAILER, start)
    if i < 0:
        break
    marks.append(i)
    start = i + len(TRAILER)
recs, prev = [], 14
for m in marks:
    recs.append(buf[prev:m + len(TRAILER)])
    prev = m + len(TRAILER)


def d(rec, off):
    if off + 8 > len(rec):
        return None
    v = struct.unpack_from("<d", rec, off)[0]
    return v if v == v else None


f = open(OUT, "w", encoding="utf-8")
f.write(f"file: {PATH}\nscan for 'Положение позиции {NEED}'\n")
shown = 0
for idx, rec in enumerate(recs):
    if f"Положение позиции {NEED}".encode("utf-16-le") not in rec:
        continue
    nom, act, tol, dev = d(rec, 70), d(rec, 78), d(rec, 86), d(rec, 110)
    if TARGET is not None and (nom is None or abs(abs(nom) - TARGET) > 1e-6):
        continue
    # the dimension name sits in the preceding records; report nearest one
    name = ""
    for back in range(1, 6):
        if idx - back < 0:
            break
        r2 = recs[idx - back]
        p = 0
        while True:
            i = r2.find(b"\xff\xfe\xff", p)
            if i < 0:
                break
            p = i + 1
            ln = r2[i + 3]
            if ln and i + 4 + ln * 2 <= len(r2):
                s = r2[i + 4:i + 4 + ln * 2].decode("utf-16-le", "replace")
                if s.startswith("POS_") or s.startswith("DIM_"):
                    name = s
            if name:
                break
        if name:
            break
    f.write(f"#{idx:6d} size={len(rec):5d} nominal={nom} measured={act} tol={tol} dev={dev} dim={name}\n")
    shown += 1
    if shown >= LIMIT:
        break
f.close()
print("written:", OUT, "rows:", shown)
