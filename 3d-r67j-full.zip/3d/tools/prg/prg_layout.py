"""Field map of the dominant PARTPROG record type.

Compares many same-size records byte by byte: offsets that never change are
constants/flags, offsets with few distinct values are enumerations, offsets with
many are data (doubles / counters).
"""
import struct
import sys
from collections import Counter

sys.path.insert(0, r"C:\Workspace\3d\tools\prg")
from probe_prg import Cfb, TRAILER

PATH = sys.argv[1] if len(sys.argv) > 1 else \
    r"C:\Users\diibl\Downloads\Головка\Головка\Не обкатаны\op40.50\770.1003014_op40.50.PRG"
WANT = int(sys.argv[2]) if len(sys.argv) > 2 else 332
N = int(sys.argv[3]) if len(sys.argv) > 3 else 400

buf = Cfb(open(PATH, "rb").read()).streams()["PARTPROG"]
marks, start = [], 0
while True:
    i = buf.find(TRAILER, start)
    if i < 0:
        break
    marks.append(i)
    start = i + len(TRAILER)

prev = 14
recs = []
for m in marks:
    rec = buf[prev:m + len(TRAILER)]
    prev = m + len(TRAILER)
    if len(rec) == WANT:
        recs.append(rec)
        if len(recs) >= N:
            break
print(f"records of size {WANT}: using first {len(recs)}")

L = WANT
cols = [set() for _ in range(L)]
for r in recs:
    for i in range(L):
        cols[i].add(r[i])

print("\noffset | distinct | meaning / constant value")
for i in range(L):
    d = len(cols[i])
    if d == 1:
        v = next(iter(cols[i]))
        tag = "CONST"
    elif d <= 8:
        tag = "enum:" + ",".join(f"{v:02x}" for v in sorted(cols[i]))
    else:
        tag = "data"
    if i % 16 == 0 or tag != "data":
        print(f"  {i:4d} | {d:8d} | {tag}")

# byte-level summary of blocks that are constant
print("\nconstant blocks:")
i = 0
while i < L:
    if len(cols[i]) == 1:
        j = i
        while j + 1 < L and len(cols[j + 1]) == 1 and cols[j + 1] == cols[i]:
            j += 1
        v = next(iter(cols[i]))
        if j - i >= 1:
            print(f"  {i:4d}..{j:4d} ({j - i + 1:3d} B) = 0x{v:02x}")
        i = j + 1
    else:
        i += 1

# candidate enumerations of 2/4 bytes
print("\ncandidate 2-byte fields (few distinct values):")
for off in range(0, L - 1):
    s = {struct.unpack_from("<H", r, off)[0] for r in recs}
    if 1 < len(s) <= 12:
        print(f"  +{off:3d}: " + ", ".join(f"0x{v:04x}({v})" for v in sorted(s)))
print("\ncandidate 4-byte fields (few distinct values):")
for off in range(0, L - 3, 2):
    s = {struct.unpack_from("<I", r, off)[0] for r in recs}
    if 1 < len(s) <= 10:
        print(f"  +{off:3d}: " + ", ".join(f"0x{v:08x}({v})" for v in sorted(s)))
