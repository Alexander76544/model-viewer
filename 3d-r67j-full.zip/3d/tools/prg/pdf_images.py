"""Extract the page images of the PC-DMIS report so they can be read visually."""
import os
import sys

from pypdf import PdfReader

src = sys.argv[1] if len(sys.argv) > 1 else \
    r"C:\Users\diibl\Downloads\Головка\Головка\Не обкатаны\op77.80\770.1003014_op77.80_1.PDF"
outdir = sys.argv[2] if len(sys.argv) > 2 else r"C:\Workspace\3d\op77-images"
pages = int(sys.argv[3]) if len(sys.argv) > 3 else 2

os.makedirs(outdir, exist_ok=True)
r = PdfReader(src)
print("pages:", len(r.pages))
for pi in range(min(pages, len(r.pages))):
    page = r.pages[pi]
    imgs = list(page.images)
    print(f"page {pi + 1}: {len(imgs)} images")
    for k, im in enumerate(imgs):
        name = im.name or f"img{k}"
        ext = os.path.splitext(name)[1].lower() or ".bin"
        if ext not in (".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"):
            ext = ".bin"
        path = os.path.join(outdir, f"p{pi + 1}_{k}{ext}")
        with open(path, "wb") as f:
            f.write(im.data)
        print(f"   {path}  {len(im.data)} bytes  ({name})")
