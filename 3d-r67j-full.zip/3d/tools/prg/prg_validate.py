"""Validate the field map using the nominal value encoded in element names.

Elements are named like D19.5_P4_MAN (diameter 19.5), D28_B2_1, PL15.6_B2_1.
If the record layout is right, that nominal must appear inside the record body
as an 8-byte double.  Prints, per element, where the nominal was found.
"""
import re
import struct
import sys
from collections import Counter

sys.path.insert(0, r"C:\Workspace\3d\tools\prg")
from probe_prg import Cfb, TRAILER

PATH = sys.argv[1] if len(sys.argv) > 1 else \
    r"C:\Users\diibl\Downloads\Головка\Головка\Не обкатаны\op40.50\770.1003014_op40.50.PRG"
OUT = sys.argv[2] if len(sys.argv) > 2 else r"C:\Workspace\3d\prg-validate.txt"

NAME_RE = re.compile(r"^(D|PL|INTR_D|INTR_PL)(\d+(?:\.\d+)?)", re.IGNORECASE)


def walk(path):
    buf = Cfb(open(path, "rb").read()).streams()["PARTPROG"]
    marks, start = [], 0
    while True:
        i = buf.find(TRAILER, start)
        if i < 0:
            break
        marks.append(i)
        start = i + len(TRAILER)
    recs, prev = [], 14
    for m in marks:
        recs.append(buf[prev:m + len(TRAILER)])
        prev = m + len(TRAILER)
    return buf, recs


def strings_of(rec):
    out, p = [], 0
    while True:
        i = rec.find(b"\xff\xfe\xff", p)
        if i < 0:
            break
        p = i + 1
        ln = rec[i + 3]
        if ln and i + 4 + ln * 2 <= len(rec):
            out.append((i, rec[i + 4:i + 4 + ln * 2].decode("utf-16-le", "replace")))
    return out


def main(path, out_path):
    buf, recs = walk(path)
    hits_off = Counter()
    found = 0
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(f"file: {path}\n")
        for idx, rec in enumerate(recs):
            names = strings_of(rec)
            for pos, s in names:
                m = NAME_RE.match(s)
                if not m:
                    continue
                nominal = float(m.group(2))
                for target, kind in ((nominal, "nominal"), (nominal / 2.0, "radius")):
                    for off in range(0, len(rec) - 7):
                        v = struct.unpack_from("<d", rec, off)[0]
                        if v == v and abs(abs(v) - target) <= max(1e-6, target * 1e-9):
                            hits_off[(off, kind)] += 1
                            found += 1
                            f.write(f"#{idx:05d} size={len(rec):5d} {s!r} "
                                    f"value {v:.10g} ({kind} of {target:g}) at +{off}\n")
                            break
    print("matched values:", found)
    print("most common (offset, kind) where the nominal sits:")
    for (off, kind), c in hits_off.most_common(25):
        print(f"   +{off:4d}  {kind:8s} x{c}")


if __name__ == "__main__":
    main(PATH, OUT)
