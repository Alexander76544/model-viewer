/* Node test for prg-real-import.js against the real programs. */
const fs = require('fs');
const path = require('path');
const mod = require('C:/Workspace/3d/prg-real-import.js');

const base = 'C:/Users/diibl/Downloads/Головка/Головка/Не обкатаны';
const jobs = [
  ['op40.50', 'op40.50/770.1003014_op40.50.PRG'],
  ['op80', 'op80/770.1003014_op80.PRG'],
  ['op77.80', 'op77.80/770.1003014_op77.80.PRG'],
  ['op5.10.20', 'op5.10.20/770.1003014-10_op5.10.20.PRG'],
];

const anchors = [
  ['op77.80', 'INTR_D12.1_T34_1', { Z: 137.5, diam: 12.1 }],
  ['op77.80', 'INTR_D12.1_T34_2', { Y: 960, Z: 137.5, diam: 12.1 }],
  ['op80', 'D9_K1_3', { Y: 434.91, Z: 25.35, diam: 9 }],
  ['op40.50', 'D25_T19_1', { diam: 25 }],
];

const out = [];
let failures = 0;

for (const [label, rel] of jobs) {
  const file = path.join(base, rel);
  const t0 = Date.now();
  const u8 = new Uint8Array(fs.readFileSync(file));
  let res;
  try {
    res = mod.parseRealPrg(u8);
  } catch (e) {
    out.push(`FAIL ${label}: ${e.message}`);
    failures++;
    continue;
  }
  const ms = Date.now() - t0;
  const st = res.stats;
  out.push(`${label}: ${(u8.length / 1048576).toFixed(1)} MB, ${ms} ms | records ${st.records}, ` +
    `cyl ${st.cylinder}, pos/dia ${st.posDia}, skipped ${st.skipped}, groups ${st.groups}, planes ${st.planes}` +
    ` | elements ${res.elements.length}, dims ${res.dimensions.length}` +
    ` | part ${res.header.partName || '-'} op ${res.header.operation || '-'}`);

  for (const [op, name, expect] of anchors) {
    if (op !== label) continue;
    const el = res.elements.find(e => e.name === name);
    if (!el) { out.push(`   ANCHOR MISS ${name}`); failures++; continue; }
    const got = { X: el.x, Y: el.y, Z: el.z, diam: el.diam };
    for (const k in expect) {
      const val = parseFloat(got[k]);
      const ok = Math.abs(val - expect[k]) < 0.001;
      out.push(`   anchor ${name}.${k}: ${got[k]} vs ${expect[k]} -> ${ok ? 'OK' : 'MISMATCH'}`);
      if (!ok) failures++;
    }
  }
}

out.push(failures === 0 ? '\nALL ANCHORS OK' : `\n${failures} FAILURES`);
fs.writeFileSync('C:/Workspace/3d/prg-js-test.txt', out.join('\n'), 'utf8');
console.log(out.join('\n'));
