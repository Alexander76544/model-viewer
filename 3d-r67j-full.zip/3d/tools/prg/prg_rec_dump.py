"""Hex dump of one record with plausible doubles annotated (to read field framing)."""
import struct
import sys

sys.path.insert(0, r"C:\Workspace\3d\tools\prg")
from probe_prg import Cfb, TRAILER

PATH = sys.argv[1]
SELECTOR = sys.argv[2]              # record name or #index
OUT = sys.argv[3] if len(sys.argv) > 3 else r"C:\Workspace\3d\prg-rec-dump.txt"
LO = int(sys.argv[4]) if len(sys.argv) > 4 else 0
HI = int(sys.argv[5]) if len(sys.argv) > 5 else 0

buf = Cfb(open(PATH, "rb").read()).streams()["PARTPROG"]
marks, start = [], 0
while True:
    i = buf.find(TRAILER, start)
    if i < 0:
        break
    marks.append(i)
    start = i + len(TRAILER)
recs, prev = [], 14
for m in marks:
    recs.append(buf[prev:m + len(TRAILER)])
    prev = m + len(TRAILER)

rec = None
idx = -1
if SELECTOR.startswith("#"):
    idx = int(SELECTOR[1:])
    rec = recs[idx]
else:
    for i, r in enumerate(recs):
        if SELECTOR.encode("utf-16-le") in r:
            rec, idx = r, i
            break
if rec is None:
    print("record not found")
    sys.exit(1)

hi = HI or len(rec)
f = open(OUT, "w", encoding="utf-8")
f.write(f"file: {PATH}\nrecord #{idx} size={len(rec)}  window {LO}..{hi}\n\n")

dbl = {}
for off in range(0, len(rec) - 7):
    v = struct.unpack_from("<d", rec, off)[0]
    if v == v and 1e-9 <= abs(v) <= 1e6:
        dbl[off] = v

for off in range(LO, min(hi, len(rec)), 16):
    chunk = rec[off:off + 16]
    toks = " ".join(f"{b:02x}" for b in chunk)
    asc = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
    note = ""
    for k in range(16):
        o = off + k
        if o in dbl:
            note += f"  +{o}={dbl[o]:.7g}"
    f.write(f"{off:5d}  {toks:<47}  {asc}{note}\n")

f.write("\nall plausible doubles:\n")
for o in sorted(dbl):
    f.write(f"  +{o:5d} (mod8={o % 8}) {dbl[o]:.10g}\n")
f.close()
print("written:", OUT, "record", idx, "size", len(rec))
