import sys,struct,re,json,collections
sys.path.insert(0,'/data/in/prgs')
b=open(sys.argv[1],'rb').read()
# load obtype table
src=open('/data/in/fullpkg/3d/pcdmis-obtype.js',encoding='utf-8').read()
OBT={int(m.group(1)):(m.group(2),m.group(3)) for m in re.finditer(r'^\s*(\d+):\s*\["([^"]+)",\s*"([^"]*)"',src,re.M)}
OBT[12345]=('FILE_HEADER','Заголовок файла')
def nm(q):
    n=b[q+3]; return b[q+4:q+4+2*n].decode('utf-16le','replace')
# all candidates: u16 type, u32 len, FF FE FF
cands=[]
for m in re.finditer(b'\xff\xfe\xff',b):
    q=m.start()
    if q<6: continue
    t,L=struct.unpack_from('<HI',b,q-6)
    t = t if t<0x8000 else -(0x10000-t)
    if abs(t) in OBT and 4<=L<=len(b)-q: cands.append((q,t,L))
print('candidates',len(cands))
# greedy chain: from body start q with length L, next candidate with q2>=q+L (minimal)
import bisect
qs=[c[0] for c in cands]
ch=[cands[0]];cur=cands[0]
gaps=collections.Counter();big=[]
while True:
    q,t,L=cur; e=q+L
    i=bisect.bisect_left(qs,e+6)
    if i>=len(cands): break
    nx=cands[i]
    g=nx[0]-6-e
    gaps[min(g,999)]+=1
    if g>200: big.append((e,g,t,nm(q)[:20],nx[1],nm(nx[0])[:20]))
    ch.append(nx);cur=nx
print('chain',len(ch),'end',hex(cur[0]+cur[2]),'size',hex(len(b)))
print('big gaps',len(big))
for x in big[:15]: print('  at %x gap %d after %d %s -> %d %s'%x)
h=collections.Counter(c[1] for c in ch)
for t,n in h.most_common(40): print('%6d %5d %s %s'%(t,n,OBT[abs(t)][0],OBT[abs(t)][1]))
json.dump([[c[0],c[1],c[2]] for c in ch],open(sys.argv[1]+'.chain.json','w'))
