"""Measure the exact record terminator: how many zero bytes follow FF FF."""
import sys
from collections import Counter

sys.path.insert(0, r"C:\Workspace\3d\tools\prg")
from probe_prg import Cfb

PATH = sys.argv[1] if len(sys.argv) > 1 else \
    r"C:\Users\diibl\Downloads\Головка\Головка\Не обкатаны\op40.50\770.1003014_op40.50.PRG"
buf = Cfb(open(PATH, "rb").read()).streams()["PARTPROG"]

runs = Counter()
pos = 0
while True:
    i = buf.find(b"\xff\xff", pos)
    if i < 0:
        break
    pos = i + 2
    n = 0
    while i + 2 + n < len(buf) and buf[i + 2 + n] == 0:
        n += 1
    runs[n] += 1
print("zero-run length after FF FF (top 10):")
for n, c in runs.most_common(10):
    print(f"   {n:3d} zeros x {c}")

# show the 40 bytes after a few markers
print("\ncontext after markers:")
shown = 0
pos = 0
while shown < 5:
    i = buf.find(b"\xff\xff", pos)
    if i < 0:
        break
    pos = i + 2
    if runs_hit := buf[i + 2:i + 26].count(0) >= 12:
        pass
    chunk = buf[max(0, i - 8):i + 40]
    print(f"  0x{i:06x}: {chunk.hex(' ')}")
    shown += 1
