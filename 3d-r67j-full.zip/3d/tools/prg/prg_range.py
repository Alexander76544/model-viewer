"""Print a range of records: size, strings and a few plausible doubles."""
import struct
import sys

sys.path.insert(0, r"C:\Workspace\3d\tools\prg")
from probe_prg import Cfb, TRAILER

PATH = sys.argv[1]
A = int(sys.argv[2])
B = int(sys.argv[3])
OUT = sys.argv[4] if len(sys.argv) > 4 else r"C:\Workspace\3d\prg-range.txt"

buf = Cfb(open(PATH, "rb").read()).streams()["PARTPROG"]
marks, start = [], 0
while True:
    i = buf.find(TRAILER, start)
    if i < 0:
        break
    marks.append(i)
    start = i + len(TRAILER)
recs, prev = [], 14
for m in marks:
    recs.append(buf[prev:m + len(TRAILER)])
    prev = m + len(TRAILER)

f = open(OUT, "w", encoding="utf-8")
f.write(f"file: {PATH}\nrecords {A}..{B} of {len(recs)}\n")
for idx in range(max(0, A), min(B + 1, len(recs))):
    rec = recs[idx]
    strs, p = [], 0
    while True:
        i = rec.find(b"\xff\xfe\xff", p)
        if i < 0:
            break
        p = i + 1
        ln = rec[i + 3]
        if ln and i + 4 + ln * 2 <= len(rec):
            strs.append(rec[i + 4:i + 4 + ln * 2].decode("utf-16-le", "replace"))
    dbls = []
    for off in range(0, len(rec) - 7):
        v = struct.unpack_from("<d", rec, off)[0]
        if v == v and 1e-6 <= abs(v) <= 1e5:
            dbls.append(f"{v:.6g}@{off}")
            if len(dbls) >= 8:
                break
    f.write(f"\n#{idx:6d} size={len(rec):8d} strings={strs[:6]}\n")
    f.write(f"        doubles: {', '.join(dbls)}\n")
f.close()
print("written:", OUT)
