import sys,struct,re,json,collections
b=open(sys.argv[1],'rb').read()
src=open('/data/in/fullpkg/3d/pcdmis-obtype.js',encoding='utf-8').read()
OBT={int(m.group(1)):(m.group(2),m.group(3)) for m in re.finditer(r'^\s*(\d+):\s*\["([^"]+)",\s*"([^"]*)"',src,re.M)}
OBT[12345]=('FILE_HEADER','header')
def typ(t): return t if t<0x8000 else -(0x10000-t)
def nm(q,e):
    k=b.find(b'\xff\xfe\xff',q,min(e,q+64))
    if k<0: return ''
    n=b[k+3]; return b[k+4:k+4+2*n].decode('utf-16le','replace')
def valid(p):
    if p+6>len(b): return None
    t,L=struct.unpack_from('<HI',b,p)
    tt=typ(t)
    if abs(tt) not in OBT or L<4 or p+6+L>len(b): return None
    return tt,L
p=8;recs=[];gaps=collections.Counter();lost=[]
while p<len(b):
    v=valid(p)
    if not v: break
    tt,L=v; q=p+6; e=q+L
    recs.append((p,tt,L))
    # find next: smallest g such that valid(e+g) and that one chains too
    nxt=None
    for g in range(0,4096):
        w=valid(e+g)
        if w:
            e2=e+g+6+w[1]
            ok=any(valid(e2+h) for h in range(0,4096)) or e2>=len(b)-64
            if ok: nxt=e+g;break
    if nxt is None: lost.append((e,len(b)-e)); break
    gaps[nxt-e]+=1; p=nxt
print('records',len(recs),'stop',hex(p),'size',hex(len(b)),'lost',lost[:3])
print('gaps',sorted(gaps.items())[:30])
h=collections.Counter(r[1] for r in recs)
for t,n in h.most_common(60): print('%7d %5d %s'%(t,n,OBT[abs(t)][0]))
json.dump(recs,open(sys.argv[1]+'.recs.json','w'))
