import sys,struct,json,re
f=sys.argv[1]; want=int(sys.argv[2])
b=open(f,'rb').read()
ch=json.load(open(f+'.chain.json'))
def strs(q,e):
    out=[];k=q
    while True:
        k=b.find(b'\xff\xfe\xff',k,e)
        if k<0: break
        n=b[k+3]
        if n: out.append((k-q,b[k+4:k+4+2*n].decode('utf-16le','replace')))
        k+=4+2*n if n else 4
    return out
for q,t,L in ch:
    if t!=want: continue
    e=q+L
    ss=strs(q,min(e,q+3000))
    print('== @%x len %d'%(q,L), [s for s in ss[:8]])
    # plausible doubles in first 2000 bytes
    ds=[]
    for o in range(0,min(L,1600)-8):
        v=struct.unpack_from('<d',b,q+o)[0]
        if v==v and 1e-3<abs(v)<5000 and (abs(v*1000-round(v*1000))<1e-6):
            ds.append((o,round(v,4)))
    print('   ',ds[:60])
    if len(sys.argv)<4: break
