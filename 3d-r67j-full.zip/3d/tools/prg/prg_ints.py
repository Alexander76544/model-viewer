"""List small integer fields (candidate tolerances in um) inside a named record."""
import struct
import sys

sys.path.insert(0, r"C:\Workspace\3d\tools\prg")
from probe_prg import Cfb, TRAILER

PATH = sys.argv[1]
NEEDLE = sys.argv[2]
OUT = sys.argv[3] if len(sys.argv) > 3 else r"C:\Workspace\3d\prg-ints.txt"
LO = int(sys.argv[4]) if len(sys.argv) > 4 else 10
HI = int(sys.argv[5]) if len(sys.argv) > 5 else 5000

buf = Cfb(open(PATH, "rb").read()).streams()["PARTPROG"]
marks, start = [], 0
while True:
    i = buf.find(TRAILER, start)
    if i < 0:
        break
    marks.append(i)
    start = i + len(TRAILER)
recs, prev = [], 14
for m in marks:
    recs.append(buf[prev:m + len(TRAILER)])
    prev = m + len(TRAILER)

f = open(OUT, "w", encoding="utf-8")
f.write(f"file: {PATH}\nneedle: {NEEDLE}\ninteger fields in [{LO}..{HI}]\n")
for idx, rec in enumerate(recs):
    if NEEDLE.encode("utf-16-le") not in rec:
        continue
    f.write(f"\n=== #{idx} size={len(rec)} ===\n")
    for off in range(0, len(rec) - 1):
        v = struct.unpack_from("<H", rec, off)[0]
        if LO <= v <= HI:
            f.write(f"  +{off:5d} (mod8={off % 8}) u16={v}\n")
    f.write("  u32 fields:\n")
    for off in range(0, len(rec) - 3):
        v = struct.unpack_from("<I", rec, off)[0]
        if LO <= v <= HI:
            f.write(f"  +{off:5d} u32={v}\n")
    break
f.close()
print("written:", OUT)
