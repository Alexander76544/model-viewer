"""Extract text from the PC-DMIS report PDF (ground truth for nominal/actual values)."""
import sys

path = sys.argv[1] if len(sys.argv) > 1 else \
    r"C:\Users\diibl\Downloads\Головка\Головка\Не обкатаны\op77.80\770.1003014_op77.80_1.PDF"
out = sys.argv[2] if len(sys.argv) > 2 else r"C:\Workspace\3d\op77.80-report.txt"
pages = int(sys.argv[3]) if len(sys.argv) > 3 else 3

text = None
try:
    import fitz  # PyMuPDF
    doc = fitz.open(path)
    print("PyMuPDF ok, pages:", doc.page_count)
    text = "\n\n".join(f"=== page {i + 1} ===\n" + doc[i].get_text()
                       for i in range(min(pages, doc.page_count)))
except Exception as exc:
    print("PyMuPDF failed:", exc)
    try:
        from pypdf import PdfReader
        r = PdfReader(path)
        print("pypdf ok, pages:", len(r.pages))
        text = "\n\n".join(f"=== page {i + 1} ===\n" + r.pages[i].extract_text()
                           for i in range(min(pages, len(r.pages))))
    except Exception as exc2:
        print("pypdf failed:", exc2)

if text is None:
    print("no extraction library available")
    sys.exit(1)

with open(out, "w", encoding="utf-8") as f:
    f.write(text)
print("written:", out, len(text), "chars")
