"""Dump the fixed tail of element records as aligned doubles.

The nominal of an element sits at a constant distance from the record end, so the
tail is a fixed parameter block; this prints it for chosen element names.
"""
import struct
import sys

sys.path.insert(0, r"C:\Workspace\3d\tools\prg")
from probe_prg import Cfb, TRAILER

PATH = sys.argv[1] if len(sys.argv) > 1 else \
    r"C:\Users\diibl\Downloads\Головка\Головка\Не обкатаны\op40.50\770.1003014_op40.50.PRG"
OUT = sys.argv[2] if len(sys.argv) > 2 else r"C:\Workspace\3d\prg-tails.txt"
WANT = sys.argv[3].split(",") if len(sys.argv) > 3 else ["D25_T19_1", "D28_B2_1", "D19.5_P4_MAN", "D32.6_B2_1"]
TAIL = 480


def walk(path):
    buf = Cfb(open(path, "rb").read()).streams()["PARTPROG"]
    marks, start = [], 0
    while True:
        i = buf.find(TRAILER, start)
        if i < 0:
            break
        marks.append(i)
        start = i + len(TRAILER)
    recs, prev = [], 14
    for m in marks:
        recs.append(buf[prev:m + len(TRAILER)])
        prev = m + len(TRAILER)
    return recs


def strings_of(rec):
    out, p = [], 0
    while True:
        i = rec.find(b"\xff\xfe\xff", p)
        if i < 0:
            break
        p = i + 1
        ln = rec[i + 3]
        if ln and i + 4 + ln * 2 <= len(rec):
            out.append(rec[i + 4:i + 4 + ln * 2].decode("utf-16-le", "replace"))
    return out


recs = walk(PATH)
with open(OUT, "w", encoding="utf-8") as f:
    f.write(f"file: {PATH}\n")
    for want in WANT:
        for idx, rec in enumerate(recs):
            names = strings_of(rec)
            if want not in names:
                continue
            f.write(f"\n=== #{idx} size={len(rec)} names={names} ===\n")
            start = max(0, len(rec) - TAIL)
            f.write(f"--- tail from +{start} (offsets relative to record start) ---\n")
            for off in range(start, len(rec) - 7, 8):
                d = struct.unpack_from("<d", rec, off)[0]
                ok = "  " if (d == d and 1e-9 <= abs(d) <= 1e6) else "??"
                f.write(f"  +{off:5d} (end-{len(rec) - off:4d})  d={d:<22.10g} {ok} "
                        f"| u16={struct.unpack_from('<H', rec, off)[0]:5d} "
                        f"u32={struct.unpack_from('<I', rec, off)[0]:10d}\n")
            break
print("written:", OUT)
