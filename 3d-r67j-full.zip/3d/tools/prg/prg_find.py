"""Find records by element name and list their plausible doubles with offsets."""
import struct
import sys

sys.path.insert(0, r"C:\Workspace\3d\tools\prg")
from probe_prg import Cfb, TRAILER

PATH = sys.argv[1]
NEEDLE = sys.argv[2]
OUT = sys.argv[3] if len(sys.argv) > 3 else r"C:\Workspace\3d\prg-find.txt"
WATCH = [float(x) for x in sys.argv[4].split(",")] if len(sys.argv) > 4 else []

buf = Cfb(open(PATH, "rb").read()).streams()["PARTPROG"]
marks, start = [], 0
while True:
    i = buf.find(TRAILER, start)
    if i < 0:
        break
    marks.append(i)
    start = i + len(TRAILER)
recs, prev = [], 14
for m in marks:
    recs.append(buf[prev:m + len(TRAILER)])
    prev = m + len(TRAILER)

f = open(OUT, "w", encoding="utf-8")
f.write(f"file: {PATH}\nneedle: {NEEDLE}\nrecords: {len(recs)}\n")

found = 0
for idx, rec in enumerate(recs):
    p, strs = 0, []
    while True:
        i = rec.find(b"\xff\xfe\xff", p)
        if i < 0:
            break
        p = i + 1
        ln = rec[i + 3]
        if ln and i + 4 + ln * 2 <= len(rec):
            strs.append((i, rec[i + 4:i + 4 + ln * 2].decode("utf-16-le", "replace")))
    names = [s for _, s in strs]
    if NEEDLE not in names:
        continue
    found += 1
    f.write(f"\n=== #{idx} size={len(rec)} names={names} ===\n")
    f.write("  strings:\n")
    for off, s in strs:
        f.write(f"    +{off:5d} {s!r}\n")
    f.write("  plausible doubles:\n")
    for off in range(0, len(rec) - 7):
        v = struct.unpack_from("<d", rec, off)[0]
        if v == v and 1e-6 <= abs(v) <= 1e6:
            mark = " <<<" if any(abs(abs(v) - w) <= max(1e-9, w * 1e-9) for w in WATCH) else ""
            f.write(f"    +{off:5d} (mod8={off % 8}) {v:.10g}{mark}\n")
    if found >= 3:
        break
f.write(f"\nmatched records: {found}\n")
f.close()
print("written:", OUT, "matched:", found)
