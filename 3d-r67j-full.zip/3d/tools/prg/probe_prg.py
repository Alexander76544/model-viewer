#!/usr/bin/env python3
"""PC-DMIS .prg (OLE/CFB, stream PARTPROG) probe.

Modes:
  python probe_prg.py tags  <PCDLRN.exe>      - dump UTF-16 string tables around record tags
  python probe_prg.py prg   <file.prg>        - list CFB streams + walk PARTPROG text runs with payload bytes
"""
import sys, struct, re

# ---------------- minimal MS-CFB reader ----------------
FREESECT, ENDOFCHAIN, FATSECT, DIFSECT = 0xFFFFFFFF, 0xFFFFFFFE, 0xFFFFFFFD, 0xFFFFFFFC


class Cfb:
    def __init__(self, data: bytes):
        self.d = data
        if data[:8] != b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
            raise ValueError("not OLE/CFB")
        self.major = struct.unpack_from("<H", data, 26)[0]
        self.sec_shift = struct.unpack_from("<H", data, 30)[0]
        self.mini_shift = struct.unpack_from("<H", data, 32)[0]
        self.sec_size = 1 << self.sec_shift
        self.mini_size = 1 << self.mini_shift
        self.first_dir = struct.unpack_from("<i", data, 48)[0]
        self.mini_cutoff = struct.unpack_from("<I", data, 56)[0]
        self.first_mini = struct.unpack_from("<i", data, 60)[0]
        self.first_difat = struct.unpack_from("<i", data, 68)[0]
        self._read_fat()
        self._read_dir()

    def sec_off(self, s):
        return (s + 1) * self.sec_size

    def _read_fat(self):
        difat = [struct.unpack_from("<i", self.d, 76 + i * 4)[0] for i in range(109)]
        difat = [x for x in difat if x >= 0]
        sid = self.first_difat
        guard = 0
        while sid >= 0 and guard < 10000:
            guard += 1
            off = self.sec_off(sid)
            n = self.sec_size // 4 - 1
            for i in range(n):
                v = struct.unpack_from("<i", self.d, off + i * 4)[0]
                if v >= 0:
                    difat.append(v)
            sid = struct.unpack_from("<i", self.d, off + n * 4)[0]
        fat = []
        for fs in difat:
            off = self.sec_off(fs)
            for i in range(self.sec_size // 4):
                fat.append(struct.unpack_from("<i", self.d, off + i * 4)[0])
        self.fat = fat

    def chain(self, start, table):
        out, s, guard = [], start, 0
        while s >= 0 and guard < 1000000:
            guard += 1
            out.append(s)
            if s >= len(table):
                break
            s = table[s]
        return out

    def read_chain(self, start, table=None):
        table = self.fat if table is None else table
        parts = []
        for s in self.chain(start, table):
            o = self.sec_off(s)
            parts.append(self.d[o:o + self.sec_size])
        return b"".join(parts)

    def _read_dir(self):
        raw = self.read_chain(self.first_dir)
        self.entries = []
        for i in range(0, len(raw) - 127, 128):
            name_len = struct.unpack_from("<H", raw, i + 64)[0]
            etype = raw[i + 66]
            start = struct.unpack_from("<i", raw, i + 116)[0]
            size = struct.unpack_from("<Q", raw, i + 120)[0] if self.major == 4 else struct.unpack_from("<I", raw, i + 120)[0]
            name = ""
            if name_len > 2:
                name = raw[i:i + max(0, name_len - 2)].decode("utf-16-le", "replace")
            self.entries.append({"name": name, "type": etype, "start": start, "size": size})

    def streams(self):
        root = next((e for e in self.entries if e["type"] == 5), None)
        mini_stream = b""
        mini_fat = []
        if root and root["start"] >= 0:
            mini_stream = self.read_chain(root["start"])
        if self.first_mini >= 0:
            mf = self.read_chain(self.first_mini)
            mini_fat = [struct.unpack_from("<i", mf, i)[0] for i in range(0, len(mf) - 3, 4)]
        out = {}
        for e in self.entries:
            if e["type"] != 2 or not e["name"]:
                continue
            if e["size"] < self.mini_cutoff and mini_stream and e["start"] >= 0:
                data = b"".join(mini_stream[s * self.mini_size:(s + 1) * self.mini_size] for s in self.chain(e["start"], mini_fat))
            else:
                data = self.read_chain(e["start"])
            out[e["name"]] = data[:e["size"]]
        return out


# ---------------- text-run extraction (mirrors the studio heuristic) ----------------
def utf16_runs(buf):
    runs = []
    i = 0
    n = len(buf)
    while i + 4 <= n:
        # record prefix seen in real files: FF FE FF <len u8> <len UTF-16LE chars>
        if buf[i] == 0xFF and buf[i + 1] == 0xFE and i + 4 <= n:
            ln = buf[i + 3]
            off = i + 4
            if 1 <= ln <= 400 and off + ln * 2 <= n:
                s = buf[off:off + ln * 2].decode("utf-16-le", "replace")
                if sum(1 for c in s if 0x20 <= ord(c) <= 0x7E) >= max(2, ln // 2):
                    runs.append((i, "BOM16", s))
                    i = off + ln * 2
                    continue
        i += 1
    return runs


def mode_tags(path):
    data = open(path, "rb").read()
    print("file", path, len(data), "bytes")
    for tag in ("PARTPROG", "DEFINE VIEWSET", "FILE HEADER", "LOAD PROBE", "SET ACTIVE TIP"):
        pat = tag.encode("utf-16-le")
        idxs = [m.start() for m in re.finditer(re.escape(pat), data)][:6]
        print(f"\n=== {tag}: {len(idxs)} hits (utf16) ===")
        for off in idxs:
            print(f"  @0x{off:x}")
            # dump neighbouring UTF-16 strings
            lo, hi = max(0, off - 8192), min(len(data), off + 8192)
            win = data[lo:hi]
            strs = re.findall(rb"(?:[\x20-\x7e]\x00){4,}", win)
            seen = []
            for s in strs:
                t = s.decode("utf-16-le", "replace")
                if t not in seen:
                    seen.append(t)
            print("   neighbours:", " | ".join(seen[:60]))


def mode_prg(path):
    data = open(path, "rb").read()
    print("file", path, len(data), "bytes")
    cfb = Cfb(data)
    st = cfb.streams()
    print("streams:")
    for k, v in st.items():
        print(f"   {k:<24} {len(v)} bytes")
    for name in ("PARTPROG", "MODS", "NAME"):
        if name not in st:
            continue
        buf = st[name]
        runs = utf16_runs(buf)
        print(f"\n=== {name}: {len(buf)} bytes, {len(runs)} BOM-text runs ===")
        for (off, kind, s) in runs[:120]:
            print(f"  0x{off:06x} {kind} {s!r}")
            print(f"        next 64B: {buf[off + 4 + len(s) * 2: off + 4 + len(s) * 2 + 64].hex(' ')}")
    if "PARTPROG" in st:
        buf = st["PARTPROG"]
        print("\n=== PARTPROG head 512 bytes ===")
        print(buf[:512].hex(" "))


def mode_sum(path, top=60):
    """Frequency table of PARTPROG text records + stream inventory."""
    from collections import Counter
    data = open(path, "rb").read()
    print("file", path, len(data), "bytes")
    cfb = Cfb(data)
    st = cfb.streams()
    for k, v in sorted(st.items(), key=lambda kv: -len(kv[1])):
        print(f"   stream {k:<24} {len(v):>12} bytes")
    for name in ("PARTPROG", "SUBROUTINES"):
        if name not in st:
            continue
        buf = st[name]
        runs = utf16_runs(buf)
        cnt = Counter(s for _, _, s in runs)
        print(f"\n=== {name}: {len(buf)} B, {len(runs)} text runs, {len(cnt)} distinct ===")
        for s, c in cnt.most_common(top):
            print(f"  {c:6d}  {s[:90]!r}")
        tails = buf.count(b"\xff\xff\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00")
        print(f"  record trailers (ff ff + 12 x 00): {tails}")
    if "NAME" in st:
        print("\nNAME stream:", st["NAME"][:256])


TRAILER = b"\xff\xff" + b"\x00" * 12


def mode_seg(path, examples=3):
    """Split PARTPROG by the ff ff + 12*00 trailer, show size histogram + example records."""
    from collections import Counter
    data = open(path, "rb").read()
    buf = Cfb(data).streams().get("PARTPROG", b"")
    print(f"PARTPROG {len(buf)} bytes")
    marks = []
    start = 0
    while True:
        i = buf.find(TRAILER, start)
        if i < 0:
            break
        marks.append(i)
        start = i + len(TRAILER)
    print(f"trailer hits: {len(marks)}")
    if not marks:
        return
    recs = []
    prev = 0
    for m in marks:
        end = m + len(TRAILER)
        recs.append(buf[prev:end])
        prev = end
    if prev < len(buf):
        recs.append(buf[prev:])
    sizes = Counter(len(r) for r in recs)
    print("\nsize histogram (top 30):")
    for size, c in sizes.most_common(30):
        print(f"  {size:6d} B x {c}")
    print(f"  distinct sizes: {len(sizes)}, min={min(sizes)}, max={max(sizes)}")

    def dump(rec, label):
        print(f"\n--- {label}: {len(rec)} B ---")
        head = rec[:192]
        for off in range(0, len(head) - 3, 4):
            u32 = struct.unpack_from("<I", head, off)[0]
            i32 = struct.unpack_from("<i", head, off)[0]
            f32 = struct.unpack_from("<f", head, off)[0]
            extra = ""
            if off + 8 <= len(head):
                f64 = struct.unpack_from("<d", head, off)[0]
                if f64 == f64 and abs(f64) < 1e7 and abs(f64) > 1e-3:
                    extra = f" d={f64:.6g}"
            print(f"   +{off:3d}: u32={u32:<12} i32={i32:<12} f32={f32:<12.5g}{extra}")

    common = [s for s, _ in sizes.most_common(20) if s >= 16][:examples]
    for size in common:
        for r in recs:
            if len(r) == size:
                dump(r, f"record size {size}")
                break
    print("\nfirst 6 records (hex, first 96 B):")
    for r in recs[:6]:
        print(f"  len={len(r):5d}  {r[:96].hex(' ')}")


def plausible_doubles(rec, lo=1e-3, hi=1e5):
    out = []
    for off in range(0, min(len(rec) - 7, 512)):
        v = struct.unpack_from("<d", rec, off)[0]
        if v == v and lo <= abs(v) <= hi:
            out.append((off, v))
    return out


def mode_rec(path):
    """Dump the most common record size: hex + plausible double offsets."""
    from collections import Counter
    data = open(path, "rb").read()
    buf = Cfb(data).streams().get("PARTPROG", b"")
    marks, start = [], 0
    while True:
        i = buf.find(TRAILER, start)
        if i < 0:
            break
        marks.append(i)
        start = i + len(TRAILER)
    recs, prev = [], 0
    for m in marks:
        recs.append(buf[prev:m + len(TRAILER)])
        prev = m + len(TRAILER)
    sizes = Counter(len(r) for r in recs)
    size, count = sizes.most_common(1)[0]
    print(f"dominant record size {size} B x {count}")
    shown = 0
    for idx, r in enumerate(recs):
        if len(r) != size:
            continue
        print(f"\n########## record #{idx} (len {len(r)}) ##########")
        for off in range(0, len(r), 16):
            chunk = r[off:off + 16]
            print(f"  {off:04x}  {chunk.hex(' '):<48}  " +
                  "".join(chr(c) if 32 <= c < 127 else "." for c in chunk))
        print("  plausible doubles:")
        for off, v in plausible_doubles(r):
            print(f"     +{off:3d}: {v:.9g}")
        shown += 1
        if shown >= 3:
            break


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    if sys.argv[1] == "tags":
        mode_tags(sys.argv[2])
    elif sys.argv[1] == "sum":
        mode_sum(sys.argv[2])
    elif sys.argv[1] == "seg":
        mode_seg(sys.argv[2])
    elif sys.argv[1] == "rec":
        mode_rec(sys.argv[2])
    else:
        mode_prg(sys.argv[2])
