"""Extract position/diameter element records from real PARTPROG streams.

Field offsets are tail-relative (verified against the PC-DMIS report):

    end-591  X (nominal point)
    end-539  Y
    end-503  Z
    end-68   nominal diameter      <- cross-checked against the D<value> in the name
    end-60   measured diameter
    end-26   diameter deviation

Every record is self-checked: the nominal diameter parsed from the element name
(D12.1_... -> 12.1) must equal the double at end-68, otherwise the record is
skipped and counted as "layout mismatch" instead of emitting wrong data.
"""
import csv
import re
import struct
import sys
from collections import Counter

sys.path.insert(0, r"C:\Workspace\3d\tools\prg")
from probe_prg import Cfb, TRAILER

NAME_RE = re.compile(r"^(?:INTR_|POS_)?D(\d+(?:\.\d+)?)[_A-Za-z]*", re.IGNORECASE)
OFF_X, OFF_Y, OFF_Z, OFF_NOM, OFF_ACT, OFF_DEV = 591, 539, 503, 68, 60, 26

# Field positions differ per record family.  Both offsets below are measured from the
# END of the record, because the head of a record contains variable-length strings.
#   pos/diameter family (INTR_/POS_): nominal diameter end-68, measured diameter end-60
#     -> verified against the PC-DMIS report for INTR_D12.1_T34_1/T34_2
#   cylinder family (D<n>_...):       nominal diameter end-382, radius end-86
#     -> verified only by the nominal encoded in the element name
PROFILES = [
    # pos/diameter family: same 36-byte axis blocks, but shifted because this command's
    # head is shorter.  Anchors: INTR_D12.1_T34_2 (report Y 960.000, Z 137.500) -> +122/+158;
    # validated on records of 661 B only, so coordinates are marked accordingly.
    {"id": "pos_dia", "match": re.compile(r"^(?:INTR_|POS_)", re.IGNORECASE),
     "nom": 68, "act": 60, "extra": (),
     "axes": (("X", 86), ("Y", 122), ("Z", 158)), "axes_note": "anchors: 661 B records"},
    # cylinder family: nominal diameter end-382 (D18_P17 -> 18.0, report "18.000");
    # nominal X at record+272 and nominal Z at record+344, both verified against the
    # report for D18_P17 (report X -100.300, Z -81.500) and consistent with the field
    # map of the 1171-byte cylinder records (272 -> -107.5, 344 -> 112.5).
    # three 36-byte axis blocks; the nominal sits in the third double of each block:
    #   X +272, Y +308, Z +344   -- verified twice against the PC-DMIS reports:
    #   D18_P17 (op77.80): report X -100.300, Z -81.500  -> +272, +344
    #   D9_K1_3 (op80):    report Y 434.910, Z 25.350    -> +308, +344
    {"id": "cylinder", "match": re.compile(r"^D\d", re.IGNORECASE),
     "nom": 382, "act": None, "extra": (),
     "axes": (("X", 272), ("Y", 308), ("Z", 344)), "requires_cmd": "CYL"},
]


def walk(path):
    buf = Cfb(open(path, "rb").read()).streams()["PARTPROG"]
    marks, start = [], 0
    while True:
        i = buf.find(TRAILER, start)
        if i < 0:
            break
        marks.append(i)
        start = i + len(TRAILER)
    recs, prev = [], 14
    for m in marks:
        recs.append(buf[prev:m + len(TRAILER)])
        prev = m + len(TRAILER)
    return recs


def strings_of(rec):
    """[(offset, text)] of every marker-framed string in the record."""
    out, p = [], 0
    while True:
        i = rec.find(b"\xff\xfe\xff", p)
        if i < 0:
            break
        p = i + 1
        ln = rec[i + 3]
        if ln and i + 4 + ln * 2 <= len(rec):
            out.append((i, rec[i + 4:i + 4 + ln * 2].decode("utf-16-le", "replace")))
    return out


CYL_CMD = "ЦИЛИНДР ( КОНТАКТ )"


def norm(s):
    return " ".join(s.replace("\xa0", " ").split())


def dbl(rec, from_end):
    off = len(rec) - from_end
    if off < 0 or off + 8 > len(rec):
        return None
    v = struct.unpack_from("<d", rec, off)[0]
    return v if v == v else None


def process(path, rows, stats):
    for idx, rec in enumerate(walk(path)):
        if len(rec) < 300:
            continue
        strs = strings_of(rec)
        cmd_off = None
        for off, t in strs:
            if norm(t) == CYL_CMD:
                cmd_off = off
                break
        for s in (t for _, t in strs):
            m = NAME_RE.match(s)
            if not m:
                continue
            nominal_name = float(m.group(1))
            for prof in PROFILES:
                if not prof["match"].match(s):
                    continue
                if prof.get("requires_cmd") and cmd_off is None:
                    # this profile's field layout belongs to that command only
                    continue
                nom = dbl(rec, prof["nom"])
                # self-check: the nominal field must equal the number in the element name
                if nom is None or abs(abs(nom) - nominal_name) > max(1e-9, nominal_name * 1e-9):
                    continue
                act = dbl(rec, prof["act"]) if prof["act"] else None
                if act is not None and not (nominal_name * 0.5 <= abs(act) <= nominal_name * 1.5):
                    act = None
                extra = {name: dbl(rec, fr) for name, fr in prof["extra"]}


                def coord(fr):
                    v = dbl(rec, fr)
                    return v if (v is not None and 1e-3 <= abs(v) <= 5000) else None

                def coord_abs(off):
                    """plausible double at an absolute offset from the record start"""
                    if off < 0 or off + 8 > len(rec):
                        return None
                    v = struct.unpack_from("<d", rec, off)[0]
                    return v if (v == v and 1e-3 <= abs(v) <= 5000) else None

                if prof.get("axes"):
                    ax = {name: coord_abs(fr) for name, fr in prof["axes"]}
                    xs, ys, zs = ax.get("X"), ax.get("Y"), ax.get("Z")
                    n_ok = sum(1 for v in (xs, ys, zs) if v is not None)
                    pos_ok = n_ok >= 2
                    if not pos_ok:
                        pos_flag = "unconfirmed"
                    elif prof["id"] == "cylinder":
                        pos_flag = "family-verified"          # 2 report anchors
                    else:
                        pos_flag = prof.get("axes_note", "profile-offsets")
                else:
                    xs, ys, zs = coord(OFF_X), coord(OFF_Y), coord(OFF_Z)
                    pos_ok = xs is not None and ys is not None and zs is not None
                    pos_flag = "yes" if pos_ok else "unconfirmed"
                stats["ok"] += 1
                stats["by_profile"][prof["id"]] += 1
                stats["sizes"][len(rec)] += 1
                stats["xyz_ok" if pos_ok else "xyz_partial"] += 1
                row = {
                    "file": path.rsplit("\\", 1)[-1],
                    "record": idx,
                    "profile": prof["id"],
                    "element": s,
                    "size": len(rec),
                    "X": xs,
                    "Y": ys,
                    "Z": zs,
                    "pos_fields_ok": pos_flag,
                    "nominal_d": nom,
                    "measured_d": act,
                    "dev_calc": None if act is None else act - nom,
                }
                for name, v in extra.items():
                    row[name] = v
                rows.append(row)
                break
            else:
                stats["mismatch"] += 1
            break


def main(paths, out_csv):
    rows, stats = [], {"ok": 0, "mismatch": 0, "xyz_ok": 0, "xyz_partial": 0,
                       "sizes": Counter(), "by_profile": Counter()}
    for p in paths:
        try:
            process(p, rows, stats)
            print(f"scanned {p.rsplit(chr(92), 1)[-1]}")
        except Exception as exc:
            print(f"failed {p}: {exc}")
    fields = ["file", "record", "profile", "element", "size", "X", "Y", "Z",
              "pos_fields_ok", "nominal_d", "measured_d", "dev_calc", "radius"]
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f"\nextracted {stats['ok']} records, {stats['mismatch']} layout mismatches")
    print("by profile:", dict(stats["by_profile"]))
    print("coords confirmed:", stats["xyz_ok"], "| unconfirmed:", stats["xyz_partial"])
    print("record sizes:", stats["sizes"].most_common(8))
    print("written:", out_csv)


if __name__ == "__main__":
    base = r"C:\Users\diibl\Downloads\Головка\Головка\Не обкатаны"
    ops = ["op5.10.20", "op30.60", "op40.50", "op70", "op77.80", "op80"]
    import os
    paths = []
    for op in ops:
        d = os.path.join(base, op)
        if not os.path.isdir(d):
            continue
        for fn in os.listdir(d):
            if fn.upper().endswith(".PRG"):
                paths.append(os.path.join(d, fn))
    main(paths, r"C:\Workspace\3d\prg-elements.csv")
