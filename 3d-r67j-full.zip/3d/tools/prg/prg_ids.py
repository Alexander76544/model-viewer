"""Histogram of candidate record-type fields in a real PARTPROG stream."""
import struct
import sys
from collections import Counter

sys.path.insert(0, r"C:\Workspace\3d\tools\prg")
from probe_prg import Cfb, TRAILER

PATH = sys.argv[1] if len(sys.argv) > 1 else \
    r"C:\Users\diibl\Downloads\Головка\Головка\Не обкатаны\op40.50\770.1003014_op40.50.PRG"

buf = Cfb(open(PATH, "rb").read()).streams()["PARTPROG"]
print("PARTPROG bytes:", len(buf))

marks, start = [], 0
while True:
    i = buf.find(TRAILER, start)
    if i < 0:
        break
    marks.append(i)
    start = i + len(TRAILER)
print("records (split by trailer):", len(marks))

prev = 14  # skip the 14-byte stream header
sizes, a16, b32, c32 = Counter(), Counter(), Counter(), Counter()
for m in marks:
    rec = buf[prev:m + len(TRAILER)]
    sizes[len(rec)] += 1
    if len(rec) >= 56:
        a16[struct.unpack_from("<H", rec, len(rec) - 50)[0]] += 1
        b32[struct.unpack_from("<I", rec, len(rec) - 4)[0]] += 1
        c32[struct.unpack_from("<I", rec, len(rec) - 52)[0]] += 1
    prev = m + len(TRAILER)

print("\nrecord sizes (top 12):")
for s, c in sizes.most_common(12):
    print(f"   {s:6d} B x {c}")
print("\nu16 at (end-50) top 20:")
for v, c in a16.most_common(20):
    print(f"   0x{v:04x} ({v:5d}) x {c}")
print("\nu32 at (end-52) top 20:")
for v, c in c32.most_common(20):
    print(f"   0x{v:08x} ({v}) x {c}")
print("\nu32 at (end-4) top 12:")
for v, c in b32.most_common(12):
    print(f"   0x{v:08x} ({v}) x {c}")
print("\ndistinct: sizes", len(sizes), "| u16", len(a16),
      "| u32-52", len(c32), "| u32end", len(b32))
