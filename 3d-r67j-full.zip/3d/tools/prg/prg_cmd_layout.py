"""Per-command field map for real PARTPROG streams.

Groups records by their command-name string and, inside each group, looks for
offsets that behave like geometry fields (8 aligned doubles that are plausible
for most records) and offsets that are constant (flags / type ids).
"""
import struct
import sys
from collections import defaultdict

sys.path.insert(0, r"C:\Workspace\3d\tools\prg")
from probe_prg import Cfb, TRAILER

RU_CMDS = [
    "Заголовок файла", "Задание вида", "ЗАПУСК", "Начало построения СК", "Конец СК",
    "Ручной режим", "Формат размера", "Температурная компенсация", "Загр. щуп",
    "Уст. активн. щуп", "Группа", "ПЛОСКОСТЬ ( КОНТАКТ )", "ЦИЛИНДР ( КОНТАКТ )",
    "ОКРУЖНОСТЬ ( КОНТАКТ )", "ТОЧКА ( КОНТАКТ )", "ЛИНИЯ ( КОНТАКТ )", "КОНУС ( КОНТАКТ )",
    "Выполнить замер", "Перемещение", "Позиционирование", "ВЫРАВНИВАНИЕ",
]


def walk(path):
    buf = Cfb(open(path, "rb").read()).streams()["PARTPROG"]
    marks, start = [], 0
    while True:
        i = buf.find(TRAILER, start)
        if i < 0:
            break
        marks.append(i)
        start = i + len(TRAILER)
    recs, prev = [], 14
    for m in marks:
        recs.append(buf[prev:m + len(TRAILER)])
        prev = m + len(TRAILER)
    return buf, recs


def cmd_of(rec):
    p = 0
    while True:
        i = rec.find(b"\xff\xfe\xff", p)
        if i < 0:
            return None, -1
        p = i + 1
        ln = rec[i + 3]
        if not ln or i + 4 + ln * 2 > len(rec):
            continue
        s = rec[i + 4:i + 4 + ln * 2].decode("utf-16-le", "replace")
        # the stream uses U+00A0 inside command names ("ПЛОСКОСТЬ ( КОНТАКТ )")
        norm = " ".join(s.replace("\xa0", " ").split())
        for c in RU_CMDS:
            if norm == c:
                return c, i
    return None, -1


def main(path, out_path):
    buf, recs = walk(path)
    groups = defaultdict(list)
    for r in recs:
        c, off = cmd_of(r)
        if c:
            groups[c].append((r, off))

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(f"file: {path}\nrecords: {len(recs)}\n")
        f.write("\ncommand groups:\n")
        for c, lst in sorted(groups.items(), key=lambda kv: -len(kv[1])):
            f.write(f"  {len(lst):6d}  {c}\n")

        for c, lst in sorted(groups.items(), key=lambda kv: -len(kv[1])):
            if len(lst) < 8:
                continue
            sizes = defaultdict(int)
            for r, _ in lst:
                sizes[len(r)] += 1
            size = max(sizes, key=sizes.get)
            same = [r for r, _ in lst if len(r) == size][:300]
            f.write(f"\n=== {c} :: {len(same)} records of {size} B ===\n")

            # offsets where an aligned double is plausible in >= 80% of records
            good = []
            for off in range(0, size - 7, 4):
                ok = 0
                for r in same:
                    v = struct.unpack_from("<d", r, off)[0]
                    if v == v and 1e-6 <= abs(v) <= 1e6:
                        ok += 1
                if ok >= 0.8 * len(same):
                    good.append(off)
            # merge adjacent offsets into blocks
            blocks = []
            for off in good:
                if blocks and off - blocks[-1][1] == 4:
                    blocks[-1][1] = off
                else:
                    blocks.append([off, off])
            for a, b in blocks:
                sample = struct.unpack_from("<d", same[0], a)[0]
                f.write(f"  field {a:4d}..{b + 7:4d}  first value {sample:.6g}\n")
            # constant byte blocks
            consts = []
            for off in range(size):
                vals = {r[off] for r in same}
                if len(vals) == 1:
                    consts.append((off, next(iter(vals))))
            run = []
            for off, v in consts:
                if run and off == run[-1][0] + 1 and v == run[-1][1]:
                    run[-1][0] = off
                else:
                    run.append([off, v])
            f.write("  constant blocks: " +
                    ", ".join(f"{a}-{v:02x}" if False else f"{o}..{o}" for o, v in run[:0]) + "\n")
            txt = []
            for o, v in consts:
                txt.append(f"{o}:{v:02x}")
            f.write("  const bytes: " + " ".join(txt[:80]) + "\n")
    print("written:", out_path)


if __name__ == "__main__":
    p = sys.argv[1] if len(sys.argv) > 1 else \
        r"C:\Users\diibl\Downloads\Головка\Головка\Не обкатаны\op40.50\770.1003014_op40.50.PRG"
    o = sys.argv[2] if len(sys.argv) > 2 else r"C:\Workspace\3d\prg-cmd-layout.txt"
    main(p, o)
