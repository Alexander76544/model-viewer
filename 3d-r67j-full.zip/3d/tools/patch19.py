P='/data/in/fullpkg/3d/prg-commands.js'
s=open(P,encoding='utf-8').read()
assert 'r67b hits' not in s
old="  var KIND = {"
add=r'''  /* r67b hits: касания внутри автоэлемента — записи фикс. длины (в op5: 308 Б):
     X Y Z I J K (double) + служебные поля; перед каждой — 16-байтный идентификатор + пустая CString. */
  function unitAt(b, o) {
    var i = dbl(b, o), j = dbl(b, o + 8), k = dbl(b, o + 16);
    if (i === null || j === null || k === null) return false;
    var l = i * i + j * j + k * k; return Math.abs(l - 1) < 2e-6 && (i !== 0 || j !== 0 || k !== 0);
  }
  function xyzOk(b, o) { for (var c = 0; c < 3; c++) { var v = dbl(b, o + c * 8); if (v === null || Math.abs(v) > 1e5 || (v !== 0 && Math.abs(v) < 1e-9)) return false; } return true; }
  function readHits(b, from, end, near, maxPts) {
    for (var o = from; o + 48 < end; o++) {
      if (b[o + 31] !== 0xbf && b[o + 31] !== 0x3f && b[o + 47] !== 0xbf && b[o + 47] !== 0x3f && b[o + 39] !== 0xbf && b[o + 39] !== 0x3f) continue;
      if (!unitAt(b, o + 24) || !xyzOk(b, o)) continue;
      var x = dbl(b, o), y = dbl(b, o + 8), z = dbl(b, o + 16);
      if (near && Math.hypot(x - near[0], y - near[1], z - near[2]) > near[3]) continue;
      for (var S = 64; S <= 700; S++) {
        if (o + S + 48 > end || !unitAt(b, o + S + 24) || !xyzOk(b, o + S)) continue;
        var pts = [], p = o;
        while (p + 48 <= end && unitAt(b, p + 24) && xyzOk(b, p) && pts.length < maxPts) {
          pts.push([r3(dbl(b, p)), r3(dbl(b, p + 8)), r3(dbl(b, p + 16)), Math.round(dbl(b, p + 24) * 1e6) / 1e6, Math.round(dbl(b, p + 32) * 1e6) / 1e6, Math.round(dbl(b, p + 40) * 1e6) / 1e6]);
          p += S;
        }
        var total = pts.length; while (p + 48 <= end && unitAt(b, p + 24) && xyzOk(b, p)) { total++; p += S; }
        if (total >= 2) return { stride: S, at: o, count: total, pts: pts };
      }
    }
    return null;
  }

'''
s=s.replace(old,add+old,1)
old2="        if (f) { f.kind = KIND[ac] || 'point';"
assert old2 in s
new2="""        if (f) {
          var nmOff = ss[1] ? c.q + ss[1].off : c.q;
          var rad = Math.max(50, (f.diam || 0) * 2 + 50);
          var h = readHits(part, nmOff + 600, c.q + c.len, [f.X, f.Y, f.Z, f.kind === 'plane' ? 5000 : rad], 2000);
          if (h) { f.hits = h.pts; f.hitCount = h.count; f.hitStride = h.stride; }
          f.kind = KIND[ac] || 'point';"""
s=s.replace(old2,new2,1)
s=s.replace("      if (f) s += '   X' + f.X","      if (f && f.hitCount) s += '   [касаний ' + f.hitCount + ']';\n      if (f) s += '   X' + f.X",1)
open(P,'w',encoding='utf-8').write(s)

P2='/data/in/fullpkg/3d/prg-real-import.js'
t=open(P2,encoding='utf-8').read()
old3="          if (f.diam !== null) vals.diam = num(f.diam);"
assert old3 in t
t=t.replace(old3,old3+"\n          if (f.hitCount) { vals._hits = f.hits; vals._hitCount = f.hitCount; if (f.hitCount <= 200) vals.points = String(f.hitCount); }",1)
open(P2,'w',encoding='utf-8').write(t)
print('ok')
