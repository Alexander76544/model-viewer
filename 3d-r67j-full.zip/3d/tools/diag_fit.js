const fs = require('fs');
const html = fs.readFileSync('C:/Workspace/3d/pcdmis-generator-6.html', 'utf8');
const re = /<script\b([^>]*)>([\s\S]*?)<\/script>/gi;
let m, i = 0, code = '';
while ((m = re.exec(html)) !== null) { i++; if (i === 10) code = m[2]; }
// инжект-экспорт внутренних функций (перед закрытием RE-IIFE — предпоследнее "})();")
let lastClose = code.lastIndexOf('})();');
let secondLast = code.lastIndexOf('})();', lastClose - 1);
code = code.slice(0, secondLast) + 'window.__dbg={eig3:eig3,solveLin:solveLin,covariance:covariance,fitCircle2D:fitCircle2D};\n' + code.slice(secondLast);
const fakeEl = () => ({ style: {}, setAttribute() {}, appendChild() {}, addEventListener() {}, querySelector() { return null; }, querySelectorAll() { return []; } });
global.window = {};
global.document = { addEventListener() {}, getElementById: () => null, createElement: () => fakeEl(), body: { appendChild() {} }, head: { appendChild() {} } };
eval(code);
const D = global.window.__dbg;

// 1) solveLin: 2x2 x + y = 1; 2x - y = 4 → x=5/3, y=-2/3
let r = D.solveLin([[1,1],[2,-1]],[1,4]);
console.log('solveLin 2x2:', r, 'expected [1.6667,-0.6667]');
// 3x3 identity-like
r = D.solveLin([[2,1,1],[1,3,2],[1,0,0]],[4,10,1]);
console.log('solveLin 3x3:', r, 'expected [1,2,3]');
// 4x4
r = D.solveLin([[1,0,0,0],[0,2,0,0],[0,0,3,0],[0,0,0,4]],[1,4,9,16]);
console.log('solveLin 4x4:', r, 'expected [1,2,3,4]');

// 2) eig3: diag(3,1,2) → values 3,2,1; evecs = axes
let e = D.eig3([[3,0,0],[0,1,0],[0,0,2]]);
console.log('eig3 diag values:', e.values.map(v=>v.toFixed(4)));
console.log('eig3 diag vectors:', e.vectors.map(v=>[v.x.toFixed(3),v.y.toFixed(3),v.z.toFixed(3)]));
// eig3: symmetric mixed
const S2=[[2,1,0],[1,2,0],[0,0,3]];
e = D.eig3(S2);
console.log('eig3 mixed values:', e.values.map(v=>v.toFixed(4)), '(expected 4,1,3 → sorted 4,3,1)');
e.vectors.forEach((v,k)=>{
  // проверка S·v = λ·v
  const Sv={ x:S2[0][0]*v.x+S2[0][1]*v.y+S2[0][2]*v.z, y:S2[1][0]*v.x+S2[1][1]*v.y+S2[1][2]*v.z, z:S2[2][0]*v.x+S2[2][1]*v.y+S2[2][2]*v.z };
  const ok = Math.abs(Sv.x-e.values[k]*v.x)<1e-9 && Math.abs(Sv.y-e.values[k]*v.y)<1e-9 && Math.abs(Sv.z-e.values[k]*v.z)<1e-9;
  console.log('  vec'+k, v.x.toFixed(3), v.y.toFixed(3), v.z.toFixed(3), 'eig check:', ok);
});
// 3) fitCircle2D: окружность (1,2) R=3
const px=[],py=[];
for(let a=0;a<24;a++){ const t=2*Math.PI*a/24; px.push(1+3*Math.cos(t)); py.push(2+3*Math.sin(t)); }
let c = D.fitCircle2D(px,py);
console.log('circle2D:', c, 'expected c=(1,2) R=3');
