const fx=require('../prg-fixture.js');const fs=require('fs');
const j=JSON.parse(fs.readFileSync('/data/out/fixture-pkg/osnastka.qfxt.json'));fx.json=j;
function bb(file){const b=fs.readFileSync(file);const n=b.readUInt32LE(80);const p=new Float32Array(n*9);let o=84;for(let i=0;i<n;i++){o+=12;for(let k=0;k<9;k++){p[i*9+k]=b.readFloatLE(o);o+=4;}o+=2;}
const c=fx.toCad(p,j);let mn=[1e9,1e9,1e9],mx=[-1e9,-1e9,-1e9];for(let i=0;i<c.length;i+=3)for(let a=0;a<3;a++){mn[a]=Math.min(mn[a],c[i+a]);mx[a]=Math.max(mx[a],c[i+a]);}return mn.map(v=>v.toFixed(1))+' .. '+mx.map(v=>v.toFixed(1));}
console.log('fixture',bb('/data/out/fixture-pkg/osnastka.stl'));console.log('part   ',bb('/data/out/fixture-pkg/detal-na-osnastke.stl'));console.log(fx.pcdmisText());
