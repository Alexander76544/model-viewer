
/* =====================================================================
   r53 (часть 4) — FeatureTools (извлечение фич из CAD) ·
   WAI (оптический щуп: настройка + виртуальный скан) ·
   облако точек в 3D-вьювере (для reverse engineering).
   Оригинальная реализация; геометрия — из собственного каталога фич
   приложения (nvAlignCollectFeatures / faceCatalog3 / snaps3).
   ===================================================================== */
(function(){
"use strict";
function $(id){ return document.getElementById(id); }
function st(){ try{ return (typeof state!=="undefined" && state) ? state : null; }catch(e){ return null; } }
function cur(){ const p=st(); if(!p) throw new Error("нет активной операции"); return p; }
function reRender(){
  try{ if(typeof renderElementsList==="function") renderElementsList(); }catch(e){}
  try{ if(typeof renderDimensionsList==="function") renderDimensionsList(); }catch(e){}
  try{ if(typeof refreshStatus==="function") refreshStatus(); }catch(e){}
  try{ if(typeof renderOutput==="function") renderOutput(); }catch(e){}
  try{ if(window.pcdRefreshProg) window.pcdRefreshProg(); }catch(e){}
  try{ if(typeof scheduleAutosave==="function") scheduleAutosave(); }catch(e){}
  try{ if(typeof refreshThreeIfNeeded==="function") refreshThreeIfNeeded(); }catch(e){}
}
function toast(msg){
  var t=$("__pcdToast");
  if(!t){ t=document.createElement("div"); t.id="__pcdToast"; document.body.appendChild(t); }
  t.textContent=msg; t.style.display="block";
  var prev=t.__tm; if(prev) clearTimeout(prev);
  t.__tm=setTimeout(function(){ t.style.display="none"; }, 4200);
}
function dlg(opts){
  var ov=document.createElement("div"); ov.className="pcd-dlg-overlay";
  var box=document.createElement("div"); box.className="pcd-dlg";
  if(opts.width) box.style.width=opts.width+"px";
  var hd=document.createElement("div"); hd.className="pcd-dlg-hd";
  hd.appendChild(document.createTextNode(opts.title));
  var x=document.createElement("span"); x.className="x"; x.textContent="✕"; x.title="Закрыть (Esc)";
  x.addEventListener("click",function(){ close(); });
  hd.appendChild(x);
  var bd=document.createElement("div"); bd.className="pcd-dlg-bd";
  if(opts.body) bd.appendChild(opts.body);
  var ft=document.createElement("div"); ft.className="pcd-dlg-ft";
  (opts.footer||[]).forEach(function(f){
    var b=document.createElement("button"); b.className="btn2"+(f.cls?" "+f.cls:""); b.textContent=f.label;
    b.addEventListener("click",function(){ if(f.onClick) f.onClick(box, ft); });
    ft.appendChild(b);
  });
  box.appendChild(hd); box.appendChild(bd); box.appendChild(ft);
  ov.appendChild(box);
  function close(){ try{ ov.remove(); }catch(e){} document.removeEventListener("keydown",onKey,true); }
  function onKey(ev){ if(ev.key==="Escape") close(); }
  ov.addEventListener("mousedown",function(ev){ if(ev.target===ov) close(); });
  document.addEventListener("keydown",onKey,true);
  document.body.appendChild(ov);
  return { root:ov, box:box, body:bd, close:close };
}
function mk(tag, attrs, html){
  var e=document.createElement(tag);
  if(attrs) Object.keys(attrs).forEach(function(k){ if(k==="class") e.className=attrs[k]; else e.setAttribute(k,attrs[k]); });
  if(html!=null) e.innerHTML=html;
  return e;
}
function fld(label, input){ var w=mk("div",{"class":"fld"}); w.innerHTML=label; w.appendChild(input); return w; }
/* part-координаты из фичи каталога (three y<->z) */
function featPart(f){
  return {
    p:{ x:f.p.x, y:f.p.z, z:f.p.y },
    w:{ x:f.w.x, y:f.w.z, z:f.w.y },
    r:f.r||0, h:f.h||0, a:f.a||0, k:f.k
  };
}
/* базовый элемент — та же схема полей, что у автоплана приложения */
function mkBaseEl(type, name, p, w, extra){
  var num=function(x){ return String(Math.round(x*1000)/1000); };
  var e={
    id:(typeof uid==="function")?uid():"e"+Math.random().toString(36).slice(2), type:type, name:name, group:"",
    x:num(p.x), y:num(p.y), z:num(p.z), i:num(w.x), j:num(w.y), k:num(w.z),
    diam:"10", depth:"10",
    strategy:"ПО_УМОЛЧ.", entry:"ВХОД", points:"4", rows:"3", layers:"2", depthParam:"2",
    finishOffset:"5", step:"0", avoidBefore:"0", avoidAfter:"10",
    direction:"ПРОТИВ ЧАСОВОЙ", angleVec:"0,0,1", startAngle:"0", endAngle:"360",
    factSameAsNominal:true, hasTarget:true, factX:"", factY:"", factZ:"", factI:"", factJ:"", factK:"", factDiam:"", factDepth:"",
    open:true, extraLines:[]
  };
  Object.assign(e, extra||{});
  return e;
}
function freeName(p, base){
  var have={}; (p.elements||[]).forEach(function(e){ if(e&&e.name) have[e.name]=1; });
  var nm=base, i=1;
  while(have[nm]) nm=base+"_"+(++i+1);
  return nm;
}
window.__pcdMkBaseEl=mkBaseEl;
window.__pcdFreeName=freeName;

/* ---------- облако точек в 3D (part→three: (x, z, y)) ---------- */
var pointCloud3=null;
window.__pcdRebuildPointCloud3=function(){
  try{
    if(typeof scene3==="undefined" || !scene3 || typeof THREE==="undefined") return;
    if(pointCloud3){ try{ scene3.remove(pointCloud3); if(pointCloud3.geometry) pointCloud3.geometry.dispose(); if(pointCloud3.material) pointCloud3.material.dispose(); }catch(e){} pointCloud3=null; }
    var p=st(); var pc=p&&p.pointCloud;
    if(!pc || !pc.points || !pc.points.length) return;
    var pos=new Float32Array(pc.points.length*3);
    for(var i=0;i<pc.points.length;i++){ var pt=pc.points[i]; pos[i*3]=pt[0]; pos[i*3+1]=pt[2]; pos[i*3+2]=pt[1]; }
    var geo=new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(pos,3));
    var mat=new THREE.PointsMaterial({ size:1.8, color:0x35c4ff, sizeAttenuation:true, transparent:true, opacity:0.92 });
    pointCloud3=new THREE.Points(geo,mat);
    scene3.add(pointCloud3);
    try{ if(typeof proRenderHint3==="function") proRenderHint3(); }catch(e){}
  }catch(e){ try{ console.warn("pointCloud3:", e); }catch(_){} }
};

/* =====================================================================
   1. FEATURE TOOLS — извлечение фич из CAD (FeatureExtractor)
   ===================================================================== */
window.pcdFeatureToolsOpen=function(){
  var p=cur();
  var feats=[];
  try{ if(typeof nvAlignCollectFeatures==="function") feats=nvAlignCollectFeatures()||[]; }catch(e){}
  if(!feats.length){
    toast("Каталог фич пуст: загрузите модель (STEP — серверный разбор v5, либо STL + «📊 Анализ → Фичи») во вкладке «3D модель»");
    return;
  }
  var body=mk("div");
  body.innerHTML=
    '<div class="hint">Фичи взяты из каталога загруженной модели (плоскости и цилиндры с настоящими номиналами). '+
    'Отметьте фичи — они добавятся в текущую операцию как измеряемые элементы (Плоскость / Цилиндр с Ø и глубиной из CAD).</div>'+
    '<table class="t"><thead><tr><th style="width:26px;"></th><th>#</th><th>Тип</th><th>X</th><th>Y</th><th>Z</th><th>I</th><th>J</th><th>K</th><th>Ø / пл., мм²</th></tr></thead><tbody id="__ftRows"></tbody></table>'+
    '<div style="margin-top:10px;display:flex;gap:8px;">'+
      '<button class="btn2" id="__ftAll">Отметить все</button>'+
      '<button class="btn2" id="__ftNone">Снять все</button>'+
      '<span style="flex:1"></span>'+
      '<button class="btn2 prim" id="__ftAdd">＋ Добавить выбранные в операцию</button>'+
      '<button class="btn2" id="__ftAddGdt">＋ Добавить + Авто-GDT</button>'+
    '</div>';
  var tb=body.querySelector("#__ftRows");
  feats.forEach(function(f, idx){
    var fp=featPart(f);
    var tr=mk("tr");
    var ck=mk("input",{type:"checkbox"});
    var typeTxt = fp.k==="P" ? "Плоскость" : "Цилиндр";
    var extra = fp.k==="P" ? fp.a.toFixed(2) : (fp.r ? ("Ø"+(2*fp.r).toFixed(3)) : "—");
    tr.innerHTML='<td></td><td>'+(idx+1)+'</td><td><b>'+typeTxt+'</b></td>'+
      '<td>'+fp.p.x.toFixed(3)+'</td><td>'+fp.p.y.toFixed(3)+'</td><td>'+fp.p.z.toFixed(3)+'</td>'+
      '<td>'+fp.w.x.toFixed(3)+'</td><td>'+fp.w.y.toFixed(3)+'</td><td>'+fp.w.z.toFixed(3)+'</td>'+
      '<td>'+extra+'</td>';
    tr.firstChild.appendChild(ck);
    tr.__feat=fp;
    tb.appendChild(tr);
  });
  function addSelected(withGdt){
    var sel=Array.prototype.filter.call(tb.querySelectorAll("tr"),function(tr){ return tr.firstChild && tr.firstChild.firstChild && tr.firstChild.firstChild.checked; });
    if(!sel.length){ toast("Отметьте хотя бы одну фичу"); return; }
    var pi=0, ci=0;
    sel.forEach(function(tr){
      var f=tr.__feat;
      if(f.k==="P"){ pi++; p.elements.push(mkBaseEl("plane", freeName(p,"FT_PL"+pi), f.p, f.w)); }
      else { ci++; p.elements.push(mkBaseEl("cylinder", freeName(p,"FT_CYL"+ci), f.p, f.w,
          { diam:String(Math.round(f.r*2*1000)/1000), depth:String(Math.round((f.h||10)*1000)/1000) })); }
    });
    reRender();
    if(withGdt && typeof window.pcdAutoGdt==="function") setTimeout(function(){ try{ window.pcdAutoGdt(); }catch(e){} }, 60);
    toast("Из CAD добавлено элементов: "+(pi+ci)+" (плоскостей: "+pi+", цилиндров: "+ci+")");
  }
  var d=dlg({
    title:"Извлечение фич из CAD (FEATURE TOOLS) — "+feats.length+" фич в модели", width:860, body:body,
    footer:[
      {label:"＋ Добавить выбранные", cls:"", onClick:function(){ addSelected(false); }},
      {label:"＋ Добавить + Авто-GDT", cls:"", onClick:function(){ addSelected(true); }},
      {label:"Закрыть", cls:"prim", onClick:function(){ d.close(); }}
    ]
  });
  body.querySelector("#__ftAll").addEventListener("click",function(){ tb.querySelectorAll("input[type=checkbox]").forEach(function(c){ c.checked=true; }); });
  body.querySelector("#__ftNone").addEventListener("click",function(){ tb.querySelectorAll("input[type=checkbox]").forEach(function(c){ c.checked=false; }); });
  body.querySelector("#__ftAdd").addEventListener("click",function(){ addSelected(false); });
  body.querySelector("#__ftAddGdt").addEventListener("click",function(){ addSelected(true); });
};

/* =====================================================================
   2. WAI — ОПТИЧЕСКИЙ ЩУП: настройка + виртуальный скан (WAI_Probe)
   ===================================================================== */
var WAI_PROBES=["Optronis 400","Optronis 600","Confocal 2D","OptoScan"];
window.pcdWaiOpen=function(){
  var p=cur();
  p.waiCfg=p.waiCfg||{ probe:"Optronis 400", mode:"ПЛОЩАДКА", res:"0.1", fov:"100", trig:"ВНУТР.", sigma:"0.02" };
  var feats=[];
  try{ if(typeof nvAlignCollectFeatures==="function") feats=(nvAlignCollectFeatures()||[]).map(featPart); }catch(e){}
  var body=mk("div");
  body.innerHTML=
    '<div class="sect">Настройка оптического щупа (WAI)</div>'+
    '<div class="grid3">'+
      '<div class="fld"><span>Щуп</span><select id="__wProbe"></select></div>'+
      '<div class="fld"><span>Режим скана</span><select id="__wMode"><option>ПЛОЩАДКА</option><option>ЛИНИЯ</option><option>ТОЧКА</option></select></div>'+
      '<div class="fld"><span>Триггер</span><select id="__wTrig"><option>ВНУТР.</option><option>ВНЕШНИЙ</option></select></div>'+
    '</div>'+
    '<div class="grid3" style="margin-top:10px;">'+
      '<div class="fld"><span>Шаг (мм/точку)</span><input type="text" id="__wRes" maxlength="8"></div>'+
      '<div class="fld"><span>Поле (мм)</span><input type="text" id="__wFov" maxlength="8"></div>'+
      '<div class="fld"><span>Шум σ (мм) для виртуального скана</span><input type="text" id="__wSig" maxlength="8"></div>'+
    '</div>'+
    '<div class="sect" style="margin-top:14px;">Виртуальный скан по фичам CAD ('+feats.length+' фич) — результат: облако точек для Reverse Engineering</div>'+
    '<div id="__wFeatList" style="max-height:160px;overflow:auto;border:1px solid #eceef1;border-radius:4px;padding:8px;"></div>'+
    '<div class="hint">Виртуальный скан генерирует точки на поверхностях выбранных фич (сетка по площади / кольца по цилиндру) '+
    'с гауссовым шумом σ — как будто оптикой «прошлась» по детали. Точки попадают в облако (видно в 3D, синим) '+
    'и доступны в диалоге «Reverse engineering» для подгонки плоскости/цилиндра/сферы.</div>';
  function q(id){ return body.querySelector("#"+id); }
  var sp=q("__wProbe"); WAI_PROBES.forEach(function(x){ sp.appendChild(mk("option",{value:x},x)); }); sp.value=p.waiCfg.probe||WAI_PROBES[0];
  q("__wMode").value=p.waiCfg.mode||"ПЛОЩАДКА"; q("__wTrig").value=p.waiCfg.trig||"ВНУТР.";
  q("__wRes").value=p.waiCfg.res||"0.1"; q("__wFov").value=p.waiCfg.fov||"100"; q("__wSig").value=p.waiCfg.sigma||"0.02";
  var fl=q("__wFeatList");
  feats.forEach(function(f, idx){
    var lbl=mk("label",{"class":"chk",style:"display:flex;margin-bottom:4px;"});
    var ck=mk("input",{type:"checkbox",value:String(idx)});
    ck.checked = f.k==="P" ? (f.a>=1) : (f.r>0.5);
    var txt = (f.k==="P"?"Плоскость":"Цилиндр Ø"+(2*f.r).toFixed(2)) + " №"+(idx+1) + (f.a?(" · "+f.a.toFixed(1)+" мм²"):"");
    lbl.appendChild(ck); lbl.appendChild(document.createTextNode(" "+txt));
    fl.appendChild(lbl);
  });
  if(!feats.length) fl.appendChild(mk("div",{class:"hint"},"Каталог фич пуст — скан недоступен. Загрузите модель во вкладке «3D модель»."));
  /* детерминированный ГСЧ + гаусс (как у виртуального прогона) */
  function mulberry32(seed){ var a=(seed|0)>>>0; return function(){ a=(a+0x6D2B79F5)|0; var t=Math.imul(a^(a>>>15),1|a); t=(t^Math.imul(t^(t>>>7),61|t))^((t^(t>>>14))>>>0); return ((t^(t>>>14))>>>0)/4294967296; }; }
  function gauss(rng){ var u=0; while(u===0) u=rng(); return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*rng()); }
  function basis(n){
    var ax = Math.abs(n.x) < 0.9 ? {x:1,y:0,z:0} : {x:0,y:1,z:0};
    var u={ x:n.y*ax.z-n.z*ax.y, y:n.z*ax.x-n.x*ax.z, z:n.x*ax.y-n.y*ax.x };
    var lu=Math.sqrt(u.x*u.x+u.y*u.y+u.z*u.z)||1; u={x:u.x/lu,y:u.y/lu,z:u.z/lu};
    var v={ x:n.y*u.z-n.z*u.y, y:n.z*u.x-n.x*u.z, z:n.x*u.y-n.y*u.x };
    return [u,v];
  }
  function scan(){
    var sel=Array.prototype.filter.call(fl.querySelectorAll("input[type=checkbox]"),function(c){ return c.checked; });
    if(!sel.length){ toast("Отметьте фичи для скана"); return; }
    var res=parseFloat(q("__wRes").value.replace(",", "."))||0.1;
    var sig=parseFloat(q("__wSig").value.replace(",", "."))||0;
    var rng=mulberry32(20261003);
    var pts=[];
    sel.forEach(function(c){
      var f=feats[+c.value]; if(!f) return;
      if(f.k==="P"){
        var side=Math.sqrt(Math.max(f.a,0.01));
        var n=Math.min(40, Math.max(4, Math.round(side/res)));
        var bv=basis(f.w);
        for(var i2=0;i2<n;i2++) for(var j2=0;j2<n;j2++){
          if(pts.length>=20000) return;
          var uu=((i2/(n-1))-0.5)*side, vv=((j2/(n-1))-0.5)*side;
          var px=f.p.x+uu*bv[0].x+vv*bv[1].x, py=f.p.y+uu*bv[0].y+vv*bv[1].y, pz=f.p.z+uu*bv[0].z+vv*bv[1].z;
          pts.push([px+gauss(rng)*sig, py+gauss(rng)*sig, pz+gauss(rng)*sig]);
        }
      } else if(f.r>0){
        var hExt=f.h||Math.max(2, f.r*2);
        var nr=Math.min(12, Math.max(2, Math.round(hExt/Math.max(res,0.5))));
        var np=Math.min(72, Math.max(8, Math.round(2*Math.PI*f.r/res)));
        var bv2=basis(f.w);
        for(var ri=0;ri<nr;ri++){
          if(pts.length>=20000) return;
          var off=-hExt/2+ (nr>1? ri*(hExt/(nr-1)) : 0);
          for(var qi=0;qi<np;qi++){
            var ang=2*Math.PI*qi/np;
            var cu=Math.cos(ang)*bv2[0], sv=Math.sin(ang)*bv2[1];
            var cx=f.p.x+off*f.w.x+ (cu.x*sv.y - cu.y*sv.x + f.r*0) ; // заготовка — ниже пересчитаем
            // точка = p + off*w + r*(cosA*u + sinA*v)
            var tx=f.p.x+off*f.w.x+f.r*(Math.cos(ang)*bv2[0].x+Math.sin(ang)*bv2[1].x);
            var ty=f.p.y+off*f.w.y+f.r*(Math.cos(ang)*bv2[0].y+Math.sin(ang)*bv2[1].y);
            var tz=f.p.z+off*f.w.z+f.r*(Math.cos(ang)*bv2[0].z+Math.sin(ang)*bv2[1].z);
            pts.push([tx+gauss(rng)*sig, ty+gauss(rng)*sig, tz+gauss(rng)*sig]);
          }
        }
      }
    });
    if(!pts.length){ toast("Скан не дал точек"); return; }
    p.pointCloud={ points:pts, source:"WAI виртуальный скан ("+sp.value+", σ="+q("__wSig").value+" мм, "+sel.length+" фич)" };
    if(typeof window.__pcdRebuildPointCloud3==="function") window.__pcdRebuildPointCloud3();
    reRender();
    toast("WAI скан: "+pts.length+" точек в облаке (видно в 3D). Открыть «Reverse engineering» для подгонки?");
    setTimeout(function(){ try{ if(typeof window.pcdReverseOpen==="function" && window.confirm("Открыть диалог Reverse engineering с этим облаком?")) window.pcdReverseOpen(); }catch(e){} }, 300);
  }
  var d=dlg({
    title:"WAI — оптический щуп (virtual)", width:720, body:body,
    footer:[
      {label:"Закрыть", cls:"", onClick:function(){ d.close(); }},
      {label:"📡 Виртуальный скан", cls:"", onClick:scan},
      {label:"💾 Сохранить настройку", cls:"prim", onClick:function(){
        p.waiCfg={ probe:sp.value, mode:q("__wMode").value, trig:q("__wTrig").value,
                   res:q("__wRes").value.trim(), fov:q("__wFov").value.trim(), sigma:q("__wSig").value.trim() };
        reRender(); toast("Настройка WAI сохранена (строка WAI добавлена в программу)"); d.close();
      }}
    ]
  });
};

/* WAI/облако-строки в генерируемой программе: оборачиваем genAlignAndDatumBlocks */
(function(){
  var orig=window.genAlignAndDatumBlocks;
  if(typeof orig!=="function") return;
  window.genAlignAndDatumBlocks=function(proj){
    var s=orig(proj);
    try{
      var w=proj&&proj.waiCfg;
      if(w && w.probe){
        var line="// WAI: ЩУП = "+w.probe+", РЕЖИМ = "+(w.mode||"")+", ШАГ = "+(w.res||"")+", ПОЛЕ = "+(w.fov||"")+" мм, ТРИГГЕР = "+(w.trig||"");
        s = s ? (s+"\n"+line) : line;
      }
      var pc=proj&&proj.pointCloud;
      if(pc && pc.points && pc.points.length){
        var l2="// ОБЛАКО ТОЧЕК (RE): "+pc.points.length+" тч. ("+(pc.source||"")+")";
        s = s ? (s+"\n"+l2) : l2;
      }
    }catch(e){}
    return s;
  };
})();
/* =====================================================================
   3. REVERSE ENGINEERING — облако точек + подгонка (Rsh*: mesh/geometry)
   Подгонка: МНК для плоскости/сферы/цилиндра (стандартные алгоритмы).
   ===================================================================== */
(function(){
  /* ---- линейная алгебра (оригинальная реализация) ---- */
  function vAdd(a,b){return{x:a.x+b.x,y:a.y+b.y,z:a.z+b.z};}
  function vSub(a,b){return{x:a.x-b.x,y:a.y-b.y,z:a.z-b.z};}
  function vMul(a,k){return{x:a.x*k,y:a.y*k,z:a.z*k};}
  function vDot(a,b){return a.x*b.x+a.y*b.y+a.z*b.z;}
  function vCross(a,b){return{x:a.y*b.z-a.z*b.y,y:a.z*b.x-a.x*b.z,z:a.x*b.y-a.y*b.x};}
  function vLen(a){return Math.sqrt(vDot(a,a));}
  function vNorm(a){var l=vLen(a)||1;return{x:a.x/l,y:a.y/l,z:a.z/l};}
  /* решение A·x=b (NxN), гауссово вычитание с выбором главного элемента */
  function solveLin(A,b){
    var n=b.length, M=A.map(function(r,i){return r.concat([b[i]]);});
    for(var c2=0;c2<n;c2++){
      var piv=c2;
      for(var r2=c2+1;r2<n;r2++) if(Math.abs(M[r2][c2])>Math.abs(M[piv][c2])) piv=r2;
      if(Math.abs(M[piv][c2])<1e-14) return null;
      var tmp=M[c2]; M[c2]=M[piv]; M[piv]=tmp;
      for(r2=c2+1;r2<n;r2++){
        var f=M[r2][c2]/M[c2][c2];
        for(var k2=c2;k2<=n;k2++) M[r2][k2]-=f*M[c2][k2];
      }
    }
    var x=new Array(n);
    for(var i2=n-1;i2>=0;i2--){
      var s=M[i2][n];
      for(var k3=i2+1;k3<n;k3++) s-=M[i2][k3]*x[k3];
      x[i2]=s/M[i2][i2];
    }
    return x;
  }
  /* собственные значения/векторы симметричной 3x3 (аналитически, общий случай)
     λ³ − tr·λ² + m·λ − det = 0; λ = t + tr/3 → t³ + p·t + q0 = 0 */
  function eig3(S){
    var tr=S[0][0]+S[1][1]+S[2][2];
    var m = S[0][0]*S[1][1] - S[0][1]*S[1][0]
          + S[1][1]*S[2][2] - S[1][2]*S[2][1]
          + S[0][0]*S[2][2] - S[0][2]*S[2][0];
    var det = S[0][0]*(S[1][1]*S[2][2]-S[1][2]*S[2][1])
            - S[0][1]*(S[1][0]*S[2][2]-S[1][2]*S[2][0])
            + S[0][2]*(S[1][0]*S[2][1]-S[1][1]*S[2][0]);
    var p1 = m - tr*tr/3;
    var q0 = 2*tr*tr*tr/27 - tr*m/3 + det;
    var evals;
    if(p1 > -1e-14){ // вырождение (все значения равны)
      evals=[tr/3, tr/3, tr/3];
    } else {
      var arg=(3*q0)/(2*p1)*Math.sqrt(-3/p1);
      var phi=Math.acos(Math.max(-1,Math.min(1,arg)))/3;
      var amp=2*Math.sqrt(-p1/3);
      evals=[ amp*Math.cos(phi)+tr/3,
              amp*Math.cos(phi-2*Math.PI/3)+tr/3,
              amp*Math.cos(phi-4*Math.PI/3)+tr/3 ];
    }
    // сортируем по убыванию
    evals.sort(function(x,y){return y-x;});
    function evec(lam){
      var B=[
        [S[0][0]-lam, S[0][1], S[0][2]],
        [S[1][0], S[1][1]-lam, S[1][2]],
        [S[2][0], S[2][1], S[2][2]-lam]
      ];
      // строка с максимальным элементом → вектор из миноров
      var best=0, bk=0;
      for(var i3=0;i3<3;i3++){
        for(var j3=0;j3<3;j3++){
          var v=Math.abs(B[i3][j3]);
          if(v>bk){ bk=v; best=i3*3+j3; }
        }
      }
      var ei=Math.floor(best/3), ej=best%3;
      var vec;
      if(ei===0) vec={x: B[1][2]*B[2][1]-B[1][1]*B[2][2], y: -(B[0][2]*B[2][1]-B[0][1]*B[2][2]), z: B[0][1]*B[1][2]-B[0][2]*B[1][1]};
      else if(ei===1) vec={x: -(B[1][2]*B[0][1]-B[1][1]*B[0][2]), y: B[0][2]*B[2][1]-B[0][1]*B[2][2], z: -(B[0][2]*B[1][1]-B[0][1]*B[1][2])};
      else vec={x: B[1][2]*B[0][1]-B[1][1]*B[0][2], y: -(B[0][2]*B[1][1]-B[0][1]*B[1][2]), z: B[0][1]*B[1][0]-B[0][0]*B[1][1]};
      var l2=vLen(vec);
      if(l2<1e-12){ // дегенерация — берём любой ортогональный
        vec={x:B[0][1],y:-B[0][0],z:0}; l2=vLen(vec)||1;
      }
      return vNorm(vec);
    }
    return { values:evals, vectors:[evec(evals[0]), evec(evals[1]), evec(evals[2])] };
  }
  function covariance(pts){
    var m={x:0,y:0,z:0};
    pts.forEach(function(p){ m.x+=p[0]; m.y+=p[1]; m.z+=p[2]; });
    m={x:m.x/pts.length,y:m.y/pts.length,z:m.z/pts.length};
    var S=[[0,0,0],[0,0,0],[0,0,0]];
    pts.forEach(function(p){
      var d=[p[0]-m.x,p[1]-m.y,p[2]-m.z];
      S[0][0]+=d[0]*d[0]; S[0][1]+=d[0]*d[1]; S[0][2]+=d[0]*d[2];
      S[1][1]+=d[1]*d[1]; S[1][2]+=d[1]*d[2];
      S[2][2]+=d[2]*d[2];
    });
    S[1][0]=S[0][1]; S[2][0]=S[0][2]; S[2][1]=S[1][2];
    return { m:m, S:S };
  }
  /* ---- плоскость ---- */
  function fitPlane(pts){
    var cv=covariance(pts), e=eig3(cv.S);
    var n=e.vectors[2];              // мин. собственное значение → нормаль
    var d=vDot(n,cv.m);
    var dev=pts.map(function(p){ return Math.abs(p[0]*n.x+p[1]*n.y+p[2]*n.z-d); });
    var rms=Math.sqrt(dev.reduce(function(a,b){return a+b*b;},0)/dev.length);
    var max=Math.max.apply(null,dev);
    return { n:n, d:d, center:cv.m, rms:rms, max:max, np:pts.length };
  }
  /* ---- сфера (линейная МНК) ---- */
  function fitSphere(pts){
    var A=[[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]], b=[0,0,0,0];
    pts.forEach(function(p){
      var v=[p[0],p[1],p[2],1], r2=p[0]*p[0]+p[1]*p[1]+p[2]*p[2];
      for(var i4=0;i4<4;i4++){ b[i4]+=v[i4]*r2; for(var j4=0;j4<4;j4++) A[i4][j4]+=v[i4]*v[j4]; }
    });
    var x=solveLin(A,b); if(!x) return null;
    var c={x:-x[0]/2,y:-x[1]/2,z:-x[2]/2};
    var R=Math.sqrt(x[0]*x[0]/4+x[1]*x[1]/4+x[2]*x[2]/4 - x[3]);
    if(!(R>0)) return null;
    var dev=pts.map(function(p){ return Math.abs(vLen({x:p[0]-c.x,y:p[1]-c.y,z:p[2]-c.z})-R); });
    return { c:c, R:R, rms:Math.sqrt(dev.reduce(function(a,b2){return a+b2*b2;},0)/dev.length), max:Math.max.apply(null,dev), np:pts.length };
  }
  /* ---- цилиндр (итерации: ось = макс. собственное направление, окружность 2D) ---- */
  function fitCircle2D(px,py){
    var A=[[0,0,0],[0,0,0],[0,0,0]], b=[0,0,0];
    for(var i5=0;i5<px.length;i5++){
      var r2=px[i5]*px[i5]+py[i5]*py[i5];
      A[0][0]+=px[i5]*px[i5]; A[0][1]+=px[i5]*py[i5]; A[0][2]+=px[i5]; b[0]+=px[i5]*r2;
      A[1][1]+=py[i5]*py[i5]; A[1][2]+=py[i5]; b[1]+=py[i5]*r2;
      A[2][2]+=1; b[2]+=r2;
      A[1][0]=A[0][1]; A[2][0]=A[0][2]; A[2][1]=A[1][2];
    }
    var x=solveLin(A,b); if(!x) return null;
    var c={x:x[0]/2,y:x[1]/2};
    var R=Math.sqrt(x[0]*x[0]/4+x[1]*x[1]/4-x[2]);
    if(!(R>0)) return null;
    return {c:c,R:R};
  }
  function fitCylinder(pts){
    var cv=covariance(pts), e=eig3(cv.S);
    var axis=e.vectors[0];           // ось = направление макс. дисперсии
    for(var it=0; it<5; it++){
      // базис плоскости, перпендикулярной оси
      var ref = Math.abs(axis.x)<0.9 ? {x:1,y:0,z:0} : {x:0,y:1,z:0};
      var u=vNorm(vCross(axis,ref)), w=vCross(axis,u);
      var px=[],py=[],t=[];
      pts.forEach(function(p){
        var d={x:p[0]-cv.m.x,y:p[1]-cv.m.y,z:p[2]-cv.m.z};
        px.push(vDot(d,u)); py.push(vDot(d,w)); t.push(vDot(d,axis));
      });
      var ci=fitCircle2D(px,py); if(!ci) break;
      // центр оси в координатах части
      var oc=vAdd(cv.m, vAdd(vMul(u,ci.c.x), vMul(w,ci.c.y)));
      var axis2 = it===0 ? axis : axis; // ось остаётся (пересчитываем по коварианце обновлённой подгонки)
      var rad=0;
      pts.forEach(function(p){
        var d=vSub(p,oc);
        var along=vDot(d,axis2);
        var perp=vSub(d,vMul(axis2,along));
        rad+=vLen(perp);
      });
      rad/=pts.length;
      if(it===4) {
        // финальная RMS
        var dev=pts.map(function(p){
          var d=vSub(p,oc);
          var along=vDot(d,axis2);
          var perp=vSub(d,vMul(axis2,along));
          return Math.abs(vLen(perp)-rad);
        });
        var tmin=Math.min.apply(null,t), tmax=Math.max.apply(null,t);
        return { axis:vNorm(axis2), center:oc, R:rad, h:(tmax-tmin),
                 rms:Math.sqrt(dev.reduce(function(a,b2){return a+b2*b2;},0)/dev.length),
                 max:Math.max.apply(null,dev), np:pts.length };
      }
      // уточнение оси: PCA от центра окружности
      var S2=[[0,0,0],[0,0,0],[0,0,0]];
      pts.forEach(function(p){
        var d=vSub(p,oc);
        S2[0][0]+=d.x*d.x; S2[0][1]+=d.x*d.y; S2[0][2]+=d.x*d.z;
        S2[1][1]+=d.y*d.y; S2[1][2]+=d.y*d.z; S2[2][2]+=d.z*d.z;
        S2[1][0]=S2[0][1]; S2[2][0]=S2[0][2]; S2[2][1]=S2[1][2];
      });
      var e2=eig3(S2);
      // выбираем направление, максимально близкое к предыдущей оси
      var cands=[e2.vectors[0], e2.vectors[1], e2.vectors[2]];
      var bestA=null,bestDot=2;
      cands.forEach(function(v){ var dd=Math.abs(vDot(v,axis2)); if(dd<bestDot){bestDot=dd;bestA=v;} });
      if(bestA) axis=bestA;
    }
    return null;
  }
  window.__pcdFit={ plane:fitPlane, sphere:fitSphere, cylinder:fitCylinder };

  /* ---- диалог ---- */
  window.pcdReverseOpen=function(){
    var p=cur();
    p.pointCloud=p.pointCloud||{points:[],source:""};
    var body=mk("div");
    function paintHead(){
      var pc=p.pointCloud, n=pc.points.length;
      var s='<div class="sect">Облако точек: <b>'+n+'</b> тч.'+(pc.source?' · <span style="color:#0a6ea8;">'+String(pc.source).replace(/</g,"&lt;")+'</span>':"")+'</div>'+
        '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;">'+
        '<button class="btn2" id="__rvCsv">📥 CSV (X,Y,Z)</button>'+
        '<button class="btn2" id="__rvShow">👁 Показать в 3D</button>'+
        '<button class="btn2" id="__rvClear">✕ Очистить облако</button>'+
        '<span id="__rvStats" class="hint" style="margin:0;align-self:center;"></span></div>'+
        '<div class="sect">Подгонка (least squares)</div>'+
        '<div style="display:flex;gap:8px;margin-bottom:8px;">'+
        '<button class="btn2" id="__rvFitPl">▭ Плоскость</button>'+
        '<button class="btn2" id="__rvFitCy">◍ Цилиндр</button>'+
        '<button class="btn2" id="__rvFitSp">◍ Сфера</button>'+
        '</div>'+
        '<div id="__rvFitRes" style="margin-bottom:8px;"></div>'+
        '<div style="display:flex;gap:8px;"><button class="btn2 prim" id="__rvCreate" disabled>＋ Создать элемент из подгонки</button></div>'+
        '<div class="hint">Плоскость → элемент «Плоскость» (+ допуск плоскостности). Цилиндр → «Цилиндр» с Ø=2R (+ допуск диаметра). Сфера → точка в центре (типа «Сфера» в схеме элементов нет). '+
        'Облако: WAI-виртуальный скан (из диалога WAI) или CSV (колонки x;y;z или x,y,z, разделитель — запятая/точка с запятой).</div>';
      body.innerHTML=s;
      var pc2=p.pointCloud;
      if(pc2.points.length){
        var xs=[],ys=[],zs=[];
        pc2.points.forEach(function(pt){ xs.push(pt[0]); ys.push(pt[1]); zs.push(pt[2]); });
        body.querySelector("#__rvStats").innerHTML=
          'Центр: ('+(pc2.points.reduce(function(a,b){return a+b[0];},0)/pc2.points.length).toFixed(2)+', '+(pc2.points.reduce(function(a,b){return a+b[1];},0)/pc2.points.length).toFixed(2)+', '+(pc2.points.reduce(function(a,b){return a+b[2];},0)/pc2.points.length).toFixed(2)+') · '+
          'Размах: '+(Math.max.apply(null,xs)-Math.min.apply(null,xs)).toFixed(1)+' × '+(Math.max.apply(null,ys)-Math.min.apply(null,ys)).toFixed(1)+' × '+(Math.max.apply(null,zs)-Math.min.apply(null,zs)).toFixed(1)+' мм';
      }
      body.querySelector("#__rvCsv").addEventListener("click",function(){ csvInput.click(); });
      body.querySelector("#__rvShow").addEventListener("click",function(){
        if(!p.pointCloud.points.length){ toast("Облако пустое"); return; }
        if(typeof window.__pcdRebuildPointCloud3==="function") window.__pcdRebuildPointCloud3();
        toast("Облако показано в 3D-вьювере (синие точки)");
      });
      body.querySelector("#__rvClear").addEventListener("click",function(){
        p.pointCloud={points:[],source:""};
        if(typeof window.__pcdRebuildPointCloud3==="function") window.__pcdRebuildPointCloud3();
        reRender(); paintHead(); toast("Облако точек очищено");
      });
      function doFit(kind){
        if(p.pointCloud.points.length<4){ toast("Нужно минимум 4 точки (сейчас "+p.pointCloud.points.length+")"); return; }
        var res=null, kindName="";
        try{
          if(kind==="pl"){ res=fitPlane(p.pointCloud.points); kindName="Плоскость: точка ("+res.center.x.toFixed(3)+", "+res.center.y.toFixed(3)+", "+res.center.z.toFixed(3)+") · нормаль IJK ("+res.n.x.toFixed(3)+", "+res.n.y.toFixed(3)+", "+res.n.z.toFixed(3)+") · d="+res.d.toFixed(3); }
          else if(kind==="cy"){ res=fitCylinder(p.pointCloud.points); if(res) kindName="Цилиндр: центр оси ("+res.center.x.toFixed(3)+", "+res.center.y.toFixed(3)+", "+res.center.z.toFixed(3)+") · ось ("+res.axis.x.toFixed(3)+", "+res.axis.y.toFixed(3)+", "+res.axis.z.toFixed(3)+") · Ø"+(2*res.R).toFixed(3)+" · длина "+res.h.toFixed(2); }
          else { res=fitSphere(p.pointCloud.points); if(res) kindName="Сфера: центр ("+res.c.x.toFixed(3)+", "+res.c.y.toFixed(3)+", "+res.c.z.toFixed(3)+") · R="+res.R.toFixed(3)+" (Ø"+(2*res.R).toFixed(3)+")"; }
        }catch(err){}
        var box=body.querySelector("#__rvFitRes");
        if(!res){ box.innerHTML='<div class="hint" style="color:#c0392b;">Подгонка не удалась (мало точек или вырожденное облако).</div>'; body.querySelector("#__rvCreate").disabled=true; return; }
        box.innerHTML='<div style="border:1px solid #b7d9c0;background:#e2f4e6;border-radius:4px;padding:8px 10px;font-family:Consolas,monospace;font-size:11.5px;">'+kindName+
          '<br>Точек: '+res.np+' · RMS: <b>'+res.rms.toFixed(4)+'</b> мм · Макс. отклонение: '+res.max.toFixed(4)+' мм</div>';
        box.__res=res; box.__kind=kind;
        body.querySelector("#__rvCreate").disabled=false;
      }
      body.querySelector("#__rvFitPl").addEventListener("click",function(){ doFit("pl"); });
      body.querySelector("#__rvFitCy").addEventListener("click",function(){ doFit("cy"); });
      body.querySelector("#__rvFitSp").addEventListener("click",function(){ doFit("sp"); });
      body.querySelector("#__rvCreate").addEventListener("click",function(){
        var box=body.querySelector("#__rvFitRes"), res=box.__res, kind=box.__kind;
        if(!res){ toast("Сначала выполните подгонку"); return; }
        var dec=3;
        var num=function(x){ return String(Math.round(x*1000)/1000); };
        var made="";
        if(kind==="pl"){
          var c=vSub(res.center, vMul(res.n, res.d));
          var nm=freeName(p,"RE_PL");
          p.elements.push(mkBaseEl("plane", nm, c, res.n));
          var ddim=(typeof newDimension==="function")?newDimension():{id:uid(),name:"FLA_"+nm,dimType:"ПЛОСКОСТНОСТЬ",refElement:nm,refElement2:"",axes:[]};
          ddim.name="FLA_"+nm; ddim.dimType="ПЛОСКОСТНОСТЬ"; ddim.refElement=nm;
          ddim.axes=[{id:(typeof uid==="function")?uid():"a"+Date.now(),axis:"FLA",nominal:"0",plusTol:"0.1",minusTol:"0"}];
          p.dimensions.push(ddim);
          made=nm;
        } else if(kind==="cy"){
          var nm2=freeName(p,"RE_CYL");
          p.elements.push(mkBaseEl("cylinder", nm2, res.center, res.axis, { diam:num(2*res.R), depth:num(res.h) }));
          var dd2=(typeof newDimension==="function")?newDimension():{id:uid(),name:"RAZM_"+nm2,dimType:"ДИАМЕТР",refElement:nm2,refElement2:"",axes:[]};
          dd2.name="RAZM_"+nm2; dd2.dimType="ДИАМЕТР"; dd2.refElement=nm2;
          dd2.axes=[{id:(typeof uid==="function")?uid():"a"+Date.now(),axis:"D",nominal:num(2*res.R),plusTol:"0.05",minusTol:"0"}];
          p.dimensions.push(dd2);
          made=nm2;
        } else {
          var nm3=freeName(p,"RE_PT");
          p.elements.push(mkBaseEl("point_measured", nm3, res.c, {x:0,y:0,z:1}));
          made=nm3;
        }
        reRender();
        toast("Создан элемент из подгонки: "+made);
      });
    }
    var csvInput=document.createElement("input");
    csvInput.type="file"; csvInput.accept=".csv,.txt"; csvInput.style.display="none";
    csvInput.addEventListener("change",function(){
      var f=csvInput.files&&csvInput.files[0]; if(!f) return;
      var rd=new FileReader();
      rd.onload=function(){
        var txt=String(rd.result||"");
        var pts=[];
        txt.split(/\r?\n/).forEach(function(line){
          line=line.trim(); if(!line) return;
          if(/^[a-zа-яё]+/i.test(line) && line.indexOf(",")<0) return; // шапка
          var sep = (line.indexOf(";")>=0 && line.indexOf(",")>=0) ? ";" : ",";
          var parts=line.split(sep).map(function(s){ return s.trim(); });
          if(parts.length<3) return;
          var a=parseFloat(parts[0].replace(",", "."));
          var b=parseFloat(parts[1].replace(",", "."));
          var c=parseFloat(parts[2].replace(",", "."));
          if(isFinite(a)&&isFinite(b)&&isFinite(c)){ pts.push([a,b,c]); if(pts.length>=20000) line="#stop"; }
        });
        if(!pts.length){ toast("CSV: точек не распознано (нужны колонки X,Y,Z)"); return; }
        p.pointCloud={points:pts, source:"CSV: "+f.name};
        if(typeof window.__pcdRebuildPointCloud3==="function") window.__pcdRebuildPointCloud3();
        reRender(); paintHead();
        toast("Загружено точек: "+pts.length+" из "+f.name);
      };
      rd.readAsText(f);
      csvInput.value="";
    });
    document.body.appendChild(csvInput);
    paintHead();
    var d=dlg({
      title:"Reverse engineering — облако точек и подгонка (Rsh)", width:760, body:body,
      footer:[ {label:"Закрыть", cls:"prim", onClick:function(){ d.close(); }} ]
    });
  };
  /* то же исправление замыкания, что и в FeatureTools: d объявлен после dlg() — выносим */
})();
