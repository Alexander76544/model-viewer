P='/data/in/fullpkg/3d/prg-commands.js'
s=open(P,encoding='utf-8').read()
assert 'r67 dims' not in s
old="    var hist = {};"
add=r'''    /* r67 dims: блоки размеров. Ось 1002..1009: номинал +154, +доп +162, -доп +170 (от начала тела).
       Истинная позиция 1202..1209: номинал +190, допуск +198. Расстояние/угол 11xx: номинал +192, +доп +200, -доп +208. */
    var AX = { 1002: 'X', 1003: 'Y', 1004: 'Z', 1005: 'D', 1006: 'R', 1007: 'A', 1008: 'T', 1009: 'V',
      1202: 'X', 1203: 'Y', 1204: 'Z', 1205: 'D', 1206: 'DF', 1207: 'PA', 1208: 'PR', 1209: 'TP' };
    var dims = [], blk = null;
    function rd(q, o) { var v = dbl(part, q + o); return v === null || Math.abs(v) > 1e6 ? null : r3n(v); }
    for (var di = 0; di < out.length; di++) {
      var r = out[di], q = cmds[di].q;
      if (r.code === 1000 || r.code === 1200) { blk = { name: r.arg || r.label, kind: r.code === 1200 ? 'ПОЗИЦИЯ' : 'ПОЛОЖЕНИЕ', axes: [], group: r.group, at: r.at }; dims.push(blk); continue; }
      if (r.code === 1001 || r.code === 1201) { blk = null; continue; }
      if (AX[r.code] && blk) {
        if (r.code >= 1200) blk.axes.push({ axis: AX[r.code], nominal: rd(q, 190), plusTol: rd(q, 198), minusTol: null });
        else blk.axes.push({ axis: AX[r.code], nominal: rd(q, 154), plusTol: rd(q, 162), minusTol: rd(q, 170) });
        continue;
      }
      if (r.code >= 1100 && r.code < 1200) {
        dims.push({ name: r.arg || r.label, kind: r.ru, code: r.code, group: r.group, at: r.at,
          axes: [{ axis: r.code === 1109 ? 'A' : 'M', nominal: rd(q, 192), plusTol: rd(q, 200), minusTol: rd(q, 208) }] });
      }
    }
'''
s=s.replace(old,add+old,1)
s=s.replace("return { version: version, commands: out, features: feats, histogram: hist };","return { version: version, commands: out, features: feats, dims: dims, histogram: hist };",1)
s=s.replace("  function r3(v) {","  function r3n(v) { return Math.round(v * 1e6) / 1e6; }\n  function r3(v) {",1)
open(P,'w',encoding='utf-8').write(s)

P2='/data/in/fullpkg/3d/prg-real-import.js'
t=open(P2,encoding='utf-8').read()
assert 'r67 dims merge' not in t
anchor="        warnings.push('r67: прочитано команд программы '"
assert anchor in t
add2=r'''        /* r67 dims merge: размеры с допусками из кадра команд заменяют эвристические */
        if (cmdRes.dims && cmdRes.dims.length) {
          var nd = [], nt = 0;
          var fmt = function (v) { return v === null || v === undefined ? '' : String(v); };
          cmdRes.dims.forEach(function (d, k) {
            var base = String(d.name || '').replace(/^(DIAM_|POS_|DIM_|РАЗМ_|ПОЗ_)/i, '');
            var ref = byName[base] ? base : (byName[d.name] ? d.name : '');
            if (!ref) { for (var en in byName) if (base.indexOf(en) >= 0 && en.length > ref.length) ref = en; }
            var isDia = d.axes.length === 1 && d.axes[0].axis === 'D';
            nd.push({ id: 'prgdimR' + k, name: d.name, dimType: isDia ? 'ДИАМЕТР' : d.kind, refElement: ref || base, refElement2: '', mod1: '', mod2: '', extraSuffix: '',
              axes: d.axes.map(function (a, j) { if (a.plusTol !== null) nt++; return { id: 'prgaxR' + k + '_' + j, axis: a.axis, nominal: fmt(a.nominal), plusTol: fmt(a.plusTol), minusTol: fmt(a.minusTol) }; }),
              optLine: '', axisHeader: '', groupPath: d.group ? [d.group] : [] });
          });
          dimensions.length = 0; nd.forEach(function (d) { dimensions.push(d); });
          stats.dims = nd.length;
          warnings.push('r67: размеров из файла ' + nd.length + ', допусков прочитано ' + nt + ' (номинал / +доп / −доп — из полей команды).');
        }
'''
t=t.replace(anchor,add2+anchor,1)
open(P2,'w',encoding='utf-8').write(t)
print('ok')
