const s = require('fs').readFileSync(process.argv[2], 'utf8');
let b = 0, p = 0, line = 1, i = 0, n = s.length;
const stack = [];
while (i < n) {
  const c = s[i];
  if (c === '\n') line++;
  if (c === '"' || c === "'" || c === '`') {
    const q = c; i++;
    while (i < n && s[i] !== q) { if (s[i] === '\\') i++; if (s[i] === '\n') line++; i++; }
    i++; continue;
  }
  if (c === '/' && s[i + 1] === '/') { while (i < n && s[i] !== '\n') i++; continue; }
  if (c === '/' && s[i + 1] === '*') { i += 2; while (i < n && !(s[i] === '*' && s[i + 1] === '/')) { if (s[i] === '\n') line++; i++; } i += 2; continue; }
  if (c === '{') { b++; stack.push(['b', line]); }
  if (c === '}') { b--; stack.pop(); if (b < 0) { console.log('extra } at line ~' + line); process.exit(0); } }
  if (c === '(') { p++; stack.push(['p', line]); }
  if (c === ')') { p--; stack.pop(); if (p < 0) { console.log('extra ) at line ~' + line); process.exit(0); } }
  i++;
}
console.log('final: brace=' + b + ' paren=' + p);
console.log('unclosed (last 15): ' + JSON.stringify(stack.slice(-15)));
