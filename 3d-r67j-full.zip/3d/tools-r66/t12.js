// диагностика триангуляции плоских граней: потерянные циклы и площадь треугольников vs (внешний - дыры)
global.window=globalThis;
require('/data/in/proj/3d/pcdmis-cad-reader.js');require('./pcdmis-cad-objects.js');
const fs=require('fs');const buf=fs.readFileSync('/data/in/part.CAD');const u8=new Uint8Array(buf.buffer,buf.byteOffset,buf.length);
const O=PcdCadObjects;const o=O.parse(u8,PcdCadReader.readHeader(u8));
const src=fs.readFileSync(process.argv[2]||'./planes-src.js','utf8');
// instrument: expose loopPts results via hook
const src2=src.replace("var T = earcut(flat, holes.length ? holes : null, 2);","var T = earcut(flat, holes.length ? holes : null, 2); if (root.__diag) root.__diag(f, L.length, rings, T, flat);");
eval(src2.replace(/^\/\*[\s\S]*?\*\//,''));
const st={faces:0,lost:0,lostFaces:0,over:0,under:0,ex:[]};const unk={};
window.__diag=function(f,nL,rings,T,flat){st.faces++;if(rings.length<nL){st.lost+=nL-rings.length;st.lostFaces++;}
 let At=0;for(let t=0;t<T.length;t+=3){const a=T[t]*2,b=T[t+1]*2,c=T[t+2]*2;At+=Math.abs((flat[b]-flat[a])*(flat[c+1]-flat[a+1])-(flat[c]-flat[a])*(flat[b+1]-flat[a+1]))/2;}
 let Ae=rings[0].A;for(let i=1;i<rings.length;i++)Ae-=rings[i].A;const rel=(At-Ae)/Math.max(Ae,1e-9);
 if(rel>0.01&&At-Ae>0.5){st.over++;if(st.ex.length<8)st.ex.push({f,nL,rings:rings.length,At:+At.toFixed(2),Ae:+Ae.toFixed(2)});}else if(rel<-0.01&&Ae-At>0.5)st.under++;};
const r=PcdCadPlanes.build(o);
// какие типы кривых идут хордой
const arcs={};o.arcs.forEach(a=>arcs[a.h]=a);
for(const eh in o.edges){const e=o.edges[eh];const t=o.type[e.curve];if(arcs[e.curve]&&arcs[e.curve].R>0)continue;if(t===10&&O.curveAt(u8,o,e.curve))continue;if(t===2)continue;const k=t+(e.v1===e.v2?'(closed)':'');unk[k]=(unk[k]||0)+1;}
console.log(JSON.stringify({nFaces:r.nFaces,nFail:r.nFail,...st,ex:undefined}));console.log('over examples',JSON.stringify(st.ex));console.log('chord edges by curve type',JSON.stringify(unk));
