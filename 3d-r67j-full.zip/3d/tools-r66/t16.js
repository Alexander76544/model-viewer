// сколько треугольников файла лежат далеко от своей аналитической поверхности (центр треугольника)
global.window=globalThis;global.performance=require('perf_hooks').performance;
require('/data/in/proj/3d/pcdmis-cad-reader.js');require('./pcdmis-cad-objects.js');require('./pcdmis-cad-planes.js');require('./pcdmis-cad-nurbs.js');
const fs=require('fs');const s=fs.readFileSync('./pcdmis-ui-r61.js','utf8');
const a=s.indexOf('  function cadExtras(');const b=s.indexOf('  // r66: каркас поверх');eval(s.slice(a,b)+';global.cadExtras=cadExtras;');
const buf=fs.readFileSync('/data/in/part.CAD');const u8=new Uint8Array(buf.buffer,buf.byteOffset,buf.length);
const res=PcdCadReader.read(u8);let tri=0;res.meshes.forEach(m=>tri+=m.tri.length/3);const pos=new Float32Array(tri*9);let q=0;res.meshes.forEach(m=>{for(let j=0;j<m.tri.length;j++){const v=m.tri[j]*3;pos[q++]=m.V[v];pos[q++]=m.V[v+1];pos[q++]=m.V[v+2]}});
const ex=cadExtras(u8,res,pos);const P=ex.pos||pos,o=ex.cad,TF=ex.triFace;
console.log('surface sample',JSON.stringify(Object.values(o.surfaces).find(x=>x.k==='CYLINDER')),JSON.stringify(Object.values(o.surfaces).find(x=>x.k==='TORUS')));
const H={},VK={};const bad={};const tot={};
function dev(sf,c){const d=[c[0]-sf.O[0],c[1]-sf.O[1],c[2]-sf.O[2]];if(sf.k==='CYLINDER'){const t=d[0]*sf.A[0]+d[1]*sf.A[1]+d[2]*sf.A[2];const r=Math.hypot(d[0]-t*sf.A[0],d[1]-t*sf.A[1],d[2]-t*sf.A[2]);return Math.abs(r-sf.R)/sf.R;}
 if(sf.k==='SPHERE'){return Math.abs(Math.hypot(...d)-sf.R)/sf.R;}
 if(sf.k==='TORUS'){const t=d[0]*sf.A[0]+d[1]*sf.A[1]+d[2]*sf.A[2];const rho=Math.hypot(d[0]-t*sf.A[0],d[1]-t*sf.A[1],d[2]-t*sf.A[2]);return Math.abs(Math.hypot(rho-sf.Rmaj,t)-sf.R)/sf.R;}return null;}
for(let t=0;t<tri;t++){const f=TF[t];if(!f)continue;const sf=o.surfaces[o.faceSurf[f]];if(!sf)continue;const i=t*9;const c=[(P[i]+P[i+3]+P[i+6])/3,(P[i+1]+P[i+4]+P[i+7])/3,(P[i+2]+P[i+5]+P[i+8])/3];const v=dev(sf,c);if(v==null)continue;tot[sf.k]=(tot[sf.k]||0)+1;const bin=v<0.05?'<5%':v<0.15?'<15%':v<0.3?'<30%':'>=30%';H[sf.k+bin]=(H[sf.k+bin]||0)+1;if(v>=0.3){bad[f]=(bad[f]||0)+1;let on=0;for(let k=0;k<3;k++){const w=dev(sf,[P[i+3*k],P[i+3*k+1],P[i+3*k+2]]);if(w<0.05)on++;}VK[sf.k+':vertsOn'+on]=(VK[sf.k+':vertsOn'+on]||0)+1;}}
console.log(JSON.stringify(tot),JSON.stringify(H),JSON.stringify(VK),'faces with bad',Object.keys(bad).length);
