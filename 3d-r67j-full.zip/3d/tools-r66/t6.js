global.window=globalThis;global.performance=require('perf_hooks').performance;
require('/data/in/proj/3d/pcdmis-cad-reader.js');require('./pcdmis-cad-objects.js');require('./pcdmis-cad-nurbs.js');
const fs=require('fs');const buf=fs.readFileSync('/data/in/part.CAD');const u8=new Uint8Array(buf.buffer,buf.byteOffset,buf.length);
const res=PcdCadReader.read(u8);const o=PcdCadObjects.parse(u8,res.header);
console.log('mesh keys',Object.keys(res.meshes[0]));
let n=0,read=0,ok0=0,ok1=0,both=0,none=0;const errs=[];const t0=Date.now();
const st=o.start,N=o.N;function recOf(at){let lo=1,hi=N;while(lo<hi){const mm=(lo+hi+1)>>1;if(st[mm]<=at)lo=mm;else hi=mm-1}return lo}
for(const m of res.meshes){if(!m.tri.length)continue;const f=recOf(m.at);if(o.type[f]!==103)continue;const sh=o.faceSurf[f];if(o.type[sh]!==11)continue;n++;if(n>800)break;
 const s=PcdCadNurbs.read(u8,o,sh);if(!s)continue;read++;const nv=m.V.length/3,pick=[0,Math.floor(nv/3),Math.floor(2*nv/3),nv-1];
 const e=[0,1].map(ord=>{s.order=ord;let mx=0;for(const i of pick){const X=[m.V[i*3],m.V[i*3+1],m.V[i*3+2]];mx=Math.max(mx,PcdCadNurbs.project(s,X,12).dist)}return mx});
 const a=e[0]<0.05,b=e[1]<0.05;if(a&&b)both++;else if(a)ok0++;else if(b)ok1++;else{none++;errs.push(Math.min(...e).toFixed(3))}}
console.log({faces:n,read,ok0,ok1,both,none,ms:Date.now()-t0},errs.slice(0,15).join(' '));
