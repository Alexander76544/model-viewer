const fs=require('fs');const s=fs.readFileSync('./pcdmis-ui-r61.js','utf8');
const a=s.indexOf('  function p66addToProgram(');const b=s.indexOf('  function p66show(r) {');
global.window=globalThis;const html=fs.readFileSync('/data/in/fullpkg/3d/pcdmis-generator-6.html','utf8');
const m1=html.indexOf('function mkBaseEl(');const m2=html.indexOf('window.__pcdFreeName=freeName;')+30;eval(html.slice(m1,m2));
const prog={elements:[{name:'CAD_CYL1'}]};global.cur=()=>prog;let rr=0;global.reRender=()=>rr++;const msgs=[];global.toast=m=>msgs.push(m);
eval(s.slice(a,b));
const made=p66addToProgram([{type:'cylinder',base:'CAD_CYL',p:[1.23456,2,3],w:[0,0,1],extra:{diam:'12.5',depth:'20'}},{type:'point_measured',base:'CAD_PT',p:[5,6,7],w:[1,0,0]}]);
console.log(made,rr,msgs);const e=prog.elements[1];console.log(e.type,e.name,e.x,e.y,e.z,e.i,e.j,e.k,e.diam,e.depth,e.group);
