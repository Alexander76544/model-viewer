// какие треугольники закрывают отверстия: луч по оси каждого цилиндра-отверстия
global.window=globalThis;global.performance=require('perf_hooks').performance;
require('/data/in/proj/3d/pcdmis-cad-reader.js');require('./pcdmis-cad-objects.js');require('./pcdmis-cad-planes.js');require('./pcdmis-cad-nurbs.js');
const fs=require('fs');const s=fs.readFileSync('./pcdmis-ui-r61.js','utf8');
const a=s.indexOf('  function cadExtras(');const b=s.indexOf('  // r66: каркас поверх');eval(s.slice(a,b)+';global.cadExtras=cadExtras;');
const buf=fs.readFileSync('/data/in/part.CAD');const u8=new Uint8Array(buf.buffer,buf.byteOffset,buf.length);
const res=PcdCadReader.read(u8);let tri=0;res.meshes.forEach(m=>tri+=m.tri.length/3);const pos=new Float32Array(tri*9);let q=0;res.meshes.forEach(m=>{for(let j=0;j<m.tri.length;j++){const v=m.tri[j]*3;pos[q++]=m.V[v];pos[q++]=m.V[v+1];pos[q++]=m.V[v+2]}});
const nFile=tri;const ex=cadExtras(u8,res,pos);const P=ex.pos||pos,o=ex.cad,TF=ex.triFace,nT=P.length/9;
console.log('file tris',nFile,'total',nT);
// цилиндры-грани (по поверхности)
const F=require('./pcdmis-cad-features.js');const r=F.collect({off:0,n:nT,triFace:TF,cad:o,hidden:{}},P,{});
const holes=r.els.filter(e=>e.type==='cylinder'&&e.inner);console.log('holes',holes.length);
// сетка в координатах детали (pos уже в координатах детали до swap) — проверим оба варианта
function sub(a,b){return[a[0]-b[0],a[1]-b[1],a[2]-b[2]]}function dot(a,b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]}function cr(a,b){return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]}
// сетка по ячейкам 20мм для ускорения по проекции не делаем: проверяем 300 отверстий полным перебором
const sw=process.argv[2]==='swap';
function V(i){return sw?[P[i],P[i+2],P[i+1]]:[P[i],P[i+1],P[i+2]]}
const stat={file:0,plane:0},types={},ex2=[];let cov=0,tested=0;
const H=holes.filter((h,i)=>i%Math.ceil(holes.length/400)===0);
for(const h of H){tested++;const A=h.w,p0=h.p,D=h.extra.depth,R=h.extra.diam/2;let hit=null;
 for(let t=0;t<nT&&!hit;t++){const i=t*9;const a=V(i),b=V(i+3),c=V(i+6);const e1=sub(b,a),e2=sub(c,a),pv=cr(A,e2),det=dot(e1,pv);if(Math.abs(det)<1e-9)continue;const tv=sub(p0,a),u=dot(tv,pv)/det;if(u<0||u>1)continue;const qv=cr(tv,e1),v=dot(A,qv)/det;if(v<0||u+v>1)continue;const tt=dot(e2,qv)/det;
  if(tt>-0.02*D-0.01&&tt<D*1.02+0.01){const n=cr(e1,e2),L=Math.hypot(...n);if(Math.abs(dot(n,A))/L>0.9){hit={t,tt}}}}
 if(hit){cov++;const src=hit.t<nFile?'file':'plane';stat[src]++;const f=TF[hit.t],sf=o.surfaces[o.faceSurf[f]];const k=(sf?sf.k:'?')+'/'+src;types[k]=(types[k]||0)+1;if(ex2.length<6)ex2.push({name:h.name,D:h.extra.diam,depth:h.extra.depth,p:h.p.map(x=>+x.toFixed(2)),face:f,src,tt:+hit.tt.toFixed(3)});}}
console.log(JSON.stringify({sw,tested,cov,stat,types}));console.log(JSON.stringify(ex2));
