global.window=globalThis;global.performance=require('perf_hooks').performance;
require('/data/in/proj/3d/pcdmis-cad-reader.js');require('./pcdmis-cad-objects.js');require('./pcdmis-cad-planes.js');require('./pcdmis-cad-nurbs.js');
const fs=require('fs');const s=fs.readFileSync('./pcdmis-ui-r61.js','utf8');
const a=s.indexOf('  function cadExtras(');const b=s.indexOf('  // r66: каркас поверх');
const c=s.indexOf('  var p66hi = null');const d=s.indexOf('  function p66show(');
function esc(x){return x}
eval(s.slice(a,b)+s.slice(c,d)+';global.cadExtras=cadExtras;global.p66feature=p66feature;');
const buf=fs.readFileSync('/data/in/part.CAD');const u8=new Uint8Array(buf.buffer,buf.byteOffset,buf.length);
const res=PcdCadReader.read(u8);let tri=0;res.meshes.forEach(m=>tri+=m.tri.length/3);
const pos=new Float32Array(tri*9);let o=0;res.meshes.forEach(m=>{for(let j=0;j<m.tri.length;j++){const v=m.tri[j]*3;pos[o++]=m.V[v];pos[o++]=m.V[v+1];pos[o++]=m.V[v+2]}});
const ex=cadExtras(u8,res,pos);const pos2=ex.pos||pos;console.log(ex.log.join('\n'));console.log('bodies',ex.bodies.length,ex.bodies.slice(0,5).map(x=>x.name+' '+x.tris).join(' | '));
const P={off:0,n:pos2.length/9,triFace:ex.triFace,cad:ex.cad};
const done={};let shown=0;
for(let t=0;t<P.n&&shown<7;t++){const h=P.triFace[t];if(!h)continue;const sf=ex.cad.surfaces[ex.cad.faceSurf[h]];const k=sf?sf.k:('t'+ex.cad.type[ex.cad.faceSurf[h]]);if(done[k])continue;done[k]=1;
 const verts=[];for(let k2=0;k2<P.n;k2++)if(P.triFace[k2]===h)for(let j=0;j<9;j++)verts.push(pos2[k2*9+j]);
 const hit=[pos2[t*9],pos2[t*9+1],pos2[t*9+2]];const r=p66feature(P,h,hit,[0,0,-1],[0,0,1],verts);console.log('---',k);console.log(r.info.join('\n'));console.log(r.text);shown++}
