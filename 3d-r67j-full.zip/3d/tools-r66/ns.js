const {b,R,N,base}=require('./dump.js');const T=h=>R[(h-1)*4];
function cnt(p){const n=b.readUInt16LE(p);return n===0xffff?[b.readUInt32LE(p+2),6]:[n,2]}
function knots(p,e){const [n,s]=cnt(p);if(n<2||n>2000||p+s+n*8>e)return null;const K=[];let q=p+s;for(let i=0;i<n;i++){const v=b.readDoubleLE(q);q+=8;if(!isFinite(v)||Math.abs(v)>1e7)return null;if(i&&v<K[i-1]-1e-12)return null;K.push(v)}if(K[n-1]-K[0]<=0)return null;return {K,end:q}}
function surfAt(h){const o=base(R[(h-1)*4+2]);const e=R[(h-1)*4+3];
 for(let p=o.body;p<e-20;p++){const a=knots(p,e);if(!a)continue;const c=knots(a.end,e);if(!c)continue;
  let q=c.end;const [nw,sw]=cnt(q);if(q+sw+nw*8>e)continue;const W=[];for(let i=0;i<nw;i++)W.push(b.readDoubleLE(q+sw+i*8));q+=sw+nw*8;
  const [np,sp]=cnt(q);if(np<4||q+sp+np*24>e)continue;if(nw&&nw!==np)continue;
  const nu=a.K.length,nv=c.K.length;let du=-1,dv=-1;for(let x=1;x<=9;x++)for(let y=1;y<=9;y++)if((nu-x-1)*(nv-y-1)===np&&du<0){du=x;dv=y}
  if(du<0)continue;const P=[];q+=sp;for(let i=0;i<np;i++){P.push([b.readDoubleLE(q),b.readDoubleLE(q+8),b.readDoubleLE(q+16)]);q+=24}
  return {h,off:p-o.body,Ku:a.K,Kv:c.K,W,P,du,dv,nU:nu-du-1,nV:nv-dv-1,tail:e-q}}
 return null}
module.exports={surfAt,T,N};
if(require.main===module){let ok=0,bad=0;const offs={},deg={},tails={};let first=null;for(let h=1;h<=N;h++)if(T(h)===11){const s=surfAt(h);if(!s){bad++;continue}ok++;if(!first)first=s;offs[s.off]=(offs[s.off]||0)+1;const k=s.du+'x'+s.dv+(s.W.length?' rat':'');deg[k]=(deg[k]||0)+1;tails[s.tail]=(tails[s.tail]||0)+1}
console.log({ok,bad});console.log('offs',Object.entries(offs).sort((a,b)=>b[1]-a[1]).slice(0,8));console.log('deg',deg);console.log('tails',Object.entries(tails).sort((a,b)=>b[1]-a[1]).slice(0,6));console.log(first.h,first.Ku,first.Kv,first.nU,first.nV,first.P.slice(0,3))}
