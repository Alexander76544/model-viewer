// r66l: тест математики Quick Fixture (Drop / Pin / Pin2 / Square) на three.js из pcdmis-generator-6.html
const fs = require('fs');
const html = fs.readFileSync(process.argv[2] || '/data/in/fullpkg/3d/pcdmis-generator-6.html', 'utf8');
const scripts = [...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m => m[1]);
const src = scripts.find(s => /REVISION/.test(s));
global.window = global; global.self = global; global.document = { createElementNS: () => ({ style: {} }), createElement: () => ({ style: {}, getContext: () => null }) }; global.navigator = { userAgent: 'node' };
try { (0, eval)(src); } catch (e) { console.log('three eval err', e.message); }
const T = global.THREE; if (!T || !T.Matrix4) { console.log('THREE not available, keys:', Object.keys(global).filter(k => /three/i.test(k))); process.exit(1); }
console.log('three r' + T.REVISION);
const ui = fs.readFileSync('/data/out/pcdmis-ui-r61.js', 'utf8');
const a = ui.indexOf('  var QF = {'), b = ui.indexOf('  window.pcdCadQuickFixture');
let M = new T.Matrix4();
const P = { xf: {} };
global.__p66pick = P; global.__p61bodies = [{ bh: 1, tris: 100 }, { bh: 2, tris: 10 }];
const code = ui.slice(a, b) + '\nreturn {QF, qfDrop, qfSquare, qfPin, qfPin2, qfCur};';
const lib = new Function('$', 'G', 'toast', 'p66applyVis', code)(() => null, () => null, () => {}, () => 0);
const V = (x, y, z) => new T.Vector3(x, y, z);
function cur() { return lib.qfCur(); }
function tp(p) { return p.clone().applyMatrix4(cur()); }
function td(d) { return d.clone().applyMatrix3(new T.Matrix3().setFromMatrix4(cur())).normalize(); }
// деталь: нижняя грань в точке (5,3,2) с нормалью наклонённой; оснастка: стол y=10 нормаль +y
const pn = V(0.3, -1, 0.2).normalize(), pO = V(5, 3, 2);
console.log(lib.qfDrop({ O: pO, N: pn }, { O: V(0, 10, 0), N: V(0, 1, 0) }));
const O1 = tp(pO), N1 = td(pn); console.log('drop: y=', O1.y.toFixed(6), ' N=', N1.toArray().map(v => v.toFixed(6)));
// отверстие детали перпендикулярно грани (в исходных координатах вдоль pn)
const h1 = pO.clone().add(V(20, 0, 0).projectOnPlane(pn)), h2 = pO.clone().add(V(0, 0, 50).projectOnPlane(pn));
const cyl = (p, ax) => ({ O: tp(p), A: td(ax), R: 3 });
console.log(lib.qfPin(cyl(h1, pn), { O: V(100, 10, 40), A: V(0, 1, 0), R: 3 }));
let c1 = tp(h1); console.log('pin1: hole at', c1.toArray().map(v => v.toFixed(6)), ' plane y=', tp(pO).y.toFixed(6));
const d12 = h2.distanceTo(h1);
console.log(lib.qfPin2(cyl(h2, pn), { O: V(100, 10 + 5, 40 + d12), A: V(0, 1, 0), R: 3 }));
const c2 = tp(h2); console.log('pin2: hole2 at', c2.toArray().map(v => v.toFixed(6)), ' expect x=100 z=', (40 + d12).toFixed(6), ' hole1', tp(h1).toArray().map(v => v.toFixed(6)), ' plane y', tp(pO).y.toFixed(6));
// square: сброс пина, боковая грань детали к упору x=0 (нормаль упора +x)
const sN = V(1, 0, 0).projectOnPlane(pn).normalize().negate(), sO = pO.clone().add(sN.clone().multiplyScalar(-1).multiplyScalar(0)).add(V(-7, 0, 0).projectOnPlane(pn));
console.log(lib.qfSquare({ O: tp(sO), N: td(sN) }, { O: V(0, 10, 0), N: V(1, 0, 0) }));
console.log('square: face x=', tp(sO).x.toFixed(6), ' N=', td(sN).toArray().map(v => v.toFixed(6)), ' plane y=', tp(pO).y.toFixed(6), ' bottom N=', td(pn).toArray().map(v => v.toFixed(6)));
console.log('hist', lib.QF.hist.length);
