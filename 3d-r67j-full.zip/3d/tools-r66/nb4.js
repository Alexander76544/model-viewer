const {rd,T,b,N}=require('./nb3.js');
require('/data/out/pcdmis-cad-objects.js');require('/data/in/proj/3d/pcdmis-cad-reader.js');
const u8=new Uint8Array(b.buffer,b.byteOffset,b.length);const res=PcdCadReader.read(u8);const o=PcdCadObjects.parse(u8,res.header);
function ev(c,t){const p=c.nk-c.nc-1,K=c.K;let k=p;while(k<c.nc-1&&t>=K[k+1])k++;const d=[];for(let j=0;j<=p;j++)d.push(c.P[k-p+j].slice());
 for(let r=1;r<=p;r++)for(let j=p;j>=r;j--){const i=k-p+j;const den=K[i+p-r+1]-K[i];const a=den>0?(t-K[i])/den:0;for(let q=0;q<3;q++)d[j][q]=(1-a)*d[j-1][q]+a*d[j][q]}return d[p]}
const d2=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1],a[2]-b[2]);
let ec=0,okEnd=0,inside=0,tot=0,rat=0,ratOk=0;const coeSurf={};o.coedges.forEach(c=>{(coeSurf[c.edge]||(coeSurf[c.edge]=[])).push(c.surf)});
let cylChk=0,cylBad=0,ratCyl=0,ratCylBad=0;
for(const eh in o.edges){const e=o.edges[eh];if(T(e.curve)!==10)continue;ec++;const c=rd(e.curve);if(c.bad||c.nc<2||c.nk!==c.nc+4)continue;tot++;const isR=c.restLen>26;if(isR)rat++;
 const A=c.P[0],B=c.P[c.nc-1],V1=o.verts[e.v1],V2=o.verts[e.v2];if(!V1||!V2)continue;const m=Math.min(d2(A,V1)+d2(B,V2),d2(A,V2)+d2(B,V1));if(m<0.01){okEnd++;if(isR)ratOk++}
 // interior on cylinder?
 for(const sh of coeSurf[eh]||[]){const s=o.surfaces[sh];if(!s||s.k!=='CYLINDER')continue;const t0=c.K[3],t1=c.K[c.nk-4];let mx=0;for(let i=1;i<20;i++){const P=ev(c,t0+(t1-t0)*i/20);const dd=[P[0]-s.O[0],P[1]-s.O[1],P[2]-s.O[2]];const tt=dd[0]*s.A[0]+dd[1]*s.A[1]+dd[2]*s.A[2];const r=Math.hypot(dd[0]-tt*s.A[0],dd[1]-tt*s.A[1],dd[2]-tt*s.A[2]);mx=Math.max(mx,Math.abs(r-s.R))}if(isR){ratCyl++;if(mx>0.01)ratCylBad++}else{cylChk++;if(mx>0.01)cylBad++}break}}
console.log({edgesWithBspline:ec,parsed:tot,endpointsMatch:okEnd,rational:rat,ratOk,cylChk,cylBad,ratCyl,ratCylBad});
