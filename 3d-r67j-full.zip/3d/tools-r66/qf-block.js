  /* r66l: «Уложить деталь на оснастку» по образцу PC-DMIS Quick Fixture (GraphicsUI.dll: CQuickFixtureAdjustDlg —
     OnDrop / OnLevel / OnSquare / OnX OnY OnZ / OnRotate*, CGDispView::QuickFixtureDropAndAlign). Тела «детали» двигаются
     как одно целое (матрица P.xf[тело] в осях three), остальные тела — неподвижная оснастка. */
  var QF = { mov: null, op: null, pick: [], hist: [], base: null, pin: null, down: null };
  function qfT() { return window.THREE; }
  function qfSw(a) { return [a[0], a[2], a[1]]; } // оси детали ↔ three (y↔z)
  function qfMain() { var B = (window.__p61bodies || []).filter(function (b) { return b.bh; }); if (!B.length) return null; return B.reduce(function (a, b) { return b.tris > a.tris ? b : a; }).bh; }
  function qfMov() { if (!QF.mov) { QF.mov = {}; var m = qfMain(); if (m) QF.mov[m] = 1; } return QF.mov; }
  function qfCur() { var T3 = qfT(), P = window.__p66pick; if (!P) return new T3.Matrix4(); P.xf = P.xf || {}; var ks = Object.keys(qfMov()); var M = ks.length && P.xf[ks[0]]; return M ? M.clone() : new T3.Matrix4(); }
  function qfSet(M, noHist) { var P = window.__p66pick; if (!P) return; P.xf = P.xf || {}; if (!noHist) QF.hist.push(qfCur()); Object.keys(qfMov()).forEach(function (bh) { P.xf[bh] = M.clone(); }); p66applyVis(); qfUpd(); }
  function qfPre(D) { qfSet(D.clone().multiply(qfCur())); } // D — дополнительное движение в осях оснастки
  function qfAbout(R, p) { var T3 = qfT(); return new T3.Matrix4().makeTranslation(p.x, p.y, p.z).multiply(R).multiply(new T3.Matrix4().makeTranslation(-p.x, -p.y, -p.z)); }
  function qfRotTo(a, b) { var T3 = qfT(); return new T3.Matrix4().makeRotationFromQuaternion(new T3.Quaternion().setFromUnitVectors(a.clone().normalize(), b.clone().normalize())); }
  // точная геометрия кликнутой грани в текущем положении (three-локальные оси модели)
  function qfFeat(ti, rayDir) {
    var T3 = qfT(), P = window.__p66pick, h = P.triFace[ti]; if (!h) return { err: 'треугольник без грани' };
    var o = P.cad, s = o.surfaces[o.faceSurf[h]], bh = o.faceBody[h]; if (!s) return { err: 'у грани нет точной поверхности (NURBS) — выберите плоскость или цилиндр', bh: bh };
    var M = (P.xf && P.xf[bh]) || new T3.Matrix4(), R3 = new T3.Matrix3().setFromMatrix4(M);
    function pt(a) { return new T3.Vector3().fromArray(qfSw(a)).applyMatrix4(M); }
    function dir(a) { return new T3.Vector3().fromArray(qfSw(a)).applyMatrix3(R3).normalize(); }
    if (s.k === 'PLANE') { var n = dir(s.N); if (rayDir && n.dot(rayDir) > 0) n.negate(); return { k: 'PLANE', h: h, bh: bh, O: pt(s.O), N: n }; } // нормаль — к смотрящему (наружу из материала)
    if (s.k === 'CYLINDER') return { k: 'CYL', h: h, bh: bh, O: pt(s.O), A: dir(s.A), R: s.R };
    return { err: 'грань ' + s.k + ' — нужна плоскость или цилиндр', bh: bh };
  }
  // Положить (Drop/Level): плоскость детали на плоскость оснастки, нормали навстречу
  function qfDrop(pp, fp) {
    var T3 = qfT(), R = qfAbout(qfRotTo(pp.N, fp.N.clone().negate()), pp.O), d = fp.N.dot(fp.O.clone().sub(pp.O));
    qfPre(new T3.Matrix4().makeTranslation(fp.N.x * d, fp.N.y * d, fp.N.z * d).multiply(R)); QF.base = fp.N.clone(); QF.pin = null;
    return 'Деталь положена на опорную плоскость';
  }
  // Упор (Square): боковая грань детали к упору оснастки — поворот вокруг нормали опоры и сдвиг вдоль опоры
  function qfSquare(pp, fp) {
    var T3 = qfT(), up = QF.base || new T3.Vector3(0, 1, 0), a = pp.N.clone().projectOnPlane(up), b = fp.N.clone().negate().projectOnPlane(up);
    if (a.length() < 1e-6 || b.length() < 1e-6) return 'Упорная грань параллельна опорной — выберите боковую';
    a.normalize(); b.normalize(); var ang = Math.atan2(a.clone().cross(b).dot(up), a.dot(b));
    var R = qfAbout(new T3.Matrix4().makeRotationAxis(up.clone().normalize(), ang), pp.O), dir = fp.N.clone().projectOnPlane(up).normalize(), k = fp.N.dot(dir);
    var d = fp.N.dot(fp.O.clone().sub(pp.O)) / (Math.abs(k) > 1e-6 ? k : 1);
    qfPre(new T3.Matrix4().makeTranslation(dir.x * d, dir.y * d, dir.z * d).multiply(R));
    return 'Деталь подведена к упору (поворот ' + (ang * 180 / Math.PI).toFixed(3) + '°)';
  }
  // Штифт 1: отверстие детали на штифт оснастки — соосно, без сдвига вдоль оси (контакт с опорой сохраняется)
  function qfPin(pc, fc) {
    var T3 = qfT(), a = pc.A.clone(), b = fc.A.clone(); if (a.dot(b) < 0) b.negate();
    var R = qfAbout(qfRotTo(a, b), pc.O), dl = fc.O.clone().sub(pc.O); dl.sub(b.clone().multiplyScalar(dl.dot(b)));
    qfPre(new T3.Matrix4().makeTranslation(dl.x, dl.y, dl.z).multiply(R)); QF.pin = { O: fc.O.clone(), A: b.clone() };
    var msg = 'Отверстие Ø' + (2 * pc.R).toFixed(3) + ' надето на Ø' + (2 * fc.R).toFixed(3);
    if (QF.base && Math.abs(b.dot(QF.base)) < 0.999) msg += ' — внимание: ось не перпендикулярна опоре, контакт с опорой мог нарушиться';
    return msg;
  }
  // Штифт 2: поворот вокруг первого штифта, чтобы второе отверстие (паз) встало на второй штифт
  function qfPin2(pc, fc) {
    if (!QF.pin) return 'Сначала выполните «Штифт 1»';
    var T3 = qfT(), ax = QF.pin.A, c = QF.pin.O, a = pc.O.clone().sub(c).projectOnPlane(ax), b = fc.O.clone().sub(c).projectOnPlane(ax);
    if (a.length() < 1e-6 || b.length() < 1e-6) return 'Второй штифт на оси первого — невозможно сориентировать';
    var ang = Math.atan2(a.clone().cross(b).dot(ax), a.clone().normalize().dot(b.clone().normalize()));
    qfPre(qfAbout(new T3.Matrix4().makeRotationAxis(ax.clone().normalize(), ang), c));
    return 'Поворот вокруг штифта 1 на ' + (ang * 180 / Math.PI).toFixed(3) + '°; расстояния до центров: деталь ' + a.length().toFixed(3) + ', оснастка ' + b.length().toFixed(3) + ' мм';
  }
  var QF_OPS = {
    drop: { t: 'Положить: плоскость на плоскость', k: 'PLANE', f: qfDrop },
    square: { t: 'Упор: боковая грань к упору', k: 'PLANE', f: qfSquare },
    pin: { t: 'Штифт 1: отверстие на штифт', k: 'CYL', f: qfPin },
    pin2: { t: 'Штифт 2: довернуть по второму', k: 'CYL', f: qfPin2 }
  };
  function qfMsg(m, bad) { var e = $('p66qfMsg'); if (e) { e.textContent = m; e.style.color = bad ? '#b00' : '#060'; } }
  function qfStart(op) { QF.op = op; QF.pick = []; qfMsg(op === 'body' ? 'Кликните по телу — включить/исключить его из детали (Esc — готово)' : QF_OPS[op].t + ': кликните грань ДЕТАЛИ и грань ОСНАСТКИ (в любом порядке)'); qfUpd(); }
  function qfStop() { QF.op = null; QF.pick = []; qfUpd(); }
  function qfOnPick(ti, rayDir) {
    var P = window.__p66pick, mov = qfMov();
    if (QF.op === 'body') { var h0 = P.triFace[ti], bh0 = h0 && P.cad.faceBody[h0]; if (!bh0) return; if (mov[bh0]) { delete mov[bh0]; if (P.xf) delete P.xf[bh0]; } else { mov[bh0] = 1; P.xf = P.xf || {}; var ks = Object.keys(mov).filter(function (k) { return +k !== bh0 && P.xf[k]; }); if (ks.length) P.xf[bh0] = P.xf[ks[0]].clone(); } p66applyVis(); qfUpd(); qfMsg('Деталь: ' + Object.keys(mov).map(function (k) { return '#' + k; }).join(', ')); return; }
    var op = QF_OPS[QF.op], F = qfFeat(ti, rayDir); if (F.err) { qfMsg(F.err, true); return; }
    if (F.k !== op.k) { qfMsg('Нужен ' + (op.k === 'PLANE' ? 'плоская грань' : 'цилиндр (отверстие или штифт)') + ', а выбрано: ' + (F.k === 'CYL' ? 'цилиндр' : 'плоскость'), true); return; }
    F.part = !!mov[F.bh]; QF.pick = QF.pick.filter(function (x) { return x.part !== F.part; }); QF.pick.push(F);
    if (QF.pick.length < 2) { qfMsg((F.part ? 'Грань детали' : 'Грань оснастки') + ' выбрана (грань #' + F.h + '). Теперь — ' + (F.part ? 'ОСНАСТКИ' : 'ДЕТАЛИ')); return; }
    var pp = QF.pick.filter(function (x) { return x.part; })[0], fp = QF.pick.filter(function (x) { return !x.part; })[0];
    var m = op.f(pp, fp); QF.pick = []; qfMsg(m, /Сначала|невозможно|параллельна/.test(m)); QF.op = null; qfUpd();
  }
  function qfUpd() {
    var d = $('p66qfInfo'); if (!d) return; var T3 = qfT(), M = qfCur(), e = M.elements, sw = qfSw;
    var t = sw([e[12], e[13], e[14]]), X = sw([e[0], e[1], e[2]]), Y = sw([e[8], e[9], e[10]]), Z = sw([e[4], e[5], e[6]]);
    function f(v) { return v.map(function (x) { return (Math.abs(x) < 5e-7 ? 0 : x).toFixed(4); }).join(', '); }
    d.textContent = 'Деталь (тела ' + Object.keys(qfMov()).map(function (k) { return '#' + k; }).join(', ') + ') в координатах оснастки:\nсмещение X,Y,Z = ' + f(t) + '\nось X детали = ' + f(X) + '\nось Y детали = ' + f(Y) + '\nось Z детали = ' + f(Z);
    var bs = document.querySelectorAll('#p66qf button[data-op]'); for (var i = 0; i < bs.length; i++) bs[i].style.outline = bs[i].getAttribute('data-op') === QF.op ? '2px solid #2a7' : '';
    var u = $('p66qfUndo'); if (u) u.disabled = !QF.hist.length;
  }
  function qfMove(ax, sgn) { var T3 = qfT(), st = parseFloat(($('p66qfStep') || {}).value) || 1, v = [0, 0, 0]; v[ax] = sgn * st; var w = qfSw(v); qfPre(new T3.Matrix4().makeTranslation(w[0], w[1], w[2])); }
  function qfRot(ax, sgn) { // поворот вокруг оси оснастки X/Y/Z через центр детали
    var T3 = qfT(), an = (parseFloat(($('p66qfAng') || {}).value) || 90) * Math.PI / 180 * sgn, v = [0, 0, 0]; v[ax] = 1; var w = qfSw(v), axis = new T3.Vector3(w[0], w[1], w[2]);
    if (ax === 1) an = -an; // y↔z — отражение, направление поворота в осях детали инвертируется
    if (ax !== 1) an = -an;
    var c = qfCenter(); qfPre(qfAbout(new T3.Matrix4().makeRotationAxis(axis, an), c));
  }
  function qfCenter() { var T3 = qfT(), P = window.__p66pick, mesh = G('stlMesh3'), mov = qfMov(), A = mesh.geometry.attributes.position.array, o0 = P.off * 9, s = [0, 0, 0], n = 0;
    for (var t = 0; t < P.n; t += 7) { var h = P.triFace[t]; if (h && mov[P.cad.faceBody[h]]) { var q = o0 + t * 9; s[0] += A[q]; s[1] += A[q + 1]; s[2] += A[q + 2]; n++; } }
    return n ? new T3.Vector3(s[0] / n, s[1] / n, s[2] / n) : new T3.Vector3(); }
  function qfDialog() {
    var P = window.__p66pick; if (!P || !P.cad) { toast('Сначала импортируйте .CAD'); return; }
    var d = $('p66qf'); if (d) d.remove(); d = document.createElement('div'); d.id = 'p66qf';
    d.style.cssText = 'position:fixed;left:16px;top:70px;z-index:99999;background:#fff;border:1px solid #8aa;box-shadow:0 4px 16px rgba(0,0,0,.25);padding:8px 10px;font:12px Segoe UI,Arial;width:430px';
    var B = function (id, t, op) { return '<button type="button" ' + (id ? 'id="' + id + '" ' : '') + (op ? 'data-op="' + op + '" ' : '') + 'style="margin:2px">' + t + '</button>'; };
    d.innerHTML = '<div style="font-weight:600;margin-bottom:4px">Оснастка — уложить деталь (как Quick Fixture в PC-DMIS)</div>' +
      '<div style="color:#456">Двигается только деталь, остальные тела — неподвижная оснастка. После выбора шага кликайте грани обычным кликом.</div>' +
      '<div style="margin-top:4px">' + B('', 'Выбрать тела детали…', 'body') + '</div>' +
      '<div style="margin-top:4px;font-weight:600">Укладка по граням</div><div>' + B('', '1. Положить (плоскость → опора)', 'drop') + B('', '2. Штифт 1 (отверстие → штифт)', 'pin') + B('', '3. Штифт 2 (довернуть)', 'pin2') + B('', 'Упор (боковая грань → упор)', 'square') + '</div>' +
      '<div id="p66qfMsg" style="margin:4px 0;min-height:16px;color:#060"></div>' +
      '<div style="font-weight:600">Ручная подводка (оси оснастки)</div>' +
      '<div>шаг, мм <input id="p66qfStep" value="1" style="width:60px"> ' + ['X', 'Y', 'Z'].map(function (a, i) { return B('', a + '−') .replace('<button', '<button data-mv="' + i + ',-1"') + B('', a + '+').replace('<button', '<button data-mv="' + i + ',1"'); }).join('') + '</div>' +
      '<div>угол, ° <input id="p66qfAng" value="90" style="width:60px"> ' + ['X', 'Y', 'Z'].map(function (a, i) { return B('', '⟲' + a).replace('<button', '<button data-rt="' + i + ',1"') + B('', '⟳' + a).replace('<button', '<button data-rt="' + i + ',-1"'); }).join('') + '</div>' +
      '<pre id="p66qfInfo" style="margin:6px 0;padding:6px;background:#f4f7fa;border:1px solid #d5dde5;font:11px Consolas,monospace;white-space:pre"></pre>' +
      B('p66qfUndo', 'Отменить шаг') + B('p66qfReset', 'Сброс (как в файле)') + B('p66qfClose', 'Закрыть');
    document.body.appendChild(d);
    var bs = d.querySelectorAll('button[data-op]'); for (var i = 0; i < bs.length; i++) bs[i].onclick = function () { var op = this.getAttribute('data-op'); if (QF.op === op) { qfStop(); qfMsg(''); } else qfStart(op); };
    var mv = d.querySelectorAll('button[data-mv]'); for (i = 0; i < mv.length; i++) mv[i].onclick = function () { var a = this.getAttribute('data-mv').split(','); qfMove(+a[0], +a[1]); };
    var rt = d.querySelectorAll('button[data-rt]'); for (i = 0; i < rt.length; i++) rt[i].onclick = function () { var a = this.getAttribute('data-rt').split(','); qfRot(+a[0], +a[1]); };
    $('p66qfUndo').onclick = function () { if (QF.hist.length) qfSet(QF.hist.pop(), true); };
    $('p66qfReset').onclick = function () { QF.hist.push(qfCur()); var Pp = window.__p66pick; if (Pp && Pp.xf) Object.keys(qfMov()).forEach(function (k) { delete Pp.xf[k]; }); QF.base = QF.pin = null; p66applyVis(); qfUpd(); qfMsg('Деталь возвращена в положение из файла'); };
    $('p66qfClose').onclick = function () { qfStop(); d.remove(); };
    qfUpd();
  }
  window.pcdCadQuickFixture = { open: qfDialog, state: QF, drop: qfDrop, square: qfSquare, pin: qfPin, pin2: qfPin2, feat: qfFeat, set: qfSet, cur: qfCur };
  (function qfHook() { var rd = G('renderer3'); if (!rd || !rd.domElement) { setTimeout(qfHook, 1000); return; } var el = rd.domElement; if (el.__qf) return; el.__qf = 1;
    el.addEventListener('pointerdown', function (e) { QF.down = [e.clientX, e.clientY]; }, true);
    el.addEventListener('click', function (e) {
      if (!QF.op || e.altKey) return; if (QF.down && Math.abs(e.clientX - QF.down[0]) + Math.abs(e.clientY - QF.down[1]) > 5) return; // это был поворот камеры
      var T3 = qfT(), P = window.__p66pick, mesh = G('stlMesh3'), cam = G('camera3'); if (!P || !mesh || !cam) return;
      var r = el.getBoundingClientRect(), rc = new T3.Raycaster(); rc.setFromCamera(new T3.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1), cam);
      var hs = rc.intersectObject(mesh, false); if (!hs.length) return; var ti = hs[0].faceIndex - P.off; if (ti < 0 || ti >= P.n) return;
      e.preventDefault(); e.stopPropagation();
      var dirL = rc.ray.direction.clone().transformDirection(new T3.Matrix4().copy(mesh.matrixWorld).invert());
      qfOnPick(ti, dirL);
    }, true);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && QF.op) { qfStop(); qfMsg(''); } });
  })();
