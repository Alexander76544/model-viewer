const fs=require('fs');const s=fs.readFileSync('./pcdmis-ui-r61.js','utf8');
const a=s.indexOf('  function p66applyVis(');const b=s.indexOf('  /* ---------- окно «Импорт CAD» ---------- */');
const A=new Float32Array(2*9).map((_,i)=>i+1);const mesh={geometry:{attributes:{position:{array:A}},computeBoundingSphere(){},computeBoundingBox(){}}};
global.window=globalThis;global.document={querySelectorAll:()=>[]};function G(n){return n==='stlMesh3'?mesh:null}
window.__p66pick={off:0,n:2,triFace:new Int32Array([5,6]),cad:{faceBody:{5:100,6:200}}};window.__p61bodies=[{bh:100,tris:1},{bh:200,tris:5}];
eval(s.slice(a,b));
p66setBody(100,false);console.log('hide100',Array.from(A.slice(0,9)).join(','),'|',Array.from(A.slice(9)).join(','));
p66setAll('main');console.log('main',Array.from(A.slice(0,9)).join(','));p66setAll('all');console.log('all',Array.from(A).join(','));
