global.window=globalThis;require('/data/in/proj/3d/pcdmis-cad-reader.js');require('./pcdmis-cad-objects.js');
const fs=require('fs');const buf=fs.readFileSync('/data/in/part.CAD');const u8=new Uint8Array(buf.buffer,buf.byteOffset,buf.length);
const O=PcdCadObjects;const o=O.parse(u8,PcdCadReader.readHeader(u8));
let ok=0,fail=0,rat=0,bad=0,degs={};const d=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1],a[2]-b[2]);
for(const eh in o.edges){const e=o.edges[eh];if(o.type[e.curve]!==10)continue;const c=O.curveAt(u8,o,e.curve);if(!c){fail++;continue;}ok++;if(c.W)rat++;degs[c.deg]=(degs[c.deg]||0)+1;
 const Q=O.curvePoints(c,6),V1=o.verts[e.v1],V2=o.verts[e.v2];if(V1&&V2){const m=Math.min(d(Q[0],V1)+d(Q[Q.length-1],V2),d(Q[0],V2)+d(Q[Q.length-1],V1));if(m>0.05)bad++;}}
console.log({ok,fail,rat,bad,degs});
