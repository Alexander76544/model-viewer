p='/data/out/pcdmis-ui-r61.js'
s=open(p,encoding='utf-8').read()
def rep(o,n):
    global s
    assert o in s, o[:80]
    s=s.replace(o,n,1)
# 1) заметная кнопка поверх 3D-окна + горячая клавиша Ctrl+Shift+F
rep("    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && QF.op) { qfStop(); qfMsg(''); } });",
"""    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && QF.op) { qfStop(); qfMsg(''); }
      if (e.ctrlKey && e.shiftKey && (e.key === 'F' || e.key === 'f' || e.code === 'KeyF')) { e.preventDefault(); qfDialog(); } });
    var fb = document.createElement('button'); fb.id = 'p66qfFab'; fb.type = 'button'; fb.textContent = '🧲 Оснастка / уложить деталь';
    fb.title = 'Как Quick Fixture в PC-DMIS: положить деталь на опору, надеть на штифты, подвести к упору (Ctrl+Shift+F)';
    fb.style.cssText = 'position:fixed;z-index:99998;display:none;padding:6px 10px;font:600 13px Segoe UI,Arial;background:#2a7;color:#fff;border:0;border-radius:4px;box-shadow:0 2px 8px rgba(0,0,0,.3);cursor:pointer';
    fb.onclick = qfDialog; document.body.appendChild(fb);
    setInterval(function () { var P = window.__p66pick, r = el.getBoundingClientRect(), vis = !!(P && P.cad) && r.width > 50 && r.height > 50;
      fb.style.display = vis ? 'block' : 'none'; if (vis) { fb.style.left = Math.round(r.left + 10) + 'px'; fb.style.top = Math.round(r.top + 10) + 'px'; } }, 700);""")
# 2) кнопка во всплывающем окне Alt+клика
rep("'<button id=\"p66copy\">Копировать</button> <button id=\"p66all\">Все из CAD…</button>",
    "'<button id=\"p66copy\">Копировать</button> <button id=\"p66all\">Все из CAD…</button> <button id=\"p66qfB\">Оснастка…</button>")
open(p,'w',encoding='utf-8').write(s);print('ok')
