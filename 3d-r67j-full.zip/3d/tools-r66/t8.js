global.window=globalThis;global.performance=require('perf_hooks').performance;
require('/data/in/proj/3d/pcdmis-cad-reader.js');require('./pcdmis-cad-objects.js');require('./pcdmis-cad-planes.js');require('./pcdmis-cad-nurbs.js');
const fs=require('fs');const s=fs.readFileSync('./pcdmis-ui-r61.js','utf8');
const a=s.indexOf('  function cadExtras(');const b=s.indexOf('  // r66: каркас поверх');eval(s.slice(a,b)+';global.cadExtras=cadExtras;');
const buf=fs.readFileSync('/data/in/part.CAD');const u8=new Uint8Array(buf.buffer,buf.byteOffset,buf.length);
const res=PcdCadReader.read(u8);let tri=0;res.meshes.forEach(m=>tri+=m.tri.length/3);const pos=new Float32Array(tri*9);let o=0;res.meshes.forEach(m=>{for(let j=0;j<m.tri.length;j++){const v=m.tri[j]*3;pos[o++]=m.V[v];pos[o++]=m.V[v+1];pos[o++]=m.V[v+2]}});
const ex=cadExtras(u8,res,pos);const W=ex.wireBody;let tagged=0;const per={};for(const x of W){if(x){tagged++;per[x]=(per[x]||0)+1}}
console.log('wire segs',ex.wire.length/6,'wireBody',W.length,'tagged',tagged,'bodies with wire',Object.keys(per).length);
const big=ex.bodies[0];console.log('largest',big.name,'tris',big.tris,'wire segs',per[big.bh]);
