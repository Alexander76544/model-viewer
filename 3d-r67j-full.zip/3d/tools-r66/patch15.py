p='/data/out/pcdmis-ui-r61.js'
s=open(p,encoding='utf-8').read()
def rep(old,new):
    global s
    assert old in s, old[:90]
    s=s.replace(old,new,1)

# 1) p66applyVis: матрицы тел (Quick Fixture)
rep("""      if (off) { cnt++; for (var k = 0; k < 9; k += 3) { A[q + k] = B[r]; A[q + k + 1] = B[r + 1]; A[q + k + 2] = B[r + 2]; } }
      else for (var k2 = 0; k2 < 9; k2++) A[q + k2] = B[r + k2];""",
"""      var M = h && XF && XF[fb[h]];
      if (off) { cnt++; for (var k = 0; k < 9; k += 3) { A[q + k] = B[r]; A[q + k + 1] = B[r + 1]; A[q + k + 2] = B[r + 2]; } }
      else if (M) { var e = M.elements; for (var k3 = 0; k3 < 9; k3 += 3) { var x = B[r + k3], y = B[r + k3 + 1], z = B[r + k3 + 2]; A[q + k3] = e[0] * x + e[4] * y + e[8] * z + e[12]; A[q + k3 + 1] = e[1] * x + e[5] * y + e[9] * z + e[13]; A[q + k3 + 2] = e[2] * x + e[6] * y + e[10] * z + e[14]; } }
      else for (var k2 = 0; k2 < 9; k2++) A[q + k2] = B[r + k2];""")
rep("    var B = P.bak;\n","    var B = P.bak, XF = P.xf;\n")
rep("""      for (var sg = 0; sg < WB.length; sg++) { var z = sg * 6; if (WB[sg] && hid[WB[sg]]) { WA[z + 3] = WK[z]; WA[z + 4] = WK[z + 1]; WA[z + 5] = WK[z + 2]; } else { WA[z + 3] = WK[z + 3]; WA[z + 4] = WK[z + 4]; WA[z + 5] = WK[z + 5]; } }""",
"""      for (var sg = 0; sg < WB.length; sg++) { var z = sg * 6, WM = WB[sg] && XF && XF[WB[sg]];
        if (WM) { var we = WM.elements; for (var wk = 0; wk < 6; wk += 3) { var wx = WK[z + wk], wy = WK[z + wk + 1], wz = WK[z + wk + 2]; WA[z + wk] = we[0] * wx + we[4] * wy + we[8] * wz + we[12]; WA[z + wk + 1] = we[1] * wx + we[5] * wy + we[9] * wz + we[13]; WA[z + wk + 2] = we[2] * wx + we[6] * wy + we[10] * wz + we[14]; } }
        else { WA[z] = WK[z]; WA[z + 1] = WK[z + 1]; WA[z + 2] = WK[z + 2]; }
        if (WB[sg] && hid[WB[sg]]) { WA[z + 3] = WA[z]; WA[z + 4] = WA[z + 1]; WA[z + 5] = WA[z + 2]; } else if (!WM) { WA[z + 3] = WK[z + 3]; WA[z + 4] = WK[z + 4]; WA[z + 5] = WK[z + 5]; } }""")

# 2) Alt+клик по перемещённому телу — считаем в исходных координатах детали (как в .CAD)
rep("""    var lp = mesh.worldToLocal(H.point.clone()), hitPart = sw([lp.x, lp.y, lp.z]);
    var c0 = cam.position.clone(); mesh.worldToLocal(c0); var vp = p66norm(sw([lp.x - c0.x, lp.y - c0.y, lp.z - c0.z]));
    var verts = [], hiPos = [], base = P.off * 9;
    for (var k = 0; k < P.n; k++) if (P.triFace[k] === h) { for (var j = 0; j < 9; j += 3) { var q = base + k * 9 + j; verts.push(pa[q], pa[q + 2], pa[q + 1]); hiPos.push(pa[q], pa[q + 1], pa[q + 2]); } }
    var q0 = base + ti * 9, a = [pa[q0], pa[q0 + 2], pa[q0 + 1]], b = [pa[q0 + 3], pa[q0 + 5], pa[q0 + 4]], c = [pa[q0 + 6], pa[q0 + 8], pa[q0 + 7]];""",
"""    var XM = P.xf && P.cad && P.xf[P.cad.faceBody[h]], XI = XM ? XM.clone().invert() : null;
    var lp = mesh.worldToLocal(H.point.clone()); if (XI) lp.applyMatrix4(XI); var hitPart = sw([lp.x, lp.y, lp.z]);
    var c0 = cam.position.clone(); mesh.worldToLocal(c0); if (XI) c0.applyMatrix4(XI); var vp = p66norm(sw([lp.x - c0.x, lp.y - c0.y, lp.z - c0.z]));
    var verts = [], hiPos = [], base = P.off * 9, src = XM && P.bak ? P.bak : pa, sb = XM && P.bak ? 0 : base;
    for (var k = 0; k < P.n; k++) if (P.triFace[k] === h) { for (var j = 0; j < 9; j += 3) { var q = base + k * 9 + j, qs = sb + k * 9 + j; verts.push(src[qs], src[qs + 2], src[qs + 1]); hiPos.push(pa[q], pa[q + 1], pa[q + 2]); } }
    var q0 = sb + ti * 9, a = [src[q0], src[q0 + 2], src[q0 + 1]], b = [src[q0 + 3], src[q0 + 5], src[q0 + 4]], c = [src[q0 + 6], src[q0 + 8], src[q0 + 7]];""")

# 3) блок Quick Fixture
qf=open('/data/out/qf-block.js',encoding='utf-8').read()
rep("  window.pcdCadBodies = { set: p66setBody,", qf+"  window.pcdCadBodies = { set: p66setBody,")

# 4) кнопка в окне импорта и во всплывающем окне
rep("""<button type="button" id="p66bFeat" style="font-weight:600">Все элементы из CAD → программа…</button>""",
"""<button type="button" id="p66bFeat" style="font-weight:600">Все элементы из CAD → программа…</button> <button type="button" id="p66bQF" style="font-weight:600">Оснастка: уложить деталь…</button>""")
rep("var bf = $('p66bFeat'); if (bf) bf.onclick = p66bulkDialog;","var bf = $('p66bFeat'); if (bf) bf.onclick = p66bulkDialog; var bq = $('p66bQF'); if (bq) bq.onclick = qfDialog;")
open(p,'w',encoding='utf-8').write(s);print('ok')
