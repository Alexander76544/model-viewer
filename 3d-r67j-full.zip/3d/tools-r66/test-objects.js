global.window=undefined;require('/data/in/proj/3d/pcdmis-cad-reader.js');require('./pcdmis-cad-objects.js');
const fs=require('fs');const b=fs.readFileSync('/data/in/part.CAD');const u8=new Uint8Array(b.buffer,b.byteOffset,b.length);
const t0=Date.now();const h=PcdCadReader.readHeader(u8);const o=PcdCadObjects.parse(u8,h);
console.log('ms',Date.now()-t0,'lines',o.lines.length,'arcs',o.arcs.length,'surf',Object.keys(o.surfaces).length,'edges',Object.keys(o.edges).length,'coedges',o.coedges.length);
// check: edge vertices vs curve endpoints (vertex record body starts with P3d)
const dv=new DataView(u8.buffer,u8.byteOffset,u8.byteLength);
function vert(hh){const bb=PcdCadObjects.baseAt(u8,dv,o.start[hh]);return [0,8,16].map(k=>dv.getFloat64(bb.body+k,true));}
const L={};o.lines.forEach(l=>L[l.h]=l);const A={};o.arcs.forEach(a=>A[a.h]=a);
const dist=(p,q)=>Math.hypot(p[0]-q[0],p[1]-q[1],p[2]-q[2]);
let nl=0,okl=0,na=0,oka=0,okaFlip=0,nn=0;
for(const [eh,e] of Object.entries(o.edges)){const t=o.type[e.curve];if(o.type[e.v1]!==107)continue;const V1=vert(e.v1),V2=o.type[e.v2]===107?vert(e.v2):V1;
 if(t===2){nl++;const l=L[e.curve];if(Math.min(dist(l.P1,V1)+dist(l.P2,V2),dist(l.P1,V2)+dist(l.P2,V1))<1e-3)okl++;}
 else if(t===5){na++;const a=A[e.curve];const p0=PcdCadObjects.arcPoint(a,a.a0),p1=PcdCadObjects.arcPoint(a,a.a1);if(Math.min(dist(p0,V1)+dist(p1,V2),dist(p0,V2)+dist(p1,V1))<1e-3)oka++;
  const Y=a.X;const b2={...a,N:a.N.map(x=>-x)};const q0=PcdCadObjects.arcPoint(b2,a.a0),q1=PcdCadObjects.arcPoint(b2,a.a1);if(Math.min(dist(q0,V1)+dist(q1,V2),dist(q0,V2)+dist(q1,V1))<1e-3)okaFlip++;}
 else nn++;}
console.log('edge check: lines',okl+'/'+nl,'arcs',oka+'/'+na,'(flipped N',okaFlip+')','other curves',nn);
const cyl=Object.values(o.surfaces).filter(s=>s.k==='CYLINDER');const dia={};cyl.forEach(c=>{const k=(2*c.R).toFixed(3);dia[k]=(dia[k]||0)+1});
console.log('cyl diameters top',Object.entries(dia).sort((a,b)=>b[1]-a[1]).slice(0,12));
const axOk=Object.values(o.surfaces).filter(s=>{const a=s.A||s.N;return Math.abs(Math.hypot(...a)-1)<1e-6}).length;console.log('unit axes',axOk);
const bodies={};for(let i=1;i<=o.N;i++)if(o.type[i]===101){const c=o.colors[i];bodies[c]=(bodies[c]||0)+1}console.log('body colors',Object.entries(bodies).map(([c,n])=>'#'+(+c&0xffffff).toString(16).padStart(6,'0')+' x'+n));
const cs={};o.coedges.forEach(c=>{cs[o.type[c.surf]]=(cs[o.type[c.surf]]||0)+1});console.log('coedge.surf types',cs);
