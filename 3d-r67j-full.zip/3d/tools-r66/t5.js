require('./pcdmis-cad-objects.js');require('./pcdmis-cad-planes.js');require('/data/in/proj/3d/pcdmis-cad-reader.js');
const fs=require('fs');const buf=fs.readFileSync('/data/in/part.CAD');const u8=new Uint8Array(buf.buffer,buf.byteOffset,buf.length);
const res=PcdCadReader.read(u8);const o=PcdCadObjects.parse(u8,res.header);
const t0=Date.now();const r=PcdCadPlanes.build(o);console.log('planes',r.nFaces,'fail',r.nFail,'tris',r.face.length,'ms',Date.now()-t0);
// sanity: triangles on plane & total area
let bad=0,area=0;for(let t=0;t<r.face.length;t++){const s=o.surfaces[o.faceSurf[r.face[t]]];for(let k=0;k<3;k++){const q=t*9+k*3;const d=(r.pos[q]-s.O[0])*s.N[0]+(r.pos[q+1]-s.O[1])*s.N[1]+(r.pos[q+2]-s.O[2])*s.N[2];if(Math.abs(d)>0.01)bad++}
 const a=[r.pos[t*9+3]-r.pos[t*9],r.pos[t*9+4]-r.pos[t*9+1],r.pos[t*9+5]-r.pos[t*9+2]],b=[r.pos[t*9+6]-r.pos[t*9],r.pos[t*9+7]-r.pos[t*9+1],r.pos[t*9+8]-r.pos[t*9+2]];area+=Math.hypot(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])/2}
console.log('off-plane verts',bad,'area mm2',area.toFixed(0));
