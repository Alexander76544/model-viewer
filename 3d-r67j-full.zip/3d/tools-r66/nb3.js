const {b,R,N,base}=require('./dump.js');const T=h=>R[(h-1)*4];
function rd(h){const o=base(R[(h-1)*4+2]);const e=R[(h-1)*4+3];let p=o.body;const nk=b.readUInt16LE(p);p+=2;if(p+nk*8+4>e)return {h,bad:1,len:e-o.body};const K=[];for(let i=0;i<nk;i++){K.push(b.readDoubleLE(p));p+=8}
 const f=b.readUInt16LE(p),nc=b.readUInt16LE(p+2);p+=4;if(p+nc*24>e)return {h,bad:2,len:e-o.body,nk,f,nc};const P=[];for(let i=0;i<nc;i++){P.push([b.readDoubleLE(p),b.readDoubleLE(p+8),b.readDoubleLE(p+16)]);p+=24}
 return {h,nk,f,nc,K,P,restAt:p,end:e,restLen:e-p,len:e-o.body}}
module.exports={rd,T,b,N};
if(require.main===module){
const hist={};let shown=0,bad={};for(let h=1;h<=N;h++)if(T(h)===10){const r=rd(h);if(r.bad){bad[r.bad]=(bad[r.bad]||0)+1;continue}const k='f'+r.f+' deg'+(r.nk-r.nc-1)+' extra'+(r.restLen-r.nc*8);hist[k]=(hist[k]||0)+1;
 if(shown<2){shown++;console.log('h',r.h,'nc',r.nc,'restLen',r.restLen);console.log(b.slice(r.restAt,r.end).toString('hex').replace(/(.{16})/g,'$1 ').slice(0,900))}}
console.log('bad',bad);console.log(Object.entries(hist).sort((a,b)=>b[1]-a[1]).slice(0,15));}
