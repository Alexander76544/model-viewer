const fs=require('fs');const s=fs.readFileSync('./pcdmis-ui-r61.js','utf8');global.window=globalThis;
const html=fs.readFileSync('/data/in/fullpkg/3d/pcdmis-generator-6.html','utf8');const m1=html.indexOf('function mkBaseEl(');const m2=html.indexOf('window.__pcdFreeName=freeName;')+30;eval(html.slice(m1,m2));
const a=s.indexOf('  function p66addToProgram(');const b=s.indexOf('  window.pcdCadAddToProgram');
const prog={elements:[]};global.cur=()=>prog;global.reRender=()=>{};global.toast=m=>console.log('toast:',m);eval(s.slice(a,b));
const els=[];for(let i=0;i<4700;i++)els.push({type:i%2?'cylinder':'plane',base:i%2?'CAD_HOLE':'CAD_PL',p:[i,0,0],w:[0,0,1],extra:i%2?{diam:'6',depth:'10'}:undefined});
let t=Date.now();const m=p66addToProgram(els);console.log(m.length,new Set(prog.elements.map(e=>e.name)).size,Date.now()-t,'ms',m[0],m[m.length-1]);
