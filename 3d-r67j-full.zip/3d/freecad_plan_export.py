# -*- coding: utf-8 -*-
# ============================================================================
# FreeCAD → «Генератор PC-DMIS»: экспорт плана измерения
# ----------------------------------------------------------------------------
# Превращает геометрию детали (активный документ FreeCAD) в блоки элементов
# в формате программы PC-DMIS, которые понимает «Генератор PC-DMIS»:
#   * плоские грани  -> ПЛОСКОСТЬ (точка = центр грани, нормаль наружу)
#   * цилиндры       -> ЦИЛИНДР   (точка на оси в середине грани, ось, Ø, глубина)
#
# Как пользоваться:
#   1. В FreeCAD: меню «Макросы» (или Python-консоль) → выполнить этот скрипт:
#        exec(open(r"C:\Workspace\3d\freecad_plan_export.py", encoding="utf-8").read())
#   2. Вызвать функцию:
#        plan_export()                      # результат в Python-консоли
#        plan_export(r"C:\plan.txt")        # + сохранить в файл
#   3. Скопировать выведенный текст и вставить в «Генератор PC-DMIS»:
#        вкладка «Импорт» → поле вставки → «Импортировать»
#      (лучше — в НОВУЮ операцию, чтобы не смешивать с существующей программой).
#
# Элементы создаются с НОМИНАЛом из модели, без ФАКТ (факты — после прогона
# на КИМ). Фильтр мелких граней — MIN_AREA мм².
# ============================================================================

import FreeCAD
import Part

MIN_AREA = 1.0          # мм² — грани меньше этого не попадают в план
ROUND = 3               # знаков после запятой


def _n(x):
    return round(float(x), ROUND)


def _fmt(v):
    return str(_n(v)).replace(".", ".")


def _plane_block(idx, face):
    c = face.CenterOfMass
    try:
        nr = face.normalAt(0.5, 0.5)      # нормаль, ориентированная наружу
        if nr.Length < 0.5:
            nr = face.Surface.Axis
    except Exception:
        nr = face.Surface.Axis
    nr = nr.normalize()
    name = "PL%d_1" % idx
    lines = [
        "%s=ЭЛТ/ КОНТАКТ /ПЛОСКОСТЬ/ПО_УМОЛЧ.,ДЕКАРТОВ,НЕТ,СРЕД.МНК" % name,
        "  НОМИН/%s,%s,%s,%s,%s,%s" % (_fmt(c.x), _fmt(c.y), _fmt(c.z),
                                       _fmt(nr.x), _fmt(nr.y), _fmt(nr.z)),
    ]
    return lines


def _cyl_block(idx, face):
    s = face.Surface                      # Part.Cylinder
    axis_pt = s.Center
    axis_dir = s.Axis.normalize()
    r = s.Radius
    # проекции вершин грани на ось -> глубина и середина
    tmin, tmax = None, None
    for vtx in face.Vertexes:
        t = (vtx.Point - axis_pt).dot(axis_dir)
        tmin = t if tmin is None else min(tmin, t)
        tmax = t if tmax is None else max(tmax, t)
    if tmin is None:
        tmin, tmax = 0.0, 0.0
    tmid = 0.5 * (tmin + tmax)
    depth = max(tmax - tmin, 1.0)
    c = axis_pt + axis_dir * tmid         # точка на оси в середине грани
    name = "CYL%d_1" % idx
    lines = [
        "%s=ЭЛТ/ КОНТАКТ / ЦИЛИНДР /ПО_УМОЛЧ.,ДЕКАРТОВ,ВХОД,СРЕД.МНК" % name,
        "  НОМИН/%s,%s,%s,%s,%s,%s,%s,%s" % (_fmt(c.x), _fmt(c.y), _fmt(c.z),
                                             _fmt(axis_dir.x), _fmt(axis_dir.y),
                                             _fmt(axis_dir.z), _fmt(2.0 * r),
                                             _fmt(depth)),
    ]
    return lines


def plan_export(path=None):
    doc = FreeCAD.ActiveDocument
    if doc is None:
        print("Нет активного документа FreeCAD.")
        return ""
    # собираем все твёрдые тела (или compound)
    shapes = []
    for o in doc.Objects:
        try:
            sh = o.Shape
            if sh.Solids:
                shapes.extend(sh.Solids)
            elif sh.Faces:
                shapes.append(sh)
        except Exception:
            pass
    if not shapes:
        print("В документе нет твёрдых тел с гранями.")
        return ""
    out = []
    n_plane = n_cyl = n_sph = 0
    for sh in shapes:
        for f in sh.Faces:
            if f.Area < MIN_AREA:
                continue
            s = f.Surface
            try:
                kind = s.TypeId
            except Exception:
                kind = ""
            try:
                if kind == "Part::GeomPlane" or isinstance(s, Part.Plane):
                    n_plane += 1
                    out.extend(_plane_block(n_plane, f))
                elif kind == "Part::GeomCylinder" or isinstance(s, Part.Cylinder):
                    n_cyl += 1
                    out.extend(_cyl_block(n_cyl, f))
                elif kind == "Part::GeomSphere" or isinstance(s, Part.Sphere):
                    n_sph += 1   # сферы в генераторе не стандартизированы — пропускаем
                # остальные (конус, тор, B-spline) — пропускаем
            except Exception as e:
                pass
    text = "\n".join(out)
    print("=" * 60)
    print("План измерения: плоскостей %d, цилиндров %d (сфер пропущено %d)" % (n_plane, n_cyl, n_sph))
    print("Скопируйте текст ниже во вкладку «Импорт» генератора:")
    print("=" * 60)
    print(text)
    if path:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(text)
        print("\n[сохранено в %s]" % path)
    return text
