const fs = require('fs');
const { cfbStreams, walkRecords, stringsOf, dblAt, dblFromEnd } = require('./prg-real-import.js');

const file = 'EQRX220-R5-02-2 OP10  P1P2评价全部特征-1.PRG';
const data = fs.readFileSync(file);
const streams = cfbStreams(data);
const part = streams['PARTPROG'];
const recs = walkRecords(part);

console.log('Total records:', recs.length);

let allStrings = new Set();

for (let i = 0; i < recs.length; i++) {
  const strs = stringsOf(recs[i]);
  for (const s of strs) {
    const n = s.text.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
    if (n.length > 1) allStrings.add(n);
  }
}

console.log('\nAll unique strings:');
[...allStrings].sort().forEach(s => console.log(' ', s));