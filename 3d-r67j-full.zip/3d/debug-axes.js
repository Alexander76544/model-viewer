const fs = require('fs');
const { cfbStreams, walkRecords, stringsOf } = require('./prg-real-import.js');

function dblAt(rec, off) {
  if (off < 0 || off + 8 > rec.length) return null;
  var dv = new DataView(rec.buffer, rec.byteOffset + off, 8);
  var v = dv.getFloat64(0, true);
  return isFinite(v) ? v : null;
}
function dblFromEnd(rec, fromEnd) { return dblAt(rec, rec.length - fromEnd); }

const file = 'E01--缸盖凸轮轴孔.PRG';
const data = fs.readFileSync(file);
const streams = cfbStreams(data);
const part = streams['PARTPROG'];
const recs = walkRecords(part);

console.log('Total records:', recs.length);

for (let i = 0; i < recs.length; i++) {
  const strs = stringsOf(recs[i]);
  if (!strs.length) continue;
  
  const normStrs = strs.map(s => s.text.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim());
  
  // Check for element name
  const namePattern = /^(?:圆|柱体)[\-_]?([A-Z0-9\-_]+)$/i;
  let elName = null;
  for (const n of normStrs) {
    const mm = namePattern.exec(n);
    if (mm) { elName = n; break; }
  }
  
  if (elName) {
    console.log('\nRecord', i, '->', elName);
    console.log('  Strings:', normStrs.join(' | '));
    
    // Check various offsets for X, Y, Z
    for (const off of [86, 122, 158, 272, 308, 344, 70, 78, 100, 200, 300, 400]) {
      const v = dblAt(recs[i], off);
      if (v !== null && Math.abs(v) > 0.001 && Math.abs(v) < 5000) {
        console.log(`  Abs-${off}: ${v}`);
      }
    }
    // Check from end
    for (const off of [60, 68, 70, 78, 86, 110, 150, 200, 300, 382, 400]) {
      const v = dblFromEnd(recs[i], off);
      if (v !== null && Math.abs(v) > 0.001 && Math.abs(v) < 5000) {
        console.log(`  End-${off}: ${v}`);
      }
    }
  }
}