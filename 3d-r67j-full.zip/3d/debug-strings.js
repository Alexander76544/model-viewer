const fs = require('fs');
const { cfbStreams, walkRecords, stringsOf } = require('./prg-real-import.js');

const files = fs.readdirSync('.').filter(f => f.endsWith('.PRG') || f.endsWith('.prg'));

for (const file of files) {
  console.log('\n==========', file, '==========');
  try {
    const data = fs.readFileSync(file);
    const streams = cfbStreams(data);
    const part = streams['PARTPROG'];
    if (!part) {
      console.log('No PARTPROG stream');
      continue;
    }
    const recs = walkRecords(part);
    console.log('Records:', recs.length);
    
    const allStrings = new Set();
    const cmdStrings = new Set();
    for (let i = 0; i < Math.min(recs.length, 200); i++) {
      const strs = stringsOf(recs[i]);
      for (const s of strs) {
        const n = s.text.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
        allStrings.add(n);
        if (n.includes('ЦИЛИНДР') || n.includes('ПЛОСКОСТЬ') || n.includes('ТОЧКА') || n.includes('КОНУС') || n.includes('СФЕРА') || n.includes('ОСЬ') || n.includes('ГРУППА') || /^INTR_/i.test(n) || /^POS_/i.test(n) || /^DIM_/i.test(n)) {
          cmdStrings.add(n);
        }
      }
    }
    console.log('Command-like strings:');
    [...cmdStrings].sort().forEach(s => console.log('  ', s));
  } catch (e) {
    console.error('ERROR:', e.message, e.stack);
  }
}