/* r67i - графика PC-DMIS из присланных файлов (pcdmis-assets/): иконки в меню, списке элементов,
   размерах и кнопках; заставка в стартовом окне; окно «Графика PC-DMIS» со всеми рисунками и векторными иконками.
   Выключить иконки: «CAD / 3D» -> «Иконки PC-DMIS». */
(function(){
  'use strict';
  if (typeof document === 'undefined') return;
  var A = window.PCD_ASSETS || { images: [], vectors: {} };
  var KEY = 'pcd67icons', on = true; try { on = localStorage.getItem(KEY) !== '0'; } catch(e){}
  function img(n){ for (var i = 0; i < A.images.length; i++) if (A.images[i].name === n) return A.images[i].src; return null; }
  var S = 'StrategyEditorMainView__', D = 'PcDmisViews__';
  /* ключевые слова (рус/англ + типы элементов) -> рисунок PC-DMIS; сначала размеры (более специфичные) */
  var MAP = [
    [/позици|true ?position|\btp\b/i, D+'positiondim'], [/плоскостност|flatness/i, D+'flatnessdim'],
    [/круглост|circularity|roundness/i, D+'circularitydim'], [/цилиндричност|cylindricity/i, D+'cylindricitydim'],
    [/параллельн|parallel/i, D+'parallelismdim'], [/перпендикуляр|perpendic/i, D+'perpendicularitydim'],
    [/наклон|angularity/i, D+'angularitydim'], [/прямолинейн|straightness/i, D+'straigthnessdim'],
    [/соосност|coaxial/i, D+'coaxialitydim'], [/концентричн|concentric/i, D+'concentricitydim'], [/симметр|symmetry/i, D+'simmetrydim'],
    [/полн\S* биен|total ?runout/i, D+'totalrunoutdim'], [/биен|runout/i, D+'circularrunoutdim'],
    [/профил\S* поверх|profile ?surf/i, D+'profilesurfacedim'], [/профил|profile/i, D+'profilelinedim'],
    [/расстоян|distance|\bdist/i, D+'distancedim'], [/угол между|angle ?between|\bangle\b/i, D+'angledim'],
    [/местополож|location|размеры/i, D+'locationdim'], [/размер|size|dimension/i, D+'sizedim'],
    [/цилиндр|cylinder|отверст/i, S+'cylinder'], [/конус|\bcone/i, S+'cone'], [/сфер|sphere/i, S+'sphere'],
    [/эллипс|ellipse/i, S+'ellipse'], [/окружност|circle/i, S+'circle'], [/паз круг|round ?slot/i, S+'roundslot'],
    [/паз прям|square ?slot/i, S+'squareslot'], [/паз|slot|notch/i, S+'notchslot'], [/многоугол|polygon/i, S+'polygon'],
    [/плоск|plane|level/i, S+'plane'], [/лини|line/i, S+'line'], [/кромк|edge ?point/i, S+'edgepoint'],
    [/угловая точк|corner/i, S+'cornerpoint'], [/высшая|high ?point/i, S+'highpoint'], [/зазор|flush|gap/i, S+'flushgap'],
    [/точк\S* поверх|surface ?point/i, S+'surfacepoint'], [/точк|point|касан/i, S+'vectorpoint'],
    [/3-2-1|выравниван|alignment|базир/i, '321Alignment__app'], [/итератив/i, 'IterativeAlignment__app'],
    [/щуп|probe|наконечн/i, 'ProbeWizard__app'], [/импорт cad|\bcad\b|step|iges/i, 'CadImport__app'],
    [/dmis/i, 'DMIS-OUT__app'], [/excel/i, 'PCD2EXCEL__app'], [/скан|scan/i, 'SurfaceScan__app'], [/qif/i, 'QIFExport__app'],
    [/удалить|delete/i, 'UserControls__delete'], [/очист/i, 'UserControls__delete-sweep'], [/экспорт|выгруз|сохран/i, 'UserControls__export'],
    [/импорт|открыт|загруз/i, 'UserControls__import'], [/обнов|refresh|перестр/i, 'UserControls__refresh'],
    [/вверх|up\b/i, 'UserControls__arrow-up-bold'], [/вниз|down\b/i, 'UserControls__arrow-down-bold'],
    [/закрепить|заблок/i, 'ServiceToolUC__locked'], [/откреп/i, 'ServiceToolUC__open'], [/вниман|warning|ошиб/i, 'Honeycomb_Shared__warning'],
    [/температур|коэффициент расш/i, 'MaterialCoefficientsEditor__thermometer'], [/шероховат|roughness/i, 'RoughnessScan__app'],
    [/оснастк|fixture/i, 'WeightComp__WilcoxAssociates.WeightCompensation.Resources.ThreeSupports'], [/лопатк|blade/i, 'BladeScanRT__app'],
    [/отчёт|отчет|report/i, 'ExcelFormReport__app'], [/новая программ|программ\S* детал|pc-dmis|\.prg/i, 'PCDLRN__app32']
  ];
  M.MAP = MAP;
  function M(){}
  function pick(text, type){
    var t = (type ? type + ' ' : '') + String(text || '');
    for (var i = 0; i < MAP.length; i++) if (MAP[i][0].test(t)) { var s = img(MAP[i][1]); if (s) return s; }
    return null;
  }
  var css = document.createElement('style');
  css.textContent = '.p67ic{width:16px;height:16px;object-fit:contain;vertical-align:-3px;margin-right:6px;image-rendering:auto;pointer-events:none}' +
    '.p67ic.big{width:20px;height:20px}body.p67noic .p67ic{display:none!important}' +
    '#p67gal{position:fixed;inset:40px;z-index:99990;background:#f3f4f6;border:1px solid #7a8594;box-shadow:0 10px 40px rgba(0,0,0,.4);display:flex;flex-direction:column;font:12px Segoe UI,sans-serif;color:#1c2128}' +
    '#p67gal .hd{background:linear-gradient(#2f6ea8,#245a8c);color:#fff;padding:6px 10px;font-weight:600;display:flex;gap:10px;align-items:center}' +
    '#p67gal .bd{overflow:auto;padding:10px;display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:8px}' +
    '#p67gal .it{background:#fff;border:1px solid #d0d5dc;padding:6px;text-align:center;cursor:pointer;word-break:break-all;font-size:10px;color:#4a5462}' +
    '#p67gal .it:hover{border-color:#2f6ea8}#p67gal .it img,#p67gal .it svg{display:block;margin:0 auto 4px;max-width:110px;max-height:80px;min-height:24px}';
  (document.head || document.documentElement).appendChild(css);
  function apply(){
    document.body && document.body.classList.toggle('p67noic', !on);
    if (!on) return;
    var sel = '#pcdMenu .si, #p67cadMi .si, .mi .sub .si, #p67list button, #p67ov button, .p57tg, #p67fm button, .pcd-toolbar button, #p60Tb button';
    [].forEach.call(document.querySelectorAll(sel), function(el){
      if (el.__p67ic) return; el.__p67ic = 1;
      var tx = (el.childNodes[0] && el.childNodes[0].nodeType === 3 ? el.childNodes[0].textContent : el.textContent);
      var s = pick(tx); if (!s) return;
      var i = document.createElement('img'); i.className = 'p67ic'; i.src = s; i.alt = '';
      i.onerror = function(){ i.remove(); };
      el.insertBefore(i, el.firstChild);
    });
    // список элементов программы: по типу элемента
    try {
      var els = (state && state.elements) || [];
      [].forEach.call(document.querySelectorAll('[data-id]'), function(row){
        if (row.__p67ic || row.closest('#p67gal')) return;
        var id = row.getAttribute('data-id'), e = null;
        for (var k = 0; k < els.length; k++) if (String(els[k].id) === id) { e = els[k]; break; }
        if (!e) return; row.__p67ic = 1;
        var s = pick(e.type.replace('_constructed', ''), e.type); if (!s) return;
        var i = document.createElement('img'); i.className = 'p67ic'; i.src = s; i.alt = ''; row.insertBefore(i, row.firstChild);
      });
    } catch(e){}
    // заставка стартового окна
    var ov = document.getElementById('p67ov');
    if (ov && !ov.__p67ic){
      ov.__p67ic = 1; var box = ov.firstElementChild, logo = img('ScanPlot__pc-dmis_logo') || img('HexagonLauncher__applogo'), pic = img('HexagonLauncher__image2');
      if (box && logo){
        var b = document.createElement('div');
        b.style.cssText = 'display:flex;align-items:center;gap:12px;padding:8px 12px;background:#fff;border-bottom:1px solid #d0d5dc';
        b.innerHTML = (img('PCDLRN__app') ? '<img src="' + img('PCDLRN__app') + '" style="height:46px">' : '') + '<img src="' + logo + '" style="height:46px">' + (pic ? '<img src="' + pic + '" style="height:46px;margin-left:auto;border-radius:3px">' : '');
        box.insertBefore(b, box.children[1] || null);
      }
    }
  }
  function gallery(){
    var g = document.getElementById('p67gal'); if (g) { g.remove(); return; }
    g = document.createElement('div'); g.id = 'p67gal';
    var cats = {}; A.images.forEach(function(i){ cats[i.cat] = (cats[i.cat] || 0) + 1; });
    g.innerHTML = '<div class="hd">Графика PC-DMIS — ' + A.images.length + ' рисунков, ' + Object.keys(A.vectors).length + ' векторных иконок' +
      '<select id="p67galC" style="margin-left:auto"><option value="">Все</option>' + Object.keys(cats).map(function(c){ return '<option>' + c + '</option>'; }).join('') + '<option value="vector">vector</option></select>' +
      '<input id="p67galQ" placeholder="Поиск" style="width:160px"><b id="p67galX" style="cursor:pointer">✕</b></div><div class="bd" id="p67galB"></div>' +
      '<div style="padding:4px 10px;color:#5a6472">Щелчок — скопировать имя/путь. Файлы: pcdmis-assets/img (PNG), pcdmis-assets/orig (оригиналы ICO/BMP/PNG), manifest.json.</div>';
    document.body.appendChild(g);
    function draw(){
      var c = g.querySelector('#p67galC').value, q = g.querySelector('#p67galQ').value.toLowerCase(), h = [];
      if (c !== 'vector') A.images.forEach(function(i){ if ((!c || i.cat === c) && (!q || i.name.toLowerCase().indexOf(q) >= 0)) h.push('<div class="it" data-c="' + i.src + '" title="' + i.orig + '"><img src="' + i.src + '">' + i.name + '<br>' + i.w + '×' + i.h + '</div>'); });
      if (!c || c === 'vector') Object.keys(A.vectors).forEach(function(k){ var v = A.vectors[k]; if (q && k.toLowerCase().indexOf(q) < 0) return;
        h.push('<div class="it" data-c="' + v.d.replace(/"/g, '') + '" title="' + v.from + '"><svg viewBox="0 0 24 24" width="48" height="48"><path fill="#245a8c" d="' + v.d.replace(/"/g, '') + '"/></svg>' + k + '</div>'); });
      var bd = g.querySelector('#p67galB'); bd.innerHTML = h.join('');
      [].forEach.call(bd.querySelectorAll('svg'), function(s){ try { var bb = s.querySelector('path').getBBox(); if (bb.width) s.setAttribute('viewBox', [bb.x - 1, bb.y - 1, bb.width + 2, bb.height + 2].join(' ')); } catch(e){} });
    }
    g.querySelector('#p67galC').onchange = draw; g.querySelector('#p67galQ').oninput = draw;
    g.querySelector('#p67galX').onclick = function(){ g.remove(); };
    g.querySelector('#p67galB').onclick = function(e){ var it = e.target.closest('.it'); if (!it) return; try { navigator.clipboard.writeText(it.getAttribute('data-c')); toast('Скопировано'); } catch(_){} };
    draw();
  }
  function menu(){
    var sub = document.querySelector('#p67cadMi .sub'); if (!sub || sub.querySelector('.p67galm')) return !!sub;
    [['Графика PC-DMIS (все рисунки)…', gallery], ['Иконки PC-DMIS в интерфейсе', function(){ on = !on; try { localStorage.setItem(KEY, on ? '1' : '0'); } catch(e){} apply(); t.classList.toggle('on', on); }]].forEach(function(a, ix){
      var s = document.createElement('span'); s.className = 'si p67td p67galm' + (ix && on ? ' on' : ''); s.textContent = a[0]; if (ix) t = s;
      s.addEventListener('click', function(e){ e.stopPropagation(); [].forEach.call(document.querySelectorAll('.mi.open'), function(x){ x.classList.remove('open'); }); a[1](); });
      sub.appendChild(s);
    });
    return true;
  }
  var t = null;
  window.pcdAssets = { assets: A, pick: pick, apply: apply, gallery: gallery };
  var n = 0, iv = setInterval(function(){ menu(); apply(); if (++n > 40) clearInterval(iv); }, 500);
  new MutationObserver(function(){ if (M._q) return; M._q = setTimeout(function(){ M._q = 0; apply(); }, 150); }).observe(document.documentElement, { childList: true, subtree: true });
})();
