const fs = require('fs');
const { cfbStreams, walkRecords, stringsOf } = require('./prg-real-import.js');

const files = fs.readdirSync('.').filter(f => f.endsWith('.PRG') || f.endsWith('.prg'));

for (const file of files) {
  console.log('\n==========', file, '==========');
  try {
    const data = fs.readFileSync(file);
    const streams = cfbStreams(data);
    const part = streams['PARTPROG'];
    if (!part) {
      console.log('No PARTPROG stream');
      continue;
    }
    const recs = walkRecords(part);
    console.log('Records:', recs.length);
    
    const allStrings = new Set();
    for (let i = 0; i < Math.min(recs.length, 50); i++) {
      const strs = stringsOf(recs[i]);
      for (const s of strs) {
        const n = s.text.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
        if (n.length > 2) allStrings.add(n);
      }
    }
    console.log('All strings (first 50 records):');
    [...allStrings].sort().forEach(s => console.log('  ', s));
  } catch (e) {
    console.error('ERROR:', e.message, e.stack);
  }
}