/*  Real PC-DMIS .prg import for the generator studio.
 *
 *  Reads the OLE/CFB container, walks the PARTPROG stream and extracts elements
 *  using record profiles whose field offsets were verified against PC-DMIS
 *  printouts (see prg-format-findings.md):
 *
 *    cylinder family  "ЦИЛИНДР ( КОНТАКТ )" : X +272, Y +308, Z +344, Ø at end-382
 *                                             (anchors: D18_P17 -> X -100.3 / Z -81.5 / Ø 18,
 *                                                       D9_K1_3  -> Y 434.91 / Z 25.35 / Ø 9)
 *    pos/diameter     "INTR_/POS_ ..."      : X +86, Y +122, Z +158,
 *                                             Ø nominal end-68, Ø measured end-60
 *                                             (anchors: INTR_D12.1_T34_1/T34_2)
 *
 *    Chinese (Simplified) PC-DMIS:
 *    cylinder family  "柱体 (触测)"         : same offsets as Russian
 *    circle family    "圆 (触测)"           : same offsets as pos/dia
 *    element names:   "柱体-P1", "柱体T33-1", "圆-P1", "平面-P1"
 *    dimensions:      "尺寸位置度", "尺寸同轴度", "尺寸垂直度", "尺寸圆柱度"
 *
 *  Every record is self-checked: the diameter in the element name (D25_..., INTR_D12.1_...)
 *  must equal the value found in the record, otherwise the record is skipped and counted.
 *  Records that do not fit a verified profile are reported, never silently guessed.
 *
 *  r56: command type decoded from the OBTYPE u16 field (table: pcdmis-obtype.js), auto-calibrated offset.
 *  r54: pos/diameter family restored (INTR_/POS_ -> +86/+122/+158, Ø end-68), groups
 *  resolved from the command stream ("Группа" -> next string), cylinder/circle axis
 *  vector read from the same 36-byte blocks (accepted only when it is a unit vector),
 *  duplicate element records merged, readable program outline, async parsing.
 */
(function (root) {
  'use strict';

  var OLE_SIG = [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1];
  var CYL_CMDS = ['ЦИЛИНДР ( КОНТАКТ )', '柱体 (触测)'];
  var CIRCLE_CMDS = ['ОКРУЖНОСТЬ ( КОНТАКТ )', '圆 (触测)'];
  var PLANE_CMDS = ['平面', '平面-定位面', '平面-定位平面', '平面-P', '平面-P1', '平面-P3', '平面-C'];
  var NAME_RE_RU = /^(?:INTR_|POS_)?D(\d+(?:\.\d+)?)/i;
  var NAME_RE_CN_CYL = /^(?:柱体|圆\-M)[\-_]?([A-Z0-9\-_]+)$/i;
  var NAME_RE_CN_CIRCLE = /^(?:圆)(?!\-M)[\-_]?([A-Z0-9\-_]+)$/i;
  var NAME_RE_CN_PLANE = /^(?:平面)[\-_]?([A-Z0-9\-_]+)$/i;
  var DIM_CN_PREFIX = '尺寸';

  function isOle(u8) {
    for (var i = 0; i < 8; i++) if (u8[i] !== OLE_SIG[i]) return false;
    return true;
  }

  function normName(s) {
    return String(s).replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  }

  /* ---------------- OLE / CFB ---------------- */
  function cfbStreams(u8) {
    var dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    var major = dv.getUint16(26, true);
    var secShift = dv.getUint16(30, true);
    var miniShift = dv.getUint16(32, true);
    var secSize = 1 << secShift, miniSize = 1 << miniShift;
    var firstDir = dv.getInt32(48, true);
    var miniCut = dv.getUint32(56, true);
    var firstMini = dv.getInt32(60, true);
    var firstDifat = dv.getInt32(68, true);
    function secOff(s) { return (s + 1) * secSize; }

    var difat = [], i, v;
    for (i = 0; i < 109; i++) { v = dv.getInt32(76 + i * 4, true); if (v >= 0) difat.push(v); }
    var sid = firstDifat, guard = 0;
    while (sid >= 0 && guard++ < 10000) {
      var o = secOff(sid), n = secSize / 4 - 1;
      for (i = 0; i < n; i++) { v = dv.getInt32(o + i * 4, true); if (v >= 0) difat.push(v); }
      sid = dv.getInt32(o + n * 4, true);
    }
    var fat = [];
    for (var f = 0; f < difat.length; f++) {
      var fo = secOff(difat[f]);
      for (i = 0; i < secSize / 4; i++) fat.push(dv.getInt32(fo + i * 4, true));
    }
    function chain(start, table) {
      var out = [], s = start, g = 0;
      while (s >= 0 && g++ < 1000000) { out.push(s); if (s >= table.length) break; s = table[s]; }
      return out;
    }
    function readChain(start, table) {
      var parts = chain(start, table || fat), total = 0, k;
      for (k = 0; k < parts.length; k++) total += secSize;
      var out = new Uint8Array(total), p = 0;
      for (k = 0; k < parts.length; k++) {
        var off = secOff(parts[k]);
        out.set(u8.subarray(off, Math.min(off + secSize, u8.length)), p);
        p += secSize;
      }
      return out;
    }

    var dirRaw = readChain(firstDir);
    var entries = [], dec = new TextDecoder('utf-16le');
    for (i = 0; i + 128 <= dirRaw.length; i += 128) {
      var edv = new DataView(dirRaw.buffer, dirRaw.byteOffset + i, 128);
      var nameLen = edv.getUint16(64, true);
      var type = dirRaw[i + 66];
      var start = edv.getInt32(116, true);
      var size = major === 4 ? Number(edv.getBigUint64(120, true)) : edv.getUint32(120, true);
      var name = nameLen > 2 ? dec.decode(dirRaw.subarray(i, i + nameLen - 2)) : '';
      entries.push({ name: name, type: type, start: start, size: size });
    }
    var rootEnt = null;
    for (i = 0; i < entries.length; i++) if (entries[i].type === 5) { rootEnt = entries[i]; break; }
    var miniStream = (rootEnt && rootEnt.start >= 0) ? readChain(rootEnt.start) : new Uint8Array(0);
    var miniFat = [];
    if (firstMini >= 0) {
      var mf = readChain(firstMini);
      var mdv = new DataView(mf.buffer, mf.byteOffset, mf.length);
      for (i = 0; i + 4 <= mf.length; i += 4) miniFat.push(mdv.getInt32(i, true));
    }
    var streams = {};
    for (i = 0; i < entries.length; i++) {
      var e = entries[i];
      if (e.type !== 2 || !e.name || e.start < 0) continue;
      var data;
      if (e.size < miniCut && miniStream.length) {
        var partsM = chain(e.start, miniFat), outM = new Uint8Array(e.size), pm = 0;
        for (var k2 = 0; k2 < partsM.length && pm < e.size; k2++) {
          var seg = miniStream.subarray(partsM[k2] * miniSize, (partsM[k2] + 1) * miniSize);
          var cnt = Math.min(seg.length, e.size - pm);
          outM.set(seg.subarray(0, cnt), pm);
          pm += cnt;
        }
        data = outM;
      } else {
        data = readChain(e.start).subarray(0, e.size);
      }
      streams[e.name] = data;
    }
    return streams;
  }

  /* ---------------- PARTPROG records ----------------
   * Frame kept identical to the Python tooling: a record runs from the end of the
   * previous "FF FF + 12 zeros" marker to the end of the current one, so the
   * verified field offsets stay valid.
   */
  var MARK = 14; // FF FF + 12 zero bytes

  function markerAt(u8, p) {
    if (p + MARK > u8.length) return false;
    if (u8[p] !== 0xff || u8[p + 1] !== 0xff) return false;
    for (var k = 2; k < MARK; k++) if (u8[p + k] !== 0) return false;
    return true;
  }

  function walkRecords(buf) {
    var recs = [], prev = 14, i;
    for (i = prev; i + MARK <= buf.length; i++) {
      if (markerAt(buf, i)) {
        recs.push(buf.subarray(prev, i + MARK));
        prev = i + MARK;
        i += MARK - 1;
      }
    }
    return recs;
  }

  var UTF16 = new TextDecoder('utf-16le');
  function stringsOf(rec) {
    var out = [], p = 0, dec = UTF16;
    while (true) {
      var i = -1;
      for (var k = p; k + 4 <= rec.length; k++) {
        if (rec[k] === 0xff && rec[k + 1] === 0xfe && rec[k + 2] === 0xff) { i = k; break; }
      }
      if (i < 0) break;
      p = i + 1;
      var len = rec[i + 3];
      if (len && i + 4 + len * 2 <= rec.length) {
        out.push({ at: i, text: dec.decode(rec.subarray(i + 4, i + 4 + len * 2)) });
      }
    }
    return out;
  }

  function dblAt(rec, off) {
    if (off < 0 || off + 8 > rec.length) return null;
    var dv = new DataView(rec.buffer, rec.byteOffset + off, 8);
    var v = dv.getFloat64(0, true);
    return isFinite(v) ? v : null;
  }
  function dblFromEnd(rec, fromEnd) { return dblAt(rec, rec.length - fromEnd); }
  function plausibleMm(v) { return v !== null && Math.abs(v) >= 1e-3 && Math.abs(v) <= 5000 ? v : null; }
  function num(x) { return String(Math.round(x * 1000) / 1000); }

  /* ---------------- name / profile matching ---------------- */
  var CMD_KIND = {
    'Группа': 'group', 'Group': 'group', '组': 'group',
    'Конец группы': 'groupEnd', 'Group End': 'groupEnd',
    'Загр. щуп': 'probe', 'Load Probe': 'probe',
    'Уст. активн. щуп': 'tip', 'Set Active Tip': 'tip',
    'Начало построения СК': 'alignStart', 'Start Alignment': 'alignStart',
    'Конец СК': 'alignEnd', 'End Alignment': 'alignEnd',
    'Комментарий': 'comment', 'Comment': 'comment',
    'Заголовок файла': 'misc', 'File Header': 'misc', 'Задание вида': 'misc', 'Define Viewset': 'misc',
    'ЗАПУСК': 'misc', 'Ручной режим': 'misc', 'Режим ЧПУ': 'misc', 'Manual/DCC Mode': 'misc',
    'Формат размера': 'misc', 'Dimension Format': 'misc', 'Температурная компенсация': 'misc',
    'Выполнить Замер': 'misc', 'Позиция размера': 'dimStart', 'Конец размеров позиции': 'dimEnd',
    '终止尺寸': 'dimEnd'
  };
  var FEATURE_CMD_RE = /^(ПЛОСКОСТЬ|ЦИЛИНДР|ОКРУЖНОСТЬ|ТОЧКА|КОНУС|СФЕРА|ЛИНИЯ|ПРЯМАЯ|ПАЗ|Plane|Cylinder|Circle|Point|Cone|Sphere|Line|Slot|平面|柱体|圆|点|圆锥|球|直线)\s*(\(|$)/i;

  function cmdKind(nt) {
    if (CMD_KIND[nt]) return CMD_KIND[nt];
    if (CYL_CMDS.indexOf(nt) >= 0 || CIRCLE_CMDS.indexOf(nt) >= 0 || FEATURE_CMD_RE.test(nt)) return 'feature';
    if (nt.indexOf(DIM_CN_PREFIX) === 0 && nt !== DIM_CN_PREFIX) return 'dimStart';
    return null;
  }

  var PROF_CYL = { id: 'cylinder', nomEnd: 382, actEnd: null, axes: [['X', 272], ['Y', 308], ['Z', 344]], vec: [264, 300, 336] };
  var PROF_POS = { id: 'pos_dia', nomEnd: 68, actEnd: 60, axes: [['X', 86], ['Y', 122], ['Z', 158]], vec: [78, 114, 150] };
  var PROF_PLANE = { id: 'plane', nomEnd: null, actEnd: null, axes: [], vec: null };

  /* Element name -> { type, nominal (from name, or null), profiles to try in order } */
  function matchElementName(name) {
    var mm = NAME_RE_RU.exec(name);
    if (mm) {
      // INTR_/POS_ -> pos/diameter family only (verified on INTR_D12.1_T34_*);
      // D<n>_...    -> cylinder family (verified on D18_P17, D9_K1_3, D25_T19_*)
      var posDia = /^(?:INTR_|POS_)/i.test(name);
      return { name: name, nominal: parseFloat(mm[1]), type: 'cylinder', profiles: posDia ? [PROF_POS] : [PROF_CYL] };
    }
    if (NAME_RE_CN_CYL.test(name)) return { name: name, nominal: null, type: 'cylinder', profiles: [PROF_CYL] };
    if (NAME_RE_CN_CIRCLE.test(name)) return { name: name, nominal: null, type: 'circle', profiles: [PROF_POS] };
    if (NAME_RE_CN_PLANE.test(name)) return { name: name, nominal: null, type: 'plane', profiles: [PROF_PLANE] };
    return null;
  }

  function sameNominal(a, b) { return a !== null && Math.abs(Math.abs(a) - b) <= Math.max(1e-9, b * 1e-9); }

  /* unit direction vector from three doubles; null if they do not form one */
  function unitVec(rec, offs) {
    if (!offs) return null;
    var v = [dblAt(rec, offs[0]), dblAt(rec, offs[1]), dblAt(rec, offs[2])];
    if (v[0] === null || v[1] === null || v[2] === null) return null;
    var n = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    return Math.abs(n - 1) < 1e-3 ? v : null;
  }

  function fmtVec(v) { return String(Math.round(v * 1e6) / 1e6); }

  /* ---------------- command type (OBTYPE) ---------------- */
  // Table from pcdmis-obtype.js (browser: window.PcdObtype, node: require). Optional.
  var OBT = (typeof root !== 'undefined' && root.PcdObtype) || null;
  if (!OBT && typeof require === 'function') { try { OBT = require('./pcdmis-obtype.js'); } catch (e) { OBT = null; } }

  function u16At(rec, off) { return off >= 0 && off + 2 <= rec.length ? rec[off] | (rec[off + 1] << 8) : -1; }

  /* The command-type field is u16 = OBTYPE (verified: 332-byte records carry 0x69 = VECTOR_HIT at
   * +0x10A = end-66). Its offset in other record sizes is not documented, so we calibrate it per file:
   * for every candidate offset (from the record end and from the start) count how many records hold a
   * known OBTYPE value >= 20 (small numbers are too common to be evidence). Best offset wins if it
   * explains at least half of the sampled records. */
  function calibrateType(recs) {
    if (!OBT) return null;
    var step = Math.max(1, Math.floor(recs.length / 20000)), sample = [], i, k;
    for (i = 0; i < recs.length; i += step) if (recs[i].length >= 40) sample.push(recs[i]);
    if (sample.length < 3) return null;
    var best = null;
    ['end', 'start'].forEach(function (mode) {
      for (k = 16; k <= 400; k++) {
        var hit = 0, seen = {}, kinds = 0;
        for (var j = 0; j < sample.length; j++) {
          var r = sample[j], off = mode === 'end' ? r.length - k : k;
          var v = u16At(r, off);
          if (v >= 20 && OBT.has(v)) { hit++; if (!seen[v]) { seen[v] = 1; kinds++; } }
        }
        var score = hit / sample.length;
        if (!best || score > best.score || (score === best.score && kinds > best.kinds)) best = { mode: mode, off: k, score: score, kinds: kinds };
      }
    });
    return best && best.score >= 0.5 ? best : null;
  }
  function typeOf(rec, cal) {
    if (!cal) return null;
    var v = u16At(rec, cal.mode === 'end' ? rec.length - cal.off : cal.off);
    return v > 0 && OBT.has(v) ? v : null;
  }

  /* ---------------- extraction ---------------- */
  function createParser(u8, opts) {
    opts = opts || {};
    var warnings = [], elements = [], dimensions = [], outline = [], idc = 0;
    var stats = { records: 0, cylinder: 0, circle: 0, plane: 0, posDia: 0, skipped: 0, duplicates: 0,
      groups: 0, planes: 0, probes: 0, tips: 0, features: 0, dims: 0, vectors: 0 };
    var header = { partName: '', operation: '', programName: '', source: 'real .prg' };

    if (!isOle(u8)) throw new Error('файл не является OLE/CFB контейнером PC-DMIS');
    var streams = cfbStreams(u8);
    var part = streams['PARTPROG'];
    if (!part) {
      for (var sk in streams) if (sk.toUpperCase() === 'PARTPROG') { part = streams[sk]; break; }
    }
    if (!part) throw new Error('в контейнере нет потока PARTPROG (потоки: ' + (Object.keys(streams).join(', ') || '—') + ')');

    var magic = String.fromCharCode(part[8], part[9]);
    if (magic !== '90') warnings.push('неожиданный маркер версии потока: ' + JSON.stringify(magic));

    var recs = walkRecords(part);
    stats.records = recs.length;
    var typeCal = calibrateType(recs), typeHist = {};

    var byName = {};            // element name -> element (dedupe)
    var currentGroup = '', groupDepth = 0, pending = null; // pending: command waiting for its argument
    var lastFeatureCmd = '', featureCmdByName = {};
    var dimBlocks = [], cur = null, pendingDimName = null;
    var cnDimBlocks = [], cnCur = null;
    var ri = 0;

    function pushOutline(depth, text, elName) { if (outline.length < 5000) outline.push({ d: depth, t: text, el: elName || '' }); }

    function onArgument(kind, cmd, arg) {
      if (kind === 'group') {
        currentGroup = arg; stats.groups++;
        pushOutline(groupDepth, '▸ ГРУППА ' + arg);
        groupDepth++;
      } else if (kind === 'probe') { stats.probes++; pushOutline(groupDepth, 'ЩУП ' + arg); }
      else if (kind === 'tip') { stats.tips++; pushOutline(groupDepth, 'НАКОНЕЧНИК ' + arg); }
      else if (kind === 'comment') pushOutline(groupDepth, 'КОММЕНТАРИЙ ' + arg);
      else if (kind === 'feature') { stats.features++; featureCmdByName[arg] = cmd; pushOutline(groupDepth, cmd + '  ' + arg, arg); }
    }

    function processRecord(rec) {
      var code = typeOf(rec, typeCal);
      if (code !== null) typeHist[code] = (typeHist[code] || 0) + 1;
      var strs = stringsOf(rec);
      if (!strs.length) return;

      var fileName = '', elementCmd = null;
      for (var si = 0; si < strs.length; si++) {
        var nt = normName(strs[si].text);
        if (!nt) continue;
        var kind = cmdKind(nt);
        if (pending && !kind) { onArgument(pending.kind, pending.cmd, nt); pending = null; }
        else if (pending && kind) pending = null; // command without a readable argument
        if (kind === 'feature') {
          elementCmd = nt; lastFeatureCmd = nt;
          if (nt.indexOf('ПЛОСКОСТЬ') === 0 || nt.indexOf('平面') === 0) stats.planes++;
        }
        if (kind === 'group' || kind === 'probe' || kind === 'tip' || kind === 'comment' || kind === 'feature') {
          pending = { kind: kind, cmd: nt };
        } else if (kind === 'groupEnd') {
          groupDepth = Math.max(0, groupDepth - 1);
        } else if (kind === 'alignStart') pushOutline(groupDepth, 'НАЧАЛО СК');
        else if (kind === 'alignEnd') pushOutline(groupDepth, 'КОНЕЦ СК');
        else if (!kind) {
          if (/\.PRG$/i.test(nt)) fileName = nt;
          else if (/^GRP_/i.test(nt) && nt !== currentGroup) currentGroup = nt; // fallback: group name seen without its command
        }
      }

      if (!header.programName && fileName) {
        header.programName = fileName;
        var mOp = fileName.match(/(op[\d.]*\d)/i);
        if (mOp) header.operation = mOp[1];
        header.partName = fileName.replace(/\.[^.]*$/, '');
      }

      collectDimBlocks(rec, strs);

      // element record
      var match = null;
      for (var sj = 0; sj < strs.length; sj++) {
        match = matchElementName(normName(strs[sj].text));
        if (match) break;
      }
      if (!match) return;

      var prof = null, nom = null;
      for (var pi = 0; pi < match.profiles.length; pi++) {
        var p = match.profiles[pi];
        if (p.id === 'plane') { prof = p; break; }
        var v = dblFromEnd(rec, p.nomEnd);
        if (match.nominal !== null ? sameNominal(v, match.nominal) : (v !== null && v > 0.05 && v < 2000)) { prof = p; nom = v; break; }
      }
      if (!prof) { stats.skipped++; return; }
      if (prof.id === 'plane') return; // plane layout not verified: listed in the outline only

      var act = prof.actEnd ? dblFromEnd(rec, prof.actEnd) : null;
      if (act !== null && (Math.abs(act) < Math.abs(nom) * 0.5 || Math.abs(act) > Math.abs(nom) * 1.5)) act = null;

      var raw = {}, nOk = 0, a, val;
      for (a = 0; a < prof.axes.length; a++) {
        val = dblAt(rec, prof.axes[a][1]);
        raw[prof.axes[a][0]] = val;
        if (plausibleMm(val) !== null) nOk++;
      }
      // a nominal of 0 is stored as ~1e-6 noise: accept it once the other axes prove the layout
      var ax = {};
      for (a = 0; a < prof.axes.length; a++) {
        val = raw[prof.axes[a][0]];
        if (plausibleMm(val) !== null) ax[prof.axes[a][0]] = val;
        else if (nOk >= 2 && val !== null && Math.abs(val) < 1e-3) ax[prof.axes[a][0]] = 0;
        else ax[prof.axes[a][0]] = null;
      }
      var vec = nOk >= 2 ? unitVec(rec, prof.vec) : null;

      var cmdHint = elementCmd || featureCmdByName[match.name] || '';
      var isCircle = match.type === 'circle' || (cmdHint && (CIRCLE_CMDS.indexOf(cmdHint) >= 0 || /^(ОКРУЖНОСТЬ|Circle|圆)/i.test(cmdHint)));
      var elemType = isCircle ? 'circle' : 'cylinder';

      var prev = byName[match.name];
      if (prev) {
        stats.duplicates++;
        if (!(nOk > prev._axesOk)) return; // keep the better-filled record
      }

      var e = {
        id: prev ? prev.id : 'prg' + (++idc), type: elemType, name: match.name, group: currentGroup,
        x: ax.X === null || ax.X === undefined ? '' : num(ax.X),
        y: ax.Y === null || ax.Y === undefined ? '' : num(ax.Y),
        z: ax.Z === null || ax.Z === undefined ? '' : num(ax.Z),
        i: vec ? fmtVec(vec[0]) : '0', j: vec ? fmtVec(vec[1]) : '0', k: vec ? fmtVec(vec[2]) : '1',
        diam: num(Math.abs(nom)), depth: '10',
        strategy: 'ПО_УМОЛЧ.', entry: 'ВХОД', points: '4', rows: '3', layers: '2', depthParam: '2',
        finishOffset: '5', step: '0', avoidBefore: '0', avoidAfter: '10',
        direction: 'ПРОТИВ ЧАСОВОЙ', angleVec: '0,0,1', startAngle: '0', endAngle: '360',
        constrFrom1: '', constrFrom2: '', outlierRemoval: 'ВЫКЛ,3', filterWave: '0',
        factSameAsNominal: act === null, hasTarget: true,
        factX: '', factY: '', factZ: '', factI: '', factJ: '', factK: '',
        factDiam: act === null ? '' : num(act), factDepth: '',
        open: true, extraLines: [], _profile: prof.id, _axesConfirmed: nOk >= 2, _axesOk: nOk,
        _vectorFromFile: !!vec, _cmd: cmdHint || lastFeatureCmd || '',
        _obtype: code !== null && OBT.get(code).cat === 'feature' ? OBT.get(code).id : ''
      };
      if (prev) {
        for (var key in e) prev[key] = e[key];
      } else {
        byName[match.name] = e;
        elements.push(e);
      }
    }

    function collectDimBlocks(rc, st) {
      /* Russian position blocks */
      var isStart = false, isEnd = false, axisLabel = null, dimName = null, q, nq;
      for (q = 0; q < st.length; q++) {
        nq = normName(st[q].text);
        if (nq === 'Позиция размера') isStart = true;
        else if (nq === 'Конец размеров позиции') isEnd = true;
        else if (nq.indexOf('Положение позиции') === 0) axisLabel = nq.replace('Положение позиции', '').trim();
        else if (/^(?:POS_|DIM_)/.test(nq)) dimName = nq;
      }
      if (isStart) { cur = { name: pendingDimName || '', rows: [], posTol: null }; dimBlocks.push(cur); }
      if (dimName) {
        pendingDimName = dimName;
        if (!cur || cur.name) { cur = { name: dimName, rows: [], posTol: null }; dimBlocks.push(cur); }
        else cur.name = dimName;
      }
      if (axisLabel !== null && cur) {
        cur.rows.push({ axis: axisLabel, nominal: dblAt(rc, 70), measured: dblAt(rc, 78), tol: dblAt(rc, 86), dev: dblAt(rc, 110) });
      }
      if (isEnd && cur) { cur.posTol = dblAt(rc, 86); cur = null; }

      /* Chinese blocks */
      var cnIsStart = false, cnIsEnd = false, cnDimType = null, cnRef = null;
      for (q = 0; q < st.length; q++) {
        nq = normName(st[q].text);
        if (nq.indexOf(DIM_CN_PREFIX) === 0 && nq !== DIM_CN_PREFIX) { cnIsStart = true; cnDimType = nq; }
        else if (nq === '终止尺寸') cnIsEnd = true;
        else if (matchElementName(nq)) cnRef = nq;
      }
      if (cnIsStart) { cnCur = { type: cnDimType, ref: cnRef, rows: [] }; cnDimBlocks.push(cnCur); }
      if (cnRef && cnCur) cnCur.ref = cnRef;
      if (cnIsEnd && cnCur) cnCur = null;
    }

    function finish() {
      var diamDimByEl = {};
      elements.forEach(function (e) {
        if (e._profile === 'cylinder') stats.cylinder++;
        else if (e._profile === 'pos_dia') stats.posDia++;
        if (e.type === 'circle') stats.circle++;
        if (e._vectorFromFile) stats.vectors++;
        var d = {
          id: 'prgdim' + e.id, name: 'RAZM_' + e.name, dimType: 'ДИАМЕТР', refElement: e.name,
          refElement2: '', mod1: '', mod2: '', extraSuffix: '',
          axes: [{ id: 'prgax' + e.id, axis: 'D', nominal: e.diam, plusTol: '', minusTol: '' }],
          optLine: '', axisHeader: '', groupPath: e.group ? [e.group] : []
        };
        diamDimByEl[e.name] = d;
        dimensions.push(d);
      });

      var all = dimBlocks.concat(cnDimBlocks), tolCount = 0;
      for (var bi = 0; bi < all.length; bi++) {
        var blk = all[bi];
        if (!blk || (!blk.name && !blk.type) || !blk.rows || !blk.rows.length) continue;
        var elementName = blk.name ? blk.name.replace(/^(?:POS_|DIM_)/i, '') : blk.ref;
        var target = byName[elementName] || null;
        var diaRow = null, axisRows = [];
        for (var rr = 0; rr < blk.rows.length; rr++) {
          var row = blk.rows[rr];
          if (row.axis === 'Диам' || row.axis === '直径') diaRow = row; else axisRows.push(row);
        }
        if (diaRow && diaRow.nominal !== null) {
          var existing = diamDimByEl[elementName];
          var tol = diaRow.tol === null ? '' : num(diaRow.tol);
          if (existing && sameNominal(diaRow.nominal, parseFloat(existing.axes[0].nominal) || 0)) {
            if (tol) { existing.axes[0].plusTol = tol; tolCount++; }   // merge instead of duplicating
          } else {
            dimensions.push({
              id: 'prgdimD' + (++idc), name: blk.name || blk.type, dimType: 'ДИАМЕТР', refElement: elementName,
              refElement2: '', mod1: '', mod2: '', extraSuffix: '',
              axes: [{ id: 'prgaxD' + idc, axis: 'D', nominal: num(diaRow.nominal), plusTol: tol, minusTol: '' }],
              optLine: '', axisHeader: '', groupPath: target && target.group ? [target.group] : []
            });
            if (tol) tolCount++;
          }
          if (target && diaRow.measured !== null) { target.factSameAsNominal = false; target.factDiam = num(diaRow.measured); }
        }
        dimensions.push({
          id: 'prgdimP' + (++idc), name: blk.name || blk.type, dimType: 'ПОЗИЦИЯ', refElement: elementName,
          refElement2: '', mod1: '', mod2: '', extraSuffix: '',
          axes: [{ id: 'prgaxP' + idc, axis: 'TP', nominal: '', plusTol: blk.posTol === null ? '' : num(blk.posTol), minusTol: '' }],
          optLine: '', axisHeader: '', groupPath: target && target.group ? [target.group] : []
        });
        if (blk.posTol !== null) tolCount++;
        if (target) target._dimAxes = axisRows.map(function (r) { return { axis: r.axis, nominal: r.nominal, measured: r.measured, tol: r.tol, dev: r.dev }; });
        stats.dims += (diaRow ? 1 : 0) + 1;
      }

      /* r67 PrgCommands: full command walk (u16 OBTYPE + u32 len framing) */
      var PC = root.PrgCommands || (typeof require === 'function' ? (function () { try { return require('./prg-commands.js'); } catch (e) { return null; } })() : null);
      var cmdRes = null;
      if (PC) {
        try { cmdRes = PC.parse(part); } catch (e) { warnings.push('Обход команд r67: ' + e.message); }
      }
      if (cmdRes) {
        var added = 0, upd = 0;
        cmdRes.features.forEach(function (f) {
          if (!f.name) return;
          var ty = f.kind === 'plane' ? 'plane' : f.kind === 'circle' ? 'circle' : f.kind === 'cylinder' ? 'cylinder' : f.kind;
          var v = f.vec || [0, 0, 1];
          var prev = byName[f.name];
          var vals = { type: ty, group: f.group || (prev && prev.group) || '', x: num(f.X), y: num(f.Y), z: num(f.Z),
            i: fmtVec(v[0]), j: fmtVec(v[1]), k: fmtVec(v[2]), _vectorFromFile: !!f.vec, _axesConfirmed: true, _cmd: f.cmd, _obtype: f.obtype };
          if (f.diam !== null) vals.diam = num(f.diam);
          if (f.hitCount) { vals._hits = f.hits; vals._hitCount = f.hitCount; if (f.hitCount <= 200) vals.points = String(f.hitCount); }
          if (f.startAngle !== null && f.startAngle !== undefined) { vals.startAngle = num(f.startAngle); vals.endAngle = num(f.endAngle); }
          if (prev) { for (var k in vals) prev[k] = vals[k]; upd++; return; }
          var e = {
            id: 'prg' + (++idc), name: f.name, diam: f.diam === null ? '0' : num(f.diam), depth: '10',
            strategy: 'ПО_УМОЛЧ.', entry: 'ВХОД', points: '4', rows: '3', layers: '2', depthParam: '2',
            finishOffset: '5', step: '0', avoidBefore: '0', avoidAfter: '10',
            direction: 'ПРОТИВ ЧАСОВОЙ', angleVec: '0,0,1', startAngle: '0', endAngle: '360',
            constrFrom1: '', constrFrom2: '', outlierRemoval: 'ВЫКЛ,3', filterWave: '0',
            factSameAsNominal: true, hasTarget: true, factX: '', factY: '', factZ: '', factI: '', factJ: '', factK: '',
            factDiam: '', factDepth: '', open: true, extraLines: [], _profile: 'r67_' + f.kind, _axesOk: 3
          };
          for (var k2 in vals) e[k2] = vals[k2];
          byName[f.name] = e; elements.push(e); added++;
          if (ty === 'plane') stats.plane++;
        });
        /* r67 dims merge: размеры с допусками из кадра команд заменяют эвристические */
        if (cmdRes.dims && cmdRes.dims.length) {
          var nd = [], nt = 0;
          var fmt = function (v) { return v === null || v === undefined ? '' : String(v); };
          cmdRes.dims.forEach(function (d, k) {
            var base = String(d.name || '').replace(/^(DIAM_|POS_|DIM_|РАЗМ_|ПОЗ_)/i, '');
            var ref = byName[base] ? base : (byName[d.name] ? d.name : '');
            if (!ref) { for (var en in byName) if (base.indexOf(en) >= 0 && en.length > ref.length) ref = en; }
            var isDia = d.axes.length === 1 && d.axes[0].axis === 'D';
            nd.push({ id: 'prgdimR' + k, name: d.name, dimType: isDia ? 'ДИАМЕТР' : d.kind, refElement: ref || base, refElement2: '', mod1: '', mod2: '', extraSuffix: '',
              axes: d.axes.map(function (a, j) { if (a.plusTol !== null) nt++; return { id: 'prgaxR' + k + '_' + j, axis: a.axis, nominal: fmt(a.nominal), plusTol: fmt(a.plusTol), minusTol: fmt(a.minusTol) }; }),
              optLine: '', axisHeader: '', groupPath: d.group ? [d.group] : [] });
          });
          dimensions.length = 0; nd.forEach(function (d) { dimensions.push(d); });
          stats.dims = nd.length;
          warnings.push('r67: размеров из файла ' + nd.length + ', допусков прочитано ' + nt + ' (номинал / +доп / −доп — из полей команды).');
        }
        warnings.push('r67: прочитано команд программы ' + cmdRes.commands.length + ' (формат v' + cmdRes.version + '), автоэлементов с номиналами ' +
          cmdRes.features.length + ' — добавлено ' + added + ', уточнено ' + upd + '.');
      }
      if (!header.partName && opts.fileName) header.partName = String(opts.fileName).replace(/\.[^.]*$/, '');

      /* readable program outline (shown in the import summary) */
      var preview = outline.map(function (o) {
        var line = new Array(o.d + 1).join('   ') + o.t;
        var e = o.el && byName[o.el];
        if (e) {
          line += '   Ø' + e.diam + (e.factDiam ? ' (факт ' + e.factDiam + ')' : '');
          var xyz = [e.x && 'X' + e.x, e.y && 'Y' + e.y, e.z && 'Z' + e.z].filter(Boolean).join(' ');
          if (xyz) line += '   ' + xyz;
        }
        return line;
      });

      var typeList = Object.keys(typeHist).map(function (c) { var t = OBT.get(c); return { code: +c, id: t.id, ru: t.ru, cat: t.cat, count: typeHist[c] }; })
        .sort(function (x, y) { return y.count - x.count; });
      var catHist = {};
      typeList.forEach(function (t) { catHist[t.cat] = (catHist[t.cat] || 0) + t.count; });
      stats.types = typeList; stats.typeCats = catHist;
      stats.typeField = typeCal ? { mode: typeCal.mode, offset: typeCal.off, score: Math.round(typeCal.score * 1000) / 10 } : null;
      if (typeList.length) {
        var head = ['ТИПЫ КОМАНД (поле OBTYPE, ' + (typeCal.mode === 'end' ? 'конец−' : '+') + typeCal.off + ', совпадение ' + stats.typeField.score + '% записей):'];
        Object.keys(catHist).sort(function (x, y) { return catHist[y] - catHist[x]; }).forEach(function (c) {
          head.push('   ' + (OBT.catRu[c] || c) + ': ' + catHist[c]);
        });
        typeList.slice(0, 15).forEach(function (t) { head.push('      ' + t.ru + ' [' + t.id + '=' + t.code + '] ×' + t.count); });
        head.push('');
        preview = head.concat(preview);
        warnings.push('Типы команд прочитаны из поля OBTYPE: ' + typeList.slice(0, 5).map(function (t) { return t.ru + ' ×' + t.count; }).join(', ') +
          (typeList.length > 5 ? ' и ещё ' + (typeList.length - 5) + ' типов' : '') + '.');
      }

      warnings.push('Импортировано из родного .prg: элементов ' + elements.length +
        ' (цилиндров ' + stats.cylinder + ', позиций/диаметров ' + stats.posDia + ', окружностей ' + stats.circle + ')' +
        (stats.vectors ? ', направление оси прочитано из файла у ' + stats.vectors : '') + '.');
      if (stats.skipped) warnings.push('Пропущено записей без подтверждённой раскладки: ' + stats.skipped +
        ' (самопроверка Ø по имени не прошла). Плоскостей в программе: ' + stats.planes + ' — показаны в структуре, но не импортированы (раскладка не подтверждена).');
      if (stats.duplicates) warnings.push('Повторные записи одного элемента объединены: ' + stats.duplicates + '.');
      if (stats.dims) warnings.push('Блоков размеров распознано: ' + stats.dims + (tolCount ? ', допусков прочитано: ' + tolCount : '') +
        '. Смещения полей допуска пока не сверены с протоколом — проверьте значения.');
      else warnings.push('Допуски в файле не читались (поле не подтверждено) — подставьте их вручную во вкладке «Размеры».');

      if (cmdRes && PC) { preview = PC.outline(cmdRes, 5000); }
      return {
        header: header, elements: elements, dimensions: dimensions,
        warnings: warnings, flow: [], groupLines: {}, mvf: [], blade: null,
        preview: preview, stats: stats, commands: cmdRes ? cmdRes.commands : [], formatVersion: cmdRes ? cmdRes.version : null
      };
    }

    return {
      total: recs.length,
      step: function (n) {             // process up to n records; returns true when done
        var end = Math.min(recs.length, ri + n);
        for (; ri < end; ri++) processRecord(recs[ri]);
        return ri >= recs.length;
      },
      done: function () { return ri; },
      finish: finish
    };
  }

  function parseRealPrg(u8, opts) {
    var p = createParser(u8, opts);
    p.step(Infinity);
    return p.finish();
  }

  /* Same as parseRealPrg, but yields to the browser so a 80 MB program does not freeze the page.
   * opts.onProgress(doneRecords, totalRecords) is called between chunks. */
  function parseRealPrgAsync(u8, opts) {
    opts = opts || {};
    return new Promise(function (resolve, reject) {
      var p;
      try { p = createParser(u8, opts); } catch (e) { reject(e); return; }
      (function tick() {
        try {
          var t0 = Date.now(), fin = false;
          while (!fin && Date.now() - t0 < 40) fin = p.step(2000);
          if (opts.onProgress) opts.onProgress(p.done(), p.total);
          if (fin) resolve(p.finish()); else setTimeout(tick, 0);
        } catch (e) { reject(e); }
      })();
    });
  }

  var api = {
    parseRealPrg: parseRealPrg, parseRealPrgAsync: parseRealPrgAsync, isOle: isOle, cfbStreams: cfbStreams,
    walkRecords: walkRecords, stringsOf: stringsOf
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.PrgRealImport = api;
})(typeof window !== 'undefined' ? window : globalThis);