// ============================================================
//  «Чемпионат ЯМЗ» — общий профиль игрока и рейтинг по ВСЕМ играм
//  (покер, морской бой, лото, мафия, монополия).
//
//  Данные: championship.json рядом с сервером (сохраняются на диск,
//  переживают перезапуск). Ключ игрока — его yz_uid (общий для всех
//  страниц, хранится в браузере); без uid — hash имени.
//
//  Очки за победы: покер (рука) +5, морской бой +15, лото +25,
//  мафия (победа команды) +20, монополия +30, чемпион турнира +50 (и титул).
//  Серия = подряд выигранные партии/руки; поражение обнуляет.
//
//  Только встроенные модули Node.
// ============================================================
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const FILE = path.join(__dirname, 'championship.json');
const GAMES = ['poker', 'boy', 'ludo', 'mafia', 'monopoly'];
const POINTS = { poker: 5, boy: 15, ludo: 25, mafia: 20, monopoly: 30, champ: 50 };

let data = { v: 1, players: {} };
let saveTimer = null;

function load() {
  try {
    const raw = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    if (raw && typeof raw === 'object' && raw.players && typeof raw.players === 'object') data = raw;
  } catch (e) { /* нет файла/битый — начинаем заново */ }
}
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      const tmp = FILE + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(data, null, 1));
      fs.renameSync(tmp, FILE);
    } catch (e) { console.log('[Чемпионат] не удалось сохранить: ' + e.message); }
  }, 200);
}

function keyOf(uid, name) {
  if (uid) {
    const clean = String(uid).replace(/[^a-zA-Z0-9]/g, '').slice(0, 24);
    if (clean.length >= 4) return 'u' + clean;
  }
  const h = crypto.createHash('sha1').update(String(name || '').toLowerCase().trim()).digest('hex').slice(0, 16);
  return 'n' + h;
}

function ensure(key, name) {
  let pl = data.players[key];
  if (!pl) {
    pl = data.players[key] = {
      key, name: String(name || 'Игрок').slice(0, 20), avatar: null,
      rating: 0, series: 0, bestSeries: 0, titles: 0,
      wins: { poker: 0, boy: 0, ludo: 0, mafia: 0, monopoly: 0 },
      createdAt: Date.now(), lastSeen: Date.now(),
    };
    save();
  }
  pl.lastSeen = Date.now();
  if (name && pl.name !== name) pl.name = String(name).slice(0, 20);
  return pl;
}

function publicView(pl) {
  return {
    key: pl.key, name: pl.name, avatar: pl.avatar || null,
    rating: pl.rating, series: pl.series, bestSeries: pl.bestSeries, titles: pl.titles,
    wins: pl.wins,
  };
}

// победа: очки + серия
function recordWin(uid, name, game, points) {
  if (!POINTS[game]) return null;
  const pl = ensure(keyOf(uid, name), name);
  pl.rating += (points === undefined ? POINTS[game] : points);
  pl.series++;
  if (pl.series > pl.bestSeries) pl.bestSeries = pl.series;
  if (GAMES.indexOf(game) >= 0) pl.wins[game] = (pl.wins[game] || 0) + 1;
  if (game === 'champ') pl.titles++;
  save();
  return publicView(pl);
}

// поражение: серия обнуляется (если профиль уже есть)
function recordLoss(uid, name) {
  const pl = data.players[keyOf(uid, name)];
  if (!pl) return null;
  pl.series = 0;
  save();
  return publicView(pl);
}

function top(n) {
  n = n || 5;
  return Object.values(data.players)
    .filter(p => p.rating > 0 || p.titles > 0)
    .sort((a, b) => (b.rating - a.rating) || (b.bestSeries - a.bestSeries) || (b.lastSeen - a.lastSeen))
    .slice(0, n)
    .map(publicView);
}

function byUid(uid, name) {
  const pl = data.players[keyOf(uid, name)];
  return pl ? publicView(pl) : null;
}

function setAvatar(uid, name, dataUrl) {
  if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/') || dataUrl.length > 200000)
    return 'Картинка не прошла: только JPG/PNG, до ~150 КБ';
  const pl = ensure(keyOf(uid, name), name);
  pl.avatar = dataUrl;
  save();
  return null;
}

function clearAvatar(uid, name) {
  const pl = data.players[keyOf(uid, name)];
  if (pl) { pl.avatar = null; save(); }
  return null;
}

load();
module.exports = { recordWin, recordLoss, top, byUid, setAvatar, clearAvatar, keyOf, POINTS };
