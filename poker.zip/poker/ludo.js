// ============================================================
//  «Лото» (Ludo) — серверная логика (host-authoritative).
//  2–4 игрока, у каждого 4 фишки. Доехать до центра по кольцу
//  из 52 клеток + домашняя колонка (5 клеток).
//
//  Поле 15×15 [row, col]:
//    кольцо — периметр 14×14 (строк 0..13, колонок 0..13) = 52 клетки;
//    старты: красный (13,1)=1, синий (12,13)=14, жёлтый (0,12)=27, зелёный (1,0)=40;
//    домашние колонки (по 5 клеток к центру):
//      красный: (12,7),(11,7),(10,7),(9,7),(8,7)   вход с (13,7)
//      синий:   (7,12),(7,11),(7,10),(7,9),(7,8)   вход с (7,13)
//      жёлтый:  (1,7),(2,7),(3,7),(4,7),(5,7)      вход с (0,7)
//      зелёный: (7,1),(7,2),(7,3),(7,4),(7,5)      вход с (7,0)
//    безопасные: 4 старта + 4 звезды (старт+7).
//
//  Правила (упрощённая классика):
//    * шестёрка — вывод фишки из базы и дополнительный бросок
//      (три шестёрки подряд — ход сгорает);
//    * на кольце (не в безопасной клетке) фишка противника сбрасывается в базу;
//    * на свою фишку встать нельзя;
//    * финиш — только точное число (63-й шаг);
//    * победил, кто первым привёз все 4 фишки.
//
//  WS: /ws-ludo, JSON-сообщения (как в покере). Только встроенные модули Node.
// ============================================================
'use strict';
const crypto = require('crypto');
const champ = require('./championship'); // 🏆 «Чемпионат ЯМЗ»

const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const SIZE = 15;
const TURN_MS = 30000;        // время на бросок/ход
const GONE_HARD_MS = 10 * 60000;
const GRACE_MS = 60000;
const HOME_LEN = 5;           // клеток в домашней колонке
const TOTAL = 58 + HOME_LEN;  // 63 шага от старта до финиша (d=63 — дома)
const MAX_PLAYERS = 4;

const COLORS = ['red', 'blue', 'yellow', 'green'];
const COLOR_RU = { red: 'красный', blue: 'синий', yellow: 'жёлтый', green: 'зелёный' };

// ---------- поле ----------
// кольцо 52 клетки: периметр 14×14 (r,c ∈ 0..13), против часовой
const TRACK = (() => {
  const t = [];
  for (let c = 0; c <= 13; c++) t.push([13, c]);        // низ: (13,0)..(13,13)  idx 0..13
  for (let r = 12; r >= 0; r--) t.push([r, 13]);        // право: (12,13)..(0,13) idx 14..26
  for (let c = 12; c >= 0; c--) t.push([0, c]);         // верх: (0,12)..(0,0)    idx 27..39
  for (let r = 1; r <= 12; r++) t.push([r, 0]);         // лево:  (1,0)..(12,0)   idx 40..51
  return t;
})();
const START = [1, 14, 27, 40];            // idx старта по цвету (red, blue, yellow, green)
// шаг, на котором фишка стоит на клетке входа (последний шаг по кольцу):
// вход = клетка трека, соседняя с первой клеткой домашней колонки
const ENTRY = [58, 57, 57, 58];
const FINISH = [63, 62, 62, 63];          // = ENTRY + 5 (дом — 5 клеток)
const HOME = [
  [[12, 7], [11, 7], [10, 7], [9, 7], [8, 7]],
  [[7, 12], [7, 11], [7, 10], [7, 9], [7, 8]],
  [[1, 7], [2, 7], [3, 7], [4, 7], [5, 7]],
  [[7, 1], [7, 2], [7, 3], [7, 4], [7, 5]],
];
const SAFE = new Set([1, 8, 14, 21, 27, 34, 40, 47]);   // 4 старта + 4 звезды (старт+7)
const rcKey = (r, c) => r * SIZE + c;

// служебная проверка геометрии при запуске (сбрасывает сервер при ошибке кода)
(function selfCheck() {
  const seen = new Set();
  for (let i = 0; i < TRACK.length; i++) {
    const [r, c] = TRACK[i];
    if (seen.has(rcKey(r, c))) throw new Error('ludo: дубликаты в кольце');
    seen.add(rcKey(r, c));
    const [nr, nc] = TRACK[(i + 1) % TRACK.length];
    if (Math.abs(nr - r) + Math.abs(nc - c) !== 1) throw new Error('ludo: разрыв кольца в ' + i);
  }
  if (TRACK.length !== 52) throw new Error('ludo: кольцо не из 52 клеток');
  for (let ci = 0; ci < 4; ci++) {
    const e = TRACK[(START[ci] + ENTRY[ci]) % 52]; // клетка входа E
    const h0 = HOME[ci][0];
    if (Math.abs(h0[0] - e[0]) + Math.abs(h0[1] - e[1]) !== 1) throw new Error('ludo: вход ' + ci + ' не соседний');
    for (let k = 0; k < HOME_LEN - 1; k++) {
      const a = HOME[ci][k], b = HOME[ci][k + 1];
      if (Math.abs(b[0] - a[0]) + Math.abs(b[1] - a[1]) !== 1) throw new Error('ludo: колонка ' + ci + ' не соседняя');
    }
    const fin = HOME[ci][HOME_LEN - 1];
    // финиш — в центре 3×3 или вплотную к нему
    const dr = Math.max(6 - fin[0], 0, fin[0] - 8), dc = Math.max(6 - fin[1], 0, fin[1] - 8);
    if (Math.max(dr, dc) > 1) throw new Error('ludo: финиш ' + ci + ' не у центра');
  }
})();

// позиция фишки: d = шаг от старта (0..FINISH[ci]). d<0 — в базе.
// d 0..ENTRY[ci]: кольцо idx (start+d) mod 52; ENTRY+1..ENTRY+4: колонка; ENTRY+5: дома.
function tokenCell(ci, d) {
  if (d < 0) return null;
  if (d <= ENTRY[ci]) return TRACK[(START[ci] + d) % 52];
  if (d <= FINISH[ci] - 1) return HOME[ci][d - ENTRY[ci] - 1];
  return [7, 7]; // центр
}
function tokenTrackIdx(ci, d) { return d >= 0 && d <= ENTRY[ci] ? (START[ci] + d) % 52 : -1; }

// ---------- состояние ----------
let idc = 0;
const st = {
  phase: 'waiting', // waiting | playing | over
  slots: [null, null, null, null],
  hostId: null,
  turn: -1,
  stage: null,      // 'roll' | 'move'
  dice: null,
  sixCount: 0,
  movable: [],      // индексы фишек текущего игрока, которыми можно ходить
  deadline: 0,
  turnTimer: null,
  winner: -1,
  winOrder: [],
  logs: [],
  chat: [],
};

function log(msg) {
  st.logs.push({ t: msg, ts: Date.now() });
  if (st.logs.length > 80) st.logs.shift();
  console.log('[Лото] ' + msg);
}
function players() { return st.slots.filter(Boolean); }
function playerById(id) { return players().find(p => p.id === id) || null; }
function activePlayers() { return st.slots.map((p, i) => p && !p.done ? i : -1).filter(i => i >= 0); }

function send(p, obj) {
  if (p && p.ws) { try { p.ws.write(wsFrame(0x1, Buffer.from(JSON.stringify(obj), 'utf8'))); } catch (e) {} }
}
function broadcast() { for (const p of players()) send(p, stateFor(p)); }
function sendRaw(conn, obj) {
  if (conn.player && conn.player.ws === conn.sock) send(conn.player, obj);
  else { try { conn.sock.write(wsFrame(0x1, Buffer.from(JSON.stringify(obj), 'utf8'))); } catch (e) {} }
}

// ---------- игроки ----------
function join(sock, name, pid, uid) {
  name = String(name || '').trim().slice(0, 20) || 'Игрок';
  let ex = null;
  if (pid) ex = playerById(pid);
  if (!ex) ex = players().find(p => p.name === name && !p.connected && !p.isBot) || null;
  if (ex) {
    if (ex.ws && ex.ws !== sock) { try { ex.ws.destroy(); } catch (e) {} }
    ex.ws = sock; ex.connected = true;
    if (uid) ex.uid = uid;
    if (ex.goneTimer) { clearTimeout(ex.goneTimer); ex.goneTimer = null; }
    log('🔌 ' + ex.name + ' снова в игре');
    afterJoin();
    return ex;
  }
  const seat = st.slots.indexOf(null);
  if (seat === -1) return { err: 'Лото — до 4 игроков: все места заняты' };
  const p = {
    id: 'l' + (++idc), name, seat, uid: uid || null, ws: sock,
    connected: true, isBot: false, done: false,
    tokens: [-1, -1, -1, -1],
    botTimer: null, goneTimer: null, wsConn: null,
  };
  st.slots[seat] = p;
  if (!st.hostId) st.hostId = p.id;
  log('🎲 ' + name + ' (' + COLOR_RU[COLORS[seat]] + ') в игре');
  afterJoin();
  return p;
}

function afterJoin() {
  broadcast();
}

function sitOut(p, why) {
  st.slots[p.seat] = null;
  if (p.ws) { try { p.ws.destroy(); } catch (e) {} }
  if (p.goneTimer) { clearTimeout(p.goneTimer); p.goneTimer = null; }
  if (p.botTimer) { clearTimeout(p.botTimer); p.botTimer = null; }
  log('👋 ' + p.name + (why ? ' — ' + why : ' вышел(ла) из игры'));
  if (p.id === st.hostId) st.hostId = null;
  const seated = players();
  if (st.phase === 'playing') {
    const act = activePlayers();
    if (act.length < 2) {
      endGame(-1, 'Игроков меньше двух — игра остановлена');
    } else if (!act.includes(st.turn)) {
      advanceTurn();
    }
  } else if (st.phase === 'waiting' && st.hostId === null && seated.length) {
    st.hostId = seated[0].id;
  }
  if (seated.length === 1 && st.phase !== 'over') {
    endGame(seated[0].seat, seated[0].name + ' остался(лась) один(а) — победа по сданию');
  }
  // отключившиеся и не вернувшиеся — освобождаем (рекурсия один уровень)
  for (const q of [...players()]) {
    if (!q.isBot && !q.connected) { log('🗑 ' + q.name + ' — не вернулся, место освобождено'); sitOut(q); return; }
  }
  broadcast();
}

function onDisconnect(p) {
  p.connected = false;
  if (p.isBot) return;
  log('🔌 ' + p.name + ' отключился');
  if (p.goneTimer) clearTimeout(p.goneTimer);
  const grace = st.phase === 'playing' ? GONE_HARD_MS : GRACE_MS;
  p.goneTimer = setTimeout(() => { if (!p.connected) sitOut(p, 'не вернулся вовремя'); }, grace);
  broadcast();
}

// ---------- игра ----------
function newGame(initiator) {
  for (const p of players()) {
    p.done = false; p.tokens = [-1, -1, -1, -1];
    if (p.botTimer) { clearTimeout(p.botTimer); p.botTimer = null; }
  }
  st.phase = 'playing'; st.turn = -1; st.stage = null; st.dice = null; st.sixCount = 0;
  st.movable = []; st.winner = -1; st.winOrder = [];
  st.logs = []; st.chat = [];
  log('— Игра началась: ' + players().length + ' игрока —');
  advanceTurn();
  return null;
}

function advanceTurn() {
  if (st.phase !== 'playing') return; // игра уже закончилась (тутер мог быть запланирован ранее)
  const act = activePlayers();
  if (act.length === 0) { endGame(st.winner, 'Все закончили'); return; }
  let idx = act.indexOf(st.turn);
  if (idx === -1) idx = 0;
  else if (act.length > 1) idx = (idx + 1) % act.length;
  st.turn = act[idx];
  st.stage = 'roll'; st.dice = null; st.sixCount = 0; st.movable = [];
  st.deadline = Date.now() + TURN_MS;
  const p = st.slots[st.turn];
  log('🎲 Ход: ' + p.name);
  clearTimeout(st.turnTimer);
  st.turnTimer = setTimeout(() => turnTimeout(p), TURN_MS);
  broadcast();
  if (p.isBot) scheduleBot(p);
}

function rollDice(p) {
  if (st.phase !== 'playing' || st.slots[st.turn] !== p || st.stage !== 'roll') return 'Сейчас не ваш ход';
  clearTimeout(st.turnTimer); st.turnTimer = null;
  const d = 1 + ((Math.random() * 6) | 0);
  st.dice = d;
  log(p.name + ' бросает: ' + d);
  // что можно ходить
  st.movable = [];
  for (let t = 0; t < 4; t++) {
    const pos = p.tokens[t];
    if (pos === FINISH[p.seat]) continue;
    if (pos < 0) { if (d === 6) st.movable.push(t); continue; }
    if (pos + d > FINISH[p.seat]) continue; // финиш только точный
    // нельзя встать на свою фишку (на кольце)
    const idx = tokenTrackIdx(p.seat, pos + d);
    if (idx >= 0 && p.tokens.some((q, i2) => i2 !== t && tokenTrackIdx(p.seat, q) === idx)) continue;
    st.movable.push(t);
  }
  if (st.movable.length === 0) {
    st.stage = null;
    log(p.name + (d === 6 ? ' — шестёрка, но ходить нечем' : ' — ходить некуда'));
    st.turnTimer = setTimeout(() => advanceTurn(), 800);
    broadcast();
    return null;
  }
  st.stage = 'move';
  st.deadline = Date.now() + TURN_MS;
  st.turnTimer = setTimeout(() => turnTimeout(p), TURN_MS);
  broadcast();
  if (p.isBot) scheduleBot(p);
  return null;
}

function moveToken(p, t) {
  if (st.phase !== 'playing' || st.slots[st.turn] !== p || st.stage !== 'move') return 'Сейчас не ваш ход';
  if (st.movable.indexOf(t) === -1) return 'Этой фишкой сейчас нельзя ходить';
  clearTimeout(st.turnTimer); st.turnTimer = null;
  const from = p.tokens[t];
  const d = from + st.dice;
  p.tokens[t] = d;
  // захват (только на кольце, не в безопасной клетке)
  const idx = tokenTrackIdx(p.seat, d);
  if (idx >= 0 && !SAFE.has(idx)) {
    for (const q of players()) {
      if (q === p) continue;
      for (let i2 = 0; i2 < 4; i2++) {
        if (q.tokens[i2] >= 0 && q.tokens[i2] <= ENTRY[q.seat] && tokenTrackIdx(q.seat, q.tokens[i2]) === idx) {
          q.tokens[i2] = -1;
          log('💥 ' + p.name + ' сбрасывает ' + q.name + ' в базу!');
        }
      }
    }
  }
  log(p.name + ': фишка ' + (d < 0 ? 'в базе' : d <= ENTRY[p.seat] ? 'на кольце' : d === FINISH[p.seat] ? 'ДОМА 🏠' : 'в колонке'));
  if (d === FINISH[p.seat]) {
    p.done = p.tokens.every(x => x === FINISH[p.seat]);
    if (p.done) {
      st.winOrder.push(p.name);
      log('🏁 ' + p.name + ' привёз(ла) все фишки!');
      if (st.winner === -1) {
        champ.recordWin(p.uid, p.name, 'ludo', champ.POINTS.ludo); // 🏆 чемпионат ЯМЗ
        for (const q of players()) if (q !== p && !q.isBot) champ.recordLoss(q.uid, q.name);
      }
      endGame(p.seat, p.name);
      return null;
    }
  }
  // шестёрка: ещё один бросок (три подряд — сгорает)
  if (st.dice === 6) {
    st.sixCount++;
    if (st.sixCount >= 3) {
      log('⚠️ ' + p.name + ' — три шестёрки подряд, ход сгорает');
      st.stage = 'roll'; st.dice = null; st.sixCount = 0;
      st.turn = -1;
      st.turnTimer = setTimeout(() => advanceTurn(), 800);
      broadcast();
      return null;
    }
    st.stage = 'roll'; st.dice = null;
    st.deadline = Date.now() + TURN_MS;
    st.turnTimer = setTimeout(() => turnTimeout(p), TURN_MS);
    broadcast();
    if (p.isBot) scheduleBot(p);
  } else {
    st.turn = -1;
    st.turnTimer = setTimeout(() => advanceTurn(), 500);
    broadcast();
  }
  return null;
}

function turnTimeout(p) {
  st.turnTimer = null;
  if (st.phase !== 'playing' || st.slots[st.turn] !== p) return;
  if (st.stage === 'roll') { log('⏰ ' + p.name + ' — время вышло (бросок за него)'); rollDice(p); }
  else if (st.stage === 'move' && st.movable.length) {
    log('⏰ ' + p.name + ' — время вышло (случайный ход)');
    moveToken(p, st.movable[(Math.random() * st.movable.length) | 0]);
  }
}

function endGame(winnerSeat, msg) {
  st.phase = 'over'; st.turn = -1; st.stage = null; st.movable = [];
  clearTimeout(st.turnTimer); st.turnTimer = null;
  if (winnerSeat >= 0) st.winner = winnerSeat;
  if (msg) log('🏆 ' + msg);
  broadcast();
}

// ---------- боты ----------
function addBot() {
  const seat = st.slots.indexOf(null);
  if (seat === -1) return 'Мест нет (максимум 4)';
  let n = players().filter(p => p.isBot).length + 1;
  let name = 'Бот-' + n;
  while (players().some(p => p.name === name)) name = 'Бот-' + (++n);
  const b = {
    id: 'l' + (++idc), name, seat, uid: null, ws: null,
    connected: true, isBot: true, done: false,
    tokens: [-1, -1, -1, -1], botTimer: null, goneTimer: null, wsConn: null,
  };
  st.slots[seat] = b;
  log('🤖 ' + name + ' (' + COLOR_RU[COLORS[seat]] + ') зашёл');
  if (st.phase === 'waiting' && players().length >= 2) newGame(st.hostId ? playerById(st.hostId) : players()[0]);
  broadcast();
  return null;
}

function removeBot(p) {
  const b = players().find(q => q.isBot);
  if (!b) return 'Бота нет';
  sitOut(b, 'убран хостом');
  return null;
}

function scheduleBot(p) {
  if (p.botTimer) clearTimeout(p.botTimer);
  p.botTimer = setTimeout(() => {
    p.botTimer = null;
    if (st.phase !== 'playing' || st.slots[st.turn] !== p || p.isBot !== true) return;
    if (st.stage === 'roll') { rollDice(p); return; }
    if (st.stage === 'move' && st.movable.length) {
      moveToken(p, botPick(p));
    }
  }, 1200 + Math.random() * 1500);
}

function botPick(p) {
  // приоритет: дом > захват > безопасная клетка > самая дальняя фишка
  const scored = st.movable.map(t => {
    const pos = p.tokens[t];
    const d = pos + st.dice;
    let score = 0;
    if (d === FINISH[p.seat]) score = 10000;
    else if (pos < 0) score = 800 + st.dice; // вывел фишку
    else {
      const idx = tokenTrackIdx(p.seat, d);
      if (idx >= 0) {
        if (SAFE.has(idx)) score += 500;
        for (const q of players()) if (q !== p && q.tokens.some(x => x >= 0 && x <= ENTRY[q.seat] && tokenTrackIdx(q.seat, x) === idx)) score += 2000;
      }
      score += d; // дальность
    }
    return { t, score };
  }).sort((a, b) => b.score - a.score);
  return scored[0].t;
}

// ---------- состояние для клиента ----------
function stateFor(p) {
  const s = {
    t: 'state',
    phase: st.phase,
    mySeat: p ? p.seat : -1,
    myId: p ? p.id : null,
    isHost: !!(p && p.id === st.hostId),
    turn: st.turn, stage: st.stage, dice: st.dice, sixCount: st.sixCount,
    movable: (p && st.slots[st.turn] === p && st.stage === 'move') ? st.movable : [],
    deadline: (st.stage === 'roll' || st.stage === 'move') ? st.deadline : 0,
    winner: st.winner, winOrder: st.winOrder,
    logs: st.logs.slice(-40),
    chat: st.chat.slice(-25),
    slots: st.slots.map((x, i) => x ? {
      id: x.id, name: x.name, color: COLORS[i],
      connected: x.connected, bot: !!x.isBot, done: !!x.done,
      tokens: x.tokens.slice(),
      finish: FINISH[i],
      tokensHome: x.tokens.filter(v => v === FINISH[i]).length,
    } : null),
  };
  return s;
}

function ludoStatus() {
  return { players: players().length, phase: st.phase, inGame: st.phase === 'playing' };
}

// ---------- WebSocket (RFC6455, как в покере) ----------
function wsFrame(opcode, payload) {
  const len = payload.length;
  let header;
  if (len < 126) header = Buffer.from([0x80 | opcode, len]);
  else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x80 | opcode; header[1] = 126; header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x80 | opcode; header[1] = 127; header.writeBigUInt64BE(BigInt(len), 2);
  }
  return Buffer.concat([header, payload]);
}

function closeConn(conn) {
  if (conn.closed) return;
  conn.closed = true;
  try { conn.sock.write(wsFrame(0x8, Buffer.from([]))); } catch (e) {}
  setTimeout(() => { try { conn.sock.destroy(); } catch (e) {} }, 300);
}

function onDrop(conn) {
  const p = conn.player;
  if (p && p.ws === conn.sock) { // если уже пере-подключился — этот сокет его не касается
    p.ws = null; p.wsConn = null;
    onDisconnect(p);
  }
}

function handleMsg(conn, text) {
  let m;
  try { m = JSON.parse(text); } catch (e) { return; }
  conn.lastSeen = Date.now();
  const p = conn.player;
  if (!p) {
    if (m.t !== 'join') return;
    const r = join(conn.sock, m.name, m.pid, m.uid);
    if (r && r.err) { sendRaw(conn, { t: 'error', msg: r.err }); return; }
    if (r) { conn.player = r; r.wsConn = conn; }
    send(r, { t: 'board', size: SIZE, track: TRACK, home: HOME, start: START, safe: [...SAFE], entry: ENTRY, finish: FINISH }); // статика поля
    send(r, stateFor(r));
    return;
  }
  switch (m.t) {
    case 'start': {
      if (st.phase !== 'waiting') { send(p, { t: 'error', msg: 'Игра уже идёт' }); break; }
      if (players().length < 2) { send(p, { t: 'error', msg: 'Нужно минимум 2 игрока' }); break; }
      newGame(p);
      break;
    }
    case 'newGame': {
      if (st.phase !== 'over') { send(p, { t: 'error', msg: 'Новая игра — после завершения' }); break; }
      newGame(p);
      break;
    }
    case 'roll': { const e = rollDice(p); if (e) send(p, { t: 'error', msg: e }); break; }
    case 'move': { const e = moveToken(p, Math.floor(Number(m.token))); if (e) send(p, { t: 'error', msg: e }); break; }
    case 'addBot': { const e = addBot(); if (e) send(p, { t: 'error', msg: e }); break; }
    case 'removeBot': { const e = removeBot(p); if (e) send(p, { t: 'error', msg: e }); break; }
    case 'leave': { sitOut(p, 'покинул(а) игру'); break; }
    case 'chat': {
      const txt = String(m.msg || '').trim().slice(0, 200);
      let img = null;
      if (m.img) {
        if (typeof m.img === 'string' && m.img.startsWith('data:image/') && m.img.length <= 400000) img = m.img;
        else if (!txt) { send(p, { t: 'error', msg: 'Картинка не прошла: только JPG/PNG, до ~300 КБ' }); return; }
      }
      if (!txt && !img) return;
      st.chat.push({ from: p.name, bot: p.isBot, msg: txt, img: img ? true : null, ts: Date.now() });
      if (st.chat.length > 100) st.chat.shift();
      const live = { t: 'chat', from: p.name, bot: p.isBot, msg: txt };
      if (img) live.img = img;
      for (const q of players()) send(q, live);
      break;
    }
  }
}

function handleLudoUpgrade(req, socket) {
  const key = req.headers['sec-websocket-key'];
  if (!key) { socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + WS_GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  const conn = { sock: socket, player: null, closed: false, lastSeen: Date.now() };
  let buf = Buffer.alloc(0);
  socket.on('data', chunk => {
    conn.lastSeen = Date.now();
    buf = Buffer.concat([buf, chunk]);
    while (true) {
      if (buf.length < 2) return;
      const opcode = buf[0] & 0x0f;
      const masked = (buf[1] & 0x80) !== 0;
      let len = buf[1] & 0x7f; let off = 2;
      if (len === 126) { if (buf.length < off + 2) return; len = buf.readUInt16BE(off); off += 2; }
      else if (len === 127) { if (buf.length < off + 8) return; len = Number(buf.readBigUInt64BE(off)); off += 8; }
      if (len > 1e6) { closeConn(conn); return; }
      let mask = null;
      if (masked) { if (buf.length < off + 4) return; mask = buf.slice(off, off + 4); off += 4; }
      if (buf.length < off + len) return;
      const payload = Buffer.from(buf.slice(off, off + len));
      buf = buf.slice(off + len);
      if (masked) for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
      if (opcode === 0x8) { closeConn(conn); return; }
      else if (opcode === 0x9) { try { socket.write(wsFrame(0xA, payload)); } catch (e) {} }
      else if (opcode === 0xA) { conn.lastSeen = Date.now(); }
      else if (opcode === 0x1 || opcode === 0x0) { handleMsg(conn, payload.toString('utf8')); }
    }
  });
  socket.on('close', () => onDrop(conn));
  socket.on('error', () => onDrop(conn));
}

// ping/keepalive
setInterval(() => {
  for (const p of [...players()]) {
    if (!p.ws) continue;
    try { p.ws.write(wsFrame(0x9, Buffer.from([]))); } catch (e) {}
    if (Date.now() - ((p.wsConn && p.wsConn.lastSeen) || 0) > 75000) {
      log('🔌 ' + p.name + ' отключился (нет ответа)');
      try { p.ws.destroy(); } catch (e) {}
    }
  }
}, 25000);

module.exports = { handleLudoUpgrade, ludoStatus, _debug: { TRACK, START, HOME, SAFE, tokenCell } };
