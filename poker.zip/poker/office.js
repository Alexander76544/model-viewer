// ============================================================
//  «Офисная тема» — общий хром окна Microsoft Excel для всех
//  страниц подпольного ЯМЗ (максимальная маскировка).
//
//  Страница задаёт конфигурацию ПЕРЕД подключением:
//     <script>window.OFFICE = { doc:'Имя_файла.xlsx',
//       tabs:['Лист1','Лист2'], formula:'=СУММ(B2:B50)', cell:'B4',
//       flow:true /* лобби: обычный поток, со скроллом */ };</script>
//     <script src="/office.js"></script>
//
 //  Что делает:
 //   - зелёный заголовок «Microsoft Excel — имя.xlsx» + кнопки окна
 //     (кнопка «✕» запускает босс-режим, если доступен YAMZ_PANIC);
 //   - меню Файл/Правка/Вид/… и псевдо-ленту с кнопками;
 //   - строку формул (ячейка + fx + формула);
 //   - вкладки листов внизу и статус-бар «Готово» с часами;
 //   - переносит текущее содержимое body во внутреннюю область
 //     и подгоняет fixed-блоки игр под границы окна;
 //   - Excel-сетку позади всего окна: буквы столбцов A.., номера строк 1..,
 //     линии ячеек 92×22 — страница выглядит как настоящий лист;
 //   - панели журнала/чата/участников оформляет как строки-ячейки
 //     с номерами строк слева; поле ввода чата — как ячейка;
  //   - у каждой секции панели кнопка «▾»/«▸»: скрывает её ПОЛНОСТЬЮ
  //     (включая заголовок) только на своём экране — для маскировки;
  //   - «▾» в заголовке окна скрывает ВСЁ верхнее меню (заголовок, меню,
  //     ленту, строку формул): лист занимает окно целиком, ячейки до
  //     самого края; возвращает угловая кнопка «▾».
  //   - «▾» в шапке игрового документа скрывает её ПОЛНОСТЬЮ — строка
  //     становится обычными ячейками листа; возвращает маленькая «▸»
  //     в левом верхнем углу области игры.
// ============================================================
(function () {
  'use strict';
  const cfg = window.OFFICE;
  if (!cfg) return;
  const DOC = cfg.doc || 'Рабочая_книга.xlsx';
  const TABS = (cfg.tabs && cfg.tabs.length) ? cfg.tabs : ['Лист1', 'Лист2'];
  const F = cfg.formula || '=СУММ(B2:B100)';
  const CELL = cfg.cell || 'C4';
  const esc = s => String(s).replace(/[&<>"]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]));

  const style = document.createElement('style');
  style.id = 'ow-style';
  style.textContent = `
    html,body{height:100%;}
    body{display:flex !important; flex-direction:column !important; overflow:hidden !important; margin:0 !important; background:#fff; font-family:Tahoma,'Segoe UI',Arial,sans-serif;}
    .ow-top{flex:none; user-select:none; z-index:500;}
    /* заголовок — тёмно-зелёная тема Office, поиск по центру */
    .ow-title{height:27px; background:#185C37; color:#fff; display:flex; align-items:center; padding:0 6px; gap:6px; font-size:11px; line-height:1;}
    .ow-xic{width:16px; height:16px; flex:none; background:#fff; color:#185C37; font-weight:700; font-size:11px; display:flex; align-items:center; justify-content:center; font-family:Arial,sans-serif;}
    .ow-ttext{flex:1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; color:rgba(255,255,255,.95);}
    .ow-search{margin:0 auto; width:170px; height:17px; flex:none; background:rgba(255,255,255,.16); border:1px solid rgba(255,255,255,.25); border-radius:3px; display:flex; align-items:center; gap:5px; padding:0 7px; color:rgba(255,255,255,.85); font-size:10.5px;}
    .ow-srch{position:relative; width:9px; height:9px; border:1.5px solid rgba(255,255,255,.85); border-radius:50%; flex:none;}
    .ow-srch::after{content:''; position:absolute; right:-4px; bottom:-3px; width:4px; height:1.5px; background:rgba(255,255,255,.85); transform:rotate(45deg);}
    .ow-people{position:relative; width:12px; height:11px; flex:none;}
    .ow-people::before{content:''; position:absolute; left:2px; top:0; width:5px; height:5px; border:1.5px solid rgba(255,255,255,.9); border-radius:50%;}
    .ow-people::after{content:''; position:absolute; left:0; top:6.5px; width:9px; height:4.5px; border:1.5px solid rgba(255,255,255,.9); border-bottom:none; border-radius:5px 5px 0 0;}
    .ow-tbtns{margin-left:auto; display:flex; align-items:center; flex:none;}
    .ow-wbtn{width:30px; height:19px; text-align:center; font-size:11px; line-height:18px; color:#fff; cursor:default; flex:none;}
    .ow-wbtn:hover{background:rgba(255,255,255,.14);}
    .ow-wbtn.x:hover{background:#E81123;}
    .ow-wbtn[data-ow]{cursor:pointer;}
    .ow-cloud{width:18px; height:17px; flex:none; margin:0 2px; background:#2B7CD3; border-radius:2px; color:#fff; font-size:10px; display:flex; align-items:center; justify-content:center;}
    .ow-share{flex:none; margin-left:5px; height:19px; padding:0 9px; display:flex; align-items:center; gap:5px; background:rgba(255,255,255,.16); border:1px solid rgba(255,255,255,.4); border-radius:3px; color:#fff; font-size:10.5px; cursor:pointer;}
    .ow-share:hover{background:rgba(255,255,255,.28);}
    /* полное скрытие верхнего меню (заголовок+меню+лента+формулы) и
       нижнего (вкладки+статус-бар): ячейки доходят до края окна;
       возвращает маленькая кнопка «▴» в углу */
    .ow-top.ow-off{display:none !important;}
    .ow-tminus{width:20px; height:20px; border:1px solid #c8c8c8; background:#fff; color:#444; display:flex; align-items:center; justify-content:center; margin-left:6px; font-size:11px; cursor:pointer; flex:none;}
    .ow-tminus:hover{border-color:#217346; color:#217346;}
    .ow-rest{position:fixed; z-index:501; width:18px; height:14px; box-sizing:border-box; background:#f4f6f8; border:1px solid #c9ced6; color:#6b7280; font:9px Tahoma,Arial,sans-serif; line-height:12px; text-align:center; cursor:pointer; display:none; user-select:none;}
    .ow-rest:hover{background:#e2f0e8; color:#217346; border-color:#9fcdb2;}
    #ow-top-rest{top:1px; left:1px;}
    /* вкладки меню (лента) — как в настоящем Excel */
    .ow-menu{height:23px; background:#fff; border-bottom:1px solid #e6e3e1; display:flex; align-items:stretch; padding:0 6px; font-size:11px; color:#252423;}
    .ow-mtab{display:flex; align-items:center; padding:0 8px; cursor:default; white-space:nowrap;}
    .ow-mtab:hover{background:#f3f2f1;}
    .ow-mtab.file{font-weight:600;}
    .ow-mtab.on{color:#107C41; font-weight:600; box-shadow:inset 0 -2px 0 #107C41;}
    /* лента: группы с иконками и подписями снизу */
    .ow-ribbon{height:84px; background:#faf9f8; border-bottom:1px solid #e1dfdd; display:flex; align-items:stretch; padding:3px 2px 0; overflow:hidden;}
    .ow-rb{flex:none; display:flex; flex-direction:column; padding:1px 4px 0; border-right:1px solid #e6e3e1; min-width:0;}
    .ow-rb:last-child{border-right:0;}
    .ow-rb-rows{flex:1; display:flex; flex-direction:column; justify-content:center; gap:2px; min-width:0;}
    .ow-rb-row{display:flex; align-items:center; gap:2px; min-width:0;}
    .ow-rb-lab{flex:none; font-size:9px; color:#797775; text-align:center; padding:2px 0 3px; line-height:1; white-space:nowrap; overflow:hidden;}
    .ow-rb-btn{display:flex; align-items:center; gap:4px; border:1px solid transparent; background:transparent; color:#252423; font-size:10px; padding:1px 4px; cursor:pointer; line-height:1.2; text-align:left; white-space:nowrap;}
    .ow-rb-btn:hover{background:#eef6f1; border-color:#c9e2d3;}
    .ow-rb-ic{flex:none; width:16px; height:16px; display:flex; align-items:center; justify-content:center; font-size:12px; color:#444;}
    .ow-rb-lg .ow-rb-ic{width:20px; height:20px; font-size:15px;}
    .ow-rb-dd{font-size:8px; color:#797775; flex:none;}
    .ow-fontbox{border:1px solid #c8c6c4; background:#fff; font-size:10px; padding:0 3px; height:16px; display:flex; align-items:center; gap:3px; color:#252423; cursor:pointer;}
    .ow-fontbox.small{min-width:26px; justify-content:center;}
    .ow-ab{font-weight:700;} .ow-ai{font-style:italic;} .ow-au{text-decoration:underline;} .ow-as{text-decoration:line-through;}
    .ow-ar{color:#fff; background:#d13438; font-weight:700; padding:0 2px;}
    .ow-ahl{background:#ffe8a3; padding:0 2px; font-weight:700;}
    .ow-al{width:14px; height:12px; flex:none; display:flex; flex-direction:column; gap:2px; align-self:center;}
    .ow-al i{display:block; height:2px; background:#555;}
    .ow-al.c i{margin:0 auto;} .ow-al.c i:nth-child(2){width:70%;}
    .ow-al.r i{margin-left:auto;} .ow-al.r i:nth-child(2){width:70%;}
    .ow-al.j i:nth-child(2){width:70%; margin:0 auto;}
    .ow-sty{width:68px; display:flex; align-items:center; gap:3px; border:1px solid #d7d4d0; background:#fff; font-size:8px; padding:0 4px; color:#252423; cursor:pointer; white-space:nowrap;}
    .ow-stys{display:grid; grid-template-columns:repeat(3,68px); gap:2px; align-content:center;}
    .ow-sty i{width:8px; height:10px; flex:none; border:1px solid rgba(0,0,0,.25); background:repeating-linear-gradient(to bottom,#fff 0 3px,#e9e9e9 3px 4px);}
    .ow-sty.b{color:#1F4E78;} .ow-sty.o{color:#C45911;} .ow-sty.r{color:#C00000;} .ow-sty.g{color:#375623;} .ow-sty.y{color:#7F6000;}
    .ow-sty.hot{border-color:#E26B0A; background:#fdf4e8;}
    /* строка формул: имя ячейки + fx + поле */
    .ow-fbar{height:20px; background:#fff; display:flex; align-items:center; border-bottom:1px solid #e1dfdd; font-size:11px; padding:0 2px;}
    .ow-fcell{width:52px; height:16px; border:1px solid #c8c6c4; background:#fff; display:flex; align-items:center; justify-content:center; margin-right:3px; font-size:11px; color:#252423; flex:none;}
    .ow-fx{width:30px; display:flex; align-items:center; justify-content:center; color:#605e5c; font-style:italic; font-weight:700; font-family:Georgia,'Times New Roman',serif; flex:none;}
    .ow-fval{flex:1; display:flex; align-items:center; padding:0 8px; color:#333; white-space:nowrap; overflow:hidden; min-width:0;}
    .ow-formula{border:0 !important; outline:0 !important; background:#fff !important; min-width:0; font:11px Tahoma,Arial,sans-serif;}
    .ow-formula:focus{box-shadow:inset 0 0 0 1px #107C41 !important;}
    .ow-edit-toggle{background:none; border:0; color:#fff; font:10.5px Tahoma,Arial,sans-serif; cursor:pointer; padding:0 4px; opacity:.92;}
    .ow-edit-toggle:hover{text-decoration:underline; opacity:1;}
    .ow-cell-edit{outline:2px solid #217346 !important; outline-offset:-2px !important; background:#fff !important;}
    .ow-cell-input{position:absolute; inset:0; width:100%; height:100%; box-sizing:border-box; border:0; padding:2px 5px; outline:0; background:#fff; font:12px Tahoma,Arial,sans-serif; color:#222;}
    .ow-cell-input:focus{box-shadow:inset 0 0 0 2px #217346;}
    .ow-edit-grid{position:absolute; top:var(--ow-headh); left:var(--ow-headw); right:0; bottom:0; z-index:3; display:grid; grid-template-columns:repeat(40,var(--ow-colw)); grid-auto-rows:var(--ow-rowh); pointer-events:none; overflow:hidden;}
    .ow-edit-grid.on{pointer-events:auto;}
    .ow-edit-grid .ow-edit-cell{position:relative; box-sizing:border-box; min-width:var(--ow-colw); height:var(--ow-rowh); padding:0 4px; overflow:hidden; border:1px solid transparent; background:transparent; font:10px Tahoma,Arial,sans-serif; color:#222; cursor:cell; white-space:nowrap;}
    .ow-edit-grid.on .ow-edit-cell:hover{border-color:#9fcdb2; background:rgba(226,240,232,.72);}
    .ow-edit-grid .ow-edit-cell.has-value{background:rgba(255,255,255,.88); border-color:#c9ced6;}
    .ow-edit-grid .ow-edit-cell.selected{outline:2px solid #217346; outline-offset:-2px; z-index:2;}
    .ow-main{flex:1; position:relative; z-index:0; --ow-bottom-h:0px; --ow-colw:34px; --ow-rowh:13px; --ow-headw:34px; --ow-headh:13px; ${cfg.flow ? 'overflow:auto' : 'overflow:hidden'}; background:#fff;}
    ${cfg.flow ? '.ow-main.ow-flow{padding:var(--ow-headh) 0 0 var(--ow-headw) !important; box-sizing:border-box;} .ow-main.ow-flow > :not(.ow-grid){position:relative; z-index:1;}' : '.ow-main > :is(#app,#join,#backmodal,#hostmodal,#rolemask,#cardmask){position:absolute !important; top:var(--ow-headh) !important; left:var(--ow-headw) !important; right:0 !important; bottom:var(--ow-bottom-h) !important; transition:bottom .1s linear;}'}
    /* ---------- нижние панели: журнал / комментарии как вкладки Excel ---------- */
    .ow-bottom{position:absolute; left:var(--ow-headw); right:0; bottom:0; z-index:6; background:#fff; border-top:1px solid #c9ced6; display:none; overflow:hidden;}
    .ow-bottom.on{display:block;}
    .ow-bsec{display:flex; flex-direction:column; height:110px;}
    .ow-bsec .side-panel{flex:1 1 0 !important; min-height:0 !important;}
    .ow-bsec #chat-box{flex:none; height:22px; overflow:hidden;}
    /* Панель эмодзи — fixed: чат внизу, и absolute-позиция обрезалась
       22px-строкой чата и полосой .ow-bottom (overflow:hidden). */
    .ow-bsec #chat-emoji{position:fixed !important; z-index:500;}
    .ow-bsec #chat-row{width:auto; max-width:560px; margin:2px 8px; gap:4px;}
    .ow-bsec #chat-in{width:100%; max-width:420px;}
    .ow-tab.ow-open{background:#fff !important; color:#217346 !important; border-bottom:2px solid #217346 !important; margin-bottom:-1px;}
    .ow-main > :not(.ow-grid){z-index:1;}
    .ow-main #app{background:transparent !important; overflow:hidden !important;}
    .ow-main #app > header{height:22px !important; min-height:22px !important; box-sizing:border-box !important; padding:0 8px !important; border-bottom:1px solid #c9ced6 !important; background:#f4f6f8 !important; color:#333 !important;}
    .ow-main #app > header b{font-size:11px !important; color:#217346 !important;}
    .ow-main #app > #main{min-height:0 !important; overflow:hidden !important;}
    .ow-main #app > #main > aside{width:276px !important; min-width:276px !important; max-width:276px !important; background:#fff !important;}
    .ow-main aside{position:relative !important; box-sizing:border-box !important;}
    .ow-main aside.ow-side-off{width:22px !important; min-width:22px !important; max-width:22px !important; background:#f4f6f8 !important; border-left:1px solid #c9ced6 !important;}
    .ow-main aside.ow-side-off > :not(.ow-side-toggle){display:none !important;}
    .ow-side-toggle{display:flex !important; align-items:center !important; justify-content:center !important; flex:none !important; width:22px !important; min-width:22px !important; height:22px !important; margin:0 !important; padding:0 !important; border:0 !important; border-bottom:1px solid #c9ced6 !important; border-radius:0 !important; background:#f4f6f8 !important; color:#5f6b7a !important; font:11px Consolas,monospace !important; cursor:pointer !important;}
    .ow-side-toggle:hover{background:#e2f0e8 !important; color:#217346 !important;}
    .ow-main .side-title{height:22px !important; min-height:22px !important; box-sizing:border-box !important; padding:0 6px 0 8px !important; line-height:21px !important; border-bottom:1px solid #c9ced6 !important; background:#f4f6f8 !important; color:#333 !important; font-size:11px !important; font-weight:600 !important;}
    .ow-main .side-panel{overflow:auto !important;}
    .ow-main .side-panel > *{min-height:22px !important; box-sizing:border-box !important; padding:3px 6px 3px 38px !important; line-height:16px !important;}
    .ow-main .side-title.ow-off{height:18px !important; min-height:18px !important; line-height:17px !important;}
    /* Текст игры лежит прямо на сетке листа: без лишних рамок и белых плашек. */
    .ow-main .ow-cell{box-sizing:border-box !important; min-height:22px !important; border:0 !important; border-radius:0 !important; background:transparent !important; color:#222 !important; font-family:Tahoma,'Segoe UI',Arial,sans-serif !important;}
    .ow-main .ow-cell::before{display:none !important;}
    .ow-main .ow-cell input,.ow-main .ow-cell button{border-radius:0 !important; font-family:Tahoma,'Segoe UI',Arial,sans-serif !important;}
    .ow-main .ow-grid{z-index:0 !important;}
    .ow-main .ow-garea{background-color:transparent !important;}
    .ow-tabs{flex:none; height:22px; background:#f3f2f1; border-top:1px solid #d9d9d9; display:flex; align-items:stretch; padding:3px 4px 0; font-size:10.5px; user-select:none;}
    .ow-tab{display:flex; align-items:center; padding:2px 12px; background:transparent; border:1px solid transparent; color:#444; cursor:pointer;}
    .ow-tab:hover{border-color:#c8c8c8; background:#faf9f8;}
    .ow-tab.on{background:#fff; border-color:#d1d1d1; border-bottom-color:#fff; color:#107C41; font-weight:600; box-shadow:inset 0 -2px 0 #107C41;}
    .ow-tplus{width:18px; height:18px; align-self:center; border:1px solid #c8c8c8; background:#fff; color:#444; display:flex; align-items:center; justify-content:center; margin-left:6px; font-size:12px; flex:none;}
    .ow-tplus:hover{border-color:#217346; color:#217346;}
    /* фейковый горизонтальный скроллбар (как в настоящем Excel) */
    .ow-hscroll{flex:none; height:14px; background:#faf9f8; border-top:1px solid #e1dfdd; position:relative; user-select:none;}
    .ow-hscroll .track{position:absolute; left:2px; right:30px; top:1px; bottom:1px; background:#f0f0f0;}
    .ow-hscroll .thumb{position:absolute; left:12%; width:80%; top:3px; bottom:3px; background:#b7b7b7;}
    .ow-hscroll .arr{position:absolute; top:1px; bottom:1px; width:14px; background:#faf9f8; display:flex; align-items:center; justify-content:center; font-size:8px; color:#666;}
    .ow-hscroll .arr.l{left:0;} .ow-hscroll .arr.r{right:0;}
    /* статус-бар — зелёный: слева «Готово», справа режимы + 100% */
    .ow-status{flex:none; height:22px; background:#185C37; color:#fff; display:flex; align-items:center; font-size:10.5px; padding:0 10px; user-select:none; gap:8px;}
    .ow-sleft{flex:1; display:flex; align-items:center; gap:8px; white-space:nowrap; overflow:hidden;}
    .ow-sright{display:flex; align-items:center; gap:8px; white-space:nowrap;}
    .ow-view{width:16px; height:14px; border:1px solid rgba(255,255,255,.45); display:flex; align-items:center; justify-content:center; font-size:8px; cursor:default;}
    .ow-view.on{background:rgba(255,255,255,.22);}
    .ow-main .side-title{display:flex; align-items:center;}
    .ow-main .side-title .ow-st{margin-left:auto; background:none; border:none; padding:0 2px 0 8px; font-size:12px; color:#8b96ab; cursor:pointer; line-height:1; flex:none;}
    .ow-main .side-title .ow-st:hover{color:#217346;}
    /* секция полностью скрыта: тонкая полоска с «▸» (как свёрнутая группа строк) */
    .ow-main .side-title.ow-off{padding:2px 4px 2px 8px !important; font-size:10px !important; line-height:14px !important; background:#f2f4f7 !important; color:#98a2b3 !important; letter-spacing:0 !important; text-transform:none !important; border-bottom:1px solid #e0e4ea !important;}
    .ow-main .side-title.ow-off .ow-sttxt{display:none;}
    /* ---------- Excel-сетка позади всего содержимого ---------- */
    /* z-index:-1: поверх фона .ow-main, но ПОД всем контентом
       (в т.ч. статическими блоками, которые иначе накрывались бы) */
    .ow-grid{position:absolute; top:0; left:0; width:100%; height:100%; z-index:-1; pointer-events:none; font-family:Tahoma,Verdana,Arial,sans-serif; user-select:none;}
    .ow-gcorner{position:absolute; top:0; left:0; width:var(--ow-headw); height:var(--ow-headh); background:#f5f5f5; border-right:1px solid #d4d4d4; border-bottom:1px solid #d4d4d4;}
    .ow-gcols{position:absolute; top:0; left:var(--ow-headw); right:0; height:var(--ow-headh); background:#f5f5f5; border-bottom:1px solid #d4d4d4; display:flex; overflow:hidden; pointer-events:auto;}
    .ow-gcols span{flex:none; width:var(--ow-colw); border-right:1px solid #e6e6e6; text-align:center; line-height:12px; font-size:9px; color:#666; cursor:default;}
    .ow-grows{position:absolute; top:var(--ow-headh); left:0; width:var(--ow-headw); bottom:0; background:#f5f5f5; border-right:1px solid #d4d4d4; pointer-events:auto;}
    .ow-grows span{display:block; height:var(--ow-rowh); line-height:12px; text-align:center; font-size:9px; color:#666; border-bottom:1px solid #e6e6e6;}
    .ow-gcols span.on,.ow-grows span.on{background:#dcefe4 !important; color:#0b5c32 !important; font-weight:700;}
    .ow-garea{position:absolute; top:var(--ow-headh); left:var(--ow-headw); right:0; bottom:0; background-color:#fff;
      background-image:linear-gradient(to right,#e8e8e8 1px,transparent 1px),linear-gradient(to bottom,#e8e8e8 1px,transparent 1px);
      background-size:var(--ow-colw) var(--ow-rowh);}
    /* выделение ячейки/диапазона — зелёная рамка; позиция и размер
       задаются JS (по умолчанию — A1, как в пустом листе) */
    .ow-sel{position:absolute; top:var(--ow-headh); left:var(--ow-headw); width:var(--ow-colw); height:var(--ow-rowh); border:1px solid #107C41; box-sizing:border-box;}
    .ow-sel::after{content:''; position:absolute; right:-4px; bottom:-4px; width:6px; height:6px; background:#107C41; box-sizing:border-box; z-index:1;}
    /* подсветка найденной ячейки (Ctrl+F) */
    .ow-found{position:absolute; z-index:1; background:#ffe699; outline:2px solid #E26B0A; box-sizing:border-box; pointer-events:none;}
    /* ---------- панели (журнал/чат/участники) — строки-ячейки с номерами ---------- */
    .ow-main .side-panel{background:#fff; padding:0 !important; counter-reset:owrow; border-top:1px solid #e0e4ea;}
    .ow-main .side-panel > *{counter-increment:owrow; position:relative; border-bottom:1px solid #eef1f5; padding:3px 8px 3px 38px !important; font-family:Tahoma,Arial,sans-serif; font-size:12px; line-height:1.4; word-break:break-word;}
    .ow-main .side-panel > *::before{content:counter(owrow); position:absolute; left:0; top:3px; width:30px; text-align:center; font-size:10px; line-height:16px; color:#a7afbb; border-right:1px solid #eef1f5; background:#fafbfc;}
    /* ---------- поле ввода чата — как ячейка ---------- */
    .ow-main #chat-box{background:#f7f9fb; border-top:1px solid #d9d9d9;}
    .ow-main #chat-in{border:1px solid #b9c2cd !important; border-radius:0 !important; background:#fff !important; font-family:Tahoma,Arial,sans-serif !important; font-size:12px; box-shadow:none !important;}
    .ow-main #chat-in:focus{border-color:#217346 !important;}
    /* ---------- баннер-уведомление — текст без рамки ---------- */
    .ow-main #banner{font-family:Tahoma,'Segoe UI',Arial,sans-serif !important; background:transparent !important; border:0 !important; box-shadow:none !important;}
    /* ---------- плоское Excel-оформление: без скруглений и теней ---------- */
    .ow-main *{border-radius:0 !important; box-shadow:none !important;}
    .ow-main .side-panel > *{line-height:16px !important;}
    .ow-main .side-title .ow-st, .ow-main #app > header .ow-st{background:none; border:none; padding:2px 8px; font-size:13px; color:#5f6b7a; cursor:pointer; line-height:1; flex:none;}
    .ow-main .side-title .ow-st:hover, .ow-main #app > header .ow-st:hover{background:#e2f0e8; color:#217346;}
    .ow-main #app > header .ow-st{margin-left:10px;}
    /* «меню выхода» (шапка документа) прячется ПОЛНОСТЬЮ: её строка
       становится обычными ячейками листа (как у панели действий покера);
       возвращает маленькая «▸» в левом верхнем углу области игры */
    .ow-main #app > header.ow-off{display:none !important;}
    /* боковая панель — таблица ровно на 3 колонки листа (3×92=276px),
       строки — ровно 22px как в листе: панель встает в сетку заподлицо */
    @media (min-width:900px){
      .ow-main aside{width:276px !important; min-width:276px !important; max-width:276px !important; background:#fff !important; border-left:1px solid #c9ced6 !important;}
    }
    /* ---------- v20: статистика и зум в статус-баре ---------- */
    #ow-stats{color:#e8f5ee; font-size:10px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;}
    .ow-zoom{display:flex; align-items:center; gap:2px;}
    .ow-zbtn{width:16px; height:16px; box-sizing:border-box; border:1px solid rgba(255,255,255,.5); background:rgba(255,255,255,.08); color:#fff; font-size:11px; line-height:14px; text-align:center; cursor:pointer; user-select:none;}
    .ow-zbtn:hover{background:rgba(255,255,255,.25);}
    #ow-zval{min-width:36px; text-align:center; color:#fff; font-size:10px;}
    /* пилюля «Автосохранение» в заголовке окна */
    .ow-asv{flex:none; margin:0 6px; height:17px; padding:0 8px; display:flex; align-items:center; gap:4px; background:rgba(255,255,255,.14); border:1px solid rgba(255,255,255,.35); border-radius:8px; color:rgba(255,255,255,.92); font-size:9.5px; cursor:pointer; user-select:none;}
    .ow-asv:hover{background:rgba(255,255,255,.26);}
    .ow-asv.off{opacity:.5;}
    /* ---------- «Найти и заменить» — панель справа ---------- */
    .ow-find{position:fixed; top:154px; right:0; bottom:58px; width:280px; background:#fff; border-left:1px solid #c8c6c4; z-index:900; display:none; box-sizing:border-box; font-size:11px; color:#252423;}
    .ow-find.on{display:block;}
    .ow-find-t{height:24px; padding:0 6px; display:flex; align-items:center; justify-content:space-between; font-size:11px; font-weight:600; border-bottom:1px solid #e1dfdd;}
    .ow-find-x{cursor:pointer; color:#797775; font-size:11px; padding:0 5px;}
    .ow-find-x:hover{color:#C00000;}
    .ow-find-tabs{display:flex; gap:12px; padding:6px 8px 0; font-size:11px; color:#605e5c;}
    .ow-find-tabs span{padding-bottom:2px; cursor:default;}
    .ow-find-tabs span.on{color:#107C41; border-bottom:2px solid #107C41; font-weight:600;}
    .ow-find-b{padding:6px 8px 0; display:flex; align-items:center; gap:6px;}
    .ow-find-lab{width:56px; flex:none; font-size:10.5px; color:#444;}
    .ow-find-in{flex:1; height:21px; border:1px solid #c8c6c4; padding:0 6px; font:11px Tahoma,Arial,sans-serif; outline:0; min-width:0;}
    .ow-find-in:focus{border-color:#107C41; box-shadow:inset 0 0 0 1px #107C41;}
    .ow-find-btns{display:flex; flex-direction:column; gap:4px; padding:8px;}
    .ow-find-btn{height:21px; border:1px solid #c8c6c4; background:#faf9f8; font:10.5px Tahoma,Arial,sans-serif; cursor:pointer;}
    .ow-find-btn:hover{border-color:#217346; color:#217346;}
    .ow-find-note{padding:0 8px 8px; font-size:10px; color:#797775; min-height:14px;}
    /* ---------- контекстное меню (правый клик по листу) ---------- */
    .ow-cmenu{position:fixed; z-index:950; min-width:196px; background:#fff; border:1px solid #c8c6c4; box-shadow:2px 3px 8px rgba(0,0,0,.18); padding:3px 0; font-size:11px; color:#252423; display:none; user-select:none;}
    .ow-cmenu.on{display:block;}
    .ow-cmi{display:flex; justify-content:space-between; gap:18px; padding:3px 12px 3px 22px; white-space:nowrap; cursor:default;}
    .ow-cmi:hover{background:#e2f0e8; color:#0b5c32;}
    .ow-cmi .k{color:#797775; font-size:10px;}
    .ow-cmenu hr{border:0; border-top:1px solid #e1dfdd; margin:3px 0;}
    /* ---------- фейковые окна Excel (печать, свойства) ---------- */
    .ow-dlg-mask{position:fixed; inset:0; z-index:960; background:rgba(0,0,0,.14); display:none;}
    .ow-dlg-mask.on{display:block;}
    .ow-dlg{position:fixed; z-index:970; left:50%; top:40%; transform:translate(-50%,-50%); width:440px; background:#fff; border:1px solid #8a8886; box-shadow:4px 6px 18px rgba(0,0,0,.28); display:none; font-size:11px; color:#252423;}
    .ow-dlg.on{display:block;}
    .ow-dlg-t{height:26px; background:#185C37; color:#fff; display:flex; align-items:center; gap:6px; padding:0 8px; font-size:11px;}
    .ow-dlg-t .ow-dlg-x{margin-left:auto; cursor:pointer; font-size:11px; padding:0 4px;}
    .ow-dlg-t .ow-dlg-x:hover{color:#ffd7d7;}
    .ow-dlg-b{padding:12px 14px; display:flex; flex-direction:column; gap:8px;}
    .ow-dlg-row{display:flex; align-items:center; gap:8px;}
    .ow-dlg-row label{width:118px; flex:none; color:#444; text-align:right; font-size:10.5px;}
    .ow-dlg-row .v{flex:1; color:#252423;}
    .ow-dlg-row input,.ow-dlg-row select{flex:1; height:21px; border:1px solid #c8c6c4; font:11px Tahoma,Arial,sans-serif; padding:0 5px; outline:0; min-width:0;}
    .ow-dlg-row input:focus,.ow-dlg-row select:focus{border-color:#107C41; box-shadow:inset 0 0 0 1px #107C41;}
    .ow-dlg-f{padding:8px 14px 12px; display:flex; justify-content:flex-end; gap:8px;}
    .ow-dlg-btn{min-width:82px; height:23px; border:1px solid #c8c6c4; background:#faf9f8; font:11px Tahoma,Arial,sans-serif; cursor:pointer;}
    .ow-dlg-btn:hover{border-color:#217346; color:#217346;}
    .ow-dlg-btn.p{border-color:#217346; background:#e2f0e8; color:#0b5c32; font-weight:600;}
    /* босс-режим: все новые оверлеи (поиск, меню, окна) скрыты */
    body.yzp-on .ow-find, body.yzp-on .ow-cmenu, body.yzp-on .ow-dlg, body.yzp-on .ow-dlg-mask{display:none !important;}
    /* именованное поле (адрес ячейки) — кликабельное */
    .ow-fcell{cursor:pointer;}
    .ow-fcell input{width:48px; height:15px; border:1px solid #107C41; outline:0; font:11px Tahoma,Arial,sans-serif; text-align:center; padding:0;}
  `;
  document.head.appendChild(style);

  const top = document.createElement('div');
  top.className = 'ow-top';
  // лента: группы с иконками и подписями (1-в-1 по референсу)
  const RB = (lab, rows, big) => '<div class="ow-rb' + (big ? ' ow-rb-lg' : '') + '"><div class="ow-rb-rows">' +
    (Array.isArray(rows) ? rows : [rows]).map(r => '<div class="ow-rb-row">' + r + '</div>').join('') +
    '</div><div class="ow-rb-lab">' + lab + '</div></div>';
  const B = (ic, txt, dd) => '<span class="ow-rb-btn"><span class="ow-rb-ic">' + ic + '</span>' +
    (txt ? '<span>' + txt + '</span>' : '') + (dd ? '<span class="ow-rb-dd">&#9662;</span>' : '') + '</span>';
  const STY = '<span class="ow-sty b"><i></i>Обычный</span><span class="ow-sty o"><i></i>Ультральный</span>' +
    '<span class="ow-sty r"><i></i>Плохой</span><span class="ow-sty g"><i></i>Хороший</span>' +
    '<span class="ow-sty y"><i></i>Ввод</span><span class="ow-sty hot"><i></i>Контрольный</span>' +
    '<span class="ow-sty g"><i></i>Применение</span>';
  top.innerHTML =
     '<div class="ow-title"><span class="ow-xic">X</span><span class="ow-ttext">' + esc(DOC) + ' — Microsoft Excel</span>' +
       '<span class="ow-asv" id="ow-asv" title="Автосохранение: клик — вкл/выкл">&#128190; Автосохранение: ВКЛ</span>' +
       '<span class="ow-search"><span class="ow-srch"></span>Поиск</span>' +
      '<span class="ow-tbtns">' +
        '<span class="ow-wbtn" data-ow="hidetop" title="Скрыть меню — ячейки до края окна">&#9662;</span>' +
        '<span class="ow-cloud" title="Синхронизировано">&#9729;</span>' +
        '<span class="ow-wbtn" title="Свернуть">&#8212;</span>' +
        '<span class="ow-wbtn" title="Развернуть">&#9633;</span>' +
        '<span class="ow-wbtn x" title="Закрыть">&#10005;</span>' +
        '<span class="ow-share" title="Общий доступ"><span class="ow-people"></span>Общий доступ</span>' +
      '</span></div>' +
    '<div class="ow-menu"><span class="ow-mtab file">Файл</span><span class="ow-mtab on">Главная</span><span class="ow-mtab">Вставка</span><span class="ow-mtab">Разметка страницы</span><span class="ow-mtab">Формулы</span><span class="ow-mtab">Данные</span><span class="ow-mtab">Рецензирование</span><span class="ow-mtab">Вид</span><span class="ow-mtab">Разработка</span><span class="ow-mtab">Редактирование ОК</span><span class="ow-mtab">Редактирование Мк.</span><span class="ow-mtab">Справка</span></div>' +
    '<div class="ow-ribbon">' +
      RB('Буфер обмена', [B('&#9986;', 'Вырезать', 1), B('&#8992;', 'Копировать', 1), B('&#9998;', 'По образцу', 1)]) +
      RB('Шрифт', [
        '<span class="ow-fontbox">Calibri <span class="ow-rb-dd">&#9662;</span></span><span class="ow-fontbox small">11 <span class="ow-rb-dd">&#9662;</span></span>' +
        '<span class="ow-rb-btn"><span class="ow-rb-ic ow-ab">Ж</span></span><span class="ow-rb-btn"><span class="ow-rb-ic ow-ai">К</span></span><span class="ow-rb-btn"><span class="ow-rb-ic ow-au">Ч</span></span><span class="ow-rb-btn"><span class="ow-rb-ic ow-as">S</span></span>',
        '<span class="ow-rb-btn"><span class="ow-rb-ic ow-ar">A</span><span class="ow-rb-dd">&#9662;</span></span><span class="ow-rb-btn"><span class="ow-rb-ic ow-ahl">A</span><span class="ow-rb-dd">&#9662;</span></span><span class="ow-rb-btn"><span class="ow-rb-ic">&#8862;</span><span class="ow-rb-dd">&#9662;</span></span><span class="ow-rb-btn"><span class="ow-rb-ic">&#9642;</span><span class="ow-rb-dd">&#9662;</span></span>'
      ]) +
      RB('Выравнивание', [
        '<span class="ow-rb-btn"><span class="ow-al"><i></i><i></i><i></i></span></span><span class="ow-rb-btn"><span class="ow-al c"><i></i><i></i><i></i></span></span><span class="ow-rb-btn"><span class="ow-al r"><i></i><i></i><i></i></span></span><span class="ow-rb-btn"><span class="ow-al j"><i></i><i></i><i></i></span></span>',
        B('&#8862;', 'Объединить и поместить в центре', 1) + B('&#8617;', 'Перенос', 0) + B('&#8635;', '', 0)
      ]) +
      RB('Число', [
        '<span class="ow-fontbox">Общий <span class="ow-rb-dd">&#9662;</span></span>',
        '<span class="ow-rb-btn"><span class="ow-rb-ic" style="font-size:8px">1 000</span></span><span class="ow-rb-btn"><span class="ow-rb-ic">%</span></span><span class="ow-rb-btn"><span class="ow-rb-ic">&#8381;</span></span><span class="ow-rb-btn"><span class="ow-rb-ic" style="font-size:8px">00</span></span><span class="ow-rb-btn"><span class="ow-rb-ic" style="font-size:8px">000</span></span>'
      ]) +
      '<div class="ow-rb"><div class="ow-rb-rows" style="flex-direction:row; gap:6px; align-items:center;">' +
        '<div style="display:flex; flex-direction:column; gap:2px;">' + B('&#8862;', 'Условное', 1) + B('&#9638;', 'Таблица', 1) + '</div>' +
        '<div class="ow-stys">' + STY + '</div>' +
      '</div><div class="ow-rb-lab">Стили</div></div>' +
      RB('Ячейки', [B('&#10066;', 'Вставить', 1), B('&#10012;', 'Удалить', 1), B('&#9881;', 'Формат', 1)]) +
      '<div class="ow-rb"><div class="ow-rb-rows" style="flex-direction:row; gap:6px; align-items:center;">' +
        '<div style="display:flex; flex-direction:column; gap:2px;">' + B('&#931;', 'Автосумма', 1) + B('&#9636;', 'Заполнить', 1) + B('&#8986;', 'Очистить', 1) + '</div>' +
        '<div style="display:flex; flex-direction:column; gap:2px;">' + B('&#8645;', 'Сортировка', 1) + B('&#8981;', 'Найти и выделить', 1) + '</div>' +
      '</div><div class="ow-rb-lab">Редактирование</div></div>' +
    '</div>' +
    '<div class="ow-fbar"><span class="ow-fcell" id="ow-cell-ref">' + esc(CELL) + '</span><span class="ow-fx">fx</span><input class="ow-fval ow-formula" id="ow-formula" value="' + esc(F) + '" spellcheck="false" aria-label="Строка формул"></div>';

  const main = document.createElement('div');
  main.className = 'ow-main' + (cfg.flow ? ' ow-flow' : '');

  // ---- Excel-сетка: буквы столбцов A.., номера строк 1.., линии ячеек ----
   let ZOOM = 1, COLW = 34, ROWH = 13, HEADW = 34, HEADH = 13;
  const colName = n => { let s = ''; for (n = n + 1; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + (n - 1) % 26) + s; return s; };
  let colsHtml = '';
  for (let c = 0; c < Math.max(10, Math.ceil((window.innerWidth - HEADW) / COLW) + 3); c++) colsHtml += '<span>' + colName(c) + '</span>';
  let rowsHtml = '';
  for (let r = 1; r <= Math.max(12, Math.ceil(window.innerHeight / ROWH) + 4); r++) rowsHtml += '<span>' + r + '</span>';
  const grid = document.createElement('div');
  grid.className = 'ow-grid';
  grid.setAttribute('aria-hidden', 'true');
  grid.innerHTML =
    '<div class="ow-gcorner"></div>' +
    '<div class="ow-gcols">' + colsHtml + '</div>' +
    '<div class="ow-grows">' + rowsHtml + '</div>' +
    '<div class="ow-garea"></div>' +
    '<div class="ow-sel"></div>';
  main.appendChild(grid);

  const self = document.currentScript;
  const children = Array.from(document.body.children);
  for (const ch of children) if (ch !== self) main.appendChild(ch);

  const tabs = document.createElement('div');
  tabs.className = 'ow-tabs';
  tabs.innerHTML = '<span class="ow-tab">Лист1</span>' +
    TABS.map((t, i) => '<span class="ow-tab' + (i === 0 ? ' on' : '') + '">' + esc(t) + '</span>').join('') +
    '<span class="ow-tplus">+</span>';

  // фейковый горизонтальный скроллбар (между вкладками и статус-баром)
  const hscroll = document.createElement('div');
  hscroll.className = 'ow-hscroll';
  hscroll.setAttribute('aria-hidden', 'true');
  hscroll.innerHTML = '<span class="arr l">&#9664;</span><span class="track"></span><span class="thumb"></span><span class="arr r">&#9654;</span>';

  const status = document.createElement('div');
  status.className = 'ow-status';
  status.innerHTML =
    '<span class="ow-sleft"><span id="ow-ready">Готово</span><span id="ow-stats"></span>' +
      '<span title="Специальные возможности">&#9881; Специальные возможности: все в порядке</span>' +
      '<button class="ow-edit-toggle" type="button" title="Ввод значений в ячейки (вкл/выкл)">Правка ячеек: выкл</button></span>' +
    '<span class="ow-sright"><span class="ow-view on" title="Обычный режим">&#9638;</span><span class="ow-view" title="Режим размеченной страницы">&#9636;</span><span class="ow-view" title="Черновой режим">&#9675;</span>' +
      '<span class="ow-zoom"><span class="ow-zbtn" id="ow-zout" title="Уменьшить масштаб">&#8722;</span><span id="ow-zval">100%</span><span class="ow-zbtn" id="ow-zin" title="Увеличить масштаб">+</span></span></span>';

  document.body.insertBefore(main, children.length ? null : document.body.firstChild);
  document.body.insertBefore(top, main);
  document.body.appendChild(tabs);
  document.body.appendChild(hscroll);
  document.body.appendChild(status);

  // на прокручиваемых страницах (лобби) сетка покрывает всё содержимое;
  // пересчёт нужен и при скрытии верхнего меню — область листа становится
  // выше, иначе номера строк и линии обрывались
  const rowsEl = grid.querySelector('.ow-grows');
  const colsEl = grid.querySelector('.ow-gcols');
  function sizeGrid() {
    const hgt = Math.max(main.clientHeight, main.scrollHeight);
    grid.style.height = hgt + 'px';
    const needR = Math.max(12, Math.ceil(hgt / ROWH));
    if (rowsEl.children.length !== needR) {
      let html = '';
      for (let r = 1; r <= needR; r++) html += '<span>' + r + '</span>';
      rowsEl.innerHTML = html;
    }
    const wdt = Math.max(main.clientWidth, main.scrollWidth);
    const needC = Math.max(10, Math.ceil((wdt - HEADW) / COLW) + 3);
    if (colsEl.children.length !== needC) {
      let html = '';
      for (let c = 0; c < needC; c++) html += '<span>' + colName(c) + '</span>';
      colsEl.innerHTML = html;
    }
    applySel();
  }
  requestAnimationFrame(sizeGrid);
  window.addEventListener('resize', sizeGrid);

  // ---------- панель действий покера (#actions: фишки, чек, рейз, таймер) ----------
  // «▾» в правом верхнем углу панели прячет её полностью: её строки
  // (≈3–4 ряда) становятся обычными пустыми ячейками, как строки 1–2.
  // Маленькая «▴» в левом нижнем углу возвращает панель.
  let placeARest = null;
  const actions = document.querySelector('#actions');
  if (actions) {
    actions.style.position = 'relative';
    const aBtn = document.createElement('span');
    aBtn.className = 'ow-tminus';
    aBtn.textContent = '\u25BE';
    aBtn.title = 'Скрыть панель действий — сделать ячейки';
    aBtn.style.cssText = 'position:absolute; right:4px; top:4px;';
    actions.appendChild(aBtn);
    const aRest = document.createElement('div');
    aRest.className = 'ow-rest';
    aRest.id = 'ow-act-rest';
    aRest.textContent = '\u25B4';
    aRest.title = 'Показать панель действий';
    document.body.appendChild(aRest);
    placeARest = function () {
      aRest.style.left = '2px';
      aRest.style.right = 'auto';
      // над строкой вкладок (вкладки 22 + скроллбар 14 + статус 22 = 58px)
      aRest.style.bottom = '60px';
    };
    function setActOff(off) {
      actions.style.display = off ? 'none' : '';
      aRest.style.display = off ? 'block' : 'none';
      if (off) placeARest();
    }
    aBtn.addEventListener('click', e => { e.stopPropagation(); setActOff(true); });
    aRest.addEventListener('click', () => setActOff(false));
  }

  // ---------- скрытие верхнего меню ----------
  // «▾» в заголовке — прячет .ow-top целиком (заголовок + меню + лента +
  // строка формул): ячейки доходят до верхнего края окна.
  // Маленькая кнопка «▾» в левом верхнем углу возвращает меню обратно.
  const topRest = document.createElement('div');
  topRest.className = 'ow-rest'; topRest.id = 'ow-top-rest'; topRest.textContent = '▾';
  topRest.title = 'Показать меню';
  document.body.appendChild(topRest);
  function setTopOff(off) {
    top.classList.toggle('ow-off', off);
    topRest.style.display = off ? 'block' : 'none';
    requestAnimationFrame(sizeGrid);
  }
  topRest.addEventListener('click', () => setTopOff(false));

  // «автосохранение» в фоне: статус-бар периодически пишет «Сохранение…»
  // (отключается кликом по пилюле «Автосохранение» в заголовке окна)
  let autoSave = true;
  setInterval(() => { if (autoSave) readyFlash('Сохранение…', 1400); }, 45000);

  // ---------- редактируемые Excel-подобные ячейки ----------
  const storageKey = 'yamz_excel_cells_' + DOC;
  let cells = {};
  try { cells = JSON.parse(localStorage.getItem(storageKey) || '{}') || {}; } catch (_) { cells = {}; }
  let selected = CELL;
  let editMode = false;
  const colToNum = s => { let n = 0; for (const ch of String(s).toUpperCase()) n = n * 26 + ch.charCodeAt(0) - 64; return n; };
  const numToCol = n => { let s = ''; for (; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + (n - 1) % 26) + s; return s; };
  const parseRef = ref => { const m = /^([A-Z]+)([1-9][0-9]*)$/i.exec(String(ref).trim()); return m ? { c: colToNum(m[1]), r: +m[2] } : null; };
  const refOf = el => el && (el.dataset.cell || el.getAttribute('data-cell'));
  function parseRange(s) {
    s = String(s).trim();
    if (s.indexOf(':') > -1) {
      const p = s.split(':'); const a = parseRef(p[0]), b = parseRef(p[1]);
      if (!a || !b) return null;
      return [Math.min(a.r, b.r), Math.min(a.c, b.c), Math.max(a.r, b.r), Math.max(a.c, b.c)];
    }
    const a = parseRef(s);
    return a ? [a.r, a.c, a.r, a.c] : null;
  }
  function rangeVals(rr, seen) {
    if (!rr) return [];
    const out = [];
    for (let r = rr[0]; r <= rr[1]; r++) for (let c = rr[2]; c <= rr[3]; c++) out.push(valueOf(numToCol(c) + r, seen));
    return out;
  }
  const NUMS = v => { const n = Number(v); return Number.isFinite(n) ? n : null; };
  function valueOf(ref, stack) {
    const raw = Object.prototype.hasOwnProperty.call(cells, ref) ? cells[ref] : '';
    if (typeof raw !== 'string' || raw[0] !== '=') return raw;
    const seen = stack || [];
    if (seen.includes(ref)) return '#ЦИКЛ!';
    try {
      const source = raw.slice(1).trim();
      let m;
      // подстановка ссылок на ячейки: числовые — как числа, текстовые — в кавычках
      const numSub = s => String(s).trim().replace(/([A-Za-zА-Яа-я]{1,3}[0-9]+)/g, mm => {
        const v = valueOf(mm.toUpperCase(), seen.concat(ref));
        const n = NUMS(v);
        return n !== null ? String(n) : JSON.stringify(String(v));
      });
      // =СЕЙЧАС() — текущие дата/время (пересчитывается каждые 30 с)
      if (/^СЕЙЧАС\s*\(\s*\)$/i.test(source)) return new Date().toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
      // =СУММ(A1:B3; C5) / =SUM
      if ((m = source.match(/^(?:СУММ|SUM)\s*\((.*)\)$/is))) {
        let s = 0;
        for (const part of m[1].split(/[,;]/)) for (const v of rangeVals(parseRange(part), seen.concat(ref))) { const n = NUMS(v); if (n !== null) s += n; }
        return s;
      }
      // =СРЗНАЧ(A1:B3) / =AVERAGE
      if ((m = source.match(/^(?:СРЗНАЧ|AVERAGE)\s*\((.*)\)$/is))) {
        const vals = [];
        for (const part of m[1].split(/[,;]/)) for (const v of rangeVals(parseRange(part), seen.concat(ref))) { const n = NUMS(v); if (n !== null) vals.push(n); }
        return vals.length ? vals.reduce((x, y) => x + y, 0) / vals.length : 0;
      }
      // =СЧЁТ(A1:B3) / =COUNT — число ячеек с числами
      if ((m = source.match(/^(?:СЧЁТ|COUNT)\s*\((.*)\)$/is))) {
        let n = 0;
        for (const part of m[1].split(/[,;]/)) for (const v of rangeVals(parseRange(part), seen.concat(ref))) if (NUMS(v) !== null) n++;
        return n;
      }
      // =ВПР(значение; A1:B10; 2) — поиск по первому столбцу диапазона
      if ((m = source.match(/^ВПР\s*\(([^;]+?)\s*;\s*([A-Za-zА-Яа-я]{1,3}\s*[0-9]+\s*:\s*[A-Za-zА-Яа-я]{1,3}\s*[0-9]+)\s*;\s*(\d{1,4})\s*(?:;.*)?\)$/i))) {
        const rr = parseRange(m[2]); if (!rr) return '#ИМЯ?';
        const col = Math.max(1, Math.min(rr[3] - rr[2] + 1, parseInt(m[3], 10)));
        let look = m[1].trim();
        if (/^[A-Za-zА-Яа-я]{1,3}[0-9]+$/.test(look)) look = String(valueOf(look.toUpperCase(), seen.concat(ref)));
        if (/^'(.*)'$/.test(look)) look = look.slice(1, -1);
        for (let r = rr[0]; r <= rr[1]; r++) {
          if (String(valueOf(numToCol(rr[2]) + r, seen.concat(ref))).trim() === String(look).trim()) {
            return valueOf(numToCol(rr[2] + col - 1) + r, seen.concat(ref));
          }
        }
        return '#Н/Д';
      }
      // =ЕСЛИ(условие; да; нет)
      if ((m = source.match(/^ЕСЛИ\s*\(([^;]+?)\s*;\s*([^;]*);(.*?)\)\s*$/is))) {
        const c = numSub(m[1]);
        if (!/^[0-9+*/().\s"'><=!&|,\-]+$/.test(c) || !/[><=!]/.test(c)) return '#ЗНАЧ!';
        const arg = s => {
          s = numSub(s);
          if (/^'(.*)'$/.test(s)) return s.slice(1, -1);
          if (/^[0-9+*/().\s-]+$/.test(s)) { try { const v = Function('return (' + s + ')')(); return Number.isFinite(v) ? v : s; } catch (_) { return s; } }
          return s;
        };
        return Function('return (' + c + ')')() ? arg(m[2]) : arg(m[3]);
      }
      // общий случай: подставить ячейки и посчитать арифметику
      const formula = numSub(source);
      if (!/^[0-9+*/().\s-]+$/.test(formula)) return raw;
      return Function('return (' + formula + ')')();
    } catch (_) { return '#ЗНАЧ!'; }
  }
  function persist() { localStorage.setItem(storageKey, JSON.stringify(cells)); }
  function paintCell(el, ref) {
    if (!el) return;
    const raw = Object.prototype.hasOwnProperty.call(cells, ref) ? cells[ref] : '';
    el.dataset.cell = ref;
    el.title = ref + (raw ? ': ' + raw : '');
    if (!el.querySelector('.ow-cell-input')) el.textContent = raw ? String(valueOf(ref)) : '';
    el.classList.toggle('ow-cell-edit', ref === selected && editMode);
  }
  function selectCell(el) {
    const ref = refOf(el); if (!ref) return;
    selected = ref;
    const p = parseRef(ref);
    if (p) { sel.rA = sel.rB = p.r; sel.cA = sel.cB = p.c; }
    document.querySelectorAll('.ow-cell-edit').forEach(x => x.classList.remove('ow-cell-edit'));
    if (editMode) el.classList.add('ow-cell-edit');
    applySel();
  }
  function commitCell(el, raw) {
    const ref = refOf(el); if (!ref) return;
    cells[ref] = String(raw);
    if (!cells[ref]) delete cells[ref];
    persist();
    document.querySelectorAll('[data-cell="' + ref + '"]').forEach(x => paintCell(x, ref));
    if (typeof refreshEditGrid === 'function') refreshEditGrid();
    selectCell(el);
    readyFlash('Изменения сохранены', 900);
  }
  function beginEdit(el, firstChar) {
    const ref = refOf(el); if (!ref || el.querySelector('.ow-cell-input')) return;
    editMode = true; selectCell(el);
    const input = document.createElement('input'); input.className = 'ow-cell-input'; input.value = firstChar !== undefined ? firstChar : (Object.prototype.hasOwnProperty.call(cells, ref) ? cells[ref] : '');
    el.textContent = ''; el.appendChild(input); el.classList.add('ow-cell-edit'); input.focus(); input.select();
    const finish = save => { if (save) commitCell(el, input.value); else paintCell(el, ref); };
    input.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); finish(true); } else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finish(false); } else if (e.key === 'Tab') { e.preventDefault(); finish(true); const next = el.nextElementSibling; if (next && next.dataset.cell) beginEdit(next); } });
    input.addEventListener('blur', () => { if (el.contains(input)) finish(true); }, { once:true });
  }
  function makeCell(el, ref) {
    if (!el || el.dataset.cell) return;
    el.dataset.cell = ref; paintCell(el, ref);
    el.addEventListener('click', () => selectCell(el));
    el.addEventListener('dblclick', () => beginEdit(el));
  }
  // Редактируем только отдельный слой листа, не трогая игровые DOM-блоки.
  const editGrid = document.createElement('div');
  editGrid.className = 'ow-edit-grid';
  const editCells = {};
  for (let r = 1; r <= 80; r++) for (let c = 1; c <= 40; c++) {
    const ref = numToCol(c) + r;
    const el = document.createElement('div'); el.className = 'ow-edit-cell'; el.dataset.cell = ref; el.textContent = valueOf(ref);
    editCells[ref] = el; editGrid.appendChild(el);
    el.addEventListener('click', () => selectCell(el));
    el.addEventListener('dblclick', () => beginEdit(el));
  }
  main.appendChild(editGrid);
  function refreshEditGrid() { Object.keys(editCells).forEach(ref => { const el = editCells[ref], raw = cells[ref] || ''; el.textContent = valueOf(ref); el.classList.toggle('has-value', !!raw); el.classList.toggle('selected', ref === selected); }); }
  refreshEditGrid();
  const formulaEl = document.getElementById('ow-formula');
  if (formulaEl) { formulaEl.addEventListener('keydown', e => { if (e.key === 'Enter') { cells[selected] = formulaEl.value; if (!cells[selected]) delete cells[selected]; persist(); refreshEditGrid(); readyFlash('Изменения сохранены', 900); } }); }
  const editToggle = document.querySelector('.ow-edit-toggle');
  if (editToggle) editToggle.addEventListener('click', () => { editMode = !editMode; editGrid.classList.toggle('on', editMode); editToggle.textContent = editMode ? 'Правка ячеек: вкл' : 'Правка ячеек: выкл'; });

  function readyFlash(text, ms) {
    const r = document.getElementById('ow-ready');
    if (!r) return;
    r.textContent = text;
    setTimeout(() => { r.textContent = 'Готово'; }, ms || 1000);
  }

  top.addEventListener('click', e => {
    const b = e.target.closest ? e.target.closest('[data-ow]') : null;
    if (b) {
      const a = b.getAttribute('data-ow');
      if (a === 'save') readyFlash('Сохранение…', 900);
      else if (a === 'print') readyFlash('Печать: отправка в очередь…', 1600);
      else if (a === 'hidetop') setTopOff(true);
    }
    const w = e.target.closest ? e.target.closest('.ow-wbtn') : null;
    if (w && w.title === 'Закрыть' && window.YAMZ_PANIC && typeof window.YAMZ_PANIC.show === 'function') {
      try { window.YAMZ_PANIC.show(); } catch (err) { /* ignore */ }
    }
  });

  tabs.addEventListener('click', e => {
    const t = e.target.closest ? e.target.closest('.ow-tab') : null;
    if (!t) return;
    tabs.querySelectorAll('.ow-tab').forEach(x => x.classList.toggle('on', x === t));
  });

  // ---------- журнал / комментарии / участники — внизу, как вкладки Excel ----------
  // Правая панель переезжает вниз: клик по вкладке открывает строку-панель
  // (5 строк листа), клик по той же вкладке закрывает. Игра при этом
  // поднимается на высоту панели, чтобы ничего не закрывалось.
  (function () {
    const aside = document.querySelector('.ow-main aside');
    if (!aside) return;
    const sections = [];
    let cur = null;
    for (const el of Array.from(aside.children)) {
      if (el.classList.contains('side-title')) {
        if (cur) sections.push(cur);
        cur = { name: el.textContent.trim(), nodes: [] };
      } else if (cur) cur.nodes.push(el);
    }
    if (cur) sections.push(cur);
    if (!sections.length) return;
    aside.style.display = 'none';

    const bottom = document.createElement('div');
    bottom.className = 'ow-bottom';
    const short = h => /журн/i.test(h) ? 'Журнал' : (/коммент/i.test(h) ? 'Комментарии' : (/участник/i.test(h) ? 'Участники' : h));
    sections.forEach(sec => {
      sec.short = short(sec.name);
      const box = document.createElement('div');
      box.className = 'ow-bsec';
      box.dataset.name = sec.short;
      box.style.display = 'none';
      const head = document.createElement('div');
      head.className = 'side-title';
      head.textContent = sec.name;
      box.appendChild(head);
      sec.nodes.forEach(n => box.appendChild(n));
      bottom.appendChild(box);
    });
    main.appendChild(bottom);

    const tabsEl = document.querySelector('.ow-tabs');
    const addTab = tabsEl.querySelector('.ow-tabadd');
    let openName = null;
    function toggle(name, tab) {
      const closing = openName === name;
      bottom.querySelectorAll('.ow-bsec').forEach(s => s.style.display = 'none');
      tabsEl.querySelectorAll('.ow-tab.ow-open').forEach(x => x.classList.remove('ow-open'));
      if (closing) {
        openName = null;
        bottom.classList.remove('on');
        main.style.setProperty('--ow-bottom-h', '0px');
      } else {
        const sec = bottom.querySelector('.ow-bsec[data-name="' + name + '"]');
        if (!sec) return;
        sec.style.display = 'flex';
        openName = name;
        tab.classList.add('ow-open');
        bottom.classList.add('on');
        main.style.setProperty('--ow-bottom-h', '110px');
        if (/коммент/i.test(name)) {
          const inp = sec.querySelector('#chat-in');
          if (inp) setTimeout(() => { try { inp.focus(); } catch (e) {} }, 120);
        }
      }
    }
    sections.forEach(sec => {
      const name = sec.short;
      let tab = Array.from(tabsEl.querySelectorAll('.ow-tab')).find(x => x.textContent.trim() === name);
      if (!tab) {
        tab = document.createElement('span');
        tab.className = 'ow-tab';
        tab.textContent = name;
        tabsEl.insertBefore(tab, addTab);
      }
      tab.addEventListener('click', () => toggle(name, tab));
    });
  })();

  // Панель эмодзи: чат живёт в нижней полосе, поэтому панель показываем
  // НАД кнопкой 😀 (fixed, позиция вычисляется по rect кнопки после клика).
  // Capture-слушатель + setTimeout(0): сработает после собственных
  // обработчиков страницы, какие бы они ни были.
  document.addEventListener('click', e => {
    const b = e.target && e.target.closest ? e.target.closest('#chat-emoji-btn') : null;
    if (!b) return;
    setTimeout(() => {
      const box = b.closest('#chat-box');
      const p = box ? box.querySelector('#chat-emoji') : null;
      if (!p || p.classList.contains('hidden')) return;
      const r = b.getBoundingClientRect();
      const pw = p.offsetWidth || 320, ph = p.offsetHeight || 160;
      p.style.left = Math.max(6, Math.min(r.left, window.innerWidth - pw - 6)) + 'px';
      p.style.top = Math.max(6, r.top - ph - 6) + 'px';
    }, 0);
  }, true);

  // «меню выхода» — шапка документа (#app > header): «▾» прячет её
  // ПОЛНОСТЬЮ (название, «Каталог», кнопки «Закрыть/Назад», статус) —
  // её строка становится обычными ячейками листа; маленькая «▸» в
  // левом верхнем углу области игры возвращает шапку. Только на своём экране.
  const h = document.querySelector('.ow-main #app > header');
  if (h && !h.querySelector('.ow-st')) {
    let hRest = null;
    const appEl = h.parentElement;
    if (appEl) {
      hRest = document.createElement('div');
      hRest.className = 'ow-rest';
      hRest.id = 'ow-hdr-rest';
      hRest.textContent = '▸';
      hRest.title = 'Показать шапку';
      hRest.style.cssText = 'position:absolute; top:2px; left:2px;';
      appEl.appendChild(hRest);
    }
    const hb = document.createElement('button');
    hb.type = 'button';
    hb.className = 'ow-st';
    hb.textContent = '▾';
    hb.title = 'Скрыть шапку полностью — сделать ячейки (только на вашем экране)';
    h.appendChild(hb);
    const setHdrOff = off => {
      h.classList.toggle('ow-off', off);
      hb.textContent = off ? '▸' : '▾';
      if (hRest) hRest.style.display = off ? 'block' : 'none';
    };
    hb.addEventListener('click', e => {
      e.stopPropagation();
      setHdrOff(!h.classList.contains('ow-off'));
    });
    if (hRest) hRest.addEventListener('click', e => { e.stopPropagation(); setHdrOff(false); });
  }

  // Общая кнопка правого поля: скрывает журнал, чат и участников одним кликом.
  const side = document.querySelector('.ow-main #app > #main > aside, .ow-main aside');
  if (side && !side.querySelector('.ow-side-toggle')) {
    const sb = document.createElement('button');
    sb.type = 'button';
    sb.className = 'ow-side-toggle';
    sb.textContent = '◀';
    sb.title = 'Скрыть правое поле целиком';
    side.insertBefore(sb, side.firstChild);
    sb.addEventListener('click', e => {
      e.stopPropagation();
      const off = side.classList.toggle('ow-side-off');
      sb.textContent = off ? '▶' : '◀';
      sb.title = off ? 'Показать правое поле' : 'Скрыть правое поле целиком';
    });
  }

  // Автоматически превращаем основные текстовые прямоугольники в ячейки.
  document.querySelectorAll('.ow-main #banner, .ow-main .plate, .ow-main .badge, .ow-main .seat, .ow-main .p-card, .ow-main .crow, .ow-main .pm-box, .ow-main .mbox, .ow-main .join-box').forEach(el => el.classList.add('ow-cell'));

  // сворачивание секций боковой панели (журнал/комментарии/участники):
  // «▾» прячет раздел ПОЛНОСТЬЮ (включая заголовок и поле ввода) только на
  // СВОЁМ экране — остаётся тонкая полоска с «▸» (свёрнутая группа строк).
  document.querySelectorAll('.side-title').forEach(t => {
    if (t.querySelector('.ow-st')) return;
    for (const n of Array.from(t.childNodes)) {
      if (n.nodeType === 3 && n.textContent.trim()) {
        const s = document.createElement('span');
        s.className = 'ow-sttxt';
        n.replaceWith(s);
        s.appendChild(n);
      }
    }
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'ow-st';
    b.textContent = '▾';
    b.title = 'Скрыть раздел полностью (только на вашем экране)';
    t.appendChild(b);
    b.addEventListener('click', e => {
      e.stopPropagation();
      const off = !t.classList.contains('ow-off');
      t.classList.toggle('ow-off', off);
      let el = t.nextElementSibling;
      while (el && !el.classList.contains('side-title')) {
        el.style.display = off ? 'none' : '';
        el = el.nextElementSibling;
      }
      b.textContent = off ? '▸' : '▾';
    });
  });

  // ============================================================
  //  v20 — интерактивная часть листа: выделение ячеек, диапазоны
  //  и статистика, горячие клавиши Excel, «Найти и заменить»,
  //  контекстное меню, зум, «Автосохранение» и «Свойства».
  //  Выделение работает только на «пустых» местах листа и на
  //  шапках строк/столбцов; кнопки и поля игр не затрагиваются.
  //  Esc сначала закрывает открытые панели/окна (capture-фаза
  //  срабатывает раньше bubble-обработчика panic.js), потом —
  //  босс-режим, как и раньше.
  // ============================================================
  const nameBox = document.getElementById('ow-cell-ref');
  const statsEl = document.getElementById('ow-stats');
  const selEl = grid.querySelector('.ow-sel');
  const sel = { rA: 1, cA: 1, rB: 1, cB: 1 };
  let dragging = false;

  const anchorRef = () => numToCol(sel.cA) + sel.rA;
  const normSel = () => ({
    r0: Math.min(sel.rA, sel.rB), r1: Math.max(sel.rA, sel.rB),
    c0: Math.min(sel.cA, sel.cB), c1: Math.max(sel.cA, sel.cB),
  });

  function updateStats() {
    if (!statsEl) return;
    const n = normSel();
    const total = (n.r1 - n.r0 + 1) * (n.c1 - n.c0 + 1);
    if (total <= 1) { statsEl.textContent = ''; return; }
    let sum = 0, cnt = 0, budget = 20000;
    outer:
    for (let r = n.r0; r <= n.r1; r++) {
      for (let c = n.c0; c <= n.c1; c++) {
        const ref = numToCol(c) + r;
        if (!Object.prototype.hasOwnProperty.call(cells, ref) || cells[ref] === '') continue;
        const v = NUMS(valueOf(ref));
        if (v !== null) { sum += v; cnt++; }
        if (--budget <= 0) break outer;
      }
    }
    if (!cnt) { statsEl.textContent = ''; return; }
    const fmt = x => (Math.round(x * 100) / 100).toLocaleString('ru-RU');
    statsEl.textContent = 'Среднее: ' + fmt(sum / cnt) + '    Сумма: ' + fmt(sum) + '    Количество: ' + cnt;
  }

  function applySel() {
    const n = normSel();
    if (selEl) {
      selEl.style.left = (HEADW + (n.c0 - 1) * COLW) + 'px';
      selEl.style.top = (HEADH + (n.r0 - 1) * ROWH) + 'px';
      selEl.style.width = (n.c1 - n.c0 + 1) * COLW + 'px';
      selEl.style.height = (n.r1 - n.r0 + 1) * ROWH + 'px';
    }
    if (colsEl) for (let i = 0; i < colsEl.children.length; i++) colsEl.children[i].classList.toggle('on', i + 1 >= n.c0 && i + 1 <= n.c1);
    if (rowsEl) for (let i = 0; i < rowsEl.children.length; i++) rowsEl.children[i].classList.toggle('on', i + 1 >= n.r0 && i + 1 <= n.r1);
    const ref = anchorRef();
    selected = ref;
    if (nameBox && !nameBox.querySelector('input')) nameBox.textContent = ref;
    if (formulaEl) {
      const rawv = Object.prototype.hasOwnProperty.call(cells, ref) ? cells[ref] : '';
      formulaEl.value = rawv || (ref === CELL && Object.keys(cells).length === 0 ? F : '');
    }
    if (editCells[ref]) {
      Object.values(editCells).forEach(x => x.classList.remove('selected'));
      editCells[ref].classList.add('selected');
    }
    updateStats();
  }

  function selectCellRef(ref) {
    const p = parseRef(ref); if (!p) return;
    sel.rA = sel.rB = p.r; sel.cA = sel.cB = p.c;
    applySel();
  }
  function setRange(rA, cA, rB, cB) {
    const nr = rowsEl ? rowsEl.children.length : 1, nc = colsEl ? colsEl.children.length : 1;
    const cl = (x, mx) => Math.max(1, Math.min(x, mx));
    sel.rA = cl(rA, nr); sel.cA = cl(cA, nc); sel.rB = cl(rB, nr); sel.cB = cl(cB, nc);
    applySel();
  }
  function evtCell(e) {
    const rect = grid.getBoundingClientRect();
    return {
      r: Math.floor((e.clientY - rect.top - HEADH) / ROWH) + 1,
      c: Math.floor((e.clientX - rect.left - HEADW) / COLW) + 1,
    };
  }

  // --- клик / протяжка по «пустому» листу → выделение ---
  const NO_SEL = 'input,textarea,select,button,label,a,.ow-cell-input,.ow-cell,.ow-edit-cell,.side-panel,.ow-bottom,.ow-rest,.ow-side-toggle,.ow-edit-toggle';
  main.addEventListener('mousedown', e => {
    if (e.button !== 0) return;
    const t = e.target;
    if (t.closest && (t.closest(NO_SEL) || t.closest('.ow-top') || t.closest('.ow-tabs') || t.closest('.ow-status'))) return;
    const p = evtCell(e);
    if (p.r < 1 || p.c < 1) return;
    setRange(p.r, p.c, p.r, p.c);
    dragging = true;
    e.preventDefault();
  });
  document.addEventListener('mousemove', e => {
    if (!dragging) return;
    const p = evtCell(e);
    if (p.r !== sel.rB || p.c !== sel.cB) setRange(sel.rA, sel.cA, p.r, p.c);
  });
  document.addEventListener('mouseup', () => { dragging = false; });

  // --- клик по букве столбца / номеру строки → весь столбец/строка ---
  if (colsEl) colsEl.addEventListener('mousedown', e => {
    const sp = e.target.closest ? e.target.closest('span') : null;
    if (!sp) return;
    e.preventDefault(); e.stopPropagation();
    const c = Array.prototype.indexOf.call(colsEl.children, sp) + 1;
    if (c > 0) setRange(1, c, rowsEl.children.length, c);
  });
  if (rowsEl) rowsEl.addEventListener('mousedown', e => {
    const sp = e.target.closest ? e.target.closest('span') : null;
    if (!sp) return;
    e.preventDefault(); e.stopPropagation();
    const r = Array.prototype.indexOf.call(rowsEl.children, sp) + 1;
    if (r > 0) setRange(r, 1, r, colsEl.children.length);
  });

  // --- зум (статус-бар: − / проценты / +) ---
  const ZLEVELS = [0.75, 0.9, 1, 1.1, 1.25, 1.5];
  function setZoom(z) {
    ZOOM = z;
    COLW = Math.round(34 * z); ROWH = Math.max(10, Math.round(13 * z));
    HEADW = Math.round(34 * z); HEADH = Math.max(10, Math.round(13 * z));
    main.style.setProperty('--ow-colw', COLW + 'px');
    main.style.setProperty('--ow-rowh', ROWH + 'px');
    main.style.setProperty('--ow-headw', HEADW + 'px');
    main.style.setProperty('--ow-headh', HEADH + 'px');
    const zv = document.getElementById('ow-zval');
    if (zv) zv.textContent = Math.round(z * 100) + '%';
    sizeGrid();
  }
  const zIn = document.getElementById('ow-zin'), zOut = document.getElementById('ow-zout');
  if (zIn) zIn.addEventListener('click', () => setZoom(ZLEVELS[Math.min(ZLEVELS.length - 1, ZLEVELS.indexOf(ZOOM) + 1)]));
  if (zOut) zOut.addEventListener('click', () => setZoom(ZLEVELS[Math.max(0, ZLEVELS.indexOf(ZOOM) - 1)]));

  // --- фейковые окна Excel (печать, свойства) ---
  let dlgOpen = false;
  const dlgMask = document.createElement('div'); dlgMask.className = 'ow-dlg-mask';
  const dlg = document.createElement('div'); dlg.className = 'ow-dlg';
  document.body.appendChild(dlgMask); document.body.appendChild(dlg);
  function closeDlg() {
    dlgOpen = false;
    dlgMask.classList.remove('on'); dlg.classList.remove('on');
    dlg.innerHTML = '';
  }
  function openDlg(title, bodyHtml, footHtml) {
    dlgOpen = true;
    dlg.innerHTML =
      '<div class="ow-dlg-t"><span class="ow-xic" style="width:14px;height:14px;font-size:9px">X</span><span>' + title + '</span><span class="ow-dlg-x" title="Закрыть">&#10005;</span></div>' +
      '<div class="ow-dlg-b">' + bodyHtml + '</div>' +
      (footHtml ? '<div class="ow-dlg-f">' + footHtml + '</div>' : '');
    dlgMask.classList.add('on'); dlg.classList.add('on');
    dlg.querySelector('.ow-dlg-x').addEventListener('click', closeDlg);
    dlg.querySelectorAll('.ow-dlg-btn').forEach(b => b.addEventListener('click', () => {
      const act = b.getAttribute('data-act');
      closeDlg();
      if (act === 'print') readyFlash('Печать: отправка в очередь…', 1600);
    }));
  }
  dlgMask.addEventListener('click', closeDlg);
  function openPrintDlg() {
    if (dlgOpen) return;
    openDlg('Печать — ' + esc(DOC),
      '<div class="ow-dlg-row"><label>Имя принтера:</label><select><option>Microsoft Print to PDF</option><option>Электронный документ (Excel)</option></select></div>' +
      '<div class="ow-dlg-row"><label>Область печати:</label><select><option>Весь лист</option><option>Текущий диапазон</option></select></div>' +
      '<div class="ow-dlg-row"><label>Копий:</label><input value="1"></div>' +
      '<div class="ow-dlg-row"><label>Ориентация:</label><select><option>Альбомная</option><option>Книжная</option></select></div>',
      '<button class="ow-dlg-btn" type="button">Отмена</button><button class="ow-dlg-btn p" type="button" data-act="print">Печать</button>');
  }
  function openPropsDlg() {
    if (dlgOpen) return;
    const d = new Date();
    openDlg('Свойства: ' + esc(DOC),
      '<div class="ow-dlg-row"><label>Имя файла:</label><span class="v">' + esc(DOC) + '</span></div>' +
      '<div class="ow-dlg-row"><label>Тип файла:</label><span class="v">Книга Excel (.xlsx)</span></div>' +
      '<div class="ow-dlg-row"><label>Автор:</label><span class="v">Отдел планирования</span></div>' +
      '<div class="ow-dlg-row"><label>Создано:</label><span class="v">' + d.toLocaleDateString('ru-RU') + '</span></div>' +
      '<div class="ow-dlg-row"><label>Изменено:</label><span class="v">' + d.toLocaleDateString('ru-RU') + ', только что (автосохранение)</span></div>' +
      '<div class="ow-dlg-row"><label>Ячеек с данными:</label><span class="v">' + Object.keys(cells).length + '</span></div>',
      '<button class="ow-dlg-btn" type="button">Отмена</button><button class="ow-dlg-btn p" type="button">ОК</button>');
  }

  // --- «Найти и заменить» (Ctrl+F): панель справа, настоящий поиск ---
  const find = document.createElement('div'); find.className = 'ow-find';
  find.innerHTML =
    '<div class="ow-find-t"><span>Найти и заменить</span><span class="ow-find-x" title="Закрыть (Esc)">&#10005;</span></div>' +
    '<div class="ow-find-tabs"><span class="on">Найти</span><span>Заменить</span></div>' +
    '<div class="ow-find-b"><span class="ow-find-lab">Поиск:</span><input class="ow-find-in" id="ow-find-in" placeholder="Введите текст…" spellcheck="false"></div>' +
    '<div class="ow-find-b"><span class="ow-find-lab">Область:</span><input class="ow-find-in" value="Все ячейки листа" readonly></div>' +
    '<div class="ow-find-btns"><button class="ow-find-btn" id="ow-find-next" type="button">Найти далее</button><button class="ow-find-btn" id="ow-find-prev" type="button">Найти назад</button></div>' +
    '<div class="ow-find-note" id="ow-find-note"></div>';
  document.body.appendChild(find);
  let findOpen = false, findIdx = -1;
  function findTop() {
    find.style.top = (top.classList.contains('ow-off') ? 0 : top.offsetHeight) + 'px';
    find.style.bottom = (tabs.offsetHeight + hscroll.offsetHeight + status.offsetHeight) + 'px';
  }
  function toggleFind(force) {
    findOpen = force !== undefined ? !!force : !findOpen;
    find.classList.toggle('on', findOpen);
    if (findOpen) {
      findTop();
      findIdx = -1;
      const note = find.querySelector('#ow-find-note'); if (note) note.textContent = '';
      const inp = find.querySelector('#ow-find-in'); if (inp) { inp.value = ''; inp.focus(); }
    }
  }
  function flashFound(ref) {
    const p = parseRef(ref); if (!p) return;
    const f = document.createElement('div'); f.className = 'ow-found';
    f.style.left = (HEADW + (p.c - 1) * COLW) + 'px';
    f.style.top = (HEADH + (p.r - 1) * ROWH) + 'px';
    f.style.width = COLW + 'px'; f.style.height = ROWH + 'px';
    grid.appendChild(f);
    setTimeout(() => f.remove(), 900);
  }
  function doFind(dir) {
    const inp = find.querySelector('#ow-find-in'), note = find.querySelector('#ow-find-note');
    const q = (inp.value || '').trim();
    if (!q) { note.textContent = 'Введите текст для поиска.'; return; }
    const low = q.toLowerCase(), hits = [];
    for (const ref of Object.keys(cells)) {
      const rawv = String(cells[ref]), shown = String(valueOf(ref));
      if (rawv.toLowerCase().indexOf(low) > -1 || (shown !== rawv && shown.toLowerCase().indexOf(low) > -1)) hits.push(ref);
    }
    if (!hits.length) { note.textContent = 'Строка поиска не найдена'; readyFlash('Строка поиска не найдена', 1600); return; }
    hits.sort((a, b) => { const pa = parseRef(a), pb = parseRef(b); return (pa.c - pb.c) || (pa.r - pb.r); });
    findIdx = findIdx === -1 ? (dir > 0 ? 0 : hits.length - 1) : (dir > 0 ? findIdx + 1 : findIdx - 1 + hits.length) % hits.length;
    const ref = hits[findIdx];
    selectCellRef(ref);
    flashFound(ref);
    note.textContent = 'Найдено ' + (findIdx + 1) + ' из ' + hits.length;
    inp.focus();
  }
  find.querySelector('.ow-find-x').addEventListener('click', () => toggleFind(false));
  find.querySelector('#ow-find-next').addEventListener('click', () => doFind(1));
  find.querySelector('#ow-find-prev').addEventListener('click', () => doFind(-1));
  find.querySelector('#ow-find-in').addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.preventDefault(); doFind(e.shiftKey ? -1 : 1); }
    else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); toggleFind(false); }
  });

  // --- контекстное меню (правый клик по листу) ---
  const cmenu = document.createElement('div'); cmenu.className = 'ow-cmenu';
  const CM = [
    ['cut', 'Вырезать', 'Ctrl+X'],
    ['copy', 'Копировать', 'Ctrl+C'],
    ['paste', 'Вставить', 'Ctrl+V'],
    ['hr'],
    ['ins', 'Вставить…', ''],
    ['del', 'Удалить…', ''],
    ['fmt', 'Формат ячеек…', ''],
    ['hr'],
    ['props', 'Свойства документа…', 'Ctrl+F2'],
  ];
  cmenu.innerHTML = CM.map(it => it[0] === 'hr' ? '<hr>' :
    '<div class="ow-cmi" data-act="' + it[0] + '"><span>' + it[1] + '</span><span class="k">' + it[2] + '</span></div>').join('');
  document.body.appendChild(cmenu);
  let cmenuOpen = false;
  function hideCmenu() { cmenuOpen = false; cmenu.classList.remove('on'); }
  function showCmenu(x, y) {
    cmenuOpen = true; cmenu.classList.add('on');
    cmenu.style.left = Math.min(x, window.innerWidth - 205) + 'px';
    cmenu.style.top = Math.min(y, window.innerHeight - 250) + 'px';
  }
  function copyToClipboard(v) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(v).then(
        () => readyFlash('Скопировано в буфер обмена', 1100),
        () => readyFlash('Скопировано: «' + v + '»', 1500));
    } else readyFlash('Скопировано: «' + v + '»', 1500);
  }
  cmenu.addEventListener('click', e => {
    const it = e.target.closest ? e.target.closest('.ow-cmi') : null;
    if (!it) return;
    const act = it.getAttribute('data-act'), ref = anchorRef();
    hideCmenu();
    if (act === 'copy') copyToClipboard(String(valueOf(ref)));
    else if (act === 'cut') { copyToClipboard(String(valueOf(ref))); delete cells[ref]; persist(); refreshEditGrid(); selectCellRef(ref); }
    else if (act === 'paste') {
      const done = t => {
        cells[ref] = String(t).split('\n')[0];
        if (!cells[ref]) delete cells[ref];
        persist(); refreshEditGrid(); selectCellRef(ref);
        readyFlash('Вставлено в ' + ref, 1000);
      };
      if (navigator.clipboard && navigator.clipboard.readText) navigator.clipboard.readText().then(done, () => readyFlash('Буфер обмена недоступен — вставьте через Ctrl+V в строку формул', 1800));
      else readyFlash('Буфер обмена недоступен — вставьте через Ctrl+V в строку формул', 1800);
    }
    else if (act === 'ins') readyFlash('Вставка: выберите данные', 1100);
    else if (act === 'del') { delete cells[ref]; persist(); refreshEditGrid(); selectCellRef(ref); readyFlash('Содержимое удалено', 1000); }
    else if (act === 'fmt') readyFlash('Формат ячеек: Обычный', 1100);
    else if (act === 'props') openPropsDlg();
  });
  main.addEventListener('contextmenu', e => {
    const t = e.target;
    if (t.closest && t.closest('input,textarea')) return;
    e.preventDefault();
    showCmenu(e.clientX, e.clientY);
  });
  document.addEventListener('mousedown', e => { if (cmenuOpen && !cmenu.contains(e.target)) hideCmenu(); }, true);
  window.addEventListener('blur', hideCmenu);

  // --- адрес ячейки в именном поле: клик → ручной ввод ---
  let nameEditing = false;
  function closeNameEdit(commit) {
    if (!nameEditing || !nameBox) return;
    nameEditing = false;
    const inp = nameBox.querySelector('input');
    const ref = commit && inp ? parseRef(inp.value) : null;
    nameBox.textContent = anchorRef();
    if (ref) selectCellRef(numToCol(ref.c) + ref.r); else applySel();
  }
  if (nameBox) {
    nameBox.title = 'Адрес ячейки: клик — ввести вручную, Enter — перейти';
    nameBox.addEventListener('mousedown', e => e.stopPropagation());
    nameBox.addEventListener('click', e => {
      e.stopPropagation();
      if (nameEditing) return;
      nameEditing = true;
      const inp = document.createElement('input');
      inp.value = anchorRef(); inp.spellcheck = false;
      nameBox.textContent = ''; nameBox.appendChild(inp); inp.focus(); inp.select();
      inp.addEventListener('keydown', ev => {
        if (ev.key === 'Enter') { ev.preventDefault(); closeNameEdit(true); }
        else if (ev.key === 'Escape') { ev.preventDefault(); ev.stopPropagation(); closeNameEdit(false); }
      });
      inp.addEventListener('blur', () => closeNameEdit(true), { once: true });
    });
  }

  // --- страж Esc: закрывает открытые панели/окна/ввод, а не босс-режим ---
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    if (document.body.classList.contains('yzp-on')) return; // Esc выводит из босс-режима
    if (nameEditing) { e.preventDefault(); e.stopPropagation(); closeNameEdit(false); return; }
    if (findOpen) { e.preventDefault(); e.stopPropagation(); toggleFind(false); return; }
    if (cmenuOpen) { e.preventDefault(); e.stopPropagation(); hideCmenu(); return; }
    if (dlgOpen) { e.preventDefault(); e.stopPropagation(); closeDlg(); return; }
    // ввод в ячейку — собственное поле обрабатывает Esc (stopPropagation)
  }, true);

  // --- горячие клавиши Excel и навигация по листу ---
  document.addEventListener('keydown', e => {
    const ae = document.activeElement;
    const onChrome = ae === document.body || ae === document.documentElement;
    if ((e.ctrlKey || e.metaKey) && !e.altKey) {
      const k = (e.key || '').toLowerCase();
      if (k === 's' || k === 'ф') { e.preventDefault(); readyFlash('Сохранение…', 1200); return; }
      if (k === 'p' || k === 'з') { e.preventDefault(); if (!dlgOpen) openPrintDlg(); return; }
      if (k === 'f' || k === 'а') { e.preventDefault(); if (!document.body.classList.contains('yzp-on')) toggleFind(true); return; }
      if (e.key === 'F2') { e.preventDefault(); if (!dlgOpen) openPropsDlg(); return; }
    }
    if (!onChrome || e.ctrlKey || e.altKey || e.metaKey) return;
    const nr = rowsEl ? rowsEl.children.length : 1, nc = colsEl ? colsEl.children.length : 1;
    const mv = (dr, dc) => {
      e.preventDefault();
      if (e.shiftKey) setRange(sel.rA, sel.cA, Math.max(1, Math.min(sel.rB + dr, nr)), Math.max(1, Math.min(sel.cB + dc, nc)));
      else { const r = Math.max(1, Math.min(sel.rA + dr, nr)), c = Math.max(1, Math.min(sel.cA + dc, nc)); setRange(r, c, r, c); }
    };
    if (e.key === 'ArrowUp') mv(-1, 0);
    else if (e.key === 'ArrowDown') mv(1, 0);
    else if (e.key === 'ArrowLeft') mv(0, -1);
    else if (e.key === 'ArrowRight') mv(0, 1);
    else if (e.key === 'Tab') mv(0, e.shiftKey ? -1 : 1);
    else if (e.key === 'Enter') { if (!editMode) mv(1, 0); }
    else if (e.key === 'F2') {
      if (editGrid.classList.contains('on')) { const el = editCells[anchorRef()]; if (el) { e.preventDefault(); beginEdit(el); } }
    }
    else if (e.key === 'Delete' || e.key === 'Backspace') {
      const ref = anchorRef();
      if (Object.prototype.hasOwnProperty.call(cells, ref)) { delete cells[ref]; persist(); refreshEditGrid(); selectCellRef(ref); }
    }
    else if (e.key.length === 1 && editGrid.classList.contains('on') && !editMode && !e.shiftKey) {
      const ch = e.key;
      if (/[a-zA-ZА-Яа-яёЁ0-9+=\-.,:;()$/@#%&|<>!?*'"]/.test(ch)) {
        const el = editCells[anchorRef()];
        if (el && !el.querySelector('.ow-cell-input')) { e.preventDefault(); beginEdit(el, ch); }
      }
    }
  });

  // --- пилюля «Автосохранение» в заголовке окна ---
  const asv = document.getElementById('ow-asv');
  if (asv) asv.addEventListener('click', e => {
    e.stopPropagation();
    autoSave = !autoSave;
    asv.classList.toggle('off', !autoSave);
    asv.innerHTML = '&#128190; Автосохранение: ' + (autoSave ? 'ВКЛ' : 'ВЫКЛ');
    readyFlash(autoSave ? 'Автосохранение включено' : 'Автосохранение выключено', 1200);
  });

  // --- =СЕЙЧАС() — пересчёт каждые 30 секунд ---
  setInterval(() => {
    try { if (Object.keys(cells).some(ref => /СЕЙЧАС/i.test(String(cells[ref])))) refreshEditGrid(); } catch (_) {}
  }, 30000);

  // --- начальное состояние: выбрана ячейка из конфига страницы ---
  try { selectCellRef(CELL); } catch (_) { /* ignore */ }
})();
