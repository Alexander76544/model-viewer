// ============================================================
//  «Офисная тема» — общий хром окна Microsoft Excel для всех
//  страниц подпольного ЯМЗ (максимальная маскировка).
//
//  Страница задаёт конфигурацию ПЕРЕД подключением:
//     <script>window.OFFICE = { doc:'Имя_файла.xlsx',
//       tabs:['Лист1','Лист2'], formula:'=СУММ(B2:B50)', cell:'B4',
//       flow:true /* лобби: обычный поток, со скроллом */ };</script>
//     <script src="/office.js"></script>
//
 //  Что делает:
 //   - зелёный заголовок «Microsoft Excel — имя.xlsx» + кнопки окна
 //     (кнопка «✕» запускает босс-режим, если доступен YAMZ_PANIC);
 //   - меню Файл/Правка/Вид/… и псевдо-ленту с кнопками;
 //   - строку формул (ячейка + fx + формула);
 //   - вкладки листов внизу и статус-бар «Готово» с часами;
 //   - переносит текущее содержимое body во внутреннюю область
 //     и подгоняет fixed-блоки игр под границы окна;
 //   - Excel-сетку позади всего окна: буквы столбцов A.., номера строк 1..,
 //     линии ячеек 92×22 — страница выглядит как настоящий лист;
 //   - панели журнала/чата/участников оформляет как строки-ячейки
 //     с номерами строк слева; поле ввода чата — как ячейка;
  //   - у каждой секции панели кнопка «▾»/«▸»: скрывает её ПОЛНОСТЬЮ
  //     (включая заголовок) только на своём экране — для маскировки;
  //   - «▾» в заголовке окна скрывает ВСЁ верхнее меню (заголовок, меню,
  //     ленту, строку формул): лист занимает окно целиком, ячейки до
  //     самого края; возвращает угловая кнопка «▾».
  //   - «▾» в шапке игрового документа скрывает её ПОЛНОСТЬЮ — строка
  //     становится обычными ячейками листа; возвращает маленькая «▸»
  //     в левом верхнем углу области игры.
// ============================================================
(function () {
  'use strict';
  const cfg = window.OFFICE;
  if (!cfg) return;
  const DOC = cfg.doc || 'Рабочая_книга.xlsx';
  const TABS = (cfg.tabs && cfg.tabs.length) ? cfg.tabs : ['Лист1', 'Лист2'];
  const F = cfg.formula || '=СУММ(B2:B100)';
  const CELL = cfg.cell || 'C4';
  const esc = s => String(s).replace(/[&<>"]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]));

  const style = document.createElement('style');
  style.id = 'ow-style';
  style.textContent = `
    html,body{height:100%;}
    body{display:flex !important; flex-direction:column !important; overflow:hidden !important; margin:0 !important; background:#fff; font-family:Tahoma,'Segoe UI',Arial,sans-serif;}
    .ow-top{flex:none; user-select:none; z-index:500;}
    /* заголовок — тёмно-зелёная тема Office, поиск по центру */
    .ow-title{height:27px; background:#185C37; color:#fff; display:flex; align-items:center; padding:0 6px; gap:6px; font-size:11px; line-height:1;}
    .ow-xic{width:16px; height:16px; flex:none; background:#fff; color:#185C37; font-weight:700; font-size:11px; display:flex; align-items:center; justify-content:center; font-family:Arial,sans-serif;}
    .ow-ttext{flex:1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; color:rgba(255,255,255,.95);}
    .ow-search{margin:0 auto; width:170px; height:17px; flex:none; background:rgba(255,255,255,.16); border:1px solid rgba(255,255,255,.25); border-radius:3px; display:flex; align-items:center; gap:5px; padding:0 7px; color:rgba(255,255,255,.85); font-size:10.5px;}
    .ow-srch{position:relative; width:9px; height:9px; border:1.5px solid rgba(255,255,255,.85); border-radius:50%; flex:none;}
    .ow-srch::after{content:''; position:absolute; right:-4px; bottom:-3px; width:4px; height:1.5px; background:rgba(255,255,255,.85); transform:rotate(45deg);}
    .ow-people{position:relative; width:12px; height:11px; flex:none;}
    .ow-people::before{content:''; position:absolute; left:2px; top:0; width:5px; height:5px; border:1.5px solid rgba(255,255,255,.9); border-radius:50%;}
    .ow-people::after{content:''; position:absolute; left:0; top:6.5px; width:9px; height:4.5px; border:1.5px solid rgba(255,255,255,.9); border-bottom:none; border-radius:5px 5px 0 0;}
    .ow-tbtns{margin-left:auto; display:flex; align-items:center; flex:none;}
    .ow-wbtn{width:30px; height:19px; text-align:center; font-size:11px; line-height:18px; color:#fff; cursor:default; flex:none;}
    .ow-wbtn:hover{background:rgba(255,255,255,.14);}
    .ow-wbtn.x:hover{background:#E81123;}
    .ow-wbtn[data-ow]{cursor:pointer;}
    .ow-cloud{width:18px; height:17px; flex:none; margin:0 2px; background:#2B7CD3; border-radius:2px; color:#fff; font-size:10px; display:flex; align-items:center; justify-content:center;}
    .ow-share{flex:none; margin-left:5px; height:19px; padding:0 9px; display:flex; align-items:center; gap:5px; background:rgba(255,255,255,.16); border:1px solid rgba(255,255,255,.4); border-radius:3px; color:#fff; font-size:10.5px; cursor:pointer;}
    .ow-share:hover{background:rgba(255,255,255,.28);}
    /* полное скрытие верхнего меню (заголовок+меню+лента+формулы) и
       нижнего (вкладки+статус-бар): ячейки доходят до края окна;
       возвращает маленькая кнопка «▴» в углу */
    .ow-top.ow-off{display:none !important;}
    .ow-tminus{width:20px; height:20px; border:1px solid #c8c8c8; background:#fff; color:#444; display:flex; align-items:center; justify-content:center; margin-left:6px; font-size:11px; cursor:pointer; flex:none;}
    .ow-tminus:hover{border-color:#217346; color:#217346;}
    .ow-rest{position:fixed; z-index:501; width:18px; height:14px; box-sizing:border-box; background:#f4f6f8; border:1px solid #c9ced6; color:#6b7280; font:9px Tahoma,Arial,sans-serif; line-height:12px; text-align:center; cursor:pointer; display:none; user-select:none;}
    .ow-rest:hover{background:#e2f0e8; color:#217346; border-color:#9fcdb2;}
    #ow-top-rest{top:1px; left:1px;}
    /* вкладки меню (лента) — как в настоящем Excel */
    .ow-menu{height:23px; background:#fff; border-bottom:1px solid #e6e3e1; display:flex; align-items:stretch; padding:0 6px; font-size:11px; color:#252423;}
    .ow-mtab{display:flex; align-items:center; padding:0 8px; cursor:default; white-space:nowrap;}
    .ow-mtab:hover{background:#f3f2f1;}
    .ow-mtab.file{font-weight:600;}
    .ow-mtab.on{color:#107C41; font-weight:600; box-shadow:inset 0 -2px 0 #107C41;}
    /* лента: группы с иконками и подписями снизу */
    .ow-ribbon{height:84px; background:#faf9f8; border-bottom:1px solid #e1dfdd; display:flex; align-items:stretch; padding:3px 2px 0; overflow:hidden;}
    .ow-rb{flex:none; display:flex; flex-direction:column; padding:1px 4px 0; border-right:1px solid #e6e3e1; min-width:0;}
    .ow-rb:last-child{border-right:0;}
    .ow-rb-rows{flex:1; display:flex; flex-direction:column; justify-content:center; gap:2px; min-width:0;}
    .ow-rb-row{display:flex; align-items:center; gap:2px; min-width:0;}
    .ow-rb-lab{flex:none; font-size:9px; color:#797775; text-align:center; padding:2px 0 3px; line-height:1; white-space:nowrap; overflow:hidden;}
    .ow-rb-btn{display:flex; align-items:center; gap:4px; border:1px solid transparent; background:transparent; color:#252423; font-size:10px; padding:1px 4px; cursor:pointer; line-height:1.2; text-align:left; white-space:nowrap;}
    .ow-rb-btn:hover{background:#eef6f1; border-color:#c9e2d3;}
    .ow-rb-ic{flex:none; width:16px; height:16px; display:flex; align-items:center; justify-content:center; font-size:12px; color:#444;}
    .ow-rb-lg .ow-rb-ic{width:20px; height:20px; font-size:15px;}
    .ow-rb-dd{font-size:8px; color:#797775; flex:none;}
    .ow-fontbox{border:1px solid #c8c6c4; background:#fff; font-size:10px; padding:0 3px; height:16px; display:flex; align-items:center; gap:3px; color:#252423; cursor:pointer;}
    .ow-fontbox.small{min-width:26px; justify-content:center;}
    .ow-ab{font-weight:700;} .ow-ai{font-style:italic;} .ow-au{text-decoration:underline;} .ow-as{text-decoration:line-through;}
    .ow-ar{color:#fff; background:#d13438; font-weight:700; padding:0 2px;}
    .ow-ahl{background:#ffe8a3; padding:0 2px; font-weight:700;}
    .ow-al{width:14px; height:12px; flex:none; display:flex; flex-direction:column; gap:2px; align-self:center;}
    .ow-al i{display:block; height:2px; background:#555;}
    .ow-al.c i{margin:0 auto;} .ow-al.c i:nth-child(2){width:70%;}
    .ow-al.r i{margin-left:auto;} .ow-al.r i:nth-child(2){width:70%;}
    .ow-al.j i:nth-child(2){width:70%; margin:0 auto;}
    .ow-sty{width:68px; display:flex; align-items:center; gap:3px; border:1px solid #d7d4d0; background:#fff; font-size:8px; padding:0 4px; color:#252423; cursor:pointer; white-space:nowrap;}
    .ow-stys{display:grid; grid-template-columns:repeat(3,68px); gap:2px; align-content:center;}
    .ow-sty i{width:8px; height:10px; flex:none; border:1px solid rgba(0,0,0,.25); background:repeating-linear-gradient(to bottom,#fff 0 3px,#e9e9e9 3px 4px);}
    .ow-sty.b{color:#1F4E78;} .ow-sty.o{color:#C45911;} .ow-sty.r{color:#C00000;} .ow-sty.g{color:#375623;} .ow-sty.y{color:#7F6000;}
    .ow-sty.hot{border-color:#E26B0A; background:#fdf4e8;}
    /* строка формул: имя ячейки + fx + поле */
    .ow-fbar{height:20px; background:#fff; display:flex; align-items:center; border-bottom:1px solid #e1dfdd; font-size:11px; padding:0 2px;}
    .ow-fcell{width:52px; height:16px; border:1px solid #c8c6c4; background:#fff; display:flex; align-items:center; justify-content:center; margin-right:3px; font-size:11px; color:#252423; flex:none;}
    .ow-fx{width:30px; display:flex; align-items:center; justify-content:center; color:#605e5c; font-style:italic; font-weight:700; font-family:Georgia,'Times New Roman',serif; flex:none;}
    .ow-fval{flex:1; display:flex; align-items:center; padding:0 8px; color:#333; white-space:nowrap; overflow:hidden; min-width:0;}
    .ow-formula{border:0 !important; outline:0 !important; background:#fff !important; min-width:0; font:11px Tahoma,Arial,sans-serif;}
    .ow-formula:focus{box-shadow:inset 0 0 0 1px #107C41 !important;}
    .ow-edit-toggle{background:none; border:0; color:#fff; font:10.5px Tahoma,Arial,sans-serif; cursor:pointer; padding:0 4px; opacity:.92;}
    .ow-edit-toggle:hover{text-decoration:underline; opacity:1;}
    .ow-cell-edit{outline:2px solid #217346 !important; outline-offset:-2px !important; background:#fff !important;}
    .ow-cell-input{position:absolute; inset:0; width:100%; height:100%; box-sizing:border-box; border:0; padding:2px 5px; outline:0; background:#fff; font:12px Tahoma,Arial,sans-serif; color:#222;}
    .ow-cell-input:focus{box-shadow:inset 0 0 0 2px #217346;}
    .ow-edit-grid{position:absolute; top:13px; left:34px; right:0; bottom:0; z-index:3; display:grid; grid-template-columns:repeat(40,34px); grid-auto-rows:13px; pointer-events:none; overflow:hidden;}
    .ow-edit-grid.on{pointer-events:auto;}
    .ow-edit-grid .ow-edit-cell{position:relative; box-sizing:border-box; min-width:34px; height:13px; padding:0 4px; overflow:hidden; border:1px solid transparent; background:transparent; font:10px Tahoma,Arial,sans-serif; color:#222; cursor:cell; white-space:nowrap;}
    .ow-edit-grid.on .ow-edit-cell:hover{border-color:#9fcdb2; background:rgba(226,240,232,.72);}
    .ow-edit-grid .ow-edit-cell.has-value{background:rgba(255,255,255,.88); border-color:#c9ced6;}
    .ow-edit-grid .ow-edit-cell.selected{outline:2px solid #217346; outline-offset:-2px; z-index:2;}
    .ow-main{flex:1; position:relative; z-index:0; --ow-bottom-h:0px; ${cfg.flow ? 'overflow:auto' : 'overflow:hidden'}; background:#fff;}
    ${cfg.flow ? '.ow-main.ow-flow{padding:13px 0 0 34px !important; box-sizing:border-box;} .ow-main.ow-flow > :not(.ow-grid){position:relative; z-index:1;}' : '.ow-main > :is(#app,#join,#backmodal,#hostmodal,#rolemask,#cardmask){position:absolute !important; top:13px !important; left:34px !important; right:0 !important; bottom:var(--ow-bottom-h) !important; transition:bottom .1s linear;}'}
    /* ---------- нижние панели: журнал / комментарии как вкладки Excel ---------- */
    .ow-bottom{position:absolute; left:34px; right:0; bottom:0; z-index:6; background:#fff; border-top:1px solid #c9ced6; display:none; overflow:hidden;}
    .ow-bottom.on{display:block;}
    .ow-bsec{display:flex; flex-direction:column; height:110px;}
    .ow-bsec .side-panel{flex:1 1 0 !important; min-height:0 !important;}
    .ow-bsec #chat-box{flex:none; height:22px; overflow:hidden;}
    /* Панель эмодзи — fixed: чат внизу, и absolute-позиция обрезалась
       22px-строкой чата и полосой .ow-bottom (overflow:hidden). */
    .ow-bsec #chat-emoji{position:fixed !important; z-index:500;}
    .ow-bsec #chat-row{width:auto; max-width:560px; margin:2px 8px; gap:4px;}
    .ow-bsec #chat-in{width:100%; max-width:420px;}
    .ow-tab.ow-open{background:#fff !important; color:#217346 !important; border-bottom:2px solid #217346 !important; margin-bottom:-1px;}
    .ow-main > :not(.ow-grid){z-index:1;}
    .ow-main #app{background:transparent !important; overflow:hidden !important;}
    .ow-main #app > header{height:22px !important; min-height:22px !important; box-sizing:border-box !important; padding:0 8px !important; border-bottom:1px solid #c9ced6 !important; background:#f4f6f8 !important; color:#333 !important;}
    .ow-main #app > header b{font-size:11px !important; color:#217346 !important;}
    .ow-main #app > #main{min-height:0 !important; overflow:hidden !important;}
    .ow-main #app > #main > aside{width:276px !important; min-width:276px !important; max-width:276px !important; background:#fff !important;}
    .ow-main aside{position:relative !important; box-sizing:border-box !important;}
    .ow-main aside.ow-side-off{width:22px !important; min-width:22px !important; max-width:22px !important; background:#f4f6f8 !important; border-left:1px solid #c9ced6 !important;}
    .ow-main aside.ow-side-off > :not(.ow-side-toggle){display:none !important;}
    .ow-side-toggle{display:flex !important; align-items:center !important; justify-content:center !important; flex:none !important; width:22px !important; min-width:22px !important; height:22px !important; margin:0 !important; padding:0 !important; border:0 !important; border-bottom:1px solid #c9ced6 !important; border-radius:0 !important; background:#f4f6f8 !important; color:#5f6b7a !important; font:11px Consolas,monospace !important; cursor:pointer !important;}
    .ow-side-toggle:hover{background:#e2f0e8 !important; color:#217346 !important;}
    .ow-main .side-title{height:22px !important; min-height:22px !important; box-sizing:border-box !important; padding:0 6px 0 8px !important; line-height:21px !important; border-bottom:1px solid #c9ced6 !important; background:#f4f6f8 !important; color:#333 !important; font-size:11px !important; font-weight:600 !important;}
    .ow-main .side-panel{overflow:auto !important;}
    .ow-main .side-panel > *{min-height:22px !important; box-sizing:border-box !important; padding:3px 6px 3px 38px !important; line-height:16px !important;}
    .ow-main .side-title.ow-off{height:18px !important; min-height:18px !important; line-height:17px !important;}
    /* Текст игры лежит прямо на сетке листа: без лишних рамок и белых плашек. */
    .ow-main .ow-cell{box-sizing:border-box !important; min-height:22px !important; border:0 !important; border-radius:0 !important; background:transparent !important; color:#222 !important; font-family:Tahoma,'Segoe UI',Arial,sans-serif !important;}
    .ow-main .ow-cell::before{display:none !important;}
    .ow-main .ow-cell input,.ow-main .ow-cell button{border-radius:0 !important; font-family:Tahoma,'Segoe UI',Arial,sans-serif !important;}
    .ow-main .ow-grid{z-index:0 !important;}
    .ow-main .ow-garea{background-color:transparent !important;}
    .ow-tabs{flex:none; height:22px; background:#f3f2f1; border-top:1px solid #d9d9d9; display:flex; align-items:stretch; padding:3px 4px 0; font-size:10.5px; user-select:none;}
    .ow-tab{display:flex; align-items:center; padding:2px 12px; background:transparent; border:1px solid transparent; color:#444; cursor:pointer;}
    .ow-tab:hover{border-color:#c8c8c8; background:#faf9f8;}
    .ow-tab.on{background:#fff; border-color:#d1d1d1; border-bottom-color:#fff; color:#107C41; font-weight:600; box-shadow:inset 0 -2px 0 #107C41;}
    .ow-tplus{width:18px; height:18px; align-self:center; border:1px solid #c8c8c8; background:#fff; color:#444; display:flex; align-items:center; justify-content:center; margin-left:6px; font-size:12px; flex:none;}
    .ow-tplus:hover{border-color:#217346; color:#217346;}
    /* фейковый горизонтальный скроллбар (как в настоящем Excel) */
    .ow-hscroll{flex:none; height:14px; background:#faf9f8; border-top:1px solid #e1dfdd; position:relative; user-select:none;}
    .ow-hscroll .track{position:absolute; left:2px; right:30px; top:1px; bottom:1px; background:#f0f0f0;}
    .ow-hscroll .thumb{position:absolute; left:12%; width:80%; top:3px; bottom:3px; background:#b7b7b7;}
    .ow-hscroll .arr{position:absolute; top:1px; bottom:1px; width:14px; background:#faf9f8; display:flex; align-items:center; justify-content:center; font-size:8px; color:#666;}
    .ow-hscroll .arr.l{left:0;} .ow-hscroll .arr.r{right:0;}
    /* статус-бар — зелёный: слева «Готово», справа режимы + 100% */
    .ow-status{flex:none; height:22px; background:#185C37; color:#fff; display:flex; align-items:center; font-size:10.5px; padding:0 10px; user-select:none; gap:8px;}
    .ow-sleft{flex:1; display:flex; align-items:center; gap:8px; white-space:nowrap; overflow:hidden;}
    .ow-sright{display:flex; align-items:center; gap:8px; white-space:nowrap;}
    .ow-view{width:16px; height:14px; border:1px solid rgba(255,255,255,.45); display:flex; align-items:center; justify-content:center; font-size:8px; cursor:default;}
    .ow-view.on{background:rgba(255,255,255,.22);}
    .ow-main .side-title{display:flex; align-items:center;}
    .ow-main .side-title .ow-st{margin-left:auto; background:none; border:none; padding:0 2px 0 8px; font-size:12px; color:#8b96ab; cursor:pointer; line-height:1; flex:none;}
    .ow-main .side-title .ow-st:hover{color:#217346;}
    /* секция полностью скрыта: тонкая полоска с «▸» (как свёрнутая группа строк) */
    .ow-main .side-title.ow-off{padding:2px 4px 2px 8px !important; font-size:10px !important; line-height:14px !important; background:#f2f4f7 !important; color:#98a2b3 !important; letter-spacing:0 !important; text-transform:none !important; border-bottom:1px solid #e0e4ea !important;}
    .ow-main .side-title.ow-off .ow-sttxt{display:none;}
    /* ---------- Excel-сетка позади всего содержимого ---------- */
    /* z-index:-1: поверх фона .ow-main, но ПОД всем контентом
       (в т.ч. статическими блоками, которые иначе накрывались бы) */
    .ow-grid{position:absolute; top:0; left:0; width:100%; height:100%; z-index:-1; pointer-events:none; font-family:Tahoma,Verdana,Arial,sans-serif; user-select:none;}
    .ow-gcorner{position:absolute; top:0; left:0; width:34px; height:13px; background:#f5f5f5; border-right:1px solid #d4d4d4; border-bottom:1px solid #d4d4d4;}
    .ow-gcols{position:absolute; top:0; left:34px; right:0; height:13px; background:#f5f5f5; border-bottom:1px solid #d4d4d4; display:flex; overflow:hidden;}
    .ow-gcols span{flex:none; width:34px; border-right:1px solid #e6e6e6; text-align:center; line-height:12px; font-size:9px; color:#666;}
    .ow-grows{position:absolute; top:13px; left:0; width:34px; bottom:0; background:#f5f5f5; border-right:1px solid #d4d4d4;}
    .ow-grows span{display:block; height:13px; line-height:12px; text-align:center; font-size:9px; color:#666; border-bottom:1px solid #e6e6e6;}
    .ow-garea{position:absolute; top:13px; left:34px; right:0; bottom:0; background-color:#fff;
      background-image:linear-gradient(to right,#e8e8e8 1px,transparent 1px),linear-gradient(to bottom,#e8e8e8 1px,transparent 1px);
      background-size:34px 13px;}
    /* выбранная ячейка A1 — зелёная рамка + «ручка» заполнения */
    .ow-sel{position:absolute; top:13px; left:34px; width:34px; height:13px; border:1px solid #107C41;}
    .ow-sel::after{content:''; position:absolute; right:-4px; bottom:-4px; width:6px; height:6px; background:#107C41;}
    /* ---------- панели (журнал/чат/участники) — строки-ячейки с номерами ---------- */
    .ow-main .side-panel{background:#fff; padding:0 !important; counter-reset:owrow; border-top:1px solid #e0e4ea;}
    .ow-main .side-panel > *{counter-increment:owrow; position:relative; border-bottom:1px solid #eef1f5; padding:3px 8px 3px 38px !important; font-family:Tahoma,Arial,sans-serif; font-size:12px; line-height:1.4; word-break:break-word;}
    .ow-main .side-panel > *::before{content:counter(owrow); position:absolute; left:0; top:3px; width:30px; text-align:center; font-size:10px; line-height:16px; color:#a7afbb; border-right:1px solid #eef1f5; background:#fafbfc;}
    /* ---------- поле ввода чата — как ячейка ---------- */
    .ow-main #chat-box{background:#f7f9fb; border-top:1px solid #d9d9d9;}
    .ow-main #chat-in{border:1px solid #b9c2cd !important; border-radius:0 !important; background:#fff !important; font-family:Tahoma,Arial,sans-serif !important; font-size:12px; box-shadow:none !important;}
    .ow-main #chat-in:focus{border-color:#217346 !important;}
    /* ---------- баннер-уведомление — текст без рамки ---------- */
    .ow-main #banner{font-family:Tahoma,'Segoe UI',Arial,sans-serif !important; background:transparent !important; border:0 !important; box-shadow:none !important;}
    /* ---------- плоское Excel-оформление: без скруглений и теней ---------- */
    .ow-main *{border-radius:0 !important; box-shadow:none !important;}
    .ow-main .side-panel > *{line-height:16px !important;}
    .ow-main .side-title .ow-st, .ow-main #app > header .ow-st{background:none; border:none; padding:2px 8px; font-size:13px; color:#5f6b7a; cursor:pointer; line-height:1; flex:none;}
    .ow-main .side-title .ow-st:hover, .ow-main #app > header .ow-st:hover{background:#e2f0e8; color:#217346;}
    .ow-main #app > header .ow-st{margin-left:10px;}
    /* «меню выхода» (шапка документа) прячется ПОЛНОСТЬЮ: её строка
       становится обычными ячейками листа (как у панели действий покера);
       возвращает маленькая «▸» в левом верхнем углу области игры */
    .ow-main #app > header.ow-off{display:none !important;}
    /* боковая панель — таблица ровно на 3 колонки листа (3×92=276px),
       строки — ровно 22px как в листе: панель встает в сетку заподлицо */
    @media (min-width:900px){
      .ow-main aside{width:276px !important; min-width:276px !important; max-width:276px !important; background:#fff !important; border-left:1px solid #c9ced6 !important;}
    }
  `;
  document.head.appendChild(style);

  const top = document.createElement('div');
  top.className = 'ow-top';
  // лента: группы с иконками и подписями (1-в-1 по референсу)
  const RB = (lab, rows, big) => '<div class="ow-rb' + (big ? ' ow-rb-lg' : '') + '"><div class="ow-rb-rows">' +
    (Array.isArray(rows) ? rows : [rows]).map(r => '<div class="ow-rb-row">' + r + '</div>').join('') +
    '</div><div class="ow-rb-lab">' + lab + '</div></div>';
  const B = (ic, txt, dd) => '<span class="ow-rb-btn"><span class="ow-rb-ic">' + ic + '</span>' +
    (txt ? '<span>' + txt + '</span>' : '') + (dd ? '<span class="ow-rb-dd">&#9662;</span>' : '') + '</span>';
  const STY = '<span class="ow-sty b"><i></i>Обычный</span><span class="ow-sty o"><i></i>Ультральный</span>' +
    '<span class="ow-sty r"><i></i>Плохой</span><span class="ow-sty g"><i></i>Хороший</span>' +
    '<span class="ow-sty y"><i></i>Ввод</span><span class="ow-sty hot"><i></i>Контрольный</span>' +
    '<span class="ow-sty g"><i></i>Применение</span>';
  top.innerHTML =
    '<div class="ow-title"><span class="ow-xic">X</span><span class="ow-ttext">' + esc(DOC) + ' — Microsoft Excel</span>' +
      '<span class="ow-search"><span class="ow-srch"></span>Поиск</span>' +
      '<span class="ow-tbtns">' +
        '<span class="ow-wbtn" data-ow="hidetop" title="Скрыть меню — ячейки до края окна">&#9662;</span>' +
        '<span class="ow-cloud" title="Синхронизировано">&#9729;</span>' +
        '<span class="ow-wbtn" title="Свернуть">&#8212;</span>' +
        '<span class="ow-wbtn" title="Развернуть">&#9633;</span>' +
        '<span class="ow-wbtn x" title="Закрыть">&#10005;</span>' +
        '<span class="ow-share" title="Общий доступ"><span class="ow-people"></span>Общий доступ</span>' +
      '</span></div>' +
    '<div class="ow-menu"><span class="ow-mtab file">Файл</span><span class="ow-mtab on">Главная</span><span class="ow-mtab">Вставка</span><span class="ow-mtab">Разметка страницы</span><span class="ow-mtab">Формулы</span><span class="ow-mtab">Данные</span><span class="ow-mtab">Рецензирование</span><span class="ow-mtab">Вид</span><span class="ow-mtab">Разработка</span><span class="ow-mtab">Редактирование ОК</span><span class="ow-mtab">Редактирование Мк.</span><span class="ow-mtab">Справка</span></div>' +
    '<div class="ow-ribbon">' +
      RB('Буфер обмена', [B('&#9986;', 'Вырезать', 1), B('&#8992;', 'Копировать', 1), B('&#9998;', 'По образцу', 1)]) +
      RB('Шрифт', [
        '<span class="ow-fontbox">Calibri <span class="ow-rb-dd">&#9662;</span></span><span class="ow-fontbox small">11 <span class="ow-rb-dd">&#9662;</span></span>' +
        '<span class="ow-rb-btn"><span class="ow-rb-ic ow-ab">Ж</span></span><span class="ow-rb-btn"><span class="ow-rb-ic ow-ai">К</span></span><span class="ow-rb-btn"><span class="ow-rb-ic ow-au">Ч</span></span><span class="ow-rb-btn"><span class="ow-rb-ic ow-as">S</span></span>',
        '<span class="ow-rb-btn"><span class="ow-rb-ic ow-ar">A</span><span class="ow-rb-dd">&#9662;</span></span><span class="ow-rb-btn"><span class="ow-rb-ic ow-ahl">A</span><span class="ow-rb-dd">&#9662;</span></span><span class="ow-rb-btn"><span class="ow-rb-ic">&#8862;</span><span class="ow-rb-dd">&#9662;</span></span><span class="ow-rb-btn"><span class="ow-rb-ic">&#9642;</span><span class="ow-rb-dd">&#9662;</span></span>'
      ]) +
      RB('Выравнивание', [
        '<span class="ow-rb-btn"><span class="ow-al"><i></i><i></i><i></i></span></span><span class="ow-rb-btn"><span class="ow-al c"><i></i><i></i><i></i></span></span><span class="ow-rb-btn"><span class="ow-al r"><i></i><i></i><i></i></span></span><span class="ow-rb-btn"><span class="ow-al j"><i></i><i></i><i></i></span></span>',
        B('&#8862;', 'Объединить и поместить в центре', 1) + B('&#8617;', 'Перенос', 0) + B('&#8635;', '', 0)
      ]) +
      RB('Число', [
        '<span class="ow-fontbox">Общий <span class="ow-rb-dd">&#9662;</span></span>',
        '<span class="ow-rb-btn"><span class="ow-rb-ic" style="font-size:8px">1 000</span></span><span class="ow-rb-btn"><span class="ow-rb-ic">%</span></span><span class="ow-rb-btn"><span class="ow-rb-ic">&#8381;</span></span><span class="ow-rb-btn"><span class="ow-rb-ic" style="font-size:8px">00</span></span><span class="ow-rb-btn"><span class="ow-rb-ic" style="font-size:8px">000</span></span>'
      ]) +
      '<div class="ow-rb"><div class="ow-rb-rows" style="flex-direction:row; gap:6px; align-items:center;">' +
        '<div style="display:flex; flex-direction:column; gap:2px;">' + B('&#8862;', 'Условное', 1) + B('&#9638;', 'Таблица', 1) + '</div>' +
        '<div class="ow-stys">' + STY + '</div>' +
      '</div><div class="ow-rb-lab">Стили</div></div>' +
      RB('Ячейки', [B('&#10066;', 'Вставить', 1), B('&#10012;', 'Удалить', 1), B('&#9881;', 'Формат', 1)]) +
      '<div class="ow-rb"><div class="ow-rb-rows" style="flex-direction:row; gap:6px; align-items:center;">' +
        '<div style="display:flex; flex-direction:column; gap:2px;">' + B('&#931;', 'Автосумма', 1) + B('&#9636;', 'Заполнить', 1) + B('&#8986;', 'Очистить', 1) + '</div>' +
        '<div style="display:flex; flex-direction:column; gap:2px;">' + B('&#8645;', 'Сортировка', 1) + B('&#8981;', 'Найти и выделить', 1) + '</div>' +
      '</div><div class="ow-rb-lab">Редактирование</div></div>' +
    '</div>' +
    '<div class="ow-fbar"><span class="ow-fcell" id="ow-cell-ref">' + esc(CELL) + '</span><span class="ow-fx">fx</span><input class="ow-fval ow-formula" id="ow-formula" value="' + esc(F) + '" spellcheck="false" aria-label="Строка формул"></div>';

  const main = document.createElement('div');
  main.className = 'ow-main' + (cfg.flow ? ' ow-flow' : '');

  // ---- Excel-сетка: буквы столбцов A.., номера строк 1.., линии ячеек ----
  const COLW = 34, ROWH = 13, HEADW = 34, HEADH = 13;
  const colName = n => { let s = ''; for (n = n + 1; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + (n - 1) % 26) + s; return s; };
  let colsHtml = '';
  for (let c = 0; c < Math.max(10, Math.ceil((window.innerWidth - HEADW) / COLW) + 3); c++) colsHtml += '<span>' + colName(c) + '</span>';
  let rowsHtml = '';
  for (let r = 1; r <= Math.max(12, Math.ceil(window.innerHeight / ROWH) + 4); r++) rowsHtml += '<span>' + r + '</span>';
  const grid = document.createElement('div');
  grid.className = 'ow-grid';
  grid.setAttribute('aria-hidden', 'true');
  grid.innerHTML =
    '<div class="ow-gcorner"></div>' +
    '<div class="ow-gcols">' + colsHtml + '</div>' +
    '<div class="ow-grows">' + rowsHtml + '</div>' +
    '<div class="ow-garea"></div>' +
    '<div class="ow-sel"></div>';
  main.appendChild(grid);

  const self = document.currentScript;
  const children = Array.from(document.body.children);
  for (const ch of children) if (ch !== self) main.appendChild(ch);

  const tabs = document.createElement('div');
  tabs.className = 'ow-tabs';
  tabs.innerHTML = '<span class="ow-tab">Лист1</span>' +
    TABS.map((t, i) => '<span class="ow-tab' + (i === 0 ? ' on' : '') + '">' + esc(t) + '</span>').join('') +
    '<span class="ow-tplus">+</span>';

  // фейковый горизонтальный скроллбар (между вкладками и статус-баром)
  const hscroll = document.createElement('div');
  hscroll.className = 'ow-hscroll';
  hscroll.setAttribute('aria-hidden', 'true');
  hscroll.innerHTML = '<span class="arr l">&#9664;</span><span class="track"></span><span class="thumb"></span><span class="arr r">&#9654;</span>';

  const status = document.createElement('div');
  status.className = 'ow-status';
  status.innerHTML =
    '<span class="ow-sleft"><span id="ow-ready">Готово</span>' +
      '<span title="Специальные возможности">&#9881; Специальные возможности: все в порядке</span>' +
      '<button class="ow-edit-toggle" type="button" title="Ввод значений в ячейки (вкл/выкл)">Правка ячеек: выкл</button></span>' +
    '<span class="ow-sright"><span class="ow-view on" title="Обычный режим">&#9638;</span><span class="ow-view" title="Режим размеченной страницы">&#9636;</span><span class="ow-view" title="Черновой режим">&#9675;</span><span>100%</span></span>';

  document.body.insertBefore(main, children.length ? null : document.body.firstChild);
  document.body.insertBefore(top, main);
  document.body.appendChild(tabs);
  document.body.appendChild(hscroll);
  document.body.appendChild(status);

  // на прокручиваемых страницах (лобби) сетка покрывает всё содержимое;
  // пересчёт нужен и при скрытии верхнего меню — область листа становится
  // выше, иначе номера строк и линии обрывались
  const rowsEl = grid.querySelector('.ow-grows');
  function sizeGrid() {
    const hgt = Math.max(main.clientHeight, main.scrollHeight);
    grid.style.height = hgt + 'px';
    const need = Math.max(12, Math.ceil(hgt / ROWH));
    if (rowsEl.children.length !== need) {
      let html = '';
      for (let r = 1; r <= need; r++) html += '<span>' + r + '</span>';
      rowsEl.innerHTML = html;
    }
  }
  requestAnimationFrame(sizeGrid);
  window.addEventListener('resize', sizeGrid);

  // ---------- панель действий покера (#actions: фишки, чек, рейз, таймер) ----------
  // «▾» в правом верхнем углу панели прячет её полностью: её строки
  // (≈3–4 ряда) становятся обычными пустыми ячейками, как строки 1–2.
  // Маленькая «▴» в левом нижнем углу возвращает панель.
  let placeARest = null;
  const actions = document.querySelector('#actions');
  if (actions) {
    actions.style.position = 'relative';
    const aBtn = document.createElement('span');
    aBtn.className = 'ow-tminus';
    aBtn.textContent = '\u25BE';
    aBtn.title = 'Скрыть панель действий — сделать ячейки';
    aBtn.style.cssText = 'position:absolute; right:4px; top:4px;';
    actions.appendChild(aBtn);
    const aRest = document.createElement('div');
    aRest.className = 'ow-rest';
    aRest.id = 'ow-act-rest';
    aRest.textContent = '\u25B4';
    aRest.title = 'Показать панель действий';
    document.body.appendChild(aRest);
    placeARest = function () {
      aRest.style.left = '2px';
      aRest.style.right = 'auto';
      // над строкой вкладок (вкладки 22 + скроллбар 14 + статус 22 = 58px)
      aRest.style.bottom = '60px';
    };
    function setActOff(off) {
      actions.style.display = off ? 'none' : '';
      aRest.style.display = off ? 'block' : 'none';
      if (off) placeARest();
    }
    aBtn.addEventListener('click', e => { e.stopPropagation(); setActOff(true); });
    aRest.addEventListener('click', () => setActOff(false));
  }

  // ---------- скрытие верхнего меню ----------
  // «▾» в заголовке — прячет .ow-top целиком (заголовок + меню + лента +
  // строка формул): ячейки доходят до верхнего края окна.
  // Маленькая кнопка «▾» в левом верхнем углу возвращает меню обратно.
  const topRest = document.createElement('div');
  topRest.className = 'ow-rest'; topRest.id = 'ow-top-rest'; topRest.textContent = '▾';
  topRest.title = 'Показать меню';
  document.body.appendChild(topRest);
  function setTopOff(off) {
    top.classList.toggle('ow-off', off);
    topRest.style.display = off ? 'block' : 'none';
    requestAnimationFrame(sizeGrid);
  }
  topRest.addEventListener('click', () => setTopOff(false));

  // «автосохранение» в фоне: статус-бар периодически пишет «Сохранение…»
  setInterval(() => { readyFlash('Сохранение…', 1400); }, 45000);

  // ---------- редактируемые Excel-подобные ячейки ----------
  const storageKey = 'yamz_excel_cells_' + DOC;
  let cells = {};
  try { cells = JSON.parse(localStorage.getItem(storageKey) || '{}') || {}; } catch (_) { cells = {}; }
  let selected = CELL;
  let editMode = false;
  const colToNum = s => { let n = 0; for (const ch of String(s).toUpperCase()) n = n * 26 + ch.charCodeAt(0) - 64; return n; };
  const numToCol = n => { let s = ''; for (; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + (n - 1) % 26) + s; return s; };
  const parseRef = ref => { const m = /^([A-Z]+)([1-9][0-9]*)$/i.exec(String(ref).trim()); return m ? { c: colToNum(m[1]), r: +m[2] } : null; };
  const refOf = el => el && (el.dataset.cell || el.getAttribute('data-cell'));
  function valueOf(ref, stack) {
    const raw = Object.prototype.hasOwnProperty.call(cells, ref) ? cells[ref] : '';
    if (typeof raw !== 'string' || raw[0] !== '=') return raw;
    const seen = stack || [];
    if (seen.includes(ref)) return '#ЦИКЛ!';
    try {
      const source = raw.slice(1).trim();
      const sum = source.match(/^(?:СУММ|SUM)\\(([^)]+)\\)$/i);
      const avg = source.match(/^(?:СРЗНАЧ|AVERAGE)\\(([^)]+)\\)$/i);
      if (sum || avg) {
        const range = (sum || avg)[1].split(':');
        const a = parseRef(range[0]), b = parseRef(range[1] || range[0]);
        if (!a || !b) return '#ИМЯ?';
        const vals = [];
        for (let r = Math.min(a.r,b.r); r <= Math.max(a.r,b.r); r++) for (let c = Math.min(a.c,b.c); c <= Math.max(a.c,b.c); c++) {
          const v = Number(valueOf(numToCol(c) + r, seen.concat(ref))); if (Number.isFinite(v)) vals.push(v);
        }
        return avg ? (vals.length ? vals.reduce((x,y)=>x+y,0)/vals.length : 0) : vals.reduce((x,y)=>x+y,0);
      }
      const formula = source.replace(/([A-Z]+[1-9][0-9]*)/gi, m => JSON.stringify(valueOf(m.toUpperCase(), seen.concat(ref))));
      if (!/^[0-9+*/().\s-]+$/.test(formula)) return raw;
      return Function('return (' + formula + ')')();
    } catch (_) { return '#ЗНАЧ!'; }
  }
  function persist() { localStorage.setItem(storageKey, JSON.stringify(cells)); }
  function paintCell(el, ref) {
    if (!el) return;
    const raw = Object.prototype.hasOwnProperty.call(cells, ref) ? cells[ref] : '';
    el.dataset.cell = ref;
    el.title = ref + (raw ? ': ' + raw : '');
    if (!el.querySelector('.ow-cell-input')) el.textContent = raw ? String(valueOf(ref)) : '';
    el.classList.toggle('ow-cell-edit', ref === selected && editMode);
  }
  function selectCell(el) {
    const ref = refOf(el); if (!ref) return;
    selected = ref;
    const raw = Object.prototype.hasOwnProperty.call(cells, ref) ? cells[ref] : '';
    const refEl = document.getElementById('ow-cell-ref'), formulaEl = document.getElementById('ow-formula');
    if (refEl) refEl.textContent = ref;
    if (formulaEl) formulaEl.value = raw;
    document.querySelectorAll('.ow-cell-edit').forEach(x => x.classList.remove('ow-cell-edit'));
    if (editMode) el.classList.add('ow-cell-edit');
  }
  function commitCell(el, raw) {
    const ref = refOf(el); if (!ref) return;
    cells[ref] = String(raw);
    if (!cells[ref]) delete cells[ref];
    persist();
    document.querySelectorAll('[data-cell="' + ref + '"]').forEach(x => paintCell(x, ref));
    if (typeof refreshEditGrid === 'function') refreshEditGrid();
    selectCell(el);
    readyFlash('Изменения сохранены', 900);
  }
  function beginEdit(el) {
    const ref = refOf(el); if (!ref || el.querySelector('.ow-cell-input')) return;
    editMode = true; selectCell(el);
    const input = document.createElement('input'); input.className = 'ow-cell-input'; input.value = Object.prototype.hasOwnProperty.call(cells, ref) ? cells[ref] : '';
    el.textContent = ''; el.appendChild(input); el.classList.add('ow-cell-edit'); input.focus(); input.select();
    const finish = save => { if (save) commitCell(el, input.value); else paintCell(el, ref); };
    input.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); finish(true); } else if (e.key === 'Escape') { e.preventDefault(); finish(false); } else if (e.key === 'Tab') { e.preventDefault(); finish(true); const next = el.nextElementSibling; if (next && next.dataset.cell) beginEdit(next); } });
    input.addEventListener('blur', () => { if (el.contains(input)) finish(true); }, { once:true });
  }
  function makeCell(el, ref) {
    if (!el || el.dataset.cell) return;
    el.dataset.cell = ref; paintCell(el, ref);
    el.addEventListener('click', () => selectCell(el));
    el.addEventListener('dblclick', () => beginEdit(el));
  }
  // Редактируем только отдельный слой листа, не трогая игровые DOM-блоки.
  const editGrid = document.createElement('div');
  editGrid.className = 'ow-edit-grid';
  const editCells = {};
  for (let r = 1; r <= 80; r++) for (let c = 1; c <= 40; c++) {
    const ref = numToCol(c) + r;
    const el = document.createElement('div'); el.className = 'ow-edit-cell'; el.dataset.cell = ref; el.textContent = valueOf(ref);
    editCells[ref] = el; editGrid.appendChild(el);
    el.addEventListener('click', () => { selected = ref; Object.values(editCells).forEach(x => x.classList.remove('selected')); el.classList.add('selected'); if (formulaEl) formulaEl.value = cells[ref] || ''; });
    el.addEventListener('dblclick', () => beginEdit(el));
  }
  main.appendChild(editGrid);
  function refreshEditGrid() { Object.keys(editCells).forEach(ref => { const el = editCells[ref], raw = cells[ref] || ''; el.textContent = valueOf(ref); el.classList.toggle('has-value', !!raw); el.classList.toggle('selected', ref === selected); }); }
  refreshEditGrid();
  const formulaEl = document.getElementById('ow-formula');
  if (formulaEl) { formulaEl.addEventListener('keydown', e => { if (e.key === 'Enter') { cells[selected] = formulaEl.value; if (!cells[selected]) delete cells[selected]; persist(); refreshEditGrid(); readyFlash('Изменения сохранены', 900); } }); }
  const editToggle = document.querySelector('.ow-edit-toggle');
  if (editToggle) editToggle.addEventListener('click', () => { editMode = !editMode; editGrid.classList.toggle('on', editMode); editToggle.textContent = editMode ? 'Правка ячеек: вкл' : 'Правка ячеек: выкл'; });

  function readyFlash(text, ms) {
    const r = document.getElementById('ow-ready');
    if (!r) return;
    r.textContent = text;
    setTimeout(() => { r.textContent = 'Готово'; }, ms || 1000);
  }

  top.addEventListener('click', e => {
    const b = e.target.closest ? e.target.closest('[data-ow]') : null;
    if (b) {
      const a = b.getAttribute('data-ow');
      if (a === 'save') readyFlash('Сохранение…', 900);
      else if (a === 'print') readyFlash('Печать: отправка в очередь…', 1600);
      else if (a === 'hidetop') setTopOff(true);
    }
    const w = e.target.closest ? e.target.closest('.ow-wbtn') : null;
    if (w && w.title === 'Закрыть' && window.YAMZ_PANIC && typeof window.YAMZ_PANIC.show === 'function') {
      try { window.YAMZ_PANIC.show(); } catch (err) { /* ignore */ }
    }
  });

  tabs.addEventListener('click', e => {
    const t = e.target.closest ? e.target.closest('.ow-tab') : null;
    if (!t) return;
    tabs.querySelectorAll('.ow-tab').forEach(x => x.classList.toggle('on', x === t));
  });

  // ---------- журнал / комментарии / участники — внизу, как вкладки Excel ----------
  // Правая панель переезжает вниз: клик по вкладке открывает строку-панель
  // (5 строк листа), клик по той же вкладке закрывает. Игра при этом
  // поднимается на высоту панели, чтобы ничего не закрывалось.
  (function () {
    const aside = document.querySelector('.ow-main aside');
    if (!aside) return;
    const sections = [];
    let cur = null;
    for (const el of Array.from(aside.children)) {
      if (el.classList.contains('side-title')) {
        if (cur) sections.push(cur);
        cur = { name: el.textContent.trim(), nodes: [] };
      } else if (cur) cur.nodes.push(el);
    }
    if (cur) sections.push(cur);
    if (!sections.length) return;
    aside.style.display = 'none';

    const bottom = document.createElement('div');
    bottom.className = 'ow-bottom';
    const short = h => /журн/i.test(h) ? 'Журнал' : (/коммент/i.test(h) ? 'Комментарии' : (/участник/i.test(h) ? 'Участники' : h));
    sections.forEach(sec => {
      sec.short = short(sec.name);
      const box = document.createElement('div');
      box.className = 'ow-bsec';
      box.dataset.name = sec.short;
      box.style.display = 'none';
      const head = document.createElement('div');
      head.className = 'side-title';
      head.textContent = sec.name;
      box.appendChild(head);
      sec.nodes.forEach(n => box.appendChild(n));
      bottom.appendChild(box);
    });
    main.appendChild(bottom);

    const tabsEl = document.querySelector('.ow-tabs');
    const addTab = tabsEl.querySelector('.ow-tabadd');
    let openName = null;
    function toggle(name, tab) {
      const closing = openName === name;
      bottom.querySelectorAll('.ow-bsec').forEach(s => s.style.display = 'none');
      tabsEl.querySelectorAll('.ow-tab.ow-open').forEach(x => x.classList.remove('ow-open'));
      if (closing) {
        openName = null;
        bottom.classList.remove('on');
        main.style.setProperty('--ow-bottom-h', '0px');
      } else {
        const sec = bottom.querySelector('.ow-bsec[data-name="' + name + '"]');
        if (!sec) return;
        sec.style.display = 'flex';
        openName = name;
        tab.classList.add('ow-open');
        bottom.classList.add('on');
        main.style.setProperty('--ow-bottom-h', '110px');
        if (/коммент/i.test(name)) {
          const inp = sec.querySelector('#chat-in');
          if (inp) setTimeout(() => { try { inp.focus(); } catch (e) {} }, 120);
        }
      }
    }
    sections.forEach(sec => {
      const name = sec.short;
      let tab = Array.from(tabsEl.querySelectorAll('.ow-tab')).find(x => x.textContent.trim() === name);
      if (!tab) {
        tab = document.createElement('span');
        tab.className = 'ow-tab';
        tab.textContent = name;
        tabsEl.insertBefore(tab, addTab);
      }
      tab.addEventListener('click', () => toggle(name, tab));
    });
  })();

  // Панель эмодзи: чат живёт в нижней полосе, поэтому панель показываем
  // НАД кнопкой 😀 (fixed, позиция вычисляется по rect кнопки после клика).
  // Capture-слушатель + setTimeout(0): сработает после собственных
  // обработчиков страницы, какие бы они ни были.
  document.addEventListener('click', e => {
    const b = e.target && e.target.closest ? e.target.closest('#chat-emoji-btn') : null;
    if (!b) return;
    setTimeout(() => {
      const box = b.closest('#chat-box');
      const p = box ? box.querySelector('#chat-emoji') : null;
      if (!p || p.classList.contains('hidden')) return;
      const r = b.getBoundingClientRect();
      const pw = p.offsetWidth || 320, ph = p.offsetHeight || 160;
      p.style.left = Math.max(6, Math.min(r.left, window.innerWidth - pw - 6)) + 'px';
      p.style.top = Math.max(6, r.top - ph - 6) + 'px';
    }, 0);
  }, true);

  // «меню выхода» — шапка документа (#app > header): «▾» прячет её
  // ПОЛНОСТЬЮ (название, «Каталог», кнопки «Закрыть/Назад», статус) —
  // её строка становится обычными ячейками листа; маленькая «▸» в
  // левом верхнем углу области игры возвращает шапку. Только на своём экране.
  const h = document.querySelector('.ow-main #app > header');
  if (h && !h.querySelector('.ow-st')) {
    let hRest = null;
    const appEl = h.parentElement;
    if (appEl) {
      hRest = document.createElement('div');
      hRest.className = 'ow-rest';
      hRest.id = 'ow-hdr-rest';
      hRest.textContent = '▸';
      hRest.title = 'Показать шапку';
      hRest.style.cssText = 'position:absolute; top:2px; left:2px;';
      appEl.appendChild(hRest);
    }
    const hb = document.createElement('button');
    hb.type = 'button';
    hb.className = 'ow-st';
    hb.textContent = '▾';
    hb.title = 'Скрыть шапку полностью — сделать ячейки (только на вашем экране)';
    h.appendChild(hb);
    const setHdrOff = off => {
      h.classList.toggle('ow-off', off);
      hb.textContent = off ? '▸' : '▾';
      if (hRest) hRest.style.display = off ? 'block' : 'none';
    };
    hb.addEventListener('click', e => {
      e.stopPropagation();
      setHdrOff(!h.classList.contains('ow-off'));
    });
    if (hRest) hRest.addEventListener('click', e => { e.stopPropagation(); setHdrOff(false); });
  }

  // Общая кнопка правого поля: скрывает журнал, чат и участников одним кликом.
  const side = document.querySelector('.ow-main #app > #main > aside, .ow-main aside');
  if (side && !side.querySelector('.ow-side-toggle')) {
    const sb = document.createElement('button');
    sb.type = 'button';
    sb.className = 'ow-side-toggle';
    sb.textContent = '◀';
    sb.title = 'Скрыть правое поле целиком';
    side.insertBefore(sb, side.firstChild);
    sb.addEventListener('click', e => {
      e.stopPropagation();
      const off = side.classList.toggle('ow-side-off');
      sb.textContent = off ? '▶' : '◀';
      sb.title = off ? 'Показать правое поле' : 'Скрыть правое поле целиком';
    });
  }

  // Автоматически превращаем основные текстовые прямоугольники в ячейки.
  document.querySelectorAll('.ow-main #banner, .ow-main .plate, .ow-main .badge, .ow-main .seat, .ow-main .p-card, .ow-main .crow, .ow-main .pm-box, .ow-main .mbox, .ow-main .join-box').forEach(el => el.classList.add('ow-cell'));

  // сворачивание секций боковой панели (журнал/комментарии/участники):
  // «▾» прячет раздел ПОЛНОСТЬЮ (включая заголовок и поле ввода) только на
  // СВОЁМ экране — остаётся тонкая полоска с «▸» (свёрнутая группа строк).
  document.querySelectorAll('.side-title').forEach(t => {
    if (t.querySelector('.ow-st')) return;
    for (const n of Array.from(t.childNodes)) {
      if (n.nodeType === 3 && n.textContent.trim()) {
        const s = document.createElement('span');
        s.className = 'ow-sttxt';
        n.replaceWith(s);
        s.appendChild(n);
      }
    }
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'ow-st';
    b.textContent = '▾';
    b.title = 'Скрыть раздел полностью (только на вашем экране)';
    t.appendChild(b);
    b.addEventListener('click', e => {
      e.stopPropagation();
      const off = !t.classList.contains('ow-off');
      t.classList.toggle('ow-off', off);
      let el = t.nextElementSibling;
      while (el && !el.classList.contains('side-title')) {
        el.style.display = off ? 'none' : '';
        el = el.nextElementSibling;
      }
      b.textContent = off ? '▸' : '▾';
    });
  });
})();
