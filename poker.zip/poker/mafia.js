// 🕵️ Мафия — серверная логика (host-authoritative), подключается к serve.js.
// 6–9 игроков. Ночью: мафия выбирает жертву (голоса мафии), врач лечит,
// следователь проверяет (приватный ответ). Днём: обсуждение (чат) + голосование —
// исключённого выводят с открытием роли. Победа: город вырезал всю мафию
// ИЛИ мафия стала не меньше города. Мёртвые остаются в игре как наблюдатели (чат).
// WebSocket /ws-mafia, JSON. Только встроенные модули Node.
'use strict';
const crypto = require('crypto');
const champ = require('./championship'); // 🏆 «Чемпионат ЯМЗ»

const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_P = 9, MIN_P = 6;
const NIGHT_MS = 45000;
const DAY_MS = 90000;
const VOTE_MS = 45000;
const GONE_HARD_MS = 10 * 60000; // во время партии
const GRACE_MS = 60000;          // между партиями

const ROLE_NAME = { mafia: 'Мафия', doctor: 'Врач', detective: 'Следователь', citizen: 'Мирный' };
const ROLE_ICON = { mafia: '🔪', doctor: '🩺', detective: '🔍', citizen: '🧑' };

let idc = 0;
const st = {
  phase: 'waiting', // waiting | night | day | over
  dayStage: null,   // discuss | vote (когда phase === 'day')
  slots: [null, null, null, null, null, null, null, null, null],
  hostId: null,
  nightNo: 0,
  dayNo: 0,
  winner: null, // 'town' | 'mafia'
  winMsg: null,
  deadline: 0,
  phaseTimer: null,
  night: null, // { kill:{id:targetId|null}, heal:{id:targetId|null}|null, check:{id:targetId|null}|null }
  votes: null, // {id: targetId|null} — при dayStage==='vote'
  lastTally: null, // {counts:{name:n}, outcast:{name, role}|null} — для клиента после подсчёта
  logs: [],
  chat: [],
};

// ---------- утилиты ----------
function log(msg) {
  st.logs.push({ t: msg, ts: Date.now() });
  if (st.logs.length > 80) st.logs.shift();
  console.log('[Мафия] ' + msg);
}
function players() { return st.slots.filter(Boolean); }
function alivePlayers() { return players().filter(p => p.alive); }
function playerById(id) { return players().find(p => p.id === id) || null; }
function send(p, obj) {
  if (p && p.ws) { try { p.ws.write(wsFrame(0x1, Buffer.from(JSON.stringify(obj), 'utf8'))); } catch (e) {} }
}
function broadcast() { for (const p of players()) send(p, stateFor(p)); }
function sendRaw(conn, obj) {
  if (conn.player && conn.player.ws === conn.sock) send(conn.player, obj);
  else { try { conn.sock.write(wsFrame(0x1, Buffer.from(JSON.stringify(obj), 'utf8'))); } catch (e) {} }
}
function clearTimeoutPhase() { if (st.phaseTimer) { clearTimeout(st.phaseTimer); st.phaseTimer = null; } }

// набор ролей по числу игроков
function roleSet(n) {
  const mafia = n <= 6 ? 1 : n <= 8 ? 2 : 3;
  const arr = new Array(mafia).fill('mafia').concat(['doctor', 'detective']);
  while (arr.length < n) arr.push('citizen');
  for (let i = arr.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [arr[i], arr[j]] = [arr[j], arr[i]]; }
  return arr;
}

// ---------- игроки ----------
function join(sock, name, pid, uid) {
  name = String(name || '').trim().slice(0, 20) || 'Игрок';
  let ex = null;
  if (pid) ex = playerById(pid);
  if (!ex) ex = players().find(p => p.name === name && !p.connected && !p.isBot) || null;
  if (ex) {
    if (ex.ws && ex.ws !== sock) { try { ex.ws.destroy(); } catch (e) {} }
    ex.ws = sock; ex.connected = true;
    if (uid) ex.uid = uid;
    if (ex.goneTimer) { clearTimeout(ex.goneTimer); ex.goneTimer = null; }
    log('🔌 ' + ex.name + ' снова в игре');
    send(ex, { t: 'board', min: MIN_P, max: MAX_P, nightMs: NIGHT_MS, dayMs: DAY_MS, voteMs: VOTE_MS });
    if (ex.role) sendRole(ex);
    broadcast();
    return ex;
  }
  if (st.phase !== 'waiting' && st.phase !== 'over') {
    return { err: 'Игра уже идёт — дождитесь конца партии, чтобы сесть' };
  }
  const seat = st.slots.indexOf(null);
  if (seat === -1) return { err: 'Мафия — до 9 игроков: все места заняты' };
  const p = {
    id: 'f' + (++idc), name, seat, ws: sock, uid: uid || null,
    connected: true, isBot: false, alive: true, role: null,
    mem: { checks: [], kills: [], heals: [] },
    botTimer: null, goneTimer: null, wsConn: null,
  };
  st.slots[seat] = p;
  if (!st.hostId) st.hostId = p.id;
  log('🪑 ' + name + ' сел(ась) за стол (' + players().length + '/' + MAX_P + ')');
  broadcast();
  return p;
}

function sitOut(p, why) {
  st.slots[p.seat] = null;
  if (p.ws) { try { p.ws.destroy(); } catch (e) {} }
  if (p.goneTimer) { clearTimeout(p.goneTimer); p.goneTimer = null; }
  if (p.botTimer) { clearTimeout(p.botTimer); p.botTimer = null; }
  log('👋 ' + p.name + (why ? ' — ' + why : ' вышел(ла) из игры'));
  if (p.id === st.hostId) st.hostId = null;
  const seated = players();
  if (st.hostId === null && seated.length) st.hostId = seated[0].id;
  const inRound = st.phase === 'night' || st.phase === 'day';
  if (inRound && p.alive) {
    if (st.night) {
      if (st.night.kill[p.id] !== undefined) delete st.night.kill[p.id];
      if (st.night.heal === p.id) st.night.heal = null;
      if (st.night.check === p.id) st.night.check = null;
    }
    if (st.votes) delete st.votes[p.id];
  }
  if (inRound && seated.length < MIN_P) {
    resetToWaiting('игроков меньше ' + MIN_P + ' — партия сброшена');
  } else if (inRound) {
    if (checkWin()) endGame();
    else {
      if (st.phase === 'night' && p.alive) nightDoneCheck();
      if (st.phase === 'day' && st.dayStage === 'vote' && p.alive) voteDoneCheck();
      broadcast();
    }
  } else {
    broadcast();
  }
  // отключившиеся и не вернувшиеся — освобождаем (рекурсия один уровень)
  for (const q of [...players()]) {
    if (!q.isBot && !q.connected) { log('🗑 ' + q.name + ' — не вернулся, место освобождено'); sitOut(q); return; }
  }
}

function onDisconnect(p) {
  p.connected = false;
  if (p.isBot) return;
  log('🔌 ' + p.name + ' отключился');
  if (p.goneTimer) clearTimeout(p.goneTimer);
  const grace = (st.phase === 'night' || st.phase === 'day') ? GONE_HARD_MS : GRACE_MS;
  p.goneTimer = setTimeout(() => { if (!p.connected) sitOut(p, 'не вернулся вовремя'); }, grace);
  broadcast();
}

// ---------- партии ----------
function resetToWaiting(why) {
  clearTimeoutPhase();
  st.phase = 'waiting'; st.dayStage = null; st.night = null; st.votes = null;
  st.deadline = 0; st.lastTally = null;
  for (const p of players()) { p.alive = true; p.role = null; p.mem = { checks: [], kills: [], heals: [] }; }
  if (why) log('↩ ' + why);
  broadcast();
}

function newGame(initiator) {
  clearTimeoutPhase();
  const ps = players();
  if (ps.length < MIN_P) return 'Нужно минимум ' + MIN_P + ' игроков';
  for (const p of ps) {
    p.alive = true; p.role = null; p.mem = { checks: [], kills: [], heals: [] };
    if (p.botTimer) { clearTimeout(p.botTimer); p.botTimer = null; }
  }
  st.dayStage = null; st.night = null; st.votes = null; st.lastTally = null;
  st.winner = null; st.winMsg = null; st.nightNo = 0; st.dayNo = 0;
  st.logs = []; st.chat = [];
  log('— Партия началась: ' + ps.length + ' игроков —');
  // раздача ролей
  const roles = roleSet(ps.length);
  ps.forEach((p, i) => { p.role = roles[i]; });
  const mafia = ps.filter(p => p.role === 'mafia');
  log('🎭 Роли разданы (мафия: ' + mafia.map(p => p.name).join(', ') + ')');
  for (const p of ps) sendRole(p);
  startNight();
  return null;
}

// приватное: роль + память (проверки/убийства/лечения) + кто в мафии
function sendRole(p) {
  if (!p.role) return;
  const obj = {
    t: 'role', role: p.role, roleRu: ROLE_NAME[p.role], icon: ROLE_ICON[p.role],
    checks: p.mem.checks.slice(), kills: p.mem.kills.slice(), heals: p.mem.heals.slice(),
  };
  if (p.role === 'mafia') {
    obj.mafia = players().filter(q => q.role === 'mafia').map(q => q.id);
  }
  send(p, obj);
}

// ---------- НОЧЬ ----------
function startNight() {
  clearTimeoutPhase();
  st.phase = 'night'; st.dayStage = null;
  st.nightNo++;
  st.night = { kill: {}, heal: null, check: null };
  st.deadline = Date.now() + NIGHT_MS;
  log('🌙 Ночь ' + st.nightNo + ': мафия, врач и следователь действуют…');
  st.phaseTimer = setTimeout(() => { resolveNight(true); }, NIGHT_MS);
  broadcast();
  for (const p of alivePlayers()) {
    if (p.isBot) scheduleNightBot(p);
    else if (p.role !== 'citizen') send(p, { t: 'nightTask', role: p.role, night: st.nightNo });
  }
}

function nightAct(p, kind, targetId) {
  if (st.phase !== 'night') return 'Сейчас не ночь';
  if (!p.alive) return 'Вы в игре больше не участвуете';
  const roleFor = { kill: 'mafia', heal: 'doctor', check: 'detective' }[kind];
  if (p.role !== roleFor) return 'Это действие не для вашей роли';
  let target = null;
  if (targetId !== null && targetId !== undefined && targetId !== '') {
    target = playerById(String(targetId));
    if (!target) return 'Такого игрока нет';
    if (!target.alive) return 'Этот игрок уже мёртв';
    if (kind === 'kill' && target.role === 'mafia') return 'Мафия не стреляет в своих';
    if (kind === 'check' && target.id === p.id) return 'Себя проверять не нужно';
  }
  const bag = st.night;
  if (kind === 'kill') {
    bag.kill[p.id] = target ? target.id : null;
    p.mem.kills.push({ night: st.nightNo, name: target ? target.name : '—' });
    send(p, { t: 'whisper', msg: target ? ('🔪 Ваша цель на эту ночь: ' + target.name) : '🔪 Вы решили не убивать эту ночь' });
  } else if (kind === 'heal') {
    bag.heal = target ? target.id : null;
    bag.healDone = true;
    p.mem.heals.push({ night: st.nightNo, name: target ? target.name : '—' });
    send(p, { t: 'whisper', msg: target ? ('🩺 Вы охраняете: ' + target.name) : '🩺 Вы пропускаете ночь' });
  } else {
    bag.check = target ? target.id : null;
    bag.checkDone = true;
    send(p, { t: 'whisper', msg: target ? ('🔍 Проверяете: ' + target.name + '…') : '🔍 Вы пропускаете проверку' });
  }
  nightDoneCheck();
  broadcast();
  return null;
}

// ночь заканчивается, когда все живые «спецы» сделали выбор (или по таймеру)
function nightDoneCheck() {
  if (st.phase !== 'night') return;
  const bag = st.night;
  const alive = alivePlayers();
  const mafiaOk = alive.filter(p => p.role === 'mafia').every(p => bag.kill[p.id] !== undefined);
  const docOk = !alive.some(p => p.role === 'doctor') || !!bag.healDone;
  const detOk = !alive.some(p => p.role === 'detective') || !!bag.checkDone;
  if (mafiaOk && docOk && detOk) resolveNight(false);
}

function resolveNight(byTimeout) {
  if (st.phase !== 'night') return;
  clearTimeoutPhase();
  const bag = st.night;
  // цель мафии: plurality голосов мафии; ничья/пусто — спокойная ночь
  const tally = {};
  for (const p of alivePlayers()) {
    if (p.role !== 'mafia') continue;
    const t = bag.kill[p.id];
    if (t === undefined) continue;
    if (t === null) continue;
    tally[t] = (tally[t] || 0) + 1;
  }
  let killId = null, best = 0, tie = false;
  for (const [id, n] of Object.entries(tally)) {
    if (n > best) { best = n; killId = id; tie = false; }
    else if (n === best) tie = true;
  }
  if (tie) killId = null;
  let victim = killId ? playerById(killId) : null;
  if (victim && !victim.alive) victim = null;
  // врач
  const healerId = bag.heal;
  const healed = healerId ? playerById(healerId) : null;
  // следователь: приватный ответ
  if (bag.check) {
    const det = players().find(p => p.role === 'detective');
    const target = playerById(bag.check);
    if (det && det.alive && target) {
      const isM = target.role === 'mafia';
      det.mem.checks.push({ night: st.nightNo, name: target.name, mafia: isM });
      send(det, { t: 'whisper', msg: '🔍 Проверка: ' + target.name + ' — ' + (isM ? 'МАФИЯ!' : 'мирный') });
    }
  }
  const prefix = (byTimeout ? '⏰ ' : '') + '🌙 ';
  if (victim) {
    if (healed && healed.id === victim.id) {
      log(prefix + 'Мафия напала на ' + victim.name + ', но врач спас(ла) — ночь спокойная');
    } else {
      victim.alive = false;
      log(prefix + '💀 Ночью погиб(ла) ' + victim.name + ' (роль не разглашается)');
    }
  } else {
    log(prefix + 'Ночь прошла спокойно');
  }
  st.night = null;
  if (!checkWin()) startDay();
  else endGame();
}

// ---------- ДЕНЬ ----------
function startDay() {
  st.phase = 'day'; st.dayStage = 'discuss';
  st.dayNo++;
  st.lastTally = null;
  st.deadline = Date.now() + DAY_MS;
  log('☀️ День ' + st.dayNo + ': обсуждение в чате');
  st.phaseTimer = setTimeout(() => { openVote(true); }, DAY_MS);
  broadcast();
}

function endDiscuss(p) {
  if (st.phase !== 'day' || st.dayStage !== 'discuss') return 'Сейчас не обсуждение';
  if (p.id !== st.hostId) return 'Дальше двигает хост';
  openVote(false);
  return null;
}

function openVote(byTimeout) {
  if (st.phase !== 'day' || st.dayStage !== 'vote') {
    st.dayStage = 'vote';
    st.votes = {};
    st.deadline = Date.now() + VOTE_MS;
    log((byTimeout ? '⏰ ' : '') + '🗳 Голосование: кого изолируем?');
    st.phaseTimer = setTimeout(() => { tallyVotes(true); }, VOTE_MS);
    broadcast();
    for (const p of alivePlayers()) if (p.isBot) scheduleVoteBot(p);
  }
  return null;
}

function vote(p, targetId) {
  if (st.phase !== 'day' || st.dayStage !== 'vote') return 'Сейчас не голосование';
  if (!p.alive) return 'Мёртвые не голосуют';
  if (st.votes[p.id] !== undefined) return 'Вы уже проголосовали';
  let target = null;
  if (targetId !== null && targetId !== undefined && targetId !== '') {
    target = playerById(String(targetId));
    if (!target) return 'Такого игрока нет';
    if (target.id === p.id) return 'За себя голосовать нельзя';
    if (!target.alive) return 'Этот игрок уже мёртв';
  }
  st.votes[p.id] = target ? target.id : null;
  log('🗳 ' + p.name + (target ? ' голосует за ' + target.name : ' воздерживается'));
  voteDoneCheck();
  broadcast();
  return null;
}

function voteDoneCheck() {
  if (st.phase !== 'day' || st.dayStage !== 'vote') return;
  const alive = alivePlayers();
  if (alive.length && alive.every(p => st.votes[p.id] !== undefined)) tallyVotes(false);
}

function tallyVotes(byTimeout) {
  if (st.phase !== 'day' || st.dayStage !== 'vote') return;
  clearTimeoutPhase();
  const counts = {};
  for (const [pid, tid] of Object.entries(st.votes || {})) {
    if (tid === null || tid === undefined) continue;
    const t = playerById(tid);
    if (!t) continue;
    counts[t.name] = (counts[t.name] || 0) + 1;
  }
  let outId = null, best = 0, tie = false;
  for (const [name, n] of Object.entries(counts)) {
    if (n > best) { best = n; outId = name; tie = false; }
    else if (n === best) tie = true;
  }
  if (tie) outId = null;
  const outcast = outId ? players().find(p => p.name === outId && p.alive) : null;
  st.lastTally = { counts, outcast: outcast ? { name: outcast.name, role: ROLE_NAME[outcast.role] } : null };
  log((byTimeout ? '⏰ ' : '') + '📊 Голоса: ' + (Object.keys(counts).length ? Object.entries(counts).map(([n, c]) => n + ' — ' + c).join(', ') : 'нет голосов'));
  if (outcast) {
    outcast.alive = false;
    log('🚪 Исключён(а): ' + outcast.name + ' — роль: ' + (outcast.role === 'mafia' ? '🔪 МАФИЯ' : ROLE_ICON[outcast.role] + ' ' + ROLE_NAME[outcast.role]));
  } else {
    log('🤝 Никто не исключён (ничья или без голосов)');
  }
  st.votes = null; st.dayStage = null;
  if (!checkWin()) startNight();
  else endGame();
}

// ---------- победа ----------
function checkWin() {
  const alive = alivePlayers();
  const mafia = alive.filter(p => p.role === 'mafia').length;
  const town = alive.length - mafia;
  if (mafia <= 0) { st.winner = 'town'; st.winMsg = 'Город вырезал всю мафию 🏆'; }
  else if (mafia >= town) { st.winner = 'mafia'; st.winMsg = 'Мафия заправила городом 🌃'; }
  else return false;
  log('🏁 ' + st.winMsg);
  return true;
}

function endGame() {
  clearTimeoutPhase();
  st.phase = 'over'; st.dayStage = null;
  st.deadline = 0; st.night = null; st.votes = null;
  // 🏆 «Чемпионат ЯМЗ»: победившей стороне очки, проигравшей — сброс серии
  for (const p of players()) {
    if (p.isBot) continue;
    const won = (p.role === 'mafia') === (st.winner === 'mafia');
    if (won) champ.recordWin(p.uid, p.name, 'mafia', champ.POINTS.mafia);
    else champ.recordLoss(p.uid, p.name);
  }
  broadcast();
}

// ---------- боты ----------
function addBot() {
  const seat = st.slots.indexOf(null);
  if (seat === -1) return 'Мест нет (максимум 9)';
  if (st.phase !== 'waiting' && st.phase !== 'over') return 'Бота посадить нельзя во время партии';
  let n = players().filter(p => p.isBot).length + 1;
  let name = 'Бот-' + n;
  while (players().some(p => p.name === name)) name = 'Бот-' + (++n);
  const b = {
    id: 'f' + (++idc), name, seat, ws: null, uid: null,
    connected: true, isBot: true, alive: true, role: null,
    mem: { checks: [], kills: [], heals: [] },
    botTimer: null, goneTimer: null, wsConn: null,
  };
  st.slots[seat] = b;
  log('🤖 ' + name + ' зашёл (' + players().length + '/' + MAX_P + ')');
  broadcast();
  return null;
}

function removeBot(p) {
  const b = players().find(q => q.isBot);
  if (!b) return 'Бота за столом нет';
  if (st.phase === 'night' || st.phase === 'day') return 'Бота нельзя убрать во время партии';
  sitOut(b, 'убран хостом');
  return null;
}

function pickRandom(arr) { return arr.length ? arr[(Math.random() * arr.length) | 0] : null; }

function scheduleNightBot(p) {
  if (p.botTimer) clearTimeout(p.botTimer);
  p.botTimer = setTimeout(() => {
    p.botTimer = null;
    if (st.phase !== 'night' || !p.alive || st.slots[p.seat] !== p) return;
    if (p.role === 'mafia') {
      const target = pickRandom(alivePlayers().filter(q => q.role !== 'mafia'));
      nightAct(p, 'kill', target ? target.id : null);
    } else if (p.role === 'doctor') {
      const target = pickRandom(alivePlayers());
      nightAct(p, 'heal', target ? target.id : null);
    } else if (p.role === 'detective') {
      const known = new Set(p.mem.checks.map(c => c.name));
      const target = pickRandom(alivePlayers().filter(q => q.id !== p.id && !known.has(q.name)))
        || pickRandom(alivePlayers().filter(q => q.id !== p.id));
      nightAct(p, 'check', target ? target.id : null);
    }
  }, 1500 + Math.random() * 2500);
}

function scheduleVoteBot(p) {
  if (p.botTimer) clearTimeout(p.botTimer);
  p.botTimer = setTimeout(() => {
    p.botTimer = null;
    if (st.phase !== 'day' || st.dayStage !== 'vote' || !p.alive || st.slots[p.seat] !== p) return;
    let target = null;
    if (p.role === 'mafia') {
      target = pickRandom(alivePlayers().filter(q => q.role !== 'mafia'));
    } else if (p.role === 'detective') {
      const flagged = pickRandom(alivePlayers().filter(q => p.mem.checks.some(c => c.name === q.name && c.mafia)));
      target = flagged || pickRandom(alivePlayers().filter(q => q.id !== p.id));
    } else {
      target = pickRandom(alivePlayers().filter(q => q.id !== p.id));
    }
    vote(p, target ? target.id : null);
  }, 5000 + Math.random() * 15000);
}

// ---------- состояние для клиента ----------
function stateFor(p) {
  const s = {
    t: 'state',
    phase: st.phase,
    dayStage: st.phase === 'day' ? st.dayStage : null,
    nightNo: st.nightNo,
    dayNo: st.dayNo,
    mySeat: p ? p.seat : -1,
    myId: p ? p.id : null,
    isHost: !!(p && p.id === st.hostId),
    deadline: st.deadline,
    winner: st.winner,
    winMsg: st.winMsg,
    inMafia: !!(p && p.role === 'mafia'),
    voteDone: !!(p && st.dayStage === 'vote' && st.votes && st.votes[p.id] !== undefined),
    lastTally: st.lastTally,
    logs: st.logs.slice(-40),
    chat: st.chat.slice(-25),
    slots: st.slots.map(x => x ? {
      id: x.id, name: x.name, bot: !!x.isBot, connected: x.connected, alive: x.alive,
      role: (st.phase === 'over') ? ROLE_NAME[x.role] : null,
      roleIcon: (st.phase === 'over') ? ROLE_ICON[x.role] : null,
    } : null),
  };
  return s;
}

function mafiaStatus() {
  const inRound = st.phase === 'night' || st.phase === 'day';
  return { players: players().length, phase: st.phase, inGame: inRound, min: MIN_P, max: MAX_P };
}

// ---------- WebSocket (RFC6455, как в покере) ----------
function wsFrame(opcode, payload) {
  const len = payload.length;
  let header;
  if (len < 126) header = Buffer.from([0x80 | opcode, len]);
  else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x80 | opcode; header[1] = 126; header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x80 | opcode; header[1] = 127; header.writeBigUInt64BE(BigInt(len), 2);
  }
  return Buffer.concat([header, payload]);
}

function closeConn(conn) {
  if (conn.closed) return;
  conn.closed = true;
  try { conn.sock.write(wsFrame(0x8, Buffer.from([]))); } catch (e) {}
  setTimeout(() => { try { conn.sock.destroy(); } catch (e) {} }, 300);
}

function onDrop(conn) {
  const p = conn.player;
  if (p && p.ws === conn.sock) {
    p.ws = null; p.wsConn = null;
    onDisconnect(p);
  }
}

function handleMsg(conn, text) {
  let m;
  try { m = JSON.parse(text); } catch (e) { return; }
  conn.lastSeen = Date.now();
  const p = conn.player;
  if (!p) {
    if (m.t !== 'join') return;
    const r = join(conn.sock, m.name, m.pid, m.uid);
    if (r && r.err) { sendRaw(conn, { t: 'error', msg: r.err }); return; }
    if (r) { conn.player = r; r.wsConn = conn; }
    send(r, { t: 'board', min: MIN_P, max: MAX_P, nightMs: NIGHT_MS, dayMs: DAY_MS, voteMs: VOTE_MS });
    send(r, stateFor(r));
    return;
  }
  let e = null;
  switch (m.t) {
    case 'start':
      if (st.phase !== 'waiting') { e = 'Игра уже идёт'; break; }
      if (p.id !== st.hostId) { e = 'Партию начинает хост'; break; }
      e = newGame(p); break;
    case 'restart':
      if (p.id !== st.hostId) { e = 'Может хост'; break; }
      if (players().length < MIN_P) { e = 'Нужно минимум ' + MIN_P + ' игроков'; break; }
      e = newGame(p); break;
    case 'newGame':
      if (st.phase !== 'over') { e = 'Новая партия — после завершения'; break; }
      if (p.id !== st.hostId) { e = 'Партию начинает хост'; break; }
      e = newGame(p); break;
    case 'kill': e = nightAct(p, 'kill', m.target); break;
    case 'heal': e = nightAct(p, 'heal', m.target); break;
    case 'check': e = nightAct(p, 'check', m.target); break;
    case 'vote': e = vote(p, m.target); break;
    case 'endDiscuss': e = endDiscuss(p); break;
    case 'addBot': e = addBot(); if (!e && players().length >= MIN_P && st.phase === 'waiting' && p.id === st.hostId) { /* хост сам нажмёт «Начать» */ } break;
    case 'removeBot': e = removeBot(p); break;
    case 'leave': sitOut(p, 'покинул(а) игру'); return;
    case 'chat': {
      const txt = String(m.msg || '').trim().slice(0, 200);
      let img = null;
      if (m.img) {
        if (typeof m.img === 'string' && m.img.startsWith('data:image/') && m.img.length <= 400000) img = m.img;
        else if (!txt) { send(p, { t: 'error', msg: 'Картинка не прошла: только JPG/PNG, до ~300 КБ' }); return; }
      }
      if (!txt && !img) return;
      st.chat.push({ from: p.name, bot: p.isBot, dead: !p.alive, msg: txt, img: img ? true : null, ts: Date.now() });
      if (st.chat.length > 100) st.chat.shift();
      const live = { t: 'chat', from: p.name, bot: p.isBot, dead: !p.alive, msg: txt };
      if (img) live.img = img;
      for (const q of players()) send(q, live);
      return;
    }
  }
  if (e) send(p, { t: 'error', msg: e });
}

function handleMafiaUpgrade(req, socket) {
  const key = req.headers['sec-websocket-key'];
  if (!key) { socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + WS_GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  const conn = { sock: socket, player: null, closed: false, lastSeen: Date.now() };
  let buf = Buffer.alloc(0);
  socket.on('data', chunk => {
    conn.lastSeen = Date.now();
    buf = Buffer.concat([buf, chunk]);
    while (true) {
      if (buf.length < 2) return;
      const opcode = buf[0] & 0x0f;
      const masked = (buf[1] & 0x80) !== 0;
      let len = buf[1] & 0x7f; let off = 2;
      if (len === 126) { if (buf.length < off + 2) return; len = buf.readUInt16BE(off); off += 2; }
      else if (len === 127) { if (buf.length < off + 8) return; len = Number(buf.readBigUInt64BE(off)); off += 8; }
      if (len > 1e6) { closeConn(conn); return; }
      let mask = null;
      if (masked) { if (buf.length < off + 4) return; mask = buf.slice(off, off + 4); off += 4; }
      if (buf.length < off + len) return;
      const payload = Buffer.from(buf.slice(off, off + len));
      buf = buf.slice(off + len);
      if (masked) for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
      if (opcode === 0x8) { closeConn(conn); return; }
      else if (opcode === 0x9) { try { socket.write(wsFrame(0xA, payload)); } catch (e) {} }
      else if (opcode === 0xA) { conn.lastSeen = Date.now(); }
      else if (opcode === 0x1 || opcode === 0x0) { handleMsg(conn, payload.toString('utf8')); }
    }
  });
  socket.on('close', () => onDrop(conn));
  socket.on('error', () => onDrop(conn));
}

// ping/keepalive
setInterval(() => {
  for (const p of [...players()]) {
    if (!p.ws) continue;
    try { p.ws.write(wsFrame(0x9, Buffer.from([]))); } catch (e) {}
    if (Date.now() - ((p.wsConn && p.wsConn.lastSeen) || 0) > 75000) {
      log('🔌 ' + p.name + ' отключился (нет ответа)');
      try { p.ws.destroy(); } catch (e) {}
    }
  }
}, 25000);

module.exports = { handleMafiaUpgrade, mafiaStatus, _debug: { roleSet } };
