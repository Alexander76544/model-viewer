// ============================================================
//  Подпольный ЯМЗ — «босс-режим» (общий модуль паники)
//
//  Экстренный экран: ПУСТОЙ Excel — остаётся только книга
//  (зелёный заголовок, меню, строка формул, сетка ячеек,
//  вкладки листов, статус-бар), игра и все панели скрываются.
//  Esc — показать/скрыть.
//  Игра/лобби продолжают работать в фоне, соединение не рвётся.
//
//  Подключение на странице:  <script src="/panic.js"></script>
//  API: window.YAMZ_PANIC = { show, hide, toggle, isOn, setMode, getMode }
// ============================================================
(function () {
  'use strict';
  if (window.YAMZ_PANIC) return;

  let on = false;

  // ---------- стили ----------
  // office.js собирает страницу так: .ow-top (шапка/меню/формулы),
  // .ow-main (внутри: .ow-grid — сетка листа, + всё игровое),
  // .ow-tabs (вкладки листов), .ow-status (статус-бар) — всё в body.
  // На панике прячем всё внутри .ow-main, кроме самой сетки .ow-grid.
  const style = document.createElement('style');
  style.textContent = `
body.yzp-on .ow-main > :not(.ow-grid){visibility:hidden !important;}
/* подсказка возврата — тонкая, в углу листа */
#yz-panic-hint{position:fixed; right:14px; bottom:30px; z-index:1001;
  font:10px Tahoma,Arial,sans-serif; color:#c9c9c9; display:none; user-select:none;}
body.yzp-on #yz-panic-hint{display:block;}
/* запасной вариант, если office.js на странице не загрузился */
#yz-panic-fallback{position:fixed; inset:0; z-index:1000; background:#f2f2f2; display:none;}`;
  document.head.appendChild(style);

  // ---------- элементы ----------
  const hint = document.createElement('span');
  hint.id = 'yz-panic-hint';
  hint.textContent = 'Esc';
  const fallback = document.createElement('div');
  fallback.id = 'yz-panic-fallback';
  const host = document.body || document.documentElement;
  host.appendChild(fallback);
  host.appendChild(hint);

  function show() {
    if (on) return;
    on = true;
    if (document.querySelector('.ow-main')) {
      document.body.classList.add('yzp-on');
    } else {
      // нет Excel-хрома — показываем просто пустой серый экран
      fallback.style.display = 'block';
      document.body.classList.add('yzp-on');
    }
  }
  function hide() {
    if (!on) return;
    on = false;
    document.body.classList.remove('yzp-on');
    fallback.style.display = 'none';
  }
  function toggle() { if (on) hide(); else show(); }

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') toggle();
  });

  window.YAMZ_PANIC = {
    show, hide, toggle,
    isOn: () => on,
    // совместимость со старым API: режимы больше не используются
    setMode: () => {},
    getMode: () => 'excel-empty',
  };
})();
