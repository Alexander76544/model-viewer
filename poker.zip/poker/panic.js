// ============================================================
//  Подпольный ЯМЗ — «босс-режим» 2.0 (общий модуль паники)
//
//  Два безобидных экрана:
//    1) «Яндекс» — ЖИВОЙ: поиск (Enter) и все плитки/карточки
//       открывают настоящий yandex.ru в новой вкладке;
//    2) «Работа» — фейковый Excel (отчёт из 1С): окно книги,
//       лента, таблица, выбор ячеек — выглядит как работа.
//
//  Esc — показать/скрыть. 🙈 в шапке — показать.
//  Экраны переключаются кнопкой в левом нижнем углу; режим
//  запоминается (localStorage yz_panic_mode).
//  Игра/лобби остаётся открытым в фоне, соединение не рвётся.
//
//  Подключение на странице:  <script src="/panic.js"></script>
//  API: window.YAMZ_PANIC = { show, hide, toggle, isOn, setMode, getMode }
// ============================================================
(function () {
  'use strict';
  if (window.YAMZ_PANIC) return;
  const $ = s => document.querySelector(s);

  const savedTitle = document.title || 'Яндекс';
  let mode = (localStorage.getItem('yz_panic_mode') === 'work') ? 'work' : 'yandex';
  let on = false;

  // ---------- стили ----------
  const style = document.createElement('style');
  style.textContent = `
#yz-panic{position:fixed; inset:0; z-index:1000; background:#fff; color:#222; font-family:'Segoe UI',Arial,sans-serif; overflow:auto; display:flex; flex-direction:column;}
#yz-panic.yzp-off{display:none;}
#yz-panic *,#yz-panic *::before{box-sizing:border-box; margin:0; padding:0;}
#yz-panic a{color:inherit; text-decoration:none; cursor:pointer;}
.yzp-screen{flex:1; display:flex; flex-direction:column; min-height:100%;}
.yzp-screen.yzp-off{display:none;}
.yzp-switch{position:fixed; left:10px; bottom:8px; font-size:10px; color:#d5d5d5; z-index:1001;}
.yzp-esc{position:fixed; right:10px; bottom:8px; font-size:10px; color:#d5d5d5;}
/* --- экран «Яндекс» (как в играх) --- */
.p-head{display:flex; align-items:center; gap:22px; padding:18px 40px 10px; max-width:1000px; margin:0 auto;}
.p-logo{font-size:30px; font-weight:700; color:#000; letter-spacing:-.5px;}
.p-logo span{color:#f5c518;}
.p-menu{font-size:14px; color:#555; display:flex; gap:14px; flex-wrap:wrap;}
.p-body{max-width:1000px; margin:0 auto; padding:8px 40px; width:100%; flex:1;}
.p-search{display:flex; margin-top:48px; max-width:680px;}
.p-search input{flex:1; padding:15px 18px; font-size:16px; border:1px solid #d1d5db; border-right:none; border-radius:10px 0 0 10px; outline:none;}
.p-search input:focus{border-color:#f5c518; box-shadow:0 0 0 3px rgba(245,197,24,.15);}
.p-search button{padding:0 30px; background:#f5c518; border:none; border-radius:0 10px 10px 0; font-size:16px; font-weight:600; color:#3b3000; cursor:pointer;}
.p-search button:hover{background:#ffce3d;}
.p-quick{display:flex; gap:18px; margin-top:16px; font-size:13px; color:#555; flex-wrap:wrap;}
.p-quick a{border-bottom:1px solid transparent;}
.p-quick a:hover{border-bottom-color:#f5c518; color:#333;}
.p-news{display:grid; grid-template-columns:repeat(4,1fr); gap:14px; margin-top:40px;}
.p-card{background:#f7f8fa; border-radius:10px; overflow:hidden; cursor:pointer; display:block;}
.p-card:hover{background:#eef0f4;}
.p-thumb{height:90px;}
.p-thumb.t1{background:linear-gradient(135deg,#8ec5fc,#e0c3fc);}
.p-thumb.t2{background:linear-gradient(135deg,#f6d365,#fda085);}
.p-thumb.t3{background:linear-gradient(135deg,#a1c4fd,#c2e9fb);}
.p-thumb.t4{background:linear-gradient(135deg,#d4fc79,#96e6a1);}
.p-card b{display:block; font-size:14px; padding:10px 12px 4px; color:#222;}
.p-card p{font-size:12px; color:#777; padding:0 12px 12px; line-height:1.45;}
.p-serv{display:grid; grid-template-columns:repeat(8,1fr); gap:10px; margin-top:30px; max-width:920px;}
.p-serv a{display:flex; flex-direction:column; align-items:center; gap:7px; font-size:12px; color:#444; padding:12px 4px; border-radius:10px;}
.p-serv a:hover{background:#f7f8fa;}
.p-serv i{font-style:normal; font-size:26px;}
.p-foot{margin-top:auto; text-align:center; font-size:12px; color:#999; padding:26px 0 20px;}
.p-menu a:hover{color:#333;}
@media (max-width:820px){ .p-news{grid-template-columns:repeat(2,1fr);} .p-serv{grid-template-columns:repeat(4,1fr);} .p-head{padding:14px 18px 8px;} .p-body{padding:8px 18px;} }
/* --- экран «Работа» (фейковый Excel/1С) --- */
.ex-title{display:flex; align-items:center; gap:8px; background:#107C41; color:#fff; padding:6px 12px; font-size:13px;}
.ex-ico{font-size:15px;}
.ex-tname{flex:1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;}
.ex-winbtns i{font-style:normal; margin-left:14px; font-size:12px; opacity:.85;}
.ex-tabs{display:flex; align-items:flex-end; gap:4px; padding:4px 10px 0; border-bottom:1px solid #e1e5ea; font-size:13px; color:#444;}
.ex-tabs span{padding:6px 12px; border-radius:6px 6px 0 0; cursor:default;}
.ex-tabs span:hover{background:#f1f4f7;}
.ex-tabs .ex-file{color:#107C41; font-weight:600;}
.ex-tabs .ex-on{color:#107C41; font-weight:600; border-bottom:2px solid #107C41; padding-bottom:5px;}
.ex-tools{display:flex; align-items:center; gap:18px; padding:7px 12px; border-bottom:1px solid #e1e5ea; font-size:12px; color:#333; flex-wrap:wrap;}
.ex-grp{display:flex; align-items:center; gap:6px; padding-right:14px; border-right:1px solid #e6e9ed;}
.ex-grp i{font-style:normal; font-size:13px; width:20px; height:20px; line-height:20px; text-align:center; border-radius:3px; background:#f4f6f8; border:1px solid #e3e7eb; color:#555;}
.ex-grp i:hover{background:#e7f3ec; border-color:#9fcdb2;}
.ex-grp .ex-wide{font-size:11px; color:#555; padding:4px 8px; border-radius:4px;}
.ex-grp .ex-wide:hover{background:#f1f4f7;}
.ex-fx{display:flex; align-items:center; border-bottom:1px solid #e1e5ea; font-size:12px; background:#fff;}
.ex-nb{width:64px; text-align:center; padding:4px 0; border-right:1px solid #e1e5ea; color:#333;}
.ex-fxs{width:34px; text-align:center; font-style:italic; color:#999; border-right:1px solid #e1e5ea; padding:4px 0;}
.ex-fxv{flex:1; padding:4px 10px; color:#222; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;}
.ex-scroll{flex:1; overflow:auto;}
.ex-g{border-collapse:collapse; font-size:12.5px; table-layout:fixed;}
.ex-g td{border:1px solid #e4e8ec; padding:3px 8px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;}
.ex-g .ex-corner{width:44px; background:#f8fafc; border-right:1px solid #d5dbe1;}
.ex-g .ex-colh{background:#f8fafc; text-align:center; color:#555; font-weight:600; border-right:1px solid #d5dbe1; position:sticky; top:0; z-index:2;}
.ex-g .ex-rowh{background:#f8fafc; text-align:center; color:#555; width:44px; border-right:1px solid #d5dbe1;}
.ex-g .ex-h{font-weight:600; color:#111; background:#fbfcfd;}
.ex-g .ex-num{text-align:right; font-variant-numeric:tabular-nums;}
.ex-g .ex-c{cursor:cell;}
.ex-g .ex-sel{outline:2px solid #107C41; outline-offset:-2px; background:#eaf5ef;}
.ex-sheets{display:flex; align-items:center; gap:2px; padding:3px 8px; border-top:1px solid #e1e5ea; font-size:12.5px; color:#555; background:#fff;}
.ex-sheets b{color:#107C41; border:1px solid #cfd6dd; border-bottom:none; padding:3px 16px; background:#fff;}
.ex-sheets span{padding:3px 14px;}
.ex-sheets .ex-add{margin-left:6px; font-weight:700; color:#888;}
.ex-status{display:flex; gap:24px; padding:4px 12px; border-top:1px solid #e1e5ea; font-size:12px; color:#444; background:#f8fafc;}
.ex-stat-r{margin-left:auto;}
`;
  document.head.appendChild(style);

  // ---------- экран «Яндекс» ----------
  const yandexScreen = `
<div class="yzp-screen yzp-yandex">
  <div class="p-head">
    <a class="p-logo" href="https://yandex.ru/" target="_blank" rel="noopener">Я<span>н</span>декс</a>
    <div class="p-menu"><a href="https://mail.yandex.ru/" target="_blank" rel="noopener">Почта</a><a href="https://yandex.ru/maps/" target="_blank" rel="noopener">Карты</a><a href="https://music.yandex.ru/" target="_blank" rel="noopener">Музыка</a><a href="https://market.yandex.ru/" target="_blank" rel="noopener">Маркет</a><a href="https://www.kinopoisk.ru/" target="_blank" rel="noopener">Кинопоис</a><a href="https://yandex.ru/news/" target="_blank" rel="noopener">Новости</a><span>Ещё ▾</span></div>
  </div>
  <div class="p-body">
    <form class="p-search" id="yzp-search">
      <input type="text" id="yzp-search-in" placeholder="Например: погода в Москве" autocomplete="off">
      <button type="submit">Поиск</button>
    </form>
    <div class="p-quick">
      <a href="https://yandex.ru/calendar/" target="_blank" rel="noopener">📅 Календарь</a><a href="https://yandex.ru/currency/" target="_blank" rel="noopener">💱 Курсы валют</a><a href="https://yandex.ru/images/" target="_blank" rel="noopener">📷 Фотопоиск</a><a href="https://translate.yandex.ru/" target="_blank" rel="noopener">📚 Переводчик</a><a href="https://travel.yandex.ru/" target="_blank" rel="noopener">✈️ Авиабилеты</a>
    </div>
    <div class="p-serv">
      <a href="https://mail.yandex.ru/" target="_blank" rel="noopener"><i>✉️</i>Почта</a><a href="https://yandex.ru/maps/" target="_blank" rel="noopener"><i>🗺️</i>Карты</a><a href="https://music.yandex.ru/" target="_blank" rel="noopener"><i>🎵</i>Музыка</a><a href="https://www.kinopoisk.ru/" target="_blank" rel="noopener"><i>🎬</i>Кинопоис</a>
      <a href="https://market.yandex.ru/" target="_blank" rel="noopener"><i>🛒</i>Маркет</a><a href="https://money.yandex.ru/" target="_blank" rel="noopener"><i>💳</i>Деньги</a><a href="https://travel.yandex.ru/" target="_blank" rel="noopener"><i>🧭</i>Путешествия</a><a href="https://yandex.ru/games/" target="_blank" rel="noopener"><i>🎮</i>Игры</a>
    </div>
    <div class="p-news">
      <a class="p-card" href="https://yandex.ru/pogoda/" target="_blank" rel="noopener"><div class="p-thumb t1"></div><b>Погода на выходные</b><p>В выходные ожидается тёплая и сухая погода, без осадков. Ночью прохладно.</p></a>
      <a class="p-card" href="https://yandex.ru/currency/" target="_blank" rel="noopener"><div class="p-thumb t2"></div><b>Курсы валют ЦБ</b><p>Центральный банк установил новые официальные курсы доллара и евро.</p></a>
      <a class="p-card" href="https://www.kinopoisk.ru/" target="_blank" rel="noopener"><div class="p-thumb t3"></div><b>Премьеры недели</b><p>Подборка новых фильмов и сериалов, которые стоит посмотреть на этой неделе.</p></a>
      <a class="p-card" href="https://yandex.ru/champion/" target="_blank" rel="noopener"><div class="p-thumb t4"></div><b>Спорт: итоги тура</b><p>Разбираем ключевые матчи тура, главные ошибки и положение в таблице.</p></a>
    </div>
  </div>
  <div class="p-foot">Яндекс · Рекламодателям · Помощь · Условия использования · Конфиденциальность · © 2026</div>
</div>`;

  // ---------- экран «Работа» (Excel с отчётом из 1С) ----------
  const EX_COLS = ['А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ж', 'З'];
  const EX_HEAD = ['Дата', 'Склад', 'Артикул', 'Позиция', 'Кол-во', 'Цена, ₽', 'Сумма, ₽', ''];
  const EX_ROWS = [
    ['24.09.2026', 'СКЛ-3', 'Арт-1042', 'Кабель ВВГнг(А)-LS 3×2,5, м', 120, 218.4],
    ['24.09.2026', 'СКЛ-1', 'Арт-2210', 'Автоматный выключатель ВА47-29 16А', 48, 312.0],
    ['25.09.2026', 'СКЛ-3', 'Арт-1187', 'Клемма WAGO 221-413', 96, 45.8],
    ['25.09.2026', 'СКЛ-2', 'Арт-3320', 'Розетка двойная с заземлением', 30, 189.5],
    ['26.09.2026', 'СКЛ-1', 'Арт-1501', 'Кабель-канал 40×25, м', 60, 96.2],
    ['26.09.2026', 'СКЛ-3', 'Арт-2211', 'УЗО 16А 30мА ВД1-63', 12, 1240.0],
    ['27.09.2026', 'СКЛ-2', 'Арт-4105', 'Лампа светодиодная E27 60Вт 4000К', 150, 89.9],
    ['28.09.2026', 'СКЛ-1', 'Арт-1188', 'Гильза ввинчиваемая 16×60', 200, 21.4],
    ['28.09.2026', 'СКЛ-3', 'Арт-3321', 'Щит распределительный 8 модулей', 8, 2450.0],
    ['29.09.2026', 'СКЛ-2', 'Арт-1043', 'Провод ПВС 3×1,5, м', 85, 134.6],
    ['29.09.2026', 'СКЛ-1', 'Арт-2212', 'Автоматный выключатель ВА47-29 25А', 36, 428.0],
    ['29.09.2026', 'СКЛ-3', 'Арт-5510', 'Хомут стальной оцинк. 3×200', 300, 3.2],
    ['30.09.2026', 'СКЛ-2', 'Арт-1502', 'Дин-рейка 35×7, м', 40, 78.0],
    ['30.09.2026', 'СКЛ-1', 'Арт-4106', 'Светильник LED офисный 36Вт', 24, 1120.0],
    ['01.10.2026', 'СКЛ-3', 'Арт-3322', 'Выключатель одноклавишный', 26, 156.3],
    ['01.10.2026', 'СКЛ-2', 'Арт-1189', 'Болт M6×40 оцинкованный', 500, 4.8],
    ['02.10.2026', 'СКЛ-1', 'Арт-2213', 'Счётчик электроэнергии МЕРКУРИЙ 201', 10, 1890.0],
    ['02.10.2026', 'СКЛ-3', 'Арт-1044', 'Кабель ВВГнг(А)-LS 5×6, м', 35, 512.7],
    ['03.10.2026', 'СКЛ-2', 'Арт-6001', 'Уголок соединительный 40×40', 14, 64.5],
  ];
  function exFmt(n) { return Number(n).toLocaleString('ru-RU', { maximumFractionDigits: 2 }); }
  const workScreen = `
<div class="yzp-screen yzp-work">
  <div class="ex-title"><span class="ex-ico">▦</span><span class="ex-tname">Отчёт_продажи_1С_2026.xlsx — Excel</span><span class="ex-winbtns"><i>—</i><i>▢</i><i>✕</i></span></div>
  <div class="ex-tabs"><span class="ex-file">Файл</span><span class="ex-on">Главная</span><span>Вставка</span><span>Формулы</span><span>Данные</span><span>Рецензирование</span><span>Просмотр</span></div>
  <div class="ex-tools">
    <span class="ex-grp"><i style="font-weight:700">B</i><i style="font-style:italic">I</i><i style="text-decoration:underline">U</i></span>
    <span class="ex-grp"><i>123</i><i>%</i><i>₽</i></span>
    <span class="ex-grp"><i>≡</i><i>⯇</i><i>◫</i></span>
    <span class="ex-grp"><i style="font-size:15px">Σ</i><b class="ex-wide">Автосумма</b></span>
    <span class="ex-grp"><b class="ex-wide">Условное форматирование</b></span>
    <span class="ex-grp"><b class="ex-wide">Сортировка и фильтры</b></span>
    <span class="ex-grp"><b class="ex-wide">Вставить диаграмму</b></span>
  </div>
  <div class="ex-fx"><span class="ex-nb" id="ex-nb">А1</span><span class="ex-fxs">fx</span><span class="ex-fxv" id="ex-fxv">Дата</span></div>
  <div class="ex-scroll"><table class="ex-g"><thead id="ex-th"></thead><tbody id="ex-tb"></tbody></table></div>
  <div class="ex-sheets"><b>Лист1</b><span>Лист2</span><span>Лист3</span><span class="ex-add">+</span></div>
  <div class="ex-status"><span>Готово</span><span class="ex-stat-r" id="ex-stat"></span></div>
</div>`;

  // ---------- сборка ----------
  const root = document.createElement('div');
  root.id = 'yz-panic';
  root.className = 'yzp-off';
  root.innerHTML = yandexScreen + workScreen +
    '<a class="yzp-switch" id="yzp-switch">📊 Эксель</a>' +
    '<span class="yzp-esc">Esc</span>';
  (document.body || document.documentElement).appendChild(root);

  // таблица Excel
  (function buildGrid() {
    const thead = root.querySelector('#ex-th');
    const tbody = root.querySelector('#ex-tb');
    let html = '<tr><td class="ex-corner"></td>';
    for (const c of EX_COLS) html += '<td class="ex-colh">' + c + '</td>';
    thead.innerHTML = html + '</tr>';
    let rows = '';
    for (let r = 0; r < 40; r++) {
      rows += '<tr><td class="ex-rowh">' + (r + 1) + '</td>';
      for (let c = 0; c < EX_COLS.length; c++) {
        let v = '', num = false;
        if (r === 0) v = EX_HEAD[c] || '';
        else {
          const d = EX_ROWS[r - 1];
          if (d) {
            if (c <= 3) v = d[c];
            else if (c === 4) { v = String(d[4]); num = true; }
            else if (c === 5) { v = exFmt(d[5]); num = true; }
            else if (c === 6) { v = exFmt(d[4] * d[5]); num = true; }
          }
        }
        rows += '<td class="ex-c' + (r === 0 ? ' ex-h' : '') + (num ? ' ex-num' : '') +
          '" data-r="' + r + '" data-c="' + c + '">' + v + '</td>';
      }
      rows += '</tr>';
    }
    tbody.innerHTML = rows;
    tbody.addEventListener('click', e => {
      const td = e.target.closest ? e.target.closest('td.ex-c') : null;
      if (!td) return;
      tbody.querySelectorAll('.ex-sel').forEach(x => x.classList.remove('ex-sel'));
      td.classList.add('ex-sel');
      const r = +td.dataset.r, c = +td.dataset.c;
      root.querySelector('#ex-nb').textContent = EX_COLS[c] + (r + 1);
      let fx = td.textContent;
      if (r > 0 && c === 6 && EX_ROWS[r - 1]) fx = '=Д' + (r + 1) + '*Е' + (r + 1);
      root.querySelector('#ex-fxv').textContent = fx;
    });
    const total = EX_ROWS.reduce((s, d) => s + d[4] * d[5], 0);
    root.querySelector('#ex-stat').textContent =
      'Среднее: ' + exFmt(total / EX_ROWS.length) + ' · Сумма: ' + exFmt(total) + ' · Количество: ' + EX_ROWS.length;
  })();

  // поиск Яндекса — реальный
  root.querySelector('#yzp-search').addEventListener('submit', e => {
    e.preventDefault();
    const q = root.querySelector('#yzp-search-in').value.trim();
    window.open(q ? 'https://yandex.ru/search/?text=' + encodeURIComponent(q) : 'https://yandex.ru/', '_blank', 'noopener');
  });

  function applyMode() {
    root.querySelector('.yzp-yandex').classList.toggle('yzp-off', mode !== 'yandex');
    root.querySelector('.yzp-work').classList.toggle('yzp-off', mode !== 'work');
    root.querySelector('#yzp-switch').textContent = mode === 'yandex' ? '📊 Эксель' : '🌐 Яндекс';
    if (on) document.title = mode === 'yandex' ? 'Яндекс' : 'Отчёт_продажи_1С_2026.xlsx — Excel';
  }
  function show(m) {
    if (m) mode = m;
    on = true;
    root.classList.remove('yzp-off');
    applyMode();
    try { localStorage.setItem('yz_panic_mode', mode); } catch (e) {}
  }
  function hide() {
    on = false;
    root.classList.add('yzp-off');
    document.title = savedTitle;
  }
  function toggle() { if (on) hide(); else show(); }
  root.querySelector('#yzp-switch').addEventListener('click', () => {
    mode = (mode === 'yandex') ? 'work' : 'yandex';
    applyMode();
    try { localStorage.setItem('yz_panic_mode', mode); } catch (e) {}
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') toggle();
  });

  window.YAMZ_PANIC = {
    show, hide, toggle,
    isOn: () => on,
    setMode: m => { if (m === 'yandex' || m === 'work') { mode = m; applyMode(); } },
    getMode: () => mode,
  };
})();
