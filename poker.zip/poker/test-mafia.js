// Протокольный тест «Мафия»: node test-mafia.js   (PORT=4181 по умолчанию)
'use strict';
const PORT = process.env.PORT || 4181;
const WS_URL = 'ws://127.0.0.1:' + PORT + '/ws-mafia';
const API = 'http://127.0.0.1:' + PORT;
const RUN = Date.now().toString(36); // свежие uid за прогон — чистые профили

const PNG_1PX = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

let fails = 0;
function ok(cond, msg) {
  if (cond) console.log('ok: ' + msg);
  else { fails++; console.error('FAIL: ' + msg); }
}
function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

function client(name, uid, pid) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(WS_URL);
    const c = {
      name, uid, pid, ws, st: null, role: null, board: null,
      errors: [], whispers: [], lastChat: null, errMsg: null, joined: false,
      send(o) { ws.send(JSON.stringify(o)); },
    };
    const to = setTimeout(() => reject(new Error('timeout join ' + name)), 8000);
    ws.onmessage = ev => {
      const m = JSON.parse(ev.data);
      if (m.t === 'board') c.board = m;
      else if (m.t === 'state') { c.st = m; if (!c.joined) { c.joined = true; clearTimeout(to); resolve(c); } }
      else if (m.t === 'role') c.role = m;
      else if (m.t === 'whisper') c.whispers.push(m.msg);
      else if (m.t === 'error') { c.errors.push(m.msg); if (!c.joined) { c.errMsg = m.msg; clearTimeout(to); resolve(c); } }
      else if (m.t === 'chat') c.lastChat = m;
    };
    ws.onerror = () => { clearTimeout(to); reject(new Error('ws error ' + name)); };
    ws.onopen = () => ws.send(JSON.stringify({ t: 'join', name, uid: uid || null, pid: pid || null }));
  });
}

async function main() {
  // чистый сервер: за столом никого (иначе тесты путают старые места со свежими)
  const g = await (await fetch(API + '/api/games')).json();
  if (g.mafia.players > 0) throw new Error('Сервер не чистый: за столом ' + g.mafia.players + ' игрока(ов). Перезапустите тестовый сервер (PORT=4181).');

  // --- 1. 5 игроков, старт отклонён ---
  const A = await client('Маф-А', 'u-mafiaa' + RUN);
  const B = await client('Маф-Б', 'u-mafiab' + RUN);
  const C = await client('Маф-В', 'u-mafiac' + RUN);
  const D = await client('Маф-Г', 'u-mafiad' + RUN);
  const E = await client('Маф-Д', 'u-mafiae' + RUN);
  ok(A.st.phase === 'waiting' && A.st.slots.filter(Boolean).length === 5, 'пятеро за столом, ожидание');

  B.send({ t: 'start' }); await wait(200);
  ok(B.errors.some(e => e.includes('хост')), 'старт не хостом отклонён: ' + (B.errors[0] || ''));
  A.send({ t: 'start' }); await wait(200);
  ok(A.errors.some(e => e.includes('6')), 'старт с 5 игроками отклонён: ' + (A.errors[A.errors.length - 1] || ''));

  // --- 2. максимум 9 мест, 10-й отклонён, выход до 6 ---
  const F = await client('Маф-Е', 'u-mafiaf' + RUN);
  const G = await client('Маф-Ж', 'u-mafiag' + RUN);
  const H = await client('Маф-З', 'u-mafiah' + RUN);
  const I = await client('Маф-И', 'u-mafiai' + RUN);
  ok(I.st.slots.filter(Boolean).length === 9, 'девять игроков — полный стол');
  const J = await client('Маф-Й', null);
  ok(!!J.errMsg && J.errMsg.includes('9'), 'десятый игрок отклонён: ' + (J.errMsg || ''));
  J.ws.close();
  I.send({ t: 'leave' }); H.send({ t: 'leave' }); G.send({ t: 'leave' });
  await wait(400);
  ok(A.st.slots.filter(Boolean).length === 6, 'трое вышли — осталось 6, можно играть');

  // --- 3. чат: эмодзи, картинка, крупная отклонена ---
  A.send({ t: 'chat', msg: '🕵️ кто тут мафия?' }); await wait(300);
  ok(B.lastChat && B.lastChat.from === 'Маф-А' && B.lastChat.msg.includes('🕵️'), 'чат с эмодзи дошёл');
  A.send({ t: 'chat', msg: '', img: PNG_1PX }); await wait(300);
  ok(B.lastChat && B.lastChat.img, 'картинка в чате дошла');
  A.send({ t: 'chat', msg: '', img: 'data:image/png;base64,' + 'x'.repeat(500000) }); await wait(300);
  ok(A.errors.some(e => e.includes('Картинка')), 'крупная картинка отклонена');

  // --- 4. старт → ночь, роли ---
  A.send({ t: 'start' }); await wait(500);
  ok(A.st.phase === 'night' && A.st.nightNo === 1, 'ночь 1 началась');
  const ps = [A, B, C, D, E, F];
  ok(ps.every(p => p.role && p.role.role), 'роли получили все шестеро');
  const counts = {};
  ps.forEach(p => { counts[p.role.role] = (counts[p.role.role] || 0) + 1; });
  ok(counts.mafia === 1 && counts.doctor === 1 && counts.detective === 1 && counts.citizen === 3,
    'состав ролей 1/1/1/3: ' + JSON.stringify(counts));
  const mafiaC = ps.find(p => p.role.role === 'mafia');
  const docC = ps.find(p => p.role.role === 'doctor');
  const detC = ps.find(p => p.role.role === 'detective');
  const citizens = ps.filter(p => p.role.role === 'citizen');
  ok(mafiaC.role.mafia && mafiaC.role.mafia.length === 1 && mafiaC.role.mafia[0] === mafiaC.st.myId,
    'мафия знает состав (себя)');

  // действие не своей роли
  citizens[0].send({ t: 'kill', target: citizens[1] ? citizens[1].id : null });
  await wait(200);
  ok(citizens[0].errors.some(e => e.includes('роли')), 'действие не своей роли отклонено');

  // --- 5. ночь: убийство, лечение, проверка ---
  const killT = citizens[0], healT = citizens[1];
  mafiaC.send({ t: 'kill', target: killT.st.myId }); await wait(150);
  docC.send({ t: 'heal', target: healT.st.myId }); await wait(150);
  detC.send({ t: 'check', target: mafiaC.st.myId }); await wait(500);
  ok(A.st.phase === 'day' && A.st.dayStage === 'discuss', 'ночь разрешена → день 1 (обсуждение)');
  const killSeat = killT.st.slots[killT.st.mySeat];
  ok(killSeat && killSeat.alive === false, 'жертва мафии погибла: ' + killT.name);
  const healSeat = healT.st.slots[healT.st.mySeat];
  ok(healSeat && healSeat.alive === true, 'защищённый врачом жив: ' + healT.name);
  ok(detC.whispers.some(w => w.includes('МАФИЯ')), 'следователь получил приватный ответ (МАФИЯ)');

  // мёртвый наблюдает и пишет в чат
  killT.send({ t: 'chat', msg: '🪦 смотрю из-за могилы' }); await wait(300);
  ok(A.lastChat && A.lastChat.from === killT.name && A.lastChat.dead === true, 'мёртвый пишет в чат (наблюдатель)');

  // --- 6. голосование: мафию выносят → победа города ---
  B.send({ t: 'endDiscuss' }); await wait(150);
  ok(B.errors.some(e => e.includes('хост')), 'ускорение не хостом отклонено');
  A.send({ t: 'endDiscuss' }); await wait(300);
  ok(A.st.phase === 'day' && A.st.dayStage === 'vote', 'голосование открыто');

  killT.send({ t: 'vote', target: mafiaC.st.myId }); await wait(150);
  ok(killT.errors.some(e => e.includes('Мёртвые')), 'мёртвые не голосуют');
  for (const p of ps.filter(p => p !== killT && p !== mafiaC)) { p.send({ t: 'vote', target: mafiaC.st.myId }); await wait(100); }
  mafiaC.send({ t: 'vote', target: null }); await wait(300); // мафия за себя голосовать не может — воздерживается
  ok(A.st.phase === 'over' && A.st.winner === 'town', 'мафию вынесли голосованием — победа города');
  ok(A.st.logs.some(l => String(l.t).includes('Исключён') && String(l.t).includes(mafiaC.name)), 'журнал: исключён с открытием роли');
  ok(A.st.slots.filter(Boolean).every(s => !!s.role), 'в конце партии роли открыты');
  ok(mafiaC.st.inMafia === true && citizens[1].st.inMafia === false, 'флаг inMafia у мафии, без него у мирных');

  // --- 7. чемпионат: городу очки, мафии нет ---
  const r1 = await fetch(API + '/api/championship?uid=' + encodeURIComponent(citizens[2].uid) + '&name=' + encodeURIComponent(citizens[2].name));
  const c1 = await r1.json();
  ok(c1.me && c1.me.rating >= 20 && c1.me.wins.mafia >= 1,
    'чемпионат: ' + citizens[2].name + ' — рейтинг ' + (c1.me ? c1.me.rating : '?') + ', побед в мафии: ' + (c1.me ? c1.me.wins.mafia : '?'));
  const r2 = await fetch(API + '/api/championship?uid=' + encodeURIComponent(mafiaC.uid) + '&name=' + encodeURIComponent(mafiaC.name));
  const c2 = await r2.json();
  ok(!c2.me || c2.me.rating === 0, 'чемпионат: мафия очки не набрала (рейтинг ' + (c2.me ? c2.me.rating : 'нет профиля') + ')');

  // --- 8. ре-коннект (мёртвый наблюдатель) ---
  const K2 = await client(killT.name, killT.uid, killT.st.myId);
  ok(K2.role && K2.role.role === 'citizen' && K2.st.phase === 'over', 'ре-коннект: место и роль сохранены');
  killT.ws.close();
  ps[ps.indexOf(killT)] = K2; // дальше действует новый сокет этого места

  // --- 9. новая партия с ботами, рестарт, выход до сброса ---
  // хост может быть жертвой и сидеть на соке K2 — работаем через ЖИВОГО хоста
  const hostC = ps.find(p => p.st && p.st.isHost && p.ws.readyState === 1);
  ok(!!hostC, 'хост за столом: ' + (hostC ? hostC.name : '?'));
  const isLive = p => { try { return p.ws.readyState === 1; } catch (e) { return false; } };
  const liveOf = id => ps.find(p => p.st && p.st.myId === id && isLive(p)) || ps.find(p => p.st && p.st.myId === id);

  hostC.send({ t: 'addBot' }); await wait(200);
  hostC.send({ t: 'addBot' }); await wait(200);
  hostC.send({ t: 'addBot' }); await wait(200);
  ok(hostC.st.slots.filter(s => s && s.bot).length === 3, 'три бота за столом (9 игроков)');
  hostC.send({ t: 'newGame' }); await wait(500);
  ok(hostC.st.phase === 'night' && hostC.st.nightNo === 1, 'новая партия с ботами — ночь 1');
  // все ЧЕЛОВЕЧЕСКИЕ специалы действуют; боты (если спецы) действуют сами — ночь обязана разрешиться
  const m2 = hostC.st.slots.map(s => (s && s.id ? liveOf(s.id) : null)).filter(Boolean);
  const mafiaIds = new Set(m2.filter(p => p.role && p.role.role === 'mafia').map(p => p.st.myId));
  const targetFor = p => hostC.st.slots.find(s => s && s.alive && s.id !== p.st.myId && !mafiaIds.has(s.id)) || null;
  for (const p of m2) {
    if (!p.role) continue;
    if (p.role.role === 'mafia') { const t2 = targetFor(p); if (t2) p.send({ t: 'kill', target: t2.id }); }
    else if (p.role.role === 'doctor') p.send({ t: 'heal', target: null });
    else if (p.role.role === 'detective') { const t2 = targetFor(p); if (t2) p.send({ t: 'check', target: t2.id }); }
  }
  const t2s = Date.now();
  let night2ok = false;
  while (Date.now() - t2s < 12000) {
    await wait(250);
    if (hostC.st.phase === 'day') { night2ok = true; break; }
    if (hostC.st.phase === 'over') break;
  }
  ok(night2ok, 'ночь с ботами разрешилась (боты не блокируют)');

  hostC.send({ t: 'restart' }); await wait(400);
  ok(hostC.st.phase === 'night', 'хост перезапустил партию (🔄)');

  // люди уходят до <6: партия либо закончилась по правилу 3v3, либо сброшена
  const leavers = ps.filter(p => p !== hostC && isLive(p)).slice(0, 4);
  for (const p of leavers) { p.send({ t: 'leave' }); await wait(250); }
  ok(hostC.st.phase === 'waiting' || hostC.st.phase === 'over',
    'людей осталось <6 — партия завершена (фаза: ' + hostC.st.phase + ')');

  // боты убираются по одному (только когда партия не идёт)
  hostC.send({ t: 'removeBot' }); await wait(250);
  ok(hostC.st.slots.filter(s => s && s.bot).length === 2, 'бот убран по одному (осталось 2)');
  hostC.send({ t: 'removeBot' }); await wait(250);
  hostC.send({ t: 'removeBot' }); await wait(250);
  ok(!hostC.st.slots.some(s => s && s.bot), 'все боты убраны');
  hostC.send({ t: 'leave' }); await wait(200);
  if (K2 !== hostC) { K2.send({ t: 'leave' }); await wait(150); } // не оставлять место с «рванутым» сокетом

  // --- 10. лишних ошибок сервера нет ---
  const stray = [A, B, C, D, E, F].concat([K2]).filter(Boolean)
    .flatMap(p => p.errors).filter(e => e.includes('Неверный') || e.includes('Не JSON'));
  ok(stray.length === 0, 'ошибок сервера нет');

  [A, B, C, D, E, F, K2].forEach(p => { try { p.ws.close(); } catch (e) {} });
  if (fails) { console.error('FAIL: ' + fails + ' проблем(ы)'); process.exit(1); }
  console.log('PASS: мафия — 6–9 мест, роли, ночь (убийство/лечение/проверка), мёртвые-наблюдатели, голосование, победа города, чемпионат, ре-коннект, бот, рестарт, сброс при <6.');
}

main().catch(e => { console.error('ОШИБКА ТЕСТА: ' + (e && e.stack || e)); process.exit(1); });
