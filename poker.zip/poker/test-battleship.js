// Авто-тест морского боя. Запуск (пока работает node serve.js):
//   node test-battleship.js
// Проверяет: заход двоих, отказ третьего, РУЧНУЮ расстановку флота
// (невалидную отклоняет, валидную принимает), перемешивание, чат с эмодзи
// и картинками, полный бой до победы, повторный выстрел, ре-коннект в бою
// и бота-соперника.
'use strict';
const PORT = process.env.PORT || '4180';
const URL = 'ws://127.0.0.1:' + PORT + '/ws-boy';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const fail = msg => { console.error('FAIL: ' + msg); process.exit(1); };
const ok = msg => console.log('ok: ' + msg);

// валидная расстановка: ряды 0/3/6/9, корабли через пустые клетки
const TEST_FLEET = [
  [0, 1, 2, 3], [5, 6, 7],
  [30, 31, 32], [34, 35],
  [60, 61], [63, 64],
  [90], [92], [94], [96],
];

function client(name, pid) {
  const c = { name, pid, ws: null, st: null, errors: [] };
  c.connect = () => new Promise((resolve, reject) => {
    const ws = new WebSocket(URL);
    c.ws = ws;
    const t = setTimeout(() => reject(new Error('таймаут соединения ' + name)), 5000);
    ws.onopen = () => ws.send(JSON.stringify({ t: 'join', name, pid: pid || null }));
    ws.onmessage = ev => {
      const m = JSON.parse(ev.data);
      if (m.t === 'state') {
        c.st = m;
        if (!c.done) { c.done = true; clearTimeout(t); resolve(c); }
      } else if (m.t === 'error') {
        c.lastErr = m.msg;
        if (c.onErr) c.onErr(m.msg); else c.errors.push(m.msg + ' (' + name + ')');
        if (!c.done) { c.done = true; clearTimeout(t); resolve(c); }
      } else if (m.t === 'chat') { if (c.onChat) c.onChat(m); }
    };
    ws.onerror = () => { clearTimeout(t); reject(new Error('ws error ' + name)); };
    ws.onclose = () => { c.dead = true; };
  });
  c.send = o => { if (c.ws && c.ws.readyState === 1) c.ws.send(JSON.stringify(o)); };
  return c;
}

async function placeBoth(A, B) {
  A.send({ t: 'placed', ships: TEST_FLEET });
  B.send({ t: 'placed', ships: TEST_FLEET });
  for (let i = 0; i < 200 && !(A.st.myReady && A.st.oppReady); i++) await sleep(50);
  if (!(A.st.myReady && A.st.oppReady)) throw new Error('флоты не подтверждены');
}

// выстрел в первую ещё не обстрелянную клетку (сканируем по порядку)
function nextShot(st) {
  if (!st || !st.enemyBoard) return null;
  const i = st.enemyBoard.findIndex(v => v === 0);
  return i < 0 ? null : { x: i % 10, y: (i / 10) | 0 };
}

async function fightTo(A, B, budgetMs) {
  const t0 = Date.now();
  while (Date.now() - t0 < budgetMs) {
    for (const c of [A, B]) {
      if (c.st && c.st.phase === 'battle' && c.st.turn === c.st.mySeat) {
        const s = nextShot(c.st);
        if (s) c.send({ t: 'fire', x: s.x, y: s.y });
      }
    }
    if (A.st && A.st.phase === 'over') return true;
    await sleep(80);
  }
  return false;
}

(async () => {
  const A = client('Бой-А');
  const B = client('Бой-Б');
  await A.connect();
  if (!A.st || A.st.phase !== 'waiting') fail('A: фаза после захода ' + (A.st && A.st.phase) + ' (ожидали waiting)');
  await B.connect();
  for (let i = 0; i < 100 && !(A.st && A.st.phase === 'setup'); i++) await sleep(50);
  if (!A.st || A.st.phase !== 'setup') fail('расстановка: фаза не setup');
  if (A.st.myBoard.cells.filter(c => c.s).length !== 0) fail('расстановка: поле должно быть пустым');
  if (A.st.myReady !== false) fail('расстановка: myReady должен быть false');
  ok('двое за столом, пустые поля для ручной расстановки');

  // третий игрок не влезает
  let fullErr = null;
  const C = client('Бой-В');
  C.onErr = m => { if (/на двоих/.test(m)) fullErr = m; };
  await C.connect();
  if (!fullErr) fail('третий игрок: не отклонён');
  ok('третий игрок отклонён (игра на двоих)');

  // ручная расстановка: невалидную (корабли касаются) отклоняем
  let badPlaceErr = null;
  A.onErr = m => { if (/касаться|пересекаются|не совпадают|Неверные/.test(m)) badPlaceErr = m; };
  A.send({ t: 'placed', ships: [[0, 1, 2, 3], [4, 5, 6], [30, 31, 32], [34, 35], [60, 61], [63, 64], [90], [92], [94], [96]] });
  for (let i = 0; i < 100 && !badPlaceErr; i++) await sleep(50);
  if (!badPlaceErr) fail('расстановка: касание кораблей не отклонено');
  if (A.st.myReady) fail('расстановка: после ошибки myReady должен быть false');
  ok('невалидная расстановка (касание) отклонена');

  // валидную принимаем
  A.send({ t: 'placed', ships: TEST_FLEET });
  for (let i = 0; i < 100 && A.st.myReady !== true; i++) await sleep(50);
  if (A.st.myReady !== true) fail('расстановка: флот не принят');
  if (A.st.oppReady !== false) fail('расстановка: oppReady должен быть false');
  B.send({ t: 'placed', ships: TEST_FLEET });
  for (let i = 0; i < 100 && A.st.oppReady !== true; i++) await sleep(50);
  if (A.st.oppReady !== true) fail('расстановка: oppReady не обновился');
  if (A.st.myBoard.cells.filter(c => c.s).length !== 20) fail('расстановка: 20 клеток не на поле');
  ok('ручная расстановка принята (20 клеток, оба готовы)');

  // перемешивание: случайный флот сразу валиден
  A.send({ t: 'shuffle' });
  for (let i = 0; i < 100 && A.st.myBoard.cells.filter(c => c.s).length !== 20; i++) await sleep(50);
  if (A.st.myBoard.cells.filter(c => c.s).length !== 20) fail('перемешивание: флот исказился');
  ok('перемешивание: случайный флот сразу готов');

  // чат: текст + эмодзи
  let chatMsg = null, imgMsg = null;
  B.onChat = m => { if (!chatMsg) chatMsg = m; if (m.img) imgMsg = m; };
  A.send({ t: 'chat', msg: 'к бою! ⚓' });
  for (let i = 0; i < 100 && !chatMsg; i++) await sleep(50);
  if (!chatMsg || chatMsg.msg !== 'к бою! ⚓') fail('чат: сообщение с эмодзи не дошло');
  ok('чат работает (включая эмодзи)');

  // чат: картинки — валидную доставляем, слишком большую отклоняем
  let bigImgErr = null;
  A.onErr = m => { if (/Картинка не прошла/.test(m)) bigImgErr = m; else if (/касаться|пересекаются/.test(m)) { /* выше */ } else A.errors.push(m + ' (' + A.name + ')'); };
  A.send({ t: 'chat', msg: 'смотри', img: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=' });
  for (let i = 0; i < 100 && !imgMsg; i++) await sleep(50);
  if (!imgMsg || !String(imgMsg.img).startsWith('data:image/') || imgMsg.msg !== 'смотри') fail('чат: картинка не дошла');
  A.send({ t: 'chat', msg: '', img: 'data:image/png;base64,' + 'A'.repeat(500000) });
  for (let i = 0; i < 100 && !bigImgErr; i++) await sleep(50);
  if (!bigImgErr) fail('чат: слишком большую картинку не отклонили');
  ok('чат: картинки (отправка + отклонение большой) — ок');

  // бой до победы
  A.send({ t: 'battle' });
  for (let i = 0; i < 100 && A.st.phase !== 'battle'; i++) await sleep(50);
  if (A.st.phase !== 'battle') fail('бой не начался');
  ok('бой начался');
  if (!(await fightTo(A, B, 90000))) fail('бой не завершился за 90 с');
  const w = A.st.winner;
  if (w !== 0 && w !== 1) fail('победителя нет');
  const wSt = w === A.st.mySeat ? A.st : B.st;
  const dmg = wSt.enemyBoard.filter(v => v >= 2).length;
  if (dmg !== 20) fail('победитель не потопил все 20 клеток (' + dmg + ')');
  ok('бой доигран: победитель — ' + A.st.winnerName + ', весь чужой флот уничтожен');

  // повторный выстрел в ту же клетку — ошибка
  A.send({ t: 'newGame' });
  for (let i = 0; i < 100 && A.st.phase !== 'setup'; i++) await sleep(50);
  if (A.st.phase !== 'setup') fail('newGame: новая расстановка не началась');
  await placeBoth(A, B);
  A.send({ t: 'battle' });
  for (let i = 0; i < 100 && A.st.phase !== 'battle'; i++) await sleep(50);
  let dupErr = null, lastA = null;
  A.onErr = m => { if (/уже стреляли/.test(m)) dupErr = m; };
  const tDup = Date.now();
  while (!dupErr && Date.now() - tDup < 90000) {
    if (A.st.phase === 'over') { // бой закончился раньше — начинаем новый
      lastA = null;
      A.send({ t: 'newGame' });
      for (let i = 0; i < 100 && A.st.phase !== 'setup'; i++) await sleep(50);
      await placeBoth(A, B);
      A.send({ t: 'battle' });
      for (let i = 0; i < 100 && A.st.phase !== 'battle'; i++) await sleep(50);
      continue;
    }
    if (A.st.phase === 'battle') {
      if (A.st.turn === A.st.mySeat) {
        const s = lastA || nextShot(A.st);
        if (s) { A.send({ t: 'fire', x: s.x, y: s.y }); if (!lastA) lastA = s; }
      } else {
        const sb = nextShot(B.st);
        if (sb) B.send({ t: 'fire', x: sb.x, y: sb.y }); // B — ассистент, ходы идут быстро
      }
    }
    await sleep(60);
  }
  if (!dupErr) fail('повторный выстрел: не отклонён');
  ok('повторный выстрел в ту же клетку — отклонён');

  // ре-коннект в середине боя: B обрывает связь и возвращается
  const bPid = B.st.myId, bSeat = B.st.mySeat;
  const shotsBefore = B.st.enemyBoard.filter(v => v !== 0).length;
  B.ws.close();
  await sleep(600);
  B.done = false;
  await B.connect();
  if (!B.st || B.st.myId !== bPid || B.st.mySeat !== bSeat) fail('ре-коннект: место/id не сохранились');
  const shotsAfter = B.st.enemyBoard.filter(v => v !== 0).length;
  if (shotsAfter < shotsBefore) fail('ре-коннект: выстрелы потеряны (' + shotsAfter + ' < ' + shotsBefore + ')');
  ok('ре-коннект в бою: место и доска сохранены');
  if (B.st.phase === 'battle' && !(await fightTo(A, B, 90000))) fail('второй бой не завершился за 90 с');
  ok('второй бой доигран (победитель: ' + B.st.winnerName + ')');

  // бот-соперник
  B.send({ t: 'leave' });
  for (let i = 0; i < 100 && A.st.seats.filter(Boolean).length !== 1; i++) await sleep(50);
  A.send({ t: 'addBot' });
  for (let i = 0; i < 100 && !A.st.seats.some(s => s && s.bot); i++) await sleep(50);
  if (!A.st.seats.some(s => s && s.bot)) fail('бот не появился');
  if (A.st.phase !== 'setup') fail('с ботом не началась расстановка');
  if (A.st.oppReady !== true) fail('бот должен быть готов сразу');
  A.send({ t: 'placed', ships: TEST_FLEET });
  for (let i = 0; i < 100 && !(A.st.myReady && A.st.oppReady); i++) await sleep(50);
  if (!(A.st.myReady && A.st.oppReady)) fail('расстановка с ботом не подтверждена');
  ok('бот-соперник за столом (расставлен сам), A расставился');
  A.send({ t: 'battle' });
  let botFired = false, aTurnUsed = false;
  const tBot = Date.now();
  while (!botFired && Date.now() - tBot < 90000) {
    if (A.st.phase === 'battle' && A.st.turn === A.st.mySeat && !aTurnUsed) {
      // A стреляет раз и «сдаёт» ход (иначе бот будет ждать 30-сек таймер)
      const s = nextShot(A.st);
      if (s) { A.send({ t: 'fire', x: s.x, y: s.y }); aTurnUsed = true; }
    }
    if (A.st.phase === 'battle' && A.st.turn !== A.st.mySeat) aTurnUsed = false;
    await sleep(100);
    if (A.st.myBoard && A.st.myBoard.cells.some(c => c.h > 0)) botFired = true;
  }
  if (!botFired) fail('бот не стрелял за 90 с');
  ok('бот стреляет');

  A.send({ t: 'leave' });
  const errs = [...A.errors, ...B.errors];
  if (errs.length) fail('ошибки сервера: ' + errs.join(' ; '));
  ok('ошибок сервера нет');
  console.log('PASS: морской бой — ручная расстановка, бой до победы, повторный выстрел, ре-коннект, чат (эмодзи+картинки), бот.');
  A.ws.close(); B.ws.close(); try { C.ws.close(); } catch (e) {}
  process.exit(0);
})().catch(e => fail(String(e && e.stack || e)));
