// Подпольный ЯМЗ — игры для локальной сети: покер (Texas Hold'em, 2–9 игроков)
// и морской бой (10×10, на двоих). Корень — лобби выбора игр, /poker и /boy.
// Хостит ваш компьютер: другие люди в локалке открывают https://<ваш-IP>:4180
// (если рядом лежат server.crt/server.key — сервер работает в TLS:
//  трафик по сети шифруется и не читается) и играют как отдельные
// игроки (каждый — свой браузер).
//
// Запуск:   node serve.js          (или «Запустить-покер.bat»)
// Порт:     переменная окружения PORT (по умолчанию 4180)
// IP:       переменная окружения IP — свой адрес, который показать игрокам
//           (например, set IP=192.168.31.99); по умолчанию — все найденные
//
// Только встроенные модули Node: http, fs, path, os, crypto.
// WebSocket (RFC6455) реализован вручную, без npm-пакетов.
'use strict';
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const boy = require('./battleship'); // ⚓ морской бой (свой WS: /ws-boy)
const champ = require('./championship'); // 🏆 «Чемпионат ЯМЗ»: общий рейтинг по всем играм
const ludo = require('./ludo');         // 🎲 лото (свой WS: /ws-ludo)
const mafia = require('./mafia');       // 🕵️ мафия (свой WS: /ws-mafia)
const monopoly = require('./monopoly'); // 🎩 монополия (свой WS: /ws-monopoly)

const APP_DIR = __dirname;
let PORT = parseInt(process.env.PORT || '4180', 10);

// ---------- TLS: шифрование трафика (самознаковый сертификат) ----------
// Если рядом лежат server.key + server.crt — сервер стартует в HTTPS/WSS,
// и содержимое (страницы, игры, чат, картинки) по сети не читается.
// Сертификат генерируется один раз (OpenSSL):
//   openssl req -x509 -newkey rsa:2048 -sha256 -nodes -days 3650 \
//     -keyout server.key -out server.crt -subj "/CN=office" \
//     -addext "subjectAltName=DNS:localhost,IP:127.0.0.1"
let TLS = null;
try {
  const keyF = path.join(APP_DIR, 'server.key');
  const crtF = path.join(APP_DIR, 'server.crt');
  if (fs.existsSync(keyF) && fs.existsSync(crtF)) {
    TLS = { key: fs.readFileSync(keyF), cert: fs.readFileSync(crtF) };
  }
} catch (e) { console.log('⚠ TLS: сертификат не загрузился (' + (e && e.message || e) + ') — запускаюсь без шифрования'); }

// ---------- настройки игры (меняются из панели хоста) ----------
const SEATS = 9;            // мест за столом
const HANDS_TO_END = 6000;  // пауза после showdown перед следующей раздачей
const AUTO_START_MS = 8000; // авто-раздача: задержка между руками
const BETTING = new Set(['pre', 'flop', 'turn', 'river']);
const settings = {
  sb: 10, bb: 20, startChips: 1000, turnSec: 30,
  auto: false,
  tournament: { on: false, level: 0, hands: 0, baseSb: 10, baseBb: 20, champion: null },
};
function curSB() { const t = settings.tournament; return t.on ? t.baseSb * (t.level + 1) : settings.sb; }
function curBB() { const t = settings.tournament; return t.on ? t.baseBb * (t.level + 1) : settings.bb; }
function turnMs() { return settings.turnSec * 1000; }

// ---------- состояние стола ----------
let idc = 0;
const seats = Array.from({ length: SEATS }, () => null); // игрок или null
const spectators = []; // наблюдатели (место не занимают)
const game = {
  phase: 'waiting', // waiting | pre | flop | turn | river | showdown | idle | champion
  handNo: 0, deck: [], board: [], pot: 0,
  currentBet: 0, lastRaise: 0,
  dealer: -1, actor: -1, turnDeadline: 0,
  winners: null,
  logs: [], chat: [],
  endHandTimer: null, autoTimer: null,
};

// ---------- утилиты карт ----------
const RANK_NAME = { 14: 'Т', 13: 'Д', 12: 'В', 11: 'Ю', 10: '10', 9: '9', 8: '8', 7: '7', 6: '6', 5: '5', 4: '4', 3: '3', 2: '2' };
const SUIT_CHAR = ['♠', '♥', '♦', '♣'];
const SUIT_RED = [false, true, true, false];
const HAND_NAMES = ['', 'Пара', 'Две пары', 'Тройка', 'Стрит', 'Флеш', 'Фулл-хаус', 'Каре', 'Стрит-флеш'];
function cardStr(c) { return RANK_NAME[c.r] + SUIT_CHAR[c.s]; }
function cardsStr(cs) { return cs.map(cardStr).join(' '); }
function makeDeck() {
  const d = [];
  for (let s = 0; s < 4; s++) for (let r = 2; r <= 14; r++) d.push({ r, s });
  for (let i = d.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [d[i], d[j]] = [d[j], d[i]]; }
  return d;
}

// оценка 5 карт -> [категория, доп...] (больше = сильнее)
function rank5(c5) {
  const flush = c5.every(c => c.s === c5[0].s);
  const ranks = c5.map(c => c.r).sort((a, b) => b - a);
  let straightHigh = 0;
  const uniq = [...new Set(ranks)];
  if (uniq.length === 5) {
    if (uniq[0] - uniq[4] === 4) straightHigh = uniq[0];
    else if (uniq[0] === 14 && uniq[1] === 5) straightHigh = 5; // колес
  }
  const cnt = {};
  for (const r of ranks) cnt[r] = (cnt[r] || 0) + 1;
  const groups = Object.keys(cnt).map(Number).sort((a, b) => cnt[b] - cnt[a] || b - a);
  const cat =
    flush && straightHigh ? 8 :
    cnt[groups[0]] === 4 ? 7 :
    cnt[groups[0]] === 3 && cnt[groups[1]] === 2 ? 6 :
    flush ? 5 :
    straightHigh ? 4 :
    cnt[groups[0]] === 3 ? 3 :
    cnt[groups[0]] === 2 && cnt[groups[1]] === 2 ? 2 :
    cnt[groups[0]] === 2 ? 1 : 0;
  let kicks;
  if (cat === 8) kicks = [straightHigh];
  else if (cat === 7) kicks = [groups[0], groups[1]];
  else if (cat === 6) kicks = [groups[0], groups[1]];
  else if (cat === 5) kicks = ranks;
  else if (cat === 4) kicks = [straightHigh];
  else if (cat === 3) kicks = groups; // [trips, k, k]
  else if (cat === 2) kicks = [groups[0], groups[1], groups[2]];
  else if (cat === 1) kicks = groups;
  else kicks = ranks;
  return [cat, ...kicks];
}
function rank7(cards7) {
  let best = null;
  const n = cards7.length;
  for (let a = 0; a < n - 4; a++) for (let b = a + 1; b < n - 3; b++) for (let c = b + 1; c < n - 2; c++)
    for (let d = c + 1; d < n - 1; d++) for (let e = d + 1; e < n; e++) {
      const r = rank5([cards7[a], cards7[b], cards7[c], cards7[d], cards7[e]]);
      if (!best || cmpRank(r, best) > 0) best = r;
    }
  return best;
}
function cmpRank(a, b) { for (let i = 0; i < Math.max(a.length, b.length); i++) { const x = a[i] || 0, y = b[i] || 0; if (x !== y) return x - y; } return 0; }

// ---------- лог ----------
function log(msg) {
  game.logs.push({ h: game.handNo, t: msg, ts: Date.now() });
  if (game.logs.length > 80) game.logs.shift();
  console.log(msg);
}

// ---------- игроки ----------
function players() { return seats.filter(Boolean); }
function inHand(p) { return !!p && !p.folded; }
function playerById(id) { return players().find(p => p.id === id) || null; }
function nextSeat(from) {
  for (let i = 1; i <= SEATS; i++) { const s = seats[(from + i) % SEATS]; if (s) return (from + i) % SEATS; }
  return -1;
}
function nextSeatChips(from) {
  for (let i = 1; i <= SEATS; i++) { const s = seats[(from + i) % SEATS]; if (s && s.chips > 0) return (from + i) % SEATS; }
  return -1;
}
function nextCanActAfter(from) {
  for (let i = 1; i <= SEATS; i++) {
    const p = seats[(from + i) % SEATS];
    if (p && !p.folded && !p.allIn) return p.seat;
  }
  return -1;
}
function totalPot() { return game.pot + players().reduce((s, p) => s + p.bet, 0); }

function sitOut(p) {
  seats[p.seat] = null;
  p.seat = -1; p.connected = false;
  if (p.ws) { try { p.ws.destroy(); } catch (e) {} }
  log(p.name + ' завершил работу');
  broadcast();
}

function join(ws, name, pid, spectate, uid) {
  name = String(name || '').trim().slice(0, 20) || 'Игрок';
  // ре-коннект: тот же pid или то же имя (разъединённый)
  let ex = null;
  if (pid) ex = playerById(pid) || spectators.find(s => s.id === pid) || null;
  if (!ex) ex = players().find(p => p.name === name && !p.connected && !p.isBot) || null;
  if (ex) {
    if (ex.ws && ex.ws !== ws) { try { ex.ws.destroy(); } catch (e) {} } // мигрируем сессию
    ex.ws = ws; ex.connected = true;
    if (uid) ex.uid = uid;
    log(ex.name + ' снова на связи');
    return ex;
  }
  if (spectate) {
    const s = {
      id: 's' + (++idc), name, seat: -1, chips: 0, uid: uid || null,
      spectate: true, connected: true, ws, isBot: false,
      botTimer: null, goneTimer: null,
      totalDelta: 0, handsWon: 0, prevChips: 0,
    };
    spectators.push(s);
    log(name + ' — режим просмотра');
    return s;
  }
  const seat = seats.indexOf(null);
  if (seat === -1) return { err: 'Стол полон — подождите, пока кто-то выйдет' };
  const p = {
    id: 'p' + (++idc), name, seat, uid: uid || null,
    chips: settings.startChips, bet: 0, contrib: 0, cards: [],
    folded: false, allIn: false, acted: false, reveal: false,
    isBot: false, connected: true, ws, botTimer: null, goneTimer: null,
    totalDelta: 0, handsWon: 0, prevChips: 0,
  };
  seats[seat] = p;
  log(name + ' начал работу (старт ' + settings.startChips + ')');
  return p;
}

// «Чемпионат ЯМЗ»: записать результат раздачи — победителю очки, остальным обнуляем серию
function recordHand(winnersArr) {
  for (const w of winnersArr) {
    const p = players().find(q => q.id === w.id);
    if (p && !p.isBot) champ.recordWin(p.uid, p.name, 'poker', champ.POINTS.poker);
  }
  for (const p of players()) {
    if (p.isBot || p.spectate) continue;
    const won = winnersArr.some(w => w.id === p.id);
    if (!won && p.prevChips > 0) champ.recordLoss(p.uid, p.name);
  }
}

// ---------- фишки ----------
function payIn(p, amount, what) {
  const pay = Math.min(amount, p.chips);
  p.chips -= pay; p.bet += pay; p.contrib += pay;
  if (p.chips === 0) p.allIn = true;
  if (pay > 0) log(p.name + (what ? ' ' + what + ' ' + pay : ' внес(ла) ' + pay));
  return pay;
}

// ---------- цикл раздачи ----------
function canStart() {
  return (game.phase === 'waiting' || game.phase === 'idle') &&
    players().filter(p => p.chips > 0).length >= 2;
}

function startHand() {
  if (!canStart()) return;
  clearTimeout(game.endHandTimer);
  clearTimeout(game.autoTimer); game.autoTimer = null;
  const withChips = players().filter(p => p.chips > 0).length;
  if (withChips < 2) return;
  game.handNo++; game.board = []; game.pot = 0; game.winners = null;
  game.phase = 'pre'; game.actor = -1;
  game.dealer = nextSeatChips(game.dealer);
  for (const p of players()) {
    p.cards = []; p.bet = 0; p.contrib = 0; p.folded = false;
    p.allIn = false; p.acted = false; p.reveal = false; p.sb = p.bb = false;
    p.prevChips = p.chips; // для статистики: чистый результат раздачи
    if (p.botTimer) { clearTimeout(p.botTimer); p.botTimer = null; }
    if (p.chips === 0) { p.folded = true; log(p.name + (settings.tournament.on ? ' — выбыл, пропуск' : ' без баланса — пропуск цикла')); }
  }
  game.deck = makeDeck();
  for (const p of players()) if (!p.folded) p.cards = [game.deck.pop(), game.deck.pop()];
  log('— Цикл #' + game.handNo + (settings.tournament.on ? ' (турнир) — ' : ' — ') + curSB() + '/' + curBB() + ' —');
  const sbSeat = withChips === 2 ? game.dealer : nextSeatChips(game.dealer); // heads-up: дилер — МБ
  const bbSeat = nextSeatChips(sbSeat);
  const sbP = seats[sbSeat], bbP = seats[bbSeat];
  sbP.sb = true; bbP.bb = true;
  for (const p of players()) { if (p !== sbP && p !== bbP) p.sb = p.bb = false; }
  payIn(sbP, curSB(), '— начисление И1');
  payIn(bbP, curBB(), '— начисление И2');
  startRound();
}

function startRound() {
  for (const p of players()) if (inHand(p) && !p.allIn) p.acted = false;
  if (game.phase === 'pre') {
    const bb = seats.find(x => x && x.bb);
    game.currentBet = bb ? Math.min(curBB(), bb.bet) : 0;
  } else game.currentBet = 0;
  game.lastRaise = curBB();
  const from = game.phase === 'pre' ? seats.findIndex(x => x && x.bb) : game.dealer;
  setActor(nextCanActAfter(from));
}

function setActor(seat) {
  game.actor = seat;
  const p = seat >= 0 ? seats[seat] : null;
  game.turnDeadline = p ? Date.now() + turnMs() : 0;
  if (p && p.isBot) scheduleBot(p);
  broadcast();
}

function scheduleBot(p) {
  if (p.botTimer) clearTimeout(p.botTimer);
  p.botTimer = setTimeout(() => {
    p.botTimer = null;
    if (game.actor === p.seat && BETTING.has(game.phase) && inHand(p)) botAct(p);
  }, 900 + Math.random() * 2000);
}

function applyAction(p, a, to) {
  if (!p || game.actor !== p.seat || !BETTING.has(game.phase) || !inHand(p)) return 'Сейчас не ваш ход';
  if (p.botTimer) { clearTimeout(p.botTimer); p.botTimer = null; }
  if (a === 'fold') {
    p.folded = true;
    log(p.name + ' снялся');
  } else if (a === 'check') {
    if (p.bet < game.currentBet) return 'Нужно коллировать ' + (game.currentBet - p.bet);
    p.acted = true;
    log(p.name + ' — без изменений');
  } else if (a === 'call') {
    const pay = Math.min(game.currentBet - p.bet, p.chips);
    if (pay <= 0) return 'Ставка уже внесена — можно чекнуть';
    p.chips -= pay; p.bet += pay; p.contrib += pay;
    if (p.chips === 0) { p.allIn = true; log(p.name + ' — весь баланс (' + p.bet + ')'); }
    else log(p.name + ' подтверждает ' + pay);
    p.acted = true;
  } else if (a === 'raise') {
    to = Math.floor(Number(to));
    const pay = to - p.bet;
    if (!Number.isFinite(to) || pay <= 0) return 'Некорректная ставка';
    if (pay > p.chips) return 'Недостаточно фишек';
    const inc = to - game.currentBet;
    const isAllIn = pay === p.chips;
    if (inc < game.lastRaise && !isAllIn) return 'Минимальный рейз — до ' + (game.currentBet + game.lastRaise);
    p.chips -= pay; p.bet = to; p.contrib += pay;
    if (isAllIn) { p.allIn = true; log(p.name + ' — весь баланс (' + to + ')'); }
    else { p.acted = true; log(p.name + ' увеличивает до ' + to); }
    const reopen = inc >= game.lastRaise || isAllIn;
    if (inc >= game.lastRaise) game.lastRaise = inc;
    if (reopen) {
      for (const q of players()) if (q !== p && inHand(q) && !q.allIn) q.acted = false;
    }
  } else return 'Неизвестное действие';
  game.currentBet = Math.max(game.currentBet, p.bet);
  afterAction();
  return null;
}

function afterAction() {
  const alive = players().filter(inHand);
  if (alive.length <= 1) {
    // все бросили — забираем банк
    for (const p of players()) { game.pot += p.bet; p.bet = 0; }
    if (alive.length === 1) {
      const w = alive[0];
      w.chips += game.pot;
      w.handsWon++;
      game.winners = [{ id: w.id, name: w.name, amount: game.pot, hand: 'все сдались' }];
      log(w.name + ' закрывает: ' + game.pot + ' (все снялись)');
      recordHand(game.winners); // 🏆 чемпионат ЯМЗ
    }
    game.phase = 'showdown'; game.actor = -1;
    broadcast();
    game.endHandTimer = setTimeout(endHand, 4000);
    return;
  }
  const pending = players().filter(p => inHand(p) && !p.allIn && (!p.acted || p.bet < game.currentBet));
  if (pending.length === 0) { endRound(); return; }
  const na = nextCanActAfter(game.actor);
  if (na === -1) { endRound(); return; } // страховка от зацикливания
  setActor(na);
}

function endRound() {
  for (const p of players()) { game.pot += p.bet; p.bet = 0; }
  const canAct = players().filter(p => inHand(p) && !p.allIn).length;
  if (game.phase === 'pre') { game.phase = 'flop'; game.board.push(game.deck.pop(), game.deck.pop(), game.deck.pop()); log('Этап 2: ' + cardsStr(game.board)); }
  else if (game.phase === 'flop') { game.phase = 'turn'; game.board.push(game.deck.pop()); log('Этап 3: ' + cardStr(game.board[3])); }
  else if (game.phase === 'turn') { game.phase = 'river'; game.board.push(game.deck.pop()); log('Этап 4: ' + cardStr(game.board[4])); }
  else if (game.phase === 'river') { doShowdown(); return; }
  if (canAct <= 1) { // доигрываем добор без ставок
    while (game.board.length < 5) game.board.push(game.deck.pop());
    log('Добор до этапа 4: ' + cardsStr(game.board));
    doShowdown();
    return;
  }
  startRound();
}

function distribute() {
  const contenders = players().filter(inHand);
  const all = players();
  const levels = [...new Set(all.map(p => p.contrib).filter(v => v > 0))].sort((a, b) => a - b);
  const gained = new Map();
  let prev = 0;
  for (const L of levels) {
    let slice = 0;
    for (const p of all) slice += Math.min(p.contrib, L) - Math.min(p.contrib, prev);
    const elig = contenders.filter(p => p.contrib >= L);
    if (slice > 0 && elig.length > 0) {
      let best = null;
      const scored = elig.map(p => ({ p, r: rank7(p.cards.concat(game.board)) }));
      for (const s of scored) if (!best || cmpRank(s.r, best) > 0) best = s.r;
      const winners = scored.filter(s => cmpRank(s.r, best) === 0).map(s => s.p);
      const share = Math.floor(slice / winners.length);
      let rem = slice - share * winners.length;
      const order = [...winners].sort((a, b) => ((a.seat - game.dealer + SEATS) % SEATS) - ((b.seat - game.dealer + SEATS) % SEATS));
      for (const p of order) { const g = share + (rem > 0 ? 1 : 0); if (rem > 0) rem--; gained.set(p.id, (gained.get(p.id) || 0) + g); }
    }
    prev = L;
  }
  // остаток от округления (на всякий случай) — первому претенденту
  const awarded = [...gained.values()].reduce((s, v) => s + v, 0);
  if (awarded < game.pot && contenders.length) {
    const f = contenders[0];
    gained.set(f.id, (gained.get(f.id) || 0) + (game.pot - awarded));
  }
  return gained;
}

function doShowdown() {
  game.phase = 'showdown'; game.actor = -1;
  for (const p of players()) if (inHand(p)) p.reveal = true;
  const gained = distribute();
  const winners = [];
  for (const p of players()) {
    const g = gained.get(p.id) || 0;
    if (g > 0) {
      p.chips += g;
      p.handsWon++;
      const best = rank7(p.cards.concat(game.board));
      winners.push({ id: p.id, name: p.name, amount: g, hand: HAND_NAMES[best[0]] });
    }
  }
  winners.sort((a, b) => b.amount - a.amount);
  game.winners = winners;
  for (const w of winners) log(w.name + ' закрывает: ' + w.amount + ' (' + w.hand + ')');
  recordHand(winners); // 🏆 чемпионат ЯМЗ
  broadcast();
  game.endHandTimer = setTimeout(endHand, HANDS_TO_END);
}

function endHand() {
  for (const p of players()) {
    if (p.isBot && p.chips === 0 && !settings.tournament.on) {
      p.chips = settings.startChips; log(p.name + ' пополнил баланс');
    }
    p.sb = p.bb = false;
    p.totalDelta += p.chips - p.prevChips; // чистый результат раздачи (сумма по столу = 0)
  }
  // ушедшие во время раздачи и не вернувшиеся — место освобождается
  for (const p of [...players()]) {
    if (!p.isBot && !p.connected) { log(p.name + ' — не вернулся, место освобождено'); sitOut(p); }
  }
  // турнир: рост блайндов и определение чемпиона
  if (settings.tournament.on) {
    settings.tournament.hands++;
    const alive = players().filter(p => p.chips > 0);
    if (alive.length <= 1) {
      settings.tournament.champion = alive.length === 1 ? alive[0].name : null;
      game.phase = 'champion'; game.actor = -1; game.winners = null;
      game.board = []; game.pot = 0;
      log('Турнир завершён! Победитель: ' + (settings.tournament.champion || 'нет (все выбыли)'));
      if (alive.length === 1 && !alive[0].isBot) champ.recordWin(alive[0].uid, alive[0].name, 'champ', champ.POINTS.champ); // 🏆 титул
      broadcast();
      return;
    }
    if (settings.tournament.hands % 5 === 0) {
      settings.tournament.level++;
      log('Уровень начислений ' + settings.tournament.level + ': ' + curSB() + '/' + curBB());
    }
  }
  game.phase = 'idle'; game.actor = -1;
  game.winners = null;
  game.board = []; game.pot = 0; // не оставляем старый борд/банк между раздачами
  maybeAutoStart();
  broadcast();
}

// авто-раздача: планируем следующую руку (из endHand или при включении в настройках)
function maybeAutoStart() {
  if (!settings.auto || !canStart()) return;
  clearTimeout(game.autoTimer);
  game.autoTimer = setTimeout(() => {
    game.autoTimer = null;
    if (canStart()) { log('Авто-цикл: старт…'); startHand(); }
  }, AUTO_START_MS);
  log('Авто-цикл: следующий через ' + (AUTO_START_MS / 1000) + ' с');
}

// ---------- боты ----------
function addBot(sender) {
  if (!canStart()) return { err: 'Ботов можно добавлять только между раздачами' };
  const seat = seats.indexOf(null);
  if (seat === -1) return { err: 'Стол полон' };
  let n = players().filter(p => p.isBot).length + 1;
  let name = 'Бот-' + n;
  while (players().some(p => p.name === name)) name = 'Бот-' + (++n);
  const p = {
    id: 'p' + (++idc), name, seat,
    chips: settings.startChips, bet: 0, contrib: 0, cards: [],
    folded: false, allIn: false, acted: false, reveal: false,
      isBot: true, connected: true, ws: null, botTimer: null, goneTimer: null,
     totalDelta: 0, handsWon: 0, prevChips: 0,
  };
  seats[seat] = p;
  log(name + ' начал работу (авт.)');
  broadcast();
  return null;
}

function botAct(p) {
  const toCall = game.currentBet - p.bet;
  const pot = totalPot();
  let strength;
  if (game.phase === 'pre') {
    const [c1, c2] = p.cards;
    let s = 0.18 + ((c1.r + c2.r) / 28) * 0.4;
    if (c1.r === c2.r) s += 0.35;
    if (c1.s === c2.s) s += 0.08;
    if (Math.abs(c1.r - c2.r) <= 2 && c1.r !== c2.r) s += 0.05;
    strength = Math.min(0.95, s + Math.random() * 0.12);
  } else {
    const best = rank7(p.cards.concat(game.board));
    const base = [0.3, 0.48, 0.62, 0.72, 0.85, 0.88, 0.95, 0.99, 0.999][best[0]];
    strength = Math.min(0.97, base + Math.random() * 0.08);
  }
  const maxTo = p.bet + p.chips;
  const minTo = Math.min(maxTo, game.currentBet + game.lastRaise);
  const err = (m) => { console.log('[bot] ' + p.name + ': ' + m); };
  try {
    if (toCall <= 0) {
      if (strength > 0.72 && p.chips > 0 && Math.random() < 0.6) {
        const target = Math.min(maxTo, Math.max(minTo, game.currentBet + Math.max(curBB(), Math.round(pot * (0.5 + Math.random() * 0.6) / curBB()) * curBB())));
        if (target > game.currentBet) return applyAction(p, 'raise', target);
      }
      return applyAction(p, 'check');
    }
    const risk = toCall / Math.max(1, pot + toCall);
    if (strength > 0.78 && Math.random() < 0.5 && toCall < p.chips) {
      const target = Math.min(maxTo, Math.max(minTo, game.currentBet + Math.max(curBB(), Math.round(pot * (0.5 + Math.random() * 0.8) / curBB()) * curBB())));
      if (target > game.currentBet) return applyAction(p, 'raise', target);
    }
    if (strength > 0.32 + risk * 0.45) return applyAction(p, 'call');
    return applyAction(p, 'fold');
  } catch (e) { err(String(e && e.message || e)); }
}

// ---------- таймеры ----------
setInterval(() => {
  if (BETTING.has(game.phase) && game.actor >= 0 && Date.now() > game.turnDeadline) {
    const p = seats[game.actor];
    if (p) {
      log(p.name + ' — время вышло');
      applyAction(p, p.bet >= game.currentBet ? 'check' : 'fold');
    }
  }
}, 1000);

// ---------- состояние для клиента ----------
function top3() {
  return players()
    .map(p => ({ name: p.name, delta: p.totalDelta, won: p.handsWon }))
    .sort((a, b) => b.delta - a.delta)
    .slice(0, 3);
}
function stateFor(p) {
  const st = {
    t: 'state',
    phase: game.phase, handNo: game.handNo,
    board: game.board.map(c => ({ r: c.r, s: c.s })),
    pot: totalPot(),
    currentBet: game.currentBet,
    dealer: game.dealer, actor: game.actor,
    turnDeadline: game.turnDeadline, turnMs: turnMs(),
    minRaiseTo: game.actor >= 0 ? game.currentBet + game.lastRaise : 0,
    maxRaiseTo: 0,
    canStart: canStart(),
    myId: p ? p.id : null,
    myCards: p && !p.spectate ? p.cards.map(c => ({ r: c.r, s: c.s })) : null,
    myChips: p ? p.chips : 0,
    mySeat: p ? p.seat : -1,
    spectating: !!(p && p.spectate),
    canSeat: seats.some(s => !s),
    winners: game.winners,
    top: top3(),
    settings: {
      sb: settings.sb, bb: settings.bb, startChips: settings.startChips,
      turnSec: settings.turnSec, auto: settings.auto,
      tournament: settings.tournament.on, tLevel: settings.tournament.level,
      champion: settings.tournament.champion,
    },
    seats: seats.map((sp, i) => sp ? {
      idx: i, id: sp.id, name: sp.name,
      chips: sp.chips, bet: sp.bet,
      folded: sp.folded, allIn: sp.allIn,
      out: settings.tournament.on && sp.chips === 0,
      connected: sp.connected, bot: sp.isBot,
      dealer: i === game.dealer, sb: !!sp.sb, bb: !!sp.bb,
      isActor: i === game.actor,
      reveal: sp.reveal,
       delta: sp.totalDelta, won: sp.handsWon,
      cards: (sp.reveal || (p && sp === p)) && sp.cards.length ? sp.cards.map(c => ({ r: c.r, s: c.s })) : null,
    } : { idx: i, empty: true }),
    logs: game.logs.slice(-40),
    chat: game.chat.slice(-25),
    sb: curSB(), bb: curBB(),
  };
  if (p && !p.spectate && game.actor === p.seat && BETTING.has(game.phase)) {
    st.canAct = true;
    st.maxRaiseTo = p.bet + p.chips;
  }
  return st;
}
function broadcast() {
  const st = players().map(p => stateFor(p));
  players().forEach((p, i) => send(p, st[i]));
  for (const s of spectators) send(s, stateFor(null));
}
function send(p, obj) {
  if (p && p.ws) {
    try { p.ws.write(wsFrame(0x1, Buffer.from(JSON.stringify(obj), 'utf8'))); } catch (e) {}
  }
}

// ---------- WebSocket (RFC6455, вручную) ----------
const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
function wsFrame(opcode, payload) {
  const len = payload.length;
  let head;
  if (len < 126) head = Buffer.from([0x80 | opcode, len]);
  else if (len < 65536) { head = Buffer.alloc(4); head[0] = 0x80 | opcode; head[1] = 126; head.writeUInt16BE(len, 2); }
  else { head = Buffer.alloc(10); head[0] = 0x80 | opcode; head[1] = 127; head.writeBigUInt64BE(BigInt(len), 2); }
  return Buffer.concat([head, payload]);
}

function handleWs(sock, conn) {
  sock.setNoDelay && sock.setNoDelay(true);
  let buf = Buffer.alloc(0);
  sock.on('data', d => {
    buf = Buffer.concat([buf, d]);
    if (buf.length > 2e6) { closeWs(conn); return; }
    while (buf.length >= 2) {
      const b1 = buf[0], b2 = buf[1];
      const opcode = b1 & 0x0f;
      const masked = b2 & 0x80;
      let len = b2 & 0x7f; let off = 2;
      if (len === 126) { if (buf.length < off + 2) return; len = buf.readUInt16BE(off); off += 2; }
      else if (len === 127) { if (buf.length < off + 8) return; len = Number(buf.readBigUInt64BE(off)); off += 8; }
      if (len > 1e6) { closeWs(conn); return; }
      let mask = null;
      if (masked) { if (buf.length < off + 4) return; mask = buf.slice(off, off + 4); off += 4; }
      if (buf.length < off + len) return;
      let payload = Buffer.from(buf.slice(off, off + len));
      buf = buf.slice(off + len);
      if (masked) for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
      if (opcode === 0x8) { closeWs(conn); return; }
      else if (opcode === 0x9) { try { sock.write(wsFrame(0xA, payload)); } catch (e) {} }
      else if (opcode === 0xA) { conn.lastSeen = Date.now(); }
      else if (opcode === 0x1 || opcode === 0x0) { handleMsg(conn, payload.toString('utf8')); }
    }
  });
  sock.on('close', () => onDrop(conn));
  sock.on('error', () => onDrop(conn));
  conn.lastSeen = Date.now();
}

function closeWs(conn) {
  if (conn.closed) return;
  conn.closed = true;
  try { conn.sock.write(wsFrame(0x8, Buffer.from([]))); } catch (e) {}
  setTimeout(() => { try { conn.sock.destroy(); } catch (e) {} }, 300);
}

function onDrop(conn) {
  const p = conn.player;
  // если игрок уже пере-подключился на новый сокет — этот сбой его не касается
  if (p && p.ws === conn.sock) {
    p.connected = false;
    p.ws = null; p.wsConn = null;
    if (p.spectate) {
      const i = spectators.indexOf(p);
      if (i >= 0) spectators.splice(i, 1);
      log(p.name + ' — ушёл из режима просмотра');
      broadcast();
      return;
    }
    if (p.isBot) return;
    log(p.name + ' — нет соединения');
    if (p.botTimer) { clearTimeout(p.botTimer); p.botTimer = null; }
    // между раздачами даём 60 с на возврат (случайный обрыв), во время
    // раздачи — до конца руки (endHand освобождает место), край — 10 минут
    const grace = (game.phase === 'waiting' || game.phase === 'idle') ? 60000 : 10 * 60000;
    if (p.goneTimer) clearTimeout(p.goneTimer);
    p.goneTimer = setTimeout(() => {
      if (!p.connected) { log(p.name + ' — место освобождено (не вернулся)'); sitOut(p); }
    }, grace);
    broadcast();
  }
}

function handleMsg(conn, text) {
  let m;
  try { m = JSON.parse(text); } catch (e) { return; }
  conn.lastSeen = Date.now();
  let p = conn.player;
  if (!p) {
    if (m.t !== 'join') return;
    p = join(conn.sock, m.name, m.pid, !!m.spectate, m.uid);
    if (p && p.err) { sendRaw(conn, { t: 'error', msg: p.err }); return; }
    if (p) { conn.player = p; p.wsConn = conn; }
    send(p, stateFor(p));
    return;
  }
  if (m.t !== 'chat' && m.t !== 'join' && p.spectate) {
    send(p, { t: 'error', msg: 'Наблюдателям доступны только зрительский режим и чат' });
    return;
  }
  switch (m.t) {
    case 'join': {
      // наблюдатель решает сесть за стол
      if (!p.spectate) return;
      if (seats.indexOf(null) === -1) { send(p, { t: 'error', msg: 'Стол полон — пока понаблюдайте' }); return; }
      const i = spectators.indexOf(p);
      if (i >= 0) spectators.splice(i, 1);
      const np = join(conn.sock, p.name, null, false, p.uid);
      if (np && np.err) { send(p, { t: 'error', msg: np.err }); return; }
      conn.player = np;
      send(np, stateFor(np));
      break;
    }
    case 'action': {
      const e = applyAction(p, m.a, m.to);
      if (e) send(p, { t: 'error', msg: e });
      break;
    }
    case 'start': {
      if (!canStart()) send(p, { t: 'error', msg: 'Нельзя начать: нужно минимум 2 игрока с фишками' });
      else startHand();
      break;
    }
    case 'addBot': {
      const e = addBot(p);
      if (e) send(p, { t: 'error', msg: e.err });
      break;
    }
    case 'bots': {
      // хост: точное количество ботов (добавить/убрать до нужного числа)
      if (!canStart()) { send(p, { t: 'error', msg: 'Ботов можно менять только между раздачами' }); break; }
      let n = Math.floor(Number(m.n));
      if (!Number.isFinite(n) || n < 0) n = 0;
      n = Math.min(n, seats.filter(s => !s).length); // не больше свободных мест
      const botCount = () => players().filter(q => q.isBot).length;
      let guard = 0;
      while (botCount() < n && seats.some(s => !s) && guard++ < 20) addBot(p);
      while (botCount() > n && guard++ < 20) {
        const bots = players().filter(q => q.isBot);
        const b = bots[bots.length - 1];
        log(b.name + ' ушёл (авт.)');
        sitOut(b);
      }
      broadcast();
      break;
    }
    case 'removeBot': {
      const b = playerById(m.id);
      if (b && b.isBot && canStart()) { log(b.name + ' ушёл (авт.)'); sitOut(b); }
      break;
    }
    case 'settings': {
      // панель хоста: блайнды / стартовые фишки / время на ход / авто-раздача
      if (!canStart()) { send(p, { t: 'error', msg: 'Настройки — только между раздачами' }); break; }
      const iv = v => { const x = Math.floor(Number(v)); return Number.isFinite(x) ? x : null; };
      let nsb = settings.sb, nbb = settings.bb, nsc = settings.startChips, nts = settings.turnSec;
      const x = iv(m.sb); if (x !== null) nsb = x;
      const y = iv(m.bb); if (y !== null) nbb = y;
      const z = iv(m.startChips); if (z !== null) nsc = z;
      const w = iv(m.turnSec); if (w !== null) nts = w;
      if (nsb < 1 || nsb > 100000 || nbb < 2 || nbb > 200000 || nsb >= nbb) {
        send(p, { t: 'error', msg: 'Блайнды: МБ 1..100000, ББ больше МБ, до 200000' }); break;
      }
      if (nsc < 100 || nsc > 1000000) { send(p, { t: 'error', msg: 'Стартовые фишки: 100..1000000' }); break; }
      if (nts < 5 || nts > 120) { send(p, { t: 'error', msg: 'Время на ход: 5..120 секунд' }); break; }
      if (!settings.tournament.on) { settings.sb = nsb; settings.bb = nbb; } // в турнире блайнды растут сами
      settings.startChips = nsc;
      settings.turnSec = nts;
      if (typeof m.auto === 'boolean') {
        settings.auto = m.auto;
        if (m.auto) maybeAutoStart();
        else { clearTimeout(game.autoTimer); game.autoTimer = null; }
      }
      log('Настройки: начисления ' + curSB() + '/' + curBB() + ', старт ' + settings.startChips +
        ', ход ' + settings.turnSec + ' с, авто ' + (settings.auto ? 'вкл' : 'выкл'));
      broadcast();
      break;
    }
    case 'tournament': {
      if (!canStart()) { send(p, { t: 'error', msg: 'Турнир — только между раздачами' }); break; }
      if (m.on) {
        settings.tournament = { on: true, level: 0, hands: 0, baseSb: settings.sb, baseBb: settings.bb, champion: null };
        log('ТУРНИР НАЧАЛ: без докупов, начисления растут каждые 5 циклов (' + curSB() + '/' + curBB() + ')');
      } else {
        settings.tournament = { on: false, level: 0, hands: 0, baseSb: settings.sb, baseBb: settings.bb, champion: null };
        log('Турнир остановлен — обычный режим (докупы снова можно)');
      }
      broadcast();
      break;
    }
    case 'newTournament': {
      if (game.phase !== 'champion') { send(p, { t: 'error', msg: 'Новый турнир — после завершения предыдущего' }); break; }
      for (const q of players()) { q.chips = settings.startChips; q.folded = false; q.prevChips = q.chips; }
      settings.tournament = { on: true, level: 0, hands: 0, baseSb: settings.sb, baseBb: settings.bb, champion: null };
      game.phase = 'idle';
      log('Новый турнир: всем по ' + settings.startChips + ' ед., уровень начислений 0');
      broadcast();
      break;
    }
    case 'resetStats': {
      if (!canStart() && game.phase !== 'champion') { send(p, { t: 'error', msg: 'Сброс — только между раздачами' }); break; }
      for (const q of players()) { q.totalDelta = 0; q.handsWon = 0; }
      log('Статистика сброшена');
      broadcast();
      break;
    }
    case 'resetChips': {
      if (!canStart() && game.phase !== 'champion') { send(p, { t: 'error', msg: 'Сброс — только между раздачами' }); break; }
      for (const q of players()) { q.chips = settings.startChips; q.prevChips = settings.startChips; q.totalDelta = 0; q.handsWon = 0; }
      log('Всем — по ' + settings.startChips + ' ед. (статистика сброшена)');
      broadcast();
      break;
    }
    case 'rebuy': {
      if (settings.tournament.on) { send(p, { t: 'error', msg: 'В турнире докупки нет: проиграли фишки — выбыли' }); break; }
      if (!canStart()) { send(p, { t: 'error', msg: 'Докупать можно только между раздачами' }); break; }
      if (p.chips > 0) { send(p, { t: 'error', msg: 'У вас ещё есть фишки' }); break; }
      p.chips = settings.startChips;
      log(p.name + ' пополнил баланс (+' + settings.startChips + ' ед.)');
      break;
    }
    case 'leave': {
      if (!canStart()) { send(p, { t: 'error', msg: 'Выйти можно только между раздачами' }); break; }
      sitOut(p);
      break;
    }
    case 'chat': {
      const txt = String(m.msg || '').trim().slice(0, 200);
      let img = null;
      if (m.img) {
        // картинка: dataURL от клиента (сам сжимает), в истории держим только флажок
        if (typeof m.img === 'string' && m.img.startsWith('data:image/') && m.img.length <= 400000) img = m.img;
        else if (!txt) { send(p, { t: 'error', msg: 'Картинка не прошла: только JPG/PNG, до ~300 КБ' }); return; }
      }
      if (!txt && !img) return;
      game.chat.push({ from: p.name, bot: p.isBot, msg: txt, img: img ? true : null, ts: Date.now() });
      if (game.chat.length > 100) game.chat.shift();
      const live = { t: 'chat', from: p.name, bot: p.isBot, msg: txt };
      if (img) live.img = img;
      for (const q of players()) send(q, live);
      for (const q of spectators) send(q, live);
      break;
    }
    case 'setBack': {
      send(p, { t: 'error', msg: 'Графические шаблоны отключены: используются текстовые ячейки' });
      break;
    }
  }
}
function sendRaw(conn, obj) {
  if (conn.player && conn.player.ws === conn.sock) send(conn.player, obj);
  else { try { conn.sock.write(wsFrame(0x1, Buffer.from(JSON.stringify(obj), 'utf8'))); } catch (e) {} }
}

// ping/keepalive
setInterval(() => {
  for (const p of [...players(), ...spectators]) {
    if (!p.ws) continue;
    try { p.ws.write(wsFrame(0x9, Buffer.from([]))); } catch (e) {}
    if (Date.now() - ((p.wsConn && p.wsConn.lastSeen) || 0) > 75000) {
      log(p.name + ' — нет ответа');
      try { p.ws.destroy(); } catch (e) {}
    }
  }
}, 25000);

// ---------- HTTP: статика + upgrade ----------
function json(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}
const httpHandler = (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  const u = new URL(req.url, 'http://localhost');
  if (u.pathname === '/api/games') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({
      poker: { players: players().length, phase: game.phase },
      boy: boy.boyStatus(),
      ludo: ludo.ludoStatus(),
      mafia: mafia.mafiaStatus(),
      monopoly: monopoly.monopolyStatus(),
    }));
    return;
  }
  if (u.pathname === '/api/championship' && req.method === 'GET') {
    // рейтинг: топ + «я» (по yz_uid и/или имени)
    const me = u.searchParams.get('uid');
    const meName = u.searchParams.get('name');
    json(res, 200, { top: champ.top(5), me: (me || meName) ? champ.byUid(me, meName) : null });
    return;
  }
  if (u.pathname === '/api/avatar' && req.method === 'POST') {
    json(res, 410, { ok: false, err: 'Графические аватары отключены: используется текстовый ID' });
    return;
  }
  let p = decodeURIComponent(u.pathname);
  if (p === '/' || p === '/index.html') p = '/lobby.html';        // корень — комната выбора игр
  else if (p === '/poker' || p === '/poker/') p = '/index.html';  // покер
  else if (p === '/boy' || p === '/boy/') p = '/boy.html';        // морской бой
  else if (p === '/ludo' || p === '/ludo/') p = '/ludo.html';     // лото
  else if (p === '/mafia' || p === '/mafia/') p = '/mafia.html';  // мафия
  else if (p === '/monopoly' || p === '/monopoly/') p = '/monopoly.html'; // монополия
  const full = path.resolve(APP_DIR, '.' + p);
  if (!full.startsWith(APP_DIR + path.sep)) { res.writeHead(403); res.end('forbidden'); return; }
  fs.readFile(full, (err, buf) => {
    if (err) { res.writeHead(404); res.end('not found'); return; }
    const ct = full.endsWith('.html') ? 'text/html; charset=utf-8'
      : full.endsWith('.js') ? 'text/javascript; charset=utf-8'
      : full.endsWith('.css') ? 'text/css; charset=utf-8'
      : 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': ct });
    res.end(buf);
  });
};
const server = TLS ? https.createServer(TLS, httpHandler) : http.createServer(httpHandler);

server.on('upgrade', (req, socket) => {
  const u = new URL(req.url, 'http://localhost');
  if (u.pathname === '/ws-boy') { boy.handleBoyUpgrade(req, socket); return; }
  if (u.pathname === '/ws-ludo') { ludo.handleLudoUpgrade(req, socket); return; }
  if (u.pathname === '/ws-mafia') { mafia.handleMafiaUpgrade(req, socket); return; }
  if (u.pathname === '/ws-monopoly') { monopoly.handleMonopolyUpgrade(req, socket); return; }
  if (u.pathname !== '/ws') { socket.write('HTTP/1.1 404 Not Found\r\n\r\n'); socket.destroy(); return; }
  const key = req.headers['sec-websocket-key'];
  if (!key) { socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + WS_GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  const conn = { sock: socket, player: null, closed: false, lastSeen: Date.now() };
  // lastSeen обновляем на каждом входящем фрагменте (для keepalive)
  socket.on('data', () => { conn.lastSeen = Date.now(); });
  handleWs(socket, conn);
});

const LAN_IP = String(process.env.IP || '').trim(); // свой IP для игроков (set IP=...)
const SCHEME = TLS ? 'https' : 'http';
const onListening = port => {
  console.log('Подпольный ЯМЗ:   ' + SCHEME + '://127.0.0.1:' + port + (TLS ? '   (TLS: трафик шифрован)' : '   (без TLS: нет server.crt/server.key рядом)'));
  const detected = [];
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) for (const net of nets[name] || []) {
    if (net.family === 'IPv4' && !net.internal) detected.push(net.address);
  }
  const show = LAN_IP && detected.includes(LAN_IP) ? [LAN_IP] : detected;
  if (LAN_IP && !detected.includes(LAN_IP)) {
    console.log('⚠ IP ' + LAN_IP + ' не найден среди адресов машины — показываю найденные:');
  }
  for (const a of show) console.log('По Wi-Fi/LAN:       ' + SCHEME + '://' + a + ':' + port + (show.length === 1 ? '   (указанный вами IP)' : ''));
  console.log('Игры: выбор — корневой адрес · покер /poker · морской бой /boy · лото /ludo · мафия /mafia · монополия /monopoly');
  console.log('Игроки заходят по адресу "По Wi-Fi/LAN" и играют каждый со своим браузером.');
  if (TLS) console.log('TLS: первое открытие покажет предупреждение о сертификате — это нормально (Далее → Продолжить); без предупреждения: добавить server.crt в доверенные сертификаты.');
  console.log('Свой IP: перед запуском set IP=192.168.x.x — тогда покажется только он.');
  console.log('Стоп: Ctrl+C в этом окне (для тихого запуска: «Остановить_сервер.bat» на 4180; на 443 — node.exe в диспетчере).');
};
server.on('error', e => {
  // Порт 443 на Windows требует прав администратора: тихо уходим на 4180,
  // чтобы «set PORT=443» никогда не ломал запуск.
  if ((e.code === 'EACCES' || e.code === 'EPERM') && PORT !== 4180) {
    console.log('⚠ Порт ' + PORT + ' не открыть без прав администратора — переключаюсь на 4180.');
    PORT = 4180;
    server.removeAllListeners('error');
    server.listen(PORT, '0.0.0.0', () => onListening(PORT));
    return;
  }
  console.error('Сервер не запустился: ' + e.message);
  process.exit(1);
});
server.listen(PORT, '0.0.0.0', () => onListening(PORT));
