@echo off
rem ============================================================
rem  FlyNav uninstaller - PURE CMD (no PowerShell).
rem  Removes only %APPDATA%\FreeCAD\v*\Mod\FlyNav  (user folder,
rem  no admin rights needed). Restart FreeCAD afterwards.
rem  ASCII only inside this file.
rem ============================================================
setlocal enabledelayedexpansion
title FlyNav remove (cmd)

set "FOUND=0"
for /d %%V in ("%APPDATA%\FreeCAD\v*") do call :TRYDEL "%%~fV"

echo.
if "%FOUND%"=="0" echo   Nothing to remove: no FlyNav found in %APPDATA%\FreeCAD\v*\Mod
echo   Done. Restart FreeCAD to see the change.
echo.
pause
exit /b 0

:TRYDEL
set "ROOT=%~1"
set "DST=%ROOT%\Mod\FlyNav"
if not exist "%DST%" goto :EOF
rmdir /s /q "%DST%" 2>nul
if exist "%DST%" (echo   [FAIL] still there: %DST% & goto :EOF)
echo   removed   %DST%
set "FOUND=1"
goto :EOF
