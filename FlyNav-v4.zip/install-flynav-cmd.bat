@echo off
rem ============================================================
rem  FlyNav installer - PURE CMD version, no PowerShell needed.
rem  Use this when corporate policy blocks .ps1 scripts.
rem
rem  1) unzip the whole archive to any folder (e.g. Desktop)
rem  2) close FreeCAD
rem  3) double click this file
rem  4) start FreeCAD again  ->  menu "FlyNav", hotkey Ctrl+Shift+F
rem
rem  No admin rights needed: the mod goes to %APPDATA%\FreeCAD\v1-1\Mod
rem  (that folder belongs to the user and is always writable).
rem  Nothing is downloaded, nothing is registered, Python is not required:
rem  FreeCAD uses its own built-in Python.
rem  ASCII only inside this file: cmd reads .bat in the OEM codepage.
rem ============================================================
setlocal enabledelayedexpansion
title FlyNav install (cmd)

set "SRC=%~dp0FlyNav"
if not exist "%SRC%\InitGui.py" goto NO_STRUCT

set "FOUND=0"
for /d %%V in ("%APPDATA%\FreeCAD\v*") do call :TRYDIR "%%~fV"

echo.
if "%FOUND%"=="0" goto NOTFOUND
echo   Next: close FreeCAD and open it again (mods load at startup).
echo   Then: menu  FlyNav   or   Ctrl+Shift+F   , keys WASD, Esc = exit.
echo   More: README.txt  (section 7 = troubleshooting)
echo.
pause
exit /b 0

:NOTFOUND
echo   [!] No FreeCAD config folder found: %APPDATA%\FreeCAD\v*
echo       Start FreeCAD once, then run this file again.
echo       Or copy folder "FlyNav" manually - see README.txt section 3.
echo.
pause
exit /b 2

:NO_STRUCT
echo   [!] Folder "FlyNav" with InitGui.py not found next to this file.
echo       Unzip the WHOLE archive first (right click -> Extract All),
echo       do not run from inside the zip window.
echo.
pause
exit /b 1

:TRYDIR
set "ROOT=%~1"
if not exist "%ROOT%\Mod" mkdir "%ROOT%\Mod" 2>nul
if not exist "%ROOT%\Mod" goto SKIP
set "DST=%ROOT%\Mod\FlyNav"
if exist "%DST%" rmdir /s /q "%DST%" 2>nul
xcopy /e /i /q /y "%SRC%" "%DST%" >nul
if errorlevel 1 goto FAILCOPY
if not exist "%DST%\InitGui.py" goto FAILCOPY
if exist "%DST%\__pycache__" rmdir /s /q "%DST%\__pycache__" 2>nul
echo   installed   %DST%
set "FOUND=1"
goto :EOF
:FAILCOPY
echo   [FAIL] cannot write to %DST%
goto :EOF
:SKIP
echo   [skip] cannot create %ROOT%\Mod
goto :EOF
