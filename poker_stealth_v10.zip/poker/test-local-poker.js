// Авто-тест локального покера. Запуск (пока работает node serve.js):
//   node test-local-poker.js
// Проверяет: чат, рубашку, ботов «сколько хочешь», 5 раздач, ре-коннект,
// настройки стола, авто-раздачу, нулевую сумму статистики, наблюдателя
// и полный цикл турнира (чемпион → новый турнир).
'use strict';
const PORT = process.env.PORT || '4180';
const URL = 'ws://127.0.0.1:' + PORT + '/ws';
const HANDS = 5;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const fail = msg => { console.error('FAIL: ' + msg); process.exit(1); };
const ok = msg => console.log('ok: ' + msg);
let aggressive = false;

function client(name, pid, spectate) {
  const c = { name, pid, ws: null, st: null, errors: [] };
  c.connect = () => new Promise((resolve, reject) => {
    const ws = new WebSocket(URL);
    c.ws = ws;
    const t = setTimeout(() => reject(new Error('таймаут соединения ' + name)), 5000);
    ws.onopen = () => {
      ws.send(JSON.stringify({ t: 'join', name, pid: pid || null, spectate: !!spectate }));
    };
    ws.onmessage = ev => {
      const m = JSON.parse(ev.data);
      if (m.t === 'state') { c.st = m; if (!c.stDone) { c.stDone = true; clearTimeout(t); resolve(c); } }
      else if (m.t === 'error') { if (c.onErr) c.onErr(m.msg); else c.errors.push(m.msg + ' (' + name + ')'); }
      else if (m.t === 'chat') { if (c.onChat) c.onChat(m); }
      else if (m.t === 'back') { if (c.onBack) c.onBack(m); }
    };
    ws.onerror = () => { clearTimeout(t); reject(new Error('ws error ' + name)); };
    ws.onclose = () => { c.dead = true; };
  });
  c.send = o => { if (c.ws && c.ws.readyState === 1) c.ws.send(JSON.stringify(o)); };
  return c;
}

function decide(st) {
  const my = st.seats[st.mySeat];
  if (!my) return { a: 'fold' };
  if (aggressive) { // турнирный режим: сразу оуин
    if (st.maxRaiseTo > st.currentBet) return { a: 'raise', to: st.maxRaiseTo };
    if (st.currentBet > my.bet) return { a: 'call' };
    return { a: 'check' };
  }
  const toCall = st.currentBet - my.bet;
  if (toCall <= 0) {
    if (st.maxRaiseTo > st.currentBet && Math.random() < 0.35)
      return { a: 'raise', to: Math.min(st.minRaiseTo, st.maxRaiseTo) };
    return { a: 'check' };
  }
  if (Math.random() < 0.2) return { a: 'fold' };
  return { a: 'call' };
}

(async () => {
  const A = client('Тест-А');
  const B = client('Тест-Б');
  await A.connect();
  await B.connect();
  ok('два клиента подключены: ' + A.st.myId + ', ' + B.st.myId);
  if (A.st.mySeat === B.st.mySeat) fail('оба сидят на одном месте');

  // добавить бота
  A.send({ t: 'addBot' });
  for (let i = 0; i < 100 && !A.st.seats.some(s => s && s.bot); i++) await sleep(100);
  if (!A.st.seats.some(s => s && s.bot)) fail('бот не добавился');
  ok('бот за столом');

  // чат: A пишет, B получает (текст + эмодзи)
  let chatMsg = null, imgMsg = null;
  B.onChat = m => { if (!chatMsg) chatMsg = m; if (m.img) imgMsg = m; };
  A.send({ t: 'chat', msg: 'привет 👋' });
  for (let i = 0; i < 100 && !chatMsg; i++) await sleep(50);
  if (!chatMsg || chatMsg.msg !== 'привет 👋' || chatMsg.from !== 'Тест-А') fail('чат: сообщение с эмодзи не дошло');
  ok('чат работает (включая эмодзи)');

  // чат: картинки — валидную доставляем, слишком большую отклоняем
  let bigImgErr = null;
  A.onErr = msg => { if (/Картинка не прошла/.test(msg)) bigImgErr = msg; else A.errors.push(msg + ' (' + A.name + ')'); };
  A.send({ t: 'chat', msg: 'смотри', img: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=' });
  for (let i = 0; i < 100 && !imgMsg; i++) await sleep(50);
  if (!imgMsg || !String(imgMsg.img).startsWith('data:image/') || imgMsg.msg !== 'смотри') fail('чат: картинка не дошла');
  A.send({ t: 'chat', msg: '', img: 'data:image/png;base64,' + 'A'.repeat(500000) });
  for (let i = 0; i < 100 && !bigImgErr; i++) await sleep(50);
  if (!bigImgErr) fail('чат: слишком большую картинку не отклонили');
  ok('чат: картинки (отправка + отклонение большой) — ок');

  // боты «сколько хочешь»: точное число от хоста
  const botCnt = () => A.st.seats.filter(s => s && s.bot).length;
  A.send({ t: 'bots', n: 2 });
  for (let i = 0; i < 200 && botCnt() !== 2; i++) await sleep(100);
  if (botCnt() !== 2) fail('боты: не удалось выставить 2');
  A.send({ t: 'bots', n: 1 });
  for (let i = 0; i < 200 && botCnt() !== 1; i++) await sleep(100);
  if (botCnt() !== 1) fail('боты: не удалось вернуть к 1');
  ok('боты: точное количество от хоста (2 → 1) — ок');

  // настройки стола: применить и вернуть
  A.send({ t: 'settings', sb: 5, bb: 10, startChips: 1000, turnSec: 30 });
  for (let i = 0; i < 200 && !(A.st.sb === 5 && A.st.bb === 10); i++) await sleep(100);
  if (!(A.st.sb === 5 && A.st.bb === 10)) fail('настройки: 5/10 не применились');
  A.send({ t: 'settings', sb: 10, bb: 20 });
  for (let i = 0; i < 200 && !(A.st.sb === 10 && A.st.bb === 20); i++) await sleep(100);
  if (!(A.st.sb === 10 && A.st.bb === 20)) fail('настройки: 10/20 не вернулись');
  ok('настройки стола: применить/вернуть — ок');

  // ---------- 5 раздач + авто-раздача + ре-коннект + статистика ----------
  let cur = A.st.handNo;
  let handsDone = 0;
  let lastSig = '', stuckAt = 0;
  const t0 = Date.now();
  let reconnected = false;
  let autoEnabled = false, autoOk = false, turnAutoOff = false, autoExpect = -1, autoAt = 0;

  while (handsDone < HANDS && Date.now() - t0 < 180000) {
    for (const c of [A, B]) {
      if (c.st && c.st.canAct) c.send(Object.assign({ t: 'action' }, decide(c.st)));
    }
    const a = A.st;
    if (a.phase === 'idle' && a.handNo !== cur) {
      const dsum = a.seats.reduce((s, sp) => s + (sp.empty ? 0 : (sp.delta || 0)), 0);
      if (dsum !== 0) fail('статистика не в ноль: ' + dsum + ' (раздача ' + a.handNo + ')');
      cur = a.handNo;
      handsDone++;
      if (turnAutoOff) { A.send({ t: 'settings', auto: false }); turnAutoOff = false; }
      if (!autoEnabled && handsDone === 1) {
        // тест авто-раздачи: включаем и НЕ жмём «Раздать»
        A.send({ t: 'settings', auto: true });
        autoEnabled = true; autoExpect = a.handNo; autoAt = Date.now(); turnAutoOff = true;
        ok('авто-тест: включено после #' + a.handNo + ', ждём автостарт');
        lastSig = '';
        continue;
      }
      ok('раздача #' + a.handNo + ' завершена (статистика в ноль)');
      if (handsDone < HANDS) A.send({ t: 'start' });
      lastSig = '';
      continue;
    }
    if (autoEnabled && !autoOk) {
      if (a.handNo === autoExpect + 1 && a.phase !== 'idle') {
        autoOk = true;
        ok('авто-раздача: рука #' + a.handNo + ' стартовала сама');
      } else if (Date.now() - autoAt > 20000) fail('авто-раздача: рука не стартовала за 20 с');
    }
    // тест ре-коннекта: в середине раздачи #3 B обрывает связь и возвращается
    if (!reconnected && a.phase === 'pre' && a.handNo === 3) {
      const pid = B.st.myId, seat = B.st.mySeat;
      B.ws.close();
      await sleep(500);
      B.stDone = false;
      await B.connect();
      if (B.st.myId !== pid || B.st.mySeat !== seat)
        fail('ре-коннект: место или id изменились (' + B.st.myId + '/' + B.st.mySeat + ')');
      ok('ре-коннект B в середине раздачи: место и фишки сохранены (' + B.st.seats[seat].chips + ')');
      reconnected = true;
    }
    // запуск первой раздачи
    if (a.phase !== 'idle' && cur === a.handNo && a.handNo === 0) A.send({ t: 'start' });
    // детект зависания
    const sig = a.phase + '|' + a.actor + '|' + a.handNo + '|' + a.board.length + '|' + a.pot;
    if (sig !== lastSig) { lastSig = sig; stuckAt = Date.now(); }
    else if (Date.now() - stuckAt > 45000) fail('зависло в состоянии: ' + sig);
    await sleep(120);
  }

  if (handsDone < HANDS) fail('сыграно только ' + handsDone + ' из ' + HANDS);
  if (!autoOk) fail('авто-раздача не подтвердилась');
  if (!reconnected) fail('ре-коннект не подтвердился');

  // ---------- турнир ----------
  aggressive = true;
  A.send({ t: 'settings', sb: 2, bb: 4, startChips: 100, turnSec: 30 });
  for (let i = 0; i < 200 && !(A.st.sb === 2 && A.st.bb === 4 && A.st.settings.startChips === 100); i++) await sleep(100);
  if (!(A.st.sb === 2 && A.st.bb === 4)) fail('турнир: настройки 2/4/100 не применились');
  A.send({ t: 'bots', n: 0 });
  for (let i = 0; i < 200 && botCnt() !== 0; i++) await sleep(100);
  if (botCnt() !== 0) fail('турнир: боты не убраны');
  A.send({ t: 'resetChips' });
  for (let i = 0; i < 200 && !A.st.seats.every(s => s.empty || s.chips === 100); i++) await sleep(100);
  if (!A.st.seats.every(s => s.empty || s.chips === 100)) fail('турнир: фишки не сброшены до 100');
  ok('турнир готов: 2/4, всем по 100, без ботов');

  // наблюдатель: подключается и смотрит турнир
  const S = client('Вики', null, true);
  await S.connect();
  if (!S.st.spectating) fail('наблюдатель: статус не получен');
  let specChat = null;
  A.onChat = m => { if (m.from === 'Вики') specChat = m; };
  S.send({ t: 'chat', msg: 'смотрю' });
  for (let i = 0; i < 100 && !specChat; i++) await sleep(50);
  if (!specChat) fail('наблюдатель: чат не дошёл');
  ok('наблюдатель: подключён, чат работает');

  A.send({ t: 'tournament', on: true });
  for (let i = 0; i < 200 && !(A.st.settings && A.st.settings.tournament); i++) await sleep(100);
  if (!A.st.settings.tournament) fail('турнир: не начался');
  ok('турнир начат (без докупов, блайнды растут каждые 5 раздач)');

  const t0t = Date.now();
  let champ = null;
  while (!champ && Date.now() - t0t < 120000) {
    for (const c of [A, B]) if (c.st && c.st.canAct) c.send(Object.assign({ t: 'action' }, decide(c.st)));
    const a = A.st;
    if (a.phase === 'champion') { champ = a.settings.champion; break; }
    if (a.phase === 'idle') A.send({ t: 'start' });
    await sleep(120);
  }
  if (!champ) fail('турнир: чемпиона нет за 2 минуты');
  ok('турнир: ЧЕМПИОН — ' + champ);
  if (S.st.phase !== 'champion') fail('наблюдатель: не получил финал турнира');
  const dsum = A.st.seats.reduce((s, sp) => s + (sp.empty ? 0 : (sp.delta || 0)), 0);
  if (dsum !== 0) fail('турнир: статистика не в ноль: ' + dsum);
  ok('наблюдатель видел финал, статистика в ноль');

  A.send({ t: 'newTournament' });
  for (let i = 0; i < 200 && !(A.st.settings.tournament && A.st.seats.every(s => s.empty || s.chips === 100)); i++) await sleep(100);
  if (!A.st.seats.every(s => s.empty || s.chips === 100)) fail('новый турнир: фишки не сброшены');
  ok('новый турнир: все снова с 100');

  // наблюдатель берёт место за столом
  S.send({ t: 'join', name: 'Вики' });
  for (let i = 0; i < 200 && !(S.st && S.st.mySeat >= 0); i++) await sleep(100);
  if (S.st.mySeat < 0) fail('наблюдатель: не смог сесть за стол');
  ok('наблюдатель: сел за стол (место ' + S.st.mySeat + ')');

  // возврат в обычный режим и чистый стол
  A.send({ t: 'tournament', on: false });
  A.send({ t: 'settings', sb: 10, bb: 20, startChips: 1000, turnSec: 30 });
  for (let i = 0; i < 200 && !(A.st.sb === 10 && A.st.bb === 20 && A.st.settings.startChips === 1000 && !A.st.settings.tournament); i++) await sleep(100);
  if (A.st.settings.tournament || A.st.bb !== 20) fail('не вернулись в обычный режим');
  A.send({ t: 'resetChips' });
  aggressive = false;
  ok('обратились в обычный режим (10/20, по 1000)');

  const errs = [...A.errors, ...B.errors, ...S.errors];
  if (errs.length) fail('ошибки сервера: ' + errs.join(' ; '));
  ok('ошибок сервера нет');
  console.log('PASS: 5 раздач + авто-раздача + статистика + ре-коннект + турнир (чемпион: ' + champ + ') + наблюдатель.');
  A.ws.close(); B.ws.close(); S.ws.close();
  process.exit(0);
})().catch(e => fail(String(e && e.stack || e)));
