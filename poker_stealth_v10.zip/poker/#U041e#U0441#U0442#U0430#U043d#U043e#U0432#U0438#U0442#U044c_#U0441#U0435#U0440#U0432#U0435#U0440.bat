@echo off
chcp 65001 >nul
set found=0
for /f "tokens=5" %%a in ('netstat -ano ^| findstr "LISTENING" ^| findstr ":4180 "') do (
  set found=1
  taskkill /F /PID %%a >nul 2>&1
)
if "%found%"=="1" (echo Сервер остановлен (порт 4180).) else (echo Порт 4180 не прослушивается — сервер не запущен.)
pause
