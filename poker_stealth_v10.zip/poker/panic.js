// ============================================================
//  Подпольный ЯМЗ — «босс-режим» 3.0 (общий модуль паники)
//
//  Экстренный экран: игра и все её окна скрываются, остаётся
//  настоящая книга Excel, ЗАПОЛНЕННАЯ правдоподобным рабочим
//  отчётом (отгрузки за месяц с формулами) — не пустой лист.
//
//  Горячие клавиши (работают всегда, даже при вводе в чат):
//    Esc            — скрыть / показать игру
//    ` (клавиша Ё)  — скрыть / показать игру
//    Shift два раза быстро — мгновенно скрыть
//  Автоскрытие: ушли на другое окно / вкладку (Alt+Tab, клик
//  мимо браузера) — игра прячется сама. Вкл/выкл — переключатель
//  «Автосохранение» в заголовке книги (маскировка под Excel).
//  Игра продолжает работать в фоне, соединение не рвётся.
//
//  API: window.YAMZ_PANIC = { show, hide, toggle, isOn, setAuto, getAuto }
// ============================================================
(function () {
  'use strict';
  if (window.YAMZ_PANIC) return;

  let on = false;
  const AKEY = 'yz_autohide';
  let auto = (function () { try { return localStorage.getItem(AKEY) !== '0'; } catch (_) { return true; } })();

  // ---------- стили ----------
  const style = document.createElement('style');
  style.textContent = `
body.yzp-on #yg-layer > *{display:none !important;}
body.yzp-on .ow-main > :not(.ow-grid){visibility:hidden !important;}
#yz-panic-fallback{position:fixed; inset:0; z-index:1000; background:#f2f2f2; display:none;}
/* переключатель «Автосохранение» в заголовке (как в Excel 365) */
#yz-auto{display:inline-flex; align-items:center; gap:6px; margin-left:10px; font:12px 'Segoe UI',system-ui,sans-serif;
  color:#fff; cursor:pointer; user-select:none; opacity:.95; white-space:nowrap;}
#yz-auto .sw{position:relative; width:30px; height:14px; border:1px solid #fff; border-radius:8px; box-sizing:border-box;}
#yz-auto .sw::after{content:''; position:absolute; top:2px; left:2px; width:8px; height:8px; border-radius:50%; background:#fff; transition:left .12s;}
#yz-auto.on .sw{background:rgba(255,255,255,.25);}
#yz-auto.on .sw::after{left:18px;}`;
  document.head.appendChild(style);

  const fallback = document.createElement('div');
  fallback.id = 'yz-panic-fallback';
  (document.body || document.documentElement).appendChild(fallback);

  // ---------- правдоподобный рабочий отчёт для листа ----------
  function reportData() {
    const firms = ['ООО «Техснаб»', 'АО «Волгаметалл»', 'ООО «Промресурс»', 'ПАО «Автодизель»', 'ООО «СеверТорг»', 'АО «УралКомплект»', 'ООО «Регион-Деталь»'];
    const items = ['Втулка 236-1002', 'Прокладка ГБЦ 238', 'Вал коленчатый 7511', 'Шестерня 236-1029', 'Фильтр топливный', 'Кронштейн 6522', 'Поршень 240-1004', 'Гильза цилиндра', 'Насос водяной 236'];
    const rows = [['Отчёт по отгрузкам продукции за сентябрь'], [],
      ['Дата', '№ накладной', 'Контрагент', 'Номенклатура', 'Кол-во, шт', 'Цена, руб', 'Сумма, руб', 'НДС 20%', 'Статус']];
    let seed = 7;
    const rnd = n => { seed = (seed * 9301 + 49297) % 233280; return Math.floor(seed / 233280 * n); };
    const st = ['Отгружено', 'Отгружено', 'Оплачено', 'В пути', 'Отгружено'];
    for (let i = 0; i < 24; i++) {
      const r = rows.length + 1;
      const d = "'" + String(2 + Math.floor(i * 1.2)).padStart(2, '0') + '.09.2025';
      rows.push([d, 'ТН-' + (4120 + i * 3 + rnd(3)), firms[rnd(firms.length)], items[rnd(items.length)],
        10 * (1 + rnd(40)), 150 + rnd(90) * 25, `=E${r}*F${r}`, `=ROUND(G${r}*0.2,2)`, st[rnd(st.length)]]);
    }
    const last = rows.length;
    rows.push([], ['Итого', '', '', '', `=SUM(E4:E${last})`, '', `=SUM(G4:G${last})`, `=SUM(H4:H${last})`],
      ['Средний чек', '', '', '', '', '', `=ROUND(AVERAGE(G4:G${last}),2)`]);
    return rows;
  }
  const hasSheet = () => { try { return typeof hf !== 'undefined' && typeof build === 'function'; } catch (_) { return false; } };
  let savedSheet = null, savedCw, savedMg, savedSt;
  function fillSheet() {
    if (!hasSheet()) return;
    try {
      savedSheet = hf.getSheetSerialized(sid);
      savedCw = cw[sid];
      // объединения и оформление листа (вид «Ячейки») — на время отчёта убрать
      try { savedMg = mgs[sid]; mgs[sid] = []; } catch (_) {}
      savedSt = st[sid]; st[sid] = {};
      hf.setSheetContent(sid, reportData());
      cw[sid] = { 0: 84, 1: 84, 2: 150, 3: 150, 4: 80, 5: 80, 6: 96, 7: 84, 8: 90 };
      build();
    } catch (_) {}
  }
  function restoreSheet() {
    if (!hasSheet() || !savedSheet) return;
    try {
      hf.setSheetContent(sid, savedSheet); cw[sid] = savedCw; st[sid] = savedSt || {};
      try { mgs[sid] = savedMg || []; } catch (_) {}
      build();
    } catch (_) {}
    savedSheet = null;
  }

  function show() {
    if (on) return;
    on = true;
    // фокус из чата/полей игры — чтобы набранный текст не ушёл в игру
    try { if (document.activeElement && document.activeElement !== document.body) document.activeElement.blur(); } catch (_) {}
    window.YG_FOCUS = false;
    document.body.classList.add('yzp-on');
    if (!document.getElementById('yg-layer') && !document.querySelector('.ow-main')) fallback.style.display = 'block';
    fillSheet();
  }
  function hide() {
    if (!on) return;
    on = false;
    document.body.classList.remove('yzp-on');
    fallback.style.display = 'none';
    restoreSheet();
    if (window.YZ_CELLS) window.YZ_CELLS.force();
  }
  function toggle() { if (on) hide(); else show(); }

  // ---------- горячие клавиши ----------
  let lastShift = 0;
  // Esc — на document (всплытие): мост yg-bridge сначала закрывает «Печать»/дизайн
  document.addEventListener('keydown', e => { if (e.key === 'Escape') toggle(); });
  // Ё и двойной Shift — на window (перехват раньше всех, даже раньше ячеек Excel)
  window.addEventListener('keydown', e => {
    if (e.code === 'Backquote' && !e.ctrlKey && !e.altKey && !e.metaKey) {
      e.preventDefault(); e.stopImmediatePropagation();
      toggle();
      return;
    }
    if (e.key === 'Shift' && !e.repeat) {
      const t = Date.now();
      if (t - lastShift < 350) { show(); lastShift = 0; } else lastShift = t;
    } else lastShift = 0;
  }, true);

  // ---------- автоскрытие при уходе из окна ----------
  window.addEventListener('blur', () => { if (auto) show(); });
  document.addEventListener('visibilitychange', () => { if (auto && document.hidden) show(); });

  // ---------- переключатель «Автосохранение» в заголовке ----------
  function mountAuto() {
    const tt = document.getElementById('tt');
    if (!tt || document.getElementById('yz-auto')) return;
    const sw = document.createElement('span');
    sw.id = 'yz-auto';
    sw.title = 'Автосохранение';
    sw.innerHTML = '<span>Автосохранение</span><span class="sw"></span>';
    const ttl = document.getElementById('ttl');
    if (ttl && ttl.parentNode === tt) tt.insertBefore(sw, ttl); else tt.appendChild(sw);
    const sync = () => sw.classList.toggle('on', auto);
    sw.addEventListener('click', () => { setAuto(!auto); sync(); });
    sync();
  }
  function setAuto(v) { auto = !!v; try { localStorage.setItem(AKEY, auto ? '1' : '0'); } catch (_) {} }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mountAuto); else mountAuto();

  window.YAMZ_PANIC = {
    show, hide, toggle,
    isOn: () => on,
    setAuto, getAuto: () => auto,
    setMode: () => {}, getMode: () => 'excel-report',
  };
})();
