// ============================================================
//  cells-boy.js — морской бой прямо в ячейках листа «Контроль»
//  (адаптер для общего движка cells-core.js)
//  Логическая раскладка (её можно двигать в «Дизайн элементов»):
//    A1–A3   — заголовок: название, статус, подсказка
//    B7:K16  — своё поле, N7:W16 — поле соперника, строка 18–19 — флот/счёт
//    A20     — время хода «————»
//    Y2…Y9   — кнопки, Y10… журнал, Y18… комментарии, Y24 — ввод комментария
// ============================================================
(function () {
  'use strict';
  if (!window.YZ_CELLS_CORE) return;
  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));
  const txt = el => el ? el.textContent.replace(/\s+/g, ' ').trim() : '';
  const shown = el => !!el && !el.classList.contains('hidden') && el.style.display !== 'none';
  const boardCells = id => { const a = []; document.querySelectorAll('#' + id + ' .cell[data-i]').forEach(c => { a[+c.dataset.i] = c; }); return a; };
  const fleetText = el => el ? Array.from(el.querySelectorAll('.fship'))
    .map(s => (s.classList.contains('gone') ? 'X' : 'О').repeat(s.querySelectorAll('i').length)).join('  ') : '';
  function mark(cl) {
    if (cl.contains('sunk')) return ['X', { al: 'center', b: true }];
    if (cl.contains('hit')) return ['X', { al: 'center', fg: '#9c0006' }];
    if (cl.contains('miss')) return ['·', { al: 'center', fg: '#8a8a8a' }];
    if (cl.contains('ghost-ok')) return ['о', { al: 'center', fg: '#107c41', b: true }];
    if (cl.contains('ghost-bad')) return ['×', { al: 'center', fg: '#c00000', b: true }];
    if (cl.contains('ship')) return ['О', { al: 'center' }];
    return [null, { al: 'center' }];
  }
  const L = 'АБВГДЕЖЗИК', RC = 24;
  const MY = { r: 6, c: 1 }, EN = { r: 6, c: 13 };
  const BTN_R0 = 1, BTN_N = 8, LOG_H = 9, LOG_R0 = 10, LOG_N = 6, CHAT_H = 17, CHAT_R0 = 18, CHAT_N = 4, CHAT_L = 22, CHAT_IN = 23;
  const COLW = { 0: 28, 11: 20, 12: 28, 23: 20, 24: 300 };
  for (let c = 1; c <= 10; c++) COLW[c] = 24;
  for (let c = 13; c <= 22; c++) COLW[c] = 24;

  YZ_CELLS_CORE.register({
    game: 'boy',
    root: '#app',
    tick: 500,
    blocks: [
      { id: 'head', name: 'Заголовок', r1: 0, r2: 2, c1: 0, c2: 23, cw: false },
      { id: 'my', name: 'Ваше поле', r1: 4, r2: 18, c1: 0, c2: 11 },
      { id: 'en', name: 'Поле соперника', r1: 4, r2: 18, c1: 12, c2: 23 },
      { id: 'timer', name: 'Время хода', r1: 19, r2: 19, c1: 0, c2: 23, cw: false },
      { id: 'panel', name: 'Панель (кнопки, журнал, чат)', r1: 0, r2: 23, c1: 24, c2: 24 },
    ],
    colw: COLW,
    merges: [
      { r1: 0, r2: 0, c1: 0, c2: 22 }, { r1: 1, r2: 1, c1: 0, c2: 22 }, { r1: 2, r2: 2, c1: 0, c2: 22 },
      { r1: 4, r2: 4, c1: 1, c2: 10 }, { r1: 4, r2: 4, c1: 13, c2: 22 },
      { r1: 17, r2: 17, c1: 1, c2: 10 }, { r1: 17, r2: 17, c1: 13, c2: 22 },
      { r1: 18, r2: 18, c1: 1, c2: 10 }, { r1: 19, r2: 19, c1: 0, c2: 22 },
    ],
    chatIn: {
      r: CHAT_IN, c: RC,
      send(v) { const inp = $('#chat-in'); if (inp) { inp.value = v; inp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true })); } },
    },
    hoverLeave(el) { if (el.closest('#my-board')) $('#my-board').dispatchEvent(new MouseEvent('mouseleave')); },
    // R / К — повернуть корабль
    key(e) {
      if (!/^[rRкК]$/.test(e.key)) return false;
      const rot = $('#btn-rotate');
      if (!rot || rot.classList.contains('hidden')) return false;
      rot.click();
      return true;
    },
    compose(k) {
      const put = k.put;
      put(0, 0, 'Контроль поверхности изделия', { b: true, sz: 14 });
      if (!shown($('#app'))) { put(1, 0, 'Документ не открыт — введите имя в окне входа', { fg: '#7f7f7f' }); return; }
      put(1, 0, [txt($('#h-phase')), txt($('#h-score'))].filter(Boolean).join(' · '), { fg: '#595959' });
      const banner = $('#banner');
      let hint = '';
      if (shown(banner)) hint = txt(banner.querySelector('div')) || txt(banner);
      else if (shown($('#place-info'))) hint = txt($('#place-info'));
      else if (shown($('#wait-hint'))) hint = txt($('#wait-hint'));
      put(2, 0, hint, { fg: '#7f7f7f', i: true });

      const tits = $$('#boards .btit');
      put(4, 1, txt(tits[0]) || 'Ваша поверхность', { b: true, al: 'center' });
      put(4, 13, txt($('#en-title')) || 'Контролируемая сторона', { b: true, al: 'center' });
      for (let x = 0; x < 10; x++) {
        put(5, MY.c + x, L[x], { al: 'center', fg: '#7f7f7f' });
        put(5, EN.c + x, L[x], { al: 'center', fg: '#7f7f7f' });
      }
      for (let y = 0; y < 10; y++) {
        put(MY.r + y, 0, y + 1, { al: 'center', fg: '#7f7f7f' });
        put(EN.r + y, 12, y + 1, { al: 'center', fg: '#7f7f7f' });
      }
      const my = boardCells('my-board'), en = boardCells('en-board');
      for (let i = 0; i < 100; i++) {
        const x = i % 10, y = (i / 10) | 0;
        if (my[i]) {
          const [v, s] = mark(my[i].classList), r = MY.r + y, c = MY.c + x;
          put(r, c, v, s); k.click(r, c, my[i]); k.hover(r, c, my[i]); k.ctx(r, c, my[i]);
        }
        if (en[i]) {
          const [v, s] = mark(en[i].classList), r = EN.r + y, c = EN.c + x;
          put(r, c, v, s); k.click(r, c, en[i]);
        }
      }
      put(17, 1, fleetText($('#fleet-my')));
      put(17, 13, txt($('#fleet-en')), { fg: '#595959' });
      if (shown($('#place-queue'))) {
        const q = fleetText($('#place-queue'));
        put(18, 1, q ? 'Осталось: ' + q : '', { fg: '#7f7f7f' });
      }
      const wrap = $('#turnbar-wrap'), bar = $('#turnbar');
      if (wrap && bar && wrap.style.opacity !== '0') {
        const pct = parseFloat(bar.style.width) || 0;
        put(19, 0, pct > 0 ? '—'.repeat(Math.max(1, Math.round(pct / 100 * 60))) : '', { fg: '#8a8a8a' });
      }

      put(0, RC, 'Действия', { b: true });
      const btns = $$('#app > header button').filter(b => !b.classList.contains('yg-hb') && b.id !== 'btn-panic' && shown(b));
      if (shown(banner)) { const nb = banner.querySelector('button'); if (nb) btns.unshift(nb); }
      const cat = $('#app > header a.yh-cat'), close = $('#btn-panic');
      btns.concat(cat ? [cat] : [], close ? [close] : []).slice(0, BTN_N).forEach((b, i) => {
        put(BTN_R0 + i, RC, txt(b), { al: 'center', bg: '#f2f2f2', bt: 1, bb: 1, bl: 1, br: 1 });
        k.click(BTN_R0 + i, RC, b);
      });
      put(LOG_H, RC, 'Журнал', { b: true });
      $$('#log > *').map(txt).filter(Boolean).slice(-LOG_N).forEach((t, i) => put(LOG_R0 + i, RC, t, { fg: '#595959' }));
      put(CHAT_H, RC, 'Комментарии', { b: true });
      $$('#chat-msgs > *').map(txt).filter(Boolean).slice(-CHAT_N).forEach((t, i) => put(CHAT_R0 + i, RC, t, { fg: '#262626' }));
      put(CHAT_L, RC, 'Новый комментарий — в ячейку ниже, Enter ↓', { fg: '#7f7f7f', i: true });
    },
  });
})();
