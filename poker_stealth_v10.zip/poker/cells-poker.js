// ============================================================
//  cells-poker.js — «Расчёт платежей» (покер) прямо в ячейках листа «Расчёт»
//  (адаптер для общего движка cells-core.js)
//    A1–A3    — заголовок: название, цикл/этап/итого, итог цикла
//    A5:H14   — таблица участников: баланс, ставка, отметки, документы (карты)
//    A16…     — общие документы (стол), итого, время хода «————»
//    J…       — кнопки (клик), сумма увеличения (ввести + Enter),
//               авто-участники (число + Enter), журнал, комментарии
//  Всё можно двигать в «Дизайн элементов».
// ============================================================
(function () {
  'use strict';
  if (!window.YZ_CELLS_CORE) return;
  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));
  const txt = el => el ? el.textContent.replace(/\s+/g, ' ').trim() : '';
  const shown = el => !!el && !el.classList.contains('hidden') && el.style.display !== 'none';
  const RC = 9;
  const T0 = 5, TN = 9;
  const BTN_R0 = 1, BTN_N = 6, RS_L = 7, RS_IN = 8, BT_L = 9, BT_IN = 10, LOG_H = 12, LOG_R0 = 13, LOG_N = 5, CH_H = 19, CH_R0 = 20, CH_N = 3, CH_L = 23, CH_IN = 24;
  const COLW = { 0: 34, 1: 170, 2: 90, 3: 70, 4: 130, 5: 92, 6: 92, 7: 70, 8: 20, 9: 320 };
  const MERGES = [0, 1, 2, 17].map(r => ({ r1: r, r2: r, c1: 0, c2: 7 }));
  const cardTxt = c => {
    if (!c) return [null, null];
    if (c.classList.contains('down')) return ['скрыто', { fg: '#a6a6a6', al: 'center', i: true }];
    const rank = txt(c.querySelector('span')), suit = txt(c.querySelector('i'));
    if (!rank) return ['·', { fg: '#bfbfbf', al: 'center' }];
    return [rank + ' ' + suit.toLowerCase(), { al: 'center', b: true, fg: c.classList.contains('red') ? '#c00000' : '#262626', bt: 1, bb: 1, bl: 1, br: 1 }];
  };

  YZ_CELLS_CORE.register({
    game: 'poker',
    root: '#app',
    blocks: [
      { id: 'head', name: 'Заголовок', r1: 0, r2: 2, c1: 0, c2: 8, cw: false },
      { id: 'table', name: 'Участники', r1: 4, r2: 13, c1: 0, c2: 8 },
      { id: 'board', name: 'Общие документы и итого', r1: 15, r2: 17, c1: 0, c2: 8, cw: false },
      { id: 'panel', name: 'Панель (кнопки, суммы, журнал, чат)', r1: 0, r2: CH_IN, c1: RC, c2: RC },
    ],
    colw: COLW,
    merges: MERGES,
    chatIn: {
      r: CH_IN, c: RC,
      send(v) { const inp = $('#chat-in'); if (inp) { inp.value = v; inp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true })); } },
    },
    inputs: () => {
      const a = [];
      if ($('#raise-slider')) a.push({
        r: RS_IN, c: RC,
        send(v) {
          const sl = $('#raise-slider'), n = parseInt(String(v).replace(/\D+/g, ''), 10);
          if (!sl || !Number.isFinite(n)) return;
          sl.value = String(n); sl.dispatchEvent(new Event('input', { bubbles: true }));
          const b = $$('#btns button.b-raise')[0]; if (b && !b.disabled) b.click();
        },
      });
      if (shown($('#bots-bar'))) a.push({
        r: BT_IN, c: RC,
        send(v) {
          const n = parseInt(String(v).replace(/\D+/g, ''), 10);
          if (!Number.isFinite(n)) return;
          $('#bots-n').value = String(n); $('#bots-apply').click();
        },
      });
      return a;
    },
    compose(k) {
      const put = k.put;
      put(0, 0, 'Расчёт платежей в партии', { b: true, sz: 14 });
      if (!shown($('#app'))) { put(1, 0, 'Документ не открыт — введите имя в окне входа', { fg: '#7f7f7f' }); return; }
      put(1, 0, [txt($('#phase')), txt($('#h-hand')).replace(/^·\s*/, ''), txt($('#pot'))].filter(Boolean).join(' · '), { fg: '#595959' });
      const ban = $('#banner');
      put(2, 0, shown(ban) ? txt(ban) : txt($('#h-top')), shown(ban) ? { b: true, fg: '#107c41' } : { fg: '#7f7f7f', i: true });

      // ---- участники ----
      const H = { b: true, bg: '#f2f2f2', bb: 1 };
      ['№', 'Участник', 'Баланс', 'Ставка', 'Отметки', 'Документ 1', 'Документ 2', ''].forEach((t, c) => put(T0 - 1, c, t, H));
      $$('#seats > .seat').slice(0, TN).forEach((sd, i) => {
        const r = T0 + i, cl = sd.classList;
        const me = cl.contains('me'), actor = cl.contains('actor'), win = cl.contains('winner'), fold = cl.contains('folded');
        const base = { fg: fold ? '#a6a6a6' : '#262626' };
        if (win) base.bg = '#e2efda'; else if (actor) base.bg = '#fff2cc'; else if (me) base.bg = '#ddebf7';
        const S = x => Object.assign({}, base, x || {});
        put(r, 0, actor ? '→' : i + 1, S({ al: 'center', b: actor }));
        const nm = sd.querySelector('.name');
        put(r, 1, txt(nm).replace('✕', '').trim() + (me ? ' (вы)' : ''), S({ b: me }));
        put(r, 2, txt(sd.querySelector('.chipsline')), S());
        put(r, 3, txt(sd.querySelector('.bet')) || null, S({ al: 'right' }));
        put(r, 4, [...sd.querySelectorAll('.badge')].map(txt).concat(fold ? ['отмена'] : []).join(' '), S());
        const cards = sd.querySelectorAll('.cards > .card');
        [0, 1].forEach(j => { const [v, s] = cardTxt(cards[j]); put(r, 5 + j, v, s ? Object.assign({}, base.bg ? { bg: base.bg } : {}, s) : S()); });
        const kick = sd.querySelector('.kick');
        if (kick) { put(r, 7, '✕ убрать', S({ fg: '#c00000', al: 'center' })); k.click(r, 7, kick); }
        else put(r, 7, null, S());
      });

      // ---- стол ----
      put(15, 1, 'Общие документы:', { b: true });
      const bc = $$('#board > *');
      for (let j = 0; j < 5; j++) { const [v, s] = cardTxt(bc[j]); put(15, 2 + j, v || '·', s || { fg: '#bfbfbf', al: 'center' }); }
      put(16, 1, txt($('#pot')) || 'Итого: —', { b: true, fg: '#595959' });
      const fill = $('#timer-fill');
      const pct = fill ? parseFloat(fill.style.width) || 0 : 0;
      put(17, 0, pct > 0 ? 'Ваш ход: ' + '—'.repeat(Math.max(1, Math.round(pct / 100 * 60))) : '', { fg: pct < 27 && pct > 0 ? '#c00000' : '#8a8a8a' });

      // ---- панель ----
      put(0, RC, 'Действия', { b: true });
      const btns = $$('#btns > button');
      const cat = $('#app > header a.yh-cat'), close = $('#btn-panic');
      btns.slice(0, BTN_N - 2).concat(cat ? [cat] : [], close ? [close] : []).forEach((b, i) => {
        const dis = b.disabled, main = /b-start|b-call|b-raise/.test(b.className);
        put(BTN_R0 + i, RC, txt(b), dis ? { al: 'center', fg: '#8a8a8a', i: true } :
          { al: 'center', bg: main ? '#e2efda' : '#f2f2f2', b: main, bt: 1, bb: 1, bl: 1, br: 1 });
        if (!dis) k.click(BTN_R0 + i, RC, b);
      });
      const sl = $('#raise-slider');
      if (sl) put(RS_L, RC, 'Сумма увеличения ' + sl.min + '–' + sl.max + ' (сейчас ' + sl.value + ') — введите ниже, Enter ↓', { fg: '#7f7f7f', i: true });
      if (shown($('#bots-bar'))) put(BT_L, RC, 'Авто-участники (' + txt($('#bots-cur')).toLowerCase() + ') — сколько нужно? Ниже, Enter ↓', { fg: '#7f7f7f', i: true });
      put(LOG_H, RC, 'Журнал операций', { b: true });
      $$('#log > *').map(txt).filter(Boolean).slice(-LOG_N).forEach((t, i) => put(LOG_R0 + i, RC, t, { fg: '#595959' }));
      put(CH_H, RC, 'Комментарии', { b: true });
      $$('#chat-msgs > *').map(txt).filter(Boolean).slice(-CH_N).forEach((t, i) => put(CH_R0 + i, RC, t, { fg: '#262626' }));
      put(CH_L, RC, 'Новый комментарий — в ячейку ниже, Enter ↓', { fg: '#7f7f7f', i: true });
    },
  });
})();
