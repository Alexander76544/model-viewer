// ============================================================
//  cells-monopoly.js — «Учёт имущества» (монополия) прямо в ячейках листа
//  (адаптер для общего движка cells-core.js)
//    A1–A3    — заголовок
//    B5:K24   — поле по периметру (у каждой клетки 2 строки:
//               название / фишки «А Б», уровень «Д2», залог «З» или цена);
//               фон второй строки — цвет владельца; клик — карточка объекта
//    середина — ваш этап, бросок, участники, фонд, карточка объекта, ход событий
//    M…       — кнопки (клик), движения, комментарии, ввод комментария
//  Всё можно двигать в «Дизайн элементов».
// ============================================================
(function () {
  'use strict';
  if (!window.YZ_CELLS_CORE) return;
  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));
  const txt = el => el ? el.textContent.replace(/\s+/g, ' ').trim() : '';
  const shown = el => !!el && !el.classList.contains('hidden') && el.style.display !== 'none';
  const GR = 4, GC = 1, RC = 12;
  const BTN_R0 = 1, BTN_N = 8, LOG_H = 10, LOG_R0 = 11, LOG_N = 6, CH_H = 18, CH_R0 = 19, CH_N = 3, CH_L = 22, CH_IN = 23;
  const COLW = { 0: 20, 11: 20, 12: 320 };
  for (let c = 0; c < 10; c++) COLW[GC + c] = 84;
  const CL = { r: GR + 2, c: GC + 1, w: 8 };                 // середина поля: 8 столбцов × 16 строк
  const MERGES = [0, 1, 2].map(r => ({ r1: r, r2: r, c1: 0, c2: 11 }));
  for (let r = 0; r < 16; r++) MERGES.push({ r1: CL.r + r, r2: CL.r + r, c1: CL.c, c2: CL.c + CL.w - 1 });
  const cellRC = i => i <= 9 ? [9, 9 - i] : i <= 17 ? [8 - (i - 10), 0] : i <= 27 ? [0, i - 18] : [i - 28, 9];
  // цвет → светлый оттенок (для фона Excel-ячейки)
  const cvs = document.createElement('canvas').getContext('2d');
  const tint = (col, k) => {
    if (!col) return null;
    try { cvs.fillStyle = '#000'; cvs.fillStyle = col; } catch (_) { return null; }
    const h = cvs.fillStyle;
    if (!/^#[0-9a-f]{6}$/i.test(h)) return null;
    const n = [1, 3, 5].map(i => parseInt(h.substr(i, 2), 16)).map(v => Math.round(v + (255 - v) * k));
    return '#' + n.map(v => v.toString(16).padStart(2, '0')).join('');
  };

  YZ_CELLS_CORE.register({
    game: 'monopoly',
    roots: ['#app', '#cardmask'],
    blocks: [
      { id: 'head', name: 'Заголовок', r1: 0, r2: 2, c1: 0, c2: 11, cw: false },
      { id: 'board', name: 'Поле', r1: 4, r2: 23, c1: 0, c2: 11 },
      { id: 'panel', name: 'Панель (кнопки, движения, чат)', r1: 0, r2: CH_IN, c1: RC, c2: RC },
    ],
    colw: COLW,
    merges: MERGES,
    chatIn: {
      r: CH_IN, c: RC,
      send(v) { const inp = $('#chat-in'); if (inp) { inp.value = v; inp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true })); } },
    },
    compose(k) {
      const put = k.put;
      put(0, 0, 'Учёт имущества склада', { b: true, sz: 14 });
      if (!shown($('#app'))) { put(1, 0, 'Документ не открыт — введите имя в окне входа', { fg: '#7f7f7f' }); return; }
      put(1, 0, txt($('#h-phase')), { fg: '#595959' });
      const cm = $('#cardmask');
      if (shown(cm)) put(2, 0, 'Уведомление: ' + txt($('#c-icon')) + ' ' + txt($('#c-text')), { b: true, bg: '#fff2cc' });
      else put(2, 0, 'Клик по клетке поля — карточка объекта (аренда, владелец, доработка/залог)', { fg: '#a6a6a6', i: true });

      // ---- поле ----
      $$('#board > .sq').forEach(sq => {
        const i = +sq.dataset.i, [gr, gc] = cellRC(i), r = GR + gr * 2, c = GC + gc;
        const kind = sq.classList.contains('kind');
        const toks = Array.from(sq.querySelectorAll('.tok')).map(txt).join(' ');
        const mine = sq.classList.contains('mine-turn');
        const B = { bl: 1, br: 1 };
        if (kind) {
          put(r, c, txt(sq.querySelector('.kname')) || txt(sq.querySelector('.kico')), Object.assign({ al: 'center', b: true, fg: '#595959', bg: '#f2f2f2', bt: 1 }, B));
          put(r + 1, c, toks || txt(sq.querySelector('.kico')), Object.assign({ al: 'center', bg: '#f2f2f2', bb: 1, b: !!toks, fg: toks ? '#c00000' : '#a6a6a6' }, B, mine ? { bg: '#fff2cc' } : {}));
        } else {
          const stripe = sq.querySelector('.stripe');
          const own = sq.querySelector('.own'), owned = own && !own.classList.contains('hidden');
          const hous = txt(sq.querySelector('.hous')), mort = shown(sq.querySelector('.mort'));
          put(r, c, txt(sq.querySelector('.nm')), Object.assign({ b: true, sz: 9, bg: tint(stripe && stripe.style.background, 0.55) || '#ffffff', bt: 1 }, B));
          const info = [toks, hous, mort ? 'З' : ''].filter(Boolean).join(' ') || txt(sq.querySelector('.pr'));
          put(r + 1, c, info, Object.assign({
            al: 'center', bb: 1, sz: 9,
            b: !!toks, fg: toks ? '#c00000' : mort ? '#9c0006' : '#7f7f7f',
            bg: mine ? '#fff2cc' : owned ? (tint(own.style.background, 0.7) || '#e7e6e6') : '#ffffff',
          }, B));
        }
        k.click(r, c, sq); k.click(r + 1, c, sq);
      });

      // ---- середина ----
      const P = (dr, v, s) => put(CL.r + dr, CL.c, v, s);
      const act = $('#action');
      P(0, txt(act.querySelector('.big')), { b: true, sz: 12 });
      P(1, [txt(act.querySelector('#dice')) ? 'Бросок: ' + txt(act.querySelector('#dice')) : '', Array.from(act.querySelectorAll('.cd')).map(txt).join(' · ')].filter(Boolean).join(' · '), { fg: '#595959' });
      P(3, 'Участники', { b: true, fg: '#595959' });
      const ban = $('#banner');
      if (shown(ban)) {
        $$('#banner .bsub p').slice(0, 6).forEach((p, j) => P(4 + j, txt(p)));
      } else {
        $$('#players-row .chip').slice(0, 6).forEach((ch, j) => {
          const sp = ch.querySelectorAll('span');
          const turn = ch.classList.contains('turn'), dead = ch.classList.contains('dead');
          P(4 + j, (turn ? '→ ' : '   ') + txt(sp[0]) + '  ' + txt(sp[1]) + ' — ' + txt(sp[2]), { b: turn, fg: dead ? '#a6a6a6' : '#262626', bg: turn ? '#fff2cc' : undefined });
        });
      }
      P(10, txt($('#pot')), { fg: '#595959' });
      const si = $('#sqinfo');
      if (si && si.style.display !== 'none') {
        P(11, txt(si.querySelector('.st')), { b: true });
        P(12, txt(si.querySelector('.sd')), { fg: '#595959' });
      }
      $$('#minilog > div').map(txt).slice(-3).forEach((t, j) => P(13 + j, t, { fg: '#7f7f7f', i: true }));

      // ---- панель ----
      put(0, RC, 'Действия', { b: true });
      const btns = $$('#action button');
      if (si && si.style.display !== 'none') $$('#sqinfo button').forEach(b => btns.push(b));
      if (shown(ban)) { const nb = $('#banner-new'); if (nb) btns.push(nb); }
      $$('#app > header button').filter(b => !b.classList.contains('yg-hb') && b.id !== 'btn-panic' && shown(b)).forEach(b => btns.push(b));
      const cat = $('#app > header a.yh-cat'), close = $('#btn-panic');
      btns.slice(0, BTN_N - 2).concat(cat ? [cat] : [], close ? [close] : []).forEach((b, j) => {
        const main = b.classList.contains('go') || b.id === 'btn-start';
        put(BTN_R0 + j, RC, txt(b), { al: 'center', bg: main ? '#e2efda' : '#f2f2f2', b: main, bt: 1, bb: 1, bl: 1, br: 1 });
        k.click(BTN_R0 + j, RC, b);
      });
      put(LOG_H, RC, 'Движения', { b: true });
      $$('#log > *').map(txt).filter(Boolean).slice(-LOG_N).forEach((t, j) => put(LOG_R0 + j, RC, t, { fg: '#595959' }));
      put(CH_H, RC, 'Комментарии', { b: true });
      $$('#chat-msgs > *').map(txt).filter(Boolean).slice(-CH_N).forEach((t, j) => put(CH_R0 + j, RC, t, { fg: '#262626' }));
      put(CH_L, RC, 'Новый комментарий — в ячейку ниже, Enter ↓', { fg: '#7f7f7f', i: true });
    },
  });
})();
