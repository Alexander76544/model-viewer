// ============================================================
//  cells-mafia.js — «Протокол совещания» (мафия) прямо в ячейках листа
//  (адаптер для общего движка cells-core.js)
//    A1–A3    — заголовок: название, фаза, подсказка
//    A5…      — ваша функция, состав, время; таблица участников:
//               № | Участник | Статус | Отметки | Действие (клик — выбрать)
//    G…       — кнопки, журнал, комментарии, ввод комментария
//  Всё можно двигать в «Дизайн элементов».
// ============================================================
(function () {
  'use strict';
  if (!window.YZ_CELLS_CORE) return;
  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));
  const txt = el => el ? el.textContent.replace(/\s+/g, ' ').trim() : '';
  const shown = el => !!el && !el.classList.contains('hidden') && el.style.display !== 'none';
  const RC = 6;
  const T0 = 9, TN = 9;                       // таблица участников: строка заголовка 9 (лог.), 9 строк
  const BTN_R0 = 1, BTN_N = 7, LOG_H = 9, LOG_R0 = 10, LOG_N = 6, CH_H = 17, CH_R0 = 18, CH_N = 4, CH_L = 22, CH_IN = 23;
  const COLW = { 0: 34, 1: 190, 2: 110, 3: 230, 4: 150, 5: 24, 6: 340 };
  const MERGES = [];
  [0, 1, 2, 4, 5, 6, 7, 19, 20, 21, 22, 23, 24, 25].forEach(r => MERGES.push({ r1: r, r2: r, c1: 0, c2: 4 }));
  let roleName = '';

  YZ_CELLS_CORE.register({
    game: 'mafia',
    roots: ['#app', '#rolemask'],
    blocks: [
      { id: 'head', name: 'Заголовок', r1: 0, r2: 2, c1: 0, c2: 5, cw: false },
      { id: 'stage', name: 'Совещание (участники)', r1: 4, r2: 25, c1: 0, c2: 5 },
      { id: 'panel', name: 'Панель (кнопки, журнал, чат)', r1: 0, r2: CH_IN, c1: RC, c2: RC },
    ],
    colw: COLW,
    merges: MERGES,
    chatIn: {
      r: CH_IN, c: RC,
      send(v) { const inp = $('#chat-in'); if (inp) { inp.value = v; inp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true })); } },
    },
    compose(k) {
      const put = k.put;
      put(0, 0, 'Протокол совещания 30.09', { b: true, sz: 14 });
      if (!shown($('#app'))) { put(1, 0, 'Протокол не открыт — введите имя в окне входа', { fg: '#7f7f7f' }); return; }
      put(1, 0, [txt($('#h-phase')), txt($('#h-count'))].filter(Boolean).join(' · '), { fg: '#595959' });
      const hints = $$('#stage [id="action-hint"]');
      put(2, 0, txt(hints[0]), { fg: '#7f7f7f', i: true });

      // ---- служебная записка (роль) ----
      const mask = $('#rolemask'), rt = txt($('#r-title'));
      if (rt) roleName = rt;
      const btns = [];
      if (shown(mask)) {
        put(4, 0, 'Служебная записка: ваша функция — ' + rt + '. ' + txt($('#r-desc')) + (shown($('#r-comps')) ? ' ' + txt($('#r-comps')) : ''), { b: true, bg: '#fff2cc' });
        btns.push($('#btn-rolemask'));
      } else put(4, 0, roleName ? 'Ваша функция на смене: ' + roleName : '', { fg: '#595959' });
      put(5, 0, txt($('#stage #subphase')), { fg: '#595959' });
      const fill = $('#stage #timer-fill'), bar = $('#stage #timer-bar');
      if (fill && shown(bar)) {
        const pct = parseFloat(fill.style.width) || 0;
        put(6, 0, pct > 0 ? '—'.repeat(Math.max(1, Math.round(pct / 100 * 70))) : '', { fg: '#8a8a8a' });
      }
      put(7, 0, hints.length > 1 ? txt(hints[hints.length - 1]) : '', { fg: '#595959' });

      // ---- участники ----
      const cards = $$('#stage .pcard');
      const H = { b: true, bg: '#f2f2f2', bb: 1 };
      ['№', 'Участник', 'Статус', 'Отметки', 'Действие'].forEach((t, c) => put(T0 - 1, c, t, H));
      const act = ($('#stage #pgrid') || {}).dataset ? $('#stage #pgrid').dataset.act : '';
      const ACT = { vote: 'голосовать', kill: 'отметить', heal: 'взять под контроль', check: 'проверить' }[act] || 'выбрать';
      cards.slice(0, TN).forEach((cd, i) => {
        const r = T0 + i, cl = cd.classList;
        const me = cl.contains('me'), dead = cl.contains('dead'), can = cl.contains('clickable') && !dead;
        const base = { fg: dead ? '#a6a6a6' : '#262626', bg: me ? '#ddebf7' : undefined };
        if (!base.bg) delete base.bg;
        put(r, 0, i + 1, Object.assign({ al: 'center' }, base));
        put(r, 1, txt(cd.querySelector('.nm')), Object.assign({ b: me }, base));
        put(r, 2, dead ? 'отстранён' : 'в работе', base);
        put(r, 3, [txt(cd.querySelector('.tags')).replace(/^·\s*/, ''), txt(cd.querySelector('.role-rev'))].filter(Boolean).join(' · '), base);
        if (can) {
          put(r, 4, '► ' + ACT, { al: 'center', bg: '#e2efda', fg: '#375623', bt: 1, bb: 1, bl: 1, br: 1 });
          for (let c = 1; c <= 4; c++) k.click(r, c, cd);
        } else put(r, 4, null, base);
      });

      // ---- итог ----
      const ban = $('#banner');
      if (shown(ban)) {
        put(19, 0, txt(ban.querySelector('h2')), { b: true, sz: 12, fg: '#107c41' });
        put(20, 0, txt(ban.querySelector('p')), { fg: '#595959' });
        const rows = $$('#banner .roles > div').slice(1);
        put(21, 0, 'Функции на смене:', { b: true, fg: '#595959' });
        rows.slice(0, 9).forEach((d, i) => put(22 + (i / 3 | 0), 0, rows.slice((i / 3 | 0) * 3, (i / 3 | 0) * 3 + 3).map(x => Array.from(x.children).map(txt).join(' — ')).join('   ·   '), { fg: '#262626' }));
        const nb = $('#banner-new'); if (nb) btns.push(nb);
      }

      // ---- панель ----
      put(0, RC, 'Действия', { b: true });
      ['#btn-night-skip', '#btn-abstain'].forEach(id => { const b = $('#stage ' + id); if (b) btns.push(b); });
      $$('#app > header button').filter(b => !b.classList.contains('yg-hb') && b.id !== 'btn-panic' && shown(b)).forEach(b => btns.push(b));
      const cat = $('#app > header a.yh-cat'), close = $('#btn-panic');
      btns.concat(cat ? [cat] : [], close ? [close] : []).slice(0, BTN_N).forEach((b, i) => {
        const main = b.id === 'btn-rolemask' || b.id === 'btn-start' || b.id === 'banner-new';
        put(BTN_R0 + i, RC, txt(b), { al: 'center', bg: main ? '#e2efda' : '#f2f2f2', b: main, bt: 1, bb: 1, bl: 1, br: 1 });
        k.click(BTN_R0 + i, RC, b);
      });
      put(LOG_H, RC, 'Журнал', { b: true });
      $$('#log > *').map(txt).filter(Boolean).slice(-LOG_N).forEach((t, i) => put(LOG_R0 + i, RC, t, { fg: '#595959' }));
      put(CH_H, RC, 'Комментарии', { b: true });
      $$('#chat-msgs > *').map(txt).filter(Boolean).slice(-CH_N).forEach((t, i) => put(CH_R0 + i, RC, t, { fg: '#262626' }));
      put(CH_L, RC, 'Новый комментарий — в ячейку ниже, Enter ↓', { fg: '#7f7f7f', i: true });
    },
  });
})();
