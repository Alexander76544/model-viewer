// ============================================================
//  cells-lobby.js — «Сводный отчёт по документам» (лобби) прямо в ячейках
//    A1–A2   — заголовок (шрифт ymz)
//    A4:E9   — реестр документов: № | Документ | Описание | Состав | Статус
//              (клик по строке — открыть документ)
//    A11:E27 — итоговая таблица участников (рейтинг)
//    G       — кнопки (Свойства пользователя, Закрыть), справка
//  Всё можно двигать в «Дизайн элементов».
// ============================================================
(function () {
  'use strict';
  if (!window.YZ_CELLS_CORE) return;
  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));
  const txt = el => el ? el.textContent.replace(/\s+/g, ' ').trim() : '';
  const F = 'ymz';
  const RC = 6, TOPN = 15;
  const BOX = { bt: 1, bb: 1, bl: 1, br: 1 };
  const HDR = Object.assign({ b: true, bg: '#1f4e78', fg: '#ffffff', al: 'center', ff: F }, BOX);
  const S = o => Object.assign({ ff: F }, o || {});

  YZ_CELLS_CORE.register({
    game: 'lobby',
    roots: ['.wrap', '.lbtns'],
    blocks: [
      { id: 'head', name: 'Заголовок', r1: 0, r2: 1, c1: 0, c2: 4, cw: false },
      { id: 'docs', name: 'Реестр документов', r1: 3, r2: 8, c1: 0, c2: 4 },
      { id: 'champ', name: 'Итоговая таблица', r1: 10, r2: 11 + TOPN, c1: 0, c2: 4, cw: false },
      { id: 'panel', name: 'Панель (кнопки)', r1: 0, r2: 10, c1: RC, c2: RC },
    ],
    colw: { 0: 50, 1: 300, 2: 400, 3: 120, 4: 150, 5: 24, 6: 230 },
    merges: [{ r1: 0, r2: 0, c1: 0, c2: 4 }, { r1: 1, r2: 1, c1: 0, c2: 4 }, { r1: 9, r2: 9, c1: 0, c2: 4 }, { r1: 10, r2: 10, c1: 0, c2: 4 }],
    compose(k) {
      const put = k.put;
      put(0, 0, txt($('.wrap h1')) || 'Каталог рабочих документов', S({ b: true, sz: 16, fg: '#1f4e78' }));
      put(1, 0, txt($('.wrap .sub')), S({ fg: '#595959' }));

      // ---- реестр документов ----
      ['№', 'Документ', 'Описание', 'Состав', 'Статус'].forEach((t, c) => put(3, c, t, HDR));
      $$('.games .game-card').slice(0, 5).forEach((cd, i) => {
        const r = 4 + i, stEl = cd.querySelector('.status'), live = stEl && stEl.classList.contains('live');
        const ps = Array.from(cd.querySelectorAll('p')).map(p => p.innerHTML.split(/<br\s*\/?>/i).map(x => x.replace(/<[^>]+>/g, '').trim()));
        const lines = ps[0] || [];
        const zebra = i % 2 ? '#ddebf7' : '#ffffff';
        const base = S(Object.assign({ bg: zebra }, BOX));
        put(r, 0, txt(cd.querySelector('.icon')), Object.assign({}, base, { al: 'center', fg: '#7f7f7f' }));
        put(r, 1, txt(cd.querySelector('h2')), Object.assign({}, base, { fg: '#0563c1', u: true }));
        put(r, 2, lines[0] || '', Object.assign({}, base, { fg: '#404040' }));
        const st = txt(stEl);
        const m = st.match(/(\d+)(?:\/(\d+))?\s*польз/);
        put(r, 3, m ? m[1] + (m[2] ? ' из ' + m[2] : '') + ' польз.' : '—', Object.assign({}, base, { al: 'center' }));
        put(r, 4, st.replace(/:\s*\d+(\/\d+)?\s*польз\.?/, '').replace(/:\s*$/, '') || st,
          Object.assign({}, base, { al: 'center', b: live, fg: live ? '#375623' : '#595959', bg: live ? '#e2efda' : zebra }));
        for (let c = 0; c <= 4; c++) k.click(r, c, cd);
      });
      put(9, 0, 'Щёлкните строку документа, чтобы открыть его.', S({ fg: '#7f7f7f', i: true }));

      // ---- итоговая таблица ----
      put(10, 0, txt($('.champ-title')) || 'Итоговая таблица', S({ b: true, sz: 13 }));
      ['Место', 'Участник', 'Результат', 'Серия', 'Рейтинг'].forEach((t, c) => put(11, c, t, HDR));
      const rows = $$('#champ-list .crow');
      if (!rows.length) put(12, 1, txt($('#champ-list')), S({ fg: '#7f7f7f', i: true }));
      rows.slice(0, TOPN).forEach((row, i) => {
        const r = 12 + i, me = row.classList.contains('me');
        const base = S(Object.assign({ bg: me ? '#fff2cc' : (i % 2 ? '#f2f2f2' : '#ffffff'), b: me }, BOX));
        put(r, 0, +txt(row.querySelector('.crank')) || i + 1, Object.assign({}, base, { al: 'center', fg: i === 0 ? '#107c41' : undefined }));
        put(r, 1, txt(row.querySelector('.cname')), base);
        put(r, 2, txt(row.querySelector('.cwins')), Object.assign({}, base, { al: 'center' }));
        put(r, 3, txt(row.querySelector('.cseries')).replace(/^серия:\s*/, '') || '—', Object.assign({}, base, { al: 'center' }));
        const rt = txt(row.querySelector('.crating'));
        put(r, 4, rt !== '' && !isNaN(+rt) ? +rt : rt, Object.assign({}, base, { al: 'right' }));
      });

      // ---- панель ----
      put(0, RC, 'Действия', S({ b: true }));
      [$('#btn-profile'), $('#btn-panic')].filter(Boolean).forEach((b, i) => {
        put(1 + i, RC, txt(b), S(Object.assign({ al: 'center', bg: i ? '#f2f2f2' : '#e2efda', b: !i }, BOX)));
        k.click(1 + i, RC, b);
      });
      put(4, RC, 'Вы: ' + (localStorage.getItem('yz_name') || 'имя не задано'), S({ fg: '#595959' }));
      put(6, RC, 'Совет', S({ b: true }));
      put(7, RC, 'Esc — быстро закрыть', S({ fg: '#7f7f7f' }));
      put(8, RC, 'Файл → Открыть — свой .xlsx', S({ fg: '#7f7f7f' }));
    },
  });
})();
