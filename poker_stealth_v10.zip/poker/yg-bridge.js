// ============================================================
//  «Подпольный ЯМЗ» — мост: игры + полнофункциональный Excel
//  (excel.html: настоящая таблица на HyperFormula, русская лента).
//
//  Что делает:
//   • игровой контент переезжает в область листа (#yg-layer внутри
//     #w): игра «лежит» поверх настоящей таблицы, а пустые места
//     листа кликабельны — начальник может реально работать в
//     Excel вокруг игры (ячейки, формулы, зум, вкладки);
//   • вкладки листов Excel = разделы игры (имена из
//     window.OFFICE.tabs) — как настоящие листы книги;
//   • вкладка «Разработчик»: «Дизайн элементов» — перетаскивание
//     и изменение размера игровых окон (раскладка сохраняется,
//     «Сбросить» — вернуть исходную);
//   • «чистый режим»: игра — только текст (по умолчанию),
//     тумблер «Графика: вкл/выкл» в статус-баре;
//   • скрытие верхнего меню (▾ в заголовке), шапки игры и панели
//     действий (▾ + чип возврата) — их строки становятся
//     обычными ячейками;
//   • Ctrl+P — окно «Печать» в стиле Excel (не браузерное);
//   • Esc: сначала закрывает окно печати / дизайн-режим, потом —
//     босс-режим (игра скрывается, остаётся настоящий Excel).
//
//  Подключение: <script src="/yg-bridge.js?v=N"></script> в body
//  страницы игры ПОСЛЕ скриптов игры.
//  Конфиг: window.OFFICE = { doc, tabs, drag: [селекторы окон] }.
// ============================================================
(function () {
  'use strict';
  const CFG = window.OFFICE || {};
  const DOC = CFG.doc || 'Документ.xlsx';
  const DRAG = CFG.drag || [];
  const escX = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  document.addEventListener('DOMContentLoaded', () => {
    const $ = s => document.querySelector(s);
    const W = $('#w'), TT = $('#tt'), RT = $('#rt'), RB = $('#rb'), FX = $('#fx'), STB = $('#stb');
    if (!W || !RB) return;

    // ---------- стили ----------
    const style = document.createElement('style');
    style.textContent = `
    /* слой «приклеивается» к видимой зоне листа JS'ом (pinLayer) — inset:0 нельзя:
       #w скроллится, и abs-дочка растёт бы на всю высоту контента */
    #yg-layer{position:absolute; top:0; left:0; z-index:4; pointer-events:none; overflow:hidden;}
    #yg-layer *{pointer-events:none;}
    #yg-layer .yg-win, #yg-layer .yg-win *, #yg-layer .yg-rest, #yg-layer .yg-rest *,
    #yg-layer > #join, #yg-layer > #join *,
    #yg-layer .yg-print, #yg-layer .yg-print *, #yg-layer .yg-hb{pointer-events:auto;}
    #yg-layer > *{position:absolute !important;}
    #yg-layer > :is(#app,.wrap,#join){inset:0 !important; overflow:auto;}
    .yg-rest{position:absolute; z-index:9; cursor:pointer; font-size:11px; padding:2px 8px; background:#fff; border:1px solid #d0d7de; color:#333; display:none; user-select:none;}
    .yg-rz{position:absolute; right:2px; bottom:2px; width:12px; height:12px; background:#107c41; border:1px solid #fff; cursor:nwse-resize; z-index:10; display:none;}
    #yg-layer.yg-designing .yg-rz{display:block;}
    /* дизайн-режим (вкладка «Разработчик» → «Дизайн элементов») */
    body.yg-design #yg-layer .yg-win{cursor:move; outline:1px dashed #107c41; outline-offset:1px;}
    /* дизайн-режим: кликабельно ВСЁ (любой блок можно схватить), сами клики
       по кнопкам/полям гасятся JS'ом — игра в этот момент не реагирует */
    body.yg-design #yg-layer *{pointer-events:auto !important;}
    body.yg-design #yg-layer :is(input,textarea,select,button,a){cursor:move !important;}
    #yg-hl{position:fixed; z-index:2147483000; pointer-events:none; display:none; outline:2px solid #107c41; background:rgba(16,124,65,.08);}
    #yg-hl span{position:absolute; left:-2px; top:-18px; background:#107c41; color:#fff; font:11px 'Segoe UI',sans-serif; padding:1px 6px; white-space:nowrap;}
    #yg-dhint{position:absolute; top:4px; left:50%; transform:translateX(-50%); z-index:20; display:none;
      background:#107c41; color:#ccc; font-size:11px; padding:2px 10px; pointer-events:none; white-space:nowrap;}
    #yg-layer.yg-designing #yg-dhint{display:block;}
    .yg-print{position:absolute; inset:0; z-index:30; background:rgba(0,0,0,.25); display:none; pointer-events:auto;}
    .yg-print.on{display:block;}
    .yg-pdlg{position:absolute; left:50%; top:40%; transform:translate(-50%,-50%); width:440px; max-width:92%; background:var(--bg,#fff); color:var(--fg,#1a1a1a); border:1px solid #8a8886; box-shadow:4px 6px 18px rgba(0,0,0,.28); font:12px system-ui,'Segoe UI',sans-serif;}
    .yg-pdlg .t{height:28px; background:#107c41; color:#ccc; display:flex; align-items:center; gap:6px; padding:0 10px;}
    .yg-pdlg .t .x{margin-left:auto; cursor:pointer;}
    .yg-pdlg .b{padding:12px 14px; display:flex; flex-direction:column; gap:8px;}
    .yg-pdlg .r{display:flex; align-items:center; gap:8px;}
    .yg-pdlg .r label{width:120px; flex:none; text-align:right; opacity:.75; font-size:12px;}
    .yg-pdlg .r input,.yg-pdlg .r select{flex:1; height:24px; border:1px solid #d0d7de; padding:0 6px; font:inherit; background:var(--bg,#fff); color:var(--fg,#1a1a1a); box-sizing:border-box;}
    .yg-pdlg .f{padding:8px 14px 12px; display:flex; justify-content:flex-end; gap:8px;}
    .yg-pdlg .f button{min-width:80px; height:26px;}
    /* ===== вид «Текст» — «чистый режим»: только серый текст =====
       без рамок, фонов, линий и картинок; всё лишнее для глаз убрано.
       Важное состояние показывается БУКВАМИ и СИМВОЛАМИ, а не цветом. */
    body.ow-clean #yg-layer *{color:#777 !important; background:transparent !important; background-color:transparent !important; border:none !important; outline:none !important; box-shadow:none !important; text-shadow:none !important; animation:none !important; transition:none !important; filter:none !important;}
    body.ow-clean #yg-layer input, body.ow-clean #yg-layer textarea{background:transparent !important; color:inherit !important;}
    body.ow-clean.yg-darksheet #yg-layer *{color:#999 !important;}
    body.ow-clean.yg-design #yg-layer .yg-win{outline:1px dashed #107c41 !important;}
    body.ow-clean.yg-design #yg-layer .yg-rz{background:#107c41 !important; border:1px solid #fff !important;}
    body.ow-clean.yg-design #yg-layer #yg-dhint{background:#107c41 !important; color:#fff !important;}
    body.ow-clean #yg-layer ::placeholder{color:#a0a0a0 !important;}
    body.ow-clean #yg-layer input[type=range]{background:transparent !important;}
    body.ow-clean #yg-layer input[type=range]::-webkit-slider-thumb{background:#808080 !important; border:none !important;}
    body.ow-clean #yg-layer *::before, body.ow-clean #yg-layer *::after{border:none !important; background:none !important; box-shadow:none !important; animation:none !important;}
    body.ow-clean #yg-layer img, body.ow-clean #yg-layer svg, body.ow-clean #yg-layer .chatimg{display:none !important;}
    body.ow-clean #chat-emoji-btn, body.ow-clean #chat-img-btn, body.ow-clean #chat-emoji{display:none !important;}
    /* морской бой: корабль — «О», куда ставишь — «о» (можно) / «×» (нельзя) */
    body.ow-clean #yg-layer .cell.ship::after{content:'О'; color:#555 !important;}
    body.ow-clean #yg-layer .cell.ghost-ok::after{content:'о'; color:#555 !important; font-weight:700;}
    body.ow-clean #yg-layer .cell.ghost-bad::after{content:'×'; color:#555 !important; font-weight:700;}
    body.ow-clean #yg-layer .cell.sunk::after{content:'X'; color:#555 !important;}
    body.ow-clean #yg-layer .cell.hit::after{content:'X'; color:#555 !important;}
    body.ow-clean #yg-layer .fship i{width:auto !important; height:auto !important; font-style:normal;}
    body.ow-clean #yg-layer .fship i::after{content:'О'; font-size:11px;}
    body.ow-clean #yg-layer .fship.gone i::after{content:'X';}
    /* полоска времени — строкой «————»: укорачивается по мере хода */
    body.ow-clean #yg-layer :is(#timer-bar,#turnbar-wrap){height:14px !important; overflow:hidden !important;}
    body.ow-clean #yg-layer :is(#timer-fill,#turnbar){height:14px !important; overflow:hidden !important; white-space:nowrap !important;
      font:12px/14px Consolas,monospace !important; letter-spacing:-1px;}
    body.ow-clean #yg-layer :is(#timer-fill,#turnbar)::before{content:'————————————————————————————————————————————————————————————————————————————————————————————————————';}
    /* шапка и кнопки в «Тексте» — тоже просто текст */
    body.ow-clean #yg-layer #app > header.yh, body.ow-clean #yg-layer #app > header.yh *,
    body.ow-clean #yg-layer .lbtns .lbtn{background:transparent !important; border:none !important; color:#777 !important; font-weight:400 !important;}
    body.ow-clean #yg-layer header.yh .yh-sep{width:0 !important;}
    body.ow-clean #yg-layer .yj-cat{color:#777 !important;}
    /* ===== «Офис»: подсказки, которые не зависят от цвета ===== */
    body.ys-office #yg-layer .cell.ghost-ok::after{content:'+'; color:#1e6b34; font-weight:700;}
    body.ys-office #yg-layer .cell.ghost-bad::after{content:'×'; color:#9c0006; font-weight:700;}
    body.ys-office #yg-layer .cell.ghost-ok{outline:2px solid #217346; outline-offset:-2px;}
    body.ys-office #yg-layer .cell.ghost-bad{outline:2px dashed #c00000; outline-offset:-2px;}
    body.ys-office #yg-layer :is(#timer-bar,#turnbar-wrap){background:#e7e6e6 !important; min-height:5px;}
    body.ys-office #yg-layer :is(#timer-fill,#turnbar){background:#217346 !important; min-height:5px;}
    body.ys-office #yg-layer :is(#timer-fill,#turnbar).danger{background:#c00000 !important;}
    body.ys-office #yg-layer .pcard.voted::after{content:'✓ голос' !important; color:#217346 !important; font-size:11px !important;}
    /* ===== единая шапка всех документов: [название][статус] … [действия] | Каталог  ✕ Закрыть ===== */
    #yg-layer #app > header.yh{display:flex !important; flex-wrap:nowrap !important; align-items:center !important; gap:6px !important;
      height:34px !important; min-height:34px; padding:0 8px 0 12px !important; box-sizing:border-box; white-space:nowrap; overflow:hidden;
      background:#f8f8f8 !important; border-bottom:1px solid #e1e1e1 !important; font-size:12px !important;}
    #yg-layer header.yh > *{flex:none;}
    #yg-layer header.yh .yh-title{font-size:13px !important; font-weight:700; color:#107c41;}
    #yg-layer header.yh > span:not(.yh-sp):not(.yh-sep):not(#conn){flex:0 1 auto; min-width:0; overflow:hidden; text-overflow:ellipsis;
      color:#605e5c !important; font-size:12px !important; margin:0 !important;}
    #yg-layer header.yh .yh-sp{flex:1 1 0 !important; min-width:6px;}
    #yg-layer header.yh .yh-sep{width:1px; height:18px; background:#d0d0d0 !important; margin:0 2px;}
    #yg-layer header.yh .hbtn{height:24px !important; padding:0 10px !important; font-size:12px !important; line-height:22px !important;
      background:#fff !important; border:1px solid #c8c6c4 !important; color:#252423 !important; border-radius:2px !important; font-weight:400 !important;}
    #yg-layer header.yh .hbtn.primary{border-color:#107c41 !important; color:#107c41 !important; font-weight:600 !important;}
    #yg-layer header.yh .hbtn:hover{background:#f3f2f1 !important;}
    #yg-layer header.yh .yh-cat{font-size:12px !important; color:#107c41 !important; text-decoration:none !important; padding:0 4px;}
    #yg-layer header.yh .yh-cat:hover{text-decoration:underline !important;}
    #yg-layer header.yh #conn{font-size:11px !important; margin:0 !important;}
    #yg-layer header.yh > .yg-hb{position:static !important; margin-left:2px; height:24px; width:24px; padding:0 !important;}
    #yg-layer .yg-hb, .yg-rest{font-family:'Segoe UI Symbol','Segoe UI',Arial,sans-serif !important;}
    /* лобби: кнопки в правом верхнем углу — там же, где «✕ Закрыть» в документах */
    #yg-layer .lbtns{top:5px !important; right:8px !important; gap:6px !important;}
    #yg-layer .lbtn{height:24px !important; padding:0 10px !important; font-size:12px !important; border-radius:2px !important;
      background:#fff !important; border:1px solid #c8c6c4 !important; color:#252423 !important;}
    /* окна входа: ссылка «← Каталог документов» везде одинаковая, внизу */
    #yg-layer .yj-cat{display:block; margin-top:10px; font-size:12px !important; color:#107c41 !important; text-decoration:none;}
    body.ow-clean #yg-layer img, body.ow-clean #yg-layer svg, body.ow-clean #yg-layer .chatimg{display:none !important;}
    body.ow-clean #chat-emoji-btn, body.ow-clean #chat-img-btn, body.ow-clean #chat-emoji{display:none !important;}
    /* вкладки «Лог»/«Чат» в нижней панели (как листы Excel) */
    .yn-tab{font:12px system-ui,'Segoe UI',sans-serif; border:0; border-right:1px solid var(--bd,#e1e1e1);
      padding:5px 12px; background:transparent; color:var(--fg,#262626); cursor:pointer; white-space:nowrap;}
    .yn-tab:hover{background:var(--sel,#eaf3ec);}
    .yn-tab.on{background:var(--bg,#fff); color:var(--ac,#107c41); border-bottom:2px solid var(--ac,#107c41); font-weight:600;}
    .yn-hid{display:none !important;}
    /* вид «Ячейки»: окна игры не рисуются — всё в ячейках листа (окно входа остаётся) */
    body.yz-cells #yg-layer > :not(#join):not(.yg-print):not(#hostmodal):not(#pmodal):not(#cardmask){display:none !important;}
    body.yz-cells .yn-tab{display:none !important;}
    /* босс-режим: прячем всё «неэкселевское» из нижних панелей */
    body.yzp-on .yn-tab, body.yzp-on .yz-gbtn{display:none !important;}
    /* ===== вид «Офис» ===== */
    body.ys-office #yg-layer, body.ys-office #yg-layer *{font-family:Calibri,Carlito,'Segoe UI',Arial,sans-serif !important;
      text-shadow:none !important; animation:none !important; transition:none !important;}
    body.ys-office #yg-layer *::before, body.ys-office #yg-layer *::after{animation:none !important;}
    body.ys-office #yg-layer *{box-shadow:none !important;}
    body.ys-office #yg-layer :is(button,input,select,textarea){border-radius:2px !important;}
    body.ys-office #yg-layer button:not(.yg-hb){background:#fdfdfd; border:1px solid #c8c6c4; color:#252423; cursor:pointer;}
    body.ys-office #yg-layer button:not(.yg-hb):not(:disabled):hover{background:#f3f2f1; border-color:#8a8886;}
    body.ys-office #yg-layer button:disabled{opacity:.55; cursor:default;}
    body.ys-office #yg-layer :is(input,textarea,select):focus{outline:2px solid #107c41 !important; outline-offset:-1px;}
    body.ys-office #yg-layer img, body.ys-office #yg-layer svg, body.ys-office #yg-layer .chatimg{display:none !important;}
    body.ys-office #chat-emoji-btn, body.ys-office #chat-img-btn, body.ys-office #chat-emoji{display:none !important;}
    body.ys-office #yg-layer #timer-fill{background:#107c41 !important;}
    body.ys-office #yg-layer #timer-fill.danger{background:#c43e1c !important;}
    aside.yn-side-empty{display:none !important;}
    `;
    document.head.appendChild(style);

    // ---------- заголовок ----------
    const ttl = $('#ttl');
    if (ttl) ttl.textContent = DOC + ' - Excel';
    document.title = DOC + ' - Excel';
    // значок вкладки — как у Excel (зелёный лист с «X»)
    try {
      document.querySelectorAll('link[rel~="icon"]').forEach(l => l.remove());
      const ico = document.createElement('link');
      ico.rel = 'icon';
      ico.href = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect x="9" y="3" width="21" height="26" rx="2" fill="#21a366"/><rect x="9" y="16" width="21" height="13" fill="#107c41"/><rect x="2" y="8" width="16" height="16" rx="2" fill="#185c37"/><path d="M6 12h3l1.5 2.6L12 12h3l-3 4 3 4h-3l-1.5-2.6L9 20H6l3-4z" fill="#fff"/></svg>');
      document.head.appendChild(ico);
    } catch (_) {}
    // адресная строка / история: /Документы/<имя>.xlsx вместо /poker, /boy…
    try { history.replaceState(history.state, '', '/' + encodeURIComponent('Документы') + '/' + encodeURIComponent(DOC)); } catch (_) {}

    // ---------- вкладки листов = разделы игры ----------
    try {
      if (CFG.tabs && CFG.tabs.length && typeof hf !== 'undefined') {
        const names = hf.getSheetNames();
        hf.renameSheet(hf.getSheetId(names[0]), CFG.tabs[0]);
        for (let i = 1; i < CFG.tabs.length; i++) if (!hf.doesSheetExist(CFG.tabs[i])) hf.addSheet(CFG.tabs[i]);
        sid = hf.getSheetId(CFG.tabs[0]);
        // демо-данные (Болт/Гайка…) наезжали на игру — лист под игрой чистый;
        // при панике panic.js заполняет его правдоподобным отчётом
        hf.setSheetContent(sid, []);
        home(); tabs(); build();
      }
    } catch (_) { /* Excel без игры или ошибка API — тихо */ }

    // ---------- слой игры внутри области листа ----------
    const layer = document.createElement('div');
    layer.id = 'yg-layer';
    W.appendChild(layer);
    let reclampAll = null; // назначается ниже (когда будут окна) — поджимает окна к границам листа
    function pinLayer() {
      layer.style.width = W.clientWidth + 'px';
      layer.style.height = W.clientHeight + 'px';
      layer.style.transform = 'translate(' + (-W.scrollLeft) + 'px,' + (-W.scrollTop) + 'px)';
      if (reclampAll) reclampAll();
    }
    // В момент DOMContentLoaded у #w (flex:1) высота ещё может быть 0 —
    // layout не завершён. Поэтому pin не только при старте, но и на следующей
    // кадре, на load, при каждом изменении размера #w (ResizeObserver) и скролле.
    pinLayer();
    requestAnimationFrame(pinLayer);
    window.addEventListener('load', pinLayer);
    W.addEventListener('scroll', pinLayer);
    window.addEventListener('resize', pinLayer);
    if (typeof ResizeObserver !== 'undefined') new ResizeObserver(pinLayer).observe(W);
    pinLayer();

    // ---------- игровой контент body → слой ----------
    // EXCEL-элементы (статичные + создаваемые скриптом таблицы) ОСТАЮТСЯ в body:
    // tb/fx/w/cm/bar/stb + afm, dg, fwct, bs, xm, ink, zw (служебные окна Excel)
    const KNOWN = new Set(['tb', 'rt', 'rb', 'fx', 'w', 'cm', 'bar', 'stb', 'fwa', 'dg', 'afm',
      'ink', 'xm', 'fwct', 'bs', 'zw', 'yz-panic-hint', 'yz-panic-fallback', 'yg-hl']);
    function isKnown(el) {
      if (!el || el.nodeType !== 1) return false;
      const t = el.tagName;
      // INPUT/A/BUTTON на верхнем уровне body — служебные элементы Excel
      // (скрытые file-инпуты, временные ссылки-«скачалки») — не трогаем
      if (t === 'SCRIPT' || t === 'STYLE' || t === 'LINK' || t === 'META' || t === 'TITLE' ||
          t === 'TEMPLATE' || t === 'INPUT' || t === 'A' || t === 'BUTTON') return true;
      return KNOWN.has(el.id);
    }
    for (const ch of Array.from(document.body.children)) {
      if (ch === layer || isKnown(ch)) continue;
      layer.appendChild(ch);
    }
    // динамические модальные окна игр (привязываем к листу)
    const moBody = new MutationObserver(ms => {
      for (const m of ms) for (const n of m.addedNodes) {
        if (n.nodeType === 1 && !isKnown(n) && !layer.contains(n) && document.body.contains(n)) layer.appendChild(n);
      }
    });
    moBody.observe(document.body, { childList: true });

    // ---------- раскладка окон: ключи + хранилище (localStorage) ----------
    const LKEY = 'yg_layout_' + DOC;
    function loadLayout() { try { return JSON.parse(localStorage.getItem(LKEY) || '{}') || {}; } catch (_) { return {}; } }
    function saveLayout(L) { try { localStorage.setItem(LKEY, JSON.stringify(L)); } catch (_) {} }
    const LAYOUT = loadLayout();
    // стабильный ключ окна: по id, иначе «класс@номер-среди-таких-же»
    function keyFor(el) {
      if (el.id) return '#' + el.id;
      const cls = String(el.className || '').trim().split(/\s+/)[0] || el.tagName.toLowerCase();
      const sibs = el.parentNode
        ? Array.prototype.filter.call(el.parentNode.children, c =>
            c.tagName === el.tagName &&
            (String(c.className || '').trim().split(/\s+/)[0] || c.tagName.toLowerCase()) === cls)
        : [el];
      return cls + '@' + (sibs.indexOf(el) + 1);
    }
    function applyPos(el, o) {
      if (!el || !o) return;
      el.style.position = 'absolute';
      el.style.left = o.l + 'px';
      el.style.top = o.t + 'px';
      if (o.w) el.style.width = o.w + 'px';
      if (o.h) el.style.height = o.h + 'px';
    }
    function resetPos(el) {
      if (!el) return;
      ['position', 'left', 'top', 'width', 'height', 'maxWidth', 'minWidth', 'maxHeight', 'minHeight']
        .forEach(k => el.style.removeProperty(k));
    }

    // ---------- игровые окна: кликабельные + перетаскиваемые ----------
    const winSel = DRAG.concat(['#hostmodal', '#pmodal', '#rolemask', '#cardmask', '#banner', '.lbtns']);
    const wins = [];
    function rzHandle() {
      const rz = document.createElement('div');
      rz.className = 'yg-rz';
      rz.title = 'Размер (режим «Дизайн»)';
      return rz;
    }
    function markWin(el) {
      if (!el) return;
      if (!el.classList.contains('yg-win')) {
        el.classList.add('yg-win');
        wins.push(el);
        el.dataset.ygKey = el.dataset.ygKey || keyFor(el);
        // раскладка с прошлой сессии; поджимаем ТОЛЬКО окна с сохранённой позицией —
        // раньше clampWin трогал и обычные окна в момент, когда лист ещё не
        // разложен, и сдвигал шапку/баннер на ~220px вниз (наезд на поле)
        if (LAYOUT[el.dataset.ygKey]) { applyPos(el, LAYOUT[el.dataset.ygKey]); requestAnimationFrame(() => requestAnimationFrame(() => clampWin(el))); }
      }
      // ручку игра может «вынести» своим innerHTML-перерендером (места игроков в покере)
      if (!el.querySelector(':scope > .yg-rz')) el.appendChild(rzHandle());
    }

    // ---------- ограничение: окно ВСЕГДА остаётся в видимой зоне листа ----------
    // (лечит «карточки исчезают / уходят в угол»: слой имеет overflow:hidden,
    //  а px-координаты прошлой сессии/перетаскивания могли оказаться за краем)
    function clampWin(win) {
      const lr = layer.getBoundingClientRect();
      if (lr.width < 300 || lr.height < 200) return; // лист ещё не разложен — не трогаем
      const r = win.getBoundingClientRect();
      // окно скрыто (экран входа, display:none) — координаты нулевые, не трогаем
      if (!win.offsetParent || (!r.width && !r.height)) return;
      const ew = win.offsetWidth, eh = win.offsetHeight;
      const M = 8;
      const offL = r.left - lr.left, offT = r.top - lr.top;
      let dL = 0, dT = 0;
      const maxL = Math.max(M, lr.width - ew - M);
      const maxT = Math.max(M, lr.height - eh - M);
      if (offL < M) dL = M - offL; else if (offL > maxL) dL = maxL - offL;
      if (offT < M) dT = M - offT; else if (offT > maxT) dT = maxT - offT;
      if (dL) win.style.left = (win.offsetLeft + dL) + 'px';
      if (dT) win.style.top = (win.offsetTop + dT) + 'px';
    }
    function reclampWins() {
      // игра перерендеривает места/окна: чистим из списка отвалившиеся узлы
      for (let i = wins.length - 1; i >= 0; i--) {
        const el = wins[i];
        if (!el.isConnected) { wins.splice(i, 1); continue; }
        if (el.style.left || el.style.top) clampWin(el);
      }
    }
    reclampAll = reclampWins;

    function markWins(root) {
      for (const s of winSel) {
        try {
          // ВАЖНО: сам добавленный узел тоже может быть окном (querySelectorAll
          // его не находит) — места игроков в покере добавляются именно так
          if (root.matches && root.matches(s)) markWin(root);
          root.querySelectorAll(s).forEach(markWin);
        } catch (_) {}
      }
    }
    markWins(layer);
    const moLayer = new MutationObserver(ms => {
      for (const m of ms) for (const n of m.addedNodes) {
        if (n.nodeType === 1 && n.querySelectorAll) markWins(n);
      }
    });
    moLayer.observe(layer, { childList: true, subtree: true });

    // ---------- «любое окно»: произвольные блоки, схваченные в дизайн-режиме ----------
    // ключ такого окна — CSS-путь от слоя ('p:' + селектор); раскладка
    // восстанавливается при загрузке и после перерисовки игры
    function pathOf(el) {
      const segs = [];
      for (let n = el; n && n !== layer; n = n.parentElement) {
        if (n.id && !/^yg-/.test(n.id)) { segs.unshift('#' + CSS.escape(n.id)); return segs.join(' > '); }
        const idx = Array.prototype.indexOf.call(n.parentElement.children, n) + 1;
        segs.unshift(n.tagName.toLowerCase() + ':nth-child(' + idx + ')');
      }
      return ':scope > ' + segs.join(' > ');
    }
    function resolvePath(sel) {
      try { return sel.startsWith(':scope') ? layer.querySelector(sel) : layer.querySelector(sel); } catch (_) { return null; }
    }
    function markPathWins() {
      for (const k of Object.keys(LAYOUT)) {
        if (!k.startsWith('p:')) continue;
        const el = resolvePath(k.slice(2));
        if (!el || el.classList.contains('yg-win')) continue;
        el.dataset.ygKey = k;
        markWin(el);
      }
    }
    markPathWins();
    let pathRaf = 0;
    new MutationObserver(() => {
      if (pathRaf) return;
      pathRaf = requestAnimationFrame(() => { pathRaf = 0; markPathWins(); });
    }).observe(layer, { childList: true, subtree: true });

    const NOKIDS = /^(INPUT|TEXTAREA|SELECT|IMG|CANVAS|SVG|OPTION|BR|HR)$/i;
    function isFullBox(el) {
      if (el === layer) return true;
      if (el.parentElement === layer && (/^(app|join)$/.test(el.id) || el.classList.contains('wrap'))) return true;
      const lr = layer.getBoundingClientRect(), r = el.getBoundingClientRect();
      return r.width >= lr.width * 0.92 && r.height >= lr.height * 0.85;
    }
    // какое окно схватит мышь: обычный клик — окно целиком (шапка, поле,
    // панель…); с зажатым Alt — самый маленький блок под курсором
    // (отдельная кнопка, строка статуса, полоска таймера и т.д.)
    function pickWin(t, alt) {
      if (!t || t.nodeType !== 1 || !layer.contains(t)) return null;
      if (t.classList.contains('yg-rz')) return t.parentElement;
      if (!alt) { const w = t.closest('.yg-win'); if (w && w !== layer) return w; }
      for (let el = t; el && el !== layer; el = el.parentElement) {
        if (NOKIDS.test(el.tagName) || /^yg-/.test(el.id) || el.classList.contains('yg-rest') || el.classList.contains('yg-print')) continue;
        if (getComputedStyle(el).opacity === '0') continue;
        if (isFullBox(el)) return null;
        const cs = getComputedStyle(el);
        if (cs.display === 'inline' && !/^(BUTTON|A|LABEL)$/.test(el.tagName)) continue;
        const r = el.getBoundingClientRect();
        if (r.width >= 16 && r.height >= 6) return el;
      }
      return null;
    }
    function ensureWin(el) {
      if (!el.classList.contains('yg-win')) { el.dataset.ygKey = 'p:' + pathOf(el); markWin(el); }
      return el;
    }
    const hl = document.createElement('div');
    hl.id = 'yg-hl';
    hl.innerHTML = '<span></span>';
    document.body.appendChild(hl);
    function showHl(el, alt) {
      if (!el) { hl.style.display = 'none'; return; }
      const r = el.getBoundingClientRect();
      hl.style.cssText = 'display:block; left:' + r.left + 'px; top:' + r.top + 'px; width:' + r.width + 'px; height:' + r.height + 'px;';
      hl.firstChild.textContent = (alt ? 'Элемент' : 'Окно') + ' · ' + Math.round(r.width) + '×' + Math.round(r.height) +
        (alt ? '' : '  (Alt — отдельный элемент)');
    }

    // флаг для патча клавиатуры в excel.html: фокус в игре — символы не в ячейку
    window.YG_FOCUS = false;
    layer.addEventListener('mousedown', () => { window.YG_FOCUS = true; }, true);
    document.addEventListener('mousedown', e => { if (!layer.contains(e.target)) window.YG_FOCUS = false; }, true);

      // ---------- тёмный лист Excel: адаптация серого «чистого режима» ----------
      // если лист тёмный (явная тема data-theme=dark или тёмная ОС без явной темы),
      // CSS-правило .yg-darksheet поднимает серые тексты игры
      function sheetDark() {
        const th = document.documentElement.dataset.theme;
        if (th) return th === 'dark';
        try { return matchMedia('(prefers-color-scheme: dark)').matches; } catch (_) { return false; }
      }
      function syncDarkSheet() { document.body.classList.toggle('yg-darksheet', sheetDark()); }
      syncDarkSheet();
      new MutationObserver(syncDarkSheet)
        .observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

      // ---------- «чистый режим» (только текст) ----------
    const SUIT_MAP = {
      '♠': 'пики', '♣': 'трефы', '♥': 'червы', '♦': 'бубны',
      '★': '*', '●': '-', '○': '-', '⚫': '-', '⚪': '-', '⬤': '-',
      '■': '-', '◼': '-', '⬛': '-', '☕': '', '⚑': '-', '⚐': '-', '☂': '',
    };
    const SUIT_TEST = /[♠♣♥♦★●○⚫⚪⬤■◼⬛☕⚑⚐☂]/u;
    const EMOJI_TEST = /[\u{1F000}-\u{1FAFF}\u{1F170}-\u{1F1FF}\u{231A}-\u{23FA}\u{2600}-\u{26FF}\u{2700}-\u{2714}\u{2717}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE0F}\u{200D}\u{203C}\u{2049}\u{2139}\u{3030}\u{303D}\u{3297}\u{3299}]/u;
    const EMOJI_RE = /[\u{1F000}-\u{1FAFF}\u{1F170}-\u{1F1FF}\u{231A}-\u{23FA}\u{2600}-\u{26FF}\u{2700}-\u{2714}\u{2717}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE0F}\u{200D}\u{203C}\u{2049}\u{2139}\u{3030}\u{303D}\u{3297}\u{3299}]/gu;
    function scrubText(t) {
      let s = String(t);
      for (const k in SUIT_MAP) if (s.indexOf(k) > -1) s = s.split(k).join(SUIT_MAP[k]);
      if (EMOJI_TEST.test(s)) s = s.replace(EMOJI_RE, '');
      return s.replace(/[ \t]{2,}/g, ' ').replace(/[ \t]+([.,;:!?])/g, '$1');
    }
    function scrubTarget(node) {
      if (!node) return false;
      if (node.nodeType === 3) {
        if (node.data && (SUIT_TEST.test(node.data) || EMOJI_TEST.test(node.data))) { node.data = scrubText(node.data); return true; }
        return false;
      }
      if (node.nodeType === 1) {
        for (const ch of Array.from(node.childNodes)) if (scrubTarget(ch)) return true;
      }
      return false;
    }
    const moScrub = new MutationObserver(ms => {
      if (document.body.classList.contains('yz-raw')) return;
      for (const m of ms) {
        if (m.type === 'characterData') scrubTarget(m.target);
        else for (const n of m.addedNodes) scrubTarget(n);
      }
    });
    moScrub.observe(layer, { childList: true, subtree: true, characterData: true });
    scrubTarget(layer);
    document.addEventListener('input', e => {
      const t = e.target;
      if (document.body.classList.contains('yz-raw')) return;
      if (!t || (t.tagName !== 'INPUT' && t.tagName !== 'TEXTAREA') || !layer.contains(t)) return;
      const v = t.value;
      if (!v || !(SUIT_TEST.test(v) || EMOJI_TEST.test(v))) return;
      const nv = scrubText(v);
      if (nv === v) return;
      const pos = t.selectionStart || 0;
      t.value = nv;
      try { t.setSelectionRange(Math.min(pos, nv.length), Math.min(pos, nv.length)); } catch (_) {}
    }, true);
    // ---------- вид: «Офис» (по умолчанию) / «Текст» / «Графика» ----------
    //  Офис    — игра в офисной теме: поле, клетки и цвета видны, но
    //            шрифт Calibri, без эмодзи/мастей/картинок/анимаций;
    //  Текст   — старый «чистый режим» (только серый текст);
    //  Графика — как задумано игрой, с эмодзи и картинками.
    const VKEY = 'yz_view';
    // «Ячейки» — игра прямо в ячейках листа (если игра это умеет: window.YZ_CELLS)
    const CELLS = !!window.YZ_CELLS;
    const VIEWS = CELLS ? ['cells', 'office', 'text', 'raw'] : ['office', 'text', 'raw'];
    const VLABEL = { cells: 'Вид: Ячейки', office: 'Вид: Офис', text: 'Вид: Текст', raw: 'Вид: Графика' };
    let view = (() => { try { return localStorage.getItem(VKEY) || 'office'; } catch (_) { return 'office'; } })();
    try { if (CELLS && !localStorage.getItem('yz_cells_seen')) { localStorage.setItem('yz_cells_seen', '1'); view = 'cells'; } } catch (_) {}
    // игра без «Ячеек» не затирает выбор «Ячейки» для остальных игр
    const keep = !VIEWS.includes(view);
    if (keep) view = 'office';
    const gBtn = document.createElement('button');
    gBtn.style.cssText = 'margin-left:10px; font-size:12px; padding:1px 8px;';
    gBtn.title = 'Режим отображения';
    gBtn.className = 'yz-gbtn';
    if (STB) STB.appendChild(gBtn);
    function setView(v, noSave) {
      view = v;
      if (!noSave) try { localStorage.setItem(VKEY, v); } catch (_) {}
      document.body.classList.toggle('ys-office', v === 'office' || v === 'cells');
      if (CELLS) { if (v === 'cells') window.YZ_CELLS.enable(); else window.YZ_CELLS.disable(); }
      document.body.classList.toggle('ow-clean', v === 'text');
      document.body.classList.toggle('yz-raw', v === 'raw');
      gBtn.textContent = VLABEL[v];
      if (v !== 'raw') scrubTarget(layer);
    }
    window.__setMode = setView;
    setView(view, keep);
    gBtn.addEventListener('click', () => setView(VIEWS[(VIEWS.indexOf(view) + 1) % VIEWS.length]));

    // ---------- скрытие верхнего меню (▾ в заголовке Excel) ----------
    if (TT && RT && RB && FX) {
      const hb = document.createElement('button');
      hb.textContent = '▾';
      hb.title = 'Скрыть меню — ячейки до края окна';
      hb.style.cssText = 'font-size:11px; padding:1px 7px; opacity:.85;';
      const shr = $('#shr');
      if (shr && shr.parentNode) shr.parentNode.insertBefore(hb, shr); else TT.appendChild(hb);
      const chip = document.createElement('div');
      chip.className = 'yg-rest';
      chip.textContent = '▾';
      chip.title = 'Показать меню';
      chip.style.left = '2px';
      chip.style.top = '2px';
      layer.appendChild(chip);
      function setTop(off) {
        RT.style.display = off ? 'none' : '';
        RB.style.display = off ? 'none' : '';
        FX.style.display = off ? 'none' : '';
        chip.style.display = off ? 'block' : 'none';
        pinLayer();
      }
      hb.addEventListener('click', () => setTop(true));
      chip.addEventListener('click', () => setTop(false));
    }

    // ---------- скрытие шапки игры / панели действий ----------
    function hideable(el, chipCss, label) {
      if (!el) return;
      const btn = document.createElement('button');
      btn.className = 'yg-hb';
      btn.textContent = '–';
      btn.title = label;
      btn.style.cssText = 'position:absolute; right:6px; top:6px; font-size:11px; padding:1px 7px; z-index:5; background:#fff; border:1px solid #d0d7de; color:#333; cursor:pointer;';
      const cs = getComputedStyle(el).position;
      if (cs === 'static') el.style.position = 'relative';
      el.appendChild(btn);
      const chip = document.createElement('div');
      chip.className = 'yg-rest';
      chip.textContent = '▸';
      chip.title = label.replace('Скрыть', 'Показать');
      chip.style.cssText = chipCss;
      layer.appendChild(chip);
      btn.addEventListener('click', e => { e.stopPropagation(); el.style.display = 'none'; chip.style.display = 'block'; });
      chip.addEventListener('click', () => { el.style.display = ''; chip.style.display = 'none'; });
    }
    hideable(document.querySelector('#app > header'), 'left:2px; top:2px;', 'Скрыть шапку — сделать ячейками');
    hideable(document.querySelector('#actions'), 'left:2px; bottom:2px;', 'Скрыть панель действий — сделать ячейками');

    // ---------- журнал и чат — в нижние вкладки («Лог» / «Чат») ----------
    // кнопки ставим в #bar ПОСЛЕ #tabs: сама функция tabs() Excel'а пересобирает
    // #tabs (innerHTML=''), и в него вставлять нельзя. Выглядят как листы книги.
    const side = document.querySelector('#side') || document.querySelector('#main > aside');
    const barEl = $('#bar');
    if (side && barEl) {
      // секции #side: заголовок .side-title начинает секцию, дальше идут элементы
      const groups = [];
      for (const k of Array.from(side.children)) {
        if (k.classList && k.classList.contains('side-title')) groups.push({ key: null, els: [k] });
        else if (groups.length) groups[groups.length - 1].els.push(k);
      }
      for (const g of groups) {
        if (g.els.some(e => e.id === 'log')) g.key = 'log';
        else if (g.els.some(e => e.id === 'chat-msgs' || e.id === 'chat-box')) g.key = 'chat';
        else if (/журнал|лог|протокол/i.test(g.els[0].textContent)) g.key = 'log';
        else g.key = 'chat';
      }
      const uniq = groups.filter((g, i) => groups.findIndex(x => x.key === g.key) === i);
      if (uniq.length) {
        const SKEY = 'yz_side_' + DOC;
        const st = Object.assign({ log: true, chat: true },
          (() => { try { return JSON.parse(localStorage.getItem(SKEY) || '{}') || {}; } catch (_) { return {}; } })());
        const sep = document.createElement('span');
        sep.style.cssText = 'width:1px; align-self:stretch; margin:3px 2px; background:var(--bd,#e1e1e1); flex:none;';
        barEl.appendChild(sep);
        const btns = {};
        for (const key of ['log', 'chat']) {
          if (!uniq.some(g => g.key === key)) continue;
          const b = document.createElement('button');
          b.type = 'button';
          b.className = 'yn-tab';
          b.textContent = key === 'log' ? 'Лог' : 'Чат';
          b.title = (key === 'log' ? 'Журнал' : 'Чат') + ': показать / скрыть';
          b.addEventListener('click', () => {
            st[key] = !st[key];
            try { localStorage.setItem(SKEY, JSON.stringify(st)); } catch (_) {}
            applySide();
          });
          btns[key] = b;
          barEl.appendChild(b);
        }
        function applySide() {
          for (const g of uniq) {
            const off = !st[g.key];
            for (const e of g.els) e.classList.toggle('yn-hid', off);
            if (btns[g.key]) btns[g.key].classList.toggle('on', !off);
          }
          side.classList.toggle('yn-side-empty', !uniq.some(g => st[g.key]));
        }
        applySide();
      }
    }

    // ---------- Ctrl+P: окно «Печать» в стиле Excel ----------
    let printOpen = false;
    const pBox = document.createElement('div');
    pBox.className = 'yg-print';
    pBox.innerHTML =
      '<div class="yg-pdlg">' +
        '<div class="t"><span>▦</span><span>Печать — ' + escX(DOC) + '</span><span class="x" title="Закрыть">✕</span></div>' +
        '<div class="b">' +
          '<div class="r"><label>Имя принтера:</label><select><option>Microsoft Print to PDF</option><option>Электронный документ (Excel)</option></select></div>' +
          '<div class="r"><label>Область печати:</label><select><option>Весь лист</option><option>Текущий диапазон</option></select></div>' +
          '<div class="r"><label>Копий:</label><input value="1"></div>' +
          '<div class="r"><label>Ориентация:</label><select><option>Альбомная</option><option>Книжная</option></select></div>' +
        '</div>' +
        '<div class="f"><button class="c" type="button">Отмена</button><button class="p" type="button">Печать</button></div>' +
      '</div>';
    layer.appendChild(pBox);
    function closePrint() { printOpen = false; pBox.classList.remove('on'); }
    pBox.querySelector('.x').addEventListener('click', closePrint);
    pBox.querySelector('.c').addEventListener('click', closePrint);
    pBox.querySelector('.p').addEventListener('click', () => { closePrint(); const sb = $('#sb'); if (sb) sb.textContent = 'Печать: отправка в очередь…'; });
    pBox.addEventListener('mousedown', e => e.stopPropagation());
    document.addEventListener('keydown', e => {
      if ((e.ctrlKey || e.metaKey) && !e.altKey && (e.key === 'p' || e.key === 'P' || e.key === 'з' || e.key === 'З')) {
        e.preventDefault();
        e.stopImmediatePropagation();
        if (!printOpen) { printOpen = true; pBox.classList.add('on'); }
      }
    }, true);

    // ---------- вкладка «Разработчик»: дизайн-режим (перетаскивание + размер) ----------
    let designOn = false;
    const pdev = $('#p-dev');
    if (pdev) {
      const nt = pdev.querySelector('.nt');
      if (nt) nt.remove();
      const g = document.createElement('div');
      g.className = 'g';
      g.innerHTML =
        '<div class="gb"><div class="rw">' +
        '<button id="yg-dzn" type="button" title="Перетаскивание и размер игровых окон. Двойной клик по окну — сброс. Esc — выйти из режима.">▦ Дизайн элементов</button>' +
        '<button id="yg-rst" type="button" title="Вернуть исходную раскладку игровых окон">↺ Сбросить раскладку</button>' +
        '</div></div><div class="gl">Макет</div>';
      pdev.appendChild(g);
    }
    const dzn = $('#yg-dzn'), rstB = $('#yg-rst');
    const dhint = document.createElement('div');
    dhint.id = 'yg-dhint';
    dhint.textContent = 'Дизайн: тянуть — переместить окно · Alt+тянуть — любой отдельный элемент · угол — размер · двойной клик — сбросить · Esc — выход';
    layer.appendChild(dhint);

    function setDesign(on) {
      if (designOn === on) return;
      designOn = on;
      layer.classList.toggle('yg-designing', on);
      if (!on) showHl(null);
      document.body.classList.toggle('yg-design', on);
      if (dzn) {
        dzn.classList.toggle('on', on);
        dzn.textContent = on ? '▦ Дизайн: ВКЛ' : '▦ Дизайн элементов';
      }
      // в режиме дизайна контейнеры игры не скроллятся —
      // иначе абсолютные окна «уезжали» бы вместе с контентом
      layer.querySelectorAll(':scope > :is(#app,.wrap,#join)')
        .forEach(c => { c.style.overflow = on ? 'visible' : ''; });
      if (on) pinLayer();
    }
    if (dzn) dzn.addEventListener('click', () => setDesign(!designOn));
    if (rstB) rstB.addEventListener('click', () => {
      if (!confirm('Вернуть исходную раскладку игровых окон?')) return;
      try { localStorage.removeItem(LKEY); Object.keys(localStorage).filter(k => k.indexOf('yz_cells_off_') === 0).forEach(k => localStorage.removeItem(k)); } catch (_) {}
      location.reload();
    });

    // перетаскивание + изменение размера (capture — раньше игровых обработчиков)
    // ОГРАНИЧЕНИЕ: окно не может уйти за границу листа (не исчезнет, не «уедет в угол»)
    layer.addEventListener('mousedown', e => {
      if (!designOn || !e.target.closest) return;
      e.preventDefault();
      e.stopPropagation();
      const picked = pickWin(e.target, e.altKey);
      if (!picked) return;
      const win = ensureWin(picked);
      const lr = layer.getBoundingClientRect();
      const r0 = win.getBoundingClientRect();
      const s = { x: e.clientX, y: e.clientY, l: win.offsetLeft, t: win.offsetTop,
                 w: win.offsetWidth, h: win.offsetHeight,
                 rL: r0.left - lr.left, rT: r0.top - lr.top, moved: false };
      if (getComputedStyle(win).position !== 'absolute') {
        // фиксируем размер, иначе блок «сжимается», выпав из потока
        win.style.width = s.w + 'px';
        win.style.height = s.h + 'px';
        win.style.position = 'absolute';
        win.style.left = s.l + 'px';
        win.style.top = s.t + 'px';
      }
      const mode = e.target.classList.contains('yg-rz') ? 'rz' : 'mv';
      const mm = ev => {
        const dx = ev.clientX - s.x, dy = ev.clientY - s.y;
        if (!s.moved && Math.abs(dx) + Math.abs(dy) < 3) return;
        s.moved = true;
        const lrw = layer.clientWidth || lr.width, lrh = layer.clientHeight || lr.height;
        if (mode === 'mv') {
          // целевая позиция в координатах листа, с ограничением по краям
          const M = 8;
          const wantL = Math.min(Math.max(M, s.rL + dx), Math.max(M, lrw - s.w - M));
          const wantT = Math.min(Math.max(M, s.rT + dy), Math.max(M, lrh - s.h - M));
          win.style.left = (s.l + (wantL - s.rL)) + 'px';
          win.style.top = (s.t + (wantT - s.rT)) + 'px';
        } else {
          const M = 8;
          const maxW = Math.max(90, lrw - s.rL - M);
          const maxH = Math.max(50, lrh - s.rT - M);
          win.style.width = Math.min(maxW, Math.max(90, s.w + dx)) + 'px';
          win.style.height = Math.min(maxH, Math.max(50, s.h + dy)) + 'px';
        }
      };
      const mu = () => {
        document.removeEventListener('mousemove', mm);
        document.removeEventListener('mouseup', mu);
        showHl(win, false);
        if (s.moved) {
          const L = loadLayout();
          L[win.dataset.ygKey] = { l: win.offsetLeft, t: win.offsetTop, w: win.offsetWidth, h: win.offsetHeight };
          saveLayout(L);
        }
      };
      document.addEventListener('mousemove', mm);
      document.addEventListener('mouseup', mu);
    }, true);

    // двойной клик по окну — вернуть его на исходное место
    layer.addEventListener('dblclick', e => {
      if (!designOn || !e.target.closest) return;
      e.preventDefault(); e.stopPropagation();
      const win = pickWin(e.target, e.altKey);
      if (!win || !win.dataset.ygKey) return;
      const L = loadLayout();
      delete L[win.dataset.ygKey];
      saveLayout(L);
      resetPos(win);
    }, true);

    // подсветка того, что будет схвачено + гасим клики игры в дизайн-режиме
    layer.addEventListener('mousemove', e => { if (designOn && !e.buttons) showHl(pickWin(e.target, e.altKey), e.altKey); }, true);
    layer.addEventListener('mouseleave', () => showHl(null));
    for (const ev of ['click', 'contextmenu', 'focusin', 'pointerup']) {
      layer.addEventListener(ev, e => { if (designOn) { e.preventDefault(); e.stopPropagation(); if (ev === 'focusin' && e.target.blur) e.target.blur(); } }, true);
    }

    // Esc (capture — раньше босс-режима panic.js):
    // сначала закрывает окно печати, потом выключает дизайн-режим,
    // и только если ничего не открыто — срабатывает паника
    document.addEventListener('keydown', e => {
      if (e.key !== 'Escape') return;
      if (printOpen) { closePrint(); e.stopPropagation(); return; }
      if (designOn) { setDesign(false); e.stopPropagation(); }
    }, true);
    // в режиме дизайна клавиатура заморожена (ни лист, ни игра не реагируют)
    document.addEventListener('keydown', e => {
      if (designOn && e.key !== 'Escape') e.stopPropagation();
    }, true);
  });
})();
