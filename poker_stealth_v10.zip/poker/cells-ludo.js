// ============================================================
//  cells-ludo.js — «Маршрутный лист» (лудо) прямо в ячейках листа «Маршрут»
//  (адаптер для общего движка cells-core.js)
//    A1–A3    — заголовок: название, статус/подсказка, итог
//    B5:P19   — поле 15×15 (фишки «A1», «B3»…; ход — жёлтая ячейка, клик по ней)
//    B20/B21  — бросок и время хода «————»
//    R…       — кнопки, участники, журнал, комментарии, ввод комментария
//  Пробел — бросок (когда ваш ход). Всё можно двигать в «Дизайн элементов».
// ============================================================
(function () {
  'use strict';
  if (!window.YZ_CELLS_CORE) return;
  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));
  const txt = el => el ? el.textContent.replace(/\s+/g, ' ').trim() : '';
  const shown = el => !!el && !el.classList.contains('hidden') && el.style.display !== 'none';
  const COLORS = ['red', 'blue', 'yellow', 'green'];
  const FG = { red: '#c00000', blue: '#0070c0', yellow: '#bf8f00', green: '#548235' };
  const TINT = { red: '#fbe2d5', blue: '#deebf7', yellow: '#fff2cc', green: '#e2efda' };
  const TINT2 = { red: '#f4b183', blue: '#9dc3e6', yellow: '#ffd966', green: '#a9d08e' };
  const NAME = { red: 'Красный', blue: 'Синий', yellow: 'Жёлтый', green: 'Зелёный' };
  const BASES = [{ color: 'red', r0: 9, c0: 1 }, { color: 'blue', r0: 9, c0: 10 }, { color: 'yellow', r0: 1, c0: 10 }, { color: 'green', r0: 1, c0: 1 }];
  const colorOf = el => COLORS.find(c => el.classList.contains('t-' + c) || el.classList.contains('h-' + c));
  const BR = 4, BC = 1, RC = 17;              // поле: строки 5–19, столбцы B–P; панель — столбец R
  const BTN_R0 = 1, BTN_N = 6, PL_H = 8, PL_R0 = 9, LOG_H = 14, LOG_R0 = 15, LOG_N = 6, CH_H = 22, CH_R0 = 23, CH_N = 4, CH_L = 27, CH_IN = 28;
  const COLW = { 0: 20, 16: 20, 17: 300 };
  for (let c = 0; c < 15; c++) COLW[BC + c] = 26;
  const MERGES = [
    { r1: 0, r2: 0, c1: 0, c2: 16 }, { r1: 1, r2: 1, c1: 0, c2: 16 }, { r1: 2, r2: 2, c1: 0, c2: 16 },
    { r1: 19, r2: 19, c1: 1, c2: 15 }, { r1: 20, r2: 20, c1: 1, c2: 15 },
  ];
  BASES.forEach(b => MERGES.push({ r1: BR + b.r0, r2: BR + b.r0, c1: BC + b.c0, c2: BC + b.c0 + 3 }));

  YZ_CELLS_CORE.register({
    game: 'ludo',
    root: '#app',
    blocks: [
      { id: 'head', name: 'Заголовок', r1: 0, r2: 2, c1: 0, c2: 16, cw: false },
      { id: 'board', name: 'Поле', r1: 3, r2: 18, c1: 0, c2: 16 },
      { id: 'dice', name: 'Бросок и время', r1: 19, r2: 20, c1: 0, c2: 16, cw: false },
      { id: 'panel', name: 'Панель (кнопки, участники, журнал, чат)', r1: 0, r2: CH_IN, c1: RC, c2: RC },
    ],
    colw: COLW,
    merges: MERGES,
    chatIn: {
      r: CH_IN, c: RC,
      send(v) { const inp = $('#chat-in'); if (inp) { inp.value = v; inp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true })); } },
    },
    // Пробел — бросок
    key(e) {
      if (e.key !== ' ') return false;
      const b = $('#btn-roll');
      if (!shown(b)) return false;
      b.click();
      return true;
    },
    compose(k) {
      const BG = {};
      const put = (r, c, v, s) => { if (s && s.bg) BG[r + ',' + c] = s.bg; else if (s && BG[r + ',' + c] && !('bg' in s)) s = Object.assign({ bg: BG[r + ',' + c] }, s); k.put(r, c, v, s); };
      put(0, 0, 'Маршрутный лист техпроцесса', { b: true, sz: 14 });
      if (!shown($('#app'))) { put(1, 0, 'Документ не открыт — введите имя в окне входа', { fg: '#7f7f7f' }); return; }
      put(1, 0, [txt($('#h-phase')), txt($('#turn-hint'))].filter(Boolean).join(' · '), { fg: '#595959' });
      const banner = $('#banner');
      if (shown(banner)) put(2, 0, [txt($('#b-title')), txt($('#b-text'))].filter(Boolean).join(' — '), { fg: '#7f7f7f', i: true });

      // ---- поле ----
      const cells = $$('#grid > .cell');
      if (cells.length >= 225) {
        for (let i = 0; i < 225; i++) {
          const el = cells[i], cl = el.classList, r = BR + ((i / 15) | 0), c = BC + (i % 15);
          const gr = (i / 15) | 0, gc = i % 15;
          const center = gr >= 6 && gr <= 8 && gc >= 6 && gc <= 8;
          let v = null, s = null;
          if (center) { s = { bg: '#e7e6e6', al: 'center' }; if (gr === 7 && gc === 7) { v = '⌂'; s.fg = '#7f7f7f'; } }
          else if (cl.contains('home')) s = { bg: TINT2[colorOf(el)] || '#eee', al: 'center' };
          else if (cl.contains('track')) {
            s = { al: 'center', bg: '#f2f2f2' };
            if (cl.contains('start')) s.bg = TINT2[colorOf(el)] || '#eee';
            else if (cl.contains('safe')) { v = '*'; s.fg = '#a6a6a6'; }
          }
          if (v != null || s) put(r, c, v, s);
        }
      }
      BASES.forEach(b => {
        for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) put(BR + b.r0 + y, BC + b.c0 + x, null, { bg: TINT[b.color], al: 'center' });
        put(BR + b.r0, BC + b.c0, NAME[b.color], { bg: TINT[b.color], fg: '#7f7f7f', sz: 9 });
      });
      // ---- фишки ----
      const per = {};
      $$('#board > .token').forEach(t => {
        const gx = Math.floor(parseFloat(t.style.left) / 100 * 15), gy = Math.floor(parseFloat(t.style.top) / 100 * 15);
        if (!(gx >= 0 && gx < 15 && gy >= 0 && gy < 15)) return;
        const key = gy + ',' + gx;
        (per[key] = per[key] || []).push(t);
      });
      Object.keys(per).forEach(key => {
        const [gy, gx] = key.split(',').map(Number), list = per[key], r = BR + gy, c = BC + gx;
        const first = list[0], col = colorOf(first);
        const lab = t => txt(t).replace('-', '');
        const v = list.length === 1 ? lab(first) : (list.every(t => colorOf(t) === col) ? lab(first)[0] + '×' + list.length : list.length + '!');
        const mv = list.find(t => t.classList.contains('movable'));
        const s = { al: 'center', b: true, fg: FG[col] || '#262626' };
        if (mv) { s.bg = '#ffff00'; k.click(r, c, mv); }
        put(r, c, v, s);
      });

      // ---- бросок и время ----
      const die = txt($('#die'));
      put(19, 1, 'Бросок: ' + (die || '—') + (shown($('#btn-roll')) ? '   (Пробел или кнопка «Выполнить бросок» справа)' : ''), { b: die === '6', fg: die === '6' ? '#c00000' : '#262626' });
      const fill = $('#timer-fill');
      const pct = fill ? parseFloat(fill.style.width) || 0 : 0;
      put(20, 1, pct > 0 ? '—'.repeat(Math.max(1, Math.round(pct / 100 * 50))) : '', { fg: '#8a8a8a' });

      // ---- панель ----
      put(0, RC, 'Действия', { b: true });
      const btns = [];
      ['#btn-roll', '#btn-start'].forEach(id => { const b = $(id); if (shown(b)) btns.push(b); });
      if (shown(banner)) $$('#b-btns button').forEach(b => btns.push(b));
      $$('#app > header button').filter(b => !b.classList.contains('yg-hb') && b.id !== 'btn-panic' && shown(b)).forEach(b => btns.push(b));
      const cat = $('#app > header a.yh-cat'), close = $('#btn-panic');
      btns.concat(cat ? [cat] : [], close ? [close] : []).slice(0, BTN_N).forEach((b, i) => {
        put(BTN_R0 + i, RC, txt(b), { al: 'center', bg: b.id === 'btn-roll' ? '#fff2cc' : '#f2f2f2', bt: 1, bb: 1, bl: 1, br: 1, b: b.id === 'btn-roll' });
        k.click(BTN_R0 + i, RC, b);
      });
      put(PL_H, RC, 'Участники', { b: true });
      $$('#players > .pl').slice(0, 4).forEach((p, i) => {
        const col = colorOf(p.querySelector('.dot') || p);
        const turn = p.classList.contains('turn');
        put(PL_R0 + i, RC, (turn ? '→ ' : '    ') + txt(p.querySelector('b')) + ' — ' + txt(p.querySelector('.home')), { fg: FG[col] || '#262626', b: turn });
      });
      put(LOG_H, RC, 'Журнал', { b: true });
      $$('#log > *').map(txt).filter(Boolean).slice(-LOG_N).forEach((t, i) => put(LOG_R0 + i, RC, t, { fg: '#595959' }));
      put(CH_H, RC, 'Комментарии', { b: true });
      $$('#chat-msgs > *').map(txt).filter(Boolean).slice(-CH_N).forEach((t, i) => put(CH_R0 + i, RC, t, { fg: '#262626' }));
      put(CH_L, RC, 'Новый комментарий — в ячейку ниже, Enter ↓', { fg: '#7f7f7f', i: true });
    },
  });
})();
