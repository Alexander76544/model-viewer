@echo off
rem ============================================================================
rem  Подпольный ЯМЗ — запуск сервера для игры по локальной сети (serve.js)
rem
rem  ИЩЕТ И ЗАПОМИНАЕТ node.exe (свой node-home.txt рядом):
rem    сохранённый путь -> PATH -> типовые папки -> ручной ввод.
rem  Введённый один раз путь запоминается в node-home.txt
rem  (можно поправить вручную).
rem
rem  Аргументы: bat (без аргументов)
rem  Путь к node: set NODE_CMD=D:\tools\node.exe — явно указать свой node.exe
rem  Порт:      set PORT=xxxx   (по умолчанию 4180)
rem  IP:        set IP=192.168.31.99   — показать игрокам только свой адрес
rem
rem  ХОСТ:      запустите этот bat — в окне появятся адреса:
rem              http://127.0.0.1:4180      — для вас
rem              http://192.168.x.x:4180    — раздайте этот адрес игрокам,
rem                                            они откроют его в браузере
rem  Остановка: Ctrl+C в этом окне (или закрыть окно).
rem ============================================================================
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
if not defined PORT set "PORT=4180"

rem --- сервер уже запущен на этом порту? -------------------------------------
powershell -NoProfile -Command "try{(New-Object Net.Sockets.TcpClient).Connect('127.0.0.1',%PORT%);exit 0}catch{exit 1}" >nul 2>nul <nul
if not errorlevel 1 (
  echo [ЯМЗ] Сервер уже работает на http://127.0.0.1:%PORT%/ — открываю браузер.
  start "" "http://127.0.0.1:%PORT%/"
  exit /b 0
)

call :findnode
if not defined NODE goto asknode

:nodeok
if not exist "%~dp0serve.js" (
  echo [ЯМЗ] Не найден serve.js рядом с этим bat. Положите bat в папку poker.
  pause
  exit /b 1
)

echo.
echo [ЯМЗ] node : "!NODE!"
echo.
echo [ЯМЗ] адрес: http://127.0.0.1:%PORT%/   Ctrl+C в этом окне — остановить
echo [ЯМЗ] игрокам в локальной сети раздайте адрес "По Wi-Fi/LAN",
echo         который появится в этом окне при старте.
echo.
start "" /b powershell -NoProfile -Command "Start-Sleep 2; Start-Process 'http://127.0.0.1:%PORT%/'"
"!NODE!" "%~dp0serve.js"
if errorlevel 1 pause
exit /b %errorlevel%

rem ============================= поиск node ==================================
:findnode
set "NODE="
rem 1) явный путь:  set NODE_CMD=D:\tools\node.exe
if defined NODE_CMD call :ckrun "%NODE_CMD%"
if defined NODE exit /b 0
if exist "%~dp0node-home.txt" (
  set "NH="
  set /p NH=<"%~dp0node-home.txt"
  if defined NH (
    call :resolve "!NH!" node.exe
    call :ckrun "!RSLV!"
  )
)
if defined NODE exit /b 0
for /f "delims=" %%i in ('where node 2^>nul ^<nul') do if not defined NODE call :ckrun "%%i"
for %%C in (
  "%ProgramFiles%\nodejs\node.exe"
  "%ProgramFiles(x86)%\nodejs\node.exe"
  "%LocalAppData%\Programs\nodejs\node.exe"
  "%ProgramData%\chocolatey\bin\node.exe"
  "%USERPROFILE%\scoop\shims\node.exe"
  "%ProgramFiles%\Volta\bin\node.exe"
  "%APPDATA%\nvm\nodejs\node.exe"
  "%NVM_SYMLINK%\node.exe"
  "%~dp0node.exe"
) do if not defined NODE if exist %%C call :ckrun "%%~C"
exit /b 0

:asknode
echo.
echo [ЯМЗ] Node.js не найден автоматически ^(PATH и типовые папки^).
echo      Напишите путь к node.exe ИЛИ к папке с ним, например:
echo        D:\tools\node-v20\node.exe     или     D:\tools\node-v20
echo      ^(q — отмена^).
set "NTRY=0"
:askloop
set /a NTRY+=1
if %NTRY% GTR 20 (echo [ЯМЗ] Слишком много неудачных попыток. Отменено. & exit /b 1)
set "NIN="
set /p NIN=[ЯМЗ] путь к node.exe: 
if /i "!NIN!"=="q" (echo [ЯМЗ] Отменено. & exit /b 1)
call :resolve "!NIN!" node.exe
call :ckrun "!RSLV!"
if defined NODE (
  >"%~dp0node-home.txt" echo !RSLV!
  echo [ЯМЗ] node запомнен в node-home.txt
  exit /b 0
)
echo [ЯМЗ] Там нет рабочего node.exe. Попробуйте ещё раз ^(q — отмена^).
goto askloop

rem =============================== подпрограммы ==============================
:resolve
rem %1 = exe или папка, %2 = имя exe в папке -> RSLV
set "RSLV=%~1"
if /i not "%~x1"==".exe" set "RSLV=%~1\%~2"
exit /b 0

:ckrun
rem %1 = полный путь к exe; проверяет запуском --version; успех -> NODE
set "CND=%~1"
if not exist "!CND!" exit /b 1
"!CND!" --version >nul 2>nul <nul || exit /b 2
set "NODE=!CND!"
exit /b 0
