// Проверка шифрования (TLS) сервера ЯМЗ.
// Запуск:  node проверить-шифрование.js        (порт 4180)
//          для другого порта: set PORT=4181 && node проверить-шифрование.js
// Проверяет: 1) страница отдаётся по HTTPS, 2) WebSocket работает через TLS
// (заходит наблюдателем, получает состояние игры и выходит).
'use strict';
const https = require('https');
const tls = require('tls');
const crypto = require('crypto');
const PORT = parseInt(process.env.PORT || '4180', 10);
const HOST = '127.0.0.1';
let fail = 0;
const ok = m => console.log('  [OK] ' + m);
const bad = m => { console.log('  [FAIL] ' + m); fail = 1; };

console.log('Проверка TLS сервера на ' + HOST + ':' + PORT + '…');
const req = https.get({ host: HOST, port: PORT, path: '/poker', rejectUnauthorized: false }, res => {
  let b = '';
  res.on('data', d => b += d);
  res.on('end', () => {
    if (res.statusCode === 200 && b.includes('office.js')) ok('HTTPS: страница /poker отдаётся (TLS работает)');
    else bad('HTTPS: статус ' + res.statusCode);
    const socket = tls.connect({ host: HOST, port: PORT, rejectUnauthorized: false }, () => {
      const key = crypto.randomBytes(16).toString('base64');
      socket.write('GET /ws HTTP/1.1\r\nHost: ' + HOST + ':' + PORT + '\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: ' + key + '\r\nSec-WebSocket-Version: 13\r\n\r\n');
    });
    let data = Buffer.alloc(0); let upgraded = false;
    const finish = () => { console.log(fail ? 'ИТОГ: есть проблемы' : 'ИТОГ: шифрование работает, всё в порядке'); process.exit(fail); };
    const timer = setTimeout(() => { bad('WSS: нет ответа (таймаут 6 с)'); socket.destroy(); finish(); }, 6000);
    socket.on('data', d => {
      data = Buffer.concat([data, d]);
      if (!upgraded) {
        const s = data.toString('latin1'); const i = s.indexOf('\r\n\r\n');
        if (i === -1) return;
        upgraded = true;
        if (s.slice(0, 15) !== 'HTTP/1.1 101 Sw') { bad('WSS: upgrade отклонён: ' + s.slice(0, 40)); socket.destroy(); finish(); return; }
        ok('WSS: WebSocket через TLS установлен');
        data = data.slice(i + 4); // после HTTP-заголовка — только WS-фреймы
        const payload = Buffer.from(JSON.stringify({ t: 'join', name: 'Проверка-TLS', spectate: true, uid: 'u-tls-check' }));
        const mask = crypto.randomBytes(4);
        socket.write(Buffer.concat([Buffer.from([0x81, 0x80 | payload.length]), mask, Buffer.from(payload.map((x, i) => x ^ mask[i & 3]))]));
      }
      if (data.length < 2) return;
      let len = data[1]; let off = 2;
      if (len === 126) { if (data.length < 4) return; len = data.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (data.length < 10) return; len = Number(data.readBigUInt64BE(2)); off = 10; }
      if (data.length < off + len) return;
      let m; try { m = JSON.parse(data.slice(off, off + len).toString('utf8')); } catch (e) { return; }
      clearTimeout(timer);
      if (m.t === 'state') { ok('WSS: игра отвечает (состояние: ' + m.phase + ')'); socket.destroy(); finish(); }
      else { bad('WSS: неожиданное сообщение: ' + m.t); socket.destroy(); finish(); }
    });
    socket.on('error', e => { clearTimeout(timer); bad('TLS: ' + e.message + ' (сервер запущен без сертификата?)'); finish(); });
  });
});
req.on('error', e => { bad('HTTPS: ' + e.message + ' — сервер отвечает не по TLS (перезапустите сервер с server.crt/server.key рядом)'); process.exit(1); });
