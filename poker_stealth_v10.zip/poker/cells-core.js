// ============================================================
//  cells-core.js — общий движок «игра прямо в ячейках листа»
//  Игра регистрирует адаптер: YZ_CELLS_CORE.register({...}).
//  Движок:
//    • зеркалит состояние скрытых окон игры в ячейки (hf.batch, без undo);
//    • пересылает клики / наведение / ПКМ по ячейкам скрытым элементам;
//    • защищает игровые ячейки от случайного ввода (кроме ячейки чата);
//    • ДИЗАЙН (Разработчик → Дизайн элементов): любой блок
//      (поле, панель…) тянется мышью на ЛЮБУЮ ячейку листа,
//      двойной клик по блоку — вернуть на место. Раскладка сохраняется.
//  Для yg-bridge.js / panic.js наружу: window.YZ_CELLS {enable,disable,force,isOn}
// ============================================================
(function () {
  'use strict';
  let def = null, ready = false, wantOn = false, on = false, api = null;
  window.YZ_CELLS = {
    enable() { wantOn = true; if (ready) api.enable(); },
    disable() { wantOn = false; if (ready) api.disable(); },
    force() { if (ready) api.force(); },
    isOn: () => on,
    resetLayout() { if (ready) api.resetLayout(); },
  };
  window.YZ_CELLS_CORE = {
    register(d) { def = d; if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(init, 0)); else setTimeout(init, 0); },
  };

  function init() {
    if (!def || typeof hf === 'undefined' || typeof refresh !== 'function' || typeof build !== 'function') return;
    const $ = s => document.querySelector(s);
    const SHEET = (window.OFFICE && OFFICE.tabs && OFFICE.tabs[0]) || hf.getSheetNames()[0];
    const gid = () => { try { return hf.getSheetId(SHEET); } catch (_) { return undefined; } };
    if (gid() === undefined) return;

    const OKEY = 'yz_cells_off_' + def.game;
    const BL = def.blocks;                       // [{id,name,r1,r2,c1,c2}] — логические координаты
    let off = {};
    try { off = JSON.parse(localStorage.getItem(OKEY) || '{}') || {}; } catch (_) { off = {}; }
    const O = id => off[id] || { dr: 0, dc: 0 };
    const blockOfL = (r, c) => BL.find(b => r >= b.r1 && r <= b.r2 && c >= b.c1 && c <= b.c2);
    const toP = (r, c) => { const b = blockOfL(r, c); const o = b ? O(b.id) : { dr: 0, dc: 0 }; return { r: r + o.dr, c: c + o.dc }; };
    const rectP = b => { const o = O(b.id); return { r1: b.r1 + o.dr, r2: b.r2 + o.dr, c1: b.c1 + o.dc, c2: b.c2 + o.dc }; };
    // физическая ячейка → логическая (последний блок сверху)
    function toL(r, c) {
      for (let i = BL.length - 1; i >= 0; i--) {
        const b = BL[i], R = rectP(b);
        if (r >= R.r1 && r <= R.r2 && c >= R.c1 && c <= R.c2) return { r: r - R.r1 + b.r1, c: c - R.c1 + b.c1, b };
      }
      return null;
    }
    const inZone = (r, c) => !!toL(r, c);

    const panicOn = () => !!(window.YAMZ_PANIC && window.YAMZ_PANIC.isOn());
    const designOn = () => document.body.classList.contains('yg-design');
    const safe = v => (typeof v === 'string' && v && /^[=+\-@']|^[\d\s.,:\/%-]+$/.test(v)) ? "'" + v : v;

    let prev = null, writing = false, raf = 0;
    // ---------- «Снять защиту игры»: свои тексты и цвета поверх игры ----------
    //  правки хранятся в логических координатах блока → переезжают вместе с блоком
    const VKEY = 'yz_cells_ovr_' + def.game;
    let ovr = {};
    try { ovr = JSON.parse(localStorage.getItem(VKEY) || '{}') || {}; } catch (_) { ovr = {}; }
    const saveOvr = () => { try { localStorage.setItem(VKEY, JSON.stringify(ovr)); } catch (_) {} };
    let unlocked = false;
    // ячейки ввода (чат, суммы…): ввели значение + Enter → send(v)
    const INS = () => (typeof def.inputs === 'function' ? def.inputs() : (def.inputs || [])).concat(def.chatIn ? [def.chatIn] : []);
    const inputAt = (r, c) => INS().find(i => { const p = toP(i.r, i.c); return p.r === r && p.c === c; });
    let clickMap = {}, hoverMap = {}, ctxMap = {};

    // ---------- состояние игры → ячейки ----------
    function compose() {
      const V = new Map(), S = {};
      clickMap = {}; hoverMap = {}; ctxMap = {};
      const k = {
        put(r, c, v, s) { const p = toP(r, c); const key = p.r + ',' + p.c; V.set(key, v == null || v === '' ? null : v); if (s) S[key] = s; },
        click(r, c, t) { const p = toP(r, c); clickMap[p.r + ',' + p.c] = t; },
        hover(r, c, t) { const p = toP(r, c); hoverMap[p.r + ',' + p.c] = t; },
        ctx(r, c, t) { const p = toP(r, c); ctxMap[p.r + ',' + p.c] = t; },
      };
      def.compose(k);
      INS().forEach(inp => {
        const p = toP(inp.r, inp.c);
        const key = p.r + ',' + p.c;
        S[key] = Object.assign({ bb: 1, bt: 1, bl: 1, br: 1, bg: '#ffffff' }, S[key] || {});
        if (!V.has(key) || inp.clear !== false) V.set(key, null);
      });
      for (const lk in ovr) {
        const [lr, lc] = lk.split(',').map(Number);
        if (!blockOfL(lr, lc)) continue;
        const p = toP(lr, lc), key = p.r + ',' + p.c, o = ovr[lk];
        if ('v' in o) V.set(key, o.v);
        if (o.s) { const x = Object.assign({}, S[key] || {}); for (const q in o.s) { if (o.s[q] == null) delete x[q]; else x[q] = o.s[q]; } S[key] = x; }
      }
      return { V, S };
    }
    function layout() {
      const G = gid(); if (G === undefined) return;
      // ширины столбцов: первый блок (поле) главнее
      const W = {};
      for (let i = BL.length - 1; i >= 0; i--) {
        const b = BL[i], o = O(b.id);
        if (b.cw === false) continue;
        for (let c = b.c1; c <= b.c2; c++) if (def.colw[c] != null) W[c + o.dc] = def.colw[c];
      }
      cw[G] = W;
      // объединение, налезающее на другой блок, снимаем — иначе оно закроет его ячейки
      const hit = (a, b) => a.r1 <= b.r2 && b.r1 <= a.r2 && a.c1 <= b.c2 && b.c1 <= a.c2;
      mgs[G] = (def.merges || []).map(m => {
        const own = blockOfL(m.r1, m.c1), p = toP(m.r1, m.c1);
        const R = { r1: p.r, r2: p.r + (m.r2 - m.r1), c1: p.c, c2: p.c + (m.c2 - m.c1) };
        return BL.some(b => b !== own && hit(R, rectP(b))) ? null : R;
      }).filter(Boolean);
      let mr = 0, mc = 0;
      BL.forEach(b => { const R = rectP(b); mr = Math.max(mr, R.r2); mc = Math.max(mc, R.c2); });
      if (typeof grow === 'function' && (mr + 6 > NR || mc + 3 > NC)) { NR = Math.max(NR, mr + 6); NC = Math.max(NC, mc + 3); }
    }
    function render() {
      raf = 0;
      if (!on || panicOn()) return;
      const G = gid(); if (G === undefined) return;
      const { V, S } = compose();
      writing = true;
      try {
        hf.batch(() => {
          const set = (key, v) => { const [r, c] = key.split(',').map(Number); hf.setCellContents({ sheet: G, row: r, col: c }, [[v == null ? null : safe(v)]]); };
          if (!prev) {
            // полная перерисовка: стереть всё в блоках (вдруг что-то вставили руками)
            BL.forEach(b => { const R = rectP(b); for (let r = R.r1; r <= R.r2; r++) for (let c = R.c1; c <= R.c2; c++) { const key = r + ',' + c; if (!V.has(key)) set(key, null); } });
            V.forEach((v, key) => set(key, v));
          } else {
            prev.forEach((v, key) => { if (!V.has(key) && v != null) set(key, null); });
            V.forEach((v, key) => { if (prev.get(key) !== v) set(key, v); });
          }
        });
        if (hf.clearUndoStack) hf.clearUndoStack();
      } catch (_) {}
      writing = false;
      const SS = (st[G] = st[G] || {});
      if (prevS) for (const key of prevS) delete SS[key];
      BL.forEach(b => { const R = rectP(b); for (let r = R.r1; r <= R.r2; r++) for (let c = R.c1; c <= R.c2; c++) delete SS[r + ',' + c]; });
      for (const key in S) SS[key] = Object.assign({}, S[key]);   // копии: правка цвета не портит общие стили адаптера
      prevS = Object.keys(S);
      prev = V;
      if (sid === G) { refresh(); if (drag || hl) drawHl(); }
    }
    let prevS = null;
    const schedule = () => { if (on && !raf) raf = requestAnimationFrame(render); };

    function enable() {
      const G = gid(); if (G === undefined) return;
      on = true;
      document.body.classList.add('yz-cells');
      layout();
      prev = null;
      if (sid === G) build();
      render();
    }
    function disable() {
      const was = on;
      on = false;
      document.body.classList.remove('yz-cells');
      showBox(null);
      if (!was) return;
      const G = gid(); if (G === undefined) return;
      writing = true;
      try { hf.setSheetContent(G, []); if (hf.clearUndoStack) hf.clearUndoStack(); } catch (_) {}
      writing = false;
      cw[G] = {}; mgs[G] = []; st[G] = {};
      prev = null; prevS = null;
      if (sid === G) build();
    }
    function relayout() {
      try { localStorage.setItem(OKEY, JSON.stringify(off)); } catch (_) {}
      const G = gid();
      if (G !== undefined) { cw[G] = {}; }
      layout();
      if (sid === G) build();
      render();
    }
    function force() { prev = null; if (on && sid === gid()) { layout(); build(); } schedule(); }
    function resetLayout() { off = {}; try { localStorage.removeItem(OKEY); } catch (_) {} if (on) relayout(); }
    api = { enable, disable, force, resetLayout };

    // ---------- игра изменилась → перерисовать ----------
    (def.roots || [def.root || '#app']).forEach(sel => {
      const root = $(sel);
      if (root) new MutationObserver(schedule).observe(root, { subtree: true, childList: true, attributes: true, attributeFilter: ['class', 'style', 'data-t'], characterData: true });
    });
    try { hf.on('valuesUpdated', () => { if (!writing && on) { prev = null; schedule(); } }); } catch (_) {}
    if (def.tick) setInterval(() => { if (on) schedule(); }, def.tick);
    const toastEl = $('#toast');
    if (toastEl) new MutationObserver(() => {
      if (on && toastEl.classList.contains('on')) { const sb = $('#sb'); if (sb) sb.textContent = toastEl.textContent.replace(/\s+/g, ' ').trim(); }
    }).observe(toastEl, { attributes: true, childList: true, characterData: true, subtree: true });

    // ---------- ячейки → игра ----------
    const T = document.getElementById('t');
    const posOf = t => {
      const td = t && t.closest && t.closest('td');
      if (!td || !T.contains(td)) return null;
      return { r: td.parentNode.rowIndex - 1, c: td.cellIndex - 1 };
    };
    const active = () => on && !panicOn() && sid === gid();
    const playing = () => active() && !unlocked;
    const keyOf = p => p ? p.r + ',' + p.c : '';
    const fire = (el, type) => { if (!el) return; el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window })); window.YG_FOCUS = false; };
    const run = t => { if (!t) return; if (typeof t === 'function') t(); else { t.click(); window.YG_FOCUS = false; } };
    let hoverEl = null;
    function hover(el) {
      if (el === hoverEl) return;
      const was = hoverEl;
      hoverEl = el;
      if (el) fire(el, 'mousemove');
      else if (was && def.hoverLeave) def.hoverLeave(was);
    }
    const rehover = () => { if (hoverEl) { const h = hoverEl; hoverEl = null; hover(h); } };
    window.YZ_CELLS.rehover = rehover;

    T.addEventListener('click', e => {
      if (!playing() || designOn()) return;
      const t = clickMap[keyOf(posOf(e.target))];
      if (t) { run(t); rehover(); }
    });
    T.addEventListener('mousemove', e => {
      if (!playing() || e.buttons || designOn()) { if (unlocked) T.style.cursor = ''; return; }
      const k = keyOf(posOf(e.target));
      hover(hoverMap[k] || null);
      T.style.cursor = (clickMap[k]) ? 'pointer' : '';
    });
    T.addEventListener('mouseleave', () => { if (active()) hover(null); });
    T.addEventListener('contextmenu', e => {
      if (!active()) return;
      if (designOn()) { e.preventDefault(); e.stopImmediatePropagation(); return; }
      const t = unlocked ? null : ctxMap[keyOf(posOf(e.target))];
      if (!t) return;
      e.preventDefault(); e.stopImmediatePropagation();
      if (typeof t === 'function') t(); else fire(t, 'contextmenu');
      rehover();
    }, true);

    // клавиатура: адаптер (например R — поворот), игровые ячейки — только чтение
    window.addEventListener('keydown', e => {
      if (!active() || (typeof editing !== 'undefined' && editing)) return;
      if (unlocked) {
        // Delete/Backspace — очистить игровые ячейки выделения (своя правка «пусто»)
        if ((e.key === 'Delete' || e.key === 'Backspace') && !/^(INPUT|SELECT|TEXTAREA)$/.test((e.target && e.target.tagName) || '')) {
          let n = 0; eachSel((r, c, L) => { (ovr[L.r + ',' + L.c] ??= {}).v = null; n++; });
          if (n) { saveOvr(); e.preventDefault(); e.stopImmediatePropagation(); prev = null; schedule(); }
        }
        return;                                    // без защиты: обычный ввод, игровые клавиши выключены
      }
      if (e.ctrlKey || e.altKey || e.metaKey || e.key.length !== 1) return;
      if (/^(INPUT|SELECT|TEXTAREA)$/.test((e.target && e.target.tagName) || '')) return;
      let a = null; try { a = act; } catch (_) {}
      const isChat = a && !!inputAt(a.r, a.c);
      if (def.key && def.key(e)) { e.preventDefault(); e.stopImmediatePropagation(); rehover(); return; }
      if (a && !isChat && inZone(a.r, a.c)) { e.preventDefault(); e.stopImmediatePropagation(); }
    }, true);
    const origPut = window.put;
    window.put = function (r, c, t) {
      if (active() && inZone(r, c)) {
        const inp = inputAt(r, c);
        if (inp && inp.send) {
          const v = String(t == null ? '' : t).trim();
          if (v) inp.send(v);
        } else if (unlocked) {
          const L = toL(r, c), lk = L.r + ',' + L.c, raw = t == null ? '' : String(t);
          if (raw === '') { if (ovr[lk]) { delete ovr[lk].v; if (!ovr[lk].s) delete ovr[lk]; } }
          else (ovr[lk] ??= {}).v = /^-?\d+(?:[.,]\d+)?$/.test(raw.trim()) ? +raw.trim().replace(',', '.') : raw;
          saveOvr();
        }
        prev = null; schedule(); refresh();
        return;
      }
      return origPut.apply(this, arguments);
    };

    // выделение → игровые ячейки (физ. r,c + логич. L)
    function eachSel(fn) {
      let g; try { g = rng(); } catch (_) { return; }
      for (let r = g.r1; r <= g.r2; r++) for (let c = g.c1; c <= g.c2; c++) { const L = toL(r, c); if (L) fn(r, c, L); }
    }
    // цвет/шрифт/границы на игровых ячейках: без защиты — запоминаем как правку
    const origSetSt = window.setSt;
    if (typeof origSetSt === 'function') window.setSt = function (fn) {
      if (!active()) return origSetSt.apply(this, arguments);
      const before = {};
      eachSel((r, c) => { const key = r + ',' + c; before[key] = JSON.stringify((st[sid] || {})[key] || {}); });
      const res = origSetSt.apply(this, arguments);
      if (!Object.keys(before).length) return res;
      if (!unlocked) { sbMsg('Ячейки игры защищены — Рецензирование → «🔓 Снять защиту игры», и можно менять текст и цвет'); prev = null; schedule(); return res; }
      for (const key in before) {
        const [r, c] = key.split(',').map(Number), L = toL(r, c);
        const was = JSON.parse(before[key]), now = (st[sid] || {})[key] || {}, d = {};
        for (const q in now) if (JSON.stringify(now[q]) !== JSON.stringify(was[q])) d[q] = now[q];
        for (const q in was) if (!(q in now)) d[q] = null;
        if (Object.keys(d).length) { const o = (ovr[L.r + ',' + L.c] ??= {}); o.s = Object.assign(o.s || {}, d); }
      }
      saveOvr(); prev = null; schedule();
      return res;
    };
    function setUnlocked(v) {
      unlocked = !!v;
      document.body.classList.toggle('yz-unlocked', unlocked);
      document.querySelectorAll('.yz-unl').forEach(b => { b.textContent = unlocked ? '🔒 Вернуть защиту' : '🔓 Снять защиту игры'; b.classList.toggle('on', unlocked); });
      if (hoverEl) hover(null);
      sbMsg(unlocked ? 'Защита игры снята: пишите любой текст в ячейки игры, крась выделение кнопками 🪣 и A · Delete — очистить · игровые клики выключены'
        : 'Защита игры включена — ваши тексты и цвета остаются поверх игры');
    }
    function resetOvr(all) {
      if (all) { if (!confirm('Убрать все свои тексты и цвета в этой игре?')) return; ovr = {}; }
      else { let n = 0; eachSel((r, c, L) => { if (ovr[L.r + ',' + L.c]) { delete ovr[L.r + ',' + L.c]; n++; } }); sbMsg(n ? 'Сброшено ячеек: ' + n : 'В выделении нет ваших правок'); }
      saveOvr(); prev = null; schedule();
    }
    window.YZ_CELLS.unlock = setUnlocked;
    window.YZ_CELLS.isUnlocked = () => unlocked;
    ['#p-rev', '#p-dev'].forEach(sel => {
      const pn = $(sel); if (!pn) return;
      const g = document.createElement('div');
      g.className = 'g';
      g.innerHTML = '<div class="gb"><div class="rw">' +
        '<button type="button" class="yz-unl" title="Разрешить писать свой текст и красить ячейки игры">🔓 Снять защиту игры</button>' +
        '<button type="button" class="yz-ors" title="Вернуть игровой текст и цвет в выделенных ячейках">↺ Сбросить в выделении</button>' +
        '<button type="button" class="yz-ora" title="Убрать все свои правки в этой игре">🗑 Все правки</button>' +
        '</div></div><div class="gl">Защита игры</div>';
      pn.appendChild(g);
      g.querySelector('.yz-unl').onclick = () => setUnlocked(!unlocked);
      g.querySelector('.yz-ors').onclick = () => resetOvr(false);
      g.querySelector('.yz-ora').onclick = () => resetOvr(true);
    });
    const ust = document.createElement('style');
    ust.textContent = 'body.yz-unlocked #sb{color:#c55a11;font-weight:600}.yz-unl.on{background:#fff2cc!important;border-color:#c55a11!important}';
    document.head.appendChild(ust);

    // ---------- ДИЗАЙН: перенос блоков на любую ячейку ----------
    const box = document.createElement('div');
    box.id = 'yz-cbox';
    box.style.cssText = 'position:fixed;z-index:9000;pointer-events:none;display:none;border:2px dashed #107c41;background:rgba(16,124,65,.07);box-sizing:border-box;';
    const lab = document.createElement('div');
    lab.style.cssText = 'position:absolute;left:-2px;top:-20px;background:#107c41;color:#fff;font:12px Segoe UI,Arial,sans-serif;padding:1px 6px;white-space:nowrap;';
    box.appendChild(lab);
    document.documentElement.appendChild(box);   // не в body: мост переносит детей body в #yg-layer
    const CN2 = c => { let s = ''; c++; while (c > 0) { const m = (c - 1) % 26; s = String.fromCharCode(65 + m) + s; c = (c - 1 - m) / 26 | 0; } return s; };
    function cellRect(r, c) {
      const th = T.tHead && T.tHead.rows[0] && T.tHead.rows[0].cells[c + 1];
      const tr = T.tBodies[0] && T.tBodies[0].rows[r];
      if (!th || !tr) return null;
      const a = th.getBoundingClientRect(), b = tr.cells[0].getBoundingClientRect();
      return { l: a.left, r: a.right, t: b.top, b: b.bottom };
    }
    function showBox(R, text) {
      if (!R) { box.style.display = 'none'; return; }
      const a = cellRect(R.r1, R.c1), z = cellRect(Math.min(R.r2, NR - 1), Math.min(R.c2, NC - 1));
      if (!a || !z) { box.style.display = 'none'; return; }
      box.style.display = 'block';
      box.style.left = a.l + 'px'; box.style.top = a.t + 'px';
      box.style.width = Math.max(8, z.r - a.l) + 'px'; box.style.height = Math.max(8, z.b - a.t) + 'px';
      lab.textContent = text || '';
    }
    let drag = null, hl = null;
    function drawHl() {
      if (drag) {
        const R = rectP(drag.b), dr = drag.cur.r - drag.p0.r, dc = drag.cur.c - drag.p0.c;
        const nr = Math.max(-R.r1, dr), nc = Math.max(-R.c1, dc);
        const Q = { r1: R.r1 + nr, r2: R.r2 + nr, c1: R.c1 + nc, c2: R.c2 + nc };
        showBox(Q, '«' + drag.b.name + '» → ' + CN2(Q.c1) + (Q.r1 + 1));
      } else if (hl) {
        const R = rectP(hl);
        showBox(R, '«' + hl.name + '» — тяните на любую ячейку · двойной клик — на место');
      } else showBox(null);
    }
    const sbMsg = t => { const f = () => { const sb = $('#sb'); if (sb) sb.textContent = t; }; f(); setTimeout(f, 60); };
    T.addEventListener('mousedown', e => {
      if (!active() || !designOn() || e.button !== 0) return;
      const p = posOf(e.target); if (!p) return;
      const L = toL(p.r, p.c);
      e.preventDefault(); e.stopImmediatePropagation();
      if (!L) return;
      drag = { b: L.b, p0: p, cur: p };
      drawHl();
    }, true);
    document.addEventListener('mousemove', e => {
      if (!active() || !designOn()) { if (hl || drag) { hl = null; drag = null; showBox(null); } return; }
      const el = document.elementFromPoint(e.clientX, e.clientY);
      const p = posOf(el);
      if (drag) { if (p) { drag.cur = p; drawHl(); } e.preventDefault(); return; }
      const L = p && toL(p.r, p.c);
      const nb = L ? L.b : null;
      if (nb !== hl) { hl = nb; drawHl(); }
    }, true);
    document.addEventListener('mouseup', e => {
      if (!drag) return;
      const R = rectP(drag.b), dr = drag.cur.r - drag.p0.r, dc = drag.cur.c - drag.p0.c;
      const b = drag.b; drag = null;
      e.preventDefault(); e.stopImmediatePropagation();
      if (!dr && !dc) { drawHl(); return; }
      const o = O(b.id);
      off[b.id] = { dr: Math.max(-b.r1, o.dr + Math.max(-R.r1, dr)), dc: Math.max(-b.c1, o.dc + Math.max(-R.c1, dc)) };
      relayout();
      const Q = rectP(b);
      sbMsg('«' + b.name + '» перенесён в ' + CN2(Q.c1) + (Q.r1 + 1));
      hl = b; drawHl();
    }, true);
    T.addEventListener('dblclick', e => {
      if (!active() || !designOn()) return;
      const p = posOf(e.target); const L = p && toL(p.r, p.c);
      e.preventDefault(); e.stopImmediatePropagation();
      if (!L) return;
      delete off[L.b.id];
      relayout();
      sbMsg('«' + L.b.name + '» возвращён на место');
      hl = L.b; drawHl();
    }, true);
    // вход/выход из дизайна — подсказка в строке состояния
    new MutationObserver(() => {
      if (!on) return;
      if (designOn()) sbMsg('Дизайн: наведите на блок и тяните его на любую ячейку · двойной клик — вернуть на место · Esc — выход');
      else { hl = null; drag = null; showBox(null); sbMsg('Готово'); }
    }).observe(document.body, { attributes: true, attributeFilter: ['class'] });
    const W = document.getElementById('w');
    if (W) W.addEventListener('scroll', () => { if (hl || drag) drawHl(); }, { passive: true });

    ready = true;
    if (wantOn) enable();
  }
})();
