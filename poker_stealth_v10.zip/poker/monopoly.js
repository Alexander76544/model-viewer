// 🎩 Монополия (подпольная версия) — серверная логика (host-authoritative).
// 2–6 игроков, поле 36 клеток (московские улицы), старт $1500, старт-клетка +$200.
// Кубик: два броска; двойка — ещё ход; три двойки подряд — в тюрьму.
// Покупка клеток (предложение 20 с), аренда (дома можно строить, группа собрана),
// залоги, «Шанс»/«Состояние», тюрьма (выкуп $50 или двойка, 3 попытки),
// парковка — общий банк: каждый раз при проходе старта банк +$20, стоящий забрал всё.
// Банкротство: долги → активы кредитору (или сгорают). Победитель — последний в игре.
// WebSocket /ws-monopoly, JSON. Только встроенные модули Node.
'use strict';
const crypto = require('crypto');
const champ = require('./championship'); // 🏆 «Чемпионат ЯМЗ»

const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MIN_P = 2, MAX_P = 6;
const TURN_MS = 45000;
const BUY_MS = 20000;
const GONE_HARD_MS = 10 * 60000;
const GRACE_MS = 60000;
const START_MONEY = 1500, GO_SALARY = 200, JAIL_FEE = 50, POT_STEP = 20;

// ---------- поле ----------
// k: go | prop | station | util | chance | chest | jail | gjail | park
const GROUPS = {
  brown:  { name: 'Коричневые', color: '#8d6e63', house: 50,  rent: null },
  lb:     { name: 'Голубые',    color: '#64b5f6', house: 50,  rent: null },
  pink:   { name: 'Розовые',    color: '#f48fb1', house: 100, rent: null },
  orange: { name: 'Оранжевые',  color: '#ffb74d', house: 100, rent: null },
  red:    { name: 'Красные',    color: '#e57373', house: 120, rent: null },
  yellow: { name: 'Жёлтые',     color: '#fff176', house: 150, rent: null },
  green:  { name: 'Зелёные',    color: '#81c784', house: 150, rent: null },
  db:     { name: 'Тёмно-синие',color: '#4fc3f7', house: 200, rent: null },
};
const P = (name, group, price, rent) => ({ k: 'prop', name, group, price, rent });
const SQ = [
  { k: 'go' },                                                        // 0
  P('Кутузовский пр.', 'brown', 60, [2, 10, 30, 90]),                // 1
  P('Ленинградский пр.', 'brown', 60, [4, 20, 60, 180]),             // 2
  { k: 'chest' },                                                     // 3
  { k: 'station', name: 'Комсомольская', price: 200 },               // 4
  P('Арбат', 'lb', 100, [6, 20, 60, 180]),                           // 5
  P('Охотный Ряд', 'lb', 100, [6, 20, 60, 180]),                     // 6
  P('Новый Арбат', 'lb', 120, [8, 30, 90, 270]),                     // 7
  { k: 'chance' },                                                    // 8
  P('Никольская', 'pink', 180, [10, 40, 100, 300]),                  // 9
  { k: 'jail' },                                                      // 10 (тут просто сидим)
  P('Лубянка', 'pink', 180, [20, 60, 150, 450]),                     // 11
  P('Пушкинская', 'pink', 180, [20, 60, 150, 450]),                  // 12
  P('Тверская', 'orange', 220, [22, 80, 200, 550]),                  // 13
  P('Гоголевский бул.', 'orange', 220, [22, 80, 200, 550]),          // 14
  P('Кузнецкий Мост', 'orange', 240, [24, 100, 220, 600]),           // 15
  { k: 'station', name: 'Павелецкий', price: 200 },                  // 16
  P('Мясницкая', 'red', 260, [26, 100, 220, 600]),                   // 17
  { k: 'util', name: 'Мосэнергосбыт', price: 150 },                  // 18
  P('Маросейка', 'red', 260, [26, 100, 220, 600]),                   // 19
  P('Чистопрудный бул.', 'red', 280, [28, 120, 260, 650]),           // 20
  { k: 'chest' },                                                     // 21
  P('Неглинная', 'yellow', 300, [30, 140, 350, 900]),                // 22
  P('Покровка', 'yellow', 300, [30, 140, 350, 900]),                 // 23
  { k: 'gjail' },                                                     // 24 (в тюрьму!)
  P('Садовое кольцо', 'yellow', 320, [35, 175, 400, 1000]),          // 25
  { k: 'chance' },                                                    // 26
  P('Б. Дмитровка', 'green', 350, [50, 200, 500, 1100]),             // 27
  { k: 'park' },                                                      // 28
  P('Столешников пер.', 'green', 350, [50, 200, 500, 1100]),         // 29
  { k: 'util', name: 'Речной порт', price: 150 },                     // 30
  P('Б. Лубянка', 'green', 350, [50, 200, 500, 1100]),               // 31
  P('Тверской бул.', 'db', 400, [100, 400, 1000, 2000]),             // 32
  { k: 'chest' },                                                     // 33
  P('Красная пл.', 'db', 450, [120, 450, 1100, 2200]),               // 34
  { k: 'chance' },                                                    // 35
];
const N = SQ.length; // 36
for (const s of SQ) { s.owner = null; s.houses = 0; s.mortgaged = false; }

const CHANCE = [
  { text: 'Событие: направление — Красная площадь. Проходит старт — +$200', to: 34 },
  { text: 'Событие: свободный проезд к начальной точке', to: 0 },
  { text: 'Событие: премия — +$150', money: 150 },
  { text: 'Событие: ремонт оборудования — −$150', money: -150 },
  { text: 'Событие: коллеги платят вам по $20', each: 20 },
  { text: 'Событие: ближайший узел — без остановки', toStation: 1 },
  { text: 'Событие: служебная проверка. Направляетесь на контроль', jail: true },
  { text: 'Событие: налоговый вычет — +$100', money: 100 },
];
const CHEST = [
  { text: 'Сообщение: проценты по вкладам — +$50', money: 50 },
  { text: 'Сообщение: возврат — +$100', money: 100 },
  { text: 'Сообщение: медосмотр — −$50', money: -50 },
  { text: 'Сообщение: ремонт по всем вашим объектам — −$100', money: -100 },
  { text: 'Сообщение: премия — +$10 от каждого участника', each: 10 },
  { text: 'Сообщение: экскурсия по ЯМЗу — к начальной точке', to: 0 },
  { text: 'Сообщение: штраф за нарушение режима — −$20', money: -20 },
  { text: 'Сообщение: премия от руководства — +$80', money: 80 },
];

let idc = 0;
const st = {
  phase: 'waiting', // waiting | playing | over
  slots: [null, null, null, null, null, null],
  hostId: null,
  turn: -1,
  stage: null,      // null | 'roll' | 'buy' | 'jail'
  dice: null,       // [d1, d2] последний бросок
  parkPot: 0,
  deadline: 0,
  turnTimer: null,
  buyTimer: null,
  pendingBuy: null, // {idx}
  winner: null,
  winMsg: null,
  logs: [],
  chat: [],
  forceRolls: [],   // для тестов: очередь готовых бросков [d1,d2]
};

// ---------- утилиты ----------
function log(msg) {
  st.logs.push({ t: msg, ts: Date.now() });
  if (st.logs.length > 80) st.logs.shift();
  console.log('[Монополия] ' + msg);
}
function players() { return st.slots.filter(Boolean); }
function alivePlayers() { return players().filter(p => p.alive); }
function playerById(id) { return players().find(p => p.id === id) || null; }
function send(p, obj) {
  if (p && p.ws) { try { p.ws.write(wsFrame(0x1, Buffer.from(JSON.stringify(obj), 'utf8'))); } catch (e) {} }
}
function broadcast() { for (const p of players()) send(p, stateFor(p)); }
function sendRaw(conn, obj) {
  if (conn.player && conn.player.ws === conn.sock) send(conn.player, obj);
  else { try { conn.sock.write(wsFrame(0x1, Buffer.from(JSON.stringify(obj), 'utf8'))); } catch (e) {} }
}
function clearTimers() {
  if (st.turnTimer) { clearTimeout(st.turnTimer); st.turnTimer = null; }
  if (st.buyTimer) { clearTimeout(st.buyTimer); st.buyTimer = null; }
}
function d6() { return 1 + (Math.random() * 6) | 0; }

// ---------- игроки ----------
function join(sock, name, pid, uid) {
  name = String(name || '').trim().slice(0, 20) || 'Участник';
  let ex = null;
  if (pid) ex = playerById(pid);
  if (!ex) ex = players().find(p => p.name === name && !p.connected && !p.isBot) || null;
  if (ex) {
    if (ex.ws && ex.ws !== sock) { try { ex.ws.destroy(); } catch (e) {} }
    ex.ws = sock; ex.connected = true;
    if (uid) ex.uid = uid;
    if (ex.goneTimer) { clearTimeout(ex.goneTimer); ex.goneTimer = null; }
    log(ex.name + ' снова на связи');
    send(ex, boardMsg());
    broadcast();
    return ex;
  }
  if (st.phase === 'playing') return { err: 'Игра уже идёт — дождитесь конца партии, чтобы сесть' };
  const seat = st.slots.indexOf(null);
  if (seat === -1) return { err: 'Учёт — до ' + MAX_P + ' участников: все места заняты' };
  const p = {
    id: 'o' + (++idc), name, seat, ws: sock, uid: uid || null,
    connected: true, isBot: false, alive: true,
    money: START_MONEY, pos: 0, token: '', color: '',
    inJail: false, jailTurns: 0, doubles: 0, lastCreditor: null,
    botTimer: null, goneTimer: null, wsConn: null,
  };
  st.slots[seat] = p;
  if (!st.hostId) st.hostId = p.id;
  log(name + ' присоединился (' + players().length + '/' + MAX_P + ')');
  broadcast();
  return p;
}

function sitOut(p, why) {
  st.slots[p.seat] = null;
  if (p.ws) { try { p.ws.destroy(); } catch (e) {} }
  if (p.goneTimer) { clearTimeout(p.goneTimer); p.goneTimer = null; }
  if (p.botTimer) { clearTimeout(p.botTimer); p.botTimer = null; }
  log(p.name + (why ? ' — ' + why : ' покинул учёт'));
  if (p.id === st.hostId) st.hostId = null;
  const seated = players();
  if (st.hostId === null && seated.length) st.hostId = seated[0].id;
  if (st.phase === 'playing') {
    if (st.stage === 'buy' && st.slots[st.turn] === p) { st.stage = null; st.pendingBuy = null; clearTimers(); }
    if (seated.filter(q => q.alive).length < 2) {
      const rest = seated.filter(q => q.alive);
      endGame(rest.length === 1 ? rest[0] : null, 'остался один участник');
    } else if (st.turn === p.seat) {
      advanceTurn();
    } else {
      broadcast();
    }
  } else {
    broadcast();
  }
  for (const q of [...players()]) {
    if (!q.isBot && !q.connected) { log(q.name + ' — не вернулся, место освобождено'); sitOut(q); return; }
  }
}

function onDisconnect(p) {
  p.connected = false;
  if (p.isBot) return;
  log(p.name + ' — нет соединения');
  if (p.goneTimer) clearTimeout(p.goneTimer);
  const grace = st.phase === 'playing' ? GONE_HARD_MS : GRACE_MS;
  p.goneTimer = setTimeout(() => { if (!p.connected) sitOut(p, 'не вернулся вовремя'); }, grace);
  broadcast();
}

// ---------- партия ----------
function resetToWaiting(why) {
  clearTimers();
  st.phase = 'waiting'; st.turn = -1; st.stage = null; st.dice = null;
  st.deadline = 0; st.pendingBuy = null; st.parkPot = 0;
  st.winner = null; st.winMsg = null;
  for (const p of players()) { p.alive = true; p.money = START_MONEY; p.pos = 0; p.inJail = false; p.jailTurns = 0; p.doubles = 0; p.lastCreditor = null; }
  if (why) log('↩ ' + why);
  broadcast();
}

function newGame(initiator) {
  const ps = players();
  if (ps.length < MIN_P) return 'Нужно минимум 2 участника';
  clearTimers();
  for (const s of SQ) { s.owner = null; s.houses = 0; s.mortgaged = false; }
  st.phase = 'playing'; st.turn = -1; st.stage = null; st.dice = null;
  st.deadline = 0; st.pendingBuy = null; st.parkPot = 0;
  st.winner = null; st.winMsg = null;
  st.logs = []; st.chat = [];
  const alive = ps;
  const colors = ['#e5484d', '#4da3ff', '#f5c542', '#37d67a', '#c678dd', '#ff8c42'];
  const tokens = ['А-1', 'Б-1', 'В-1', 'Г-1', 'Д-1', 'Е-1'];
  alive.forEach((p, i) => {
    p.money = START_MONEY; p.pos = 0; p.alive = true;
    p.inJail = false; p.jailTurns = 0; p.doubles = 0; p.lastCreditor = null;
    p.color = colors[i]; p.token = tokens[i];
    if (p.botTimer) { clearTimeout(p.botTimer); p.botTimer = null; }
  });
  log('— Учёт начат: ' + alive.length + ' участника, по $' + START_MONEY + ' —');
  advanceTurn();
  return null;
}

function advanceTurn() {
  if (st.phase !== 'playing') return;
  clearTimers();
  st.stage = null; st.pendingBuy = null; st.dice = null;
  const alive = alivePlayers();
  if (alive.length <= 1) { endGame(alive.length === 1 ? alive[0] : null, 'остался один участник'); return; }
  let i = st.turn;
  do { i = (i + 1) % st.slots.length; } while (!st.slots[i] || !st.slots[i].alive);
  st.turn = i;
  const p = st.slots[i];
  p.doubles = 0;
  st.stage = p.inJail ? 'jail' : 'roll';
  st.deadline = Date.now() + TURN_MS;
  st.turnTimer = setTimeout(() => {
    st.turnTimer = null;
    if (st.phase === 'playing' && st.slots[st.turn] === p) {
      if (p.isBot) { scheduleBot(); return; }
      log(p.name + ' — время вышло, сервер решает за него');
      if (st.stage === 'jail') { if (p.money >= JAIL_FEE) payJail(p, true); else roll(p, true); }
      else roll(p, true);
    }
  }, TURN_MS);
  if (p.isBot) scheduleBot();
  broadcast();
}

// ---------- ход ----------
function roll(p, auto) {
  if (st.phase !== 'playing') return 'Сейчас не партия';
  if (st.slots[st.turn] !== p) return 'Сейчас не ваш ход';
  if (p.inJail && st.stage !== 'jail') return 'Сначала пройдите проверку';
  if (st.stage !== 'roll' && st.stage !== 'jail') return 'Сейчас нельзя бросать';
  let d1, d2;
  const fr = st.forceRolls.shift();
  if (fr) { d1 = fr[0]; d2 = fr[1]; } else { d1 = d6(); d2 = d6(); }
  st.dice = [d1, d2];
  const dbl = d1 === d2;
  if (p.inJail) {
    if (dbl) {
      p.inJail = false; p.jailTurns = 0; p.doubles = 1;
      log(p.name + ' прошёл проверку (двойка ' + d1 + ')');
      move(p, d1 + d2);
    } else {
      p.jailTurns++;
      log(p.name + ' на проверке: ' + d1 + '+' + d2 + ' — без двойки (попытка ' + p.jailTurns + '/3)');
      if (p.jailTurns >= 3) {
        const fee = Math.min(JAIL_FEE, Math.max(0, p.money));
        p.money -= fee;
        p.inJail = false; p.jailTurns = 0;
        log(p.name + ' не прошёл проверку — платит $' + fee + ' и выходит');
        move(p, d1 + d2);
      } else {
        st.stage = 'roll'; st.deadline = Date.now() + 15000;
        st.turnTimer = setTimeout(() => {
          st.turnTimer = null;
          if (st.phase === 'playing' && st.slots[st.turn] === p && p.inJail) {
            if (p.isBot) scheduleBot();
            else { if (p.money >= JAIL_FEE) payJail(p, true); else roll(p, true); }
          }
        }, 15000);
        broadcast();
        return null;
      }
    }
  } else {
    if (dbl) {
      p.doubles++;
      if (p.doubles >= 3) {
        p.doubles = 0;
        toJail(p);
        log(p.name + ' — три двойки подряд, на проверку! (ход сгорает)');
        advanceTurn();
        return null;
      }
      log(p.name + ': ' + d1 + ' + ' + d2 + ' — ДВОЙКА, ещё ход');
    } else {
      log(p.name + ': ' + d1 + ' + ' + d2);
    }
    move(p, d1 + d2);
  }
  return null;
}

function move(p, steps) {
  const from = p.pos;
  const to = (from + steps) % N;
  if (to < from) { // пересекли старт
    p.money += GO_SALARY;
    st.parkPot += POT_STEP;
    log(p.name + ' прошёл старт: +$' + GO_SALARY + ' (общий фонд $' + st.parkPot + ')');
  }
  p.pos = to;
  onLand(p);
}

function onLand(p) {
  const sq = SQ[p.pos];
  const myTurn = st.phase === 'playing' && st.slots[st.turn] === p && p.alive;
  if (sq.k === 'chance' || sq.k === 'chest') { applyCard(p, sq.k); return; } // карты сами завершают ход
  switch (sq.k) {
    case 'go':
      // зарплата/банк уже начислены при пересечении (move / карта) — не двойной платёж
      log(p.name + ' на старте (+$' + GO_SALARY + ' уже начислено, общий фонд $' + st.parkPot + ')');
      break;
    case 'jail':
      log(p.name + ' заглянул(а) на проверку — просто посмотреть');
      break;
    case 'gjail':
      toJail(p);
      break;
    case 'park': {
      if (st.parkPot > 0) { p.money += st.parkPot; log(p.name + ' забирает общий фонд: +$' + st.parkPot); st.parkPot = 0; }
      else log(p.name + ' на парковке (фонд пуст)');
      break;
    }
    case 'prop': case 'station': case 'util':
      if (!sq.owner) {
        if (myTurn) {
          st.stage = 'buy'; st.pendingBuy = sq; st.deadline = Date.now() + BUY_MS;
          if (st.buyTimer) clearTimeout(st.buyTimer);
          st.buyTimer = setTimeout(() => {
            st.buyTimer = null;
            if (st.stage === 'buy' && st.pendingBuy === sq && st.slots[st.turn] === p) {
              log(p.name + ' отказался от объекта ' + sq.name + ' (время вышло)');
              st.stage = null; st.pendingBuy = null;
              finishTurn();
            }
          }, BUY_MS);
          if (p.isBot) scheduleBuyBot(p);
          broadcast();
          return; // ход завершится после решения о покупке
        }
      } else if (sq.owner === p) {
        log(sq.name + ' — ваша собственная ' + (sq.k === 'prop' ? 'улица' : sq.k === 'station' ? 'станция' : 'организация'));
      } else if (sq.mortgaged) {
        log(sq.name + ' в залоге — перевод не берётся');
      } else {
        payRent(p, sq, playerById(sq.owner)); // банкротство внутри может сменить ход
      }
      break;
  }
  if (myTurn && st.stage !== 'buy') finishTurn();
}

function finishTurn() {
  if (st.phase !== 'playing') return;
  const p = st.slots[st.turn];
  clearTimers();
  st.stage = null; st.pendingBuy = null;
  if (p && p.alive && st.dice && st.dice[0] === st.dice[1] && !p.inJail) {
    st.stage = 'roll';
    st.deadline = Date.now() + TURN_MS;
    st.turnTimer = setTimeout(() => {
      st.turnTimer = null;
      if (st.phase === 'playing' && st.slots[st.turn] === p) {
        if (p.isBot) scheduleBot(); else roll(p, true);
      }
    }, TURN_MS);
    log(p.name + ' идёт ещё раз (двойка)');
    broadcast();
    return;
  }
  advanceTurn();
}

// ---------- тюрьма ----------
function toJail(p) {
  p.pos = 10; p.inJail = true; p.jailTurns = 0; p.doubles = 0;
  log(p.name + ' направлен(а) на проверку');
}

function payJail(p, auto) {
  if (st.phase !== 'playing' || st.slots[st.turn] !== p) return 'Сейчас не ваш ход';
  if (!p.inJail) return 'Вы не на проверке';
  if (st.stage !== 'jail' && st.stage !== 'roll') return 'Не время';
  const fee = Math.min(JAIL_FEE, Math.max(0, p.money));
  p.money -= fee; p.lastCreditor = null;
  p.inJail = false; p.jailTurns = 0;
  log(p.name + (auto ? ' (автомат) ' : ' ') + 'закрыв(а)ет проверку за $' + fee);
  st.stage = 'roll'; st.deadline = Date.now() + 15000;
  if (st.turnTimer) clearTimeout(st.turnTimer);
  st.turnTimer = setTimeout(() => {
    st.turnTimer = null;
    if (st.phase === 'playing' && st.slots[st.turn] === p && st.stage === 'roll') {
      if (p.isBot) scheduleBot(); else roll(p, true);
    }
  }, 15000);
  if (p.isBot) scheduleBot();
  broadcast();
  return null;
}

// ---------- карты ----------
function applyCard(p, deck) {
  const list = deck === 'chance' ? CHANCE : CHEST;
  const card = list[(Math.random() * list.length) | 0];
  log(card.text + ' (' + p.name + ')');
  send(p, { t: 'card', deck, text: card.text });
  const myTurn = () => st.phase === 'playing' && st.slots[st.turn] === p && p.alive;
  if (card.jail) toJail(p);
  if (card.money) {
    p.money += card.money; p.lastCreditor = null;
    if (p.money < 0) { bankrupt(p, null); return; }
  }
  if (card.each) {
    let sum = 0;
    for (const q of alivePlayers()) {
      if (q.id === p.id) continue;
      const pay = Math.min(card.each, q.money);
      q.money -= pay; q.lastCreditor = p;
      sum += pay;
    }
    p.money += sum;
    log('   собрано $' + sum);
  }
  if (card.to !== undefined || card.toStation) {
    const stations = SQ.map((s, i) => s.k === 'station' ? i : -1).filter(i => i >= 0);
    const to = card.to !== undefined ? card.to : (stations.find(i => i > p.pos) || stations[0]);
    const from = p.pos;
    if (to < from) { p.money += GO_SALARY; st.parkPot += POT_STEP; log('🏁 ' + p.name + ' проехал старт: +$' + GO_SALARY); }
    p.pos = to;
    onLand(p); // приземление и завершение хода — внутри
    return;
  }
  if (myTurn() && st.stage !== 'buy') finishTurn();
}

// ---------- покупка / аренда / дома / залог ----------
function buy(p) {
  if (st.phase !== 'playing') return 'Сейчас не партия';
  if (st.stage !== 'buy' || st.slots[st.turn] !== p) return 'Предложения о покупке нет';
  const sq = st.pendingBuy;
  if (!sq) return 'Предложения о покупке нет';
  if (p.money < sq.price) return 'Не хватает денег ($' + sq.price + ')';
  p.money -= sq.price;
  sq.owner = p.id;
  log(p.name + ' берёт объект «' + sq.name + '» — $' + sq.price);
  clearTimers();
  st.stage = null; st.pendingBuy = null;
  if (p.isBot) scheduleBuildBot(p);
  finishTurn();
  return null;
}

function passBuy(p) {
  if (st.phase !== 'playing') return 'Сейчас не партия';
  if (st.stage !== 'buy' || st.slots[st.turn] !== p) return 'Предложения о покупке нет';
  const sq = st.pendingBuy;
  log(p.name + ' отказывается от «' + (sq ? sq.name : '?') + '»');
  clearTimers();
  st.stage = null; st.pendingBuy = null;
  finishTurn();
  return null;
}

function baseRent(sq, dice) {
  if (sq.k === 'prop') return sq.rent[sq.houses];
  if (sq.k === 'station') {
    const owned = SQ.filter(s => s.k === 'station' && s.owner === sq.owner).length;
    return owned >= 2 ? 100 : 25;
  }
  if (sq.k === 'util') {
    const owned = SQ.filter(s => s.k === 'util' && s.owner === sq.owner).length;
    return (owned >= 2 ? 10 : 4) * (dice ? dice[0] + dice[1] : 7);
  }
  return 0;
}

function payRent(p, sq, owner) {
  if (!owner || !owner.alive) { log(sq.name + ' — владелец выбыл, перевод не берётся'); return; }
  const rent = baseRent(sq, st.dice);
  p.money -= rent; owner.money += rent;
  p.lastCreditor = owner;
  log('Перевод «' + sq.name + '»: ' + p.name + ' → ' + owner.name + ' $' + rent + (sq.houses ? ' (уровень ' + sq.houses + ')' : ''));
  if (p.money < 0) bankrupt(p, owner);
}

function groupComplete(p, sq) {
  return SQ.filter(s => s.group === sq.group).every(s => s.owner === p.id);
}

function build(p, idx) {
  if (st.phase !== 'playing') return 'Сейчас не партия';
  idx = Number(idx);
  const sq = SQ[idx];
  if (!sq || sq.k !== 'prop') return 'Дом строить негде';
  if (sq.owner !== p.id) return 'Это не ваша улица';
  if (!groupComplete(p, sq)) return 'Сначала соберите всю группу «' + GROUPS[sq.group].name + '»';
  if (sq.houses >= 3) return 'Максимум 3 дома';
  const cost = GROUPS[sq.group].house;
  if (p.money < cost) return 'Не хватает $' + cost;
  p.money -= cost; sq.houses++;
  log(p.name + ' доработал объект «' + sq.name + '» ($' + cost + ', уровень ' + sq.houses + ')');
  broadcast();
  return null;
}

function mortgage(p, idx) {
  if (st.phase !== 'playing') return 'Сейчас не партия';
  idx = Number(idx);
  const sq = SQ[idx];
  if (!sq || !sq.price) return 'Заложить нечего';
  if (sq.owner !== p.id) return 'Это не ваша собственность';
  if (sq.k === 'prop' && sq.houses > 0) return 'Сначала снесите дома (у группы есть дома)';
  if (sq.mortgaged) return 'Уже заложено';
  sq.mortgaged = true;
  const cash = Math.round(sq.price / 2);
  p.money += cash;
  log(p.name + ' заложил объект «' + sq.name + '» (+$' + cash + ')');
  broadcast();
  return null;
}

function unmortgage(p, idx) {
  if (st.phase !== 'playing') return 'Сейчас не партия';
  idx = Number(idx);
  const sq = SQ[idx];
  if (!sq || !sq.price || !sq.mortgaged) return 'Снять с залога нечего';
  if (sq.owner !== p.id) return 'Это не ваша собственность';
  const cost = Math.ceil((sq.price * 11) / 10); // целочисленно: 1.1 в float даёт 110.0000…01
  if (p.money < cost) return 'Не хватает $' + cost;
  p.money -= cost; sq.mortgaged = false;
  log(p.name + ' выкупил объект «' + sq.name + '» из залога (−$' + cost + ')');
  broadcast();
  return null;
}

// ---------- банкротство ----------
function bankrupt(p, creditor) {
  if (st.phase !== 'playing') return;
  const debt = p.money < 0 ? -p.money : 0; // фиксируем ДО обнуления
  p.alive = false; p.money = 0;
  log(p.name + ' — ИСЧЕРПАН БАЛАНС' + (debt > 0 ? (creditor ? ' (долг $' + debt + ' у ' + creditor.name + ')' : ' (долг банку $' + debt + ')') : ''));
  for (const sq of SQ) {
    if (sq.owner !== p.id) continue;
    if (creditor && creditor.alive) {
      sq.owner = creditor.id;
      log('   → «' + sq.name + '» переходит к ' + creditor.name);
    } else {
      sq.owner = null; sq.houses = 0; sq.mortgaged = false;
    }
  }
  if (creditor && creditor.alive) creditor.money = Math.max(0, creditor.money - debt);
  const alive = alivePlayers();
  if (alive.length <= 1) {
    endGame(alive.length === 1 ? alive[0] : null, 'все остальные исчерпали баланс');
    return;
  }
  if (st.slots[st.turn] === p) advanceTurn();
  else broadcast();
}

// ---------- конец ----------
function endGame(winner, why) {
  clearTimers();
  st.phase = 'over'; st.stage = null; st.pendingBuy = null; st.turn = -1; st.deadline = 0;
  if (winner) {
    st.winner = winner.id; st.winMsg = 'Отчёт закрыл(а): ' + winner.name + ' (' + (why || '') + ')';
    log(st.winMsg);
    if (!winner.isBot) { // боты в чемпионате не участвуют
      champ.recordWin(winner.uid, winner.name, 'monopoly', champ.POINTS.monopoly); // 🏆 чемпионат
      for (const p of players()) if (p !== winner && !p.isBot) champ.recordLoss(p.uid, p.name);
    }
  } else {
    st.winMsg = 'Никто не выиграл — партия сорвана';
  }
  broadcast();
}

// ---------- боты ----------
function addBot() {
  if (st.phase === 'playing') return 'Бота посадить нельзя во время партии';
  const seat = st.slots.indexOf(null);
  if (seat === -1) return 'Мест нет (максимум ' + MAX_P + ')';
  let n = players().filter(p => p.isBot).length + 1;
  let name = 'Бот-' + n;
  while (players().some(p => p.name === name)) name = 'Бот-' + (++n);
  const colors = ['#e5484d', '#4da3ff', '#f5c542', '#37d67a', '#c678dd', '#ff8c42'];
  const tokens = ['А-1', 'Б-1', 'В-1', 'Г-1', 'Д-1', 'Е-1'];
  const b = {
    id: 'o' + (++idc), name, seat, ws: null, uid: null,
    connected: true, isBot: true, alive: true,
    money: START_MONEY, pos: 0, token: tokens[players().length] || '🚗', color: colors[players().length] || '#888',
    inJail: false, jailTurns: 0, doubles: 0, lastCreditor: null,
    botTimer: null, goneTimer: null, wsConn: null,
  };
  st.slots[seat] = b;
  log(name + ' зашёл (авт.) (' + players().length + '/' + MAX_P + ')');
  broadcast();
  return null;
}

function removeBot(p) {
  const b = players().find(q => q.isBot);
  if (!b) return 'Бота за столом нет';
  if (st.phase === 'playing') return 'Бота нельзя убрать во время партии';
  sitOut(b, 'убран хостом');
  return null;
}

function scheduleBot() {
  const p = st.slots[st.turn];
  if (!p || !p.isBot) return;
  if (p.botTimer) clearTimeout(p.botTimer);
  p.botTimer = setTimeout(() => {
    p.botTimer = null;
    if (st.phase !== 'playing' || st.slots[st.turn] !== p) return;
    if (st.stage === 'jail') {
      if (p.money < 250 || p.jailTurns >= 2) payJail(p, false);
      else roll(p, false);
    } else if (st.stage === 'roll') {
      roll(p, false);
    }
  }, 1500 + Math.random() * 2000);
}

function scheduleBuyBot(p) {
  if (p.botTimer) clearTimeout(p.botTimer);
  p.botTimer = setTimeout(() => {
    p.botTimer = null;
    if (st.phase !== 'playing' || st.stage !== 'buy' || st.slots[st.turn] !== p) return;
    const sq = st.pendingBuy;
    if (!sq) return;
    const want = p.money > sq.price + 250 ? (Math.random() < 0.9) : (Math.random() < 0.3);
    if (want && p.money >= sq.price) buy(p);
    else passBuy(p);
  }, 1000 + Math.random() * 1500);
}

function scheduleBuildBot(p) {
  if (p.botTimer) clearTimeout(p.botTimer);
  p.botTimer = setTimeout(() => {
    p.botTimer = null;
    if (st.phase !== 'playing' || !p.alive) return;
    for (const sq of SQ) {
      if (sq.k !== 'prop' || sq.owner !== p.id || sq.houses >= 3) continue;
      if (groupComplete(p, sq) && p.money > 400 + GROUPS[sq.group].house) { build(p, SQ.indexOf(sq)); break; }
    }
  }, 800);
}

// ---------- состояние ----------
function boardMsg() {
  return {
    t: 'board', size: N, min: MIN_P, max: MAX_P,
    groups: Object.keys(GROUPS).map(k => ({ key: k, name: GROUPS[k].name, color: GROUPS[k].color, house: GROUPS[k].house })),
    squares: SQ.map((s, i) => ({ i, k: s.k, name: s.name || null, group: s.group || null, price: s.price || 0 })),
  };
}

function stateFor(p) {
  return {
    t: 'state',
    phase: st.phase,
    myId: p ? p.id : null,
    isHost: !!(p && p.id === st.hostId),
    turn: st.turn,
    stage: st.stage,
    dice: st.dice,
    parkPot: st.parkPot,
    deadline: st.deadline,
    winner: st.winner,
    winMsg: st.winMsg,
    pendingBuy: (st.stage === 'buy' && st.pendingBuy && p && st.slots[st.turn] === p) ? { idx: SQ.indexOf(st.pendingBuy), price: st.pendingBuy.price, name: st.pendingBuy.name } : null,
    players: st.slots.map(x => x ? {
      id: x.id, name: x.name, bot: !!x.isBot, connected: x.connected, alive: x.alive,
      money: x.money, pos: x.pos, token: x.token, color: x.color, inJail: x.inJail, jailTurns: x.jailTurns,
    } : null),
    squares: SQ.map((s, i) => ({
      i, k: s.k, owner: s.owner || null, houses: s.houses || 0, mortgaged: !!s.mortgaged,
      rent: s.k === 'prop' ? s.rent[s.houses || 0] : (s.k === 'station' || s.k === 'util') ? baseRent(s, st.dice) : 0,
    })),
    logs: st.logs.slice(-40),
    chat: st.chat.slice(-25),
  };
}

function monopolyStatus() {
  return { players: players().length, phase: st.phase, inGame: st.phase === 'playing', min: MIN_P, max: MAX_P };
}

// ---------- WebSocket (RFC6455, как в остальных играх) ----------
function wsFrame(opcode, payload) {
  const len = payload.length;
  let header;
  if (len < 126) header = Buffer.from([0x80 | opcode, len]);
  else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x80 | opcode; header[1] = 126; header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x80 | opcode; header[1] = 127; header.writeBigUInt64BE(BigInt(len), 2);
  }
  return Buffer.concat([header, payload]);
}

function closeConn(conn) {
  if (conn.closed) return;
  conn.closed = true;
  try { conn.sock.write(wsFrame(0x8, Buffer.from([]))); } catch (e) {}
  setTimeout(() => { try { conn.sock.destroy(); } catch (e) {} }, 300);
}

function onDrop(conn) {
  const p = conn.player;
  if (p && p.ws === conn.sock) {
    p.ws = null; p.wsConn = null;
    onDisconnect(p);
  }
}

function handleMsg(conn, text) {
  let m;
  try { m = JSON.parse(text); } catch (e) { return; }
  conn.lastSeen = Date.now();
  const p = conn.player;
  // тестовый режим (запускается сервер с MONO_TEST=1): точные броски и телепорт
  if (m.t === '_debug' && process.env.MONO_TEST === '1') {
    if (m.op === 'roll') st.forceRolls.push([Math.max(1, Math.min(6, Number(m.d1))), Math.max(1, Math.min(6, Number(m.d2)))]);
    if (m.op === 'teleport') {
      const q = p || playerById(m.id);
      if (q) { q.pos = ((Number(m.pos) % N) + N) % N; q.inJail = q.pos === 10; q.jailTurns = 0; }
    }
    if (m.op === 'money') { const q = p || playerById(m.id); if (q) q.money = Number(m.n); }
    if (m.op === 'owner') { const s = SQ[Number(m.idx)]; if (s) s.owner = m.id || null; }
    broadcast();
    return;
  }
  if (!p) {
    if (m.t !== 'join') return;
    const r = join(conn.sock, m.name, m.pid, m.uid);
    if (r && r.err) { sendRaw(conn, { t: 'error', msg: r.err }); return; }
    if (r) { conn.player = r; r.wsConn = conn; }
    send(r, boardMsg());
    send(r, stateFor(r));
    return;
  }
  let e = null;
  switch (m.t) {
    case 'start':
      if (st.phase !== 'waiting') { e = 'Игра уже идёт'; break; }
      if (p.id !== st.hostId) { e = 'Партию начинает хост'; break; }
      e = newGame(p); break;
    case 'newGame':
      if (st.phase !== 'over') { e = 'Новая партия — после завершения'; break; }
      if (p.id !== st.hostId) { e = 'Партию начинает хост'; break; }
      e = newGame(p); break;
    case 'restart':
      if (p.id !== st.hostId) { e = 'Может хост'; break; }
      if (players().length < MIN_P) { e = 'Нужно минимум 2 участника'; break; }
      e = newGame(p); break;
    case 'roll': e = roll(p, false); break;
    case 'buy': e = buy(p); break;
    case 'passBuy': e = passBuy(p); break;
    case 'payJail': e = payJail(p, false); break;
    case 'build': e = build(p, m.idx); break;
    case 'mortgage': e = mortgage(p, m.idx); break;
    case 'unmortgage': e = unmortgage(p, m.idx); break;
    case 'addBot': e = addBot(); break;
    case 'removeBot': e = removeBot(p); break;
    case 'leave': sitOut(p, 'покинул(а) учёт'); return;
    case 'chat': {
      const txt = String(m.msg || '').trim().slice(0, 200);
      let img = null;
      if (m.img) {
        if (typeof m.img === 'string' && m.img.startsWith('data:image/') && m.img.length <= 400000) img = m.img;
        else if (!txt) { send(p, { t: 'error', msg: 'Картинка не прошла: только JPG/PNG, до ~300 КБ' }); return; }
      }
      if (!txt && !img) return;
      st.chat.push({ from: p.name, bot: p.isBot, dead: !p.alive, msg: txt, img: img ? true : null, ts: Date.now() });
      if (st.chat.length > 100) st.chat.shift();
      const live = { t: 'chat', from: p.name, bot: p.isBot, dead: !p.alive, msg: txt };
      if (img) live.img = img;
      for (const q of players()) send(q, live);
      return;
    }
  }
  if (e) send(p, { t: 'error', msg: e });
}

function handleMonopolyUpgrade(req, socket) {
  const key = req.headers['sec-websocket-key'];
  if (!key) { socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + WS_GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  const conn = { sock: socket, player: null, closed: false, lastSeen: Date.now() };
  let buf = Buffer.alloc(0);
  socket.on('data', chunk => {
    conn.lastSeen = Date.now();
    buf = Buffer.concat([buf, chunk]);
    while (true) {
      if (buf.length < 2) return;
      const opcode = buf[0] & 0x0f;
      const masked = (buf[1] & 0x80) !== 0;
      let len = buf[1] & 0x7f; let off = 2;
      if (len === 126) { if (buf.length < off + 2) return; len = buf.readUInt16BE(off); off += 2; }
      else if (len === 127) { if (buf.length < off + 8) return; len = Number(buf.readBigUInt64BE(off)); off += 8; }
      if (len > 1e6) { closeConn(conn); return; }
      let mask = null;
      if (masked) { if (buf.length < off + 4) return; mask = buf.slice(off, off + 4); off += 4; }
      if (buf.length < off + len) return;
      const payload = Buffer.from(buf.slice(off, off + len));
      buf = buf.slice(off + len);
      if (masked) for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
      if (opcode === 0x8) { closeConn(conn); return; }
      else if (opcode === 0x9) { try { socket.write(wsFrame(0xA, payload)); } catch (e) {} }
      else if (opcode === 0xA) { conn.lastSeen = Date.now(); }
      else if (opcode === 0x1 || opcode === 0x0) { handleMsg(conn, payload.toString('utf8')); }
    }
  });
  socket.on('close', () => onDrop(conn));
  socket.on('error', () => onDrop(conn));
}

// keepalive
setInterval(() => {
  for (const p of [...players()]) {
    if (!p.ws) continue;
    try { p.ws.write(wsFrame(0x9, Buffer.from([]))); } catch (e) {}
    if (Date.now() - ((p.wsConn && p.wsConn.lastSeen) || 0) > 75000) {
      log(p.name + ' — нет ответа');
      try { p.ws.destroy(); } catch (e) {}
    }
  }
}, 25000);

module.exports = { handleMonopolyUpgrade, monopolyStatus, _debug: { st, SQ, CHANCE, CHEST, forceRolls: (pairs) => { st.forceRolls = pairs.slice(); }, teleport: (id, pos) => { const p = playerById(id); if (p) { p.pos = ((pos % N) + N) % N; if (p.pos === 10) p.inJail = true; if (p.pos !== 10) { p.inJail = false; p.jailTurns = 0; } } }, setMoney: (id, n) => { const p = playerById(id); if (p) p.money = n; } } };
