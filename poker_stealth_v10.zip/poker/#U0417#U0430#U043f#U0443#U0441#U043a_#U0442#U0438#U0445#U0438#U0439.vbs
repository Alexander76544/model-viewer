' Starts the YAMZ server WITHOUT a console window (silent mode).
' Console output is written to server-log.txt in this folder.
' To stop the server, run "Остановить_сервер.bat".
Dim sh, here
Set sh = CreateObject("WScript.Shell")
here = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\") - 1)
sh.CurrentDirectory = here
sh.Run "cmd /c node serve.js > server-log.txt 2>&1", 0, False
