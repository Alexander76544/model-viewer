// ⚓ Морской бой — серверная логика (host-authoritative), подключается к serve.js.
// Поле 10×10, флот 1×4, 2×3, 3×2, 4×1; корабли не касаются друг друга (ни углами).
// Классика: попал — стреляешь ещё, промах — ход переходит.
// Подключается по WebSocket /ws-boy, сообщения — JSON (как в покере).
// Только встроенные модули Node.
'use strict';
const crypto = require('crypto');
const champ = require('./championship'); // 🏆 «Чемпионат ЯМЗ»

const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const SIZE = 10, N = SIZE * SIZE;
const FLEET = [4, 3, 3, 2, 2, 2, 1, 1, 1, 1]; // классика: 1×4, 2×3, 3×2, 4×1 (20 клеток)
const SHOT_MS = 30000;            // время на выстрел (по таймауту — авто-выстрел)
const GONE_HARD_MS = 10 * 60000;  // место игрока держим до 10 минут
const GRACE_MS = 60000;           // между боями — 60 секунд на возврат
const LETTERS = 'АБВГДЕЖЗИК';

let idc = 0;
const st = {
  phase: 'waiting', // waiting | setup | battle | over
  slots: [null, null],
  grids: [null, null],   // grids[i][idx] = индекс корабля или -1
  ships: [[], []],       // ships[i] = [{cells, size, hits, sunk}]
  shots: [null, null],   // shots[i][idx] = выстрелы ПО полю i: 0 | 1 промах | 2 попадание | 3 потоплен
  turn: -1,
  deadline: 0,
  shotTimer: null,
  ready: [false, false],   // флот расставлен и подтверждён
  setupTimer: null,        // страховка: авт расстановка, если человек не успел
  winner: -1,
  winnerName: null,
  logs: [],
  chat: [],
};

// ---------- утилиты ----------
function log(msg) {
  st.logs.push({ t: msg, ts: Date.now() });
  if (st.logs.length > 80) st.logs.shift();
  console.log('[Морской бой] ' + msg);
}
function players() { return st.slots.filter(Boolean); }
function playerById(id) { return players().find(p => p.id === id) || null; }
function send(p, obj) {
  if (p && p.ws) { try { p.ws.write(wsFrame(0x1, Buffer.from(JSON.stringify(obj), 'utf8'))); } catch (e) {} }
}
function broadcast() { for (const p of players()) send(p, stateFor(p)); }
function sendRaw(conn, obj) {
  if (conn.player && conn.player.ws === conn.sock) send(conn.player, obj);
  else { try { conn.sock.write(wsFrame(0x1, Buffer.from(JSON.stringify(obj), 'utf8'))); } catch (e) {} }
}

// «Чемпионат ЯМЗ»: победителю — очки, проигравшему — обнуление серии (только люди)
function recordResult(winnerSeat, loserSeat) {
  const w = st.slots[winnerSeat], l = st.slots[loserSeat];
  if (w && !w.isBot) champ.recordWin(w.uid, w.name, 'boy', champ.POINTS.boy);
  if (l && !l.isBot) champ.recordLoss(l.uid, l.name);
}

// ---------- расстановка флота (корабли не касаются, даже углами) ----------
function placeFleet() {
  for (let round = 0; round < 200; round++) {
    const grid = new Array(N).fill(-1);
    const ships = [];
    let ok = true;
    for (const size of FLEET) {
      let placed = false;
      for (let t = 0; t < 300; t++) {
        const horiz = Math.random() < 0.5;
        const x = (Math.random() * (horiz ? SIZE - size + 1 : SIZE)) | 0;
        const y = (Math.random() * (horiz ? SIZE : SIZE - size + 1)) | 0;
        const cells = [];
        let valid = true;
        for (let k = 0; k < size; k++) cells.push((y + (horiz ? 0 : k)) * SIZE + x + (horiz ? k : 0));
        for (const c of cells) {
          const cx = c % SIZE, cy = (c / SIZE) | 0;
          for (let dx = -1; dx <= 1 && valid; dx++) for (let dy = -1; dy <= 1; dy++) {
            const nx = cx + dx, ny = cy + dy;
            if (nx < 0 || ny < 0 || nx >= SIZE || ny >= SIZE) continue;
            if (grid[ny * SIZE + nx] !== -1) { valid = false; break; }
          }
        }
        if (!valid) continue;
        const id = ships.length;
        for (const c of cells) grid[c] = id;
        ships.push({ cells, size, hits: 0, sunk: false });
        placed = true;
        break;
      }
      if (!placed) { ok = false; break; }
    }
    if (ok) return { grid, ships };
  }
  // запасной вариант (практически никогда): четыре ряда через пустой
  const grid = new Array(N).fill(-1);
  const ships = [];
  const line = (row, x0, size) => {
    const id = ships.length, cells = [];
    for (let k = 0; k < size; k++) { cells.push(row * SIZE + x0 + k); grid[row * SIZE + x0 + k] = id; }
    ships.push({ cells, size, hits: 0, sunk: false });
  };
  line(0, 0, 4); line(0, 5, 3);
  line(3, 0, 3); line(3, 4, 2);
  line(6, 0, 2); line(6, 3, 2);
  line(9, 0, 1); line(9, 2, 1); line(9, 4, 1); line(9, 6, 1);
  return { grid, ships };
}

// ---------- игроки ----------
function join(sock, name, pid, uid) {
  name = String(name || '').trim().slice(0, 20) || 'Участник';
  let ex = null;
  if (pid) ex = playerById(pid);
  if (!ex) ex = players().find(p => p.name === name && !p.connected && !p.isBot) || null;
  if (ex) {
    if (ex.ws && ex.ws !== sock) { try { ex.ws.destroy(); } catch (e) {} } // мигрируем сессию
    ex.ws = sock; ex.connected = true;
    if (uid) ex.uid = uid;
    if (ex.goneTimer) { clearTimeout(ex.goneTimer); ex.goneTimer = null; }
    log(ex.name + ' снова на связи');
    if (players().length === 2 && st.phase === 'waiting') toSetup();
    broadcast();
    return ex;
  }
  const seat = st.slots.indexOf(null);
  if (seat === -1) return { err: 'Контроль — на двоих: оба места заняты' };
  const p = {
    id: 'm' + (++idc), name, seat, ws: sock, uid: uid || null,
    connected: true, isBot: false, botTimer: null, goneTimer: null, wsConn: null,
  };
  st.slots[seat] = p;
  log(name + ' присоединился');
  afterJoin();
  return p;
}

function afterJoin() {
  const seated = players();
  if (seated.length === 2 && (st.phase === 'waiting' || st.phase === 'over')) toSetup();
  broadcast();
}

function toSetup() {
  clearTimeout(st.shotTimer); st.shotTimer = null; st.deadline = 0;
  clearTimeout(st.setupTimer); st.setupTimer = null;
  st.phase = 'setup'; st.turn = -1; st.winner = -1; st.winnerName = null;
  st.ready = [false, false];
  for (let i = 0; i < 2; i++) {
    st.grids[i] = new Array(N).fill(-1);
    st.ships[i] = [];
    st.shots[i] = new Array(N).fill(0);
    const p = st.slots[i];
    if (p && p.isBot) { // бот расставляет мгновенно
      const pl = placeFleet();
      st.grids[i] = pl.grid; st.ships[i] = pl.ships; st.ready[i] = true;
    }
  }
  log('Расстановка элементов — ждём «Начать проверку»');
  st.setupTimer = setTimeout(() => {
    st.setupTimer = null;
    if (st.phase !== 'setup') return;
    for (let i = 0; i < 2; i++) {
      const p = st.slots[i];
      // полностью пустой флот не расставлен за 90 с — ставим случайно
      if (p && !p.isBot && !st.ready[i] && st.ships[i].length === 0) {
        const pl = placeFleet();
        st.grids[i] = pl.grid; st.ships[i] = pl.ships; st.ready[i] = true;
        log(p.name + ' не расставил(а) элементы — расставлено автоматически');
      }
    }
    broadcast();
  }, 90000);
  broadcast();
}

function sitOut(p, why) {
  st.slots[p.seat] = null;
  if (p.ws) { try { p.ws.destroy(); } catch (e) {} }
  if (p.goneTimer) { clearTimeout(p.goneTimer); p.goneTimer = null; }
  if (p.botTimer) { clearTimeout(p.botTimer); p.botTimer = null; }
  log(p.name + (why ? ' — ' + why : ' покинул проверку'));
  const seated = players();
  if (st.phase === 'battle') {
    clearTimeout(st.shotTimer); st.shotTimer = null; st.deadline = 0;
      if (seated.length === 1 && !seated[0].isBot) {
        st.phase = 'over'; st.turn = -1;
        st.winner = seated[0].seat; st.winnerName = seated[0].name;
        log('Контролирующая сторона отступила — завершил(а): ' + st.winnerName);
        champ.recordWin(seated[0].uid, seated[0].name, 'boy', champ.POINTS.boy); // 🏆 чемпионат
      } else if (seated.length < 2) {
      st.phase = 'waiting'; st.turn = -1;
    }
  } else if (st.phase === 'setup' && seated.length < 2) {
    st.phase = 'waiting'; st.turn = -1;
  }
  // отключившиеся и не вернувшиеся — освобожаем (рекурсия один уровень)
  for (const q of [...players()]) {
    if (!q.isBot && !q.connected) { log(q.name + ' — не вернулся, место освобождено'); sitOut(q); return; }
  }
  if ((st.phase === 'waiting' || st.phase === 'over') && players().length === 2) toSetup();
  broadcast();
}

function onDisconnect(p) {
  p.connected = false;
  if (p.isBot) return;
  log(p.name + ' — нет соединения');
  if (p.goneTimer) clearTimeout(p.goneTimer);
  const grace = st.phase === 'battle' ? GONE_HARD_MS : GRACE_MS;
  p.goneTimer = setTimeout(() => { if (!p.connected) sitOut(p, 'не вернулся вовремя'); }, grace);
  broadcast();
}

// ---------- бой ----------
function startBattle(p) {
  if (st.phase !== 'setup') return 'Сначала расстановка (или новый цикл)';
  if (st.slots[p.seat] !== p) return;
  if (!st.ready[p.seat]) return 'Сначала расставьте свои элементы (или «Случайно»)';
  if (!st.ready[1 - p.seat]) return 'Сторона 2 ещё расставляет элементы';
  st.phase = 'battle';
  st.turn = Math.random() < 0.5 ? 0 : 1;
  log('Проверка началась! Первым идёт: ' + st.slots[st.turn].name);
  scheduleShotTimer();
  if (st.slots[st.turn] && st.slots[st.turn].isBot) scheduleBot();
  broadcast();
  return null;
}

function resolveShot(shooter, idx) {
  const o = 1 - shooter;
  if (st.shots[o][idx] !== 0) return 'dup';
  const shipId = st.grids[o][idx];
  if (shipId >= 0) {
    const ship = st.ships[o][shipId];
    st.shots[o][idx] = 2;
    ship.hits++;
    if (ship.hits >= ship.size) {
      ship.sunk = true;
      for (const c of ship.cells) if (st.shots[o][c] === 2) st.shots[o][c] = 3;
      if (st.ships[o].every(s => s.sunk)) {
        st.phase = 'over'; st.turn = -1;
        clearTimeout(st.shotTimer); st.shotTimer = null; st.deadline = 0;
        st.winner = shooter; st.winnerName = st.slots[shooter] ? st.slots[shooter].name : 'участник';
        log(st.winnerName + ' обнаружил(а) все элементы — контроль завершён!');
        recordResult(shooter, o); // 🏆 чемпионат ЯМЗ
        return 'end';
      }
      return 'sunk';
    }
    return 'hit';
  }
  st.shots[o][idx] = 1;
  st.turn = o;
  return 'miss';
}

function fire(p, x, y, auto) {
  if (st.phase !== 'battle') return 'Сейчас не проверка';
  if (st.slots[p.seat] !== p) return;
  if (st.turn !== p.seat) return 'Сейчас не ваш ход';
  x = Math.floor(Number(x)); y = Math.floor(Number(y));
  if (!(x >= 0 && y >= 0 && x < SIZE && y < SIZE)) return 'Неверные координаты';
  const idx = y * SIZE + x;
  const res = resolveShot(p.seat, idx);
  if (res === 'dup') return 'Туда уже проверяли';
  const coord = LETTERS[x] + (y + 1);
  log(p.name + ' проверяет: ' + coord + ' — ' +
    (res === 'miss' ? 'пусто' : res === 'end' ? 'элемент, КОНТРОЛЬ ЗАВЕРШЁН' : res === 'sunk' ? 'элемент найден целиком' : 'элемент найден'));
  if (st.phase === 'battle') {
    scheduleShotTimer();
    if (st.slots[st.turn] && st.slots[st.turn].isBot) scheduleBot();
  }
  broadcast();
  return null;
}

function scheduleShotTimer() {
  clearTimeout(st.shotTimer);
  if (st.phase !== 'battle' || st.turn < 0) return;
  st.deadline = Date.now() + SHOT_MS;
  st.shotTimer = setTimeout(() => {
    st.shotTimer = null;
    if (st.phase !== 'battle' || st.turn < 0) return;
    const p = st.slots[st.turn];
    if (!p || p.isBot) return; // у бота свой таймер
    const o = 1 - p.seat;
    const cands = [];
    for (let c = 0; c < N; c++) if (st.shots[o][c] === 0) cands.push(c);
    if (!cands.length) return;
    const pick = cands[(Math.random() * cands.length) | 0];
    fire(p, pick % SIZE, (pick / SIZE) | 0, true);
  }, SHOT_MS);
}

// ---------- бот-соперник ----------
function botCandidates(seat) {
  const o = 1 - seat;
  const cands = [];
  // 1) соседние клетки рядом с ранеными (не потопленными) кораблями
  for (const s of st.ships[o]) if (s.hits > 0 && !s.sunk) {
    for (const c of s.cells) {
      const cx = c % SIZE, cy = (c / SIZE) | 0;
      for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = cx + d[0], ny = cy + d[1];
        if (nx < 0 || ny < 0 || nx >= SIZE || ny >= SIZE) continue;
        const n = ny * SIZE + nx;
        if (st.shots[o][n] === 0) cands.push(n);
      }
    }
  }
  if (cands.length) return cands;
  // 2) шахматка (чётные клетки) — любой корабль ≥2 попадёт
  const par = [];
  for (let c = 0; c < N; c++)
    if (st.shots[o][c] === 0 && ((c % SIZE) + ((c / SIZE) | 0)) % 2 === 0) par.push(c);
  if (par.length) return par;
  // 3) что осталось
  const rest = [];
  for (let c = 0; c < N; c++) if (st.shots[o][c] === 0) rest.push(c);
  return rest;
}

function scheduleBot() {
  const p = st.slots[st.turn];
  if (!p || !p.isBot) return;
  if (p.botTimer) clearTimeout(p.botTimer);
  p.botTimer = setTimeout(() => {
    p.botTimer = null;
    if (st.phase === 'battle' && st.turn === p.seat) {
      const cands = botCandidates(p.seat);
      if (cands.length) {
        const pick = cands[(Math.random() * cands.length) | 0];
        fire(p, pick % SIZE, (pick / SIZE) | 0, false);
      }
    }
  }, 1000 + Math.random() * 1800);
}

function addBot(p) {
  const seat = st.slots.indexOf(null);
  if (seat === -1) return 'Свободного места нет';
  const b = {
    id: 'b' + (++idc), name: 'Бот-1', seat, ws: null,
    connected: true, isBot: true, botTimer: null, goneTimer: null, wsConn: null,
  };
  st.slots[seat] = b;
  log('🤖 ' + b.name + ' сел(ась) за стол');
  afterJoin();
  return null;
}

function removeBot(p) {
  const b = players().find(q => q.isBot);
  if (!b) return 'Бота за столом нет';
  if (st.phase === 'battle') return 'Бота нельзя убрать во время боя';
  sitOut(b, 'убран');
  return null;
}

function shuffle(p) {
  if (st.phase !== 'setup') return 'Перемешать можно только при расстановке';
  const placed = placeFleet();
  st.grids[p.seat] = placed.grid;
  st.ships[p.seat] = placed.ships;
  st.ready[p.seat] = true; // случайный полный флот сразу валиден
  log(p.name + ' перемешал(а) элементы');
  broadcast();
  return null;
}

// ручная расстановка от клиента: shipsIn = [[cells...], ...] (10 кораблей)
function placed(p, shipsIn) {
  if (st.phase !== 'setup') return 'Сейчас не расстановка';
  if (!Array.isArray(shipsIn) || shipsIn.length !== FLEET.length) return 'Элементы — из ' + FLEET.length + ' объектов';
  const sizes = shipsIn.map(s => (Array.isArray(s) ? s.length : -1)).sort((a, b) => b - a);
  const want = [...FLEET].sort((a, b) => b - a);
  if (sizes.join(',') !== want.join(',')) return 'Размеры элементов не совпадают (4-3-2-1)';
  const grid = new Array(N).fill(-1);
  for (let sid = 0; sid < shipsIn.length; sid++) {
    const cells = shipsIn[sid].map(Number);
    for (const c of cells) {
      if (!Number.isInteger(c) || c < 0 || c >= N) return 'Неверные координаты';
      if (grid[c] !== -1) return 'Элементы пересекаются';
      grid[c] = sid;
    }
  }
  for (let c = 0; c < N; c++) { // корабли не касаются (даже углами)
    if (grid[c] < 0) continue;
    const cx = c % SIZE, cy = (c / SIZE) | 0;
    for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) {
      if (!dx && !dy) continue;
      const nx = cx + dx, ny = cy + dy;
      if (nx < 0 || ny < 0 || nx >= SIZE || ny >= SIZE) continue;
      const n = ny * SIZE + nx;
      if (grid[n] >= 0 && grid[n] !== grid[c]) return 'Элементы не могут касаться';
    }
  }
  st.grids[p.seat] = grid;
  st.ships[p.seat] = shipsIn.map(cells => ({ cells: cells.map(Number), size: cells.length, hits: 0, sunk: false }));
  st.ready[p.seat] = true;
  log(p.name + ' расставил(а) элементы');
  broadcast();
  return null;
}

function newGame(p) {
  if (st.phase !== 'over') return 'Новый цикл — после завершения текущего';
  if (players().length < 2) return 'Ждём второго участника';
  toSetup();
  return null;
}

// ---------- состояние для клиента (персональное) ----------
function stateFor(p) {
  const seat = p ? p.seat : -1;
  const opp = seat >= 0 ? 1 - seat : -1;
  const s = {
    t: 'state',
    phase: st.phase,
    mySeat: seat,
    myId: p ? p.id : null,
    seats: st.slots.map(x => x ? { id: x.id, name: x.name, bot: !!x.isBot, connected: x.connected } : null),
    turn: st.phase === 'battle' ? st.turn : -1,
    deadline: st.phase === 'battle' ? st.deadline : 0,
    winner: st.winner,
    winnerName: st.winnerName,
    logs: st.logs.slice(-40),
    chat: st.chat.slice(-25),
  };
  if (seat >= 0 && st.grids[seat]) {
    s.myBoard = {
      cells: st.grids[seat].map((g, i) => ({ s: g >= 0, h: st.shots[seat][i] })),
      ships: st.ships[seat].map(sh => ({ cells: sh.cells, sunk: sh.sunk })),
    };
    if (st.phase === 'setup') {
      s.myReady = !!st.ready[seat];
      s.oppReady = !!st.ready[opp];
    }
    if ((st.phase === 'battle' || st.phase === 'over') && st.shots[opp]) {
      s.enemyBoard = st.shots[opp].slice();
      s.myHits = st.ships[opp].reduce((a, sh) => a + sh.hits, 0);
      s.mySunk = st.ships[opp].filter(sh => sh.sunk).length;
      s.shipsSunk = st.ships[seat].filter(sh => sh.sunk).length;
      s.totalShips = FLEET.length;
    }
  }
  return s;
}

function boyStatus() {
  const seated = players();
  return { players: seated.length, phase: st.phase, inBattle: st.phase === 'battle' };
}

// ---------- WebSocket (RFC6455, как в покере) ----------
function wsFrame(opcode, payload) {
  const len = payload.length;
  let header;
  if (len < 126) header = Buffer.from([0x80 | opcode, len]);
  else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x80 | opcode; header[1] = 126; header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x80 | opcode; header[1] = 127; header.writeBigUInt64BE(BigInt(len), 2);
  }
  return Buffer.concat([header, payload]);
}

function closeConn(conn) {
  if (conn.closed) return;
  conn.closed = true;
  try { conn.sock.write(wsFrame(0x8, Buffer.from([]))); } catch (e) {}
  setTimeout(() => { try { conn.sock.destroy(); } catch (e) {} }, 300);
}

function onDrop(conn) {
  const p = conn.player;
  if (p && p.ws === conn.sock) { // если уже пере-подключился — этот сокет его не касается
    p.ws = null; p.wsConn = null;
    onDisconnect(p);
  }
}

function handleMsg(conn, text) {
  let m;
  try { m = JSON.parse(text); } catch (e) { return; }
  conn.lastSeen = Date.now();
  const p = conn.player;
  if (!p) {
    if (m.t !== 'join') return;
    const r = join(conn.sock, m.name, m.pid, m.uid);
    if (r && r.err) { sendRaw(conn, { t: 'error', msg: r.err }); return; }
    if (r) { conn.player = r; r.wsConn = conn; }
    send(r, stateFor(r));
    return;
  }
  switch (m.t) {
    case 'fire': { const e = fire(p, m.x, m.y, false); if (e) send(p, { t: 'error', msg: e }); break; }
    case 'shuffle': { const e = shuffle(p); if (e) send(p, { t: 'error', msg: e }); break; }
    case 'placed': { const e = placed(p, m.ships); if (e) send(p, { t: 'error', msg: e }); break; }
    case 'battle': { const e = startBattle(p); if (e) send(p, { t: 'error', msg: e }); break; }
    case 'newGame': { const e = newGame(p); if (e) send(p, { t: 'error', msg: e }); break; }
    case 'addBot': { const e = addBot(p); if (e) send(p, { t: 'error', msg: e }); break; }
    case 'removeBot': { const e = removeBot(p); if (e) send(p, { t: 'error', msg: e }); break; }
    case 'leave': { sitOut(p, 'покинул(а) проверку'); break; }
    case 'chat': {
      const txt = String(m.msg || '').trim().slice(0, 200);
      let img = null;
      if (m.img) {
        // картинка: dataURL от клиента (сам сжимает), в истории — только флажок
        if (typeof m.img === 'string' && m.img.startsWith('data:image/') && m.img.length <= 400000) img = m.img;
        else if (!txt) { send(p, { t: 'error', msg: 'Картинка не прошла: только JPG/PNG, до ~300 КБ' }); return; }
      }
      if (!txt && !img) return;
      st.chat.push({ from: p.name, bot: p.isBot, msg: txt, img: img ? true : null, ts: Date.now() });
      if (st.chat.length > 100) st.chat.shift();
      const live = { t: 'chat', from: p.name, bot: p.isBot, msg: txt };
      if (img) live.img = img;
      for (const q of players()) send(q, live);
      break;
    }
  }
}

function handleBoyUpgrade(req, socket) {
  const key = req.headers['sec-websocket-key'];
  if (!key) { socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + WS_GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  const conn = { sock: socket, player: null, closed: false, lastSeen: Date.now() };
  let buf = Buffer.alloc(0);
  socket.on('data', chunk => {
    conn.lastSeen = Date.now();
    buf = Buffer.concat([buf, chunk]);
    while (true) {
      if (buf.length < 2) return;
      const opcode = buf[0] & 0x0f;
      const masked = (buf[1] & 0x80) !== 0;
      let len = buf[1] & 0x7f; let off = 2;
      if (len === 126) { if (buf.length < off + 2) return; len = buf.readUInt16BE(off); off += 2; }
      else if (len === 127) { if (buf.length < off + 8) return; len = Number(buf.readBigUInt64BE(off)); off += 8; }
      if (len > 1e6) { closeConn(conn); return; }
      let mask = null;
      if (masked) { if (buf.length < off + 4) return; mask = buf.slice(off, off + 4); off += 4; }
      if (buf.length < off + len) return;
      const payload = Buffer.from(buf.slice(off, off + len));
      buf = buf.slice(off + len);
      if (masked) for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
      if (opcode === 0x8) { closeConn(conn); return; }
      else if (opcode === 0x9) { try { socket.write(wsFrame(0xA, payload)); } catch (e) {} }
      else if (opcode === 0xA) { conn.lastSeen = Date.now(); }
      else if (opcode === 0x1 || opcode === 0x0) { handleMsg(conn, payload.toString('utf8')); }
    }
  });
  socket.on('close', () => onDrop(conn));
  socket.on('error', () => onDrop(conn));
}

// ping/keepalive
setInterval(() => {
  for (const p of [...players()]) {
    if (!p.ws) continue;
    try { p.ws.write(wsFrame(0x9, Buffer.from([]))); } catch (e) {}
    if (Date.now() - ((p.wsConn && p.wsConn.lastSeen) || 0) > 75000) {
      log(p.name + ' — нет ответа');
      try { p.ws.destroy(); } catch (e) {}
    }
  }
}, 25000);

module.exports = { handleBoyUpgrade, boyStatus };
