// Протокольный тест «Лото» (Ludo): node test-ludo.js   (PORT=4181 по умолчанию)
'use strict';
const PORT = process.env.PORT || 4181;
const WS_URL = 'ws://127.0.0.1:' + PORT + '/ws-ludo';
const API = 'http://127.0.0.1:' + PORT;

const PNG_1PX = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

let fails = 0;
function ok(cond, msg) {
  if (cond) console.log('ok: ' + msg);
  else { fails++; console.error('FAIL: ' + msg); }
}
function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

function client(name, uid) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(WS_URL);
    const c = { name, uid, ws, st: null, board: null, errors: [], lastChat: null, errMsg: null, joined: false, send(o) { ws.send(JSON.stringify(o)); } };
    const to = setTimeout(() => reject(new Error('timeout join ' + name)), 8000);
    ws.onmessage = ev => {
      const m = JSON.parse(ev.data);
      if (m.t === 'board') c.board = m;
      else if (m.t === 'state') { c.st = m; if (!c.joined) { c.joined = true; clearTimeout(to); resolve(c); } }
      else if (m.t === 'error') { c.errors.push(m.msg); if (!c.joined) { c.errMsg = m.msg; clearTimeout(to); resolve(c); } }
      else if (m.t === 'chat') c.lastChat = m;
    };
    ws.onerror = () => { clearTimeout(to); reject(new Error('ws error ' + name)); };
    ws.onopen = () => ws.send(JSON.stringify({ t: 'join', name, uid: uid || null }));
  });
}

async function main() {
  // --- 1. подключение 4 игроков ---
  const A = await client('Лото-А', 'u-ludoa1');
  const B = await client('Лото-Б', 'u-ludob1');
  const C = await client('Лото-В', 'u-ludoc1');
  const D = await client('Лото-Г', 'u-ludod1');
  ok(A.st.phase === 'waiting' && A.st.slots.filter(Boolean).length === 4, 'четверо за столом, фаза ожидания');
  ok(A.board && A.board.track.length === 52, 'поле получено: кольцо из 52 клеток');

  // 5-й отклонён
  const E = await client('Лото-Д', null);
  ok(!!E.errMsg && E.errMsg.includes('4'), 'пятый игрок отклонён: ' + (E.errMsg || ''));
  E.ws.close();

  // действия до старта отклонены
  A.send({ t: 'roll' });
  await wait(200);
  ok(A.errors.length > 0, 'бросок до старта отклонён: ' + (A.errors[0] || ''));

  // --- 2. чат: текст/эмодзи, картинка, отклонение большой ---
  A.send({ t: 'chat', msg: '🎲 погнали!' });
  await wait(300);
  ok(B.lastChat && B.lastChat.from === 'Лото-А' && B.lastChat.msg.includes('🎲'), 'чат с эмодзи дошёл');
  A.send({ t: 'chat', msg: '', img: PNG_1PX });
  await wait(300);
  ok(B.lastChat && B.lastChat.img, 'картинка в чате дошла');
  A.send({ t: 'chat', msg: '', img: 'data:image/png;base64,' + 'x'.repeat(500000) });
  await wait(300);
  ok(A.errors.some(e => e.includes('Картинка')), 'крупная картинка отклонена');

  // --- 3. старт (4 игрока) + проверка хода не тем ---
  A.send({ t: 'start' });
  await wait(300);
  ok(A.st.phase === 'playing', 'игра началась, ходит: ' + (A.st.slots[A.st.turn] ? A.st.slots[A.st.turn].name : '?'));

  B.send({ t: 'roll' });
  await wait(200);
  if (A.st.turn === B.st.mySeat) { /* B мог стать ходящим — пропускаем */ }
  else ok(B.errors.some(e => e.includes('не ваш ход')), 'бросок не в свой ход отклонён: ' + (B.errors[B.errors.length - 1] || ''));

  // C и D уходят — доигрываем вдвоём (партия быстрее)
  C.send({ t: 'leave' });
  await wait(300);
  D.send({ t: 'leave' });
  await wait(300);
  ok(A.st.phase === 'playing' && A.st.slots.filter(Boolean).length === 2,
    'двое вышли — игра продолжается вдвоём');

  // --- 4. доигрываем всю партию вдвоём (жадный ход: самая дальняя фишка) ---
  const ps = [A, B];
  const t0 = Date.now();
  let rolls = 0;
  while (Date.now() - t0 < 200000) {
    if (A.st.phase === 'over') break;
    let acted = false;
    for (const p of ps) {
      const s = p.st;
      if (!s || s.phase !== 'playing' || s.turn !== s.mySeat) continue;
      if (s.stage === 'roll') { p.send({ t: 'roll' }); rolls++; acted = true; await wait(30); }
      else if (s.stage === 'move' && s.movable.length) {
        const my = s.slots[s.mySeat];
        const t = s.movable.map(ti => ({ ti, d: my.tokens[ti] + s.dice })).sort((a, b) => b.d - a.d)[0].ti;
        p.send({ t: 'move', token: t });
        acted = true; await wait(30);
      }
    }
    if (!acted) await wait(40);
  }
  ok(A.st.phase === 'over', 'партия сыграна до конца (' + rolls + ' бросков, ' + Math.round((Date.now() - t0) / 1000) + ' с)');
  const w = A.st.winner;
  const wObj = (w >= 0 && A.st.slots[w]) ? A.st.slots[w] : null;
  ok(wObj !== null, 'есть победитель: ' + (wObj ? wObj.name : '(не появилось за бюджет)'));

  // --- 5. проверки победителя + чемпионат ---
  if (wObj) {
    ok(wObj.tokens.every(t => t === wObj.finish), 'у победителя все 4 фишки дома (' + wObj.finish + ')');
    ok(A.st.winOrder.length > 0, 'порядок финишеров записан: ' + A.st.winOrder.join(', '));
    const wP = ps.find(p => p.name === wObj.name);
    const r = await fetch(API + '/api/championship?uid=' + encodeURIComponent(wP.uid) + '&name=' + encodeURIComponent(wObj.name));
    const cj = await r.json();
    ok(cj.me && cj.me.rating >= 25 && cj.me.wins.ludo >= 1,
      'чемпионат: ' + wObj.name + ' — рейтинг ' + (cj.me ? cj.me.rating : '?') + ', побед в лото: ' + (cj.me ? cj.me.wins.ludo : '?'));
  } else {
    ok(false, 'чемпионат: проверен пропущен — победителя нет');
  }

  // --- 6. новая игра, выход ---
  A.send({ t: 'newGame' });
  await wait(300);
  ok(A.st.phase === 'playing' && A.st.slots.filter(Boolean).every(s => s.tokens.every(t => t === -1)),
    'новая игра: фишки снова в базах');
  A.send({ t: 'leave' });
  await wait(400);
  ok(B.st.phase === 'over', 'остался один — игра остановлена');

  // --- 7. бот: сам играет ---
  B.send({ t: 'addBot' });
  await wait(300);
  ok(B.st.slots.some(s => s && s.bot), 'бот за столом');
  B.send({ t: 'newGame' });
  await wait(300);
  ok(B.st.phase === 'playing', 'новая игра против бота');
  const logs0 = B.st.logs.length;
  const t1 = Date.now();
  let botMoved = false;
  while (Date.now() - t1 < 25000 && !botMoved) {
    await wait(500);
    const s = B.st;
    if (s.phase === 'playing' && s.turn === s.mySeat && s.stage === 'roll') B.send({ t: 'roll' });
    else if (s.phase === 'playing' && s.turn === s.mySeat && s.stage === 'move' && s.movable.length) B.send({ t: 'move', token: s.movable[0] });
    if (B.st.logs.length > logs0 && B.st.logs.slice(logs0).some(l => String(l.t || l).includes('Бот'))) botMoved = true;
  }
  ok(botMoved, 'бот ходит сам');

  // --- 8. неожиданных ошибок не было ---
  const stray = A.errors.concat(B.errors).filter(e => e.includes('Неверный') || e.includes('Не JSON'));
  ok(stray.length === 0, 'ошибок сервера нет');

  [A, B].forEach(p => { try { p.ws.close(); } catch (e) {} });
  if (fails) { console.error('FAIL: ' + fails + ' проблем(ы)'); process.exit(1); }
  console.log('PASS: лото — 4 игрока, чат (эмодзи+картинки), партия до финиша, чемпионат, выход, новая игра, бот.');
}

main().catch(e => { console.error('ОШИБКА ТЕСТА: ' + (e && e.stack || e)); process.exit(1); });
