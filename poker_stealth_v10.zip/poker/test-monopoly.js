// Протокольный тест «Монополия»: node test-monopoly.js   (PORT=4181 по умолчанию)
// ВАЖНО: сервер должен быть запущен с MONO_TEST=1 (точные броски/телепорт).
'use strict';
const PORT = process.env.PORT || 4181;
const WS_URL = 'ws://127.0.0.1:' + PORT + '/ws-monopoly';
const API = 'http://127.0.0.1:' + PORT;
const RUN = Date.now().toString(36);

const PNG_1PX = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

let fails = 0;
function ok(cond, msg) {
  if (cond) console.log('ok: ' + msg);
  else { fails++; console.error('FAIL: ' + msg); }
}
function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

function client(name, uid) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(WS_URL);
    const c = {
      name, uid, ws, st: null, board: null, errors: [], cards: [], lastChat: null, errMsg: null,
      joined: false,
      send(o) { ws.send(JSON.stringify(o)); },
      dbg(o) { ws.send(JSON.stringify(Object.assign({ t: '_debug' }, o))); },
    };
    const to = setTimeout(() => reject(new Error('timeout join ' + name)), 8000);
    ws.onmessage = ev => {
      const m = JSON.parse(ev.data);
      if (m.t === 'board') c.board = m;
      else if (m.t === 'state') { c.st = m; if (!c.joined) { c.joined = true; clearTimeout(to); resolve(c); } }
      else if (m.t === 'card') c.cards.push(m);
      else if (m.t === 'error') { c.errors.push(m.msg); if (!c.joined) { c.errMsg = m.msg; clearTimeout(to); resolve(c); } }
      else if (m.t === 'chat') c.lastChat = m;
    };
    ws.onerror = () => { clearTimeout(to); reject(new Error('ws error ' + name)); };
    ws.onopen = () => ws.send(JSON.stringify({ t: 'join', name, uid: uid || null }));
  });
}
const me = (c) => c.st.players.find(p => p && p.id === c.st.myId);
const sq = (c, i) => c.st.squares[i];

async function main() {
  const g = await (await fetch(API + '/api/games')).json();
  if (g.monopoly.players > 0) throw new Error('Сервер не чистый: за столом ' + g.monopoly.players + ' игрока(ов). Перезапустите тестовый сервер.');

  // --- 1. стол: 2 игрока, лимит 6, старт только хостом ---
  const A = await client('Моно-А', 'u-monoa' + RUN);
  const B = await client('Моно-Б', 'u-monob' + RUN);
  await wait(250); // дождаться броска состояния обоим
  ok(A.st.phase === 'waiting' && A.st.players.filter(Boolean).length === 2, 'двое за столом, ожидание');
  B.send({ t: 'start' }); await wait(200);
  ok(B.errors.some(e => e.includes('хост')), 'старт не хостом отклонён: ' + (B.errors[0] || ''));

  const C = await client('Моно-В', 'u-monoc' + RUN);
  const D = await client('Моно-Г', 'u-monod' + RUN);
  const E = await client('Моно-Д', 'u-monoe' + RUN);
  const F = await client('Моно-Е', 'u-monof' + RUN);
  const G = await client('Моно-Ж', null);
  ok(!!G.errMsg && G.errMsg.includes('6'), 'седьмой игрок отклонён: ' + (G.errMsg || ''));
  G.ws.close();
  F.send({ t: 'leave' }); E.send({ t: 'leave' }); D.send({ t: 'leave' }); C.send({ t: 'leave' });
  await wait(400);
  ok(A.st.players.filter(Boolean).length === 2, 'четверо вышли — осталось 2');

  // чат: эмодзи, картинка, крупная отклонена
  A.send({ t: 'chat', msg: '🎩 поехали!' }); await wait(300);
  ok(B.lastChat && B.lastChat.from === 'Моно-А' && B.lastChat.msg.includes('🎩'), 'чат с эмодзи дошёл');
  A.send({ t: 'chat', msg: '', img: PNG_1PX }); await wait(300);
  ok(B.lastChat && B.lastChat.img, 'картинка в чате дошла');
  A.send({ t: 'chat', msg: '', img: 'data:image/png;base64,' + 'x'.repeat(500000) }); await wait(300);
  ok(A.errors.some(e => e.includes('Картинка')), 'крупная картинка отклонена');

  // --- 2. старт ---
  A.send({ t: 'start' }); await wait(300);
  ok(A.st.phase === 'playing' && A.st.turn === 0, 'партия началась, ходит: ' + (A.st.players[A.st.turn] ? A.st.players[A.st.turn].name : '?'));
  const X = await client('Моно-Х', null);
  ok(!!X.errMsg && X.errMsg.includes('идёт'), 'вход во время партии отклонён: ' + (X.errMsg || ''));
  X.ws.close();

  // --- 3. покупка (А: Арбат) ---
  A.dbg({ op: 'roll', d1: 2, d2: 3 }); await wait(150);
  A.send({ t: 'roll' }); await wait(300);
  ok(me(A).pos === 5, 'А на клетке 5 (Арбат), после 2+3');
  ok(A.st.stage === 'buy' && A.st.pendingBuy && A.st.pendingBuy.idx === 5, 'предложение купить Арбат');
  A.send({ t: 'buy' }); await wait(300);
  ok(sq(A, 5).owner === A.st.myId && me(A).money === 1400, 'А купил Арбат: $1400');

  // --- 4. двойка + покупка станции (Б), двойка, тюрьма-посещение ---
  B.dbg({ op: 'roll', d1: 2, d2: 2 }); await wait(150);
  B.send({ t: 'roll' }); await wait(300);
  ok(me(B).pos === 4 && sq(B, 4).owner === null, 'Б на Комсомольской (4), двойка');
  B.send({ t: 'buy' }); await wait(300);
  ok(sq(B, 4).owner === B.st.myId && me(B).money === 1300 && B.st.turn === 1 && B.st.stage === 'roll',
    'Б купил станцию ($200 → $1300), двойка — дополнительный ход');

  B.dbg({ op: 'roll', d1: 3, d2: 3 }); await wait(150);
  B.send({ t: 'roll' }); await wait(300);
  ok(me(B).pos === 10 && me(B).inJail === false, 'Б заглянул в тюрьму (10) — просто посмотреть');

  // --- 5. три двойки — в тюрьму ---
  B.dbg({ op: 'roll', d1: 4, d2: 4 }); await wait(150);
  B.send({ t: 'roll' }); await wait(300);
  ok(me(B).inJail === true && me(B).pos === 10, 'три двойки подряд — Б в тюрьме');
  ok(A.st.turn === 0 && A.st.stage === 'roll', 'ход перешёл к А');

  // --- 6. тюремный цикл: выкуп + бросок + отказ от покупки ---
  A.dbg({ op: 'roll', d1: 2, d2: 3 }); await wait(150);
  A.send({ t: 'roll' }); await wait(300);
  ok(me(A).pos === 10 && A.st.turn === 1 && A.st.stage === 'jail', 'А заглянул в тюрьму (10), ход у Б (в тюрьме)');
  B.send({ t: 'payJail' }); await wait(300);
  ok(me(B).inJail === false && me(B).money === 1250 && B.st.stage === 'roll', 'Б выкупился за $50 ($1250)');
  B.dbg({ op: 'roll', d1: 1, d2: 2 }); await wait(150);
  B.send({ t: 'roll' }); await wait(300);
  ok(me(B).pos === 13 && B.st.stage === 'buy', 'Б на Тверской (13) — предложение о покупке');
  B.send({ t: 'passBuy' }); await wait(300);
  ok(A.st.turn === 0 && A.st.stage === 'roll', 'Б промахнулся — ход к А');

  // --- 7. аренда (Б платит А за Арбат) ---
  A.dbg({ op: 'teleport', pos: 3 }); await wait(150);
  A.dbg({ op: 'roll', d1: 1, d2: 2 }); await wait(150);
  A.send({ t: 'roll' }); await wait(300);
  ok(me(A).pos === 6 && A.st.stage === 'buy', 'А на Охотном Ряду (6)');
  A.send({ t: 'buy' }); await wait(300);
  ok(me(A).money === 1300 && sq(A, 6).owner === A.st.myId, 'А купил Охотный Ряд ($1300)');

  B.dbg({ op: 'teleport', pos: 2 }); await wait(150);
  B.dbg({ op: 'roll', d1: 1, d2: 2 }); await wait(150);
  B.send({ t: 'roll' }); await wait(400);
  ok(me(B).pos === 5 && me(B).money === 1244 && me(A).money === 1306,
    'аренда: Б → А $6 (Б $1244, А $1306)');

  // --- 8. залог / выкуп ---
  A.send({ t: 'mortgage', idx: 5 }); await wait(300);
  ok(sq(A, 5).mortgaged === true && me(A).money === 1356, 'залог Арбата: +$50');
  A.send({ t: 'unmortgage', idx: 5 }); await wait(300);
  ok(sq(A, 5).mortgaged === false && me(A).money === 1246, 'выкуп Арбата: −$110');

  // --- 9. карта «Шанс» ---
  A.dbg({ op: 'teleport', pos: 3 }); await wait(150);
  A.dbg({ op: 'roll', d1: 2, d2: 3 }); await wait(150);
  A.send({ t: 'roll' }); await wait(400);
  ok(A.cards.length > 0, 'карта «Шанс» пришла: «' + (A.cards[0] ? A.cards[0].text : '?') + '»');
  if (A.st.stage === 'buy') { A.send({ t: 'passBuy' }); await wait(300); }

  // --- 10. банкротство: Б (50$) наступает на Красную площадь (аренда 120$) ---
  B.dbg({ op: 'money', n: 50 }); await wait(100);
  A.dbg({ op: 'owner', idx: 34, id: A.st.myId }); await wait(100);
  B.dbg({ op: 'teleport', pos: 32 }); await wait(150);
  B.dbg({ op: 'roll', d1: 1, d2: 1 }); await wait(150);
  B.send({ t: 'roll' }); await wait(500);
  ok(me(B).alive === false, 'Б обанкротился');
  ok(sq(A, 4).owner === A.st.myId, 'имущество банкрота (Комсомольская) перешло к кредитору А');
  ok(A.st.phase === 'over' && A.st.winner === A.st.myId, 'партия окончена, победитель: ' + (A.st.winMsg || ''));

  // --- 11. чемпионат ---
  const r = await fetch(API + '/api/championship?uid=' + encodeURIComponent(A.uid) + '&name=' + encodeURIComponent('Моно-А'));
  const cj = await r.json();
  ok(cj.me && cj.me.rating >= 30 && cj.me.wins.monopoly >= 1,
    'чемпионат: Моно-А — рейтинг ' + (cj.me ? cj.me.rating : '?') + ', побед в монополии: ' + (cj.me ? cj.me.wins.monopoly : '?'));

  // --- 12. новая партия, боты ---
  A.send({ t: 'newGame' }); await wait(400);
  ok(A.st.phase === 'playing' && me(A).money === 1500 && A.st.squares.every(q => q.owner === null),
    'новая партия: $1500 всем, клетки чистые');

  A.send({ t: 'addBot' }); await wait(250);
  ok(A.errors.some(e => e.includes('партии')), 'бота нельзя посадить во время партии');

  A.send({ t: 'leave' }); await wait(400);
  ok(B.st.phase === 'over' && B.st.winner === B.st.myId, 'А ушёл — победа по сданию: Б');

  B.send({ t: 'addBot' }); await wait(300);
  ok(B.st.players.some(p => p && p.bot), 'бот за столом (после партии)');
  B.send({ t: 'newGame' }); await wait(400);
  ok(B.st.phase === 'playing', 'партия против бота началась');

  // бот играет сам (Б отвечает на свой ход)
  const t0 = Date.now();
  let botMoved = false;
  while (Date.now() - t0 < 30000 && !botMoved) {
    await wait(400);
    const s = B.st;
    if (s.phase !== 'playing') break;
    const cur = s.players[s.turn];
    if (cur && cur.id === B.st.myId) {
      if (s.stage === 'roll') B.send({ t: 'roll' });
      else if (s.stage === 'jail') B.send({ t: 'payJail' });
      else if (s.stage === 'buy') B.send({ t: 'passBuy' });
    }
    const bot = s.players.find(p => p && p.bot);
    if (bot && (bot.pos > 0 || s.logs.some(l => String(l.t).includes('Бот')))) botMoved = true;
  }
  ok(botMoved, 'бот ходит сам');

  B.send({ t: 'removeBot' }); await wait(250);
  ok(B.errors.some(e => e.includes('партии')), 'бота нельзя убрать во время партии');
  B.send({ t: 'leave' }); await wait(400);
  const C2 = await client('Моно-З', 'u-monoz' + RUN);
  C2.send({ t: 'removeBot' }); await wait(300);
  ok(!C2.st.players.some(p => p && p.bot), 'бот убран (после партии)');
  C2.send({ t: 'leave' }); await wait(200);

  // --- 13. лишних ошибок сервера нет ---
  const stray = [A, B, C2].flatMap(p => p.errors).filter(e => e.includes('Неверный') || e.includes('Не JSON'));
  ok(stray.length === 0, 'ошибок сервера нет');

  [A, B, C2].forEach(p => { try { p.ws.close(); } catch (e) {} });
  if (fails) { console.error('FAIL: ' + fails + ' проблем(ы)'); process.exit(1); }
  console.log('PASS: монополия — стол/лимит, покупка, двойки, три двойки → тюрьма, выкуп, аренда, залог, карта, банкротство, чемпионат, новая партия, бот.');
}

main().catch(e => { console.error('ОШИБКА ТЕСТА: ' + (e && e.stack || e)); process.exit(1); });
