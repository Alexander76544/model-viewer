/* r73 · pcdmis-view-r73.js — «твердотельный» разрез (заливка сечения «железо», stencil-капы)
   + правки оформления панелей «Вид» в светлой теме PC-DMIS. */
(function () {
  'use strict';
  var W = window, KEY = 'pcd73.cap';
  function T() { return W.THREE; }
  function G(n) { try { return (0, eval)(n); } catch (e) { return undefined; } } // eslint-disable-line no-eval
  function $(id) { return document.getElementById(id); }
  function ls(v) { try { if (v === undefined) return JSON.parse(localStorage.getItem(KEY) || 'null'); localStorage.setItem(KEY, JSON.stringify(v)); } catch (e) { return null; } }
  var O = Object.assign({ on: true, color: 'steel', hatch: true, opaque: true, edge: true }, ls() || {});
  function save() { ls(O); }
  var COLORS = { steel: [0x9aa3ad, 'Сталь'], iron: [0x6f757c, 'Чугун'], alu: [0xc9cfd6, 'Алюминий'], red: [0xd9534f, 'Красный (CAD)'], body: [null, 'Как модель'] };

  /* ---------- состояние ---------- */
  var ST = { group: null, srcs: [], planes: [], caps: [], tex: null, sig: '', saved: null };
  function mesh() { return G('stlMesh3'); }
  function scene() { return G('scene3'); }
  function modelMeshes() { var m = mesh(), a = []; if (!m) return a; m.traverse(function (o) { if (o.isMesh && o.geometry && o.material && !o.userData.isEdge3 && !o.userData.p73cap) a.push(o); }); return a; }
  function curPlanes() { var mm = modelMeshes(); for (var i = 0; i < mm.length; i++) { var mt = Array.isArray(mm[i].material) ? mm[i].material[0] : mm[i].material; if (mt && mt.clippingPlanes && mt.clippingPlanes.length) return mt.clippingPlanes; } return null; }

  function hatchTex() {
    if (ST.tex) return ST.tex; var c = document.createElement('canvas'); c.width = c.height = 64; var x = c.getContext('2d');
    x.fillStyle = '#ffffff'; x.fillRect(0, 0, 64, 64); x.strokeStyle = 'rgba(40,46,54,.55)'; x.lineWidth = 3;
    for (var k = -64; k <= 128; k += 16) { x.beginPath(); x.moveTo(k, 64); x.lineTo(k + 64, 0); x.stroke(); }
    var t = new (T().CanvasTexture)(c); t.wrapS = t.wrapT = T().RepeatWrapping; t.anisotropy = 4; ST.tex = t; return t;
  }
  function capColor() {
    var c = COLORS[O.color] || COLORS.steel; if (c[0] != null) return c[0];
    var mm = modelMeshes(), mt = mm[0] && (Array.isArray(mm[0].material) ? mm[0].material[0] : mm[0].material);
    return mt && mt.color && !mt.vertexColors ? mt.color.getHex() : 0x9aa3ad;
  }
  function drop() {
    var sc = scene(); if (ST.group) { if (sc) sc.remove(ST.group); ST.group.traverse(function (o) { if (o.material) o.material.dispose(); if (o.userData.ownGeo && o.geometry) o.geometry.dispose(); }); }
    ST.group = null; ST.caps = []; ST.planes = []; ST.sig = '';
  }
  function bbox() { var m = mesh(); if (!m) return null; var b = new (T().Box3)().setFromObject(m); return b.isEmpty() ? null : b; }

  /* stencil-проходы: задние грани +1, передние −1 (по каждой плоскости отдельно); кап рисуется, где ≠ 0 */
  function build(planes) {
    drop(); var TH = T(), sc = scene(), src = modelMeshes(), bb = bbox(); if (!sc || !src.length || !bb || !planes || !planes.length) return;
    var g = new TH.Group(); g.name = 'p73caps'; g.userData.p73cap = true; ST.group = g; ST.planes = planes;
    var size = bb.getSize(new TH.Vector3()).length() * 2.2 + 10, ctr = bb.getCenter(new TH.Vector3()), col = capColor(), tex = O.hatch ? hatchTex() : null;
    planes.forEach(function (pl, i) {
      var base = 40 + i * 3;
      function stMat(side, op) { var m = new TH.MeshBasicMaterial(); m.depthWrite = false; m.depthTest = false; m.colorWrite = false; m.stencilWrite = true; m.stencilFunc = TH.AlwaysStencilFunc; m.side = side; m.clippingPlanes = [pl];
        m.stencilFail = op; m.stencilZFail = op; m.stencilZPass = op; return m; }
      src.forEach(function (s) {
        [[TH.BackSide, TH.IncrementWrapStencilOp], [TH.FrontSide, TH.DecrementWrapStencilOp]].forEach(function (pp, k) {
          var m = new TH.Mesh(s.geometry, stMat(pp[0], pp[1])); m.matrixAutoUpdate = false; m.frustumCulled = false; m.renderOrder = base + k * 0.1; m.raycast = function () {}; m.userData.p73cap = true; m.userData.src = s;
          m.onBeforeRender = function () { this.matrixWorld.copy(s.matrixWorld); };
          g.add(m);
        });
      });
      var others = planes.filter(function (q, j) { return j !== i; });
      var cm = new TH.MeshStandardMaterial({ color: col, metalness: 0.35, roughness: 0.55, map: tex, side: TH.DoubleSide, clippingPlanes: others.length ? others : null, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
      cm.stencilWrite = true; cm.stencilRef = 0; cm.stencilFunc = TH.NotEqualStencilFunc; cm.stencilFail = TH.ReplaceStencilOp; cm.stencilZFail = TH.ReplaceStencilOp; cm.stencilZPass = TH.ReplaceStencilOp;
      var tile = Math.max(6, Math.min(60, bb.getSize(new TH.Vector3()).length() / 18)), geo = new TH.PlaneGeometry(size, size); if (tex) { var uv = geo.attributes.uv; for (var u = 0; u < uv.count; u++) uv.setXY(u, uv.getX(u) * size / tile, uv.getY(u) * size / tile); }
      var cap = new TH.Mesh(geo, cm); cap.userData.ownGeo = true; cap.userData.p73cap = true; cap.renderOrder = base + 0.2; cap.raycast = function () {}; cap.frustumCulled = false;
      cap.onAfterRender = function (r) { r.clearStencil(); };
      var p0 = pl.projectPoint(ctr, new TH.Vector3()); cap.position.copy(p0); cap.lookAt(p0.x - pl.normal.x, p0.y - pl.normal.y, p0.z - pl.normal.z);
      g.add(cap); ST.caps.push(cap);
      if (O.edge) { /* контур среза: тонкая рамка-«ободок» — линия пересечения рисуется краем капа за счёт тёмной кромки текстуры не нужна; оставляем затемнение через stencil */ }
    });
    sc.add(g);
  }
  function sigOf(pl) { return pl ? pl.map(function (p) { return p.normal.toArray().map(function (v) { return v.toFixed(5); }).join(',') + '@' + p.constant.toFixed(4); }).join('|') + '#' + modelMeshes().length + ':' + O.color + O.hatch : ''; }

  function setOpaque(on) {
    var mm = modelMeshes();
    if (on) { if (ST.saved) return; ST.saved = []; mm.forEach(function (s) { var mt = s.material; (Array.isArray(mt) ? mt : [mt]).forEach(function (m) { ST.saved.push([m, m.opacity, m.transparent, m.depthWrite]); m.opacity = 1; m.transparent = false; m.depthWrite = true; m.needsUpdate = true; }); }); }
    else if (ST.saved) { ST.saved.forEach(function (r) { r[0].opacity = r[1]; r[0].transparent = r[2]; r[0].depthWrite = r[3]; r[0].needsUpdate = true; }); ST.saved = null; }
  }
  function bloomOn() { try { var f = G('bloomActive'); return typeof f === 'function' && f() && G('composer3'); } catch (e) { return false; } }
  function sync() {
    var cs = G('clipState3'), pl = curPlanes(), act = !!(O.on && cs && cs.enabled && pl && pl.length && !bloomOn());
    if (!act) { if (ST.group) drop(); setOpaque(false); status(); return; }
    var sg = sigOf(pl); if (sg !== ST.sig || !ST.group) { build(pl); ST.sig = sg; }
    if (ST.group) ST.group.children.forEach(function (c) { var s = c.userData.src; if (s) c.visible = s.visible && isVis(s); });
    setOpaque(!!O.opaque); status();
  }
  function isVis(o) { while (o) { if (o.visible === false) return false; o = o.parent; } return true; }
  function kick() { try { var r = G('requestRender3') || G('render3'); if (typeof r === 'function') r(); } catch (e) {} }

  /* ---------- перехват applyStlClipping ---------- */
  function hook() {
    var f = W.applyStlClipping; if (typeof f !== 'function' || f.__p73) return !!f;
    var w = function () { var r = f.apply(this, arguments); try { sync(); } catch (e) { console.warn('r73 cap', e); } return r; }; w.__p73 = true; W.applyStlClipping = w; return true;
  }

  /* ---------- UI в панели «Сечение» ---------- */
  function status() { var el = $('p73capSt'); if (!el) return; var cs = G('clipState3'); el.textContent = !O.on ? 'выключено' : !(cs && cs.enabled) ? 'включите «Сечение модели»' : bloomOn() ? 'недоступно при «Свечении» (выключите его)' : ST.caps.length ? 'залито плоскостей: ' + ST.caps.length : 'нет плоскостей разреза'; }
  function ui() {
    var body = document.querySelector('#apClip .ap2-body'); if (!body || $('p73cap')) return !!body;
    var d = document.createElement('div'); d.id = 'p73cap'; d.style.cssText = 'border-top:1px solid var(--stroke);padding-top:9px;display:flex;flex-direction:column;gap:6px';
    d.innerHTML = '<div class="ap2Sec" style="margin:0">🧱 Твердотельный разрез</div>' +
      '<label class="checkbox-row" style="gap:6px" title="Заливать срез материала (как в CAD): видно «железо» в местах разреза, полости и отверстия остаются пустыми"><input type="checkbox" data-k="on"' + (O.on ? ' checked' : '') + '> Заливка сечения («железо»)</label>' +
      '<label class="checkbox-row" style="gap:6px">Материал <select data-k="color" style="flex:1">' + Object.keys(COLORS).map(function (k) { return '<option value="' + k + '"' + (O.color === k ? ' selected' : '') + '>' + COLORS[k][1] + '</option>'; }).join('') + '</select></label>' +
      '<label class="checkbox-row" style="gap:6px"><input type="checkbox" data-k="hatch"' + (O.hatch ? ' checked' : '') + '> Штриховка 45°</label>' +
      '<label class="checkbox-row" style="gap:6px" title="На время разреза модель становится непрозрачной — как твёрдое тело"><input type="checkbox" data-k="opaque"' + (O.opaque ? ' checked' : '') + '> Непрозрачная модель при разрезе</label>' +
      '<div style="font-size:11px;color:#8a99ad;line-height:1.5"><span id="p73capSt"></span>. Заливка корректна для замкнутых тел (STEP/STL без дыр); в режиме «Бокс» заливается каждая грань бокса.</div>';
    var exp = $('clipExportBtn'), anchor = exp ? exp.closest('div') : null; if (anchor && anchor.parentNode === body) body.insertBefore(d, anchor); else body.appendChild(d);
    d.addEventListener('change', function (e) { var k = e.target.getAttribute('data-k'); if (!k) return; O[k] = e.target.type === 'checkbox' ? e.target.checked : e.target.value; save(); ST.sig = ''; if (k === 'opaque' && !O.opaque) setOpaque(false); sync(); kick(); });
    status(); return true;
  }

  /* ---------- светлая тема: читаемые активные/основные кнопки во всех панелях «Вид» ---------- */
  function css() {
    if ($('p73viewCss')) return; var s = document.createElement('style'); s.id = 'p73viewCss';
    s.textContent = 'body.pcdmis-skin .ap2 .btn.active,body.pcdmis-skin .ap2 .btn.primary,body.pcdmis-skin .ap2 .seg2b.active,body.pcdmis-skin .ap2 .anaTab.active{background:#0a6ea8 !important;border-color:#0a6ea8 !important;box-shadow:none !important}' +
      'body.pcdmis-skin .ap2 .btn.active,body.pcdmis-skin .ap2 .btn.active *,body.pcdmis-skin .ap2 .btn.primary,body.pcdmis-skin .ap2 .btn.primary *,body.pcdmis-skin .ap2 .seg2b.active,body.pcdmis-skin .ap2 .seg2b.active *,body.pcdmis-skin .ap2 .anaTab.active,body.pcdmis-skin .ap2 .anaTab.active *{color:#fff !important}' +
      'body.pcdmis-skin .ap2 .anaTab{background:#fff !important;border-color:#c4c9d0 !important}body.pcdmis-skin .ap2 .anaTab:hover{border-color:#0a6ea8 !important}' +
      'body.pcdmis-skin .ap2 .btn:disabled,body.pcdmis-skin .ap2 .btn[disabled]{opacity:.55}' +
      'body.pcdmis-skin .ap2 select,body.pcdmis-skin .ap2 input[type=number],body.pcdmis-skin .ap2 input[type=text]{background:#fff !important;border:1px solid #c4c9d0 !important;color:#1f2429 !important}' +
      '#apMass select{max-width:150px}#massDensCustom{width:72px !important}';
    document.head.appendChild(s);
  }

  function boot() { css(); var a = hook(), b = ui(); if (!(a && b)) return setTimeout(boot, 400); try { sync(); } catch (e) {} }
  boot();
  setInterval(function () { try { var m = mesh(), sg = (m ? m.uuid : '') + ':' + modelMeshes().length; if (sg !== ST.msig) { ST.msig = sg; ST.sig = ''; ST.saved = null; } sync(); } catch (e) {} }, 700);
  W.pcdCap = { sync: sync, opt: O, state: ST, set: function (k, v) { O[k] = v; save(); ST.sig = ''; sync(); } };
})();
