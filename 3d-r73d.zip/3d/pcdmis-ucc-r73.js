/* r73 — «Сервер КИМ (UCCserver) · Setup Machine»: библиотека инструментов SP25 (как в Renishaw UCCserver:
   Tools / Components / CalibrationParts / Racks), генератор нестандартных стержней (удлинитель + стержень,
   стержень с поворотом «колено», диск), магазины Rack_1…Rack_8 с назначением инструментов по гнёздам,
   калибровочные сферы и 3D-вид машины (плита, пиноль с головкой и активным инструментом, магазины, сферы).
   Имя инструмента = имя щупа в ЗАГР/ЩУП программы → цепочка PH10MQ · SP25M · SM25-n · (SH25-n) · UCC:<имя>.
   Подключается после pcdmis-probe-r73.js. Хранение: localStorage 'pcd73.ucc'. */
(function () {
  'use strict';
  if (typeof document === 'undefined') return;
  var W = window, KEY = 'pcd73.ucc';
  function P7() { return W.pcdProbe73 || W.pcdProbe72 || null; }
  function api() { return W.__p57api || null; }
  function ls(k, v) { try { if (v === undefined) return JSON.parse(localStorage.getItem(k) || 'null'); localStorage.setItem(k, JSON.stringify(v)); } catch (e) { return null; } }
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function num(v, d) { var n = parseFloat(String(v == null ? '' : v).replace(',', '.')); return isFinite(n) ? n : (d === undefined ? 0 : d); }
  function f(v) { return String(Math.round(v * 1000) / 1000); }
  function v3(p) { return f(p[0]) + ' ' + f(p[1]) + ' ' + f(p[2]); }
  function addv(a, b, k) { return [a[0] + b[0] * k, a[1] + b[1] * k, a[2] + b[2] * k]; }
  function toast(m) { var a = api(); if (a && a.toast) a.toast(m); else console.log(m); }

  var SYS = ['NoTool', 'RefTool', 'UnDefTool'];
  /* список инструментов с экрана UCCserver (Setup Machine → Tools), порядок как на экране */
  var DEF_TOOLS = ['SM25-1_L21_D5', 'SM25-1_L35_D4', 'SM25-1_L31_D2', 'SM25-2_L21_D5', 'SM25-3_L21_D3', 'SM25-4_L50_D5', 'SM25-4_L200_L50_D5', 'SM25-2_L75_D5',
    'SM25-5_L50_L40_D5', 'SM25-2_L75_D6', 'SM25-1_L30_D1x5', 'SM25-3_L200_D8', 'SM25-2_L50_D3', 'SM25-5_L95_L20_D3', 'SM25-5_L75_L40_D4', 'SM25-4_L200_L41_D3'];
  var DEF_SPH = ['Sphere_3x3', 'Sphere_random', 'Sphere_Y', 'Sphere_45', 'Sphere_-Y', 'Sphere_-45', 'Sphere_-90', 'Sphere_90', 'Sphere_0_', 'Sphere_X', 'Sphere_-X', 'Sphere_180'];
  var RACK_N = [3, 3, 1, 3, 1, 1, 1, 1]; /* Rack_1,2,4 — тройные FCR25 (по значку), остальные — одиночные гнёзда */

  /* разбор имени «SM25-5_L95_L20_D3»: модуль, [удлинитель L1], стержень L2, шарик D («D1x5» = Ø1.5) */
  function parseName(n) {
    var s = String(n || '').toUpperCase(), m = /SM25-(\d)/.exec(s), Ls = [], re = /_L(\d+(?:[.,]\d+)?)/g, x;
    while ((x = re.exec(s))) Ls.push(+x[1].replace(',', '.'));
    var d = /_D(\d+(?:[X.,]\d+)?)/.exec(s), D = d ? +d[1].replace(/[X,]/, '.') : 4, mod = m ? Math.max(1, Math.min(5, +m[1])) : 2;
    var ext = Ls.length > 1 ? Ls[0] : 0, L = Ls.length ? Ls[Ls.length - 1] : 40;
    return { name: String(n), module: mod, ext: ext, L: L, D: D, bend: mod === 5 && Ls.length > 1 ? 90 : 0, dir: 0, type: 'ball', dExt: ext >= 100 ? 8 : 6, note: '' };
  }
  function defCfg() {
    var racks = [], x = 60, pitch = 60;
    RACK_N.forEach(function (n, i) { racks.push({ name: 'Rack_' + (i + 1), n: n, x: x, y: 1440, z: 380, pitch: pitch }); x += n * pitch + 30; });
    var tools = DEF_TOOLS.map(parseName), ports = {}, k = 0;
    racks.forEach(function (r) { for (var j = 0; j < r.n; j++) { if (tools[k]) ports[r.name + '/' + (j + 1)] = tools[k].name; k++; } });
    var sph = DEF_SPH.map(function (nm, i) {
      var t = nm.replace(/^Sphere_/, '').replace(/_$/, ''), az = { X: 0, Y: 90, '-X': 180, '-Y': -90 }[t], tilt = 45;
      if (az == null) { az = isFinite(+t) ? +t : 0; if (!isFinite(+t)) tilt = 0; }
      return { name: nm, x: 80 + (i % 6) * 75, y: 120 + Math.floor(i / 6) * 90, z: 0, D: 25, stem: 120, az: az, tilt: tilt };
    });
    return { machine: { name: 'Legend_10158HA', X: 1000, Y: 1500, Z: 800 }, tools: tools, racks: racks, ports: ports, spheres: sph, active: 'SM25-2_L50_D3', head: { x: 285.7, y: 1177.6, z: 560, A: 90, B: 0 }, ver: 1 };
  }
  var CFG = null;
  function cfg() { if (CFG) return CFG; var c = ls(KEY); CFG = c && c.tools ? c : defCfg(); return CFG; }
  function save(noKin) { ls(KEY, CFG); if (!noKin) { try { P7().resetKin(); } catch (e) {} } }
  function U(s) { return String(s || '').toUpperCase().trim(); }
  function tool(s) {
    var c = cfg(), u = U(s); if (!u) return null;
    for (var i = 0; i < c.tools.length; i++) { var t = c.tools[i], n = U(t.name); if (n === u || u.indexOf(n + '.') === 0 || u.indexOf(n + ' ') === 0) return t; }
    return null;
  }
  var THR = { M2: 3, M3: 5, M4: 7, M5: 8 };
  /* компонент UCC:<имя> в формате PROBE.DAT: [удлинитель] → [колено] → стержень → шарик/диск + hotspot */
  function genItem(t, pm) {
    pm = /^M\d$/.test(pm || '') ? pm : 'M3';
    var L = Math.max(1, +t.L || 20), D = Math.max(0.3, +t.D || 2), E = Math.max(0, +t.ext || 0), b = (+t.bend || 0) * Math.PI / 180, ph = (+t.dir || 0) * Math.PI / 180;
    var thr = THR[pm] || 5, dE = +t.dExt || 6, stem = Math.max(0.4, Math.min(D * 0.7, thr * 0.9)), disc = t.type === 'disc';
    if (disc) stem = Math.max(0.6, Math.min(thr * 0.6, 3));
    var u = [Math.sin(b) * Math.cos(ph), Math.sin(b) * Math.sin(ph), -Math.cos(b)], P0 = [0, 0, -E], Pc = addv(P0, u, L), Ps = addv(P0, u, Math.max(0.1, L - (disc ? 0.8 : D * 0.4)));
    var c1 = Math.min(3, (E || L) * 0.15), lines = ['ribcount 12', 'color 117 117 117', 'cylinder 0 0 0 0 0 -' + f(c1) + ' ' + f(thr)];
    if (E > 0) lines.push('color 60 62 68', 'cylinder 0 0 -' + f(c1) + ' 0 0 -' + f(E) + ' ' + f(dE));
    if (b > 1e-6) lines.push('color 95 95 100', 'sphere ' + v3(P0) + ' ' + f(Math.max(dE, stem) * 1.35));
    lines.push('begintip', 'color 228 228 228', 'cylinder ' + v3(P0) + ' ' + v3(Ps) + ' ' + f(stem), 'color 255 0 0');
    if (disc) lines.push('cylinder ' + v3(addv(Pc, u, -0.8)) + ' ' + v3(addv(Pc, u, 0.8)) + ' ' + f(D)); else lines.push('sphere ' + v3(Pc) + ' ' + f(D));
    lines.push('hotspot ' + v3(Pc) + ' ' + v3([-u[0], -u[1], -u[2]]) + ' ' + f(D) + ' ' + f(D) + ' ' + (disc ? 'disk' : 'ball'), 'endtip');
    return { name: 'UCC:' + t.name, desc: 'UCC ' + t.name + ': ' + (E ? 'удл. ' + f(E) + ' + ' : '') + 'стержень ' + f(L) + (b ? ' под ' + f(+t.bend) + '°' : '') + ', ' + (disc ? 'диск' : 'шар') + ' Ø' + f(D), mountIn: pm, mountOut: '', cat: 'Стержень', hasTip: true, joints: 0, source: 'UCC', key: 'UCC:' + t.name + '@' + pm, lines: lines };
  }
  function item(name, pm) { var t = tool(name); return t ? genItem(t, pm) : null; }
  function chainOf(name) { var p = P7(); return p ? p.chainFor(name) : []; }
  /* сводка геометрии: вылет шарика от торца модуля (по оси) и в сторону */
  function reach(t) { var b = (+t.bend || 0) * Math.PI / 180; return { z: (+t.ext || 0) + (+t.L || 0) * Math.cos(b), r: (+t.L || 0) * Math.sin(b) }; }
  function portList() { var c = cfg(), out = []; c.racks.forEach(function (r) { for (var j = 0; j < r.n; j++) out.push({ key: r.name + '/' + (j + 1), rack: r, j: j, p: [r.x + j * r.pitch, r.y, r.z], tool: c.ports[r.name + '/' + (j + 1)] || '' }); }); return out; }
  function portOf(name) { var pl = portList(); for (var i = 0; i < pl.length; i++) if (pl[i].tool === name) return pl[i]; return null; }
  /* магазин для прогона (r71): тип «UCC Rack_1…8» в PCD_RACKS, координаты гнёзд — относительно левого заднего угла диапазона */
  function applyRack() {
    var p = P7(); if (!p) return 0;
    var pl = portList(), c = cfg(), it = { mount: 'UCC', geo: [], ports: pl.map(function (q) { return [q.p[0], q.p[1] - c.machine.Y, q.p[2], 0, -1, 0, q.key]; }) };
    W.PCD_RACKS = W.PCD_RACKS || {}; W.PCD_RACKS['UCC Rack_1…8'] = it;
    var probes = p.programProbes(), map = {}, n = 0;
    probes.forEach(function (pn) { var t = tool(pn); if (!t) return; for (var i = 0; i < pl.length; i++) if (pl[i].tool === t.name) { map[pn] = i; n++; return; } map[pn] = -1; });
    p.setRackCfg({ on: true, type: 'UCC Rack_1…8', x: 0, y: 0, z: 0, rot: 0, ports: map });
    try { if (p.play && p.play.bar) p.rebuildPlay(); } catch (e) {}
    return n;
  }

  /* ======================= 3D-вид Setup Machine ======================= */
  var V = null;
  function mkView(host) {
    var T = W.THREE; if (!T) return null;
    var w = host.clientWidth || 600, h = host.clientHeight || 420;
    var rd = new T.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true }); rd.setPixelRatio(Math.min(2, W.devicePixelRatio || 1)); rd.setSize(w, h); host.appendChild(rd.domElement);
    var sc = new T.Scene(); sc.background = new T.Color(0xdfeee0);
    var cam = new T.PerspectiveCamera(35, w / h, 5, 50000); cam.up.set(0, 0, 1);
    sc.add(new T.AmbientLight(0xffffff, 0.55)); var dl = new T.DirectionalLight(0xffffff, 0.8); dl.position.set(-800, -1200, 2500); sc.add(dl); var dl2 = new T.DirectionalLight(0xffffff, 0.35); dl2.position.set(1500, 2000, 800); sc.add(dl2);
    var v = { T: T, rd: rd, sc: sc, cam: cam, host: host, tgt: new T.Vector3(500, 750, 200), az: -2.0, el: 0.45, dist: 2600, world: null, objs: [], sel: null };
    v.upd = function () { var ce = Math.cos(v.el); cam.position.set(v.tgt.x + v.dist * ce * Math.cos(v.az), v.tgt.y + v.dist * ce * Math.sin(v.az), v.tgt.z + v.dist * Math.sin(v.el)); cam.lookAt(v.tgt); rd.render(sc, cam); };
    var drag = null, el = rd.domElement;
    el.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    el.addEventListener('mousedown', function (e) { drag = { x: e.clientX, y: e.clientY, b: e.button, sh: e.shiftKey }; e.preventDefault(); });
    W.addEventListener('mousemove', function (e) { if (!drag || !V || V !== v) return; var dx = e.clientX - drag.x, dy = e.clientY - drag.y; drag.x = e.clientX; drag.y = e.clientY;
      if (drag.b === 2 || drag.b === 1 || drag.sh) { var k = v.dist / 900, fw = new T.Vector3().subVectors(v.tgt, cam.position).normalize(), rt = new T.Vector3().crossVectors(fw, cam.up).normalize(), up = new T.Vector3().crossVectors(rt, fw).normalize(); v.tgt.addScaledVector(rt, -dx * k).addScaledVector(up, dy * k); }
      else { v.az -= dx * 0.008; v.el = Math.max(-1.45, Math.min(1.45, v.el + dy * 0.008)); }
      v.upd(); });
    W.addEventListener('mouseup', function () { drag = null; });
    el.addEventListener('wheel', function (e) { e.preventDefault(); v.dist = Math.max(80, Math.min(30000, v.dist * (e.deltaY > 0 ? 1.12 : 0.89))); v.upd(); }, { passive: false });
    el.addEventListener('dblclick', function (e) { var r = el.getBoundingClientRect(), m = new T.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1), rc = new T.Raycaster(); rc.setFromCamera(m, cam); var hit = rc.intersectObjects(sc.children, true)[0]; if (hit) { v.tgt.copy(hit.point); v.upd(); } });
    v.resize = function () { var w2 = host.clientWidth, h2 = host.clientHeight; if (!w2 || !h2) return; rd.setSize(w2, h2); cam.aspect = w2 / h2; cam.updateProjectionMatrix(); v.upd(); };
    v.dispose = function () { clearWorld(v); rd.dispose(); try { rd.forceContextLoss(); } catch (e) {} rd.domElement.remove(); };
    return v;
  }
  function clearWorld(v) { if (!v.world) return; v.sc.remove(v.world); v.world.traverse(function (x) { if (x.geometry) x.geometry.dispose(); if (x.material) { (Array.isArray(x.material) ? x.material : [x.material]).forEach(function (m) { if (m.map) m.map.dispose(); m.dispose(); }); } }); v.objs.forEach(function (o) { try { o.dispose(); } catch (e) {} }); v.objs = []; v.world = null; }
  function label(v, text, p, s, fg, bg) {
    var T = v.T, c = document.createElement('canvas'), x = c.getContext('2d'); x.font = 'bold 34px Arial'; var w = Math.ceil(x.measureText(text).width) + 16; c.width = w; c.height = 48;
    x.fillStyle = bg || 'rgba(255,255,255,0.85)'; x.fillRect(0, 0, w, 48); x.font = 'bold 34px Arial'; x.fillStyle = fg || '#1b3f8f'; x.textBaseline = 'middle'; x.fillText(text, 8, 25);
    var sp = new T.Sprite(new T.SpriteMaterial({ map: new T.CanvasTexture(c), depthTest: false, transparent: true })); sp.scale.set(s * 1.6 * w / 48, s * 1.6, 1); sp.position.set(p[0], p[1], p[2]); sp.renderOrder = 999; return sp; }
  function buildTool(name, A, B, partial) {
    var p7 = P7(); if (!p7) return null; var ch = chainOf(name); if (!ch.length) return null;
    if (partial) { var di = p7.dockIndex(ch); ch = ch.slice(Math.max(1, di)); }
    var ob = null; try { ob = p7.build(ch); } catch (e) { console.warn('r73 ucc build', e); }
    if (ob && ob.setAngles) ob.setAngles(A || 0, B || 0); return ob;
  }
  function drawWorld(v, opt) {
    var T = v.T, c = cfg(), M = c.machine, g = new T.Group(); opt = opt || {};
    clearWorld(v); v.world = g; v.sc.add(g);
    var mat = function (col, op) { return new T.MeshPhongMaterial({ color: col, shininess: 30, transparent: op < 1, opacity: op == null ? 1 : op }); };
    var box = function (x0, x1, y0, y1, z0, z1, m) { var o = new T.Mesh(new T.BoxGeometry(Math.abs(x1 - x0), Math.abs(y1 - y0), Math.abs(z1 - z0)), m); o.position.set((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2); g.add(o); return o; };
    /* плита и диапазон */
    box(-150, M.X + 150, -150, M.Y + 150, -160, 0, mat(0x3a3c40));
    var eg = new T.LineSegments(new T.EdgesGeometry(new T.BoxGeometry(M.X, M.Y, M.Z)), new T.LineBasicMaterial({ color: 0x7a9a7a, transparent: true, opacity: 0.6 })); eg.position.set(M.X / 2, M.Y / 2, M.Z / 2); g.add(eg);
    var ax = new T.AxesHelper(150); ax.position.set(0, 0, 2); g.add(ax);
    /* магазины */
    var mBar = mat(0x2b2d31), mPort = mat(0x55585e), mSel = mat(0xffa000);
    c.racks.forEach(function (r) {
      if (!r.n) return; var x0 = r.x - r.pitch / 2 + 6, x1 = r.x + (r.n - 1) * r.pitch + r.pitch / 2 - 6;
      box(x0, x1, r.y - 22, r.y + 40, r.z + 20, r.z + 34, mBar);
      g.add(label(v, r.name, [(x0 + x1) / 2, r.y - 30, r.z + 60], 16));
      for (var j = 0; j < r.n; j++) {
        var px = r.x + j * r.pitch, key = r.name + '/' + (j + 1), tn = c.ports[key];
        box(px - 17, px + 17, r.y - 20, r.y + 20, r.z - 6, r.z + 20, opt.selPort === key ? mSel : mPort);
        if (tn) { var ob = buildTool(tn, 0, 0, true); if (ob) { ob.root.position.set(px, r.y, r.z - 6); g.add(ob.root); v.objs.push(ob); } }
        g.add(label(v, String(j + 1) + (tn ? ' ' + tn : ''), [px, r.y - 26, r.z - 20 - (j % 2) * 14], tn ? 9 : 7, tn ? '#0b5' : '#666'));
      }
    });
    /* калибровочные сферы */
    var mS = mat(0xe8e8e8), mSt = mat(0x9a9ca2), mSs = mat(0xffb030);
    c.spheres.forEach(function (s) {
      var az = s.az * Math.PI / 180, tl = s.tilt * Math.PI / 180, d = [Math.sin(tl) * Math.cos(az), Math.sin(tl) * Math.sin(az), Math.cos(tl)], b0 = [s.x, s.y, s.z], top = addv(b0, d, s.stem);
      box(s.x - 22, s.x + 22, s.y - 22, s.y + 22, s.z, s.z + 18, mSt);
      var st = new T.Mesh(new T.CylinderGeometry(5, 7, s.stem, 12), mSt); st.position.set((b0[0] + top[0]) / 2, (b0[1] + top[1]) / 2, (b0[2] + top[2]) / 2 + 9); st.quaternion.setFromUnitVectors(new T.Vector3(0, 1, 0), new T.Vector3(d[0], d[1], d[2])); g.add(st);
      var sp = new T.Mesh(new T.SphereGeometry(s.D / 2, 24, 16), opt.selSph === s.name ? mSs : mS); sp.position.set(top[0], top[1], top[2] + 9); g.add(sp);
      g.add(label(v, s.name, [top[0], top[1], top[2] + s.D + 25], 9, '#333'));
    });
    /* пиноль + головка + активный инструмент */
    var H = c.head, ob2 = buildTool(c.active, H.A, H.B, false);
    box(H.x - 60, H.x + 60, H.y - 60, H.y + 60, H.z, H.z + 700, mat(0xb9bec6));
    if (ob2) { ob2.root.position.set(H.x, H.y, H.z); g.add(ob2.root); v.objs.push(ob2); var tl2 = ob2.tipLocal(H.A, H.B); v.tipW = [H.x + tl2.p[0], H.y + tl2.p[1], H.z + tl2.p[2]]; }
    g.add(label(v, c.active + '  A' + H.A + ' B' + H.B, [H.x, H.y, H.z + 760], 18, '#1b3f8f'));
    v.upd();
  }

  /* ======================= окно ======================= */
  var UI = { w: null, tab: 'tools', sel: null, msg: '' };
  var CSS = '.p73u{display:flex;gap:8px;height:100%}.p73u .v3{flex:1 1 52%;min-width:300px;height:470px;border:1px solid #9ab;border-radius:3px;position:relative;overflow:hidden}' +
    '.p73u .pn{flex:1 1 48%;min-width:360px;display:flex;flex-direction:column}.p73u .tb{display:flex;gap:2px;flex-wrap:wrap;border-bottom:1px solid #c9b48a;margin-bottom:4px}' +
    '.p73u .tb span{padding:3px 8px;cursor:pointer;background:#efe6d2;border:1px solid #d8c9a6;border-bottom:none;border-radius:3px 3px 0 0;font-size:12px}.p73u .tb span.on{background:#fff;font-weight:bold}' +
    '.p73u .ls{flex:1;overflow:auto;max-height:440px;font-size:12px}.p73u table{border-collapse:collapse;width:100%}.p73u td,.p73u th{border-bottom:1px solid #eee;padding:1px 3px;white-space:nowrap}' +
    '.p73u th{background:#f4efe2;position:sticky;top:0;font-weight:normal;color:#555}.p73u tr.on td{background:#fff3c8}.p73u input.n{width:52px}.p73u input.nm{width:150px}.p73u tr[data-t]{cursor:pointer}' +
    '.p73u input,.p73u select{height:20px!important;min-height:0!important;padding:0 3px!important;font-size:12px!important;margin:0!important;box-sizing:border-box}.p73u input.n{width:42px!important}.p73u input.nm{width:132px!important}.p73u select{width:auto!important}' +
    '.p73u .hint{color:#777;font-size:11px;margin:4px 0}.p73u .stat{position:absolute;left:0;right:0;bottom:0;background:rgba(255,236,200,.92);font:11px Consolas,monospace;padding:2px 6px}';
  function stEl() { var s = document.getElementById('p73uccCss'); if (!s) { s = document.createElement('style'); s.id = 'p73uccCss'; s.textContent = CSS; document.head.appendChild(s); } }
  function inp(k, v, cls, extra) { return '<input class="' + (cls || 'n') + '" data-k="' + k + '" value="' + esc(v) + '"' + (extra || '') + '>'; }
  function tabHtml() {
    var c = cfg(), t = UI.tab, h = [];
    if (t === 'tools') {
      h.push('<table><thead><tr><th>Инструмент</th><th>SM25</th><th title="Удлинитель L1, мм">L1</th><th title="Стержень L2, мм">L2</th><th title="Шарик / диск Ø, мм">D</th><th title="Поворот стержня (колено), °">∠</th><th title="Направление поворота вокруг оси модуля, °">напр.</th><th>тип</th><th>гнездо</th></tr></thead><tbody>');
      SYS.forEach(function (n) { h.push('<tr class="mut"><td colspan="9" style="color:#999">' + n + ' <span class="hint">(системный)</span></td></tr>'); });
      c.tools.forEach(function (x, i) {
        var po = portOf(x.name);
        h.push('<tr data-t="' + i + '"' + (UI.sel === x.name ? ' class="on"' : '') + '><td>' + (x.name === c.active ? '<b>● </b>' : '') + inp('name', x.name, 'nm') + '</td><td><select data-k="module">' + [1, 2, 3, 4, 5].map(function (m) { return '<option' + (m === +x.module ? ' selected' : '') + '>' + m + '</option>'; }).join('') + '</select></td>' +
          '<td>' + inp('ext', x.ext) + '</td><td>' + inp('L', x.L) + '</td><td>' + inp('D', x.D) + '</td><td>' + inp('bend', x.bend) + '</td><td>' + inp('dir', x.dir) + '</td>' +
          '<td><select data-k="type"><option value="ball"' + (x.type !== 'disc' ? ' selected' : '') + '>шар</option><option value="disc"' + (x.type === 'disc' ? ' selected' : '') + '>диск</option></select></td><td>' + (po ? esc(po.key) : '<span style="color:#aaa">—</span>') + '</td></tr>');
      });
      h.push('</tbody></table><div class="hint">Строка — выбрать (показ на пиноли). «●» — активный. L1 — удлинитель (у имён с двумя L: первая), L2 — стержень, ∠ — поворот стержня от оси (90° — «колено», для SM25-5 с двумя L задан по умолчанию, проверьте!), напр. — куда смотрит колено (0° = +X головки при A0B0).</div>');
    } else if (t === 'comp') {
      var mods = {}; c.tools.forEach(function (x) { (mods[x.module] = mods[x.module] || []).push(x.name); });
      h.push('<table><thead><tr><th>Компонент</th><th>Что это</th><th>Используется</th></tr></thead><tbody><tr><td>SP25_comp</td><td>корпус SP25M (PROBESP25M)</td><td>все</td></tr>');
      Object.keys(mods).sort().forEach(function (m) { h.push('<tr><td>SM25-' + m + '_comp</td><td>модуль SM25-' + m + ' (+SH25-' + m + ' если есть в PROBE.DAT)</td><td>' + mods[m].length + '</td></tr>'); });
      c.tools.forEach(function (x) { var it = genItem(x, 'M3'), r = reach(x); h.push('<tr data-t="' + c.tools.indexOf(x) + '"' + (UI.sel === x.name ? ' class="on"' : '') + '><td>' + esc(x.name) + '</td><td>' + esc(it.desc.replace(/^UCC \S+: /, '')) + '</td><td>вылет ' + f(r.z) + (r.r ? ' / вбок ' + f(r.r) : '') + ' мм</td></tr>'); });
      h.push('</tbody></table><div class="hint">Стержни генерируются как компоненты PROBE.DAT «UCC:&lt;имя&gt;» (удлинитель → колено → стержень → шар/диск + hotspot) и используются в прогоне, проверке столкновений и оценке времени.</div>');
    } else if (t === 'cal') {
      h.push('<table><thead><tr><th>Сфера</th><th>X</th><th>Y</th><th>Z</th><th>Ø</th><th>стойка</th><th title="азимут наклона стойки, °">азим.</th><th title="наклон стойки от вертикали, °">накл.</th></tr></thead><tbody>');
      c.spheres.forEach(function (s, i) { h.push('<tr data-s="' + i + '"' + (UI.selSph === s.name ? ' class="on"' : '') + '><td>' + inp('name', s.name, 'nm') + '</td><td>' + inp('x', s.x) + '</td><td>' + inp('y', s.y) + '</td><td>' + inp('z', s.z) + '</td><td>' + inp('D', s.D) + '</td><td>' + inp('stem', s.stem) + '</td><td>' + inp('az', s.az) + '</td><td>' + inp('tilt', s.tilt) + '</td></tr>'); });
      h.push('</tbody></table><div class="hint">Положения — в СК машины (мм от угла диапазона). По умолчанию: направление стойки из имени (X/Y/±90/45/180…), наклон 45°; Sphere_3x3 и Sphere_random — вертикальные. Задайте реальные координаты из UCCserver (CalibrationParts → свойства).</div>');
    } else if (t === 'racks') {
      h.push('<table><thead><tr><th>Магазин</th><th>гнёзд</th><th>X</th><th>Y</th><th>Z</th><th>шаг</th></tr></thead><tbody><tr><td colspan="6" style="color:#777">ManualChangePosition — ручная смена (вне магазина)</td></tr>');
      c.racks.forEach(function (r, i) { h.push('<tr data-r="' + i + '"><td><b>' + esc(r.name) + '</b></td><td>' + inp('n', r.n) + '</td><td>' + inp('x', r.x) + '</td><td>' + inp('y', r.y) + '</td><td>' + inp('z', r.z) + '</td><td>' + inp('pitch', r.pitch) + '</td></tr>'); });
      h.push('</tbody></table><div style="margin-top:6px"><b>Гнёзда</b></div><table><thead><tr><th>Гнездо</th><th>X</th><th>Y</th><th>Z</th><th>Инструмент</th></tr></thead><tbody>');
      var opts = '<option value="">— пусто —</option>' + c.tools.map(function (x) { return '<option>' + esc(x.name) + '</option>'; }).join('');
      portList().forEach(function (q) { h.push('<tr data-p="' + esc(q.key) + '"' + (UI.selPort === q.key ? ' class="on"' : '') + '><td>' + esc(q.key) + '</td><td>' + f(q.p[0]) + '</td><td>' + f(q.p[1]) + '</td><td>' + f(q.p[2]) + '</td><td><select data-k="port">' + opts.replace('<option>' + esc(q.tool) + '<', '<option selected>' + esc(q.tool) + '<') + '</select></td></tr>'); });
      h.push('</tbody></table><div class="hint">Rack_1, Rack_2, Rack_4 — тройные FCR25 (по значкам в UCCserver), остальные — одиночные. Кнопка «В прогон» передаёт гнёзда в симуляцию смены щупа (r71).</div>');
    } else if (t === 'mach') {
      var M = c.machine, H = c.head;
      h.push('<table><tbody><tr><td>Машина</td><td>' + inp('m.name', M.name, 'nm') + '</td></tr><tr><td>Диапазон X × Y × Z, мм</td><td>' + inp('m.X', M.X) + ' ' + inp('m.Y', M.Y) + ' ' + inp('m.Z', M.Z) + '</td></tr>' +
        '<tr><td>Пиноль X Y Z</td><td>' + inp('h.x', H.x) + ' ' + inp('h.y', H.y) + ' ' + inp('h.z', H.z) + '</td></tr><tr><td>Угол A / B</td><td>' + inp('h.A', H.A) + ' ' + inp('h.B', H.B) + '</td></tr>' +
        '<tr><td>Активный инструмент</td><td><select data-k="active">' + c.tools.map(function (x) { return '<option' + (x.name === c.active ? ' selected' : '') + '>' + esc(x.name) + '</option>'; }).join('') + '</select></td></tr></tbody></table>' +
        '<div class="hint">Как строка состояния UCCserver: X285.7142 Y-322.4449 Z-20.5983 A90 B0 (координаты UCC — от «дома» машины; здесь — от левого переднего угла диапазона).</div>');
    }
    if (UI.msg) h.push('<div class="hint" style="white-space:pre-line;color:#06c">' + esc(UI.msg) + '</div>');
    return h.join('');
  }
  function stat() {
    if (!UI.w || !V) return; var c = cfg(), H = c.head, t = V.tipW, el = UI.w.body.querySelector('.stat');
    if (el) el.textContent = 'Ready · ' + c.machine.name + ' · ' + c.active + '   X' + H.x.toFixed(4) + ' Y' + H.y.toFixed(4) + ' Z' + H.z.toFixed(4) + ' A' + H.A + ' B' + H.B + (t ? '   шарик: ' + t.map(function (q) { return q.toFixed(2); }).join(' ') : '');
  }
  function redraw3() { if (!V) return; try { drawWorld(V, { selPort: UI.selPort, selSph: UI.selSph }); } catch (e) { console.warn('r73 ucc 3d', e); } stat(); }
  function render() {
    if (!UI.w) return; var B = UI.w.body, pn = B.querySelector('.pn');
    pn.querySelector('.tb').innerHTML = [['tools', 'Tools'], ['comp', 'Components'], ['cal', 'CalibrationParts'], ['racks', 'Racks'], ['mach', 'Machine']].map(function (x) { return '<span data-tab="' + x[0] + '"' + (UI.tab === x[0] ? ' class="on"' : '') + '>' + x[1] + '</span>'; }).join('');
    pn.querySelector('.ls').innerHTML = tabHtml();
  }
  function onField(e) {
    var x = e.target, k = x.getAttribute('data-k'); if (!k) return; var c = cfg(), tr = x.closest('tr'), val = x.value;
    if (tr && tr.hasAttribute('data-t')) { var t = c.tools[+tr.getAttribute('data-t')];
      if (k === 'name') { var old = t.name; val = val.trim(); if (!val) return; t.name = val; Object.keys(c.ports).forEach(function (pk) { if (c.ports[pk] === old) c.ports[pk] = val; }); if (c.active === old) c.active = val; UI.sel = val; }
      else if (k === 'type') t.type = val; else t[k] = num(val, t[k]); }
    else if (tr && tr.hasAttribute('data-s')) { var s = c.spheres[+tr.getAttribute('data-s')]; if (k === 'name') s.name = val; else s[k] = num(val, s[k]); }
    else if (tr && tr.hasAttribute('data-r')) { var r = c.racks[+tr.getAttribute('data-r')]; r[k] = k === 'n' ? Math.max(0, Math.min(12, Math.round(num(val, r.n)))) : num(val, r[k]); }
    else if (tr && tr.hasAttribute('data-p') && k === 'port') { var pk2 = tr.getAttribute('data-p'); if (val) { Object.keys(c.ports).forEach(function (q) { if (c.ports[q] === val) delete c.ports[q]; }); c.ports[pk2] = val; } else delete c.ports[pk2]; }
    else if (k === 'active') c.active = val;
    else if (/^m\./.test(k)) c.machine[k.slice(2)] = k === 'm.name' ? val : num(val, c.machine[k.slice(2)]);
    else if (/^h\./.test(k)) c.head[k.slice(2)] = num(val, c.head[k.slice(2)]);
    save(); render(); redraw3();
  }
  function onClick(e) {
    var tb = e.target.closest('[data-tab]'); if (tb) { UI.tab = tb.getAttribute('data-tab'); UI.msg = ''; render(); return; }
    if (/^(INPUT|SELECT|OPTION)$/.test(e.target.tagName)) return;
    var tr = e.target.closest('tr'); if (!tr) return; var c = cfg();
    if (tr.hasAttribute('data-t')) { UI.sel = c.tools[+tr.getAttribute('data-t')].name; render(); }
    else if (tr.hasAttribute('data-s')) { UI.selSph = c.spheres[+tr.getAttribute('data-s')].name; render(); redraw3(); }
    else if (tr.hasAttribute('data-p')) { UI.selPort = tr.getAttribute('data-p'); render(); redraw3(); }
  }
  function goPort() { var c = cfg(), p = portOf(UI.sel || c.active); if (!p) { toast('Инструмент не стоит в магазине'); return; } c.head.x = p.p[0]; c.head.y = p.p[1] - 120; c.head.z = p.p[2] + 260; c.head.A = 0; c.head.B = 0; UI.selPort = p.key; save(true); render(); redraw3(); }
  function goSph() { var c = cfg(), s = null; c.spheres.forEach(function (q) { if (q.name === UI.selSph) s = q; }); s = s || c.spheres[0]; if (!s) return; var t = tool(c.active), r = t ? reach(t) : { z: 60 };
    var az = s.az * Math.PI / 180, tl = s.tilt * Math.PI / 180, d = [Math.sin(tl) * Math.cos(az), Math.sin(tl) * Math.sin(az), Math.cos(tl)], top = addv([s.x, s.y, s.z + 9], d, s.stem);
    c.head.A = 0; c.head.B = 0; var ob = buildTool(c.active, 0, 0, false), tp = ob ? ob.tipLocal(0, 0).p : [0, 0, -(r.z + 200)]; if (ob) ob.dispose();
    c.head.x = top[0] - tp[0]; c.head.y = top[1] - tp[1]; c.head.z = top[2] + s.D / 2 + (t ? t.D / 2 : 2) + 10 - tp[2]; UI.selSph = s.name; save(true); render(); redraw3(); }
  function open() {
    var a = api(); if (!a) return; stEl();
    if (UI.w) { try { UI.w.close(); } catch (e) {} }
    var w = a.win('p73ucc', 'Сервер КИМ (UCCserver) — Setup Machine', 'feat', 1180); w.el.classList.add('p68'); UI.w = w;
    w.body.innerHTML = '<div class="p73u"><div class="v3"><div class="stat"></div></div><div class="pn"><div class="tb"></div><div class="ls"></div></div></div>';
    var B = w.body; B.addEventListener('change', onField); B.addEventListener('click', onClick);
    render();
    setTimeout(function () { try { if (V) V.dispose(); V = mkView(B.querySelector('.v3')); if (V) { V.host.appendChild(B.querySelector('.stat')); redraw3(); } } catch (e) { console.warn('r73 ucc view', e); } }, 30);
    var cl = w.close; w.close = function () { try { if (V) V.dispose(); } catch (e) {} V = null; UI.w = null; return cl.apply(w, arguments); };
    try { var xb = w.el.querySelector('.x,.close,[data-close]'); if (xb) xb.addEventListener('click', function () { try { if (V) V.dispose(); } catch (e) {} V = null; UI.w = null; }); } catch (e) {}
    w.foot.innerHTML = ''; w.foot.style.cssText = 'display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end;padding:6px 10px';
    var bt = function (t, fn, d) { w.foot.appendChild(a.btn(t, fn, d)); };
    bt('Сделать активным', function () { var c = cfg(); if (UI.sel) { c.active = UI.sel; save(); render(); redraw3(); } });
    bt('К гнезду', goPort); bt('К сфере', goSph);
    bt('+ Инструмент', function () { var n = prompt('Имя инструмента (как в UCCserver / ЗАГР/ЩУП), напр. SM25-2_L75_D6 или SM25-5_L95_L20_D3', 'SM25-2_L50_D4'); if (!n) return; var c = cfg(); if (tool(n) && U(tool(n).name) === U(n)) { toast('Уже есть'); return; } c.tools.push(parseName(n.trim())); UI.sel = n.trim(); save(); render(); redraw3(); });
    bt('Удалить', function () { var c = cfg(); if (!UI.sel) return; if (!confirm('Удалить ' + UI.sel + '?')) return; c.tools = c.tools.filter(function (x) { return x.name !== UI.sel; }); Object.keys(c.ports).forEach(function (q) { if (c.ports[q] === UI.sel) delete c.ports[q]; }); UI.sel = null; save(); render(); redraw3(); });
    bt('Вставить список…', function () { var t = prompt('Имена инструментов через пробел / запятую / с новой строки (лишние — добавятся, существующие не меняются):', ''); if (!t) return; var c = cfg(), n = 0; t.split(/[\s,;]+/).forEach(function (x) { if (/^SM25-\d/i.test(x) && !tool(x)) { c.tools.push(parseName(x)); n++; } }); UI.msg = 'Добавлено: ' + n; save(); render(); redraw3(); });
    bt('В прогон (магазин)', function () { var n = applyRack(); UI.msg = 'Магазин «UCC Rack_1…8» передан в прогон. Щупов программы в гнёздах: ' + n + '.'; render(); });
    bt('Щупы программы', function () { var p = P7(), pr = p ? p.programProbes() : []; UI.msg = pr.length ? pr.map(function (x) { var t = tool(x); return x + ' → ' + (t ? 'UCC ' + t.name + ' (' + chainOf(x).join(' · ') + ')' : 'нет в библиотеке UCC: ' + chainOf(x).join(' · ')); }).join('\n') : 'В программе нет ЗАГР/ЩУП'; render(); });
    bt('Экспорт probe.dat', function () { var c = cfg(), out = ['comment UCCserver tools → PC-DMIS usrprobe.dat (r73)']; c.tools.forEach(function (x) { var it = genItem(x, 'M3'); out.push('ITEM:' + x.name.replace(/\s+/g, '_') + ' M3', 'comment ' + it.desc); it.lines.forEach(function (l) { out.push(l); }); }); var b = new Blob([out.join('\r\n') + '\r\n'], { type: 'text/plain' }), u = URL.createObjectURL(b), z = document.createElement('a'); z.href = u; z.download = 'ucc-tools-usrprobe.dat'; document.body.appendChild(z); z.click(); setTimeout(function () { URL.revokeObjectURL(u); z.remove(); }, 500); });
    bt('Сброс к экрану UCC', function () { if (!confirm('Вернуть список инструментов, сфер и магазинов по умолчанию (с фото UCCserver)?')) return; CFG = defCfg(); save(); render(); redraw3(); });
    bt('Закрыть', function () { w.close(); });
  }
  function menu() {
    var mi = document.getElementById('p68Mi'); if (!mi) return false; var sb = mi.querySelector('.sub'); if (!sb) return false; if (document.getElementById('p73uccIt')) return true;
    var s = document.createElement('span'); s.className = 'si'; s.id = 'p73uccIt'; s.textContent = 'Сервер КИМ (UCCserver) — Setup Machine…';
    s.addEventListener('click', function (e) { e.stopPropagation(); [].forEach.call(document.querySelectorAll('.mi.open'), function (y) { y.classList.remove('open'); }); open(); });
    sb.insertBefore(s, sb.firstChild); return true;
  }
  var n = 0, iv = setInterval(function () { if ((menu() && n > 4) || ++n > 60) clearInterval(iv); }, 500);
  W.addEventListener('resize', function () { if (V) V.resize(); });
  W.pcdUcc = { tool: tool, item: item, genItem: genItem, cfg: cfg, save: save, open: open, parseName: parseName, applyRack: applyRack, portList: portList, reset: function () { CFG = defCfg(); save(); }, view: function () { return V; }, redraw: function () { render(); redraw3(); } };
})();
