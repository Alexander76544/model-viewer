/* r73 — «Базы и системы координат»: разбор START_ALIGN из .PRG (теоретическое начало/оси СК в координатах CAD и
   измеренное положение в СК машины), привязка элементов к СК, показ СК в 3D (триады с именами, «0 машины»),
   исправление касаний ручных баз (ЗАПУСК: касания записаны в координатах машины → переносятся на номинал),
   автоподбор положения модели STL/STEP по касаниям программы (модель экспортирована от другого начала).
   Формат START_ALIGN (восстановлен по op5/op40): после 3-й метки FF FE FF (имя СК) — 12 пар double (теор, изм):
   Ox, X.i, X.j, X.k, Oy, Y.i, Y.j, Y.k, Oz, Z.i, Z.j, Z.k. Подключается после pcdmis-probe-r73.js. */
(function () {
  'use strict';
  if (typeof document === 'undefined') return;
  var W = window, KEY = 'pcd73.bases';
  function P7() { return W.pcdProbe73 || W.pcdProbe72 || null; }
  function api() { return W.__p57api || null; }
  function G(n) { var a = api(); return a && a.G ? a.G(n) : W[n]; }
  function S() { var a = api(); return a && a.S ? a.S() : null; }
  function ls(k, v) { try { if (v === undefined) return JSON.parse(localStorage.getItem(k) || 'null'); localStorage.setItem(k, JSON.stringify(v)); } catch (e) { return null; } }
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function num(v, d) { var n = parseFloat(String(v == null ? '' : v).replace(',', '.')); return isFinite(n) ? n : (d === undefined ? 0 : d); }
  function toast(m) { var a = api(); if (a && a.toast) a.toast(m); else console.log(m); }
  function sub(a, b) { return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]; }
  function dot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
  function len(a) { return Math.sqrt(dot(a, a)); }
  function nrm(a) { var l = len(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; }
  function addv(a, b, k) { k = k == null ? 1 : k; return [a[0] + b[0] * k, a[1] + b[1] * k, a[2] + b[2] * k]; }
  function f1(v) { return (Math.round(v * 10) / 10).toFixed(1); }
  function f3(v) { return (Math.round(v * 1000) / 1000).toFixed(3); }
  function opt() { var o = ls(KEY) || {}; return { show: o.show !== false, mach: !!o.mach, fix: o.fix !== false, base: o.base !== false }; }
  function setOpt(k, v) { var o = opt(); o[k] = v; ls(KEY, o); }

  /* ---------- разбор СК ---------- */
  var AL = { at: 0, list: [], byFeat: {}, bases: {} };
  function u16(part, k) { var n = part[k + 3], s = ''; for (var i = 0; i < n; i++) s += String.fromCharCode(part[k + 4 + i * 2] | (part[k + 5 + i * 2] << 8)); return s; }
  function aligns() {
    var p7 = P7(), L = p7 && p7.last; if (!L || !L.cmds || !L.part) return AL;
    if (AL.at === L.at) return AL;
    var part = L.part, C = L.cmds.commands || [], dv = new DataView(part.buffer, part.byteOffset, part.byteLength), list = [], byFeat = {}, cur = 'ЗАПУСК', bases = {}, recent = [];
    C.forEach(function (c, i) {
      if (c.id === 'START_ALIGN') {
        var a = c.at, b = C[i + 1] ? C[i + 1].at : Math.min(part.length, a + 600), m = [];
        for (var k = a; k < b - 3; k++) if (part[k] === 0xff && part[k + 1] === 0xfe && part[k + 2] === 0xff) m.push(k);
        var A = { name: String(c.arg || ('СК' + (list.length + 1))), ci: i, feats: [], base: [] };
        if (m.length >= 3) { var o = m[2] + 4 + part[m[2] + 3] * 2, D = []; for (var q = 0; q < 24 && o + q * 8 + 8 <= b; q++) D.push(dv.getFloat64(o + q * 8, true));
          if (D.length === 24 && D.every(function (x) { return isFinite(x) && Math.abs(x) < 1e7; })) {
            A.Ot = [D[0], D[8], D[16]]; A.Om = [D[1], D[9], D[17]];
            A.Rt = [[D[2], D[4], D[6]], [D[10], D[12], D[14]], [D[18], D[20], D[22]]]; A.Rm = [[D[3], D[5], D[7]], [D[11], D[13], D[15]], [D[19], D[21], D[23]]];
            /* 0 машины в координатах CAD: Ot + Rtᵀ·(Rm·(0 − Om)) */
            var lo = A.Rm.map(function (r) { return -dot(r, A.Om); }), mz = A.Ot.slice(); for (var j = 0; j < 3; j++) mz = addv(mz, A.Rt[j], lo[j]); A.mz = mz;
            A.mAx = [0, 1, 2].map(function (j) { var e = [0, 0, 0]; e[j] = 1; var lj = A.Rm.map(function (r) { return dot(r, e); }), v = [0, 0, 0]; for (var t = 0; t < 3; t++) v = addv(v, A.Rt[t], lj[t]); return nrm(v); });
            A.rot = [Math.atan2(A.Rm[1][2], A.Rm[2][2]), -Math.asin(Math.max(-1, Math.min(1, A.Rm[0][2]))), Math.atan2(A.Rm[0][1], A.Rm[0][0])].map(function (r) { return r * 180 / Math.PI; });
          } }
        A.base = recent.slice(-3); A.base.forEach(function (n) { (bases[n] = bases[n] || []).push(A.name); });
        list.push(A); cur = A.name; recent = []; return;
      }
      if (c.id === 'RECALL_ALIGN') { recent = []; return; }
      if (c.feature && c.feature.name) { var fn = c.feature.name; if (!byFeat[fn]) { byFeat[fn] = cur; var A2 = list[list.length - 1]; if (A2) A2.feats.push(fn); else (AL.start = AL.start || []).push(fn); } if (recent.indexOf(fn) < 0) recent.push(fn); }
    });
    if (!list.length || list[0].name !== 'ЗАПУСК') list.unshift({ name: 'ЗАПУСК', ci: -1, feats: [], base: [], Ot: [0, 0, 0], Om: [0, 0, 0], Rt: [[1, 0, 0], [0, 1, 0], [0, 0, 1]], Rm: [[1, 0, 0], [0, 1, 0], [0, 0, 1]], rot: [0, 0, 0], implicit: true });
    AL = { at: L.at, list: list, byFeat: byFeat, bases: bases };
    return AL;
  }

  /* ---------- исправление касаний ручных баз ---------- */
  var FIX = { at: 0, list: [] };
  function elsWithHits() { var st = S(); return ((st && st.elements) || []).filter(function (e) { return (e._hits && e._hits.length) || (e._hitsRaw && e._hitsRaw.length); }); }
  function fixOne(e) {
    var H = e._hitsRaw || e._hits; if (!H || !H.length) return null;
    var c = [0, 0, 0]; H.forEach(function (h) { c[0] += +h[0]; c[1] += +h[1]; c[2] += +h[2]; }); c = c.map(function (v) { return v / H.length; });
    var nom = [num(e.x), num(e.y), num(e.z)], v = nrm([num(e.i), num(e.j), num(e.k, 1)]), d = sub(nom, c), t = String(e.type || '').toLowerCase(), dia = num(e.diam, 0);
    var ext = 0; H.forEach(function (h) { ext = Math.max(ext, len(sub([+h[0], +h[1], +h[2]], c))); });
    var bad = false, sh = d;
    if (/plane/.test(t)) { var dn = Math.abs(dot(d, v)), dp = len(addv(d, v, -dot(d, v))); bad = dn > 25 || dp > Math.max(150, ext * 3); }
    else if (/cyl|circle|cone/.test(t)) { var ax = dot(d, v), rad = len(addv(d, v, -ax)); bad = rad > Math.max(25, dia * 1.5); if (bad && Math.abs(ax) < Math.max(100, ext * 2)) sh = addv(d, v, -ax); }
    else if (/sphere|point/.test(t)) bad = len(d) > Math.max(25, dia * 1.5);
    else bad = len(d) > Math.max(60, dia * 2, ext * 3);
    return bad ? { name: e.name, d: sh, dist: len(sh), n: H.length } : null;
  }
  function applyFix(force) {
    var on = opt().fix, out = [], ch = false;
    elsWithHits().forEach(function (e) {
      var r = on ? fixOne(e) : null;
      if (r) { var key = r.d.map(f3).join(','); if (e._hitsFix !== key || force) { if (!e._hitsRaw) e._hitsRaw = e._hits; e._hits = e._hitsRaw.map(function (h) { var q = h.slice(); q[0] = +h[0] + r.d[0]; q[1] = +h[1] + r.d[1]; q[2] = +h[2] + r.d[2]; return q; }); e._hitsFix = key; ch = true; } out.push(r); }
      else if (e._hitsRaw) { e._hits = e._hitsRaw; delete e._hitsRaw; delete e._hitsFix; ch = true; }
    });
    FIX.list = out;
    if (ch) { try { if (W.prgHits) W.prgHits.rebuild(); } catch (e) {} try { P7().resetKin(); } catch (e) {} }
    return out;
  }

  /* ---------- 3D: триады СК ---------- */
  var G3 = { grp: null, sig: '' };
  function txt(T, text, col) {
    var c = document.createElement('canvas'); c.width = 512; c.height = 64; var x = c.getContext('2d'); x.font = 'bold 34px Arial'; var w = Math.min(500, x.measureText(text).width + 24);
    x.fillStyle = 'rgba(255,255,255,0.88)'; x.fillRect(0, 6, w, 52); x.strokeStyle = col; x.lineWidth = 3; x.strokeRect(1.5, 7.5, w - 3, 49); x.fillStyle = col; x.textBaseline = 'middle'; x.fillText(text, 12, 33);
    var tx = new T.CanvasTexture(c), sp = new T.Sprite(new T.SpriteMaterial({ map: tx, depthTest: false, transparent: true })); sp.center.set(0, 0.5); sp.renderOrder = 1001; sp.userData.px = true; return sp;
  }
  function triad(T, g, O, axes, L, cols, name, col) {
    var lbl = ['X', 'Y', 'Z'];
    axes.forEach(function (a, i) { var ar = new T.ArrowHelper(new T.Vector3(a[0], a[1], a[2]).normalize(), new T.Vector3(O[0], O[1], O[2]), L, cols[i], L * 0.22, L * 0.1); ar.traverse(function (x) { if (x.material) { x.material.depthTest = false; x.renderOrder = 1000; } }); g.add(ar);
      var s = txt(T, lbl[i], '#' + ('00000' + cols[i].toString(16)).slice(-6)); s.position.set(O[0] + a[0] * L * 1.12, O[1] + a[1] * L * 1.12, O[2] + a[2] * L * 1.12); s.userData.sz = 0.018; g.add(s); });
    var sp = txt(T, name, col); sp.position.set(O[0], O[1], O[2]); sp.userData.sz = 0.03; g.add(sp);
  }
  function drop3() { var sc = G('scene3'); if (G3.grp) { if (sc) sc.remove(G3.grp); G3.grp.traverse(function (x) { if (x.geometry) x.geometry.dispose(); if (x.material) { if (x.material.map) x.material.map.dispose(); x.material.dispose(); } }); G3.grp = null; } }
  function build3() {
    var T = W.THREE, sc = G('scene3'), o = opt(); if (!T || !sc) return;
    var A = aligns(), sig = A.at + ':' + o.show + o.mach + o.base + ':' + (S() && S().elements || []).length;
    if (G3.grp && G3.sig === sig) { sync3(); return; } drop3(); G3.sig = sig;
    if (!(o.show || o.mach || o.base) || !A.list.length) return;
    var g = new T.Group(); g.name = 'p73bases'; g.matrixAutoUpdate = false; G3.grp = g;
    var st = S(), by = {}; ((st && st.elements) || []).forEach(function (e) { by[e.name] = e; });
    var bb = [1e9, -1e9]; Object.keys(by).forEach(function (k) { var e = by[k]; [num(e.x), num(e.y), num(e.z)].forEach(function (v) { bb[0] = Math.min(bb[0], v); bb[1] = Math.max(bb[1], v); }); });
    var L = Math.max(25, Math.min(150, (bb[1] - bb[0]) * 0.08 || 60)), seen = {};
    A.list.forEach(function (al, i) {
      if (!al.Ot) return; var key = al.Ot.map(f1).join(',');
      if (o.show) { var nm = (seen[key] ? seen[key] + ' = ' : '') + al.name; seen[key] = nm; triad(T, g, al.Ot, al.Rt, L, [0xe53935, 0x2e9d3a, 0x1e63d6], 'СК ' + nm, al.implicit || al.name === 'ЗАПУСК' ? '#777777' : '#6a1b9a'); }
      if (o.mach && al.mz && !al.implicit && al.name !== 'ЗАПУСК' && i === A.list.findIndex(function (x) { return x.mz && x.name !== 'ЗАПУСК'; })) triad(T, g, al.mz, al.mAx, L * 1.6, [0x9e9e9e, 0x9e9e9e, 0x9e9e9e], '0 машины (по ' + al.name + ')', '#555555');
      if (o.base) al.base.forEach(function (fn, k) { var e = by[fn]; if (!e) return; var s = txt(T, '⌖ ' + fn + ' → ' + al.name, '#6a1b9a'); s.position.set(num(e.x), num(e.y), num(e.z)); s.userData.sz = 0.022; g.add(s); });
    });
    sc.add(g); sync3();
  }
  function sync3() {
    if (!G3.grp) return; var p7 = P7(), cam = G('camera3'); try { G3.grp.matrix.copy(p7.progMatrix()); G3.grp.matrixWorldNeedsUpdate = true; } catch (e) {}
    if (!cam) return; var T = W.THREE, v = new T.Vector3();
    G3.grp.updateMatrixWorld(true);
    G3.grp.traverse(function (x) { if (!x.isSprite || !x.userData.sz) return; x.getWorldPosition(v); var d = cam.isOrthographicCamera ? (cam.top - cam.bottom) / cam.zoom : v.distanceTo(cam.position) * 2 * Math.tan((cam.fov || 45) * Math.PI / 360); var h = d * x.userData.sz; x.scale.set(h * 8, h, 1); });
  }

  /* ---------- автоподбор положения модели ---------- */
  var UNDO = null;
  function meshPts(maxN) {
    var T = W.THREE, m = G('stlMesh3'); if (!m) return null; m.updateMatrixWorld(true);
    var inv = new T.Matrix4().copy(P7().progMatrix()).invert(), M = new T.Matrix4().multiplyMatrices(inv, m.matrixWorld), out = [], v = new T.Vector3();
    m.traverse(function (x) { if (!x.isMesh || !x.geometry || !x.geometry.attributes.position) return; var pa = x.geometry.attributes.position, n = pa.count, st = Math.max(1, Math.floor(n / maxN)), Mx = new T.Matrix4().multiplyMatrices(inv, x.matrixWorld);
      for (var i = 0; i < n; i += st) { v.fromBufferAttribute(pa, i).applyMatrix4(Mx); out.push([v.x, v.y, v.z]); } });
    return out;
  }
  function grid(P) {
    var mn = [1e18, 1e18, 1e18], mx = [-1e18, -1e18, -1e18]; P.forEach(function (p) { for (var a = 0; a < 3; a++) { if (p[a] < mn[a]) mn[a] = p[a]; if (p[a] > mx[a]) mx[a] = p[a]; } });
    var dg = len(sub(mx, mn)) || 1, cs = Math.max(1, dg / 120), H = new Map();
    P.forEach(function (p) { var k = Math.floor(p[0] / cs) + ',' + Math.floor(p[1] / cs) + ',' + Math.floor(p[2] / cs), a = H.get(k); if (!a) H.set(k, a = []); a.push(p); });
    return { cs: cs, H: H, mn: mn, mx: mx, c: [(mn[0] + mx[0]) / 2, (mn[1] + mx[1]) / 2, (mn[2] + mx[2]) / 2] };
  }
  function nearest(Gr, q, R) {
    var cs = Gr.cs, ix = Math.floor(q[0] / cs), iy = Math.floor(q[1] / cs), iz = Math.floor(q[2] / cs), best = null, bd = 1e18;
    for (var dx = -R; dx <= R; dx++) for (var dy = -R; dy <= R; dy++) for (var dz = -R; dz <= R; dz++) { var a = Gr.H.get((ix + dx) + ',' + (iy + dy) + ',' + (iz + dz)); if (!a) continue; for (var i = 0; i < a.length; i++) { var p = a[i], d = (p[0] - q[0]) * (p[0] - q[0]) + (p[1] - q[1]) * (p[1] - q[1]) + (p[2] - q[2]) * (p[2] - q[2]); if (d < bd) { bd = d; best = p; } } }
    return best ? { p: best, d: Math.sqrt(bd) } : null;
  }
  function progPts(maxN) {
    var out = [], els = elsWithHits(), tot = 0; els.forEach(function (e) { tot += (e._hits || []).length; });
    var st = Math.max(1, Math.floor(tot / maxN)), k = 0;
    els.forEach(function (e) { (e._hits || []).forEach(function (h) { if (k++ % st === 0) out.push([+h[0], +h[1], +h[2]]); }); });
    if (out.length < 10) { var s = S(); ((s && s.elements) || []).forEach(function (e) { if (/plane|point/.test(String(e.type))) out.push([num(e.x), num(e.y), num(e.z)]); }); }
    return out;
  }
  function score(Gr, Q, t, tol) { var n = 0, s = 0; Q.forEach(function (q) { var r = nearest(Gr, [q[0] - t[0], q[1] - t[1], q[2] - t[2]], 1); if (r && r.d < tol) { n++; s += r.d; } }); return { n: n, s: s }; }
  function fitModel() {
    var P = meshPts(120000); if (!P || !P.length) { toast('Сначала загрузите модель (STL/STEP)'); return null; }
    var Q = progPts(2500); if (!Q.length) { toast('В программе нет касаний / элементов'); return null; }
    applyFix(); Q = progPts(2500);
    var Gr = grid(P), tol = Math.max(1.5, Gr.cs * 0.9), cq = [0, 0, 0]; Q.forEach(function (q) { cq = addv(cq, q, 1 / Q.length); });
    var cand = [{ t: [0, 0, 0], why: 'текущее положение' }, { t: sub(cq, Gr.c), why: 'по центру касаний' }];
    aligns().list.forEach(function (a) { if (a.Ot && len(a.Ot) > 1e-3) { cand.push({ t: a.Ot.slice(), why: 'модель от начала СК ' + a.name }); cand.push({ t: a.Ot.map(function (v) { return -v; }), why: 'программа от начала СК ' + a.name }); } });
    cand.forEach(function (c) { var r = score(Gr, Q, c.t, tol); c.n = r.n; c.s = r.s; });
    cand.sort(function (a, b) { return b.n - a.n || a.s - b.s; });
    var best = cand[0], t = best.t.slice();
    /* уточнение (ICP, только перенос) */
    var R0 = 4;
    for (var it = 0; it < 20; it++) { var acc = [0, 0, 0], n = 0, lim = Gr.cs * (it < 6 ? 3 : 1.2);
      Q.forEach(function (q) { var qq = [q[0] - t[0], q[1] - t[1], q[2] - t[2]], r = nearest(Gr, qq, it < 6 ? R0 : 2); if (r && r.d < lim) { acc = addv(acc, sub(qq, r.p)); n++; } });
      if (n < Math.max(5, Q.length * 0.05)) break; var d = acc.map(function (v) { return v / n; }); t = addv(t, d); if (len(d) < 0.01) break; }
    var fin = score(Gr, Q, t, tol);
    return { t: t, from: best, n: fin.n, of: Q.length, tol: tol, cand: cand };
  }
  function stlT() { return G('stlTransform'); }
  function setFields() { var t = stlT(); if (!t) return; [['stlOffX', 'x'], ['stlOffY', 'y'], ['stlOffZ', 'z'], ['stlRotX', 'rx'], ['stlRotY', 'ry'], ['stlRotZ', 'rz']].forEach(function (p) { var el = document.getElementById(p[0]); if (el) el.value = Math.round(t[p[1]] * 1e4) / 1e4; }); }
  function moveModel(tp) {
    var T = W.THREE, st = stlT(), ap = G('applyStlTransform'); if (!st || typeof ap !== 'function') { toast('Нет модели'); return false; }
    UNDO = { x: st.x, y: st.y, z: st.z };
    var pm = P7().progMatrix(), a = new T.Vector3(0, 0, 0).applyMatrix4(pm), b = new T.Vector3(tp[0], tp[1], tp[2]).applyMatrix4(pm), d = b.sub(a);
    var m = G('stlMesh3'), par = m && m.parent; if (par && par !== G('scene3')) { par.updateMatrixWorld(true); var inv = new T.Matrix3().setFromMatrix4(new T.Matrix4().copy(par.matrixWorld).invert()); d.applyMatrix3(inv); }
    st.x += d.x; st.y += d.z; st.z += d.y; ap(); setFields();
    try { var f = G('scheduleModelMetaAutosave'); if (typeof f === 'function') f(); } catch (e) {} try { var f2 = G('persistProjectTransform3'); if (typeof f2 === 'function') f2(); } catch (e) {}
    try { P7().resetKin(); } catch (e) {}
    return true;
  }

  /* ---------- окно ---------- */
  var UI = { w: null, msg: '' };
  function body() {
    var A = aligns(), o = opt(), fx = applyFix(), h = [];
    h.push('<div class="row" style="display:flex;gap:14px;flex-wrap:wrap"><label><input type="checkbox" data-o="show"' + (o.show ? ' checked' : '') + '> СК в 3D (триады с именами)</label><label><input type="checkbox" data-o="base"' + (o.base ? ' checked' : '') + '> базовые элементы СК</label>' +
      '<label><input type="checkbox" data-o="mach"' + (o.mach ? ' checked' : '') + '> 0 машины</label><label title="Касания ручных баз под ЗАПУСК записаны в координатах машины — переносим их на номинал элемента"><input type="checkbox" data-o="fix"' + (o.fix ? ' checked' : '') + '> исправлять касания ручных баз</label></div>');
    if (!A.list.length) h.push('<div class="mut">Откройте .PRG — системы координат читаются из команд START_ALIGN.</div>');
    else {
      h.push('<table><thead><tr><th>СК</th><th class="n">Начало (CAD) X</th><th class="n">Y</th><th class="n">Z</th><th class="n">В машине X</th><th class="n">Y</th><th class="n">Z</th><th class="n" title="поворот детали на столе относительно осей машины: вокруг X / Y / Z, °">Поворот, °</th><th>Элем.</th><th>Базы (по порядку)</th></tr></thead><tbody>');
      A.list.forEach(function (a) { h.push('<tr><td><b>' + esc(a.name) + '</b>' + (a.implicit ? ' <span class="mut">(неявная)</span>' : '') + '</td>' + (a.Ot ? a.Ot.map(function (v) { return '<td class="n">' + f3(v) + '</td>'; }).join('') + a.Om.map(function (v) { return '<td class="n">' + f3(v) + '</td>'; }).join('') + '<td class="n">' + a.rot.map(function (v) { return v.toFixed(3); }).join(' / ') + '</td>' : '<td colspan="7" class="mut">нет данных</td>') + '<td class="n">' + a.feats.length + '</td><td>' + esc(a.base.join(', ')) + '</td></tr>'); });
      h.push('</tbody></table>');
    }
    h.push('<div class="cap" style="margin-top:6px">Исправленные касания (' + fx.length + ')</div>');
    if (fx.length) h.push('<table><thead><tr><th>Элемент</th><th>СК</th><th class="n">Касаний</th><th class="n">Сдвиг, мм</th><th class="n">dX</th><th class="n">dY</th><th class="n">dZ</th></tr></thead><tbody>' + fx.map(function (r) { return '<tr><td>' + esc(r.name) + '</td><td>' + esc(A.byFeat[r.name] || '') + '</td><td class="n">' + r.n + '</td><td class="n">' + f1(r.dist) + '</td>' + r.d.map(function (v) { return '<td class="n">' + f1(v) + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table>');
    else h.push('<div class="mut">Касания всех элементов лежат у номиналов.</div>');
    h.push('<div class="mut" style="margin-top:6px;line-height:1.35">Почему в PC-DMIS базы «на модели»: там CAD и программа в одних координатах — номиналы элементов и модель записаны от начала CAD, а измеренная СК (BS_MAN …) только связывает их с машиной. ' +
      'У нас модель STL/STEP может быть экспортирована от другого начала (например, от начала СК детали), тогда всё «в стороне». «Привязать модель» подбирает перенос модели по касаниям программы: проверяет текущее положение, центр, начала всех СК (±) и уточняет методом ближайших точек. ' +
      'Касания ручных баз (ПЛОСК_…_MAN под ЗАПУСК) PC-DMIS хранит в координатах машины — они переносятся к номиналу (их подвод и время в прогоне тоже).</div>');
    if (UI.msg) h.push('<div style="white-space:pre-line;color:#06c;margin-top:4px">' + esc(UI.msg) + '</div>');
    return h.join('');
  }
  function render() { if (!UI.w) return; UI.w.body.innerHTML = body(); [].forEach.call(UI.w.body.querySelectorAll('[data-o]'), function (c) { c.onchange = function () { setOpt(c.getAttribute('data-o'), c.checked); G3.sig = ''; if (c.getAttribute('data-o') === 'fix') applyFix(true); build3(); render(); }; }); }
  function open() {
    var a = api(); if (!a) return; if (UI.w) { try { UI.w.close(); } catch (e) {} }
    var w = a.win('p73bases', 'Базы и системы координат (СК)', 'feat', 860); w.el.classList.add('p68'); UI.w = w; UI.msg = '';
    var cl = w.close; w.close = function () { UI.w = null; return cl.apply(w, arguments); };
    render(); G3.sig = ''; build3();
    w.foot.innerHTML = ''; w.foot.style.cssText = 'display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end;padding:6px 10px';
    w.foot.appendChild(a.btn('Привязать модель к программе', function () {
      UI.msg = 'Подбор…'; render();
      if (W.pcdPos) { setTimeout(function () { var F = null; try { F = W.pcdPos.autoFit({ rot: true }); } catch (e) { F = { err: e.message }; } W.pcdPos.last.fit = F;
        if (F && F.best && !F.err && F.best.s.f >= 0.2) { W.pcdPos.applyFit(F.best); F.applied = 0; UI.msg = 'Модель привязана: ' + Math.round(F.best.s.f * 100) + '% касаний на поверхности, медиана ' + f3(F.best.s.med) + ' мм, ориентация ' + F.best.rotTxt + '. Подробно и варианты — вкладка 3D «Положение».'; }
        else UI.msg = (F && F.err) || 'Надёжного совпадения нет — модель не сдвинута.'; try { W.pcdPos.refresh(); } catch (e) {} render(); }, 20); return; }
      setTimeout(function () { var r = null; try { r = fitModel(); } catch (e) { console.warn('r73 fit', e); UI.msg = 'Ошибка подбора: ' + e.message; render(); return; } if (!r) { UI.msg = ''; render(); return; }
        var ok = r.n >= r.of * 0.25;
        if (ok && len(r.t) > 0.05) moveModel(r.t);
        UI.msg = (ok ? (len(r.t) > 0.05 ? 'Модель сдвинута на ' : 'Модель уже на месте, сдвиг ') + r.t.map(f3).join(', ') + ' мм (старт: ' + r.from.why + '). ' : 'Надёжного совпадения нет — модель не сдвинута. ') + 'Касаний на поверхности модели: ' + r.n + ' из ' + r.of + ' (допуск ' + f1(r.tol) + ' мм).\nВарианты: ' + r.cand.slice(0, 5).map(function (c) { return c.why + ' — ' + c.n; }).join('; ');
        render(); }, 20); }, 'def'));
    w.foot.appendChild(a.btn('Модель от начала СК…', function () { var A = aligns().list.filter(function (x) { return x.Ot && len(x.Ot) > 1e-3; }); if (!A.length) { toast('Нет СК с ненулевым началом'); return; } var nm = prompt('Сдвинуть модель на начало СК (модель экспортирована от начала этой СК). Имя СК: ' + A.map(function (x) { return x.name; }).join(', '), A[0].name); var al = A.filter(function (x) { return x.name === nm; })[0]; if (!al) return; moveModel(al.Ot); UI.msg = 'Модель сдвинута на ' + al.Ot.map(f3).join(', '); render(); }));
    w.foot.appendChild(a.btn('Отменить сдвиг', function () { var st = stlT(), ap = G('applyStlTransform'); if (!UNDO || !st) { toast('Нечего отменять'); return; } st.x = UNDO.x; st.y = UNDO.y; st.z = UNDO.z; UNDO = null; ap(); setFields(); UI.msg = 'Положение модели возвращено'; render(); }));
    w.foot.appendChild(a.btn('Закрыть', function () { w.close(); }));
  }
  function menu() {
    var mi = document.getElementById('p68Mi'); if (!mi) return false; var sb = mi.querySelector('.sub'); if (!sb) return false; if (document.getElementById('p73basesIt')) return true;
    var s = document.createElement('span'); s.className = 'si'; s.id = 'p73basesIt'; s.textContent = 'Базы и системы координат (СК), привязка модели…';
    s.addEventListener('click', function (e) { e.stopPropagation(); [].forEach.call(document.querySelectorAll('.mi.open'), function (y) { y.classList.remove('open'); }); open(); });
    var ref = document.getElementById('p73uccIt'); sb.insertBefore(s, ref ? ref.nextSibling : sb.firstChild); return true;
  }
  var lastAt = 0, n = 0;
  setInterval(function () {
    if (n < 80) { n++; menu(); }
    var p7 = P7(), L = p7 && p7.last; if (!L) return;
    if (L.at && L.at !== lastAt && elsWithHits().length) { lastAt = L.at; try { aligns(); applyFix(); G3.sig = ''; build3(); if (UI.w) render(); } catch (e) { console.warn('r73 bases', e); } }
    else if (G3.grp) sync3(); else if (L.at && (opt().show || opt().base)) build3();
  }, 700);
  (function raf() { try { if (G3.grp) sync3(); } catch (e) {} requestAnimationFrame(raf); })();
  W.pcdBases = { aligns: aligns, applyFix: applyFix, fix: FIX, fitModel: fitModel, moveModel: moveModel, open: open, build3: build3, opt: opt, setOpt: setOpt };
})();
