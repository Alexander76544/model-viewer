/* r73 · pcdmis-view2-r73.js — функциональные улучшения панелей «Вид»:
   Вид и цвета (стиль, прозрачность, цвет, фон) · Отображение 3D (подписи: размер, без наложений, лимит)
   Свет (пресеты) · Замеры (CSV, расстояние между элементами) · Массы (STL: объём/площадь/ЦТ)
   Ракурсы (слайд-шоу, экспорт/импорт) · Сечение (точная позиция, через элемент, прокрутка, контур, площадь, SVG/DXF). */
(function () {
  'use strict';
  var W = window, KEY = 'pcd73.view2';
  function T() { return W.THREE; }
  function G(n) { try { return (0, eval)(n); } catch (e) { return undefined; } } // eslint-disable-line no-eval
  function $(id) { return document.getElementById(id); }
  function call(n) { var f = G(n); if (typeof f === 'function') { try { return f.apply(null, [].slice.call(arguments, 1)); } catch (e) { console.warn('r73v2 ' + n, e); } } }
  function ls(v) { try { if (v === undefined) return JSON.parse(localStorage.getItem(KEY) || 'null'); localStorage.setItem(KEY, JSON.stringify(v)); } catch (e) { return null; } }
  var O = Object.assign({ bg: 'grad', lblScale: 100, declutter: true, lblMax: 0, contour: true, step: 1 }, ls() || {});
  function save() { ls(O); }
  function toast(m) { var a = W.__p57api; if (a && a.toast) a.toast(m); }
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function f1(v) { return (Math.round(v * 10) / 10).toFixed(1); }
  function f3(v) { return (Math.round(v * 1000) / 1000).toFixed(3); }
  function PM() { var p = W.pcdProbe73 || W.pcdProbe72; return p && p.progMatrix ? p.progMatrix() : new (T().Matrix4)(); }
  function w2p(v) { return v.clone().applyMatrix4(PM().clone().invert()); }
  function p2w(v) { return v.clone().applyMatrix4(PM()); }
  function mesh() { return G('stlMesh3'); }
  function modelMeshes() { var m = mesh(), a = []; if (!m) return a; m.traverse(function (o) { if (o.isMesh && o.geometry && o.geometry.attributes.position && o.material && !o.userData.isEdge3 && !o.userData.p73cap && o.userData.kind !== 'measure') a.push(o); }); return a; }
  function mats() { var r = call('modelMaterials3'); return Array.isArray(r) ? r : []; }
  function els() { var a = W.__p57api, s = a && a.S ? a.S() : null; return (s && s.elements) || []; }
  function download(name, text, mime) { var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: mime || 'text/plain;charset=utf-8' })); a.download = name; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 800); }
  function baseName() { return (($('stlFileName') || {}).textContent || 'model').replace(/\.(stl|stp|step|obj|igs|iges)$/i, '').trim() || 'model'; }
  function h(tag, attrs, html) { var e = document.createElement(tag); if (attrs) for (var k in attrs) { if (k === 'style') e.style.cssText = attrs[k]; else e.setAttribute(k, attrs[k]); } if (html != null) e.innerHTML = html; return e; }
  function secEl(t) { return h('div', { class: 'ap2Sec' }, t); }
  function btn(lbl, fn, title, cls) { var b = h('button', { class: 'btn btn-mini' + (cls ? ' ' + cls : ''), type: 'button', title: title || '' }, lbl); b.addEventListener('click', fn); return b; }
  function rowEl() { return h('div', { style: 'display:flex;gap:6px;align-items:center;flex-wrap:wrap' }); }
  function body(id) { return document.querySelector('#' + id + ' .ap2-body'); }
  var HINT = 'font-size:11px;color:#8a99ad;line-height:1.5';

  /* =========================== 1. ВИД И ЦВЕТА =========================== */
  function styleNow() { var e = $('edgesBtn'), x = $('xrayBtn'), m = mats()[0]; if (x && x.classList.contains('active')) return 'xray'; if (m && m.wireframe) return 'wire'; if (e && e.classList.contains('active')) return 'edges'; return 'shade'; }
  function setStyle(s) {
    var e = $('edgesBtn'), x = $('xrayBtn');
    if (x && x.classList.contains('active') !== (s === 'xray')) x.click();
    if (e && !e.disabled && e.classList.contains('active') !== (s === 'edges')) e.click();
    mats().forEach(function (m) { m.wireframe = s === 'wire'; m.needsUpdate = true; });
    syncStyle();
  }
  function syncStyle() { var s = styleNow(); document.querySelectorAll('#p73look [data-st]').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-st') === s); }); var op = $('stlOpacity'), mo = $('p73op'), mv = $('p73opV'); if (op && mo && document.activeElement !== mo) { mo.value = op.value; if (mv) mv.textContent = Math.round(op.value * 100) + '%'; } }
  var BGS = { grad: ['Градиент', null], dark: ['Тёмный', 0x11161d], grey: ['Серый', 0xbfc4ca], white: ['Белый (для отчёта)', 0xffffff] };
  function applyBg() { var sc = G('scene3'); if (!sc) return; var b = BGS[O.bg]; try { var want = (!b || b[1] == null) ? null : '0'; if (want === '0' && localStorage.getItem('p60.bg') !== '0') { localStorage.setItem('p60.bg', '0'); O.p60bg = 1; save(); } else if (want === null && O.p60bg) { localStorage.setItem('p60.bg', '1'); O.p60bg = 0; save(); } } catch (e) {} if (!b || b[1] == null) { if (sc.background && sc.background.isColor && [0x11161d, 0xbfc4ca, 0xffffff].indexOf(sc.background.getHex()) >= 0) { sc.background = null; if (W.pcdEnsureSceneBg) W.pcdEnsureSceneBg(); } return; } if (!sc.background || !sc.background.isColor || sc.background.getHex() !== b[1]) sc.background = new (T().Color)(b[1]); }
  function setColor(hex, solid) {
    modelMeshes().forEach(function (o) { (Array.isArray(o.material) ? o.material : [o.material]).forEach(function (m) {
      if (!m.userData.p73orig) m.userData.p73orig = { c: m.color ? m.color.getHex() : null, vc: !!m.vertexColors };
      if (hex == null) { if (m.color && m.userData.p73orig.c != null) m.color.setHex(m.userData.p73orig.c); m.vertexColors = m.userData.p73orig.vc; }
      else { if (m.vertexColors && !solid) return; m.vertexColors = false; if (m.color) m.color.set(hex); }
      m.needsUpdate = true; }); });
  }
  function uiLook() {
    var b = body('apAppearance'); if (!b || $('p73look')) return !!b;
    var d = h('div', { id: 'p73look', style: 'display:flex;flex-direction:column;gap:7px' });
    d.appendChild(secEl('🖌 Стиль модели'));
    var seg = h('div', { class: 'seg2', role: 'group' });
    [['shade', '◼ Тонир.'], ['edges', '▣ С рёбрами'], ['wire', '▦ Каркас'], ['xray', '◌ Рентген']].forEach(function (s) { var x = h('button', { class: 'seg2b', type: 'button', 'data-st': s[0] }, s[1]); x.addEventListener('click', function () { setStyle(s[0]); }); seg.appendChild(x); });
    d.appendChild(seg);
    var r1 = h('label', { class: 'checkbox-row', style: 'gap:6px' }, '<span style="min-width:92px">Прозрачность</span><input type="range" id="p73op" min="0.05" max="1" step="0.01" style="flex:1;min-width:60px"><span id="p73opV" style="min-width:36px">—</span>');
    d.appendChild(r1);
    var r2 = h('div', { style: 'display:flex;gap:6px;align-items:center;flex-wrap:wrap' }, '<span style="min-width:92px">Цвет модели</span><input type="color" id="p73col" value="#94a3b8" style="width:38px;height:24px;padding:0;border:1px solid #c4c9d0;border-radius:4px"><label class="checkbox-row" style="gap:4px" title="Для цветных STEP/STL: заменить исходные цвета одним цветом"><input type="checkbox" id="p73colSolid"> однотонно</label>');
    r2.appendChild(btn('Исходный', function () { setColor(null); }, 'Вернуть исходный цвет модели'));
    d.appendChild(r2);
    var r3 = h('label', { class: 'checkbox-row', style: 'gap:6px' }, '<span style="min-width:92px">Фон сцены</span><select id="p73bg" style="flex:1">' + Object.keys(BGS).map(function (k) { return '<option value="' + k + '"' + (O.bg === k ? ' selected' : '') + '>' + BGS[k][0] + '</option>'; }).join('') + '</select>');
    d.appendChild(r3);
    var first = b.querySelector('.ap2Sec'); b.insertBefore(d, first || b.firstChild);
    $('p73op').addEventListener('input', function (e) { var op = $('stlOpacity'); if (op) { op.value = e.target.value; op.dispatchEvent(new Event('input', { bubbles: true })); } else call('setModelOpacity3', +e.target.value); $('p73opV').textContent = Math.round(e.target.value * 100) + '%'; });
    $('p73col').addEventListener('input', function (e) { setColor(e.target.value, $('p73colSolid').checked); });
    $('p73colSolid').addEventListener('change', function () { setColor($('p73col').value, $('p73colSolid').checked); });
    $('p73bg').addEventListener('change', function (e) { O.bg = e.target.value; save(); applyBg(); });
    ['edgesBtn', 'xrayBtn'].forEach(function (id) { var x = $(id); if (x) x.addEventListener('click', function () { setTimeout(syncStyle, 50); }); });
    syncStyle(); return true;
  }

  /* =========================== 2. СВЕТ: пресеты =========================== */
  var LP = { studio: ['☀ Студия', { head: 0.30, amb: 0.20, dir: [0.6, 1.2, 0.5] }], soft: ['☁ Мягкий', { head: 0.55, amb: 0.55, dir: [0.3, 1.5, 0.4] }],
    contrast: ['◑ Контраст', { head: 0.10, amb: 0.06, dir: [1.4, 0.7, 0.2] }], top: ['⬇ Сверху (цех)', { head: 0.25, amb: 0.30, dir: [0.05, 2, 0.05] }], inside: ['🔦 Полости', { head: 0.80, amb: 0.45, dir: [0.2, 0.4, 1.4] }] };
  function uiLight() {
    var b = body('apLight'); if (!b || $('p73lp')) return !!b;
    var d = h('div', { id: 'p73lp', style: 'display:flex;flex-direction:column;gap:6px' }); d.appendChild(secEl('Пресеты освещения'));
    var r = h('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:5px' });
    Object.keys(LP).forEach(function (k) { r.appendChild(btn(LP[k][0], function () { var L = G('light3'); if (!L) return; L.head = LP[k][1].head; L.amb = LP[k][1].amb; L.dir = LP[k][1].dir.slice(); call('syncLightUI3'); call('applyLight3'); call('scheduleModelMetaAutosave'); toast('Свет: ' + LP[k][0]); })); });
    d.appendChild(r); d.appendChild(h('div', { style: HINT }, '«Полости» — свет из камеры сильнее: внутренние каналы и отверстия видны лучше. Тонкая настройка — ползунки ниже.'));
    b.insertBefore(d, b.firstChild); return true;
  }

  /* =========================== 3. ПОДПИСИ: размер, без наложений, лимит =========================== */
  var LB = { last: '', t: 0, hidden: [] };
  var PRIO = { label: 0, tolerance: 1, p59: 2 };
  function lblGroup() { var f = G('nvProgramElementsRef'); try { return typeof f === 'function' ? f() : null; } catch (e) { return null; } }
  function visChain(o) { while (o) { if (!o.visible) return false; o = o.parent; } return true; }
  function labelsTick() {
    var g = lblGroup(), cam = G('camera3'), r = G('renderer3'); if (!g || !cam || !r) return;
    var sprites = []; g.traverse(function (o) { if (o.isSprite) sprites.push(o); });
    var k = O.lblScale / 100;
    sprites.forEach(function (s) { var u = s.userData; if (u.p73last === undefined || Math.abs(s.scale.x - u.p73last) > 1e-9) { u.p73bx = s.scale.x; u.p73by = s.scale.y; } s.scale.x = u.p73bx * k; s.scale.y = u.p73by * k; u.p73last = s.scale.x; });
    var sig = cam.matrixWorld.elements.map(function (v) { return v.toFixed(3); }).join() + sprites.length + ':' + O.declutter + O.lblMax + k + r.domElement.width;
    if (sig === LB.last) return; LB.last = sig;
    sprites.forEach(function (s) { if (s.userData.p73hid) { s.layers.set(0); s.userData.p73hid = false; } });
    if (!O.declutter && !O.lblMax) return;
    var Wd = r.domElement.clientWidth, Ht = r.domElement.clientHeight, P11 = cam.projectionMatrix.elements[5], V = new (T().Vector3)(), M = cam.matrixWorldInverse;
    var cand = [];
    sprites.forEach(function (s) { if (!visChain(s)) return; s.getWorldPosition(V); var z = -V.clone().applyMatrix4(M).z; if (z <= 0) return; V.project(cam); if (Math.abs(V.x) > 1.2 || Math.abs(V.y) > 1.2) return;
      var ws = new (T().Vector3)(); s.getWorldScale(ws); var att = s.material.sizeAttenuation !== false, hp = ws.y * P11 / (att ? z : 1) * Ht / 2, wp = ws.x * P11 / (att ? z : 1) * Ht / 2;
      var cx = (V.x + 1) / 2 * Wd, cy = (1 - V.y) / 2 * Ht, c = s.center || { x: 0.5, y: 0.5 };
      cand.push({ s: s, x0: cx - wp * c.x, x1: cx + wp * (1 - c.x), y0: cy - hp * (1 - c.y), y1: cy + hp * c.y, p: (PRIO[s.userData.kind] != null ? PRIO[s.userData.kind] : 1), d: Math.abs(V.x) + Math.abs(V.y) }); });
    cand.sort(function (a, b) { return a.p - b.p || a.d - b.d; });
    var placed = [], CS = 80, grid = new Map(), shown = 0;
    cand.forEach(function (c) {
      var hide = O.lblMax && shown >= O.lblMax;
      if (!hide && O.declutter) { var gx0 = Math.floor(c.x0 / CS), gx1 = Math.floor(c.x1 / CS), gy0 = Math.floor(c.y0 / CS), gy1 = Math.floor(c.y1 / CS);
        for (var gx = gx0; gx <= gx1 && !hide; gx++) for (var gy = gy0; gy <= gy1 && !hide; gy++) { var a = grid.get(gx + ',' + gy); if (a) for (var i = 0; i < a.length; i++) { var q = a[i]; if (c.x0 < q.x1 - 2 && c.x1 > q.x0 + 2 && c.y0 < q.y1 - 2 && c.y1 > q.y0 + 2) { hide = true; break; } } }
        if (!hide) for (var gx2 = gx0; gx2 <= gx1; gx2++) for (var gy2 = gy0; gy2 <= gy1; gy2++) { var kk = gx2 + ',' + gy2, b = grid.get(kk); if (!b) grid.set(kk, b = []); b.push(c); } }
      if (hide) { c.s.layers.set(31); c.s.userData.p73hid = true; } else shown++;
    });
    LB.stat = shown + ' из ' + cand.length; var st = $('p73lblSt'); if (st) st.textContent = 'на экране: ' + LB.stat;
  }
  function uiLabels() {
    var b = body('apView3d'); if (!b || $('p73lbl')) return !!b;
    var d = h('div', { id: 'p73lbl', style: 'display:flex;flex-direction:column;gap:6px' });
    d.appendChild(secEl('🏷 Подписи на модели'));
    d.appendChild(h('label', { class: 'checkbox-row', style: 'gap:6px' }, '<span style="min-width:86px">Размер</span><input type="range" id="p73lblSc" min="40" max="200" step="5" value="' + O.lblScale + '" style="flex:1;min-width:60px"><span id="p73lblScV" style="min-width:38px">' + O.lblScale + '%</span>'));
    d.appendChild(h('label', { class: 'checkbox-row', style: 'gap:6px', title: 'Подписи, которые перекрывают друг друга, временно скрываются (сначала остаются имена, затем допуски). При повороте/зуме пересчитывается.' }, '<input type="checkbox" id="p73lblDc"' + (O.declutter ? ' checked' : '') + '> Убирать наложения подписей'));
    d.appendChild(h('label', { class: 'checkbox-row', style: 'gap:6px' }, '<span style="min-width:86px">Не больше</span><select id="p73lblMax" style="flex:1">' + [0, 20, 50, 100, 200].map(function (v) { return '<option value="' + v + '"' + (+O.lblMax === v ? ' selected' : '') + '>' + (v ? v + ' подписей' : 'без ограничения') + '</option>'; }).join('') + '</select>'));
    d.appendChild(h('div', { style: HINT, id: 'p73lblSt' }, '—'));
    var g2 = $('view3dGroup1'); if (g2 && g2.parentNode === b) b.insertBefore(d, g2); else b.appendChild(d);
    $('p73lblSc').addEventListener('input', function (e) { O.lblScale = +e.target.value; $('p73lblScV').textContent = O.lblScale + '%'; save(); LB.last = ''; });
    $('p73lblDc').addEventListener('change', function (e) { O.declutter = e.target.checked; save(); LB.last = ''; });
    $('p73lblMax').addEventListener('change', function (e) { O.lblMax = +e.target.value; save(); LB.last = ''; });
    return true;
  }

  /* =========================== 4. ЗАМЕРЫ: CSV + расстояние между элементами =========================== */
  function measRows() {
    var M = G('measures3') || [], V = T().Vector3, rows = [['№', 'A.X', 'A.Y', 'A.Z', 'B.X', 'B.Y', 'B.Z', 'Длина', 'ΔX', 'ΔY', 'ΔZ']];
    M.forEach(function (m, i) { if (!m || !m.a || !m.b) return; var a = w2p(new V(m.a[0], m.a[1], m.a[2])), b = w2p(new V(m.b[0], m.b[1], m.b[2])), d = b.clone().sub(a);
      rows.push([i + 1, f3(a.x), f3(a.y), f3(a.z), f3(b.x), f3(b.y), f3(b.z), f3(d.length()), f3(d.x), f3(d.y), f3(d.z)]); });
    return rows;
  }
  function elOpts(filter) { return els().filter(function (e) { return isFinite(parseFloat(e.x)) && (!filter || filter(e)); }).map(function (e, i) { return '<option value="' + esc(e.id) + '">' + esc(e.name) + ' · ' + esc(e.type) + '</option>'; }).join(''); }
  function elById(id) { return els().find(function (e) { return String(e.id) === String(id); }); }
  function ev(e, k) { return [parseFloat(e[k[0]]) || 0, parseFloat(e[k[1]]) || 0, parseFloat(e[k[2]]) || 0]; }
  function uiMeasure() {
    var b = body('apMeasure'); if (!b || $('p73ms')) return !!b;
    var d = h('div', { id: 'p73ms', style: 'display:flex;flex-direction:column;gap:6px;border-top:1px solid var(--stroke);padding-top:8px' });
    d.appendChild(secEl('📋 Таблица замеров (координаты программы)'));
    var r = rowEl();
    r.appendChild(btn('Копировать', function () { var t = measRows().map(function (x) { return x.join('\t'); }).join('\n'); try { navigator.clipboard.writeText(t); toast('Замеры скопированы (' + (measRows().length - 1) + ')'); } catch (e) { prompt('Скопируйте:', t); } }));
    r.appendChild(btn('⬇ CSV', function () { var rows = measRows(); if (rows.length < 2) { toast('Замеров нет — включите «Линейку»'); return; } download(baseName() + ' — замеры.csv', '\ufeff' + rows.map(function (x) { return x.join(';'); }).join('\r\n'), 'text/csv;charset=utf-8'); }));
    d.appendChild(r);
    d.appendChild(secEl('↔ Между элементами программы'));
    d.appendChild(h('div', { style: 'display:grid;grid-template-columns:1fr;gap:4px' }, '<select id="p73mA"></select><select id="p73mB"></select>'));
    var r2 = rowEl(); r2.appendChild(btn('Измерить', function () { calcEl(); }, 'Расстояние между центрами, проекции и угол между осями (номинал)')); r2.appendChild(btn('Обновить список', function () { fillEl(); })); d.appendChild(r2);
    d.appendChild(h('div', { id: 'p73mR', style: 'font:11.5px Consolas,monospace;line-height:1.55;white-space:pre-wrap' }, ''));
    b.appendChild(d); fillEl(); return true;
  }
  function fillEl() { var o = elOpts(); ['p73mA', 'p73mB'].forEach(function (id, i) { var s = $(id); if (!s) return; var v = s.value; s.innerHTML = o; if (v) s.value = v; if (s.selectedIndex < 0 || !v) s.selectedIndex = s.options.length > i ? i : 0; }); }
  function calcEl() {
    var a = elById(($('p73mA') || {}).value), b = elById(($('p73mB') || {}).value), out = $('p73mR'); if (!a || !b || !out) return;
    var pa = ev(a, ['x', 'y', 'z']), pb = ev(b, ['x', 'y', 'z']), d = [pb[0] - pa[0], pb[1] - pa[1], pb[2] - pa[2]], L = Math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
    var na = ev(a, ['i', 'j', 'k']), nb = ev(b, ['i', 'j', 'k']), la = Math.hypot.apply(null, na), lb = Math.hypot.apply(null, nb), txt = 'Расстояние  ' + f3(L) + ' мм\nΔX ' + f3(d[0]) + '   ΔY ' + f3(d[1]) + '   ΔZ ' + f3(d[2]) + '\nXY ' + f3(Math.hypot(d[0], d[1])) + '  XZ ' + f3(Math.hypot(d[0], d[2])) + '  YZ ' + f3(Math.hypot(d[1], d[2]));
    if (la > 1e-9 && lb > 1e-9) { var c = Math.abs((na[0] * nb[0] + na[1] * nb[1] + na[2] * nb[2]) / la / lb); txt += '\nУгол осей ' + f3(Math.acos(Math.min(1, c)) * 180 / Math.PI) + '°';
      var u = [na[0] / la, na[1] / la, na[2] / la], t = d[0] * u[0] + d[1] * u[1] + d[2] * u[2], perp = Math.sqrt(Math.max(0, L * L - t * t)); txt += '\nВдоль оси A ' + f3(t) + ' · поперёк ' + f3(perp); }
    if (a.diam && b.diam) txt += '\nØ ' + a.diam + ' / ' + b.diam + ' · зазор стенок ' + f3(L - (+a.diam + +b.diam) / 2);
    out.textContent = txt;
  }

  /* =========================== 5. МАССЫ ДЛЯ STL =========================== */
  var MS = { key: '', r: null };
  function stlMass() {
    var m = mesh(); if (!m) return null; var mm = modelMeshes(); if (!mm.length) return null;
    var key = mm.map(function (o) { return o.geometry.uuid; }).join(); if (MS.key === key && MS.r) return MS.r;
    var V = 0, A = 0, cx = 0, cy = 0, cz = 0, inv = new (T().Matrix4)().copy(m.matrixWorld).invert(), mn = [1e18, 1e18, 1e18], mx = [-1e18, -1e18, -1e18];
    m.updateMatrixWorld(true);
    mm.forEach(function (o) {
      var Mx = new (T().Matrix4)().multiplyMatrices(inv, o.matrixWorld), e = Mx.elements, P = o.geometry.attributes.position, I = o.geometry.index, n = I ? I.count : P.count, ar = P.array, ia = I ? I.array : null, st = P.itemSize || 3;
      function vx(i) { var x = ar[i * st], y = ar[i * st + 1], z = ar[i * st + 2]; return [e[0] * x + e[4] * y + e[8] * z + e[12], e[1] * x + e[5] * y + e[9] * z + e[13], e[2] * x + e[6] * y + e[10] * z + e[14]]; }
      for (var t = 0; t + 2 < n; t += 3) { var a = vx(ia ? ia[t] : t), b = vx(ia ? ia[t + 1] : t + 1), c = vx(ia ? ia[t + 2] : t + 2);
        var v6 = a[0] * (b[1] * c[2] - b[2] * c[1]) - a[1] * (b[0] * c[2] - b[2] * c[0]) + a[2] * (b[0] * c[1] - b[1] * c[0]); V += v6; cx += v6 * (a[0] + b[0] + c[0]); cy += v6 * (a[1] + b[1] + c[1]); cz += v6 * (a[2] + b[2] + c[2]);
        var ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], wx = c[0] - a[0], wy = c[1] - a[1], wz = c[2] - a[2], qx = uy * wz - uz * wy, qy = uz * wx - ux * wz, qz = ux * wy - uy * wx; A += Math.sqrt(qx * qx + qy * qy + qz * qz) / 2;
        for (var k = 0; k < 3; k++) { var p = k === 0 ? a : k === 1 ? b : c; for (var j = 0; j < 3; j++) { if (p[j] < mn[j]) mn[j] = p[j]; if (p[j] > mx[j]) mx[j] = p[j]; } } }
    });
    if (Math.abs(V) < 1e-9) return null; var cl = [cx / (4 * V), cy / (4 * V), cz / (4 * V)]; V = Math.abs(V) / 6;
    MS.key = key; MS.r = { vol: V, area: A, cmL: cl, mn: mn, mx: mx }; return MS.r;
  }
  function hookMass() {
    var t0 = W.massTotals3, r0 = W.renderMassList3; if (typeof t0 !== 'function' || typeof r0 !== 'function' || t0.__p73) return typeof t0 === 'function';
    var T1 = function () { var sb = G('stepBodies3'); if (sb && sb.length) return t0.apply(this, arguments); var r = stlMass(); if (!r) return t0.apply(this, arguments); var dn = +G('densDef3') || 7.85, g = r.vol * 1e-3 * dn; return { g: g, n: 1, noV: 0, cg: [r.cmL[0], r.cmL[2], r.cmL[1]] }; };
    T1.__p73 = true; W.massTotals3 = T1;
    var R1 = function () { var sb = G('stepBodies3'); if (sb && sb.length) return r0.apply(this, arguments); var el = $('massTotal'), box = $('massList'); if (!el) return; var r = stlMass(); if (!r) { el.textContent = 'Модель не загружена'; if (box) box.innerHTML = ''; return; }
      var dn = +G('densDef3') || 7.85, g = r.vol * 1e-3 * dn, cw = mesh().localToWorld(new (T().Vector3)(r.cmL[0], r.cmL[1], r.cmL[2])), cp = w2p(cw), fm = G('fmtMass3');
      el.innerHTML = 'Модель: <span style="color:#facc15">' + (typeof fm === 'function' ? fm(g) : g.toFixed(1) + ' г') + '</span> <span style="font-size:11px;color:#8a99ad">(STL, плотность ' + dn + ' г/см³)</span>';
      if (box) box.innerHTML = '<table style="width:100%;font-size:11.5px;border-collapse:collapse">' + [['Объём', (r.vol / 1000).toFixed(r.vol > 1e7 ? 0 : 2) + ' см³'], ['Площадь поверхности', (r.area / 100).toFixed(1) + ' см²'], ['ЦТ X / Y / Z (программа)', f1(cp.x) + ' / ' + f1(cp.y) + ' / ' + f1(cp.z) + ' мм'], ['Габарит', [r.mx[0] - r.mn[0], r.mx[2] - r.mn[2], r.mx[1] - r.mn[1]].map(function (v) { return Math.round(v); }).join(' × ') + ' мм']].map(function (x) { return '<tr><td style="padding:2px 4px;color:#6b7280">' + x[0] + '</td><td style="padding:2px 4px;text-align:right;font-family:Consolas,monospace">' + x[1] + '</td></tr>'; }).join('') + '</table><div style="' + HINT + ';margin-top:4px">Объём и ЦТ верны для замкнутой сетки (без дыр). Плотность — список выше.</div>';
      call('updateMassCg3'); };
    R1.__p73 = true; W.renderMassList3 = R1; return true;
  }

  /* =========================== 6. РАКУРСЫ: слайд-шоу, экспорт/импорт =========================== */
  var SHOW = { t: null, i: 0 };
  function uiViews() {
    var b = body('apViews'); if (!b || $('p73vw')) return !!b;
    var d = h('div', { id: 'p73vw', style: 'display:flex;flex-direction:column;gap:6px;border-top:1px solid var(--stroke);padding-top:8px' });
    var r = rowEl();
    var sb = btn('▶ Слайд-шоу', function () { if (SHOW.t) { clearInterval(SHOW.t); SHOW.t = null; sb.textContent = '▶ Слайд-шоу'; return; } var v = G('views3') || []; if (!v.length) { toast('Сначала сохраните ракурсы (+)'); return; } SHOW.i = 0; var go = function () { var vv = G('views3') || []; if (!vv.length) return; call('flyToCam3', vv[SHOW.i % vv.length].cam); SHOW.i++; }; go(); SHOW.t = setInterval(go, 2600); sb.textContent = '⏹ Стоп'; }, 'Перелёт по сохранённым ракурсам по кругу');
    r.appendChild(sb);
    r.appendChild(btn('⬇ Экспорт', function () { var v = G('views3') || []; download(baseName() + ' — ракурсы.json', JSON.stringify({ kind: 'pcd73.views', views: v }, null, 1), 'application/json'); }));
    var fi = h('input', { type: 'file', accept: '.json', style: 'display:none' }); fi.addEventListener('change', function () { var f = fi.files[0]; if (!f) return; f.text().then(function (t) { try { var j = JSON.parse(t), arr = Array.isArray(j) ? j : j.views; if (!Array.isArray(arr)) throw 0; var v = G('views3'); arr.forEach(function (x) { if (x && x.cam) v.push(x); }); call('renderViews3'); call('scheduleModelMetaAutosave'); toast('Ракурсов добавлено: ' + arr.length); } catch (e) { toast('Не тот файл ракурсов'); } fi.value = ''; }); });
    r.appendChild(btn('⬆ Импорт', function () { fi.click(); })); r.appendChild(fi);
    d.appendChild(r); d.appendChild(h('div', { style: HINT }, 'Слайд-шоу — для показа детали/обсуждения; ракурсы можно передать коллеге файлом .json.'));
    b.appendChild(d); return true;
  }

  /* =========================== 7. СЕЧЕНИЕ: точная позиция, через элемент, прокрутка, контур =========================== */
  var CS = { sig: '', obj: null, stat: null, segs: null, t: 0, sweep: null };
  function cs3() { return G('clipState3'); }
  function curPlanes() { var m = mats(); for (var i = 0; i < m.length; i++) if (m[i].clippingPlanes && m[i].clippingPlanes.length) return m[i].clippingPlanes; return null; }
  var WA = { x: 'x', y: 'z', z: 'y' };
  function slabInfo() { var m = mesh(), c = cs3(); if (!m || !c) return null; var b = new (T().Box3)().setFromObject(m); if (b.isEmpty()) return null; var w = WA[c.axis || 'x']; return { mn: b.min[w], sp: (b.max[w] - b.min[w]) || 1 }; }
  function curMm() { var c = cs3(); if (!c) return 0; if (c.mode === 'free') return (c.free && c.free.off) || 0; if (c.mode === 'plane') return (c.plane && c.plane.off) || 0; var s = slabInfo(); return s ? s.mn + s.sp * c.pos : 0; }
  function setMm(v) {
    var c = cs3(); if (!c) return; if (!c.enabled) { c.enabled = true; var ce = $('clipEnableCb'); if (ce) ce.checked = true; }
    if (c.mode === 'free') { if (!c.free) return; c.free.off = v; call('syncFreeInputs3'); }
    else if (c.mode === 'plane') { if (!c.plane) c.plane = { idx: 0, off: 0, flip: false }; c.plane.off = v; call('syncClipPlaneInputs3'); }
    else if (c.mode === 'slab') { var s = slabInfo(); if (!s) return; c.pos = Math.max(0, Math.min(1, (v - s.mn) / s.sp)); var p = $('clipPos'); if (p) p.value = String(Math.round(c.pos * 100)); }
    else { toast('Точная позиция — для режимов Пласт / Плоск. STEP / произвольная'); return; }
    call('applyStlClipping'); call('scheduleModelMetaAutosave'); syncPos();
  }
  function syncPos() { var i = $('p73cpos'); if (i && document.activeElement !== i) i.value = f3(curMm()); }
  function cutThrough() {
    var e = elById(($('p73cEl') || {}).value), m = mesh(), c = cs3(); if (!e || !m || !c) { toast('Нет элемента или модели'); return; }
    var V = T().Vector3, o = p2w(new V(+e.x || 0, +e.y || 0, +e.z || 0)), ax = new V(+e.i || 0, +e.j || 0, +e.k || 0); if (ax.lengthSq() < 1e-12) ax.set(0, 0, 1); ax.normalize();
    var mode = ($('p73cOr') || {}).value || 'along', n;
    if (mode === 'across') n = ax.clone(); else { var ref = mode === 'alongH' ? new V(0, 0, 1) : (Math.abs(ax.z) > 0.9 ? new V(1, 0, 0) : new V(0, 0, 1)); if (mode === 'alongH') ref = Math.abs(ax.z) > 0.9 ? new V(0, 1, 0) : new V(0, 0, 1).cross(ax).normalize(); n = new V().crossVectors(ax, ref); if (n.lengthSq() < 1e-9) n = new V(1, 0, 0).cross(ax); n.normalize(); }
    var pmR = new (T().Matrix3)().setFromMatrix4(PM()), nW = n.clone().applyMatrix3(pmR).normalize();
    m.updateMatrixWorld(true); var inv = new (T().Matrix4)().copy(m.matrixWorld).invert(), oL = o.clone().applyMatrix4(inv), nL = nW.clone().transformDirection(inv);
    c.enabled = true; c.mode = 'free'; c.free = { o: [oL.x, oL.y, oL.z], n: [nL.x, nL.y, nL.z], off: 0, flip: false };
    var ce = $('clipEnableCb'); if (ce) ce.checked = true; call('syncClipModeUI3'); call('syncFreeInputs3'); call('applyStlClipping'); call('scheduleModelMetaAutosave'); syncPos();
    if (O.camCut !== false) setTimeout(function () { lookCut(o, Math.max(120, (parseFloat(e.d || e.diam || e.size) || 20) * 8)); }, 60);
    toast('Разрез через ' + e.name + (mode === 'across' ? ' (поперёк оси)' : ' (вдоль оси)'));
  }
  function cutPlaneW() { var m = mesh(); if (!m || !m.material) return null; var mt = Array.isArray(m.material) ? m.material[0] : m.material; var pl = mt && mt.clippingPlanes; if (!pl || !pl.length) { var r = G('renderer3'); pl = r && r.clippingPlanes; } return pl && pl.length ? pl[0] : null; }
  function lookCut(target, dist) {
    var pl = cutPlaneW(), V = T().Vector3; if (!pl) { toast('Сечение выключено'); return; }
    var tg = G('camTarget3'), t = target ? target.clone() : (tg ? new V(tg.x, tg.y, tg.z) : new V()); pl.projectPoint(t, t);
    var d = pl.normal.clone().negate().normalize(), phi = Math.min(Math.PI - 0.03, Math.max(0.03, Math.acos(Math.max(-1, Math.min(1, d.y))))), th = Math.atan2(d.x, d.z);
    var dist0 = G('camDist3'); call('flyToCam3', { tx: t.x, ty: t.y, tz: t.z, dist: dist || dist0 || 300, theta: th, phi: phi });
  }
  function sweep() {
    var b = $('p73cSw'); if (CS.sweep) { cancelAnimationFrame(CS.sweep.raf); CS.sweep = null; if (b) b.textContent = '▶ Прокрутка'; return; }
    var c = cs3(); if (!c) return; if (!c.enabled) { c.enabled = true; var ce = $('clipEnableCb'); if (ce) ce.checked = true; }
    if (c.mode !== 'slab' && c.mode !== 'free' && c.mode !== 'plane') { c.mode = 'slab'; call('syncClipModeUI3'); }
    var m = mesh(); if (!m) return; var bb = new (T().Box3)().setFromObject(m), R = bb.getSize(new (T().Vector3)()).length() / 2;
    var lo, hi; if (c.mode === 'slab') { var s = slabInfo(); lo = s.mn; hi = s.mn + s.sp; } else { var v0 = curMm(); lo = v0 - R; hi = v0 + R; }
    var t0 = performance.now(), dur = 9000; CS.sweep = {}; if (b) b.textContent = '⏹ Стоп';
    (function step() { if (!CS.sweep) return; var u = ((performance.now() - t0) % (2 * dur)) / dur, f = u <= 1 ? u : 2 - u; setMm(lo + (hi - lo) * f); CS.sweep.raf = requestAnimationFrame(step); })();
  }
  /* контур: пересечение треугольников с плоскостью */
  function contour(planes) {
    var TH = T(), out = [], mm = modelMeshes(); if (!mm.length) return null;
    planes.forEach(function (pl, pi) {
      var n = pl.normal, c0 = pl.constant, segs = [], others = planes.filter(function (q, j) { return j !== pi; });
      mm.forEach(function (o) {
        if (!o.visible) return; o.updateMatrixWorld(true); var e = o.matrixWorld.elements, P = o.geometry.attributes.position, I = o.geometry.index, cnt = I ? I.count : P.count, ar = P.array, ia = I ? I.array : null, st = P.itemSize || 3;
        var nl = P.count, D = new Float32Array(nl), X = new Float32Array(nl * 3);
        for (var i = 0; i < nl; i++) { var x = ar[i * st], y = ar[i * st + 1], z = ar[i * st + 2], wx = e[0] * x + e[4] * y + e[8] * z + e[12], wy = e[1] * x + e[5] * y + e[9] * z + e[13], wz = e[2] * x + e[6] * y + e[10] * z + e[14]; X[i * 3] = wx; X[i * 3 + 1] = wy; X[i * 3 + 2] = wz; D[i] = n.x * wx + n.y * wy + n.z * wz + c0; }
        for (var t = 0; t + 2 < cnt; t += 3) { var a = ia ? ia[t] : t, b = ia ? ia[t + 1] : t + 1, cc = ia ? ia[t + 2] : t + 2, da = D[a], db = D[b], dc = D[cc];
          if ((da > 0 && db > 0 && dc > 0) || (da < 0 && db < 0 && dc < 0)) continue;
          var pts = [], E = [[a, b, da, db], [b, cc, db, dc], [cc, a, dc, da]];
          for (var k = 0; k < 3; k++) { var q = E[k]; if ((q[2] > 0) !== (q[3] > 0) && q[2] !== q[3]) { var s = q[2] / (q[2] - q[3]); pts.push([X[q[0] * 3] + s * (X[q[1] * 3] - X[q[0] * 3]), X[q[0] * 3 + 1] + s * (X[q[1] * 3 + 1] - X[q[0] * 3 + 1]), X[q[0] * 3 + 2] + s * (X[q[1] * 3 + 2] - X[q[0] * 3 + 2])]); } }
          if (pts.length !== 2) continue;
          /* ориентация: (p2-p1)·(n × nTri) > 0 */
          var ux = X[b * 3] - X[a * 3], uy = X[b * 3 + 1] - X[a * 3 + 1], uz = X[b * 3 + 2] - X[a * 3 + 2], vx = X[cc * 3] - X[a * 3], vy = X[cc * 3 + 1] - X[a * 3 + 1], vz = X[cc * 3 + 2] - X[a * 3 + 2], tx = uy * vz - uz * vy, ty = uz * vx - ux * vz, tz = ux * vy - uy * vx;
          var ox = n.y * tz - n.z * ty, oy = n.z * tx - n.x * tz, oz = n.x * ty - n.y * tx, p1 = pts[0], p2 = pts[1];
          if ((p2[0] - p1[0]) * ox + (p2[1] - p1[1]) * oy + (p2[2] - p1[2]) * oz < 0) { var sw = p1; p1 = p2; p2 = sw; }
          var mx = (p1[0] + p2[0]) / 2, my = (p1[1] + p2[1]) / 2, mz = (p1[2] + p2[2]) / 2, ok = true;
          for (var j = 0; j < others.length; j++) if (others[j].normal.x * mx + others[j].normal.y * my + others[j].normal.z * mz + others[j].constant < 0) { ok = false; break; }
          if (ok) segs.push(p1[0], p1[1], p1[2], p2[0], p2[1], p2[2]); }
      });
      /* площадь (знаковая, дырки вычитаются), периметр, габарит в плоскости */
      var o0 = pl.coplanarPoint(new TH.Vector3()), A = 0, L = 0, nseg = segs.length / 6;
      for (var i2 = 0; i2 < segs.length; i2 += 6) { var ax = segs[i2] - o0.x, ay = segs[i2 + 1] - o0.y, az = segs[i2 + 2] - o0.z, bx = segs[i2 + 3] - o0.x, by = segs[i2 + 4] - o0.y, bz = segs[i2 + 5] - o0.z;
        A += 0.5 * ((ay * bz - az * by) * n.x + (az * bx - ax * bz) * n.y + (ax * by - ay * bx) * n.z); L += Math.hypot(bx - ax, by - ay, bz - az); }
      out.push({ plane: pl, segs: segs, area: Math.abs(A), per: L, n: nseg });
    });
    return out;
  }
  function dropContour() { var sc = G('scene3'); if (CS.obj) { if (sc) sc.remove(CS.obj); CS.obj.traverse(function (o) { if (o.geometry) o.geometry.dispose(); if (o.material) o.material.dispose(); }); CS.obj = null; } }
  function drawContour(res) {
    dropContour(); if (!O.contour || !res) return; var TH = T(), sc = G('scene3'); if (!sc) return; var g = new TH.Group(); g.userData.p73cap = true; g.name = 'p73contour';
    var m = mesh(), bb = new TH.Box3().setFromObject(m), eps = bb.getSize(new TH.Vector3()).length() * 2e-4;
    res.forEach(function (r, i) { if (!r.segs.length) return; var arr = new Float32Array(r.segs.length), n = r.plane.normal; for (var k = 0; k < r.segs.length; k += 3) { arr[k] = r.segs[k] - n.x * eps; arr[k + 1] = r.segs[k + 1] - n.y * eps; arr[k + 2] = r.segs[k + 2] - n.z * eps; }
      var geo = new TH.BufferGeometry(); geo.setAttribute('position', new TH.BufferAttribute(arr, 3));
      var others = res.filter(function (q, j) { return j !== i; }).map(function (q) { return q.plane; });
      var ln = new TH.LineSegments(geo, new TH.LineBasicMaterial({ color: 0xf97316, clippingPlanes: others.length ? others : null }));
      ln.renderOrder = 60; ln.raycast = function () {}; ln.frustumCulled = false; ln.userData.p73cap = true; g.add(ln); });
    sc.add(g); CS.obj = g;
  }
  function secStat() {
    var el = $('p73cSt'); if (!el) return; var R = CS.stat;
    if (!R || !R.length) { el.textContent = (cs3() && cs3().enabled) ? 'нет плоскостей разреза' : 'сечение выключено'; return; }
    el.innerHTML = R.map(function (r, i) { return (R.length > 1 ? 'Пл. ' + (i + 1) + ': ' : '') + 'площадь <b>' + (r.area >= 1e4 ? (r.area / 100).toFixed(1) + ' см²' : f1(r.area) + ' мм²') + '</b> · периметр ' + f1(r.per) + ' мм'; }).join('<br>');
  }
  function secTick() {
    var c = cs3(), pl = c && c.enabled ? curPlanes() : null, open = $('apClip') && $('apClip').classList.contains('open');
    var sig = pl ? pl.map(function (p) { return p.normal.toArray().map(function (v) { return v.toFixed(5); }).join() + '@' + p.constant.toFixed(3); }).join('|') + O.contour + modelMeshes().length : '';
    if (open) syncPos();
    if (sig === CS.sig) return; if (CS.sweep && performance.now() - CS.t < 120) return;
    CS.sig = sig; CS.t = performance.now();
    if (!pl || (!O.contour && !open)) { dropContour(); CS.stat = null; secStat(); return; }
    var res = contour(pl); CS.stat = res; drawContour(res); secStat();
  }
  function basis(n) { /* оси чертежа в координатах программы */
    var V = T().Vector3, np = n.clone().transformDirection(PM().clone().invert()), a = [Math.abs(np.x), Math.abs(np.y), Math.abs(np.z)], u, v;
    if (a[0] > 0.95) { u = new V(0, 1, 0); v = new V(0, 0, 1); } else if (a[1] > 0.95) { u = new V(1, 0, 0); v = new V(0, 0, 1); } else if (a[2] > 0.95) { u = new V(1, 0, 0); v = new V(0, 1, 0); }
    else { u = new V(0, 0, 1).cross(np); if (u.lengthSq() < 1e-6) u = new V(1, 0, 0); u.normalize(); v = new V().crossVectors(np, u).normalize(); }
    return { u: u, v: v };
  }
  function secExport(fmt) {
    var R = CS.stat; if (!R || !R.length || !R[0].segs.length) { toast('Нет сечения — включите «Сечение модели»'); return; }
    var r = R[0], B = basis(r.plane.normal), Mi = PM().clone().invert(), V = T().Vector3, L = [], mn = [1e18, 1e18], mx = [-1e18, -1e18];
    for (var i = 0; i < r.segs.length; i += 6) { var a = new V(r.segs[i], r.segs[i + 1], r.segs[i + 2]).applyMatrix4(Mi), b = new V(r.segs[i + 3], r.segs[i + 4], r.segs[i + 5]).applyMatrix4(Mi), s = [a.dot(B.u), a.dot(B.v), b.dot(B.u), b.dot(B.v)]; L.push(s);
      mn[0] = Math.min(mn[0], s[0], s[2]); mn[1] = Math.min(mn[1], s[1], s[3]); mx[0] = Math.max(mx[0], s[0], s[2]); mx[1] = Math.max(mx[1], s[1], s[3]); }
    var nm = baseName() + ' — сечение';
    if (fmt === 'dxf') { var d = ['0', 'SECTION', '2', 'ENTITIES']; L.forEach(function (s) { d.push('0', 'LINE', '8', 'SECTION', '10', s[0].toFixed(4), '20', s[1].toFixed(4), '30', '0', '11', s[2].toFixed(4), '21', s[3].toFixed(4), '31', '0'); }); d.push('0', 'ENDSEC', '0', 'EOF'); download(nm + '.dxf', d.join('\r\n'), 'application/dxf'); return; }
    var pad = 5, w = mx[0] - mn[0] + 2 * pad, ht = mx[1] - mn[1] + 2 * pad, path = L.map(function (s) { return 'M' + (s[0] - mn[0] + pad).toFixed(3) + ' ' + (mx[1] - s[1] + pad).toFixed(3) + 'L' + (s[2] - mn[0] + pad).toFixed(3) + ' ' + (mx[1] - s[3] + pad).toFixed(3); }).join('');
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + w.toFixed(2) + 'mm" height="' + ht.toFixed(2) + 'mm" viewBox="0 0 ' + w.toFixed(3) + ' ' + ht.toFixed(3) + '"><title>' + esc(nm) + '</title><path d="' + path + '" fill="none" stroke="#111" stroke-width="' + Math.max(0.1, Math.min(w, ht) / 600).toFixed(3) + '"/><text x="' + pad + '" y="' + (ht - 1).toFixed(2) + '" font-size="' + Math.max(2, ht / 40).toFixed(2) + '" fill="#555">Площадь ' + f1(r.area) + ' мм² · периметр ' + f1(r.per) + ' мм</text></svg>';
    download(nm + '.svg', svg, 'image/svg+xml');
  }
  function uiClip() {
    var b = body('apClip'); if (!b || $('p73cl')) return !!b;
    var d = h('div', { id: 'p73cl', style: 'border-top:1px solid var(--stroke);padding-top:9px;display:flex;flex-direction:column;gap:6px' });
    d.appendChild(secEl('🎯 Точная позиция плоскости'));
    var r = rowEl(); r.style.flexWrap = 'nowrap'; r.innerHTML = '<input type="number" id="p73cpos" step="0.1" style="flex:1;min-width:0" title="Положение плоскости, мм (Пласт — координата «до»; STEP/произвольная — отступ)"><span>мм</span>';
    r.appendChild(btn('−', function () { setMm(curMm() - +O.step); }, 'Сдвинуть на шаг назад')); r.appendChild(btn('+', function () { setMm(curMm() + +O.step); }, 'Сдвинуть на шаг вперёд'));
    d.appendChild(r);
    var rs = rowEl(); rs.style.flexWrap = 'nowrap'; rs.innerHTML = '<span style="min-width:92px">Шаг кнопок, мм</span><select id="p73cstep" style="flex:1">' + [0.01, 0.1, 0.5, 1, 5, 10, 50].map(function (v) { return '<option' + (+O.step === v ? ' selected' : '') + '>' + v + '</option>'; }).join('') + '</select>'; d.appendChild(rs);
    d.appendChild(secEl('⊕ Разрез через элемент программы'));
    d.appendChild(h('select', { id: 'p73cEl', style: 'width:100%' }));
    d.appendChild(h('select', { id: 'p73cOr', style: 'width:100%' }, '<option value="along">вдоль оси (профиль отверстия)</option><option value="alongH">вдоль оси, повернуть 90°</option><option value="across">поперёк оси</option>')); var r2 = rowEl(); r2.innerHTML = '<span style="display:none"></span>';
    r2.appendChild(btn('✂ Разрезать', cutThrough, 'Произвольная плоскость через центр элемента')); r2.appendChild(btn('Обновить', fillCutEl, 'Обновить список элементов')); d.appendChild(r2);
    var r2b = rowEl(); r2b.appendChild(h('label', { class: 'checkbox-row', style: 'gap:6px;flex:1', title: 'После «Разрезать» повернуть камеру перпендикулярно срезу' }, '<input type="checkbox" id="p73cCam"' + (O.camCut !== false ? ' checked' : '') + '> Камера')); r2b.appendChild(btn('👁 Смотреть на срез', function () { lookCut(null, 0); }, 'Повернуть камеру перпендикулярно плоскости сечения')); d.appendChild(r2b);
    d.appendChild(secEl('📏 Контур и площадь сечения'));
    d.appendChild(h('label', { class: 'checkbox-row', style: 'gap:6px' }, '<input type="checkbox" id="p73cCon"' + (O.contour ? ' checked' : '') + '> Контур среза (оранжевый)'));
    d.appendChild(h('div', { id: 'p73cSt', style: 'font-size:11.5px;line-height:1.55' }, '—'));
    var r3 = rowEl(); var sw = btn('▶ Прокрутка', sweep, 'Плавно провести плоскость через деталь туда-обратно'); sw.id = 'p73cSw'; r3.appendChild(sw);
    r3.appendChild(btn('⬇ SVG', function () { secExport('svg'); }, 'Контур сечения — чертёж SVG в мм (оси программы)')); r3.appendChild(btn('⬇ DXF', function () { secExport('dxf'); }, 'Контур сечения — DXF (LINE, мм)'));
    d.appendChild(r3);
    var cap = $('p73cap'); if (cap && cap.parentNode === b) b.insertBefore(d, cap); else { var ex = $('clipExportBtn'), an = ex ? ex.closest('div') : null; if (an && an.parentNode === b) b.insertBefore(d, an); else b.appendChild(d); }
    $('p73cpos').addEventListener('change', function (e) { var v = parseFloat(String(e.target.value).replace(',', '.')); if (isFinite(v)) setMm(v); });
    $('p73cstep').addEventListener('change', function (e) { O.step = +e.target.value; save(); });
    $('p73cCam').addEventListener('change', function (e) { O.camCut = e.target.checked; save(); });
    $('p73cCon').addEventListener('change', function (e) { O.contour = e.target.checked; save(); CS.sig = ''; });
    fillCutEl(); return true;
  }
  function fillCutEl() { var s = $('p73cEl'); if (!s) return; var v = s.value; s.innerHTML = elOpts(function (e) { return /cyl|circ|cone|sphere|slot|plane|point/i.test(e.type); }) || '<option value="">нет элементов программы</option>'; if (v) s.value = v; if (s.selectedIndex < 0) s.selectedIndex = 0; }

  /* =========================== запуск =========================== */
  function boot() {
    var ok = [uiLook(), uiLight(), uiLabels(), uiMeasure(), uiViews(), uiClip(), hookMass()];
    if (ok.indexOf(false) >= 0) return setTimeout(boot, 500);
    applyBg(); try { W.renderMassList3(); } catch (e) {}
  }
  boot();
  setInterval(function () { try { labelsTick(); } catch (e) {} }, 200);
  setInterval(function () { try { secTick(); } catch (e) { console.warn('r73v2 sec', e); } }, 250);
  var msig = ''; setInterval(function () { try { applyBg(); syncStyle(); var m = mesh(), s = (m ? m.uuid : '') + ':' + els().length + ':' + (els()[0] ? els()[0].id : ''); if (s !== msig) { msig = s; MS.key = ''; fillEl(); fillCutEl(); if (W.renderMassList3) W.renderMassList3(); } } catch (e) {} }, 1500);
  W.pcdView2 = { opt: O, setStyle: setStyle, setMm: setMm, curMm: curMm, cutThrough: cutThrough, lookCut: lookCut, contour: function () { return CS.stat; }, stlMass: stlMass, labelsTick: labelsTick, secExport: secExport, measRows: measRows, calcEl: calcEl };
})();
