/* r73 — вкладка «Положение» (apTransform) переделана: автопривязка модели к программе (24 ориентации × перенос +
   точная подгонка ICP точка-плоскость по касаниям .PRG), варианты для симметричных деталей, модель от начала СК,
   точная доводка шагами (сдвиг / поворот вокруг центра модели или нуля программы, в осях программы),
   карта отклонений касаний от модели (цвет) + худшие элементы, матрица положения (копировать / вставить), история отмен.
   Сюда же перенесены «Авто-совмещение по элементам (STEP)», «Точные пары», «Зеркало 3D» из «Элементы программы».
   Чистка дублей: старые «Точки касаний», «Траектория стилуса», «Симуляция», «Щуп (A/B + досягаемость)», «Машина (ход)»,
   «WCS», «Прогнать программу» / скорость / время — заменены кнопками новых инструментов (меню «Щуп»). */
(function () {
  'use strict';
  if (typeof document === 'undefined') return;
  var W = window, KEY = 'pcd73.pos';
  function P7() { return W.pcdProbe73 || W.pcdProbe72 || null; }
  function api() { return W.__p57api || null; }
  function G(n) { var a = api(); return a && a.G ? a.G(n) : W[n]; }
  function S() { var a = api(); return a && a.S ? a.S() : null; }
  function ls(k, v) { try { if (v === undefined) return JSON.parse(localStorage.getItem(k) || 'null'); localStorage.setItem(k, JSON.stringify(v)); } catch (e) { return null; } }
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function num(v, d) { var n = parseFloat(String(v == null ? '' : v).replace(',', '.')); return isFinite(n) ? n : (d === undefined ? 0 : d); }
  function toast(m) { var a = api(); if (a && a.toast) a.toast(m); else console.log(m); }
  function $(id) { return document.getElementById(id); }
  function r6(v) { var x = Math.round(v * 1e6) / 1e6; return Math.abs(x) < 1e-9 ? 0 : x; }
  function f2(v) { return (Math.round(v * 100) / 100).toFixed(2); }
  function f3(v) { return (Math.round(v * 1000) / 1000).toFixed(3); }
  function deg(r) { return r * 180 / Math.PI; }
  function opt() { var o = ls(KEY) || {}; return { step: o.step || 1, astep: o.astep || 90, pivot: o.pivot || 'center', rot: o.rot !== false, map: !!o.map }; }
  function setOpt(k, v) { var o = opt(); o[k] = v; ls(KEY, o); }

  /* ======================= преобразования ======================= */
  function TH() { return W.THREE; }
  function mesh() { return G('stlMesh3'); }
  function PM() { var p = P7(); return p && p.progMatrix ? p.progMatrix() : new (TH().Matrix4)(); }
  var UNDO = [], LAST = { fit: null };
  function snap() { var st = G('stlTransform'); return st ? { x: st.x, y: st.y, z: st.z, rx: st.rx, ry: st.ry, rz: st.rz } : null; }
  function setSnap(s) { var st = G('stlTransform'), ap = G('applyStlTransform'); if (!st || !s || typeof ap !== 'function') return; for (var k in s) st[k] = s[k]; ap(); after(); }
  function after() {
    setFields();
    try { var f = G('scheduleModelMetaAutosave'); if (typeof f === 'function') f(); } catch (e) {}
    try { var f2 = G('persistProjectTransform3'); if (typeof f2 === 'function') f2(); } catch (e) {}
    try { P7().resetKin(); } catch (e) {}
    GRID = null; if (opt().map) setTimeout(buildMap, 30); status();
  }
  function setFields() { var t = G('stlTransform'); if (!t) return; [['stlOffX', 'x'], ['stlOffY', 'y'], ['stlOffZ', 'z'], ['stlRotX', 'rx'], ['stlRotY', 'ry'], ['stlRotZ', 'rz']].forEach(function (p) { var el = $(p[0]); if (el) el.value = Math.round(t[p[1]] * 1e4) / 1e4; }); }
  /* A — Matrix4 в координатах программы: новая модель = A · текущая */
  function applyProg(A) {
    var T = TH(), m = mesh(), st = G('stlTransform'), ap = G('applyStlTransform'); if (!m || !st || typeof ap !== 'function') { toast('Сначала загрузите модель'); return false; }
    UNDO.push(snap()); if (UNDO.length > 30) UNDO.shift();
    var P = PM(), At = new T.Matrix4().multiplyMatrices(P, A).multiply(new T.Matrix4().copy(P).invert());
    var par = m.parent, Pw = new T.Matrix4(); if (par) { par.updateMatrixWorld(true); Pw.copy(par.matrixWorld); }
    var Al = new T.Matrix4().copy(Pw).invert().multiply(At).multiply(Pw);
    var pos = m.position.clone().applyMatrix4(Al), rq = new T.Quaternion().setFromRotationMatrix(new T.Matrix4().extractRotation(Al)), q = rq.multiply(m.quaternion.clone());
    var e = new T.Euler().setFromQuaternion(q, 'XYZ');
    st.x = r6(pos.x); st.y = r6(pos.z); st.z = r6(pos.y); st.rx = r6(deg(e.x)); st.rz = r6(deg(e.y)); st.ry = r6(deg(e.z));
    ap(); after(); return true;
  }
  function M4(R, t) { var T = TH(); return new T.Matrix4().set(R[0][0], R[0][1], R[0][2], t[0], R[1][0], R[1][1], R[1][2], t[1], R[2][0], R[2][1], R[2][2], t[2], 0, 0, 0, 1); }
  function rotAxis(ax, a) { var c = Math.cos(a), s = Math.sin(a); return ax === 0 ? [[1, 0, 0], [0, c, -s], [0, s, c]] : ax === 1 ? [[c, 0, s], [0, 1, 0], [-s, 0, c]] : [[c, -s, 0], [s, c, 0], [0, 0, 1]]; }
  function mul3(A, B) { var C = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]; for (var i = 0; i < 3; i++) for (var j = 0; j < 3; j++) for (var k = 0; k < 3; k++) C[i][j] += A[i][k] * B[k][j]; return C; }
  function mv3(R, v) { return [R[0][0] * v[0] + R[0][1] * v[1] + R[0][2] * v[2], R[1][0] * v[0] + R[1][1] * v[1] + R[1][2] * v[2], R[2][0] * v[0] + R[2][1] * v[1] + R[2][2] * v[2]]; }
  function tr3(R) { return [[R[0][0], R[1][0], R[2][0]], [R[0][1], R[1][1], R[2][1]], [R[0][2], R[1][2], R[2][2]]]; }
  function modelCenter() { var T = TH(), m = mesh(); if (!m) return [0, 0, 0]; var b = new T.Box3().setFromObject(m), c = b.getCenter(new T.Vector3()).applyMatrix4(new T.Matrix4().copy(PM()).invert()); return [c.x, c.y, c.z]; }
  function modelSize() { var T = TH(), m = mesh(); if (!m) return null; var b = new T.Box3().setFromObject(m); if (b.isEmpty()) return null; var s = b.getSize(new T.Vector3()); return [s.x, s.z, s.y]; }
  function rotateBy(ax, a) { var c = opt().pivot === 'center' ? modelCenter() : [0, 0, 0], R = rotAxis(ax, a), t = [c[0] - mv3(R, c)[0], c[1] - mv3(R, c)[1], c[2] - mv3(R, c)[2]]; return applyProg(M4(R, t)); }
  function moveBy(d) { return applyProg(M4([[1, 0, 0], [0, 1, 0], [0, 0, 1]], d)); }

  /* ======================= поверхность модели: равномерная выборка + сетки ======================= */
  var GRID = null;
  function sampleSurface(N) {
    var T = TH(), m = mesh(); if (!m) return null; m.updateMatrixWorld(true);
    var inv = new T.Matrix4().copy(PM()).invert(), parts = [], tot = 0;
    m.traverse(function (x) { if (!x.isMesh || !x.visible && x !== m || !x.geometry || !x.geometry.attributes.position) return; parts.push(x); });
    var tris = [];
    parts.forEach(function (x) {
      var g = x.geometry, pa = g.attributes.position, ix = g.index, Mx = new T.Matrix4().multiplyMatrices(inv, x.matrixWorld), e = Mx.elements, n = ix ? ix.count / 3 : pa.count / 3;
      var P = new Float64Array(pa.count * 3); for (var i = 0; i < pa.count; i++) { var a = pa.getX(i), b = pa.getY(i), c = pa.getZ(i); P[i * 3] = e[0] * a + e[4] * b + e[8] * c + e[12]; P[i * 3 + 1] = e[1] * a + e[5] * b + e[9] * c + e[13]; P[i * 3 + 2] = e[2] * a + e[6] * b + e[10] * c + e[14]; }
      tris.push({ P: P, ix: ix ? ix.array : null, n: n });
    });
    var nt = 0; tris.forEach(function (t) { nt += t.n; }); if (!nt) return null;
    var cum = new Float64Array(nt), ref = new Int32Array(nt), k = 0;
    tris.forEach(function (t, ti) { for (var i = 0; i < t.n; i++) { var a = t.ix ? t.ix[i * 3] : i * 3, b = t.ix ? t.ix[i * 3 + 1] : i * 3 + 1, c = t.ix ? t.ix[i * 3 + 2] : i * 3 + 2, P = t.P;
      var ux = P[b * 3] - P[a * 3], uy = P[b * 3 + 1] - P[a * 3 + 1], uz = P[b * 3 + 2] - P[a * 3 + 2], vx = P[c * 3] - P[a * 3], vy = P[c * 3 + 1] - P[a * 3 + 1], vz = P[c * 3 + 2] - P[a * 3 + 2];
      var cx = uy * vz - uz * vy, cy = uz * vx - ux * vz, cz = ux * vy - uy * vx; tot += 0.5 * Math.sqrt(cx * cx + cy * cy + cz * cz); cum[k] = tot; ref[k] = ti; k++; } });
    var T9 = new Float32Array(nt * 9), kk = 0;
    tris.forEach(function (t) { for (var i = 0; i < t.n; i++) { var vv = t.ix ? [t.ix[i * 3], t.ix[i * 3 + 1], t.ix[i * 3 + 2]] : [i * 3, i * 3 + 1, i * 3 + 2]; for (var q = 0; q < 3; q++) for (var d = 0; d < 3; d++) T9[kk * 9 + q * 3 + d] = t.P[vv[q] * 3 + d]; kk++; } });
    var NA = N; N = NA + nt;
    var X = new Float32Array(N * 3), Nn = new Float32Array(N * 3), TI = new Int32Array(N), seed = 12345, rnd = function () { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
    var base = []; var acc = 0; tris.forEach(function (t) { base.push(acc); acc += t.n; });
    for (var s = 0; s < NA; s++) {
      var r = rnd() * tot, lo = 0, hi = nt - 1; while (lo < hi) { var mid = (lo + hi) >> 1; if (cum[mid] < r) lo = mid + 1; else hi = mid; }
      var t = tris[ref[lo]], i2 = lo - base[ref[lo]], a2 = t.ix ? t.ix[i2 * 3] : i2 * 3, b2 = t.ix ? t.ix[i2 * 3 + 1] : i2 * 3 + 1, c2 = t.ix ? t.ix[i2 * 3 + 2] : i2 * 3 + 2, P2 = t.P;
      TI[s] = lo; var u = rnd(), v = rnd(); if (u + v > 1) { u = 1 - u; v = 1 - v; }
      for (var d = 0; d < 3; d++) X[s * 3 + d] = P2[a2 * 3 + d] + u * (P2[b2 * 3 + d] - P2[a2 * 3 + d]) + v * (P2[c2 * 3 + d] - P2[a2 * 3 + d]);
      var ux2 = P2[b2 * 3] - P2[a2 * 3], uy2 = P2[b2 * 3 + 1] - P2[a2 * 3 + 1], uz2 = P2[b2 * 3 + 2] - P2[a2 * 3 + 2], vx2 = P2[c2 * 3] - P2[a2 * 3], vy2 = P2[c2 * 3 + 1] - P2[a2 * 3 + 1], vz2 = P2[c2 * 3 + 2] - P2[a2 * 3 + 2];
      var nx = uy2 * vz2 - uz2 * vy2, ny = uz2 * vx2 - ux2 * vz2, nz = ux2 * vy2 - uy2 * vx2, nl = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1; Nn[s * 3] = nx / nl; Nn[s * 3 + 1] = ny / nl; Nn[s * 3 + 2] = nz / nl;
    }
    for (var j = 0; j < nt; j++) { var o9 = j * 9, s3 = (NA + j) * 3; TI[NA + j] = j;
      for (var d3 = 0; d3 < 3; d3++) X[s3 + d3] = (T9[o9 + d3] + T9[o9 + 3 + d3] + T9[o9 + 6 + d3]) / 3;
      var ax = T9[o9 + 3] - T9[o9], ay = T9[o9 + 4] - T9[o9 + 1], az = T9[o9 + 5] - T9[o9 + 2], bx = T9[o9 + 6] - T9[o9], by = T9[o9 + 7] - T9[o9 + 1], bz = T9[o9 + 8] - T9[o9 + 2], cx3 = ay * bz - az * by, cy3 = az * bx - ax * bz, cz3 = ax * by - ay * bx, l3 = Math.sqrt(cx3 * cx3 + cy3 * cy3 + cz3 * cz3) || 1;
      Nn[s3] = cx3 / l3; Nn[s3 + 1] = cy3 / l3; Nn[s3 + 2] = cz3 / l3; }
    return { X: X, N: Nn, TI: TI, T9: T9, nt: nt, n: N, area: tot, sp: Math.sqrt(tot / NA) };
  }
  function KEY3(i, j, k) { return ((i + 8192) * 16384 + (j + 8192)) * 16384 + (k + 8192); }
  function mkGrid(Sm, cs, cap) {
    var H = new Map(), X = Sm.X, mn = [1e18, 1e18, 1e18], mx = [-1e18, -1e18, -1e18];
    for (var i = 0; i < Sm.n; i++) { var x = X[i * 3], y = X[i * 3 + 1], z = X[i * 3 + 2]; if (x < mn[0]) mn[0] = x; if (y < mn[1]) mn[1] = y; if (z < mn[2]) mn[2] = z; if (x > mx[0]) mx[0] = x; if (y > mx[1]) mx[1] = y; if (z > mx[2]) mx[2] = z;
      var k = KEY3(Math.floor(x / cs), Math.floor(y / cs), Math.floor(z / cs)), a = H.get(k); if (!a) H.set(k, a = []); if (!cap || a.length < cap) a.push(i); }
    return { H: H, cs: cs, S: Sm, mn: mn, mx: mx, c: [(mn[0] + mx[0]) / 2, (mn[1] + mx[1]) / 2, (mn[2] + mx[2]) / 2] };
  }
  function grids() {
    if (GRID && GRID.ok) return GRID;
    var Sm = sampleSurface(400000); if (!Sm) return null;
    var fine = mkGrid(Sm, Math.max(0.8, Sm.sp * 1.6)); fine.exact = true; var dg = Math.sqrt(Math.pow(fine.mx[0] - fine.mn[0], 2) + Math.pow(fine.mx[1] - fine.mn[1], 2) + Math.pow(fine.mx[2] - fine.mn[2], 2));
    var coarse = mkGrid(Sm, Math.max(fine.cs * 3, dg / 90), 6);
    GRID = { ok: true, S: Sm, fine: fine, coarse: coarse, dg: dg }; return GRID;
  }
  function near(Gd, q, R) {
    var cs = Gd.cs, ix = Math.floor(q[0] / cs), iy = Math.floor(q[1] / cs), iz = Math.floor(q[2] / cs), X = Gd.S.X, best = -1, bd = 1e30;
    if (Gd.exact) return exactNear(Gd, q, ix, iy, iz, R);
    for (var dx = -R; dx <= R; dx++) for (var dy = -R; dy <= R; dy++) for (var dz = -R; dz <= R; dz++) { var a = Gd.H.get(KEY3(ix + dx, iy + dy, iz + dz)); if (!a) continue;
      for (var i = 0; i < a.length; i++) { var j = a[i] * 3, ex = X[j] - q[0], ey = X[j + 1] - q[1], ez = X[j + 2] - q[2], d = ex * ex + ey * ey + ez * ez; if (d < bd) { bd = d; best = a[i]; } } }
    if (best < 0) return null;
    var N = Gd.S.N, j2 = best * 3, pl = (q[0] - X[j2]) * N[j2] + (q[1] - X[j2 + 1]) * N[j2 + 1] + (q[2] - X[j2 + 2]) * N[j2 + 2];
    return { i: best, d: Math.sqrt(bd), pl: pl, s: [X[j2], X[j2 + 1], X[j2 + 2]], n: [N[j2], N[j2 + 1], N[j2 + 2]] };
  }

  function cpTri(T9, o, p) { /* ближайшая точка треугольника (Ericson) */
    var ax = T9[o], ay = T9[o + 1], az = T9[o + 2], bx = T9[o + 3], by = T9[o + 4], bz = T9[o + 5], cx = T9[o + 6], cy = T9[o + 7], cz = T9[o + 8];
    var abx = bx - ax, aby = by - ay, abz = bz - az, acx = cx - ax, acy = cy - ay, acz = cz - az, apx = p[0] - ax, apy = p[1] - ay, apz = p[2] - az;
    var d1 = abx * apx + aby * apy + abz * apz, d2 = acx * apx + acy * apy + acz * apz; if (d1 <= 0 && d2 <= 0) return [ax, ay, az];
    var bpx = p[0] - bx, bpy = p[1] - by, bpz = p[2] - bz, d3 = abx * bpx + aby * bpy + abz * bpz, d4 = acx * bpx + acy * bpy + acz * bpz; if (d3 >= 0 && d4 <= d3) return [bx, by, bz];
    var vc = d1 * d4 - d3 * d2; if (vc <= 0 && d1 >= 0 && d3 <= 0) { var v = d1 / (d1 - d3); return [ax + v * abx, ay + v * aby, az + v * abz]; }
    var cpx = p[0] - cx, cpy = p[1] - cy, cpz = p[2] - cz, d5 = abx * cpx + aby * cpy + abz * cpz, d6 = acx * cpx + acy * cpy + acz * cpz; if (d6 >= 0 && d5 <= d6) return [cx, cy, cz];
    var vb = d5 * d2 - d1 * d6; if (vb <= 0 && d2 >= 0 && d6 <= 0) { var w = d2 / (d2 - d6); return [ax + w * acx, ay + w * acy, az + w * acz]; }
    var va = d3 * d6 - d5 * d4; if (va <= 0 && (d4 - d3) >= 0 && (d5 - d6) >= 0) { var w2 = (d4 - d3) / ((d4 - d3) + (d5 - d6)); return [bx + w2 * (cx - bx), by + w2 * (cy - by), bz + w2 * (cz - bz)]; }
    var dn = 1 / (va + vb + vc), v2 = vb * dn, w3 = vc * dn; return [ax + abx * v2 + acx * w3, ay + aby * v2 + acy * w3, az + abz * v2 + acz * w3];
  }
  function exactNear(Gd, q, ix, iy, iz, R) {
    var S2 = Gd.S, X = S2.X, cand = [], ST = S2.stamp || (S2.stamp = new Int32Array(S2.nt)), sv = S2.sv = (S2.sv || 0) + 1;
    for (var dx = -R; dx <= R; dx++) for (var dy = -R; dy <= R; dy++) for (var dz = -R; dz <= R; dz++) { var a = Gd.H.get(KEY3(ix + dx, iy + dy, iz + dz)); if (!a) continue;
      for (var i = 0; i < a.length; i++) { var t = S2.TI[a[i]]; if (ST[t] === sv) continue; ST[t] = sv; var j = a[i] * 3, ex = X[j] - q[0], ey = X[j + 1] - q[1], ez = X[j + 2] - q[2]; cand.push(ex * ex + ey * ey + ez * ez, t); } }
    if (!cand.length) return null; var nc = cand.length / 2, ord = []; for (var c0 = 0; c0 < nc; c0++) ord.push(c0); if (nc > 24) { ord.sort(function (u, v) { return cand[u * 2] - cand[v * 2]; }); }
    var bd = 1e30, bp = null, bt = -1, K = Math.min(nc, 24);
    for (var k = 0; k < K; k++) { var tk = cand[ord[k] * 2 + 1], cp = cpTri(S2.T9, tk * 9, q), e0 = cp[0] - q[0], e1 = cp[1] - q[1], e2 = cp[2] - q[2], d = e0 * e0 + e1 * e1 + e2 * e2; if (d < bd) { bd = d; bp = cp; bt = tk; } }
    var nj = (S2.n - S2.nt + bt) * 3, N = S2.N, n = [N[nj], N[nj + 1], N[nj + 2]], d0 = Math.sqrt(bd), pl = (q[0] - bp[0]) * n[0] + (q[1] - bp[1]) * n[1] + (q[2] - bp[2]) * n[2];
    /* точка ближе к ребру — нормаль по направлению на точку */
    if (d0 > 1e-6 && Math.abs(pl) < d0 * 0.98) { n = [(q[0] - bp[0]) / d0, (q[1] - bp[1]) / d0, (q[2] - bp[2]) / d0]; pl = d0; }
    return { i: bt, d: d0, pl: pl, s: bp, n: n };
  }

  function distField(Gd) {
    if (Gd.D) return Gd.D; var t0 = Date.now(), S2 = Gd.S, X = S2.X, n = S2.n, F = Gd.fine, pad = 12, mn = [F.mn[0] - pad, F.mn[1] - pad, F.mn[2] - pad], ext = [F.mx[0] - F.mn[0] + 2 * pad, F.mx[1] - F.mn[1] + 2 * pad, F.mx[2] - F.mn[2] + 2 * pad];
    var h = Math.max(0.5, Math.cbrt(ext[0] * ext[1] * ext[2] / 6e6)), nx = Math.ceil(ext[0] / h) + 3, ny = Math.ceil(ext[1] / h) + 3, nz = Math.ceil(ext[2] / h) + 3, NN = nx * ny * nz, A = new Float32Array(NN).fill(1e9), sxy = nx * ny;
    for (var i = 0; i < n; i++) { var fx = (X[i * 3] - mn[0]) / h, fy = (X[i * 3 + 1] - mn[1]) / h, fz = (X[i * 3 + 2] - mn[2]) / h, ix = Math.round(fx), iy = Math.round(fy), iz = Math.round(fz), k = ix + iy * nx + iz * sxy, d = h * Math.sqrt((fx - ix) * (fx - ix) + (fy - iy) * (fy - iy) + (fz - iz) * (fz - iz)); if (d < A[k]) A[k] = d; }
    var w1 = h, w2 = h * Math.SQRT2, w3 = h * Math.sqrt(3), nb = [];
    for (var dz = -1; dz <= 0; dz++) for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) { if (dz === 0 && (dy > 0 || (dy === 0 && dx >= 0))) continue; var c = Math.abs(dx) + Math.abs(dy) + Math.abs(dz); nb.push([dx, dy, dz, c === 1 ? w1 : c === 2 ? w2 : w3]); }
    var OFF = new Int32Array(nb.length), WW = new Float32Array(nb.length), NB = nb.length;
    function pass(sg) { var z0 = sg > 0 ? 1 : nz - 2, z1 = sg > 0 ? nz - 1 : 0, y0 = sg > 0 ? 1 : ny - 2, y1 = sg > 0 ? ny - 1 : 0, x0 = sg > 0 ? 1 : nx - 2, x1 = sg > 0 ? nx - 1 : 0;
      for (var j0 = 0; j0 < NB; j0++) { OFF[j0] = (nb[j0][0] + nb[j0][1] * nx + nb[j0][2] * sxy) * sg; WW[j0] = nb[j0][3]; }
      for (var z = z0; z !== z1; z += sg) for (var y = y0; y !== y1; y += sg) { var row = y * nx + z * sxy; for (var x = x0; x !== x1; x += sg) { var k2 = row + x, v = A[k2];
        for (var j = 0; j < NB; j++) { var u = A[k2 + OFF[j]] + WW[j]; if (u < v) v = u; } A[k2] = v; } } }
    pass(1); pass(-1);
    Gd.D = { h: h, ms: Date.now() - t0, at: function (x, y, z) { var fx = (x - mn[0]) / h, fy = (y - mn[1]) / h, fz = (z - mn[2]) / h, ix = Math.floor(fx), iy = Math.floor(fy), iz = Math.floor(fz); if (ix < 0 || iy < 0 || iz < 0 || ix >= nx - 1 || iy >= ny - 1 || iz >= nz - 1) return 1e6; var u = fx - ix, v = fy - iy, w = fz - iz, k = ix + iy * nx + iz * sxy;
      var c00 = A[k] + (A[k + 1] - A[k]) * u, c10 = A[k + nx] + (A[k + nx + 1] - A[k + nx]) * u, c01 = A[k + sxy] + (A[k + sxy + 1] - A[k + sxy]) * u, c11 = A[k + sxy + nx] + (A[k + sxy + nx + 1] - A[k + sxy + nx]) * u, c0 = c00 + (c10 - c00) * v, c1 = c01 + (c11 - c01) * v; return c0 + (c1 - c0) * w; } };
    return Gd.D;
  }

  /* ======================= точки программы ======================= */
  function progHits(maxN) {
    var st = S(), els = ((st && st.elements) || []).filter(function (e) { return e._hits && e._hits.length; }), tot = 0, out = [], nm = [];
    els.forEach(function (e) { tot += e._hits.length; });
    var per = Math.max(3, Math.ceil(maxN / Math.max(1, els.length)));
    els.forEach(function (e) { var H = e._hits, st2 = Math.max(1, Math.floor(H.length / per)); for (var i = 0; i < H.length; i += st2) { out.push([+H[i][0], +H[i][1], +H[i][2]]); nm.push(e.name); } });
    if (out.length < 8) ((st && st.elements) || []).forEach(function (e) { if (/plane|point/.test(String(e.type))) { out.push([num(e.x), num(e.y), num(e.z)]); nm.push(e.name); } });
    return { P: out, names: nm, total: tot };
  }

  /* ======================= подбор: Y — преобразование точек программы в СК модели (Y·q ≈ s) ======================= */
  function applyY(Y, q) { var p = mv3(Y.R, q); return [p[0] + Y.t[0], p[1] + Y.t[1], p[2] + Y.t[2]]; }
  function solve(A, b, n) { /* Гаусс с выбором главного */
    for (var i = 0; i < n; i++) { var mx = i; for (var r = i + 1; r < n; r++) if (Math.abs(A[r][i]) > Math.abs(A[mx][i])) mx = r; var tmp = A[i]; A[i] = A[mx]; A[mx] = tmp; var tb = b[i]; b[i] = b[mx]; b[mx] = tb; if (Math.abs(A[i][i]) < 1e-12) return null;
      for (var r2 = i + 1; r2 < n; r2++) { var f = A[r2][i] / A[i][i]; for (var c = i; c < n; c++) A[r2][c] -= f * A[i][c]; b[r2] -= f * b[i]; } }
    var x = new Array(n); for (var i2 = n - 1; i2 >= 0; i2--) { var s = b[i2]; for (var c2 = i2 + 1; c2 < n; c2++) s -= A[i2][c2] * x[c2]; x[i2] = s / A[i2][i2]; } return x;
  }
  function rodr(w) { var a = Math.sqrt(w[0] * w[0] + w[1] * w[1] + w[2] * w[2]); if (a < 1e-12) return [[1, 0, 0], [0, 1, 0], [0, 0, 1]]; var k = [w[0] / a, w[1] / a, w[2] / a], c = Math.cos(a), s = Math.sin(a), v = 1 - c;
    return [[c + k[0] * k[0] * v, k[0] * k[1] * v - k[2] * s, k[0] * k[2] * v + k[1] * s], [k[1] * k[0] * v + k[2] * s, c + k[1] * k[1] * v, k[1] * k[2] * v - k[0] * s], [k[2] * k[0] * v - k[1] * s, k[2] * k[1] * v + k[0] * s, c + k[2] * k[2] * v]]; }
  function icpTrans(Gd, Q, Y, R, lim, iters, keep) {
    keep = keep || 0.6;
    for (var it = 0; it < iters; it++) { var V = [];
      for (var i = 0; i < Q.length; i++) { var q = applyY(Y, Q[i]), r = near(Gd, q, R); if (r && r.d < lim) V.push([r.d, r.s[0] - q[0], r.s[1] - q[1], r.s[2] - q[2]]); }
      if (V.length < Math.max(4, Q.length * 0.03)) return false;
      V.sort(function (a, b) { return a[0] - b[0]; }); var m = Math.max(4, Math.ceil(V.length * keep)), acc = [0, 0, 0];
      for (var j = 0; j < m; j++) { acc[0] += V[j][1]; acc[1] += V[j][2]; acc[2] += V[j][3]; }
      Y.t = [Y.t[0] + acc[0] / m, Y.t[1] + acc[1] / m, Y.t[2] + acc[2] / m]; }
    return true;
  }
  function icpPlane(Gd, Q, Y, lim, iters, rot, Lmin) {
    Lmin = Lmin || Math.max(0.6, Gd.S.sp * 0.6);
    for (var it = 0; it < iters; it++) {
      var rows = [], L = Math.max(Lmin, lim * Math.pow(0.75, it)), cc = [0, 0, 0], P = [];
      for (var i = 0; i < Q.length; i++) { var q = applyY(Y, Q[i]), r = near(Gd, q, 1); if (!r || r.d > L * 1.5 || Math.abs(r.pl) > L) continue; P.push([q, r]); cc[0] += q[0]; cc[1] += q[1]; cc[2] += q[2]; }
      if (P.length < 12) return false; cc = [cc[0] / P.length, cc[1] / P.length, cc[2] / P.length];
      P.forEach(function (pr) { var q = [pr[0][0] - cc[0], pr[0][1] - cc[1], pr[0][2] - cc[2]], n = pr[1].n, b = -pr[1].pl, u = Math.abs(b) / L, w = u < 1 ? (1 - u * u) * (1 - u * u) : 0, c = [q[1] * n[2] - q[2] * n[1], q[2] * n[0] - q[0] * n[2], q[0] * n[1] - q[1] * n[0]]; if (w > 0) rows.push({ a: rot ? [c[0], c[1], c[2], n[0], n[1], n[2]] : [n[0], n[1], n[2]], b: b, w: w }); });
      if (rows.length < 12) return false;
      var m = rot ? 6 : 3, A = [], bb = []; for (var k = 0; k < m; k++) { A.push(new Array(m).fill(0)); bb.push(0); }
      rows.forEach(function (rw) { for (var i2 = 0; i2 < m; i2++) { bb[i2] += rw.w * rw.a[i2] * rw.b; for (var j = 0; j < m; j++) A[i2][j] += rw.w * rw.a[i2] * rw.a[j]; } });
      var tr = 0; for (var d = 0; d < m; d++) tr += A[d][d]; for (var d2 = 0; d2 < m; d2++) A[d2][d2] += tr * 1e-7 + 1e-9;
      var x = solve(A, bb, m); if (!x) return false;
      var dR = rot ? rodr([x[0], x[1], x[2]]) : [[1, 0, 0], [0, 1, 0], [0, 0, 1]], dt = rot ? [x[3], x[4], x[5]] : [x[0], x[1], x[2]];
      /* вращение вокруг центроида: y' = dR(y-c)+c+dt */
      Y.R = mul3(dR, Y.R); var tt = mv3(dR, [Y.t[0] - cc[0], Y.t[1] - cc[1], Y.t[2] - cc[2]]); Y.t = [tt[0] + cc[0] + dt[0], tt[1] + cc[1] + dt[1], tt[2] + cc[2] + dt[2]];
      if (L <= Lmin && Math.sqrt(dt[0] * dt[0] + dt[1] * dt[1] + dt[2] * dt[2]) < 2e-4 && (!rot || Math.sqrt(x[0] * x[0] + x[1] * x[1] + x[2] * x[2]) < 2e-7)) break;
    }
    return true;
  }
  function score(Gd, Q, Y, tol) {
    var n = 0, ds = [];
    for (var i = 0; i < Q.length; i++) { var r = near(Gd, applyY(Y, Q[i]), 1); if (!r) continue; var d = Gd.exact ? r.d : r.d < Gd.cs * 1.5 ? Math.abs(r.pl) : r.d; ds.push(d); if (d < tol) n++; }
    ds.sort(function (a, b) { return a - b; });
    return { f: n / Math.max(1, Q.length), n: n, med: ds.length ? ds[Math.floor(ds.length / 2)] : 1e9, cover: ds.length / Math.max(1, Q.length) };
  }
  function rots24() { var out = [], P = [[0, 1, 2], [0, 2, 1], [1, 0, 2], [1, 2, 0], [2, 0, 1], [2, 1, 0]];
    P.forEach(function (p) { [1, -1].forEach(function (a) { [1, -1].forEach(function (b) { [1, -1].forEach(function (c) { var R = [[0, 0, 0], [0, 0, 0], [0, 0, 0]], s = [a, b, c]; for (var r = 0; r < 3; r++) R[r][p[r]] = s[r];
      var det = R[0][0] * (R[1][1] * R[2][2] - R[1][2] * R[2][1]) - R[0][1] * (R[1][0] * R[2][2] - R[1][2] * R[2][0]) + R[0][2] * (R[1][0] * R[2][1] - R[1][1] * R[2][0]); if (det > 0) out.push(R); }); }); }); });
    return out; }
  function rotName(R) { var T = TH(), m = new T.Matrix4().set(R[0][0], R[0][1], R[0][2], 0, R[1][0], R[1][1], R[1][2], 0, R[2][0], R[2][1], R[2][2], 0, 0, 0, 0, 1), e = new T.Euler().setFromRotationMatrix(m, 'XYZ'); return 'X' + Math.round(deg(e.x)) + '° Y' + Math.round(deg(e.y)) + '° Z' + Math.round(deg(e.z)) + '°'; }
  function pct(Q, k) { var v = Q.map(function (q) { return q[k]; }).sort(function (a, b) { return a - b; }); return [v[Math.floor(v.length * 0.02)], v[Math.floor(v.length * 0.98)]]; }
  function autoFit(o) {
    o = o || {}; var Gd = grids(); if (!Gd) return { err: 'Сначала загрузите модель (STL / STEP)' };
    try { if (W.pcdBases) W.pcdBases.applyFix(); } catch (e) {}
    var H = progHits(2500); if (H.P.length < 6) return { err: 'В программе нет касаний / элементов' };
    var Q = H.P, Qc = [], st = Math.max(1, Math.floor(Q.length / 500)); for (var i = 0; i < Q.length; i += st) Qc.push(Q[i]);
    var cq = [0, 1, 2].map(function (k) { var p = pct(Q, k); return (p[0] + p[1]) / 2; }), cm = Gd.fine.c, C = Gd.coarse, F = Gd.fine;
    var cands = [], I = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
    cands.push({ R: I, t: [0, 0, 0], why: 'текущее положение' });
    try { (W.pcdBases ? W.pcdBases.aligns().list : []).forEach(function (a) { if (a.Ot && Math.sqrt(a.Ot[0] * a.Ot[0] + a.Ot[1] * a.Ot[1] + a.Ot[2] * a.Ot[2]) > 1e-3) { cands.push({ R: I, t: a.Ot.map(function (v) { return -v; }), why: 'модель от начала СК ' + a.name }); } }); } catch (e) {}
    (o.rot === false ? [I] : rots24()).forEach(function (R) { var Rc = mv3(R, cq); cands.push({ R: R, t: [cm[0] - Rc[0], cm[1] - Rc[1], cm[2] - Rc[2]], why: 'ориентация ' + rotName(tr3(R)) }); });
    /* поле расстояний до поверхности (воксели) — быстрый глобальный и локальный перебор сдвигов */
    var D = distField(Gd), Qs = [], st3 = Math.max(1, Math.floor(Qc.length / 120)); for (var i3 = 0; i3 < Qc.length; i3 += st3) Qs.push(Qc[i3]);
    function dsc(R, t, P, tau) { var sc = 0; for (var i = 0; i < P.length; i++) { var p = mv3(R, P[i]), d = D.at(p[0] + t[0], p[1] + t[1], p[2] + t[2]) / tau; if (d < 1) sc += 1 - d * d; } return sc / P.length; }
    var stepG = Math.max(D.h * 3, Gd.dg / 60), shifts = [], RR = o.rot === false ? [I] : rots24();
    RR.forEach(function (R) {
      var mn = [1e18, 1e18, 1e18], mx = [-1e18, -1e18, -1e18]; Qs.forEach(function (q) { var p = mv3(R, q); for (var k = 0; k < 3; k++) { if (p[k] < mn[k]) mn[k] = p[k]; if (p[k] > mx[k]) mx[k] = p[k]; } });
      var ax = [0, 1, 2].map(function (k) { var lo = F.mn[k] - mn[k] - stepG, hi = F.mx[k] - mx[k] + stepG; if (hi < lo) { var c = (lo + hi) / 2; lo = c - stepG * 2; hi = c + stepG * 2; } var n = Math.min(80, Math.floor((hi - lo) / stepG) + 1), out = []; for (var j = 0; j < n; j++) out.push(lo + (hi - lo) * (n === 1 ? 0.5 : j / (n - 1))); return out; });
      ax[0].forEach(function (x) { ax[1].forEach(function (y) { ax[2].forEach(function (z) { shifts.push({ R: R, t: [x, y, z] }); }); }); });
    });
    if (shifts.length > 40000) { var kp = Math.ceil(shifts.length / 40000), sh2 = []; for (var i4 = 0; i4 < shifts.length; i4 += kp) sh2.push(shifts[i4]); shifts = sh2; }
    shifts.forEach(function (c) { c.g = dsc(c.R, c.t, Qs, stepG); });
    shifts.sort(function (a, b) { return b.g - a.g; });
    var perR = new Map(); shifts.forEach(function (c) { var k = c.R.join(), a2 = perR.get(k) || 0; if (a2 < 4 && cands.length < 70) { perR.set(k, a2 + 1); cands.push({ R: c.R, t: c.t, why: 'перебор ' + rotName(tr3(c.R)) }); } });
    /* локальный поиск по сетке сдвигов с уменьшением шага */
    cands.forEach(function (c) { var t = c.t.slice(), R = c.R, s = stepG;
      while (s >= D.h * 1.9) { var PP = Qs, tau = Math.max(D.h * 0.8, s * 1.5), best = dsc(R, t, PP, tau), mv = 0;
        for (var rep = 0; rep < 8; rep++) { var bt = null; for (var dx = -1; dx <= 1; dx++) for (var dy = -1; dy <= 1; dy++) for (var dz = -1; dz <= 1; dz++) { if (!dx && !dy && !dz) continue; var t2 = [t[0] + dx * s, t[1] + dy * s, t[2] + dz * s], v = dsc(R, t2, PP, tau); if (v > best + 1e-9) { best = v; bt = t2; } } if (!bt) break; t = bt; mv++; }
        s /= 2; }
      c.Y = { R: R, t: t }; c.g2 = dsc(R, t, Qc, D.h * 2.5); });
    cands.sort(function (a, b) { return b.g2 - a.g2; });
    var top = [], seenT = []; cands.forEach(function (c) { if (top.length >= 8) return; var dup = seenT.some(function (u) { return u.R.join() === c.R.join() && Math.abs(u.t[0] - c.Y.t[0]) + Math.abs(u.t[1] - c.Y.t[1]) + Math.abs(u.t[2] - c.Y.t[2]) < 3; }); if (!dup) { seenT.push({ R: c.R, t: c.Y.t }); top.push(c); } });
    /* точный локальный поиск (расстояние до треугольников) */
    function esc2(Y, P, tau) { var sc = 0; for (var i = 0; i < P.length; i++) { var r = near(F, applyY(Y, P[i]), 1); if (!r) continue; var d = r.d / tau; if (d < 1) sc += 1 - d * d; } return sc / P.length; }
    top.forEach(function (c) { var Y = c.Y, s = Math.max(2, D.h * 1.9);
      while (s >= 0.24) { var tau = Math.max(0.5, s * 1.2), best = esc2(Y, Qs, tau);
        for (var rep = 0; rep < 8; rep++) { var bt = null; for (var m6 = 0; m6 < 6; m6++) { var dx = m6 === 0 ? 1 : m6 === 1 ? -1 : 0, dy = m6 === 2 ? 1 : m6 === 3 ? -1 : 0, dz = m6 === 4 ? 1 : m6 === 5 ? -1 : 0; var Y2 = { R: Y.R, t: [Y.t[0] + dx * s, Y.t[1] + dy * s, Y.t[2] + dz * s] }, v = esc2(Y2, Qs, tau); if (v > best + 1e-9) { best = v; bt = Y2.t; } } if (!bt) break; Y.t = bt; }
        s /= 2; } });
    var tol = 0.5;
    top.forEach(function (c) { var Y = c.Y; icpPlane(F, Qc, Y, 2, 12, o.rot !== false); c.s = score(F, Qc, Y, tol); });
    top.sort(function (a, b) { return b.s.f - a.s.f || a.s.med - b.s.med; });
    top.forEach(function (c, i) { if (i === 0) icpPlane(F, Q, c.Y, 1.5, 10, o.rot !== false); c.s = score(F, i === 0 ? Q : Qc, c.Y, tol); });
    /* X = Y⁻¹: модель → программа */
    top.forEach(function (c) { var Rt = tr3(c.Y.R), tt = mv3(Rt, c.Y.t); c.X = { R: Rt, t: [-tt[0], -tt[1], -tt[2]] }; c.rotTxt = rotName(Rt); c.move = Math.sqrt(c.X.t[0] * c.X.t[0] + c.X.t[1] * c.X.t[1] + c.X.t[2] * c.X.t[2]); });
    var uq = []; top.forEach(function (c) { if (!uq.some(function (u) { var dr = 0; for (var i = 0; i < 3; i++) for (var j = 0; j < 3; j++) dr += Math.abs(u.X.R[i][j] - c.X.R[i][j]); return dr < 0.05 && Math.abs(u.X.t[0] - c.X.t[0]) + Math.abs(u.X.t[1] - c.X.t[1]) + Math.abs(u.X.t[2] - c.X.t[2]) < 2; })) uq.push(c); }); top = uq;
    return { best: top[0], top: top, n: Q.length, tol: tol, sp: F.S.sp, dbg: o.debug ? { cands: cands, shifts: shifts.slice(0, 400), Qs: Qs.length, h: D.h, ms: D.ms } : null };
  }
  function applyFit(c) { if (!c) return; applyProg(M4(c.X.R, c.X.t)); }

  /* ======================= карта отклонений ======================= */
  var MAP = { obj: null, rows: [] };
  function dropMap() { var sc = G('scene3'); if (MAP.obj) { if (sc) sc.remove(MAP.obj); MAP.obj.geometry.dispose(); MAP.obj.material.dispose(); MAP.obj = null; } }
  function colFor(d) { return d == null ? [0.85, 0.2, 0.85] : d <= 0.05 ? [0.1, 0.8, 0.3] : d <= 0.2 ? [0.55, 0.85, 0.2] : d <= 0.5 ? [1, 0.85, 0.1] : d <= 2 ? [1, 0.5, 0.1] : [0.95, 0.15, 0.15]; }
  function devAll() {
    var Gd = grids(); if (!Gd) return null; var F = Gd.fine, st = S(), els = ((st && st.elements) || []).filter(function (e) { return e._hits && e._hits.length; }), pts = [], rows = [];
    els.forEach(function (e) { var H = e._hits, step = Math.max(1, Math.floor(H.length / 400)), ds = [];
      for (var i = 0; i < H.length; i += step) { var q = [+H[i][0], +H[i][1], +H[i][2]], r = near(F, q, 1), d = r ? (r.d < F.cs * 1.5 ? Math.abs(r.pl) : r.d) : null; pts.push({ q: q, d: d }); if (d != null) ds.push(d); }
      ds.sort(function (a, b) { return a - b; }); rows.push({ name: e.name, n: H.length, med: ds.length ? ds[Math.floor(ds.length / 2)] : null, max: ds.length ? ds[ds.length - 1] : null, miss: (H.length / step | 0) - ds.length }); });
    return { pts: pts, rows: rows };
  }
  function buildMap() {
    dropMap(); var T = TH(), sc = G('scene3'); if (!T || !sc || !opt().map) return; var D = devAll(); if (!D) return; MAP.rows = D.rows;
    var pos = new Float32Array(D.pts.length * 3), col = new Float32Array(D.pts.length * 3);
    D.pts.forEach(function (p, i) { pos[i * 3] = p.q[0]; pos[i * 3 + 1] = p.q[1]; pos[i * 3 + 2] = p.q[2]; var c = colFor(p.d); col[i * 3] = c[0]; col[i * 3 + 1] = c[1]; col[i * 3 + 2] = c[2]; });
    var g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(pos, 3)); g.setAttribute('color', new T.BufferAttribute(col, 3));
    var o = new T.Points(g, new T.PointsMaterial({ size: 3.2, sizeAttenuation: false, vertexColors: true, depthTest: false, transparent: true, opacity: 0.95 }));
    o.matrixAutoUpdate = false; o.matrix.copy(PM()); o.renderOrder = 998; o.frustumCulled = false; o.raycast = function () {}; o.userData.kind = 'p73devmap'; sc.add(o); MAP.obj = o; renderRows();
  }

  /* ======================= UI вкладки «Положение» ======================= */
  var CSS = '#apTransform.open{width:360px}#p73pos{font-size:12px;color:#c9d4e2}#p73pos .sec{font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:#7f95ad;font-weight:700;margin:10px 0 4px;border-top:1px solid rgba(255,255,255,.08);padding-top:8px}' +
    '#p73pos .st{background:rgba(47,159,224,.10);border:1px solid rgba(47,159,224,.35);border-radius:8px;padding:6px 8px;line-height:1.45;font-size:11px}#p73pos .st b{color:#e6edf5}' +
    '#p73pos .q{display:inline-block;padding:0 6px;border-radius:8px;font-weight:700;color:#06121a}#p73pos .row2{display:flex;gap:4px;flex-wrap:wrap;align-items:center;margin-top:4px}' +
    '#p73pos button.b{background:#1b2430;border:1px solid #33465c;color:#d7e3f0;border-radius:6px;padding:4px 7px;font-size:11.5px;cursor:pointer}#p73pos button.b:hover{border-color:#2f9fe0;color:#fff}' +
    '#p73pos button.p{background:#2f9fe0;color:#06121a;border-color:#2f9fe0;font-weight:700;padding:7px 10px;flex:1}#p73pos button.p:hover{background:#3fb6f0}' +
    '#p73pos .pad{display:grid;grid-template-columns:repeat(6,1fr);gap:3px;margin-top:4px}#p73pos .pad button{padding:5px 0}#p73pos select,#p73pos input[type=text]{background:#0d1218;border:1px solid #33465c;color:#d7e3f0;border-radius:5px;padding:2px 4px;font-size:11.5px}' +
    '#p73pos .hint{font-size:10.5px;color:#7f95ad;line-height:1.45;margin-top:3px}#p73pos table{width:100%;border-collapse:collapse;font-size:11px}#p73pos td{padding:1px 3px;border-bottom:1px solid rgba(255,255,255,.06)}#p73pos td.n{text-align:right;font-family:Consolas,monospace}' +
    '#p73pos .alt{display:flex;gap:4px;align-items:center;margin-top:3px;font-size:11px}#p73pos .alt span.t{flex:1;min-width:0}#p73pos .mtx{font:10.5px Consolas,monospace;color:#9fb3c8;white-space:pre;background:#0d1218;border-radius:5px;padding:4px 6px;margin-top:4px;overflow:auto}' +
    '#p73pos .leg i{display:inline-block;width:9px;height:9px;border-radius:50%;margin:0 3px 0 6px;vertical-align:-1px}#p73pos .opts{display:grid;grid-template-columns:auto 1fr auto 1fr;gap:4px 6px;align-items:center;margin-top:4px}#p73pos .opts .w3{grid-column:span 3}#p73pos select{width:auto !important;min-width:0;max-width:100%}body.pcdmis-skin #p73pos .st{background:#fff !important;border-color:#b9d4ea !important}body.pcdmis-skin #p73pos .sec{color:#6b7280 !important;border-top-color:rgba(0,0,0,.1) !important}body.pcdmis-skin #p73pos .hint{color:#6b7280 !important}body.pcdmis-skin #p73pos .hint.err{color:#b91c1c !important}body.pcdmis-skin #p73pos button.b{background:#fff !important;border-color:#c4c9d0 !important;color:#2a3038 !important}body.pcdmis-skin #p73pos button.b:hover{border-color:#0a6ea8 !important;color:#0a6ea8 !important}body.pcdmis-skin #p73pos button.p,body.pcdmis-skin #p73pos button.p *{background:#0a6ea8 !important;border-color:#0a6ea8 !important;color:#fff !important}body.pcdmis-skin #p73pos button.p:hover{background:#0b7fc2 !important}body.pcdmis-skin #p73pos button:disabled{opacity:.6}body.pcdmis-skin #p73pos select,body.pcdmis-skin #p73pos input[type=text]{background:#fff !important;color:#1f2429 !important;border:1px solid #c4c9d0 !important}body.pcdmis-skin #p73pos .mtx{background:#fff !important;color:#374151 !important;border:1px solid #d7dbe0}body.pcdmis-skin #p73pos .q{color:#111 !important}body.pcdmis-skin #p73pos td{border-bottom-color:rgba(0,0,0,.07) !important}body.pcdmis-skin #p73legacy>summary{color:#6b7280 !important}#p73legacy{margin-top:6px}#p73legacy>summary{cursor:pointer;color:#7f95ad;font-size:11px;margin:6px 0}';
  function qBadge(f) { var c = f >= 0.9 ? '#22c55e' : f >= 0.6 ? '#facc15' : f >= 0.3 ? '#fb923c' : '#ef4444'; return '<span class="q" style="background:' + c + '">' + Math.round(f * 100) + '%</span>'; }
  function status() {
    var el = $('p73posSt'); if (!el) return; var m = mesh(), st = G('stlTransform'), sz = modelSize(), nm = ($('stlFileName') || {}).textContent || '';
    if (!m) { el.innerHTML = 'Модель не загружена. <b>⬆ STL / OBJ / STEP</b> — загрузите модель, затем «Привязать к программе».'; return; }
    var s = ['Модель: <b>' + esc(nm || 'загружена') + '</b>' + (sz ? ' · ' + sz.map(function (v) { return Math.round(v); }).join('×') + ' мм' : ''),
      'Сдвиг: <b>' + [st.x, st.y, st.z].map(f3).join(', ') + '</b> мм', 'Поворот: <b>X' + f2(st.rx) + '° Y' + f2(st.ry) + '° Z' + f2(st.rz) + '°</b>' + ((st.scale || 1) !== 1 ? ' · масштаб ' + st.scale : '')];
    if (LAST.fit && LAST.fit.best) s.push('Совпадение с касаниями: ' + qBadge(LAST.fit.best.s.f) + ' · медиана ' + f3(LAST.fit.best.s.med) + ' мм');
    el.innerHTML = s.join('<br>');
  }
  function renderAlt() {
    var el = $('p73posAlt'); if (!el) return; var F = LAST.fit; if (!F) { el.innerHTML = ''; return; }
    if (F.err) { el.innerHTML = '<div class="hint err" style="color:#fca5a5">' + esc(F.err) + '</div>'; return; }
    el.innerHTML = '<div class="hint">Касаний: ' + F.n + ', допуск ' + f2(F.tol) + ' мм (шаг выборки поверхности ' + f2(F.sp) + ' мм). Варианты (для симметричных деталей сравните):</div>' +
      F.top.map(function (c, i) { return '<div class="alt">' + qBadge(c.s.f) + '<span class="t">' + (i === 0 ? '<b>лучший</b> · ' : '') + esc(c.rotTxt) + ' · сдвиг ' + Math.round(c.move) + ' мм · мед. ' + f3(c.s.med) + '</span><button class="b" data-alt="' + i + '">' + (F.applied === i ? '✓' : 'Применить') + '</button></div>'; }).join('');
  }
  function renderRows() {
    var el = $('p73posDev'); if (!el) return; if (!opt().map || !MAP.rows.length) { el.innerHTML = ''; return; }
    var R = MAP.rows.slice().sort(function (a, b) { return (b.med == null ? 1e9 : b.med) - (a.med == null ? 1e9 : a.med); });
    var ok = R.filter(function (r) { return r.med != null && r.med <= 0.2; }).length;
    el.innerHTML = '<div class="hint leg">На модели: ' + ok + ' из ' + R.length + ' элементов (медиана ≤ 0.2 мм).<i style="background:#1ccc4d"></i>≤0.05<i style="background:#8cd933"></i>≤0.2<i style="background:#ffd91a"></i>≤0.5<i style="background:#ff801a"></i>≤2<i style="background:#f22"></i>&gt;2<i style="background:#d3d"></i>нет поверхности</div>' +
      '<table><tbody>' + R.slice(0, 12).map(function (r) { return '<tr><td>' + esc(r.name) + '</td><td class="n">' + (r.med == null ? '—' : f3(r.med)) + '</td><td class="n">' + (r.max == null ? '' : f2(r.max)) + '</td></tr>'; }).join('') + '</tbody></table><div class="hint">Худшие 12: медиана / максимум отклонения касаний от поверхности, мм.</div>';
  }
  function alignOpts() { var L = []; try { L = W.pcdBases ? W.pcdBases.aligns().list : []; } catch (e) {} return L.filter(function (a) { return a.Ot; }).map(function (a) { return '<option value="' + esc(a.name) + '">' + esc(a.name) + ' (' + a.Ot.map(function (v) { return Math.round(v * 10) / 10; }).join(', ') + ')</option>'; }).join(''); }
  function matrixTxt() { var T = TH(), m = mesh(); if (!m) return ''; m.updateMatrixWorld(true); var A = new T.Matrix4().copy(PM()).invert().multiply(m.matrixWorld).multiply(PM()), e = A.elements;
    return [0, 1, 2].map(function (r) { return [0, 1, 2, 3].map(function (c) { var v = e[c * 4 + r]; return (v >= 0 ? ' ' : '') + v.toFixed(c === 3 ? 3 : 6); }).join('  '); }).join('\n'); }
  function panelHtml() {
    var o = opt();
    return '<div class="st" id="p73posSt"></div>' +
      '<div class="sec">⚡ Привязка к программе</div>' +
      '<div class="row2"><button class="b p" data-a="fit">⚡ Привязать модель к программе</button><button class="b" data-a="undo" title="Отменить последнее изменение положения">Отмена</button></div>' +
      '<div class="row2"><label title="Перебрать 24 ориентации (повороты на 90°) и точно довернуть"><input type="checkbox" data-o="rot"' + (o.rot ? ' checked' : '') + '> с поворотом (24 ориентации + точная подгонка)</label></div>' +
      '<div id="p73posAlt"></div>' +
      '<div class="hint">Подбор по касаниям .PRG (точки на поверхности): модель ставится так, чтобы касания легли на её поверхность. Касания ручных баз под ЗАПУСК предварительно переносятся к номиналу.</div>' +
      '<div class="sec">🧭 От начала СК / по центру</div>' +
      '<div class="row2"><select id="p73posAl" style="flex:1;min-width:0">' + alignOpts() + '</select><button class="b" data-a="al" title="Модель экспортирована от начала этой СК — сдвинуть на её начало">Модель от начала СК</button></div>' +
      '<div class="row2"><button class="b" data-a="ctr" title="Центр габарита модели → центр касаний программы">Центр модели → центр касаний</button><button class="b" data-a="zero" title="Сбросить сдвиг и поворот (модель в своих координатах CAD)">Координаты CAD</button></div>' +
      '<div class="sec">🎯 Точная доводка (оси программы)</div>' +
      '<div class="opts"><span>Шаг, мм</span><select data-o="step">' + [0.01, 0.1, 0.5, 1, 5, 10, 50, 100].map(function (v) { return '<option' + (v === o.step ? ' selected' : '') + '>' + v + '</option>'; }).join('') + '</select><span>Угол, °</span><select data-o="astep">' + [0.01, 0.1, 0.5, 1, 5, 15, 45, 90].map(function (v) { return '<option' + (v === o.astep ? ' selected' : '') + '>' + v + '</option>'; }).join('') + '</select><span>Вокруг</span><select data-o="pivot" class="w3"><option value="center"' + (o.pivot === 'center' ? ' selected' : '') + '>центра модели</option><option value="zero"' + (o.pivot === 'zero' ? ' selected' : '') + '>нуля программы</option></select></div>' +
      '<div class="pad">' + ['X', 'Y', 'Z'].map(function (a, i) { return '<button class="b" data-mv="' + i + ':-1">' + a + '−</button><button class="b" data-mv="' + i + ':1">' + a + '+</button>'; }).join('') + ['X', 'Y', 'Z'].map(function (a, i) { return '<button class="b" data-rt="' + i + ':-1" title="Повернуть вокруг ' + a + ' против часовой">R' + a + '−</button><button class="b" data-rt="' + i + ':1" title="Повернуть вокруг ' + a + ' по часовой">R' + a + '+</button>'; }).join('') + '</div>' +
      '<div class="row2"><button class="b" data-a="drop" title="Опустить модель: низ габарита → минимальный Z касаний">Низ на касания по Z</button><button class="b" data-a="refine" title="Только точная подгонка от текущего положения (без перебора ориентаций)">✨ Довести точно</button></div>' +
      '<div class="sec">🔍 Проверка положения</div>' +
      '<div class="row2"><label><input type="checkbox" data-o="map"' + (o.map ? ' checked' : '') + '> Карта отклонений касаний (цвет точек)</label><button class="b" data-a="remap" title="Пересчитать карту">Обновить</button></div><div id="p73posDev"></div>' +
      '<div class="sec">🧮 Матрица модель → программа</div><div class="mtx" id="p73posMtx"></div>' +
      '<div class="row2"><button class="b" data-a="cpy">Копировать</button><button class="b" data-a="pst" title="Вставить 12 чисел (3 строки × 4) или 16 — матрица модель → программа">Вставить…</button></div>';
  }
  function refreshAll() { status(); renderAlt(); renderRows(); var mx = $('p73posMtx'); if (mx) mx.textContent = matrixTxt() || '—'; var al = $('p73posAl'); if (al && !al.options.length) al.innerHTML = alignOpts(); }
  function busy(on, txt) { var b = document.querySelector('#p73pos [data-a=fit]'); if (b) { b.disabled = on; b.textContent = on ? (txt || 'Подбор…') : '⚡ Привязать модель к программе'; } }
  function doFit(o) {
    busy(true); setTimeout(function () { var t0 = performance.now(), F; try { F = autoFit(o); } catch (e) { console.warn('r73 fit', e); F = { err: 'Ошибка: ' + e.message }; }
      LAST.fit = F; if (F && F.best && !F.err) { if (F.best.s.f >= 0.2) { applyFit(F.best); F.applied = 0; setTimeout(function () { var fc = G('focusCamera3'); if (typeof fc === 'function') try { fc(); } catch (e) {} }, 60); } else F.err = 'Надёжного совпадения нет (лучшее ' + Math.round(F.best.s.f * 100) + '%). Проверьте, та ли модель / операция; модель не сдвинута.'; }
      busy(false); refreshAll(); toast(F.err ? F.err : 'Модель привязана: ' + Math.round(F.best.s.f * 100) + '% касаний на поверхности (' + Math.round(performance.now() - t0) + ' мс)'); }, 30);
  }
  function onClick(e) {
    var b = e.target.closest('button'); if (!b || !b.closest('#p73pos')) return; var o = opt(), a = b.getAttribute('data-a');
    if (b.hasAttribute('data-alt')) { var F = LAST.fit, i = +b.getAttribute('data-alt'); if (F && F.top[i]) { if (F.applied != null && UNDO.length) setSnap(UNDO.pop()); applyFit(F.top[i]); F.applied = i; refreshAll(); } return; }
    if (b.hasAttribute('data-mv')) { var p = b.getAttribute('data-mv').split(':'), d = [0, 0, 0]; d[+p[0]] = +p[1] * o.step; moveBy(d); refreshAll(); return; }
    if (b.hasAttribute('data-rt')) { var p2 = b.getAttribute('data-rt').split(':'); rotateBy(+p2[0], +p2[1] * o.astep * Math.PI / 180); refreshAll(); return; }
    if (a === 'fit') doFit({ rot: o.rot });
    else if (a === 'refine') { busy(true, 'Подгонка…'); setTimeout(function () { var Gd = grids(), H = progHits(2500); if (!Gd || H.P.length < 6) { busy(false); toast('Нет модели или касаний'); return; } var Y = { R: [[1, 0, 0], [0, 1, 0], [0, 0, 1]], t: [0, 0, 0] }; icpTrans(Gd.fine, H.P, Y, 2, Gd.fine.cs * 2, 3); icpPlane(Gd.fine, H.P, Y, Gd.fine.cs * 2, 20, o.rot); var s = score(Gd.fine, H.P, Y, Math.max(0.1, Math.min(0.5, Gd.S.sp * 0.25))), Rt = tr3(Y.R), tt = mv3(Rt, Y.t);
      applyProg(M4(Rt, [-tt[0], -tt[1], -tt[2]])); LAST.fit = { best: { s: s, rotTxt: rotName(Rt), move: 0, X: null }, top: [], n: H.P.length, tol: 0, sp: Gd.S.sp }; busy(false); refreshAll(); toast('Доводка: ' + Math.round(s.f * 100) + '% касаний на поверхности, медиана ' + f3(s.med) + ' мм'); }, 30); }
    else if (a === 'undo') { if (!UNDO.length) { toast('Нечего отменять'); return; } setSnap(UNDO.pop()); refreshAll(); }
    else if (a === 'al') { var nm = ($('p73posAl') || {}).value, al = null; try { W.pcdBases.aligns().list.forEach(function (x) { if (x.name === nm) al = x; }); } catch (e2) {} if (!al) return; moveBy(al.Ot.slice()); refreshAll(); }
    else if (a === 'ctr') { var H2 = progHits(3000); if (!H2.P.length || !mesh()) return; var cq = [0, 1, 2].map(function (k) { var pp = pct(H2.P, k); return (pp[0] + pp[1]) / 2; }), cm = modelCenter(); moveBy([cq[0] - cm[0], cq[1] - cm[1], cq[2] - cm[2]]); refreshAll(); }
    else if (a === 'zero') { UNDO.push(snap()); setSnap({ x: 0, y: 0, z: 0, rx: 0, ry: 0, rz: 0 }); refreshAll(); }
    else if (a === 'drop') { var H3 = progHits(3000), T = TH(), m = mesh(); if (!H3.P.length || !m) return; var zq = pct(H3.P, 2)[0], bx = new T.Box3().setFromObject(m), inv = new T.Matrix4().copy(PM()).invert(), zmin = 1e18; [bx.min, bx.max].forEach(function (p1) { [bx.min, bx.max].forEach(function (p2) { [bx.min, bx.max].forEach(function (p3) { var v = new T.Vector3(p1.x, p2.y, p3.z).applyMatrix4(inv); zmin = Math.min(zmin, v.z); }); }); }); moveBy([0, 0, zq - zmin]); refreshAll(); }
    else if (a === 'remap') { GRID = null; buildMap(); }
    else if (a === 'cpy') { var t = matrixTxt(); try { navigator.clipboard.writeText(t); toast('Матрица скопирована'); } catch (e3) { prompt('Матрица:', t); } }
    else if (a === 'pst') { var s2 = prompt('Матрица модель → программа: 12 или 16 чисел (по строкам)', ''); if (!s2) return; var v = s2.replace(/,/g, ' ').split(/\s+/).filter(Boolean).map(Number).filter(isFinite); if (v.length < 12) { toast('Нужно 12 чисел'); return; }
      var T2 = TH(), m2 = mesh(); if (!m2) return; m2.updateMatrixWorld(true); var cur = new T2.Matrix4().copy(PM()).invert().multiply(m2.matrixWorld).multiply(PM()), tgt = new T2.Matrix4().set(v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8], v[9], v[10], v[11], 0, 0, 0, 1), A = tgt.multiply(cur.invert()), e4 = A.elements;
      applyProg(M4([[e4[0], e4[4], e4[8]], [e4[1], e4[5], e4[9]], [e4[2], e4[6], e4[10]]], [e4[12], e4[13], e4[14]])); refreshAll(); }
  }
  function onChange(e) { var x = e.target, k = x.getAttribute('data-o'); if (!k || !x.closest('#p73pos')) return; var v = x.type === 'checkbox' ? x.checked : (k === 'pivot' ? x.value : num(x.value)); setOpt(k, v); if (k === 'map') { if (v) buildMap(); else { dropMap(); renderRows(); } } }
  function install() {
    var ap = $('apTransform'); if (!ap) return false; if ($('p73pos')) return true;
    var s = document.createElement('style'); s.textContent = CSS; document.head.appendChild(s);
    var body = ap.querySelector('.ap2-body'), head = ap.querySelector('.ap2-head'); if (head && head.firstChild && head.firstChild.nodeType === 3) head.firstChild.textContent = '🧊 Положение модели';
    var d = document.createElement('div'); d.id = 'p73pos'; d.innerHTML = panelHtml(); body.insertBefore(d, body.firstChild);
    d.addEventListener('click', onClick); d.addEventListener('change', onChange);
    /* поля X/Y/Z/повороты/зеркала/пресеты — ниже, в раскрывающемся блоке «Числа и пресеты» */
    var tp = $('stlTransformPanel'); if (tp) { var sec = document.createElement('div'); sec.className = 'sec'; sec.textContent = '🔢 Числа, прозрачность, пресеты'; sec.style.cssText = 'font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:#7f95ad;font-weight:700;margin:10px 0 4px;border-top:1px solid rgba(255,255,255,.08);padding-top:8px'; body.insertBefore(sec, tp); }
    moveLegacy(body);
    [ 'stlOffX', 'stlOffY', 'stlOffZ', 'stlRotX', 'stlRotY', 'stlRotZ', 'stlScale' ].forEach(function (id) { var el = $(id); if (el) el.addEventListener('input', function () { GRID = null; setTimeout(refreshAll, 50); }); });
    refreshAll(); return true;
  }
  /* «Авто-совмещение по элементам», «Точные пары», «Зеркало 3D» — из «Элементы программы» в «Положение» */
  function moveLegacy(body) {
    var pg = $('apProgram'); if (!pg || $('p73legacy')) return; var pb = pg.querySelector('.ap2-body'), secs = [].slice.call(pb.querySelectorAll('.ap2Sec')), st = null, en = null;
    secs.forEach(function (s) { if (/Авто-совмещение модели/.test(s.textContent)) st = s; if (st && !en && /Список элементов/.test(s.textContent)) en = s; });
    if (!st) return; var det = document.createElement('details'); det.id = 'p73legacy'; det.innerHTML = '<summary>▸ По осям отверстий STEP, точные пары, зеркало 3D</summary>';
    var n = st; while (n && n !== en) { var nx = n.nextSibling; det.appendChild(n); n = nx; }
    body.appendChild(det);
  }

  /* ======================= чистка дублей в «Элементы программы» и «Отображение 3D» ======================= */
  var OLD = ['showHitsCb', 'showTrajCb', 'showSimCb', 'showProbeCb', 'showMachineCb', 'showWcsCb'];
  function cleanup() {
    var pg = $('apProgram'); if (!pg || $('p73cmm')) return !!pg;
    OLD.forEach(function (id) { var cb = $(id); if (!cb) return; if (cb.checked) { cb.checked = false; cb.dispatchEvent(new Event('change', { bubbles: true })); } var l = cb.closest('label'); if (l) l.style.display = 'none'; var mc = $('v3d-' + id), ml = mc && mc.closest('label'); if (ml) ml.style.display = 'none'; else if (mc) mc.parentNode.style.display = 'none'; });
    ['cmmMachX', 'cmmPlayBtn', 'cmmSpeedIn', 'cmmSlowSl'].forEach(function (id) { var el = $(id), r = el && el.closest('.row'); if (r) r.style.display = 'none'; });
    var sl = $('cmmStatsLine'); if (sl) sl.style.display = 'none';
    var hd = [].filter.call(pg.querySelectorAll('.ap2Sec'), function (s) { return /CMM: щуп и прогон/.test(s.textContent); })[0];
    var p = P7(), go = function (fn) { return function () { try { fn(); } catch (e) { console.warn(e); } }; };
    var B = [['▶ Прогон щупа в 3D (с часами)', function () { p.startPlay(0); }], ['⏱ Время выполнения', function () { p.openTime(); }], ['✋ Ручное управление щупом', function () { p.openJog(); }], ['🛡 Проверка столкновений', function () { p.openJog(); setTimeout(p.checkProgram, 50); }],
      ['🔧 Конструктор щупа', function () { p.openBuilder(); }], ['🧰 UCCserver: щупы, магазины, сферы', function () { W.pcdUcc.open(); }], ['🏭 Модель КИМ', function () { p.openCMM(); }], ['🗄 Магазин щупов', function () { p.openRack(); }],
      ['🧭 Базы и СК', function () { W.pcdBases.open(); }], ['🎯 Касания из PRG вкл/выкл', function () { if (W.prgHits) W.prgHits.toggle(); }]];
    var box = document.createElement('div'); box.id = 'p73cmm'; box.style.cssText = 'display:grid;grid-template-columns:1fr 1fr;gap:4px;margin:2px 0 6px';
    B.forEach(function (x) { var b = document.createElement('button'); b.className = 'btn'; b.style.cssText = 'font-size:11px;justify-content:center;padding:5px 4px'; b.textContent = x[0]; b.addEventListener('click', go(x[1])); box.appendChild(b); });
    if (hd) { hd.textContent = 'CMM: щуп, прогон, время (меню «Щуп»)'; hd.parentNode.insertBefore(box, hd.nextSibling); }
    /* «Отображение 3D» → группа «CMM и прогон»: вместо старых — новые переключатели */
    var g2 = $('view3dGroup2'); if (g2 && !$('p73v3d')) { var d = document.createElement('div'); d.id = 'p73v3d';
      var mk = function (lab, on, fn) { var l = document.createElement('label'); l.className = 'checkbox-row'; l.style.fontSize = '12px'; var c = document.createElement('input'); c.type = 'checkbox'; c.checked = on; c.addEventListener('change', function () { fn(c.checked); }); l.appendChild(c); l.appendChild(document.createTextNode(' ' + lab)); d.appendChild(l); };
      var bo = W.pcdBases ? W.pcdBases.opt() : {};
      mk('🎯 Касания из PRG (реальные точки)', true, function () { if (W.prgHits) W.prgHits.toggle(); });
      mk('🧭 СК программы (триады)', bo.show !== false, function (v) { W.pcdBases.setOpt('show', v); W.pcdBases.build3(); });
      mk('⌖ Базовые элементы СК', bo.base !== false, function (v) { W.pcdBases.setOpt('base', v); W.pcdBases.build3(); });
      mk('🌈 Карта отклонений касаний от модели', opt().map, function (v) { setOpt('map', v); if (v) buildMap(); else { dropMap(); renderRows(); } var c2 = document.querySelector('#p73pos [data-o=map]'); if (c2) c2.checked = v; });
      g2.appendChild(d); }
    return true;
  }
  var n = 0, iv = setInterval(function () { var a = install(), b = cleanup(); if ((a && b && n > 6) || ++n > 80) clearInterval(iv); }, 500);
  /* после загрузки модели / программы — сбросить кэш поверхности, обновить вкладку */
  var sig = ''; setInterval(function () { var m = mesh(), p = P7(), s2 = (m ? m.uuid : '') + ':' + (p && p.last ? p.last.at : ''); if (s2 !== sig) { sig = s2; GRID = null; LAST.fit = null; if (opt().map) setTimeout(buildMap, 200); else dropMap(); var al = $('p73posAl'); if (al) al.innerHTML = alignOpts(); refreshAll(); } }, 1000);
  W.pcdPos = { _score: function (tol) { var Gd = grids(), H = progHits(2500); return score(Gd.fine, H.P, { R: [[1, 0, 0], [0, 1, 0], [0, 0, 1]], t: [0, 0, 0] }, tol); }, _M4: M4, _i: { distField: distField, mv3: mv3, icpTrans: icpTrans, icpPlane: icpPlane, score: score, progHits: progHits }, autoFit: autoFit, applyFit: applyFit, applyProg: applyProg, moveBy: moveBy, rotateBy: rotateBy, grids: grids, devAll: devAll, buildMap: buildMap, last: LAST, undo: function () { if (UNDO.length) setSnap(UNDO.pop()); }, refresh: refreshAll, matrixTxt: matrixTxt };
})();
